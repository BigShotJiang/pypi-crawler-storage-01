# Copyright 2023 OpenSynergy Indonesia
# Copyright 2023 PT. Simetri Sinergi Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    company_ownership_type,
    company_entity_type,
    res_partner,
    partner_contact_group,
    res_partner_religion,
    res_partner_ethnicity,
)
