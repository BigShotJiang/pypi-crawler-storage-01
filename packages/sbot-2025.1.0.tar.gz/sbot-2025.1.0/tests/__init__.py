"""Tests for the sbot module."""
