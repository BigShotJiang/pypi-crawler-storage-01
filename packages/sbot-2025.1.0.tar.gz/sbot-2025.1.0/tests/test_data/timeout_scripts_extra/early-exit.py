from sbot.internal.timeout import kill_after_delay

kill_after_delay(2)
