from sbot.internal.timeout import kill_after_delay
import time

kill_after_delay(2)

time.sleep(10)
