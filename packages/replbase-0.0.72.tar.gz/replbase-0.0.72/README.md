# replbase
A Python tool that combines some features from other REPL packages into one neat reusable base class
