PART_DATE_CONTEXT_PROMPT = """
### Date Context: 
Today is "{current_date}".
The current year is "{current_year}".
"""
