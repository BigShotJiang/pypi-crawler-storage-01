from enum import Enum


class ProblemType(Enum):
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
