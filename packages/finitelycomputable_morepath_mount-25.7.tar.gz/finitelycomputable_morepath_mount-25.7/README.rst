==============
Morepath-Mount
==============

This application provides a /wsgi_info/ endpoint and uses mount() to combine all
of the Morepath modules that it finds in the virtual environment.
