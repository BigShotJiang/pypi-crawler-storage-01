from enum import Enum


class GivingType(int, Enum):
    SAME = 0
    RANDOM = 1
