#!/usr/bin/env zsh

uv run promptdir --history
