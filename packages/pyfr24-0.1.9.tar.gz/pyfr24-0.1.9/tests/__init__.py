"""
Test package for pyfr24.
""" 