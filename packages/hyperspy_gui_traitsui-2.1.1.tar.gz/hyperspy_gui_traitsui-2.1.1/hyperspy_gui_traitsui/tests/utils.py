
KWARGS = {
    "toolkit": "traitsui",
    "display": True,
}
