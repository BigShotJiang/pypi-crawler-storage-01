# Authors

The following people (in alphabetical order) have [contributed to this repository](https://github.com/eclipse-tractusx/industry-core-hub):

| Name | Project Role | Company Role | Company | GitHub |
|--|--|--|--|--|
| Borja Gómez | DevOps Engineer | | LKS Next - Spain | [@gomezbc](https://github.com/gomezbc) |
| Carlos Diez Rodriguez | Backend Engineer | | LKS Next - Spain | [@CDiezRodriguez](https://github.com/CDiezRodriguez) |
| Mathias Brunkow Moser | Architect & Technical Lead | Eclipse Tractus-X Project Lead & Chief Software Architect | Catena-X Automotive Network e.V. | [@matbmoser](https://github.com/matbmoser) |
| Mikel Garcia Bartolome | Full-Stack Engineer | | LKS Next - Spain | [@mgarciaLKS](https://github.com/mgarciaLKS) |
| Michael Scholz | Architect | Software Technology Architect | DRÄXLMAIER Group | [@sm29105](https://github.com/sm29105) |
| Patxi Juaristi Pagegi | Full-Stack Engineer | Cloud Computing Researcher | Ikerlan | [@pjuaristi-ikerlan](https://github.com/pjuaristi-ikerlan) |
| Samuel Roy | Backend Engineer | Consultant | Capgemini | [@samuelroywork](https://github.com/samuelroywork) |
| Alejandro Granizo Castro | Junior Full-Stack Engineer | Junior Backend Engineer | XITASO | [@alejandrogranizo](https://github.com/alejandrogranizo) |
| Koichi Hokonohara | Full-Stack Engineer | Senior Researcher | Fujitsu Ltd | [@hokonohara](https://github.com/hokonohara) |
| Sonam Aggarwal | Frontend Engineer | Senior Consultant | Capgemini | [@sonama](https://github.com/sonama) |
