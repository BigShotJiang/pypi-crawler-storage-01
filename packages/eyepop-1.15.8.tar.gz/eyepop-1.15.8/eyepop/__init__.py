__version__ = '1.0.2'

import eyepop.eyepopsdk
import eyepop.worker.worker_jobs
import eyepop.visualize

EyePopSdk = eyepopsdk.EyePopSdk
Job = eyepop.worker.worker_jobs.WorkerJob
Plot = visualize.EyePopPlot
