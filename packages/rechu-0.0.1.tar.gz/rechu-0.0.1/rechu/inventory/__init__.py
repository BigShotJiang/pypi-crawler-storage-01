"""
Submodule for inventory of grouped models.
"""

__all__: list[str] = []
