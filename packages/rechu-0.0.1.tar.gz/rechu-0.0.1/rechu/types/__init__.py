"""
Attribute types for model properties.
"""
