# SPDX-FileCopyrightText: 2025-present U.N. Owen <void@some.where>
#
# SPDX-License-Identifier: MIT

import pydagoras.node as Node
Node = node.Node

import pydagoras.dag_dot as DAG
DAG = dag_dot.DAG

import pydagoras.dag_dot as calc 
calc = dag_dot.calc
