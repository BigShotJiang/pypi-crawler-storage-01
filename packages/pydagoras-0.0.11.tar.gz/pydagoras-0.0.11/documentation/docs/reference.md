#Code reference
This page documents the code in the pydagoras package, and has been made with the help of mkdocstrings.

##dag_dot.py
::: pydagoras.dag_dot


##node.py
::: pydagoras.node

