
# Note
This is just a scratch page that has been used to practice code documentation.</br>


Lorem ipsum dolor sit amet, (1) consectetur adipiscing elit.
{ .annotate }

1.  :man_raising_hand: I'm an annotation! I can contain `code`, __formatted
    text__, images, ... basically anything that can be expressed in Markdown.


The `#!python range()` function is used to generate a sequence of numbers.

``` yaml
theme:
  features:
    - content.code.annotate # (1)
```

1.  :man_raising_hand: I'm a code annotation! I can contain `code`, __formatted
    text__, images, ... basically anything that can be written in Markdown.



``` python title="eg.py" linenums="10" hl_lines="2-4"
import this
  
def egfunc(i):
theme:
  print (i) # (1)
  features:
    - content.code.annotate # (2)
    - content.code.annotate # (3)
```

1.  comment x I'm a code annotation! I can contain `code`, __formatted
2.  comment y I'm a code annotation! I can contain `code`, __formatted
3.  comment z I'm a code annotation! I can contain `code`, __formatted



