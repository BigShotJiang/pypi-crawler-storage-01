# pydagoras
A Direct Acyclical Graph (DAG) library for Python

## Further documentation
[pydagoras documentation](https://markhallett.github.io/pydagoras/)
