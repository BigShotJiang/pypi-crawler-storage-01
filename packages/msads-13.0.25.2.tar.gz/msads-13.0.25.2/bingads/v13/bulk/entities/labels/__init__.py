__author__ = 'Bing Ads SDK Team'
__email__ = 'bing_ads_sdk@microsoft.com'

from .bulk_label import *
from .bulk_label_associations import *
