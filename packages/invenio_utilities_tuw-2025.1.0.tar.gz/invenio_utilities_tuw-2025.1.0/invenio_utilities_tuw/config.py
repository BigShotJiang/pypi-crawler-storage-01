# -*- coding: utf-8 -*-
#
# Copyright (C) 2020 - 2025 TU Wien.
#
# Invenio-Utilities-TUW is free software; you can redistribute it and/or
# modify it under the terms of the MIT License; see LICENSE file for more
# details.

"""Configuration for Invenio-Utilities-TUW."""
