from typing import Generator, List
import requests
import os
import openai
from openai import AzureOpenAI as _AzureAPI
from openai import OpenAI as _OpenAIAPI

from micro_graph.ai.types import ChatMessage


class LLMAPI(object):
    def embeddings(self, model: str, input: str | List[str]) -> List[List[float]]:
        raise NotImplementedError("This method should be implemented by subclasses.")
        
    def chat(self, model: str, messages: List[ChatMessage], max_tokens: int = -1) -> str:
        raise NotImplementedError("This method should be implemented by subclasses.")

    def chat_stream(self, model: str, messages: List[ChatMessage], max_tokens: int = -1) -> Generator[str, None, None]:
        raise NotImplementedError("This method should be implemented by subclasses.")

    def get_models(self) -> list[str]:
        raise NotImplementedError("This method should be implemented by subclasses.")


class LLM(LLMAPI):
    def __init__(self, api_endpoint: str, api_key: str, provider: str = "OpenAI", model: str = "AUTODETECT"):
        self._llms = {}
        if provider == "ollama":
            if model == "AUTODETECT":
                modelListEndpoint = api_endpoint + "/api/tags"
                response = requests.get(modelListEndpoint)
                response.raise_for_status()
                data = response.json()
                models: list[str] = [model["name"] for model in data["models"]]
            else:
                models = [model]
            for model in models:
                self._llms[model] = _OpenAIAPI(base_url=api_endpoint + "/v1", api_key=api_key)
        else:
            if model == "AUTODETECT":
                raise ValueError("Model must be specified when not using ollama provider.")
            if provider == "AzureOpenAI":
                self._llms[model] = _AzureAPI(api_version="2024-10-21", base_url=api_endpoint, api_key=api_key)
            else:
                self._llms[model] = _OpenAIAPI(base_url=api_endpoint, api_key=api_key)

    def embeddings(self, model: str, input: str | List[str]) -> List[List[float]]:
        response = self._llms[model].embeddings.create(input=input, model=model)
        return [d.embedding for d in response.data]

    def chat(self, model: str, messages: List[ChatMessage], max_tokens: int = -1) -> str:
        try:            
            response = self._llms[model].chat.completions.create(model=model, messages=messages, max_tokens=max_tokens, stream=False)
        except openai.NotFoundError as e:
            raise RuntimeError(str(e))
        if response.choices[0].finish_reason == "error":
            raise RuntimeError(response.choices[0].message.content)
        return response.choices[0].message.content or ""
    
    def chat_stream(self, model: str, messages: List[ChatMessage], max_tokens: int = -1) -> Generator[str, None, None]:
        try:            
            response = self._llms[model].chat.completions.create(model=model, messages=messages, max_tokens=max_tokens, stream=True)
        except openai.NotFoundError as e:
            raise RuntimeError(str(e))
        return LLM._stream_wrapper(response)

    def get_models(self) -> list[str]:
        return list(self._llms.keys())

    @staticmethod
    def _stream_wrapper(stream):
        for chunk in stream:
            yield chunk.choices[0].delta.content or ""


def get_llm_and_model_from_env() -> tuple[LLM, str]:
    llm = LLM(
        api_endpoint=os.environ.get("API_ENDPOINT", "http://localhost:11434"),
        api_key=os.environ.get("API_KEY", "ollama"),
        provider=os.environ.get("PROVIDER", "ollama"),
        model=os.environ.get("MODEL", "AUTODETECT"),
    )
    model = os.environ.get("MODEL", "gemma3:12b")
    return llm, model
