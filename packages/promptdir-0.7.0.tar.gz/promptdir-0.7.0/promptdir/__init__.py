# Prompt Directory package
from .cli import cli

def main():
    cli()