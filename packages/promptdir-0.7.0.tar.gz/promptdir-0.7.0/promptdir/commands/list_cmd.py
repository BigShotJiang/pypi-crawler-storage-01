"""List command implementation."""

def list_snippets(repo):
    """List all available snippets in the repository."""
    repo.list_snippet_names()
