# Quimb Example Notebooks

These notebooks are rendered by ``nbsphinx`` into the main docs [here](https://quimb.readthedocs.io/en/latest/#examples). Although the code and markdown cells are pre-viewable on github, for example, the raw restructured text cells will **not** render and so much explanatory text might be missing.
