# Tensor Network Guide

```{toctree}
:numbered:
:maxdepth: 2

tensor-basics
tensor-contraction
tensor-drawing
tensor-optimization
tensor-1d
tensor-2d
tensor-circuit
tensor-circuit-mps
tensor-design
```
