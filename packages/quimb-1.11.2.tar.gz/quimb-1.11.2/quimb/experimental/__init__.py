"""Submodule for experimental features that are likely untested and subject to
change.
"""