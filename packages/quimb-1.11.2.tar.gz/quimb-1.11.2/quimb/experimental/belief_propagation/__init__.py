import warnings

from quimb.tensor.belief_propagation import *

warnings.warn(
    "Most functionality of 'quimb.experimental.belief_propagation' "
    "has been moved to `quimb.tensor.belief_propagation`.",
)
