.. click:: nerfbaselines.__main__:main
     :prog: nerfbaselines
     :nested: full
