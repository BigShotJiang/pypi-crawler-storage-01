"""Three sixty image processing."""
