## cdf 

### Added

- [alpha] New command `cdf migrate canvas` that enables migration of
Canvas from asset-centric to data modeling.

## templates

No changes.