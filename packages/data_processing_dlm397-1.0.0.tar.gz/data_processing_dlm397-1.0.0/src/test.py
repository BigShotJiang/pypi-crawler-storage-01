import os
print(os.getcwd())

from data_processing_dlm397 import config_loader as sc

print(sc.get_home_path())