#!/bin/sh

rm -rf ../cochl-sense-py/README.md
cp -f ./README.md ../cochl-sense-py

rm -rf ../cochl-sense-py/samples
cp -rf ./samples ../cochl-sense-py
