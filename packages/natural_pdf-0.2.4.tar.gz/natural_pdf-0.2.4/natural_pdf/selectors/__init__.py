"""
Selector module for natural-pdf.
"""

from natural_pdf.selectors.parser import parse_selector, selector_to_filter_func
