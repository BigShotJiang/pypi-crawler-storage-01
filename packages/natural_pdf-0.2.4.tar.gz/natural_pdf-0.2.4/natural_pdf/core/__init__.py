"""
Core classes for Natural PDF.
"""
