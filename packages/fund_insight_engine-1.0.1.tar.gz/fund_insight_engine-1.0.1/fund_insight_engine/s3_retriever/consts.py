
# consts example
LIFE_MANAGERS_OF_DIVISION_01 = ['강대권', '이대상']
LIFE_MANAGERS_OF_DIVISION_02 = ['남두우', '이시우']

FUND_CLASSES = ['운용펀드', '-', '일반', '클래스펀드']
FUND_TYPES = ['주식형', '주식혼합', '채권혼합', '혼합자산', '변액']
