
# MongoDB Field Constants
DATE_REF_FIELD_NAME = 'date_ref'
FUND_CODE_FIELD_NAME = 'fund_code'
DATA_FIELD_NAME = 'data'
MONGODB_ID_FIELD_NAME = '_id'
