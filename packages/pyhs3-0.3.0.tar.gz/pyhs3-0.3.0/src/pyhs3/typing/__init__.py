"""
typing
"""

from __future__ import annotations

from pyhs3.typing.aliases import TensorVar

__all__ = ("TensorVar",)
