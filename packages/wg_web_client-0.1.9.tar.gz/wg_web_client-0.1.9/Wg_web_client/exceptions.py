class WGAutomationError(Exception):
    """Исключение, возникающее при ошибках автоматизации WireGuard."""
    pass
