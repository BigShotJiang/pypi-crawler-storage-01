.. mdinclude:: ../README.md

.. toctree::
   :hidden:

   getting-started/index
   reference/index
