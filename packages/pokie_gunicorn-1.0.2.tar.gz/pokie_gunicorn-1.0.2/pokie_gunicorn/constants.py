# Version
POKIE_GUNICORN_VERSION = ["1", "0", "2"]


def get_version():
    return ".".join(POKIE_GUNICORN_VERSION)
