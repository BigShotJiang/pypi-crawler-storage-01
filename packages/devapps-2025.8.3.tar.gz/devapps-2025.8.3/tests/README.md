# Tests?!

Most tests are currently lit. programming tests, i.e. in `docs/*.md.lp`.
