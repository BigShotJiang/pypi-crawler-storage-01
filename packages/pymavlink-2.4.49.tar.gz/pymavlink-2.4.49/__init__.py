'''Python MAVLink library - see https://mavlink.io/en/'''
__version__ = '2.4.49'
