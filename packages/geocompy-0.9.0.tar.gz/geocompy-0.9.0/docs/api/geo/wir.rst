:icon: material/arrow-right-bottom

Word Index Registration
=======================

.. automodule:: geocompy.geo.wir
    :inherited-members:

    Definitions
    -----------
