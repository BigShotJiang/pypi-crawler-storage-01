:icon: material/package

.. automodule:: geocompy
