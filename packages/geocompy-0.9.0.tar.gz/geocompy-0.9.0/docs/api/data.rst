:icon: material/code-brackets

Data
====

.. automodule:: geocompy.data
    :exclude-members: RO,PI2,_E

    Definitions
    -----------
