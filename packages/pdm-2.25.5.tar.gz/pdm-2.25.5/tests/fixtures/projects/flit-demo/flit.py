"""An awesome flit demo"""
__version__ = "0.1.0"
