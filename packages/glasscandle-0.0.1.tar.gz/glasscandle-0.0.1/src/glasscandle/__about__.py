# SPDX-FileCopyrightText: 2025-present Wytamma Wirth <wytamma.wirth@me.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
