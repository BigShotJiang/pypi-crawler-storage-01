::: src.glasscandle.providers.bioconda

::: src.glasscandle.providers.url

::: src.glasscandle.providers.pypi

::: src.glasscandle.providers.base

