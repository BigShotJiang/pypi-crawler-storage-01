def random_compliment():
    compliments = ["You're awesome!", "You light up the room!", "You're a coding star!"]
    import random
    return random.choice(compliments)

def fuck():
    print("fch1na")
