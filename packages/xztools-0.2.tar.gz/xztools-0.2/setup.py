from setuptools import setup

setup(
    name='xztools',
    version='0.2',
    packages=['xztools'],
    description='A fun library to generate random compliments!',
    author='Her Name',
    author_email='her_email@example.com',
)