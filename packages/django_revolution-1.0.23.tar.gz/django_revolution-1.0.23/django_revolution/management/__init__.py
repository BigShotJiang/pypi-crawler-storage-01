"""
Django Revolution Management Commands

Django management commands for OpenAPI client generation.
""" 