# Backup-chan client configuration

This is the module responsible for the client-side connection configuration.

## Installing

```bash
# The easy way
pip install backupchan-client-config

# Installing from source
git clone https://github.com/Backupchan/client-config.git backupchan-client-config
cd backupchan-client-config
pip install .
```
