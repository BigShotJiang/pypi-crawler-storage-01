#. Go to Settings > General Settings.
#. In the 'Progressive Web App' section you can configure all the data.
