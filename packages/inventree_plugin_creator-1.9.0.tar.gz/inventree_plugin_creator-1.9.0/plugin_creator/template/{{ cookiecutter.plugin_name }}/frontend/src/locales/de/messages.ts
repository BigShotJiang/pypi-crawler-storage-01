export const messages = {
    "panel.greeting": "Übersetzter Text, bereitgestellt durch benutzerdefinierten Code!"
}