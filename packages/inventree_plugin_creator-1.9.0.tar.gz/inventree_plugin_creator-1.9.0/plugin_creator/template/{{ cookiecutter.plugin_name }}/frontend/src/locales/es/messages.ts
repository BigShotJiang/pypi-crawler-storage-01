export const messages = {
    "panel.greeting": "¡Texto traducido, proporcionado por código personalizado!"
};