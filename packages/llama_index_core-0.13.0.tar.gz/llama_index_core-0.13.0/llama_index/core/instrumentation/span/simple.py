from llama_index_instrumentation.span.simple import SimpleSpan  # noqa
