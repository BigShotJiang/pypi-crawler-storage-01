# for backwards compatibility
from llama_index.core.base.base_retriever import BaseRetriever

__all__ = [
    "BaseRetriever",
]
