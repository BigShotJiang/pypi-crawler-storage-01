"""Version information for the knowlithic LiveKit plugin."""

__version__ = "0.1.2"
