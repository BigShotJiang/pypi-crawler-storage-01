from globalgenie.embedder.base import Embedder

__all__ = [
    "Embedder",
]
