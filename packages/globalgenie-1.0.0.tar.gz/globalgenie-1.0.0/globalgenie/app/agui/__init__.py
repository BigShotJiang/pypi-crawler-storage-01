from globalgenie.app.agui.app import AGUIApp

__all__ = ["AGUIApp"]
