from globalgenie.models.deepinfra.deepinfra import DeepInfra

__all__ = [
    "DeepInfra",
]
