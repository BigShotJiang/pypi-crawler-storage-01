VERSION = '0.5.3'
USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0'
INTERNAL_USER_AGENT = 'bandcampsync/' + VERSION
