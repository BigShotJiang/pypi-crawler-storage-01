# LlamaIndex Embeddings Integration: Mistralai
