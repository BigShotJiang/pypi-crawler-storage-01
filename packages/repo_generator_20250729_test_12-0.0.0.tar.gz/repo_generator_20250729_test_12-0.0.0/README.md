# repo_generator_20250729_test_12

## Quick start

```bash
pip install repo_generator_20250729_test_12
```

```python
from repo_generator_20250729_test_12 import ...
```

## Contributing

```bash
# clone the repo
git clone https://github.com/momomozhang/repo_generator_20250729_test_12.git

# install the dev dependencies
make install

# run the tests
make test
```
