..
    Copyright (C) 2021 Graz University of Technology.

    invenio-alma is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.


.. include:: ../CHANGES.rst
