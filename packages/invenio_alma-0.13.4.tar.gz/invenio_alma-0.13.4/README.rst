..
    Copyright (C) 2021 Graz University of Technology.

    invenio-alma is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

==============
 invenio-alma
==============

.. image:: https://github.com/tu-graz-library/invenio-alma/workflows/CI/badge.svg
        :target: https://github.com/tu-graz-library/invenio-alma/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/tu-graz-library/invenio-alma.svg
        :target: https://github.com/tu-graz-library/invenio-alma/releases

.. image:: https://img.shields.io/pypi/dm/invenio-alma.svg
        :target: https://pypi.python.org/pypi/invenio-alma

.. image:: https://img.shields.io/github/license/tu-graz-library/invenio-alma.svg
        :target: https://github.com/tu-graz-library/invenio-alma/blob/master/LICENSE

Invenio module to connect InvenioRDM to Alma

Further documentation is available on
https://invenio-alma.readthedocs.io/
