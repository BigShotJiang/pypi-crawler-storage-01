# -*- coding: utf-8 -*-
#
# Copyright (C) 2022 Graz University of Technology.
#
# invenio-alma is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Alma utils."""


def jpath_to_xpath(field_json_path: str) -> str:  # noqa: ARG001
    """Convert json path to xpath."""
    msg = "not yet implemented"
    raise RuntimeError(msg)
