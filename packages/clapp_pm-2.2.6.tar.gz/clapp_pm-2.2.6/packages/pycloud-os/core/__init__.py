"""
PyCloud OS Core Modülleri
Sistem çekirdeği ve temel işlevsellik
"""

__version__ = "0.9.0-dev"
__author__ = "PyCloud Team" 