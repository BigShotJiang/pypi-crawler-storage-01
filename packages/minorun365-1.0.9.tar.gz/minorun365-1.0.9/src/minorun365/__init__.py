"""
minorun365 Profile Card
-----------------

minorun365のプロフィールを表示
"""

__version__ = "1.0.9"