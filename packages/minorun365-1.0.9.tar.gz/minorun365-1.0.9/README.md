# minorun365-card

minorun365のプロフィールを表示するCLIカードパッケージです。

```zsh
uvx minorun365
```