"""
Welcome to Youtube Autonomous Shortcodes Module.

This shortcode modules is the one that handles
the shortcodes within a text. First, you need
to register the shortcodes you want to be 
detected. Then, the system will detect them and
extract the attributes and content information,
and leave those shortcodes simplified in the 
text.

After this, those shortcodes are searched
again one by one to obtain the previous and the
next word indexes so we are able to know the
moment in which each shortcode must be applied.

TODO: Explain the process in the code: First,
register shortcodes in X file, then add them in
Y file and create a global shortcodes variable
bla bla bla.
"""