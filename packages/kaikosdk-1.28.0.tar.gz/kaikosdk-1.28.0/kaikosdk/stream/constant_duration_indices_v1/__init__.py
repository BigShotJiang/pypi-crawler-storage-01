name='constant_duration_indices_v1'
