name='aggregated_price_v1'
