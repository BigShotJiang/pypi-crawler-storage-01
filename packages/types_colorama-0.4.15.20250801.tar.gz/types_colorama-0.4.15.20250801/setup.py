
from setuptools import setup

setup(package_data={'colorama-stubs': ['__init__.pyi', 'ansi.pyi', 'ansitowin32.pyi', 'initialise.pyi', 'win32.pyi', 'winterm.pyi', 'METADATA.toml', 'py.typed']})
