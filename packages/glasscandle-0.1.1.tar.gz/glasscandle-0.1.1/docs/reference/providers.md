::: src.glasscandle.providers.conda

::: src.glasscandle.providers.bioconda

::: src.glasscandle.providers.condaforge

::: src.glasscandle.providers.url

::: src.glasscandle.providers.pypi

::: src.glasscandle.providers.base

