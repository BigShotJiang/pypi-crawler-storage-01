# SPDX-FileCopyrightText: 2025-present Wytamma Wirth <wytamma.wirth@me.com>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == "__main__":
    from glasscandle.cli import watcher

    sys.exit(watcher())
