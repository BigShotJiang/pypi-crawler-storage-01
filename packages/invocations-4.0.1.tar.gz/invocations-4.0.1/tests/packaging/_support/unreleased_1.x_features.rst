=========
Changelog
=========

.. Notably, no release yet for 1.1.0

* :release:`1.0.1 <2014-01-02>`
* :feature:`2` New! Improved!
* :bug:`1` Fix a bug.
* :release:`1.0.0 <2014-01-01>`
