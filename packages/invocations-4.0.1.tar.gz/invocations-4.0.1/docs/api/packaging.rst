=============
``packaging``
=============

``packaging.release``
=====================

.. automodule:: invocations.packaging.release


``packaging.vendorize``
=======================

.. automodule:: invocations.packaging.vendorize
