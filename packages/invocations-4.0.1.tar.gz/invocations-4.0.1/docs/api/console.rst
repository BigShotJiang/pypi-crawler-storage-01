===========
``console``
===========

.. automodule:: invocations.console
