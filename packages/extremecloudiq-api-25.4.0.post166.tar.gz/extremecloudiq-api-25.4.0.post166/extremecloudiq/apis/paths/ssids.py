from extremecloudiq.paths.ssids.get import ApiForget


class Ssids(
    ApiForget,
):
    pass
