from extremecloudiq.paths.dashboard_wireless_client_health_frequency_distribution.post import ApiForpost


class DashboardWirelessClientHealthFrequencyDistribution(
    ApiForpost,
):
    pass
