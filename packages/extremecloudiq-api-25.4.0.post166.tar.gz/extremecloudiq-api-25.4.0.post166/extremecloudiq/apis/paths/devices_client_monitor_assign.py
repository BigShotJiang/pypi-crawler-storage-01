from extremecloudiq.paths.devices_client_monitor_assign.post import ApiForpost


class DevicesClientMonitorAssign(
    ApiForpost,
):
    pass
