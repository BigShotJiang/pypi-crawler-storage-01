from extremecloudiq.paths.devices_location_revoke.post import ApiForpost


class DevicesLocationRevoke(
    ApiForpost,
):
    pass
