from extremecloudiq.paths.radio_profiles_mac_ouis_id.get import ApiForget
from extremecloudiq.paths.radio_profiles_mac_ouis_id.put import ApiForput
from extremecloudiq.paths.radio_profiles_mac_ouis_id.delete import ApiFordelete


class RadioProfilesMacOuisId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
