from extremecloudiq.paths.copilot_anomalies_port_efficiency_speed_duplex_stats.get import ApiForget


class CopilotAnomaliesPortEfficiencySpeedDuplexStats(
    ApiForget,
):
    pass
