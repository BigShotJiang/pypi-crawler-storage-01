from extremecloudiq.paths.afc_recalculate_site_id.post import ApiForpost


class AfcRecalculateSiteId(
    ApiForpost,
):
    pass
