from extremecloudiq.paths.hiq_context_reading.get import ApiForget
from extremecloudiq.paths.hiq_context_reading.put import ApiForput


class HiqContextReading(
    ApiForget,
    ApiForput,
):
    pass
