from extremecloudiq.paths.packetcaptures_id_stop.post import ApiForpost


class PacketcapturesIdStop(
    ApiForpost,
):
    pass
