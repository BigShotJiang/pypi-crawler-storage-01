from extremecloudiq.paths.network_policies_id_ssids_remove.post import ApiForpost


class NetworkPoliciesIdSsidsRemove(
    ApiForpost,
):
    pass
