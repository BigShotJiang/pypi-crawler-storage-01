from extremecloudiq.paths.logs_audit.get import ApiForget


class LogsAudit(
    ApiForget,
):
    pass
