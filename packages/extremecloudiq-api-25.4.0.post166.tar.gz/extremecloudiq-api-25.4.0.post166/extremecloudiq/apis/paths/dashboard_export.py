from extremecloudiq.paths.dashboard_export.post import ApiForpost


class DashboardExport(
    ApiForpost,
):
    pass
