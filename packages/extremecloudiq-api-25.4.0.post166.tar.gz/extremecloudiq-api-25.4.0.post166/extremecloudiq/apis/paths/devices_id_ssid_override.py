from extremecloudiq.paths.devices_id_ssid_override.post import ApiForpost


class DevicesIdSsidOverride(
    ApiForpost,
):
    pass
