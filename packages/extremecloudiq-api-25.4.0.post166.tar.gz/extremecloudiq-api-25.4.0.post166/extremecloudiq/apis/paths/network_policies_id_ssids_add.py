from extremecloudiq.paths.network_policies_id_ssids_add.post import ApiForpost


class NetworkPoliciesIdSsidsAdd(
    ApiForpost,
):
    pass
