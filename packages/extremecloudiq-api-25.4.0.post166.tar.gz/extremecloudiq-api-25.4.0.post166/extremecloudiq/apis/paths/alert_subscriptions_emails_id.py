from extremecloudiq.paths.alert_subscriptions_emails_id.get import ApiForget
from extremecloudiq.paths.alert_subscriptions_emails_id.put import ApiForput
from extremecloudiq.paths.alert_subscriptions_emails_id.delete import ApiFordelete


class AlertSubscriptionsEmailsId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
