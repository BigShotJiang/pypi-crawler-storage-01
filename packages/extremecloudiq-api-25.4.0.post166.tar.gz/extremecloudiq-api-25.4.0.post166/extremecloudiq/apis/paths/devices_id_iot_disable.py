from extremecloudiq.paths.devices_id_iot_disable.post import ApiForpost


class DevicesIdIotDisable(
    ApiForpost,
):
    pass
