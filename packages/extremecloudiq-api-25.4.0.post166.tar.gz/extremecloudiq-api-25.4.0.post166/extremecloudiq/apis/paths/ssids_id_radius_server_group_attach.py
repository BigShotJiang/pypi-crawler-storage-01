from extremecloudiq.paths.ssids_id_radius_server_group_attach.post import ApiForpost


class SsidsIdRadiusServerGroupAttach(
    ApiForpost,
):
    pass
