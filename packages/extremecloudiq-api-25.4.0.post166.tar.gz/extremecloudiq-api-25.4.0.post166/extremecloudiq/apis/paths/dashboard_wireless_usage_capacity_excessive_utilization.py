from extremecloudiq.paths.dashboard_wireless_usage_capacity_excessive_utilization.post import ApiForpost


class DashboardWirelessUsageCapacityExcessiveUtilization(
    ApiForpost,
):
    pass
