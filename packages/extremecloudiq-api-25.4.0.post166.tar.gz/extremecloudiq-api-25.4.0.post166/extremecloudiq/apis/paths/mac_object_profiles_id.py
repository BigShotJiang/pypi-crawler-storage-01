from extremecloudiq.paths.mac_object_profiles_id.get import ApiForget
from extremecloudiq.paths.mac_object_profiles_id.put import ApiForput
from extremecloudiq.paths.mac_object_profiles_id.delete import ApiFordelete


class MacObjectProfilesId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
