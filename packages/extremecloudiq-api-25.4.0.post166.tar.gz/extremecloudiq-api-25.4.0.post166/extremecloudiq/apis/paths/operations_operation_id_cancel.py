from extremecloudiq.paths.operations_operation_id_cancel.post import ApiForpost


class OperationsOperationIdCancel(
    ApiForpost,
):
    pass
