from extremecloudiq.paths.copilot_anomalies_wifi_capacity_stats.get import ApiForget


class CopilotAnomaliesWifiCapacityStats(
    ApiForget,
):
    pass
