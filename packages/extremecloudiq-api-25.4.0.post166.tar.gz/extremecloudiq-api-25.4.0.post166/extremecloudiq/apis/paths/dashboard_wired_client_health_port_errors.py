from extremecloudiq.paths.dashboard_wired_client_health_port_errors.post import ApiForpost


class DashboardWiredClientHealthPortErrors(
    ApiForpost,
):
    pass
