from extremecloudiq.paths.ccgs.get import ApiForget
from extremecloudiq.paths.ccgs.post import ApiForpost


class Ccgs(
    ApiForget,
    ApiForpost,
):
    pass
