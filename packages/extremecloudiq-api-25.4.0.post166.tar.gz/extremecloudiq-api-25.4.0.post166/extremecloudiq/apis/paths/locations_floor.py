from extremecloudiq.paths.locations_floor.get import ApiForget
from extremecloudiq.paths.locations_floor.post import ApiForpost


class LocationsFloor(
    ApiForget,
    ApiForpost,
):
    pass
