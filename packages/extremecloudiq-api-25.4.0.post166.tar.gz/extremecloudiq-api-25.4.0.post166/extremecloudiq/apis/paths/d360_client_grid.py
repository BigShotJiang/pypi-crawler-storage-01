from extremecloudiq.paths.d360_client_grid.post import ApiForpost


class D360ClientGrid(
    ApiForpost,
):
    pass
