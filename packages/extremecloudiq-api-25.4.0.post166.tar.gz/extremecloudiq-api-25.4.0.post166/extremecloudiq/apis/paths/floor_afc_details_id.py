from extremecloudiq.paths.floor_afc_details_id.delete import ApiFordelete


class FloorAfcDetailsId(
    ApiFordelete,
):
    pass
