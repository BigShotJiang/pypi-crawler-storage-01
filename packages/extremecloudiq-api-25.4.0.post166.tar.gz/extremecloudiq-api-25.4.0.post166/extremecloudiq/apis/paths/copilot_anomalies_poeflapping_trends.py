from extremecloudiq.paths.copilot_anomalies_poeflapping_trends.get import ApiForget


class CopilotAnomaliesPoeflappingTrends(
    ApiForget,
):
    pass
