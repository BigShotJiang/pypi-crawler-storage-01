from extremecloudiq.paths.dashboard_wired_device_health_summary.post import ApiForpost


class DashboardWiredDeviceHealthSummary(
    ApiForpost,
):
    pass
