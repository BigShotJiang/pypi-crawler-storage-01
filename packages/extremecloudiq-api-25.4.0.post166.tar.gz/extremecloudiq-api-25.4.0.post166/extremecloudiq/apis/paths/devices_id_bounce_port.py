from extremecloudiq.paths.devices_id_bounce_port.post import ApiForpost


class DevicesIdBouncePort(
    ApiForpost,
):
    pass
