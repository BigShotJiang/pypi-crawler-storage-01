from extremecloudiq.paths.locations_tree.get import ApiForget


class LocationsTree(
    ApiForget,
):
    pass
