from extremecloudiq.paths.locations_building.get import ApiForget
from extremecloudiq.paths.locations_building.post import ApiForpost


class LocationsBuilding(
    ApiForget,
    ApiForpost,
):
    pass
