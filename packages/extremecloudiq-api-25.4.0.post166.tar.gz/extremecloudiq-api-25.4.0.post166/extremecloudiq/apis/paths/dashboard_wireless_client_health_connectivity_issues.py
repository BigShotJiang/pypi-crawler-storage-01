from extremecloudiq.paths.dashboard_wireless_client_health_connectivity_issues.post import ApiForpost


class DashboardWirelessClientHealthConnectivityIssues(
    ApiForpost,
):
    pass
