from extremecloudiq.paths.copilot_anomalies_adverse_traffic_device_stats.get import ApiForget


class CopilotAnomaliesAdverseTrafficDeviceStats(
    ApiForget,
):
    pass
