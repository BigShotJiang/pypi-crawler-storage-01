from extremecloudiq.paths.copilot_anomalies_exclude_vlans.post import ApiForpost


class CopilotAnomaliesExcludeVlans(
    ApiForpost,
):
    pass
