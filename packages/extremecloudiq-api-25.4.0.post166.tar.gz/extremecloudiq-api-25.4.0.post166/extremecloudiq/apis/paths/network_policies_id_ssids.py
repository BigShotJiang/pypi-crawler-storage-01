from extremecloudiq.paths.network_policies_id_ssids.get import ApiForget


class NetworkPoliciesIdSsids(
    ApiForget,
):
    pass
