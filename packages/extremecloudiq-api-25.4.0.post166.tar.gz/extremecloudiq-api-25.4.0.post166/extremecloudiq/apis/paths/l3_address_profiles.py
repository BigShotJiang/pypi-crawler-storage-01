from extremecloudiq.paths.l3_address_profiles.get import ApiForget
from extremecloudiq.paths.l3_address_profiles.post import ApiForpost


class L3AddressProfiles(
    ApiForget,
    ApiForpost,
):
    pass
