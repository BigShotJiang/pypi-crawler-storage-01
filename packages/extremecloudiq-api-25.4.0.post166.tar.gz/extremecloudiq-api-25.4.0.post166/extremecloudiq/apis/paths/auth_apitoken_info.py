from extremecloudiq.paths.auth_apitoken_info.get import ApiForget


class AuthApitokenInfo(
    ApiForget,
):
    pass
