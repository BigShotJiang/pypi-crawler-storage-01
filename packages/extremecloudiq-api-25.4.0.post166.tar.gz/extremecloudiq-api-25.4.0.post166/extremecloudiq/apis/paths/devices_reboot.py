from extremecloudiq.paths.devices_reboot.post import ApiForpost


class DevicesReboot(
    ApiForpost,
):
    pass
