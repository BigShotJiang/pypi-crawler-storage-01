from extremecloudiq.paths.rtts.post import ApiForpost


class Rtts(
    ApiForpost,
):
    pass
