from extremecloudiq.paths.dashboard_wireless_client_health_issue_ipaddress.post import ApiForpost


class DashboardWirelessClientHealthIssueIpaddress(
    ApiForpost,
):
    pass
