from extremecloudiq.paths.hiq_context.get import ApiForget
from extremecloudiq.paths.hiq_context.put import ApiForput


class HiqContext(
    ApiForget,
    ApiForput,
):
    pass
