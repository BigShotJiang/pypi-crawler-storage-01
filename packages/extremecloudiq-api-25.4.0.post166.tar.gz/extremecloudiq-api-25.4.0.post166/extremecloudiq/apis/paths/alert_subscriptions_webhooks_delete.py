from extremecloudiq.paths.alert_subscriptions_webhooks_delete.post import ApiForpost


class AlertSubscriptionsWebhooksDelete(
    ApiForpost,
):
    pass
