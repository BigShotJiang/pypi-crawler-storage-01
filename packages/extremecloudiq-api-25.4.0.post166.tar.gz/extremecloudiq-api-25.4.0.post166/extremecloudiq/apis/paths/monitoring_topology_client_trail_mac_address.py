from extremecloudiq.paths.monitoring_topology_client_trail_mac_address.get import ApiForget


class MonitoringTopologyClientTrailMacAddress(
    ApiForget,
):
    pass
