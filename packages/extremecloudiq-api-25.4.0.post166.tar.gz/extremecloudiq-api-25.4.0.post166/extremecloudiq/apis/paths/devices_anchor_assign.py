from extremecloudiq.paths.devices_anchor_assign.post import ApiForpost


class DevicesAnchorAssign(
    ApiForpost,
):
    pass
