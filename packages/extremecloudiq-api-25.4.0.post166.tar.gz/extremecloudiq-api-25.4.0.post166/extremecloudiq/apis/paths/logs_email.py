from extremecloudiq.paths.logs_email.get import ApiForget


class LogsEmail(
    ApiForget,
):
    pass
