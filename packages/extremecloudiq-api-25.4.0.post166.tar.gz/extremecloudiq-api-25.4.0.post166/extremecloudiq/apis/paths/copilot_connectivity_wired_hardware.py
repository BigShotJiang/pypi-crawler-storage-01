from extremecloudiq.paths.copilot_connectivity_wired_hardware.get import ApiForget


class CopilotConnectivityWiredHardware(
    ApiForget,
):
    pass
