from extremecloudiq.paths.devices_anchor_revoke.post import ApiForpost


class DevicesAnchorRevoke(
    ApiForpost,
):
    pass
