from extremecloudiq.paths.aps_afc_query_.get import ApiForget


class ApsAfcQuery(
    ApiForget,
):
    pass
