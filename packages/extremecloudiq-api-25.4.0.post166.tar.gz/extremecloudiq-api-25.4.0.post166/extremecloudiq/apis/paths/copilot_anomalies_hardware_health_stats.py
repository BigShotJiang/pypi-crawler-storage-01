from extremecloudiq.paths.copilot_anomalies_hardware_health_stats.get import ApiForget


class CopilotAnomaliesHardwareHealthStats(
    ApiForget,
):
    pass
