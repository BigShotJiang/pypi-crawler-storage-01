from extremecloudiq.paths.locations.post import ApiForpost


class Locations(
    ApiForpost,
):
    pass
