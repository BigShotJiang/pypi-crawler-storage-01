from extremecloudiq.paths.mac_firewall_policies_id_mac_firewall_rule_attach.post import ApiForpost


class MacFirewallPoliciesIdMacFirewallRuleAttach(
    ApiForpost,
):
    pass
