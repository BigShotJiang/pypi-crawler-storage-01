from extremecloudiq.paths.devices_manage.post import ApiForpost


class DevicesManage(
    ApiForpost,
):
    pass
