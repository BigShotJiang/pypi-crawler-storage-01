from extremecloudiq.paths.copilot_anomalies_poeflapping_stats.get import ApiForget


class CopilotAnomaliesPoeflappingStats(
    ApiForget,
):
    pass
