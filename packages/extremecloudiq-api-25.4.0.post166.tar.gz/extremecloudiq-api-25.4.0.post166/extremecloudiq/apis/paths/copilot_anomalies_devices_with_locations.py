from extremecloudiq.paths.copilot_anomalies_devices_with_locations.get import ApiForget


class CopilotAnomaliesDevicesWithLocations(
    ApiForget,
):
    pass
