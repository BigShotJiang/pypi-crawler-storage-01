from extremecloudiq.paths.locations_import_ekahau.post import ApiForpost


class LocationsImportEkahau(
    ApiForpost,
):
    pass
