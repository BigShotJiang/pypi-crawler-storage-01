from extremecloudiq.paths.radsec_proxies_id.get import ApiForget
from extremecloudiq.paths.radsec_proxies_id.put import ApiForput
from extremecloudiq.paths.radsec_proxies_id.delete import ApiFordelete


class RadsecProxiesId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
