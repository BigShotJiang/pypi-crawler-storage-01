from extremecloudiq.paths.dashboard_wired_device_health_cpu_usage_issues.post import ApiForpost


class DashboardWiredDeviceHealthCpuUsageIssues(
    ApiForpost,
):
    pass
