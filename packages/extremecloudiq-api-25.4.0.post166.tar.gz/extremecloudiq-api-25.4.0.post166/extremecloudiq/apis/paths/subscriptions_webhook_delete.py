from extremecloudiq.paths.subscriptions_webhook_delete.delete import ApiFordelete


class SubscriptionsWebhookDelete(
    ApiFordelete,
):
    pass
