from extremecloudiq.paths.d360_client_grid_metadata.get import ApiForget


class D360ClientGridMetadata(
    ApiForget,
):
    pass
