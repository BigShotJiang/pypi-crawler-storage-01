from extremecloudiq.paths.copilot_connectivity_wireless_locations_performance.get import ApiForget


class CopilotConnectivityWirelessLocationsPerformance(
    ApiForget,
):
    pass
