from extremecloudiq.paths.copilot_connectivity_wireless_quality_index.get import ApiForget


class CopilotConnectivityWirelessQualityIndex(
    ApiForget,
):
    pass
