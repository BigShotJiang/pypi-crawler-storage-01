from extremecloudiq.paths.dashboard_wired_usage_capacity_usage_utilization.post import ApiForpost


class DashboardWiredUsageCapacityUsageUtilization(
    ApiForpost,
):
    pass
