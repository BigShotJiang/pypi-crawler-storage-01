from extremecloudiq.paths.devices_rm_devices_metadata.post import ApiForpost


class DevicesRmDevicesMetadata(
    ApiForpost,
):
    pass
