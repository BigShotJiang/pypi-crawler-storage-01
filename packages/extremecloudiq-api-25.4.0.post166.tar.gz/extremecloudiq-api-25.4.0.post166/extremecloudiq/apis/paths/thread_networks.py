from extremecloudiq.paths.thread_networks.get import ApiForget


class ThreadNetworks(
    ApiForget,
):
    pass
