from extremecloudiq.paths.backup_history_restore.post import ApiForpost


class BackupHistoryRestore(
    ApiForpost,
):
    pass
