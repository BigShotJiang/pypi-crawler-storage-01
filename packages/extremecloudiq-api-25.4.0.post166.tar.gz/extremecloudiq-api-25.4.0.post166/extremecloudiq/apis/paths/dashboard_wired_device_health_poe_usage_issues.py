from extremecloudiq.paths.dashboard_wired_device_health_poe_usage_issues.post import ApiForpost


class DashboardWiredDeviceHealthPoeUsageIssues(
    ApiForpost,
):
    pass
