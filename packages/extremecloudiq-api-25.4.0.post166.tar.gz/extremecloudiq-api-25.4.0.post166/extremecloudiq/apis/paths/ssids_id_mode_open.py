from extremecloudiq.paths.ssids_id_mode_open.put import ApiForput


class SsidsIdModeOpen(
    ApiForput,
):
    pass
