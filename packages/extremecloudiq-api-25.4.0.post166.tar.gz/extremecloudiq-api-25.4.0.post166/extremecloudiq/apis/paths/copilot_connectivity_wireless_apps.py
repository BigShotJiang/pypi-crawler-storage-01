from extremecloudiq.paths.copilot_connectivity_wireless_apps.get import ApiForget


class CopilotConnectivityWirelessApps(
    ApiForget,
):
    pass
