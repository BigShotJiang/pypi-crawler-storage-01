from extremecloudiq.paths.ssids_id_user_profile_assignment_attach.post import ApiForpost


class SsidsIdUserProfileAssignmentAttach(
    ApiForpost,
):
    pass
