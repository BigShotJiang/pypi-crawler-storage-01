from extremecloudiq.paths.deployments_deployment_id_status.get import ApiForget


class DeploymentsDeploymentIdStatus(
    ApiForget,
):
    pass
