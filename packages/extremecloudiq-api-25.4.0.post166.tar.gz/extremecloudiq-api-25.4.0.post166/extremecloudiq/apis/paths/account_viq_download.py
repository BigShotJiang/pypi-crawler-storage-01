from extremecloudiq.paths.account_viq_download.get import ApiForget


class AccountViqDownload(
    ApiForget,
):
    pass
