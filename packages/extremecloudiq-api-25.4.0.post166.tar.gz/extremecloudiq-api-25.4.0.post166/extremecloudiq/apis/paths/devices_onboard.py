from extremecloudiq.paths.devices_onboard.post import ApiForpost


class DevicesOnboard(
    ApiForpost,
):
    pass
