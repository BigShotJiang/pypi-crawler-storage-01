from extremecloudiq.paths.dashboard_wireless_client_health_grid.post import ApiForpost


class DashboardWirelessClientHealthGrid(
    ApiForpost,
):
    pass
