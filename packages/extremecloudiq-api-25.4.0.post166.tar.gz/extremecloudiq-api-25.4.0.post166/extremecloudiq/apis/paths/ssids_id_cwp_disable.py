from extremecloudiq.paths.ssids_id_cwp_disable.post import ApiForpost


class SsidsIdCwpDisable(
    ApiForpost,
):
    pass
