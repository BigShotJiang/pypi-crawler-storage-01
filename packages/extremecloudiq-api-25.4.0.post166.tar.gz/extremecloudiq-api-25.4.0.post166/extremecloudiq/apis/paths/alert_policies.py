from extremecloudiq.paths.alert_policies.get import ApiForget
from extremecloudiq.paths.alert_policies.post import ApiForpost


class AlertPolicies(
    ApiForget,
    ApiForpost,
):
    pass
