from extremecloudiq.paths.ssids_id_psk_password.put import ApiForput


class SsidsIdPskPassword(
    ApiForput,
):
    pass
