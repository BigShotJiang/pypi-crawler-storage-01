from extremecloudiq.paths.ssids_id_user_profile_attach.post import ApiForpost


class SsidsIdUserProfileAttach(
    ApiForpost,
):
    pass
