from extremecloudiq.paths.email_templates.get import ApiForget


class EmailTemplates(
    ApiForget,
):
    pass
