from extremecloudiq.paths.devices_rm_devices_connection_status.post import ApiForpost


class DevicesRmDevicesConnectionStatus(
    ApiForpost,
):
    pass
