from extremecloudiq.paths.devices_id_ssid_status_change.post import ApiForpost


class DevicesIdSsidStatusChange(
    ApiForpost,
):
    pass
