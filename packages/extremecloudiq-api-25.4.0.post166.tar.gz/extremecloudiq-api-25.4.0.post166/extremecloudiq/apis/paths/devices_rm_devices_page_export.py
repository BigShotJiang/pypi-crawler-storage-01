from extremecloudiq.paths.devices_rm_devices_page_export.post import ApiForpost


class DevicesRmDevicesPageExport(
    ApiForpost,
):
    pass
