from extremecloudiq.paths.d360_wireless_surrounding_aps.post import ApiForpost


class D360WirelessSurroundingAps(
    ApiForpost,
):
    pass
