from extremecloudiq.paths.certificate_bundles.get import ApiForget
from extremecloudiq.paths.certificate_bundles.post import ApiForpost


class CertificateBundles(
    ApiForget,
    ApiForpost,
):
    pass
