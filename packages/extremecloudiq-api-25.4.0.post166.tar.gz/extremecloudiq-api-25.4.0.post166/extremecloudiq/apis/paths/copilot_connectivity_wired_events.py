from extremecloudiq.paths.copilot_connectivity_wired_events.get import ApiForget


class CopilotConnectivityWiredEvents(
    ApiForget,
):
    pass
