from extremecloudiq.paths.logs_audit_reports_id.get import ApiForget


class LogsAuditReportsId(
    ApiForget,
):
    pass
