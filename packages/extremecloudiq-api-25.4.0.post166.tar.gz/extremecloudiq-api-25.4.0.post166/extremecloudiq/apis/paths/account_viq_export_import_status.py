from extremecloudiq.paths.account_viq_export_import_status.get import ApiForget


class AccountViqExportImportStatus(
    ApiForget,
):
    pass
