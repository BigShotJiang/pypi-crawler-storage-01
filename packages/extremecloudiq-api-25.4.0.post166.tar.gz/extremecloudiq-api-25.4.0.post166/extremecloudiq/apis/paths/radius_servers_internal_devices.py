from extremecloudiq.paths.radius_servers_internal_devices.get import ApiForget


class RadiusServersInternalDevices(
    ApiForget,
):
    pass
