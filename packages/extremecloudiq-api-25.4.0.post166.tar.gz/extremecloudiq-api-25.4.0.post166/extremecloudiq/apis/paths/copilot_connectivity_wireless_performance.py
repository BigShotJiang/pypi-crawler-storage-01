from extremecloudiq.paths.copilot_connectivity_wireless_performance.get import ApiForget


class CopilotConnectivityWirelessPerformance(
    ApiForget,
):
    pass
