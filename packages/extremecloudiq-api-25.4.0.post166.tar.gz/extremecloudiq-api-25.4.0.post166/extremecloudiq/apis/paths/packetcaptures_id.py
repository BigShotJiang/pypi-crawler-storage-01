from extremecloudiq.paths.packetcaptures_id.get import ApiForget
from extremecloudiq.paths.packetcaptures_id.delete import ApiFordelete


class PacketcapturesId(
    ApiForget,
    ApiFordelete,
):
    pass
