from extremecloudiq.paths.devices_radio_information.get import ApiForget


class DevicesRadioInformation(
    ApiForget,
):
    pass
