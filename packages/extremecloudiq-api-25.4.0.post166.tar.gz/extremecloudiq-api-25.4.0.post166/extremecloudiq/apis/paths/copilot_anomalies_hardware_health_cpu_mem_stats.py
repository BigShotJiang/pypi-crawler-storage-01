from extremecloudiq.paths.copilot_anomalies_hardware_health_cpu_mem_stats.get import ApiForget


class CopilotAnomaliesHardwareHealthCpuMemStats(
    ApiForget,
):
    pass
