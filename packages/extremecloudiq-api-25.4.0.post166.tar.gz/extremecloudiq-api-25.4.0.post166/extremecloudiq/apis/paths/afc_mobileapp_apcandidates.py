from extremecloudiq.paths.afc_mobileapp_apcandidates.post import ApiForpost


class AfcMobileappApcandidates(
    ApiForpost,
):
    pass
