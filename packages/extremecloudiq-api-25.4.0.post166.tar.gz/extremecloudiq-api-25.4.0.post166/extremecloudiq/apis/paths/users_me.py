from extremecloudiq.paths.users_me.get import ApiForget


class UsersMe(
    ApiForget,
):
    pass
