from extremecloudiq.paths.subscriptions_webhook_export.get import ApiForget


class SubscriptionsWebhookExport(
    ApiForget,
):
    pass
