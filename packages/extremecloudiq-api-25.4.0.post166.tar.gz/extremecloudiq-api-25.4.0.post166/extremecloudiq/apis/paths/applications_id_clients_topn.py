from extremecloudiq.paths.applications_id_clients_topn.get import ApiForget


class ApplicationsIdClientsTopn(
    ApiForget,
):
    pass
