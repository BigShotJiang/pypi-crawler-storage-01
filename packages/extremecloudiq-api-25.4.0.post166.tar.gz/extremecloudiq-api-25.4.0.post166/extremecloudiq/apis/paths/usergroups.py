from extremecloudiq.paths.usergroups.get import ApiForget
from extremecloudiq.paths.usergroups.post import ApiForpost


class Usergroups(
    ApiForget,
    ApiForpost,
):
    pass
