from extremecloudiq.paths.vlan_profiles_delete.post import ApiForpost


class VlanProfilesDelete(
    ApiForpost,
):
    pass
