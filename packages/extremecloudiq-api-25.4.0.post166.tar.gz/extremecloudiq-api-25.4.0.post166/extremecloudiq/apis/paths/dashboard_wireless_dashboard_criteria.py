from extremecloudiq.paths.dashboard_wireless_dashboard_criteria.get import ApiForget
from extremecloudiq.paths.dashboard_wireless_dashboard_criteria.post import ApiForpost


class DashboardWirelessDashboardCriteria(
    ApiForget,
    ApiForpost,
):
    pass
