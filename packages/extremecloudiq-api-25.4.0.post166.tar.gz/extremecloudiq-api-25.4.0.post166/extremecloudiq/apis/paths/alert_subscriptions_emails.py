from extremecloudiq.paths.alert_subscriptions_emails.get import ApiForget
from extremecloudiq.paths.alert_subscriptions_emails.post import ApiForpost


class AlertSubscriptionsEmails(
    ApiForget,
    ApiForpost,
):
    pass
