from extremecloudiq.paths.devices_reset.post import ApiForpost


class DevicesReset(
    ApiForpost,
):
    pass
