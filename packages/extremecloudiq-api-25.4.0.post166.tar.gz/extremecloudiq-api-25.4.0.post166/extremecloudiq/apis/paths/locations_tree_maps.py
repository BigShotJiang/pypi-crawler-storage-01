from extremecloudiq.paths.locations_tree_maps.get import ApiForget


class LocationsTreeMaps(
    ApiForget,
):
    pass
