from extremecloudiq.paths.operations_operation_id.get import ApiForget
from extremecloudiq.paths.operations_operation_id.delete import ApiFordelete


class OperationsOperationId(
    ApiForget,
    ApiFordelete,
):
    pass
