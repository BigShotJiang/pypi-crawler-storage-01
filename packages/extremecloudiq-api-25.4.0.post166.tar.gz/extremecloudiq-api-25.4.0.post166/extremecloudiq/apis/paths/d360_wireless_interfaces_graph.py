from extremecloudiq.paths.d360_wireless_interfaces_graph.get import ApiForget


class D360WirelessInterfacesGraph(
    ApiForget,
):
    pass
