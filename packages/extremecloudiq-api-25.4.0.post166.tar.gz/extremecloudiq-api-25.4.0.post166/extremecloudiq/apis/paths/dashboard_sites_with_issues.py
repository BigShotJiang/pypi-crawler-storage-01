from extremecloudiq.paths.dashboard_sites_with_issues.post import ApiForpost


class DashboardSitesWithIssues(
    ApiForpost,
):
    pass
