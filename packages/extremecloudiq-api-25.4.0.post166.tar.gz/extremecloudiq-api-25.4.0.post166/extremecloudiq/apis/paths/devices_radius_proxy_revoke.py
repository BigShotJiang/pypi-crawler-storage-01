from extremecloudiq.paths.devices_radius_proxy_revoke.delete import ApiFordelete


class DevicesRadiusProxyRevoke(
    ApiFordelete,
):
    pass
