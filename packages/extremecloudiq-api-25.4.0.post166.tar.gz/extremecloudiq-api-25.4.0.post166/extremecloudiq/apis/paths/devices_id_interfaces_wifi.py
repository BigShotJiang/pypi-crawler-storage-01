from extremecloudiq.paths.devices_id_interfaces_wifi.get import ApiForget


class DevicesIdInterfacesWifi(
    ApiForget,
):
    pass
