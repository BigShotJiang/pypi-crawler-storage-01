from extremecloudiq.paths.copilot_anomalies_dfs_recurrence_count_stats.get import ApiForget


class CopilotAnomaliesDfsRecurrenceCountStats(
    ApiForget,
):
    pass
