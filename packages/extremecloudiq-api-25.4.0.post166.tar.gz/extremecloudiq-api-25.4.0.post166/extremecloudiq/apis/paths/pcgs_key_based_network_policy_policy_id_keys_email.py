from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_keys_email.post import ApiForpost


class PcgsKeyBasedNetworkPolicyPolicyIdKeysEmail(
    ApiForpost,
):
    pass
