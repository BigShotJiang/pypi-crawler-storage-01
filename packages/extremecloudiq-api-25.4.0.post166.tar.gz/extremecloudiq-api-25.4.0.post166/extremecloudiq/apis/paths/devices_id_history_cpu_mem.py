from extremecloudiq.paths.devices_id_history_cpu_mem.get import ApiForget


class DevicesIdHistoryCpuMem(
    ApiForget,
):
    pass
