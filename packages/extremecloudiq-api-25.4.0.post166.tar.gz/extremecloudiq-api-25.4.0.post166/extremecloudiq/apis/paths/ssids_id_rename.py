from extremecloudiq.paths.ssids_id_rename.post import ApiForpost


class SsidsIdRename(
    ApiForpost,
):
    pass
