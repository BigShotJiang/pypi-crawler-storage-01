"""
    InterParticle.__init__.py
"""