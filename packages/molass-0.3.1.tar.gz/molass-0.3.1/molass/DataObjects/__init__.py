"""
    DataObjects.__init__.py

    Copyright (c) 2025, SAXS Team, KEK-PF
"""

from .SecSaxsData import SecSaxsData
from .Curve import Curve