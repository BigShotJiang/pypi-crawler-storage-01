"""
    CurveModels.Scattering.__init__.py
"""