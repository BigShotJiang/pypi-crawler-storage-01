"""
    Except.ExceptionTypes.py


"""

class NotSpecifedError(Exception) : pass
class InadequateUseError(Exception) : pass
class InconsistentUseError(Exception): pass