"""
    Progress.__init__.py
"""