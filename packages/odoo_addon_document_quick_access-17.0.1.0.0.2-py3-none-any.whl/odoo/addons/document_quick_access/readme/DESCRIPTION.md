This module allows to search any kind of records through a launcher.
With this, we can add a QR in our reports in order to search elements
faster. It could be used to add this QR (on a label) on external
documents.
