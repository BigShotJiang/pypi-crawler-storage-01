\# Access on developer mode \# Access Settings \> Technical \> Document
Quick Access \# Create a record selecting the model, format and priority
