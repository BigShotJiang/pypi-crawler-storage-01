- It would be interesting to be able to read the QR without clicking the
  button. Maybe using a shortcut or directly accessing it.
