class NotValidSp_Dc(Exception):
    pass

class CorruptedConfig(Exception):
    pass

class NoSongPlaying(Exception):
    pass

class TOTPGenerationException(Exception):
    pass