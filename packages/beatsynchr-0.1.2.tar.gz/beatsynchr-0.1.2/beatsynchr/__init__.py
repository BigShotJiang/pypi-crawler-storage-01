# slideshow_maker/__init__.py
from .core import generate_slideshow,generate_slideshow_video
