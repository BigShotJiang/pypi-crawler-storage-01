def test_import():
    import policyengine_us_data
