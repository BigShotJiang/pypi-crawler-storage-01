"""__init__ Module for note-python."""

from .notecard import *
