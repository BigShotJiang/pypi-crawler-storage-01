def hello():
    print("Hello, KapFinance!")