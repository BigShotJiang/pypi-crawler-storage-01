To run tests, run `cargo test` in the root directory of the project.
