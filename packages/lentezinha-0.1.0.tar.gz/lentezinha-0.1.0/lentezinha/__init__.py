__version__ = "0.1.0"

from .lens import (
    Lens as Lens,
    read as read,
    update as update,
)
