from cdisc_rules_engine.enums.base_enum import BaseEnum


class Sensitivity(BaseEnum):
    DATASET = "Dataset"
    RECORD = "Record"
