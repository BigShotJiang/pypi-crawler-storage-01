class UNIITerm:
    def __init__(self, unii: str, display_name: str, **term_params):
        self.unii = unii
        self.display_name = display_name
