from .config import ConfigService

config = ConfigService()
