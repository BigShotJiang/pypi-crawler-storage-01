# 天翼网盘（cloud.189.cn）签名算法

## 安装

你可以通过 [pypi](https://pypi.org/project/p189sign/) 安装

```console
pip install -U p189sign
```

## 用法

```python
from p189sign import signature
```
