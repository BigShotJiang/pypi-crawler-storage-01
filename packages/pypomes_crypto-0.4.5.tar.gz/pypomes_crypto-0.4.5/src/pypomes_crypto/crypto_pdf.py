
# from pathlib import Path
# from pyhanko.sign.validation.pdf_embedded import EmbeddedPdfSignature
# from pyhanko_certvalidator import ValidationContext
# from pyhanko.keys import load_certs_from_pemder_data
# from pyhanko.pdf_utils.reader import PdfFileReader
# from pyhanko.sign.validation import validate_pdf_signature
# from pyhanko.sign.validation.status import PdfSignatureStatus
# from pypomes_core import file_get_data, exc_format, env_get_str, APP_PREFIX

class CryptoPdf:
    """
    Python code to extract cryptographic data from a digitally signed PDF file.

    instance attributes:

    """
