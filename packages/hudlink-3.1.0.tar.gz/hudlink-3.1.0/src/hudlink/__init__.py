"""
hudlink: A Python package for linking customizable ACS data to HUD's Picture of Subsidized Households data.

This module initializes the package.
"""

__version__ = "3.1.0"
