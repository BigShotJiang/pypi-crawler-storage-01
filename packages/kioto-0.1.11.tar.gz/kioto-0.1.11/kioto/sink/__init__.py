from kioto.sink.api import drain, FileSink
from kioto.sink.impl import Sink
