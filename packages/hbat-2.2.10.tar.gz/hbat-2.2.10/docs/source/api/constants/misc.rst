Miscellaneous Constants
=======================

Contains GUI defaults, file formats, and other miscellaneous constants.

Module Overview
---------------

.. automodule:: hbat.constants.misc
   :members:
   :undoc-members:
   :show-inheritance: