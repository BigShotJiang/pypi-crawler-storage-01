from .detector import PromptInjectionDetector

__version__ = "0.2.0"