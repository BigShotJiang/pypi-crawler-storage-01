from __future__ import annotations


def do() -> None:
    print("greetings from demo_pkg_setuptools")  # noqa: T201
