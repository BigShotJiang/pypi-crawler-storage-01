def hello_world():
    """A simple example function."""
    return "Hello from autoclean-eeg2source!"
