..
    Copyright (C) 2024-2025 Graz University of Technology.

    invenio-catalogue-marc21 is free software; you can redistribute it
    and/or modify it under the terms of the MIT License; see LICENSE file for
    more details.

Changes
=======

Version v0.0.2 (release 2025-07-21)

- setup: change to reusable workflows


Version v0.0.1 (release 2025-07-21)

- base functionality, more a proof of concept than a working state
