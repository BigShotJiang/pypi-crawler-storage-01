..
    Copyright (C) 2024 Graz University of Technology.

    invenio-catalogue-marc21 is free software; you can redistribute it
    and/or modify it under the terms of the MIT License; see LICENSE file for
    more details.

==========================
 invenio-catalogue-marc21
==========================

.. image:: https://github.com/tu-graz-library/invenio-catalogue-marc21/workflows/CI/badge.svg
        :target: https://github.com/tu-graz-library/invenio-catalogue-marc21/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/tu-graz-library/invenio-catalogue-marc21.svg
        :target: https://github.com/tu-graz-library/invenio-catalogue-marc21/releases

.. image:: https://img.shields.io/pypi/dm/invenio-catalogue-marc21.svg
        :target: https://pypi.python.org/pypi/invenio-catalogue-marc21

.. image:: https://img.shields.io/github/license/tu-graz-library/invenio-catalogue-marc21.svg
        :target: https://github.com/tu-graz-library/invenio-catalogue-marc21/blob/master/LICENSE

Invenio module link multiple marc21 modules

TODO: Please provide feature overview of module

Further documentation is available on
https://invenio-catalogue-marc21.readthedocs.io/
