Installation
============

invenio-catalogue-marc21 is on PyPI so all you need is:

.. code-block:: console

   $ pip install invenio-catalogue-marc21
