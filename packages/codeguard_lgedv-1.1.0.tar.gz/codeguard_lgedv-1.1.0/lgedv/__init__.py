# This file marks mcp_server as a Python package.
