#!/usr/bin/env python

"""Tests for `geoml_kit` package."""


import unittest

from geoml_kit import geoml_kit


class TestGeoml_kit(unittest.TestCase):
    """Tests for `geoml_kit` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
