# Usage

To use GeoML Kit in a project:

```
import geoml_kit
```
