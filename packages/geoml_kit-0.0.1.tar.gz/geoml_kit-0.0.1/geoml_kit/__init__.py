"""Top-level package for GeoML Kit."""

__author__ = """Fariborz Nasr"""
__email__ = "fariborznasr@gmail.com"
__version__ = "0.0.1"
