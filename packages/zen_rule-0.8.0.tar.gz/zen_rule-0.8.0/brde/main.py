def main():
    print("Hello from brde!")


if __name__ == "__main__":
    main()
