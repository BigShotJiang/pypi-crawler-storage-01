def main() -> None:
    print("Hello from brde2!")
