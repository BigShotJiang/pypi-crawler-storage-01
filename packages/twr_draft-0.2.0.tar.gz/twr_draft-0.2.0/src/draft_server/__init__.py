from .draft import mcp

def mcp():
    """返回MCP服务器实例"""
    return mcp