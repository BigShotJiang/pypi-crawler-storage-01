from ..identifier import Identifier


class SwiftIdentifier(Identifier): ...