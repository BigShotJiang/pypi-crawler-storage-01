from ..identifier import Identifier


class CSharpIdentifier(Identifier): ...
