from ..identifier import Identifier


class PythonIdentifier(Identifier): ...
