from __future__ import annotations

from ..statement import BlockStatement, SimpleStatement


class CSimpleStatement(SimpleStatement): ...


class CBlockStatement(BlockStatement): ...
