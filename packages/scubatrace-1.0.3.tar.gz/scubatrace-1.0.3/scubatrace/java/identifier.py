from ..identifier import Identifier


class JavaIdentifier(Identifier): ...
