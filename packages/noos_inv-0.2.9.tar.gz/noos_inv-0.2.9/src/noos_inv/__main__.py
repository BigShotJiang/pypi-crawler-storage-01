from noos_inv import collections


main = collections.program.run


if __name__ == "__main__":
    main()
