"""Main relecov package file."""

from importlib.metadata import version

__version__ = version("relecov_tools")
