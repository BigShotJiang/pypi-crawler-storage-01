

TELEPHONE_PATTERN =r"^\+\d{1,3}\d{9,15}$"

URL_PATTERN =r"^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$"

