from excelipy import Style

DEFAULT_TEXT_STYLE = Style(
    text_wrap=False,
)
