Enjoy the accounting dashboard with the banner at the top:

![Accounting dashboard with banner](../static/description/account_dashboard_banner.png)
