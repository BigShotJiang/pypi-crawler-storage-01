API Reference
===============

.. automodule:: surfactant.fileinfo
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: surfactant.configmanager
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: surfactant
   :members:
   :undoc-members:
   :show-inheritance:
