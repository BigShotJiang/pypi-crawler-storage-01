from llama_index.embeddings.fireworks.base import FireworksEmbedding

__all__ = ["FireworksEmbedding"]
