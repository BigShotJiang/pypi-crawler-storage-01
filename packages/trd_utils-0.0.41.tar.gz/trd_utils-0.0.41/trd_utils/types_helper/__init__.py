from .base_model import BaseModel


__all__ = [
    "BaseModel",
]
