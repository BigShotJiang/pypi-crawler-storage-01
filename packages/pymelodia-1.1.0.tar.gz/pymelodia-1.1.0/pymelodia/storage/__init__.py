# -*- coding: utf-8 -*-
"""数据存储模块"""

from .database import MusicDatabase

__all__ = ['MusicDatabase']
