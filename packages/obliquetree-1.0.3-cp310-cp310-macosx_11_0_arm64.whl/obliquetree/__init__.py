from ._pywrap import Classifier, Regressor

__all__ = ["Classifier", "Regressor"]
__version__ = "1.0.3"