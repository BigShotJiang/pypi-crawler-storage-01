class ItemDoesntExist(Exception):
    """Raised when item doesn't exist on the remote"""
    pass
