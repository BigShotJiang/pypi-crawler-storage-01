def main() -> None:
    print("Hello from global-agent-toolkit!")
