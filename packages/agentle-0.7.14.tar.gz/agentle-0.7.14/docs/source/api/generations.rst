Generations API
===============

.. autosummary::
   :toctree: generated
   
   agentle.generations
   agentle.generations.providers
   agentle.generations.providers.google
   agentle.generations.providers.openai