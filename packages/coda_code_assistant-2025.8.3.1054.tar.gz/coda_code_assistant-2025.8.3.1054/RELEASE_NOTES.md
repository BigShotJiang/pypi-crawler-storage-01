## What's Changed

- refactor(cli): extract banner functionality to eliminate code duplication (dce2e30)
- docs: update ROADMAP.md to reflect Phase 4.6 completion and current Phase 6 progress (e49a397)
- feat(cli): enhance welcome banner with ASCII art and improved messaging (2d0877b)

**Full Changelog**: https://github.com/djvolz/coda-code-assistant/compare/v2025.8.3.1017...v2025.8.3.1054
