API Reference
=============

models.py
---------

.. automodule:: computedfields.models
   :members:
   :show-inheritance:

resolver.py
-----------

.. automodule:: computedfields.resolver
   :members:
   :show-inheritance:


graph.py
--------

.. automodule:: computedfields.graph
   :members:
   :show-inheritance:


handlers.py
-----------

.. automodule:: computedfields.handlers
   :members:
   :show-inheritance:


admin.py
--------

.. automodule:: computedfields.admin
   :members:
   :show-inheritance:


signals.py
----------

.. automodule:: computedfields.signals
   :members:
   :show-inheritance:
