from enum import Enum


class NeptuneServiceKind(Enum):
    DB = "db"
    GRAPH = "graph"
