"""Init tests namespace"""
