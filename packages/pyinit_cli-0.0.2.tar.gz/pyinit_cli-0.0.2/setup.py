from setuptools import setup

# This file is kept for compatibility with older pip versions
setup()
