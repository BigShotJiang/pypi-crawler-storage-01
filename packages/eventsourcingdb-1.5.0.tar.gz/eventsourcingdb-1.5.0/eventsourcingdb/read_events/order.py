from enum import Enum


class Order(Enum):
    ANTICHRONOLOGICAL = "antichronological"
    CHRONOLOGICAL = "chronological"
