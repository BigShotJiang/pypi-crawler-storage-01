from rich.console import Console as RichConsole

console = RichConsole(force_terminal=True, legacy_windows=False)
