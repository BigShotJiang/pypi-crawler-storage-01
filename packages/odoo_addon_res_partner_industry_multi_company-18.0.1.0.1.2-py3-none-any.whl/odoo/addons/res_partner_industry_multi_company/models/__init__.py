from . import res_partner_industry
