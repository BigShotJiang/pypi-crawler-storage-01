"""
Geradores de pipeline do DaedalusPy
"""


__all__ = [
    'generate_simple_project'
]
