"""QT Disocvery mechanisms

This module contains the different helpers to
integrate with Discovery mechanisms with Qt
applications.

"""
