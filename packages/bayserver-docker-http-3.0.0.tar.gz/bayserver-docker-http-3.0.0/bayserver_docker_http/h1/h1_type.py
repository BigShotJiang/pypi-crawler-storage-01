class H1Type:
    HEADER = 1
    CONTENT = 2
    END_CONTENT = 3