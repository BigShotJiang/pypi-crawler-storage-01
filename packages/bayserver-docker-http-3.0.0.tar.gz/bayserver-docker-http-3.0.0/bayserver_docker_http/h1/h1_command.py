from bayserver_core.protocol.command import Command

class H1Command(Command):
    pass
