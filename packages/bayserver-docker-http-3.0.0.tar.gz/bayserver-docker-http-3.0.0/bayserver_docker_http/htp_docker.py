class HtpDocker:
    #
    # interface
    #

    H1_PROTO_NAME = "h1"
    H2_PROTO_NAME = "h2"