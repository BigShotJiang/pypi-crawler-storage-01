from .ui.main import main

# leveraged when calling as module ie "python -m lanscape"

if __name__ == "__main__":
    main()