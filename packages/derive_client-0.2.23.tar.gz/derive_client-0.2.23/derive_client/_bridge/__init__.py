"""Module for bridging assets to and from Derive."""

from .client import BridgeClient

__all__ = [
    "BridgeClient",
]
