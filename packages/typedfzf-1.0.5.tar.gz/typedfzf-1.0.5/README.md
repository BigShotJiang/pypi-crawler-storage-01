# typedfzf

[![PyPI - Version](https://img.shields.io/pypi/v/typedfzf.svg)](https://pypi.org/project/typedfzf)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/typedfzf.svg)](https://pypi.org/project/typedfzf)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/FlavioAmurrioCS/typedfzf/main.svg)](https://results.pre-commit.ci/latest/github/FlavioAmurrioCS/typedfzf/main)

-----

**Table of Contents**

- [typedfzf](#typedfzf)
  - [Installation](#installation)
  - [License](#license)

## Installation

```console
pip install typedfzf
```

## License

`typedfzf` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
