from __future__ import annotations


def test_placeholder() -> None:
    assert True
