2025-07-08 Version: 1.1.0
- Support API ListEvalResults.
- Update API ListTracesDatas: add request parameters MaxDuration.
- Update API ListTracesDatas: add request parameters MinDuration.
- Update API ListTracesDatas: add request parameters SpanName.


2025-04-23 Version: 1.0.0
- Generated python 2024-03-11 for PaiLLMTrace.

