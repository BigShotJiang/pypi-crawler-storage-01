=========================
HelloWorld-Quart-Morepath
=========================

This application adapts the hello_world endpoint provided in
finitelycomputable.helloworld_morepath to be provided in
finitelycomputable.helloworld_quart using the Quart framework.
