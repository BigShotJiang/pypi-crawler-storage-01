# autohack-next

> English | [简体中文](./docs/README_zh.md)

A highly customizable competitive programming Hack tool written in Python.

A completely refactored version of [autohack](https://github.com/gi-b716/autohack) with clearer configuration, a redesigned interface, and more powerful performance.
