#!/usr/bin/env python 


from quick_actions.CLI import CLI

def main():
    CLI()


if __name__=="__main__":
    main()