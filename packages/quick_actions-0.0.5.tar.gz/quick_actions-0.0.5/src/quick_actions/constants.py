INLINE_SCRIPT_PREFIX = "exec"
SCRIPT_PREFIX = "script"
APP_NAME = "quick_actions"