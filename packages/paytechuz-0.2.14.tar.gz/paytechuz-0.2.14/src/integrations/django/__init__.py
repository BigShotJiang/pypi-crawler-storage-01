"""
Django integration for PayTechUZ.
"""
default_app_config = 'paytechuz.integrations.django.apps.PaytechuzConfig'
