"""Payme payment gateway implementation."""
from .client import PaymeGateway  # noqa: F401