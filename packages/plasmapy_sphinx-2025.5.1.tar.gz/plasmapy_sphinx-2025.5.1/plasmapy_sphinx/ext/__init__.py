"""
The `plasmapy_sphinx.ext` module contains all the `sphinx` ``setup()``
functions for all available extensions.
"""
