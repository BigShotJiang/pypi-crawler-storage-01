:orphan:

{{ objname | escape | underline}}

.. automodapi:: {{ fullname }}
   :noindex:
   :no-groups:

API
---

.. automodapi:: {{ fullname }}
   :noindex:
   :no-main-docstring:
