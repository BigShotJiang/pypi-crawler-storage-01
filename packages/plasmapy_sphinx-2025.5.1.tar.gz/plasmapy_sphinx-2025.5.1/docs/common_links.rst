.. These are ReST substitutions and links that can be used throughout the docs
   (and docstrings) because they are added to ``docs/conf.py::rst_epilog``.
