:orphan:

`plasmapy_sphinx.directives.confval`
====================================

.. currentmodule:: plasmapy_sphinx.directives.confval

.. automodapi:: plasmapy_sphinx.directives.confval
   :no-groups:

API
---

.. automodapi:: plasmapy_sphinx.directives.confval
   :noindex:
   :no-main-docstring:
