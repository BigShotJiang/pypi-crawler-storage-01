:orphan:

`plasmapy_sphinx.automodsumm.core`
==================================

.. currentmodule:: plasmapy_sphinx.automodsumm.core

.. automodapi:: plasmapy_sphinx.automodsumm.core
   :no-groups:

.. _automodsumm-api:

API
---

.. automodapi:: plasmapy_sphinx.automodsumm.core
   :noindex:
   :no-main-docstring:
