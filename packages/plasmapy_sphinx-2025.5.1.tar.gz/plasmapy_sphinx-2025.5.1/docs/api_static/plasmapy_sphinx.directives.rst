:orphan:

`plasmapy_sphinx.directives`
============================

.. currentmodule:: plasmapy_sphinx.directives

.. automodapi:: plasmapy_sphinx.directives
   :no-groups:

API
---

.. automodapi:: plasmapy_sphinx.directives
   :noindex:
   :no-main-docstring:
