:orphan:

`plasmapy_sphinx.automodsumm.generate`
======================================

.. currentmodule:: plasmapy_sphinx.automodsumm.generate

.. automodapi:: plasmapy_sphinx.automodsumm.generate
