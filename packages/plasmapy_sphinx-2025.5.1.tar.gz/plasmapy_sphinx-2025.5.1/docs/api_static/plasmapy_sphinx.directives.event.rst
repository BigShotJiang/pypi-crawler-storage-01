:orphan:

`plasmapy_sphinx.directives.event`
==================================

.. currentmodule:: plasmapy_sphinx.directives.event

.. automodapi:: plasmapy_sphinx.directives.event
   :no-groups:

API
---

.. automodapi:: plasmapy_sphinx.directives.event
   :noindex:
   :no-main-docstring:
