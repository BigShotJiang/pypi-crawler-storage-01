:orphan:

`plasmapy_sphinx`: The Sphinx extension package for PlasmaPy
============================================================

.. currentmodule:: plasmapy_sphinx

.. automodapi:: plasmapy_sphinx
   :no-groups:

API
---

.. automodapi:: plasmapy_sphinx
   :noindex:
   :no-main-docstring:
   :heading-chars: ^~
