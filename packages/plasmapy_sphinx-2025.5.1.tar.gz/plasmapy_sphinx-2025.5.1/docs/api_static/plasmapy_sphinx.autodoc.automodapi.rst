:orphan:

`plasmapy_sphinx.autodoc.automodapi`
====================================

.. currentmodule:: plasmapy_sphinx.autodoc.automodapi

.. automodapi:: plasmapy_sphinx.autodoc.automodapi
   :no-groups:

.. _automodapi-api:

API
---

.. automodapi:: plasmapy_sphinx.autodoc.automodapi
   :noindex:
   :no-main-docstring:
