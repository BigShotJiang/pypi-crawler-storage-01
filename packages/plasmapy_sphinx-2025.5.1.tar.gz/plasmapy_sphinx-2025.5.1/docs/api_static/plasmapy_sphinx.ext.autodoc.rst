:orphan:

`plasmapy_sphinx.ext.autodoc`
=============================

.. currentmodule:: plasmapy_sphinx.ext.autodoc

.. automodapi:: plasmapy_sphinx.ext.autodoc
