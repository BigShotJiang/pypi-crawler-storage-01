:orphan:

`plasmapy_sphinx.autodoc`
=========================

.. currentmodule:: plasmapy_sphinx.autodoc

.. automodapi:: plasmapy_sphinx.autodoc
   :no-groups:

API
---

.. automodapi:: plasmapy_sphinx.autodoc
   :noindex:
   :no-main-docstring:
