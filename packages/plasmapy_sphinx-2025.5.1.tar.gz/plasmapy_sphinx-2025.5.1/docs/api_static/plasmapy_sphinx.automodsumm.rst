:orphan:

`plasmapy_sphinx.automodsumm`
=============================

.. currentmodule:: plasmapy_sphinx.automodsumm

.. automodapi:: plasmapy_sphinx.automodsumm
   :no-groups:

API
---

.. automodapi:: plasmapy_sphinx.automodsumm
   :noindex:
   :no-main-docstring:
