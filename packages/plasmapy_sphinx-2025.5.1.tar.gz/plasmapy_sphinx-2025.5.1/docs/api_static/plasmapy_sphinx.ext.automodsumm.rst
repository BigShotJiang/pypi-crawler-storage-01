:orphan:

`plasmapy_sphinx.ext.automodsumm`
=================================

.. currentmodule:: plasmapy_sphinx.ext.automodsumm

.. automodapi:: plasmapy_sphinx.ext.automodsumm
