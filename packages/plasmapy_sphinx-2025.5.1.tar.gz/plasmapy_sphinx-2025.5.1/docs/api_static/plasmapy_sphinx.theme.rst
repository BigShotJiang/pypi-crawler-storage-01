:orphan:

`plasmapy_sphinx.theme`
=======================

.. currentmodule:: plasmapy_sphinx.theme

.. automodapi:: plasmapy_sphinx.theme
   :no-groups:

API
---

.. automodapi:: plasmapy_sphinx.theme
   :noindex:
   :no-main-docstring:
