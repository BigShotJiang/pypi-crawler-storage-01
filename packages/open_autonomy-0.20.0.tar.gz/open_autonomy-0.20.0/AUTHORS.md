# Authors

This is the official list of authors for copyright purposes.

* 8baller <8ball030@gmail.com> [8ball030](https://github.com/8ball030)
* Adamantios Zaras <adamantios.zaras@valory.xyz> [Adamantios](https://github.com/Adamantios)
* David Minarsch <david.minarsch@googlemail.com> [DavidMinarsch](https://github.com/DavidMinarsch)
* David Vilela <dvilelaf@gmail.com> [dvilelaf](https://github.com/dvilelaf)
* Marco Favorito <marco.favorito@gmail.com> [marcofavorito](https://github.com/marcofavorito)
* Jose Moreira Sanchez <jose.moreira.sanchez@valory.xyz> [jmoreira-valory](https://github.com/jmoreira-valory)
* M.A.P. Karrenbelt <m.a.p.karrenbelt@gmail.com> [Karrenbelt](https://github.com/Karrenbelt)
* Viraj Patel <vptl185@gmail.com> [angrybayblade](https://github.com/angrybayblade)
* Ardian Abazi <ardian.abazi@valory.xyz> [0xArdi](https://github.com/0xArdi)
