# Gnosis Safe Proxy Factory contract

## Description

## Functions

