# ABCI connection

This package implements an AEA connection that wraps
the HTTP requests that can be done to an ABCI server.

## Usage

Configure the fields `host` and `port` to the ABCI server you want to interact with.
