<a id="packages.valory.skills.abstract_round_abci.tests.data.dummy_abci.dialogues"></a>

# packages.valory.skills.abstract`_`round`_`abci.tests.data.dummy`_`abci.dialogues

This module contains the dialogues of the DummyAbciApp.

