<a id="packages.valory.skills.abstract_round_abci.tests.data.dummy_abci.models"></a>

# packages.valory.skills.abstract`_`round`_`abci.tests.data.dummy`_`abci.models

This module contains the shared state for the abci skill of DummyAbciApp.

<a id="packages.valory.skills.abstract_round_abci.tests.data.dummy_abci.models.SharedState"></a>

## SharedState Objects

```python
class SharedState(BaseSharedState)
```

Keep the current shared state of the skill.

