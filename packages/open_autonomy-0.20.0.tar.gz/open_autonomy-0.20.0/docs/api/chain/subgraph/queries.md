<a id="autonomy.chain.subgraph.queries"></a>

# autonomy.chain.subgraph.queries

Query templates.

