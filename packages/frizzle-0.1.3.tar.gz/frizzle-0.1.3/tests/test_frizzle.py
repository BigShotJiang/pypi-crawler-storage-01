def test_import():
    from frizzle import frizzle
