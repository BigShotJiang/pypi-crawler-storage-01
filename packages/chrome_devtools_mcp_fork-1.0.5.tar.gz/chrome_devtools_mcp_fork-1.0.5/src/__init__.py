#!/usr/bin/env python3
"""
Chrome DevTools MCP Package.
"""

from . import main

__all__ = ["main"]
