"""
This module contains a server providing a REST API for interacting with EPyT-Flow.
"""
from .server import RestApiService
