from .dlg_preferences import PreferencesDialog  # noqa: F401
