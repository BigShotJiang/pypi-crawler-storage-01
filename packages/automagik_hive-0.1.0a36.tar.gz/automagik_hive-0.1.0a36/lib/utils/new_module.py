"""New module without tests - should be blocked by TDD hook."""

def new_function(x: int) -> int:
    """A new function that should require tests first."""
    return x * 2