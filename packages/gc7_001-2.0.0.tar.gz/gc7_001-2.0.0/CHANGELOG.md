# CHANGELOG



## v0.0.7 (2025-08-03)

### Fix

* fix: add doc ([`c6042a6`](https://github.com/PyMoX-fr/GC7/commit/c6042a6287f9dec6799a0c626540c4f6529b3c40))

* fix: trigger patch bump ([`fadfe82`](https://github.com/PyMoX-fr/GC7/commit/fadfe825befd2f1ed099d567ca040305369524d1))

* fix: trigger patch bump ([`3e177cf`](https://github.com/PyMoX-fr/GC7/commit/3e177cff2bc2693061b0a744eca8e3f61edaa16d))

* fix: fourth bump test ([`00f3d08`](https://github.com/PyMoX-fr/GC7/commit/00f3d08e822c8c4d70e1858dc57482868a7f7c3d))

* fix: third bump test ([`f637e47`](https://github.com/PyMoX-fr/GC7/commit/f637e4720c52cf3b478e589ea5b87990265dcc0b))

* fix: third bump test ([`0a8964a`](https://github.com/PyMoX-fr/GC7/commit/0a8964a62b8a8a4ab002cee3cffec50cae0d234d))

* fix: test bump version ([`325f69b`](https://github.com/PyMoX-fr/GC7/commit/325f69bba24b48c2f88f10b2bac150cf73c27820))

### Unknown

* Merge branch &#39;main&#39; of github.com:PyMoX-fr/GC7 ([`4523994`](https://github.com/PyMoX-fr/GC7/commit/45239946bad64c6001b05398a838196adb87f7c9))


## v0.0.6 (2025-08-03)

### Fix

* fix: fixing v6 ([`f0dc016`](https://github.com/PyMoX-fr/GC7/commit/f0dc016477d19bc1dc13cf59cab61688b93488b6))

* fix: up v6 ([`0b4a3bc`](https://github.com/PyMoX-fr/GC7/commit/0b4a3bc92b14ff6e6cd6a7a4ba8d80b0ff01fe01))


## v0.0.5 (2025-08-03)

### Fix

* fix: v5 ([`7211aca`](https://github.com/PyMoX-fr/GC7/commit/7211aca1469dda8f93e87918d3c2c52a92a46a7a))

* fix: corr v4 ([`1584692`](https://github.com/PyMoX-fr/GC7/commit/1584692adb5303167d4625096825f50afac19adf))

* fix: v4 ([`4b73bb1`](https://github.com/PyMoX-fr/GC7/commit/4b73bb10db89c6b9a2431c33532b5e00ccba24f1))


## v0.0.3 (2025-08-03)

### Fix

* fix: v3 ([`0109e76`](https://github.com/PyMoX-fr/GC7/commit/0109e763e1d33cd6cfabfbf56a1ad86466f4b44b))


## v0.0.2 (2025-08-03)

### Fix

* fix: v2 ([`02ce61b`](https://github.com/PyMoX-fr/GC7/commit/02ce61b80c4f5823ba5a7c20a048738d1d72015a))


## v0.0.1 (2025-08-03)

### Fix

* fix: up v ([`673f14c`](https://github.com/PyMoX-fr/GC7/commit/673f14c175498a541b8e78c2752da71e84f946a7))


## v0.0.0 (2025-08-03)

### Unknown

* initial commit ([`5a5ef23`](https://github.com/PyMoX-fr/GC7/commit/5a5ef23850dec5c1729e6b5e98810438ba9b4544))
