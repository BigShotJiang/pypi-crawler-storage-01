============
Installation
============

At the command line::

    pip install travis2docker
