=====
Usage
=====

To use travis2docker in a project::

	import travis2docker
