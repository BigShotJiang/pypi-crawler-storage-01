def greetings():
    your_name = input("What is your name Junior? ")
    print("\n")
    print("Hello, Snakers! 🐍")
    print("Welcome to the Python exercises.")
    print("Let's get started with your coding journey!")
    print(f"I hope you enjoy learning Python with Snakers, {your_name}!")
    print("Type 'snakers --help' for available commands.")
    print("Happy coding!\n")
    print("""Oh and Also as I forgot,
                        Hello, World! 🌍""")

if __name__ == "__main__":
    greetings()
    ...