# dagster-duckdb

The docs for `dagster-duckdb` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-duckdb).
