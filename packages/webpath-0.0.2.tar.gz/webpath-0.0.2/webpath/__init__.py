from webpath.core import WebPath
from webpath._http import WebResponse

__all__ = ["WebPath", "WebResponse"]
__version__ = "0.2.0"