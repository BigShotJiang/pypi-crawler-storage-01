"""Uses setuptools to install the module"""

import setuptools

setuptools.setup()
