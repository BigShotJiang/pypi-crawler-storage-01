.. automodule:: vivarium.framework.population.manager
