.. automodule:: vivarium.framework.lifecycle
