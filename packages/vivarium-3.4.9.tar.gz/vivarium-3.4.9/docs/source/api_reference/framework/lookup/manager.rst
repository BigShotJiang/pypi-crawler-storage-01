.. automodule:: vivarium.framework.lookup.manager
