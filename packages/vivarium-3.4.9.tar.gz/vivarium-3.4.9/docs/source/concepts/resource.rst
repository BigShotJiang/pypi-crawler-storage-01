.. _resource_concept:

===================
Resource Management
===================

.. todo::

   Everything here.
