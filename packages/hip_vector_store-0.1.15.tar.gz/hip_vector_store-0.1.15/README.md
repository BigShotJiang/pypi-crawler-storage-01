# Vector store
Creation of vector index and tables, and retrieval of vector indexes
