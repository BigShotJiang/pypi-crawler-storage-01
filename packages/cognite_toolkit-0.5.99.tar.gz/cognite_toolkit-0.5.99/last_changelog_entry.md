## cdf 

### Fixed

- [alpha] Running `cdf dump agents` and `cdf deploy` with agents.
Unofficial properties from the API are now included.

## templates

No changes.