"""Directory management for Model Sentinel."""
