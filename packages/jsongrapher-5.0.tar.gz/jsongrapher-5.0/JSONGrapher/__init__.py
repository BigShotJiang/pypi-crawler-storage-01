#Try to do things a bit like https://github.com/python/cpython/blob/master/Lib/collections/__init__.py
#Except instead of putting things here directly in __init__, we'll import them so they are accessible by importing the module.
from JSONGrapher.JSONRecordCreator import *
from JSONGrapher.version import *