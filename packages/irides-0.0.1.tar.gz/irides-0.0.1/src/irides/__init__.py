"""
-------------------------------------------------------------------------------

`irides` package top-level import

-------------------------------------------------------------------------------
"""

# AUTO-GENERATED version
__version__ = "0.0.1"

# Import the toolkit function
from .entry_point import get_name
