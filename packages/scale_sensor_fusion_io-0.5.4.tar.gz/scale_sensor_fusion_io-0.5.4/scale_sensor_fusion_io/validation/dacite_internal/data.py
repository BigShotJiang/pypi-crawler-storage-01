from typing import Dict, Mapping, Any

Data = Mapping[str, Any]
DictData = Dict[str, Any]
