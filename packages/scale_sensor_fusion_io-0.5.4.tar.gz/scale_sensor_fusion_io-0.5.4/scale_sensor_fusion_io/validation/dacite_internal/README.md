# What is this

Dacite has some really neat type checking functions that aren't exposed externally but are useful for writing custom parsers for SFS

This just copies over dacite source code to this repo locally so we can make updates without having to maintain/publish an actual fork of the repo.