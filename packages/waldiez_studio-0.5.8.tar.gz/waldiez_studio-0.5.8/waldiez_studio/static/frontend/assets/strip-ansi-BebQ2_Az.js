import{a as r}from"./ansi-regex-BLuUz8pX.js";const e=r();function t(r){if("string"!=typeof r)throw new TypeError(`Expected a \`string\`, got \`${typeof r}\``);return r.replace(e,"")}export{t as s};
