# Boulder Opal Scale Up Client

The Boulder Opal Scale Up Client package is a Python client for Q-CTRL Boulder Opal Scale Up. Scale Up provides a tailored solution to characterize and calibrate quantum hardware.
