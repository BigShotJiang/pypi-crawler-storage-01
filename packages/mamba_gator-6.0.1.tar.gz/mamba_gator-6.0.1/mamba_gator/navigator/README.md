# Gator - the conda navigator

This folder contains the conda navigator.
