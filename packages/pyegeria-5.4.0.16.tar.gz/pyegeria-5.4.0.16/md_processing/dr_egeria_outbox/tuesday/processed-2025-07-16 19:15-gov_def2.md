

#  Don't Update Regulation
## Name
A Regulation
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Create Governance Control
## Name
A Control
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Create Governance Rule
## Name
a gov rule
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Service Level Objectives
## Name
An Obligation
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Create Governance Process
## Name
A Gov Process
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Governance Responsibility
## Name
A Responsibility
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Update Governance Procedure
## Name
A Gov procedure
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

## Supports Policies
Approach

## Merge Update
True
____

#  Don't Create Security Access Control
## Name
sec access
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Security Group
## Name
a Sec Group
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED


____

#  Don't Naming Standard Rule
## Name
a Namng Standard
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Certification Type
## Name
a Cert
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create License Type
## Name
a License
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

___

#  Don't Create Governance Principle
## Name
Talmudic
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Update Governance Approach
## Name
Approach
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED
## Drivers
A Regulation
## Merge Update
True
____

# Don't Create Governance Strategy
## Name
Strategy
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Detach Governance Drivers
## Definition 1
A Regulation
## Definition 2
Strategy
## Label
Don't get caught

___

# `Governance Definitions` with filter: `*`

```
[
    {
        "typeName": "GovernanceApproach",
        "extendedProperties": {
            "summary": "Based on Talmud",
            "description": "Somewhat chaotic"
        },
        "documentIdentifier": "GovApproach::Approach",
        "title": "Approach",
        "scope": "InterGalactic",
        "domainIdentifier": 1,
        "importance": "Somewhat",
        "outcomes": [
            "Happiness"
        ],
        "results": [
            "Unknown"
        ],
        "GUID": "e0b6721f-80dc-4342-ab83-ea556d4beff8"
    },
    {
        "typeName": "GovernanceProcedure",
        "extendedProperties": {
            "summary": "Based on Talmud",
            "description": "Somewhat chaotic"
        },
        "documentIdentifier": "GovProcedure::A Gov procedure",
        "title": "A Gov procedure",
        "scope": "InterGalactic",
        "domainIdentifier": 1,
        "importance": "Somewhat",
        "outcomes": [
            "Happiness"
        ],
        "results": [
            "Unknown"
        ],
        "GUID": "7029fe43-3445-4b0a-a259-34cd3fa0b0d3"
    },
    {
        "typeName": "GovernanceStrategy",
        "extendedProperties": {
            "summary": "Based on Talmud",
            "description": "Somewhat chaotic"
        },
        "documentIdentifier": "GovStrategy::Strategy",
        "title": "Strategy",
        "scope": "InterGalactic",
        "domainIdentifier": 1,
        "importance": "Somewhat",
        "outcomes": [
            "Happiness"
        ],
        "results": [
            "Unknown"
        ],
        "GUID": "388ea693-5239-46c0-a339-5bb96bd6a514"
    },
    {
        "typeName": "Regulation",
        "extendedProperties": {
            "summary": "Based on Talmud",
            "description": "Somewhat chaotic"
        },
        "documentIdentifier": "Regulation::A Regulation",
        "title": "A Regulation",
        "scope": "InterGalactic",
        "domainIdentifier": 1,
        "importance": "Somewhat",
        "outcomes": [
            "Happiness"
        ],
        "results": [
            "Unknown"
        ],
        "GUID": "df38d7cc-f6f8-4879-a092-d735be27bc3d"
    }
]
```

# Provenance

* Results from processing file gov_def2.md on 2025-07-16 19:15
