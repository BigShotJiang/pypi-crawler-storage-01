# Creating Information Supply Chains

We can also use Dr.Egeria to create information supply chains. Lets take a look at how.

___

# Create Information Supply Chain

## Display Name

## Description

## Scope

## Purposes




___


# Create Information Supply Chain Segment

## Display Name

## Description

## Scope

## Integration Style

___

# Link Supply Chain Segments

## Segment 1 Name

## Segment 2 Name

## Link Label

## Link Description

