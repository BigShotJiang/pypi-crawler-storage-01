
___

# Don't Create Digital Product
## Name
Opposition spending data
## Description
Sensitive spending data for the political opposition.
## Product Name
Non-Patriot Spending
## Product Status
PROPOSED
## Product Type
Political Dirty Tricks
## Product Identifier
Enslave the Dems
## Product Description
This product will help assure continueing dominance of the Trump party by helping to incarcerate or enslave all
opposition after stripping them of resources to fund our `gold-plat the world` initiative.
## Maturity
Concept
## Service Life
As long as needed


#  Don't Create Data Sharing 
## Name
Leak to fox

## Description
Leak sensitive personal data only to the conservative media.

## Status
PROPOSED

___

# Don't View Data Sharing Agreements
## Output Format
LIST

___

# Don't View Data Sharing Agreements
## Output Format
REPORT
___
#  View Collections
## Output Format
LIST
