
# Create Term-Term Relationship
## Term 1 Name
T1
## Term 2 Name
T2
## Term Relationship
Synonym