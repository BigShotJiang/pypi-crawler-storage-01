

# View Data Dictionaries

## Output Format
DICT
## Search String

* 


