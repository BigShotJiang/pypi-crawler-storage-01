# sage_setup: distribution = sagemath-polyhedra
from sage.schemes.toric.all import *
