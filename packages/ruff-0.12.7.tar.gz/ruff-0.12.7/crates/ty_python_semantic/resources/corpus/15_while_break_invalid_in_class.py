while True:

    class A:
        x: int

        break
