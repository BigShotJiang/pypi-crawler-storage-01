a = 1 or \
2 and \
4
