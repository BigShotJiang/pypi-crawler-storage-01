from foo import bar
from foo.bar import baz
from foo import *
