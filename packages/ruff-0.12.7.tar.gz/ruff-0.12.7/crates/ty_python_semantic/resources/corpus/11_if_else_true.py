if True:
    b
else:
    c
