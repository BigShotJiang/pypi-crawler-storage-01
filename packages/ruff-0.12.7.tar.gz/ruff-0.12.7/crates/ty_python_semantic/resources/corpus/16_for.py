for a in b:
    c
