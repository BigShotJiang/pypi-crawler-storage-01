def name_1[name_0: name_0](name_2: name_0):
    try:
        pass
    except name_2:
        pass

from typing import Any

def name_2[T: Any](x: T):
    try:
        pass
    except x:
        pass

