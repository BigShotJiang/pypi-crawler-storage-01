class Foo(Base, metaclass=Meta):
    pass
