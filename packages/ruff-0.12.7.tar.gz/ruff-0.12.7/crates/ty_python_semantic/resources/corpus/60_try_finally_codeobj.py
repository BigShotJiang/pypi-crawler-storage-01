try:
    def f(): pass
finally:
    def g(): pass
