while a:
    continue
