while True:

    def b():
        x: int

        break
