from __future__ import annotations

def foo(a: foo()):
    pass
