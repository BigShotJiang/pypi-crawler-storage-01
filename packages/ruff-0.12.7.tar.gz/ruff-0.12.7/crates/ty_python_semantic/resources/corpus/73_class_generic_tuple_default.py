class Foo[*T = *tuple[int, str]]:
    x: T
