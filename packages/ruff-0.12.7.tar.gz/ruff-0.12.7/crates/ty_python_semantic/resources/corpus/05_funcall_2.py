fun(a, b)
