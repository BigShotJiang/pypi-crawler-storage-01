match x:
    case {0: 0}:
        pass
