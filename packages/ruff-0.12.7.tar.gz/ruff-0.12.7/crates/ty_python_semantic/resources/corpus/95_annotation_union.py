from typing import Union

x: Union[int, str] = 1
