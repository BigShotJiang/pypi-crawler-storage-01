[x for x in s].copy()
