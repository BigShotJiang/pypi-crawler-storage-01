if a:
    b
