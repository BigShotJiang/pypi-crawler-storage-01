while True:
    if x:
        try:
            y = x
        except:
            break
    else:
        y = z
