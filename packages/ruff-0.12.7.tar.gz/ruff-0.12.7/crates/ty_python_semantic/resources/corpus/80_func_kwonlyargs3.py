def foo(z, *, x=1, kwo, **c):
    a
