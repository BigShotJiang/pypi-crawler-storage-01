with a:
    if b:
        pass
    else:
        assert c
