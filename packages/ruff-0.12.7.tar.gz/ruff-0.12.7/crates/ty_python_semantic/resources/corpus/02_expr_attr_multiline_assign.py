foo(
    bar=1
).attr = 1
