match ():
    case [0, *y]:
        pass
    case [*x]:
        pass
