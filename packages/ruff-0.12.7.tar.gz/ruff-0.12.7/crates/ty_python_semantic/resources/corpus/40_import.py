import foo
import foo2, bar
import foo3 as baz
import foo.bar.baz
