x == y or (
    x is not None and x == z
)

x == y or \
    x <= 65 or x >= 102
