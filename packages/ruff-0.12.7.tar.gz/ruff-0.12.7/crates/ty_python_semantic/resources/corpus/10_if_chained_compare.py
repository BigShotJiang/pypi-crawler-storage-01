if 0 < x < 10:
    pass
