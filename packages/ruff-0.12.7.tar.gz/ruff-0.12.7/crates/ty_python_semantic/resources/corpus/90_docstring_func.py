def foo():
    "docstring"
