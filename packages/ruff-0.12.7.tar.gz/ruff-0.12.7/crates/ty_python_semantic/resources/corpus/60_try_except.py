try:
    a
except Exc:
    b
