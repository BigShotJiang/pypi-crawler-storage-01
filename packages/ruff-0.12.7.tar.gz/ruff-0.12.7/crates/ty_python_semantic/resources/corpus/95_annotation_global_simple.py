def f():
    some_global: int
    print(some_global)

