@foo.bar
class C:
   pass

