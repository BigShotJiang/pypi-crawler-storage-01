class Foo[**P]:
    x: P
