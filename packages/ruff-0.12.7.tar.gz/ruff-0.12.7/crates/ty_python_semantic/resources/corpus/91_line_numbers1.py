a = [ 1,
    2,
]
# If 1 is not on the same line as assignment, CPython3.5 reports that
# module's code object starts at line 2, while we that at line 1.
