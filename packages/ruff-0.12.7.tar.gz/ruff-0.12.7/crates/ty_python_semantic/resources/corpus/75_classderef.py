def foo(bar):

    class Foo:
        call(bar)
