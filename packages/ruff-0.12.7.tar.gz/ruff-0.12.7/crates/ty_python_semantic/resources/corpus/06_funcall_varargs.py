c = (a, b)
fun(a, b, *c)
