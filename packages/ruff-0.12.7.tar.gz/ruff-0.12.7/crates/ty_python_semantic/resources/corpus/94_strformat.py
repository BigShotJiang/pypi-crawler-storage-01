def f(name, args):
    return f"foo.{name}({', '.join(args)})"
