def f(x):
    match x:
        case {**z}:
            pass
