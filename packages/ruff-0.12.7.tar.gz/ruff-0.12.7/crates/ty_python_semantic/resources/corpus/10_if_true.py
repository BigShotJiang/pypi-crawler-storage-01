if 1:
    a

if True:
    b

if "foo":
    c
