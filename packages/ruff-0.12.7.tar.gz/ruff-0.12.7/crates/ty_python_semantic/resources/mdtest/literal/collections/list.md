# Lists

## Empty list

```py
reveal_type([])  # revealed: list[Unknown]
```
