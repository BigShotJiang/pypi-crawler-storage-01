from alation_ai_agent_mcp.server import run_server

if __name__ == "__main__":
    run_server()
