from bayserver_core.bayserver import BayServer
from bayserver_core.util.locale import Locale
from bayserver_core.util.message import Message

class CgiSymbol:

    # CGI Messages
    CGI_PROC_READ_METHOD_SELECT_NOT_SUPPORTED = "CGI_PROC_READ_METHOD_SELECT_NOT_SUPPORTED"
    CGI_PROC_READ_METHOD_SPIN_NOT_SUPPORTED = "CGI_PROC_READ_METHOD_SPIN_NOT_SUPPORTED"



