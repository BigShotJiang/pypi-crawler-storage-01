"""Package for MammotionMQTT."""

from .mammotion_mqtt import MammotionMQTT

__all__ = ["MammotionMQTT"]
