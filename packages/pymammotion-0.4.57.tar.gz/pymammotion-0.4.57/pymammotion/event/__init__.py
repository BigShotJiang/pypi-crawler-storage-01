# __init__.py

# version of Luba Desktop
__version__ = "0.0.1"

from .event import BleNotificationEvent, MoveEvent
