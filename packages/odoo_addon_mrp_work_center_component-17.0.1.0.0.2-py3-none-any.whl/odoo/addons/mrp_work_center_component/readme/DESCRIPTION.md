Adds a "Components" tab to Work Centers to define fixed products and quantities, which are automatically added to manufacturing orders using those work centers, regardless of the production quantity.
