Python side channel agent for Shaken Fist
=========================================

This is a python side channel in-guest agent for [Shaken Fist](https://github.com/shakenfist/shakenfist).