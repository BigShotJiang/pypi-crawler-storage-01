# DtoFilterOperator


## Enum

* `OpEqual` (value: `'eq'`)

* `OpNotEqual` (value: `'ne'`)

* `OpGreater` (value: `'gt'`)

* `OpGreaterEq` (value: `'gte'`)

* `OpLess` (value: `'lt'`)

* `OpLessEq` (value: `'lte'`)

* `OpLike` (value: `'like'`)

* `OpStartsWith` (value: `'starts'`)

* `OpEndsWith` (value: `'ends'`)

* `OpNotLike` (value: `'nlike'`)

* `OpIn` (value: `'in'`)

* `OpNotIn` (value: `'nin'`)

* `OpIsNull` (value: `'null'`)

* `OpIsNotNull` (value: `'nnull'`)

* `OpDateEqual` (value: `'deq'`)

* `OpDateAfter` (value: `'dafter'`)

* `OpDateBefore` (value: `'dbefore'`)

* `OpDateBetween` (value: `'dbetween'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


