"""Módulo para ejecutar experimentos."""

from .runner import ExperimentRunner

__all__ = ["ExperimentRunner"]
