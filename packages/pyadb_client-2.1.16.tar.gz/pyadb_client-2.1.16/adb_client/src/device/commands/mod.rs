mod framebuffer;
mod install;
mod pull;
mod push;
mod reboot;
mod shell;
mod stat;
mod uninstall;
