# default_logging

A Python package for standardized logging configuration with millisecond-precision timestamps, timezone-aware formatting, and seamless OpenTelemetry trace context integration.

## Features

- **Millisecond-precision timestamps** in log output.
- **Timezone-aware formatting** (local or UTC with 'Z' suffix).
- **YAML-based logging configuration** for easy customization.
- **Rotating file handler** and console logging out-of-the-box.
- **OpenTelemetry trace context** support in log messages.
- **Automatic log directory creation** for file handlers.

## Installation

Clone this repository and install dependencies:

```bash
poetry lock && poetry sync
```

## Usage

1. **Import and set up logging:**

```python
from default_logging import setup_logging

setup_logging()
```

2. **(Optional) Use your own config:**

```python
setup_logging(config_path="path/to/your_logging_config.yaml")
```

3. **Integrate with OpenTelemetry:**

See `app.py` for an example of integrating OpenTelemetry tracing with logging.

## Example

```python
from default_logging import setup_logging
import logging

setup_logging()
logger = logging.getLogger(__name__)
logger.info("Hello, world!")
```

## Logging Configuration

The default configuration is defined in [`default_logging/logging_config.yaml`](default_logging/logging_config.yaml):

- **Formatters:**  
  - `simple`: UTC timestamps, millisecond precision.
  - `simple_with_trace_context`: Adds OpenTelemetry trace info to each log line.
- **Handlers:**  
  - `console_stdout`: Logs to stdout.
  - `rotating_file_handler`: Logs to `logs/app.log` with rotation.
- **Root logger:**  
  - Level: `DEBUG`
  - Handlers: both console and file.

You can customize the YAML config or provide your own.

## MillisecondFormatter

Custom formatters in [`default_logging/millisecond_formatter.py`](default_logging/millisecond_formatter.py) provide:

- `%f` for milliseconds
- `%z` for timezone offset (`+HH:MM`, `-HH:MM`, or `Z` for UTC)

## OpenTelemetry Integration

The package is compatible with OpenTelemetry. Example usage is shown in [`app.py`](app.py):

- Sets up a tracer and logs within a span.
- Log format includes trace and span IDs.

## License

[MIT License](LICENSE) (add your license file if needed)