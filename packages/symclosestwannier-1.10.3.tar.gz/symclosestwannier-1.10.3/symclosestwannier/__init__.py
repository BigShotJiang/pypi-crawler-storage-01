import os

__version__ = "1.10.3"
__top_dir__ = os.path.normpath(os.path.dirname(__file__) + "/../") + "/"
