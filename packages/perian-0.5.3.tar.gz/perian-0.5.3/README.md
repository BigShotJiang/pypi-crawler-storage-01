# PERIAN Sky Platform API Python Client

### Getting Started 
To get started on our platform, follow [our guide](https://storage.googleapis.com/perian-public-files/Perian_Sky_Platform_Getting_Started.pdf) that will walk you through all the necessary setup and features.
