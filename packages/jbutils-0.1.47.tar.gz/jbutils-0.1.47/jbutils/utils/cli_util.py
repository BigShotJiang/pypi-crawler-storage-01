"""Utility functions for handling CLI commands, similar to a REPL but as one-offs"""

from rich import print
from rich.console import console

