# -*- coding: utf-8 -*-
"""
qspec._cpp
==========

Module for simulations of laser-atom interaction.
"""

from qspec._cpp._cpp import *
