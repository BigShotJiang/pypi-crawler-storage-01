class FactoryException(Exception):
    """
    General exception class for the lazy factory functions
    """

    ...
