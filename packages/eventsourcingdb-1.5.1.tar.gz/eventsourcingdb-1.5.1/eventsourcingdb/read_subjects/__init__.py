from .is_subject import is_subject

__all__ = [
    "is_subject",
]
