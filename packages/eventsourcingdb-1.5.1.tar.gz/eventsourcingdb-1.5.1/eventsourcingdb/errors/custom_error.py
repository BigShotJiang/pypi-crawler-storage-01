class CustomError(Exception):
    pass
