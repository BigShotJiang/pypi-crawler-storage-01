This module adds support for multi company on Project module.
It adds ``company_id`` on the following models :
- ``project.task.type`` (Task Stages)
- ``project.project.stage`` (Project Stages)
