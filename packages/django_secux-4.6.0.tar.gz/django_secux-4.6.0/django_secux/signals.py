from django.dispatch import Signal

attack_detected = Signal()
