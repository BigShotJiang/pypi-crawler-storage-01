from .data_collection import DataCollectionDto, DataCollectionSpec
from .dataset import Attribute, Citation, DatasetDto, DatasetSpec
from .distribution import Distribution
from .observable import ObservableDto, ObservableSpec
from odp.dto.resource import ResourceDto

del ResourceDto
