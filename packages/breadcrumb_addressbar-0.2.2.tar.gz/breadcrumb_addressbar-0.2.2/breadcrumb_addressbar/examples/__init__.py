"""
Examples package for Breadcrumb Address Bar.

This package contains demonstration scripts showing how to use
the breadcrumb address bar library.
"""

__all__ = []
