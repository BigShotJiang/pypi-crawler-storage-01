.. _install:

Installation
============

With Pip
--------

.. code-block:: bash

    $ pip install airtable-db-export


With UV
--------

.. code-block:: bash

    $ uv add airtable-db-export
