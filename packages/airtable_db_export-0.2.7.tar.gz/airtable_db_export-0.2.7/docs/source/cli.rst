.. _cli:

ADBE CLI
========

Airtable DB Export is a command line utility, available after installing as ``airtable-db-export`` or
``adbe`` (same tool).

.. click:: airtable_db_export.main:cli
   :prog: adbe
   :nested: full
