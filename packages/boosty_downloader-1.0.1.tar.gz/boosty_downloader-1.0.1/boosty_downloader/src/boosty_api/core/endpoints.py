"""All constants for endpoints."""

BASE_URL = 'https://api.boosty.to/v1/'
