"""A module containing the token service for azol"""
from azol.services.token_service import TokenService

__all__ = [
    "TokenService"
]
