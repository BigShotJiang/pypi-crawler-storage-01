"""A module containing all Azol models"""
from .generic_resource import GenericResource

__all__ = [
    "GenericResource"
]
