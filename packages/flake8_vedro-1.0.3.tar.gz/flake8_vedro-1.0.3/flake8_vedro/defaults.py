class Defaults:
    MAX_PARAMS_COUNT = 8
