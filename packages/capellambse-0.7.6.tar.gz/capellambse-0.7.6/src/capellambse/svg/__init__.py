# SPDX-FileCopyrightText: Copyright DB InfraGO AG
# SPDX-License-Identifier: Apache-2.0
"""Export diagrams to ``.svg`` files."""

from .generate import SVGDiagram as SVGDiagram
