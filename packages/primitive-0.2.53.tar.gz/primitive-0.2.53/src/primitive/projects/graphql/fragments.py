project_fragment = """
fragment ProjectFragment on Project {
    id
    pk
    slug
    name
    createdAt
    updatedAt
}
"""
