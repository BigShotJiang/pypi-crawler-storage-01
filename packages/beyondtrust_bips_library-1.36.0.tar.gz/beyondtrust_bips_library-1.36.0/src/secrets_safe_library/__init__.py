from .config import configure_logging

__version__ = "v1.36.0"
__library_name__ = "Secret Safe Library"

configure_logging()
