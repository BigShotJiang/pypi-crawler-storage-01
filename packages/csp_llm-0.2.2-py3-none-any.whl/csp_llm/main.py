import gui

if __name__ == "__main__":
    gui.main()
