"""
csp_llm

I'll put a description here later
"""

import importlib.metadata

__version__ = importlib.metadata.version("csp_llm")
__name__ = "csp_llm"


# __all__ = [
#     "__version__",
# ]
