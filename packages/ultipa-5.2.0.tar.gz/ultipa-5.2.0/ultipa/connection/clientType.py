# -*- coding: utf-8 -*-
# @Time    : 2023/7/18 11:53
# @Author  : Ultipa
# @Email   : support@ultipa.com
# @File    : clientType.py
class ClientType:
    '''
        This class defines the types of client.

    '''
    Default = 0
    Algo = 1
    Update = 2
    Leader = 3
