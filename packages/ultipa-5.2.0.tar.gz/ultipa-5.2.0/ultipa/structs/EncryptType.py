
class EncryptType:
    AES128 = 'AES128'
    AES256 = 'AES256'
    RSA = 'RSA'
    ECC = 'ECC'
