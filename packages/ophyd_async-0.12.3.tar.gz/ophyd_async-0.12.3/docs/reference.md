# Reference

Technical reference material including APIs and release notes.

```{toctree}
:maxdepth: 1
:glob:

API <_api/index>
genindex
Release Notes <https://github.com/bluesky/ophyd-async/releases>
```
