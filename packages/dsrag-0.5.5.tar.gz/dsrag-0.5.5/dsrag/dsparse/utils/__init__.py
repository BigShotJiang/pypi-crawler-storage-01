"""
Utility functions for dsparse.
""" 