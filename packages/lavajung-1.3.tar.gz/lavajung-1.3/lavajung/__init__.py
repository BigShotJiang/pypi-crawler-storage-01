# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from .parser import *
import os

__version__ = '1.3'

__all__ = [
    'RE_PATTERN_TEMPLATE',
    'replace',
    'normalize',
    'Emoji'
]
