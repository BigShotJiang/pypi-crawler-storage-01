<h1 align="center">
<img src="https://cdn.prod.website-files.com/669594441bac4d6528273301/669594441bac4d6528273329_Group%20180.svg" alt="TYBA" width="300">
</h1><br>


Python client to Tyba's project simulation API.

__Documentation:__ https://docs.tybaenergy.com/api
