from django.dispatch import Signal

honeypot = Signal()
