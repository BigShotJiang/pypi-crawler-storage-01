from .explanations import remove_duplicate_words, remove_character_combo, register_hooks, simplification

__all__ = [remove_duplicate_words, remove_character_combo, register_hooks, simplification]
