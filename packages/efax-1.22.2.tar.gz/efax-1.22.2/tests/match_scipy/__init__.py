"""These tests ensure that our distributions match scipy's."""
