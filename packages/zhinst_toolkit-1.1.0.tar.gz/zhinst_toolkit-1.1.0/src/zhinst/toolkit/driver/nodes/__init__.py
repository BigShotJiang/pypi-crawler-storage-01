"""Adaptions of specific nodes.

Custom node child classes with additional helper functions and attributes.
"""
