"""Package containing a set of scripts to ease the use of this project."""
