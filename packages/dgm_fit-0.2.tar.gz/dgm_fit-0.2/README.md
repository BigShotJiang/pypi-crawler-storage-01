# dgm-fit

[![python](https://img.shields.io/badge/python-3.11-purple.svg)](https://www.python.org/)
[![pipeline](https://git.jinr.ru/dagflow-team/dgm-fit/badges/master/pipeline.svg)](https://git.jinr.ru/dagflow-team/dgm-fit/commits/master)
[![coverage report](https://git.jinr.ru/dagflow-team/dgm-fit/badges/master/coverage.svg)](https://git.jinr.ru/dagflow-team/dgm-fit/-/commits/master)

The fitter interface for the dag-modelling framework.

## Repositories

- Main repo:
  - Development/CI: https://git.jinr.ru/dagflow-team/dgm-fit
  - Contact/pypi/mirror: https://github.com/dagflow-team/dgm-fit
  - PYPI: https://pypi.org/project/dgm-fit
