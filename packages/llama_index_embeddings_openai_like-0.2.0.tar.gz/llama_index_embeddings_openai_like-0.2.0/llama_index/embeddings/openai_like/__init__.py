from llama_index.embeddings.openai_like.base import (
    OpenAILikeEmbedding,
)

__all__ = [
    "OpenAILikeEmbedding",
]
