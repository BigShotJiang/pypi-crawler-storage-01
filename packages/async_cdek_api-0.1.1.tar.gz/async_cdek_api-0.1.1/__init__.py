from .client import CDEKAPIClient

__version__ = "0.1.1"
__all__ = ["CDEKAPIClient"]
