title: FTIR
::: pydatalab.apps.ftir
