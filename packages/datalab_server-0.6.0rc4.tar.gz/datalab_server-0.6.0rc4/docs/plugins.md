# Plugins

*datalab*'s plugin system is under active development, as is this documentation
page.
The most mature plugin type are custom application data blocks, a template repository for which can be found at [datalab-org/datalab-app-plugin-template](https://github.com/datalab-org/datalab-app-plugin-template).
