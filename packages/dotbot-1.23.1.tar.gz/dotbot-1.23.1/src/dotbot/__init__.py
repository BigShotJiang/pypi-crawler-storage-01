from dotbot.__about__ import __version__
from dotbot.cli import main
from dotbot.plugin import Plugin

__all__ = ["main", "Plugin", "__version__"]
