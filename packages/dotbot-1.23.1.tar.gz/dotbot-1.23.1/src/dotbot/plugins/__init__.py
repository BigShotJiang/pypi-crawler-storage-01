from dotbot.plugins.clean import Clean
from dotbot.plugins.create import Create
from dotbot.plugins.link import Link
from dotbot.plugins.shell import Shell

__all__ = ["Clean", "Create", "Link", "Shell"]
