from dotbot.util.common import shell_command

__all__ = ["shell_command"]
