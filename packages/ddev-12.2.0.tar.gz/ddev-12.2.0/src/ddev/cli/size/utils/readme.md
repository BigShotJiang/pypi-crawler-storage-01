# Size Utils

## Dashboard Template

`dashboard.json` contains the JSON template for creating the Datadog dashboard: Disk Usage Status for Integrations and Dependencies 


The dashboard can be created using the `ddev size create-dashboard` command.