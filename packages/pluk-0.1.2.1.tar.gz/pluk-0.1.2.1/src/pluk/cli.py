def main():
    """Entry point for pluk CLI."""
    print("pluk: symbol search engine CLI")


if __name__ == '__main__':
    main()
