Authors
=======

This file contains the list of people involved in the development
of pytest-mongo along its history.

* Paweł Wilczyński
* Tomasz Święcicki
* Tomasz Karbownicki
* Grzegorz Śliwiński
* Karolina Blümke
* Damian Skrzypczak
