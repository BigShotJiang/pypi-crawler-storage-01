"""wavinsentio - API Wrapper for Wavin Sentio underfloor heating system"""

__version__ = '0.5.3'
__author__ = 'Tobias Laursen <djerik@gmail.com>'
__all__ = []
