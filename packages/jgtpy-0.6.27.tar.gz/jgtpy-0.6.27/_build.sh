make clean;make bump_version ;make dist && twine upload dist/* 

