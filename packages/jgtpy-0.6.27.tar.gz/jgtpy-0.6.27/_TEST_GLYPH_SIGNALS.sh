INST=EUR/USD JGTPY_DATA=/src/jgtml/data/current TF="m5 m15 H1 H4 D1 W1 M1" . _GLYPH_SIGNALS.sh|(mkdir -p logs;tee logs/$(tlid min).txt)
