JGTPY_DATA=/src/jgtml/data/current TF="m5 m15 H1 H4 D1 W1 M1" . _GLYPH_MOUTH_PHASE_WATER_STATE.sh
