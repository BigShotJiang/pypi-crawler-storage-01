# Signals

* Bellow is a CSV of the various signals that this package aim to serve with their corresponding columns in CDS data :

```
Name;Title;Description;Question;Notes
fdb;Fractal Divergent Bar Code;Fractal Divergent Bar Code (contains the signal value either buy, sell or nothing);;" bdb"
fdbs;Fractal Divergent Bar Sell;Fractal Divergent Bar Sell;;" Bearish Divergent Bar"
fdbb;Fractal Divergent Bar Buy;Fractal Divergent Bar Buy;;" Bullish Divergent Bar"
acs;AC Deceleration Sell;AC Deceleration Sell;;" "
acb;AC Acceleration Buy;AC Acceleration Buy;;" "
fs;Fractal Sell;Fractal Sell;Can the representation be optimized ? Enhanced ?;" "
fb;Fractal Buy;Fractal Buy;;" "
zlcb;Zero Line Crossing Buy;Zero Line Crossing Buy;;" "
zlcs;Zero Line Crossing Sell;Zero Line Crossing Sell;;" "
zcol;Zero Line Crossing;Zero Line Crossing (Not sure if this is a signal);How many bars were there since last cross signal of the opposite direction ? How is the relationship of this signal profit and this number of bars ?;" Number of bars before last cross when another type of signal was generated could be a learning"
sz;Zone Signal Sell;Zone Signal Sell;;" "
bz;Zone Signal Buy;Zone Signal Buy;;" "
ss;Saucer Sell;Saucer Sell;;" "
sb;Saucer Buy;Saucer Buy;;
```