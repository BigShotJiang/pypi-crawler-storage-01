
JGTCLI_PROG_NAME="jgtcli"
JGTCLI_PROG_DESCRIPTION="JGTCLI Command Line Interface"
JGTCLI_EPILOG="Basically deals with Indicators data and the signal generation (will be replaced by cdscli)"

CDSCLI_PROG_NAME="cdscli"
CDSCLI_PROG_DESCRIPTION="CDSCLI Command Line Interface"
CDSCLI_EPILOG="Basically deals with Indicators data and the signal generation (meant to replace jgtcli)"



ADSCLI_PROG_NAME="adscli"
ADSCLI_PROG_DESCRIPTION="Analysis Data Service Command Line Interface"
ADSCLI_PROG_EPILOG="View Data and generated visualizations.Plot the chart for a given instrument and timeframe."


IDSCLI_PROG_NAME="idscli"
IDSCLI_PROG_EPILOG="Indicator data IDS generation, no signal.  It is meant to be a previous step to signal generation done in CDS and is not yet used in the current version of the system. (even though it is implemented, works and saves JGTPY_DATA/ids/... files)"
IDSCLI_PROG_DESCRIPTION="JGTAPY Command Line Interface"



MKSCLI_PROG_NAME="mkscli"
MKSCLI_PROG_DESCRIPTION="Market Data Service Command Line Interface"
MKSCLI_PROG_EPILOG="Market Data Service Command Line Interface"

