# FigletWidget reference

::: textual_pyfiglet.figletwidget.FigletWidget
