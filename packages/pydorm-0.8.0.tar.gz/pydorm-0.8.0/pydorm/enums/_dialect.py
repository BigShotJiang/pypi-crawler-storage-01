from enum import Enum


class Dialect(Enum):
    MYSQL = 'Mysql'
    SQLITE = 'Sqlite'
