from ._datasource import IDataSource

__all__ = [
    'IDataSource',
]
