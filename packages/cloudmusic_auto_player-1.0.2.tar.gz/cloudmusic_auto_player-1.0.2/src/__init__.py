"""
网易云音乐 MCP 控制器包
"""

__version__ = "1.0.0"
__author__ = "xiduan"
__email__ = "lxd4094@foxmail.com" 