"""Exact or Tabular RL algorithms

"""