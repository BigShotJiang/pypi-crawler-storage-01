"""
Rain UI - PyCloud OS Arayüz Sistemi
macOS Aqua stilinde masaüstü ortamı
"""

__version__ = "0.9.0-dev"
__author__ = "PyCloud Team" 