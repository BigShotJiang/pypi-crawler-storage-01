# sage_setup: distribution = sagemath-objects
# Resolve a cyclic import
import sage.structure.element
