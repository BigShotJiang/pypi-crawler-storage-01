"""
INDI driver for libcamera supported cameras
"""

__version__ = "3.0.0"
