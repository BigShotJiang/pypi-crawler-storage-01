set -e
cp -a ../book/docs/shared docs/

