raise ValueError(
    "Please use the tilemaker dev command line tool to run with a sample map"
)
