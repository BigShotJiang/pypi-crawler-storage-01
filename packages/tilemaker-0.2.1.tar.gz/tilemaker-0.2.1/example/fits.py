raise ValueError(
    "Please use the tilemaker add iqu command line tool to ingest FITS files."
)
