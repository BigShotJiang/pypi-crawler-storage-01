"""
The tilemaker package is a microservice that turns
full .fits files into servable tiles stored in a
postgres database.
"""
