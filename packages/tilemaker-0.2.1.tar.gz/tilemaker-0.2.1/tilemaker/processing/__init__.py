"""
Processing utilities to make maps into tiles.
"""
