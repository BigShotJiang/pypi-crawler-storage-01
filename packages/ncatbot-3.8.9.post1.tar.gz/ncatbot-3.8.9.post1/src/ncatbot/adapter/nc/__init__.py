# NapCat 环境适配

from ncatbot.adapter.nc.launcher import launch_napcat_service

__all__ = ["launch_napcat_service"]
