from ncatbot.scripts.utils import get_plugin_info, get_plugin_info_by_name

__all__ = [
    "get_plugin_info",
    "get_plugin_info_by_name",
]
