"""
Attribution
"""

from .input_times_gradient import InputTimesGradient

__all__ = [
    "InputTimesGradient",
]
