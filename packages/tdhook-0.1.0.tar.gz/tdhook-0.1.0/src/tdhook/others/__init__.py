"""
Prototypes
"""

__all__ = []
