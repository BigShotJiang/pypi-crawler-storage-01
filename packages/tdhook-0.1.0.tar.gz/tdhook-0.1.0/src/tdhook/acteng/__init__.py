"""
Latents
"""

from . import linear_probing

from .linear_probing import ProbingContext

__all__ = [
    "linear_probing",
    "ProbingContext",
]
