"""Workspaces tools for SingleStore MCP server."""

from .workspaces import workspaces_info

__all__ = ["workspaces_info"]
