import threading

thread_local = threading.local()
