from ansible_base.rbac.permission_registry import permission_registry

__all__ = [
    'permission_registry',
]
