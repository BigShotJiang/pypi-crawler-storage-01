"""An mdformat plugin for creating tight lists (no empty lines between list items)."""

__version__ = "0.1.1"

from .plugin import RENDERERS, update_mdit  # noqa: F401
