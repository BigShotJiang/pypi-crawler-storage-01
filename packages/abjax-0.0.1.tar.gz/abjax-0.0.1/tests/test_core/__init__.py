"""Tests for core statistical functionality."""
