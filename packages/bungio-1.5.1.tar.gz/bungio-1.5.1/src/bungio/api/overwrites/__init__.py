from bungio.api.overwrites.destiny2 import Destiny2RouteInterface


class AllRouteInterfacesOverwrites(Destiny2RouteInterface):
    pass
