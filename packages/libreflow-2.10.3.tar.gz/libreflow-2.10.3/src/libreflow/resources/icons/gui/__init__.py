import kabaret.app.resources as resources
import logging


resources.add_folder('icons.gui', __file__)
logging.debug('ICONS.GUI LOADED')