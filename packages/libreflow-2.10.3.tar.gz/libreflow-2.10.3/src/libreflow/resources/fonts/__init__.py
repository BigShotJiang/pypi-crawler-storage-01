import kabaret.app.resources as resources
import logging


resources.add_folder("fonts", __file__)
logging.debug("FONTS LOADED")