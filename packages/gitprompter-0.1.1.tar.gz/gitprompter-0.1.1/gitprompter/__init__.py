"""gitprompter"""

from .cli import diff

__all__ = ["diff"]