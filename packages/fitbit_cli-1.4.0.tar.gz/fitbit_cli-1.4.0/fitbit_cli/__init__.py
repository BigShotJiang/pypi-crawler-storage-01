# -*- coding: utf-8 -*-
"""
fitbit_cli Module
"""

__version__ = "1.4.0"
