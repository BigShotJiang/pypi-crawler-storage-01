"""Tests for external integrations."""
