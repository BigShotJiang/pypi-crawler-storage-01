# PyEfficiency
omg silly functions like binary searches and actually functional rounding!! :D

IMPORTANT LINKS:

[GitHub](https://github.com/montypythonist/PyEfficiency)

[Website](https://montypythonist.carrd.co/)

[PyPI](https://pypi.org/user/montypythonist/)

[Wiki](https://pypi.org/user/montypythonist/wiki)

[Email](mailto:julia.alotoom.contact@gmail.com)
