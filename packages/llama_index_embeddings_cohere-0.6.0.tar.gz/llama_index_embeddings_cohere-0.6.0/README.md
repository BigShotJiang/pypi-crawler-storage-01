# LlamaIndex Embeddings Integration: Cohere
