from .my_functions import random_compliment
from .my_functions import time_remaining

__all__ = ['random_compliment', 'time_remaining']
