"""
Full-text search database implementations.
"""

from .base import FulltextDB

__all__ = ["FulltextDB"] 