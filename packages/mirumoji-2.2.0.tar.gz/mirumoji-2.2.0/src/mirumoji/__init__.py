"""
CLI launcher for the Mirumoji project, an open-source, self-hostable Japanese
language immersion tool.
"""
