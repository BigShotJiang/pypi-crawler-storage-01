"""Provide a model based on Z-Wave JS.

The model pieces here should map 1:1 with the model of Z-Wave JS upstream API.
"""
