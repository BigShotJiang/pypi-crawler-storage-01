"""Constants for the Central Scene CC."""

from __future__ import annotations

SCENE_PROPERTY = "scene"
