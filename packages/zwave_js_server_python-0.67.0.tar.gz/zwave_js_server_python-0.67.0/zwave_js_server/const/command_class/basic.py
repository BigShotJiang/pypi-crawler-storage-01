"""Constants for the Basic CC."""

from __future__ import annotations

EVENT_PROPERTY = "event"
