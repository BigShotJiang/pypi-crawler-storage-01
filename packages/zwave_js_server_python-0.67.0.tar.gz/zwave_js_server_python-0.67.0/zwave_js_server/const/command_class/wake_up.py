"""Constants for the Wake Up CC."""

from __future__ import annotations

WAKE_UP_INTERVAL_PROPERTY = "wakeUpInterval"
WAKE_UP_CONTROLLER_NODE_ID_PROPERTY = "controllerNodeId"
