"""Constants for the Protection CC."""

from __future__ import annotations

LOCAL_PROPERTY = "local"
RF_PROPERTY = "rf"
