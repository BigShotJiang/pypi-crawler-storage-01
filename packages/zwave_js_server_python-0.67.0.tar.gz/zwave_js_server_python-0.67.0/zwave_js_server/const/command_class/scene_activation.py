"""Constants for the Scene Activation CC."""

from __future__ import annotations

SCENE_ID_PROPERTY = "sceneId"
