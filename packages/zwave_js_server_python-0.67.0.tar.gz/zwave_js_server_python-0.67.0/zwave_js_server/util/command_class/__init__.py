"""Module for Command Class specific utility functions."""
