"""
OpenInverter CAN Tools main program
"""

from .cli import cli

if __name__ == '__main__':
    cli()
