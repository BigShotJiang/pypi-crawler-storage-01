from src.ndvis.NDVisualizer_GUI import main

if __name__ == "__main__":
    main()