class HelicsFederateMock:
    pass

class HelicsEndpointMock:
    pass