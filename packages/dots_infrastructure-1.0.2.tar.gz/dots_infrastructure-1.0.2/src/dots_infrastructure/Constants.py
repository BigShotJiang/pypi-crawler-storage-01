from enum import Enum

class TimeRequestType(Enum):
    PERIOD = 0
    ON_INPUT = 1