pytest --cov=extract_favicon --cov-report=xml
