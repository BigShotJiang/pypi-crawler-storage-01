# TODO: The following are TODOs moved from contact-location-local
# TODO Move those to group_category.py in group-local-python-package, we'll generate this file using sql2code
# TODO develop file group_category.py in group-local-python-package
# Moved from contact-location-local https://github.com/circles-zone/contact-location-local-python-package
#TODO Sql2Code
STATE_THEY_LIVE_IN_GROUP_CATEGORY = 501
CITY_THEY_LIVE_IN_GROUP_CATEGORY = 201
