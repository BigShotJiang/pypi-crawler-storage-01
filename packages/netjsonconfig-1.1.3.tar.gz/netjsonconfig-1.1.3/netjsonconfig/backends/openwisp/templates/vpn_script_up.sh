#!/bin/sh

rm -f /tmp/will_reboot
