# History

## 1 (2025-07-24)

* First release on PyPI.
