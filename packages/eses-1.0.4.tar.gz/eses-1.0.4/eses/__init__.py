import requests
import time
import threading
from typing import List

api_url = "http://52.24.104.170:8086/RestSimulator"
proxies = []
proxy_lock = threading.Lock()
active_threads = []

def addproxy(proxy: str):
    """Add a proxy (format: 'ip:port' or 'http://ip:port')"""
    if not proxy.startswith(('http://', 'https://')):
        proxy = f"http://{proxy}"
    with proxy_lock:
        if proxy not in proxies:
            proxies.append(proxy)
            print(f"Proxy added: {proxy}")

def donate(company_name: str, country: str, war_id: str, 
           donation_sum: str = "100000000000", proxy: str = None):
    """Send a single donation (with optional proxy)"""
    params = {
        "Operation": "postDonation",
        "available_patriotism": "0",
        "company_id": "4456964",
        "company_name": company_name,
        "country": country,
        "donation_sum": donation_sum,
        "donation_type": "0",
        "sender_company_id": "4456964",
        "user_id": "3CE57CF11AFA43A1ABB7DB10431C2234",
        "version_code": "22",
        "war_id": war_id
    }
    headers = {
        "Host": "52.24.104.170:8086",
        "Connection": "Keep-Alive",
        "User-Agent": "android-async-http",
        "Accept-Encoding": "gzip",
        "Content-Length": "0"
    }
    try:
        response = requests.post(
            api_url,
            params=params,
            headers=headers,
            proxies={"http": proxy, "https": proxy} if proxy else None,
            timeout=10
        )
        print(f"Success via {proxy or 'DIRECT'}: {response.status_code}")
        return response.json()
    except Exception as e:
        print(f"Failed via {proxy or 'DIRECT'}: {str(e)}")
        return None

def _donate_cycle(company_name: str, country: str, war_id: str, times: int, delay: int):
    """Internal function for proxy cycling"""
    while True:
        with proxy_lock:
            if not proxies:
                # No proxies - just send 'times' requests directly
                for _ in range(times):
                    donate(company_name, country, war_id)
                time.sleep(delay)
                continue

            # Use all proxies in sequence
            for proxy in proxies:
                for _ in range(times):
                    donate(company_name, country, war_id, proxy=proxy)

        # Delay after full cycle
        time.sleep(delay)

def donatewithproxy(company_name: str, country: str, war_id: str, times: int = 1, delay: int = 0):
    """
    Send donations using all proxies in cycles:
    1. Each proxy sends 'times' requests
    2. Waits 'delay' seconds after full cycle
    3. Repeats indefinitely
    
    Example:
    donatewithproxy("Blackrock", "India", "2382", times=3, delay=20)
    """
    thread = threading.Thread(
        target=_donate_cycle,
        args=(company_name, country, war_id, times, delay),
        daemon=True
    )
    thread.start()
    active_threads.append(thread)
    print(f"Started donation cycle (proxies={len(proxies)}, times={times}, delay={delay}s)")

def clear_proxies():
    """Clear all proxies"""
    with proxy_lock:
        proxies.clear()
    print("Proxies cleared")

def stop_all_donations():
    """Stop all active donation threads"""
    for thread in active_threads:
        thread.join(timeout=1)
    active_threads.clear()
    print("All donations stopped")