# eses Python Package

A library for sending donation requests with proxy rotation capabilities.

## Installation

```bash
pip install eses