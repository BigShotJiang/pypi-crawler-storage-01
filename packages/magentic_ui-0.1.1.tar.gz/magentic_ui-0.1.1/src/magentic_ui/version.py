VERSION = "0.1.1"
__version__ = VERSION
APP_NAME = "Magentic-UI"
