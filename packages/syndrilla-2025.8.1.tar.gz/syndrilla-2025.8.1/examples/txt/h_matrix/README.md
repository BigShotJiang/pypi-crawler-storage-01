Codes from [here](https://github.com/quantumgizmos/bp_osd/tree/main/examples/codes).
