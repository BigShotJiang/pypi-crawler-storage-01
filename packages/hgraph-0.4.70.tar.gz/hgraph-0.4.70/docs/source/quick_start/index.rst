Quick Start
===========

For those who are impatient, or have experience with similar development models and just want
to get started, this provides a quick path that will highlight the key features of the package.

This will be enough to get up and using HGraph, but will only lightly cover the key concepts.

.. toctree::
    run_loop
    graph
    node
