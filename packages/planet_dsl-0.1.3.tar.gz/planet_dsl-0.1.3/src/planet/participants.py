class Participants:
    def __init__(self, n):
        self.n = n