class Sequence:
    def __init__(self, n):
        self.n = n