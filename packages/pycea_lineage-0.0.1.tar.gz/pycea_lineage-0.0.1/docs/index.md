```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

notebooks/getting-started

api.md
changelog.md
contributing.md
references.md

```
