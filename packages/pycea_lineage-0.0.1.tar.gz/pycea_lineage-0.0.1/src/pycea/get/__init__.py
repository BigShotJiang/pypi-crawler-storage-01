from .get_palette import palette
