#define CMAKE_CURRENT_SOURCE_DIR "/home/jiamingy/ws/xgboost_dev/xgboost/dmlc-core/test/unittest"
