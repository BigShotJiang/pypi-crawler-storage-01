class TimePeriodName():
    Year = "year"
    Month = "month"
    Week = "week"
    Day = "day"
