from ._ecologits import EcoLogits

__version__ = "0.8.0"
__all__ = [
    "EcoLogits",
    "__version__"
]
