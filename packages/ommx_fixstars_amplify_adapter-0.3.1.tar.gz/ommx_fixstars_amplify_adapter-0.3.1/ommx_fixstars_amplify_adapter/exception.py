class OMMXFixstarsAmplifyAdapterError(Exception):
    pass
