.. ommx-fixstars-amplify-adapter documentation master file, created by
   sphinx-quickstart on Tue Oct 29 10:43:19 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ommx-fixstars-amplify-adapter's documentation!
==========================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`