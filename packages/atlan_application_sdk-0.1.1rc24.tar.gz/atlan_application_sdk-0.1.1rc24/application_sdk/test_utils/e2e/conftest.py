from typing import Any, Dict

workflow_details: Dict[str, Any] = {}
