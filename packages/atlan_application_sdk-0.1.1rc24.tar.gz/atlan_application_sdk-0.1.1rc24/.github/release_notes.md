## v0.1.1rc24 (August 01, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc23...v0.1.1rc24

### Features

- Add utility function to fetch include/exclude databases from include-exclude regex (#623) (by @Abhishek Agrawal in [0c6cc62](https://github.com/atlanhq/application-sdk/commit/0c6cc62))

### Bug Fixes

- miner output path (#626) (by @Onkar Ravgan in [cabe7eb](https://github.com/atlanhq/application-sdk/commit/cabe7eb))
- db name regex pattern (#630) (by @Onkar Ravgan in [bb26992](https://github.com/atlanhq/application-sdk/commit/bb26992))
