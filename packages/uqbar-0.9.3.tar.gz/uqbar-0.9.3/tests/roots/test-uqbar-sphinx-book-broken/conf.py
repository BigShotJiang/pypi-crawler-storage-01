master_doc = "index"

extensions = ["uqbar.sphinx.book"]

html_static_path = ["_static"]

uqbar_book_strict = True
