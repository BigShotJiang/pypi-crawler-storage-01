class PublicClass:
    pass


class _PrivateClass:
    pass


def public_function():
    pass


def _private_function():
    pass
