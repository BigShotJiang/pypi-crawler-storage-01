Installation
============

To install :mod:`opensmile` run:

.. code-block:: bash

    $ # Create and activate Python virtual environment, e.g.
    $ # virtualenv --no-download --python=python3 ${HOME}/.envs/opensmile
    $ # source ${HOME}/.envs/opensmile/bin/activate
    $ pip install opensmile
