"""CLI module for TrackIt."""
