"""Tests for TrackIt time tracking application."""
