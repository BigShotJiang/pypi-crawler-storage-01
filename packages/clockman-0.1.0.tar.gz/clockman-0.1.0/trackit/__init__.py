"""
TrackIt: Terminal-based time tracking for developers.

A privacy-focused, offline-first time tracking CLI application.
"""

__version__ = "0.1.0"
__author__ = "TrackIt Team"
__email__ = "team@trackit.dev"
