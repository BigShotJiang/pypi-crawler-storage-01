import os
from typing import Optional
from typing import Self

from openinference.semconv.trace import OpenInferenceSpanKindValues
from pydantic import Field

from grafi.assistants.assistant import Assistant
from grafi.assistants.assistant_base import AssistantBaseBuilder
from grafi.common.topics.input_topic import InputTopic
from grafi.common.topics.output_topic import OutputTopic
from grafi.nodes.node import Node
from grafi.tools.llms.impl.openai_tool import OpenAITool
from grafi.workflows.impl.event_driven_workflow import EventDrivenWorkflow
from tests_integration.invoke_kwargs.llm_prompt_template_command import (
    LLMPromptTemplateCommand,
)


class SimpleLLMPromptTemplateAssistant(Assistant):
    """
    A simple assistant class that uses OpenAI's language model to process input and generate responses.

    This class sets up a workflow with a single LLM node using OpenAI's API, and provides a method
    to run input through this workflow.

    Attributes:
        api_key (str): The API key for OpenAI. If not provided, it tries to use the OPENAI_API_KEY environment variable.
        model (str): The name of the OpenAI model to use.
        event_store (EventStore): An instance of EventStore to record events during the assistant's operation.
    """

    oi_span_type: OpenInferenceSpanKindValues = Field(
        default=OpenInferenceSpanKindValues.AGENT
    )
    name: str = Field(default="SimpleLLMPromptTemplateAssistant")
    type: str = Field(default="SimpleLLMPromptTemplateAssistant")
    api_key: Optional[str] = Field(default_factory=lambda: os.getenv("OPENAI_API_KEY"))
    system_message: Optional[str] = Field(default=None)
    model: str = Field(default="gpt-4o-mini")

    @classmethod
    def builder(cls) -> "SimpleLLMPromptTemplateAssistantBuilder":
        """Return a builder for SimpleLLMPromptTemplateAssistant."""
        return SimpleLLMPromptTemplateAssistantBuilder(cls)

    def _construct_workflow(self) -> "SimpleLLMPromptTemplateAssistant":
        agent_input_topic = InputTopic(name="agent_input_topic")
        agent_output_topic = OutputTopic(name="agent_output_topic")
        # Create an LLM node
        llm_node: Node = (
            Node.builder()
            .name("OpenAINode")
            .subscribe(agent_input_topic)
            .publish_to(agent_output_topic)
            .build()
        )

        llm_node.command = LLMPromptTemplateCommand(
            tool=OpenAITool.builder()
            .name("OpenAITool")
            .api_key(self.api_key)
            .model(self.model)
            .system_message(self.system_message)
            .build()
        )

        # Create a workflow and add the LLM node
        self.workflow = (
            EventDrivenWorkflow.builder()
            .name("SimpleLLMWorkflow")
            .node(llm_node)
            .build()
        )

        return self


class SimpleLLMPromptTemplateAssistantBuilder(
    AssistantBaseBuilder[SimpleLLMPromptTemplateAssistant]
):
    """Concrete builder for SimpleLLMPromptTemplateAssistant."""

    def api_key(self, api_key: str) -> Self:
        self.kwargs["api_key"] = api_key
        return self

    def system_message(self, system_message: str) -> Self:
        self.kwargs["system_message"] = system_message
        return self

    def model(self, model: str) -> Self:
        self.kwargs["model"] = model
        return self
