from .eses import ESES

# Create module-level instance
eses = ESES()

# Expose main methods at package level
donate = eses.donate
add_proxy = eses.add_proxy
rotateproxy = eses.rotateproxy
stop_rotation = eses.stop_rotation
get_proxy_list = eses.get_proxy_list
set_default_param = eses.set_default_param
set_default_header = eses.set_default_header
clear_proxies = eses.clear_proxies

# Explicit exports
__all__ = [
    'ESES',
    'eses',
    'donate',
    'add_proxy',
    'rotateproxy',
    'stop_rotation',
    'get_proxy_list',
    'set_default_param',
    'set_default_header',
    'clear_proxies'
]