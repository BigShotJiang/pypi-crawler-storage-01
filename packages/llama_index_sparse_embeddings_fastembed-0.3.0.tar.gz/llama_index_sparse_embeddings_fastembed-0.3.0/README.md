# LlamaIndex Embeddings Integration: Fastembed
