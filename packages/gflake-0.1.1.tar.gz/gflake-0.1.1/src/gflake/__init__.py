"""gFlake - A CLI tool for deflaking Google Test test cases."""

__version__ = "0.1.0"
