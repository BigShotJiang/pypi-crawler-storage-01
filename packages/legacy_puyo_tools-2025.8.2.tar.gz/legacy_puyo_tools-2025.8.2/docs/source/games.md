# Supported Games

This tool will try to support formats from the following Puyo Puyo games:

- Puyo Puyo! 15th Annversivery
- Puyo Puyo 7
- Puyo Puyo!! 20th Annversivery (Not yet implemented)

:::{todo} Add more information about the games and the formats they use.
:::
