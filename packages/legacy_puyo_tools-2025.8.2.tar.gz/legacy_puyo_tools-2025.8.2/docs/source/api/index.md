# API Reference

This page contains auto-generated API Reference documentation[^1].

[^1]: Created with [sphinx-autodoc] and [sphinx-autodoc2].

[sphinx-autodoc]: https://www.sphinx-doc.org/en/master/usage/extensions/autodoc.html
[sphinx-autodoc2]: https://sphinx-autodoc2.readthedocs.io/en/latest/

```{toctree}
    :titlesonly:

legacy_puyo_tools/legacy_puyo_tools
```
