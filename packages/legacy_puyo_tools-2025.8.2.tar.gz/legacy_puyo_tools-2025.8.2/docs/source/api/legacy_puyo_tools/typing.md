# {mod}`legacy_puyo_tools.typing`

````{module} legacy_puyo_tools.typing

```{autodoc2-docstring} legacy_puyo_tools.typing
    :allowtitles:
```
````

## Module Contents

### Type Aliases

```{autodoc2-summary}
~legacy_puyo_tools.typing.StrPath
~legacy_puyo_tools.typing.FmpSize
~legacy_puyo_tools.typing.FmpCharacter
~legacy_puyo_tools.typing.MtxString
```

## API

````{class} legacy_puyo_tools.typing.StrPath
```{autodoc2-docstring} legacy_puyo_tools.typing.StrPath
```
````

````{class} legacy_puyo_tools.typing.FmpSize
```{autodoc2-docstring} legacy_puyo_tools.typing.FmpSize
```
````

````{class} legacy_puyo_tools.typing.FmpCharacter
```{autodoc2-docstring} legacy_puyo_tools.typing.FmpCharacter
```
````

````{class} legacy_puyo_tools.typing.MtxString
```{autodoc2-docstring} legacy_puyo_tools.typing.MtxString
```
````
