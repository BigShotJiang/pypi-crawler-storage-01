# {mod}`legacy_puyo_tools.formats.base`

````{module} legacy_puyo_tools.formats.base

```{autodoc2-docstring} legacy_puyo_tools.formats.base
    :allowtitles:
```
````

## Module Contents

### Classes

```{autodoc2-summary}
~legacy_puyo_tools.formats.base.Format
```

### API

```{autodoc2-object} legacy_puyo_tools.formats.base.Format
```
