```{autodoc2-object} legacy_puyo_tools.cli
```

<!-- # {mod}`legacy_puyo_tools.cli`

````{module} legacy_puyo_tools.cli

```{autodoc2-docstring} legacy_puyo_tools.cli
    :allowtitles:
```
````

## Module Contents

### API -->
