# {mod}`legacy_puyo_tools`

````{module} legacy_puyo_tools

```{autodoc2-docstring} legacy_puyo_tools
    :allowtitles:
```
````

## Subpackages

```{toctree}
    :titlesonly:
    :maxdepth: 3

formats/formats
```

## Submodules

```{toctree}
    :titlesonly:
    :maxdepth: 1

cli
exceptions
typing
```
