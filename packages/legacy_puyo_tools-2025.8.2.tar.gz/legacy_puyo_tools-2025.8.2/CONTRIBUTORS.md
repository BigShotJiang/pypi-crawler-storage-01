# Contributors

Thanks to the following people and projects who helped to contribute to
`legacy-puyo-tools`.

-   @nickworonekin for creating
    [Puyo Text Editor](https://github.com/nickworonekin/puyo-text-editor).
-   @52871299hzy for contributing information about the `fmp` format.
