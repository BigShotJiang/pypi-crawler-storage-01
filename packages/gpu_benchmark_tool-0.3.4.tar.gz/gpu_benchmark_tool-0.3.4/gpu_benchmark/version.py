"""Version information for GPU Benchmark Tool.

Attributes:
    __version__ (str): The current version of the GPU Benchmark Tool.
"""

__version__ = "0.3.4"
