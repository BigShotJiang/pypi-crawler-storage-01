ESTAT_ENDPOINTS = {
    "base_url": "https://api.e-stat.go.jp/rest/3.0/app/json/",
    "stats_data": "getStatsData",
    "stats_list": "getStatsList",
    "meta_info": "getMetaInfo",
    "data_catalog": "getDataCatalog",
}
