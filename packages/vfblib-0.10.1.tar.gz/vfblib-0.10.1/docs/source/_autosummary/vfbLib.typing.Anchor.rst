vfbLib.typing.Anchor
====================

.. currentmodule:: vfbLib.typing

.. autoclass:: Anchor
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Anchor.__init__
      ~Anchor.clear
      ~Anchor.copy
      ~Anchor.fromkeys
      ~Anchor.get
      ~Anchor.items
      ~Anchor.keys
      ~Anchor.pop
      ~Anchor.popitem
      ~Anchor.setdefault
      ~Anchor.update
      ~Anchor.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Anchor.name
      ~Anchor.x
      ~Anchor.x1
      ~Anchor.y
      ~Anchor.y1
   
   