﻿vfbLib.tth
==========

.. automodule:: vfbLib.tth
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      extract_glyph_hints
      extract_truetype_hinting
      extract_tt_stem_ppem_1
      extract_tt_stem_ppems
      extract_tt_stems
      extract_tt_zone_deltas
      extract_tt_zones
      merge_stem_information
      merge_zone_information
      vfb2tth
   
   

   
   
   

   
   
   



