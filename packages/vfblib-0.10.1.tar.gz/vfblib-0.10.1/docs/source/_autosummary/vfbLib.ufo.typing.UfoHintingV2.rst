vfbLib.ufo.typing.UfoHintingV2
==============================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: UfoHintingV2
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UfoHintingV2.__init__
      ~UfoHintingV2.clear
      ~UfoHintingV2.copy
      ~UfoHintingV2.fromkeys
      ~UfoHintingV2.get
      ~UfoHintingV2.items
      ~UfoHintingV2.keys
      ~UfoHintingV2.pop
      ~UfoHintingV2.popitem
      ~UfoHintingV2.setdefault
      ~UfoHintingV2.update
      ~UfoHintingV2.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UfoHintingV2.flexList
      ~UfoHintingV2.hintSetList
      ~UfoHintingV2.id
   
   