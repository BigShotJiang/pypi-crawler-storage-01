vfbLib.parsers.value.read\_floats
=================================

.. currentmodule:: vfbLib.parsers.value

.. autofunction:: read_floats