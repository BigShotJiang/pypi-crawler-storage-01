vfbLib.typing.HintDict
======================

.. currentmodule:: vfbLib.typing

.. autoclass:: HintDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~HintDict.__init__
      ~HintDict.clear
      ~HintDict.copy
      ~HintDict.fromkeys
      ~HintDict.get
      ~HintDict.items
      ~HintDict.keys
      ~HintDict.pop
      ~HintDict.popitem
      ~HintDict.setdefault
      ~HintDict.update
      ~HintDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~HintDict.h
      ~HintDict.v
      ~HintDict.hintmasks
   
   