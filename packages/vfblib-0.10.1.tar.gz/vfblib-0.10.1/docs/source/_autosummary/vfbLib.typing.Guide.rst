vfbLib.typing.Guide
===================

.. currentmodule:: vfbLib.typing

.. autoclass:: Guide
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Guide.__init__
      ~Guide.clear
      ~Guide.copy
      ~Guide.fromkeys
      ~Guide.get
      ~Guide.items
      ~Guide.keys
      ~Guide.pop
      ~Guide.popitem
      ~Guide.setdefault
      ~Guide.update
      ~Guide.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Guide.angle
      ~Guide.pos
   
   