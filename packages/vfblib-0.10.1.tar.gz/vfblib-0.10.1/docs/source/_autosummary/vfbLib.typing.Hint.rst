vfbLib.typing.Hint
==================

.. currentmodule:: vfbLib.typing

.. autoclass:: Hint
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Hint.__init__
      ~Hint.clear
      ~Hint.copy
      ~Hint.fromkeys
      ~Hint.get
      ~Hint.items
      ~Hint.keys
      ~Hint.pop
      ~Hint.popitem
      ~Hint.setdefault
      ~Hint.update
      ~Hint.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Hint.pos
      ~Hint.width
   
   