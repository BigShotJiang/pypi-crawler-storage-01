vfbLib.tth.extract\_tt\_stem\_ppem\_1
=====================================

.. currentmodule:: vfbLib.tth

.. autofunction:: extract_tt_stem_ppem_1