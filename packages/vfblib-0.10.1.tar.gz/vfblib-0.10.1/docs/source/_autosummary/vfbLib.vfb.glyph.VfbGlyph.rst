vfbLib.vfb.glyph.VfbGlyph
=========================

.. currentmodule:: vfbLib.vfb.glyph

.. autoclass:: VfbGlyph
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbGlyph.__init__
      ~VfbGlyph.clearContours
      ~VfbGlyph.decompile
      ~VfbGlyph.draw
      ~VfbGlyph.drawPoints
      ~VfbGlyph.empty
      ~VfbGlyph.getPen
      ~VfbGlyph.getPointPen
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbGlyph.name
   
   