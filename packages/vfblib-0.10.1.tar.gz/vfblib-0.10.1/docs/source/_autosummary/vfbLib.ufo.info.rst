vfbLib.ufo.info
===============

.. automodule:: vfbLib.ufo.info
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      VfbToUfoInfo
   
   

   
   
   



