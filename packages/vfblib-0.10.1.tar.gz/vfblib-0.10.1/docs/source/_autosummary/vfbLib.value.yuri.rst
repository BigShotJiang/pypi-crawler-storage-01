vfbLib.value.yuri
=================

.. currentmodule:: vfbLib.value

.. autofunction:: yuri