vfbLib.vfb.pens.VfbGlyphPointPen
================================

.. currentmodule:: vfbLib.vfb.pens

.. autoclass:: VfbGlyphPointPen
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbGlyphPointPen.__init__
      ~VfbGlyphPointPen.addComponent
      ~VfbGlyphPointPen.addPoint
      ~VfbGlyphPointPen.addVarComponent
      ~VfbGlyphPointPen.beginPath
      ~VfbGlyphPointPen.endPath
   
   

   
   
   