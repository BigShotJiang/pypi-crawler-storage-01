vfbLib.parsers.value.read\_doubles
==================================

.. currentmodule:: vfbLib.parsers.value

.. autofunction:: read_doubles