vfbLib.ufo.kerning.UfoKerning
=============================

.. currentmodule:: vfbLib.ufo.kerning

.. autoclass:: UfoKerning
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UfoKerning.__init__
      ~UfoKerning.get_master_kerning
   
   

   
   
   