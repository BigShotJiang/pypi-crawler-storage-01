vfbLib.vfb.vfb.Vfb
==================

.. currentmodule:: vfbLib.vfb.vfb

.. autoclass:: Vfb
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Vfb.__init__
      ~Vfb.add_entry
      ~Vfb.as_dict
      ~Vfb.clear
      ~Vfb.decompile
      ~Vfb.getGlyphMaster
      ~Vfb.get_masters
      ~Vfb.items
      ~Vfb.keys
      ~Vfb.read
      ~Vfb.read_stream
      ~Vfb.write
   
   

   
   
   