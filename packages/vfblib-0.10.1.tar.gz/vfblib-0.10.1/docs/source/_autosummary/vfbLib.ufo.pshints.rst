vfbLib.ufo.pshints
==================

.. automodule:: vfbLib.ufo.pshints
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      build_ps_glyph_hints
      get_master_hints
      normalize_hint
      normalize_hint_dict
      update_adobe_hinting
   
   

   
   
   

   
   
   



