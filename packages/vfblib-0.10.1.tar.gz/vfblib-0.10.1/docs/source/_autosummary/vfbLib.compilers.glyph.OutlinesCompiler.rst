vfbLib.compilers.glyph.OutlinesCompiler
=======================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: OutlinesCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OutlinesCompiler.__init__
      ~OutlinesCompiler.compile
      ~OutlinesCompiler.write_bytes
      ~OutlinesCompiler.write_double
      ~OutlinesCompiler.write_doubles
      ~OutlinesCompiler.write_float
      ~OutlinesCompiler.write_floats
      ~OutlinesCompiler.write_int16
      ~OutlinesCompiler.write_int32
      ~OutlinesCompiler.write_str
      ~OutlinesCompiler.write_uint16
      ~OutlinesCompiler.write_uint32
      ~OutlinesCompiler.write_uint8
      ~OutlinesCompiler.write_value
   
   

   
   
   