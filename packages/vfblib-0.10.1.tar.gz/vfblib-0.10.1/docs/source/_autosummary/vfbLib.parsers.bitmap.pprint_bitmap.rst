vfbLib.parsers.bitmap.pprint\_bitmap
====================================

.. currentmodule:: vfbLib.parsers.bitmap

.. autofunction:: pprint_bitmap