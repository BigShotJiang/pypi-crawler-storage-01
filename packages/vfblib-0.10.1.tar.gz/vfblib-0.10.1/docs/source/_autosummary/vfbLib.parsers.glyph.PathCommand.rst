vfbLib.parsers.glyph.PathCommand
================================

.. currentmodule:: vfbLib.parsers.glyph

.. autoclass:: PathCommand
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PathCommand.move
      ~PathCommand.line
      ~PathCommand.curve
      ~PathCommand.qcurve
   
   