vfbLib.typing.MMAnchor
======================

.. currentmodule:: vfbLib.typing

.. autoclass:: MMAnchor
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MMAnchor.__init__
      ~MMAnchor.clear
      ~MMAnchor.copy
      ~MMAnchor.fromkeys
      ~MMAnchor.get
      ~MMAnchor.items
      ~MMAnchor.keys
      ~MMAnchor.pop
      ~MMAnchor.popitem
      ~MMAnchor.setdefault
      ~MMAnchor.update
      ~MMAnchor.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MMAnchor.x
      ~MMAnchor.y
   
   