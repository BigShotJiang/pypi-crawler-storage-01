vfbLib.ufo.typing.UfoGuide
==========================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: UfoGuide
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UfoGuide.__init__
      ~UfoGuide.clear
      ~UfoGuide.copy
      ~UfoGuide.fromkeys
      ~UfoGuide.get
      ~UfoGuide.items
      ~UfoGuide.keys
      ~UfoGuide.pop
      ~UfoGuide.popitem
      ~UfoGuide.setdefault
      ~UfoGuide.update
      ~UfoGuide.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UfoGuide.angle
      ~UfoGuide.color
      ~UfoGuide.name
      ~UfoGuide.x
      ~UfoGuide.y
   
   