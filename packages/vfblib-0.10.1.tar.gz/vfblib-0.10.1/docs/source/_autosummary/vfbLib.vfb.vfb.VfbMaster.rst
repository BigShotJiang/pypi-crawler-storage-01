vfbLib.vfb.vfb.VfbMaster
========================

.. currentmodule:: vfbLib.vfb.vfb

.. autoclass:: VfbMaster
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbMaster.__init__
      ~VfbMaster.items
      ~VfbMaster.keys
      ~VfbMaster.num_masters
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbMaster.info
   
   