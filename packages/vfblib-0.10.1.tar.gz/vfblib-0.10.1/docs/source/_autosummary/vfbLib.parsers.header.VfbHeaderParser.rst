vfbLib.parsers.header.VfbHeaderParser
=====================================

.. currentmodule:: vfbLib.parsers.header

.. autoclass:: VfbHeaderParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbHeaderParser.__init__
      ~VfbHeaderParser.parse
      ~VfbHeaderParser.read_double
      ~VfbHeaderParser.read_doubles
      ~VfbHeaderParser.read_float
      ~VfbHeaderParser.read_floats
      ~VfbHeaderParser.read_int16
      ~VfbHeaderParser.read_int32
      ~VfbHeaderParser.read_int8
      ~VfbHeaderParser.read_str
      ~VfbHeaderParser.read_str_all
      ~VfbHeaderParser.read_uint16
      ~VfbHeaderParser.read_uint32
      ~VfbHeaderParser.read_uint8
      ~VfbHeaderParser.read_value
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbHeaderParser.encoding
      ~VfbHeaderParser.stream
   
   