vfbLib.typing.GuideProperty
===========================

.. currentmodule:: vfbLib.typing

.. autoclass:: GuideProperty
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GuideProperty.__init__
      ~GuideProperty.clear
      ~GuideProperty.copy
      ~GuideProperty.fromkeys
      ~GuideProperty.get
      ~GuideProperty.items
      ~GuideProperty.keys
      ~GuideProperty.pop
      ~GuideProperty.popitem
      ~GuideProperty.setdefault
      ~GuideProperty.update
      ~GuideProperty.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GuideProperty.color
      ~GuideProperty.index
      ~GuideProperty.name
   
   