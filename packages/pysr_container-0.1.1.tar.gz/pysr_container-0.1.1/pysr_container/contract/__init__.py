from .definition import DefinitionInterface
