# dagster-sigma

Experimental package for integrating with [Sigma](https://sigmacomputing.com).
