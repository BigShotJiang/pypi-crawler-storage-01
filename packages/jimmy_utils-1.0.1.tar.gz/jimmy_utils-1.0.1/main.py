def main():
    print("Hello from jimmy-utils!")


if __name__ == "__main__":
    main()
