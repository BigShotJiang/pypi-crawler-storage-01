===============================================
Identification of Trust (Peewee Database Layer)
===============================================

This contains a database layer for implementations of the
Identification of Trust microsite. It should not depend upon a specific
framework, and it does not implement a website on its own.
