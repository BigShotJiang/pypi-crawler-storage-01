import setuptools

setuptools.setup(
    name="odoo_addon_energy_communities_service_invoicing",
    setup_requires=['setuptools-odoo'],
    odoo_addon=True,
)
