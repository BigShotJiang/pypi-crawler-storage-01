from .pypi_mcp_test import mcp

def main() -> None:
    mcp.run()