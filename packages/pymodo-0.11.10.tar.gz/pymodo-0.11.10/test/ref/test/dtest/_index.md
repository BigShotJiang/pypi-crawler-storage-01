Mojo module [🡭](https://github.com/mlange-42/modo/blob/main/test/src/doctest.mojo)

# `dtest`

Package doctests tests doctests



```mojo {doctest="test"}
var c = add(a, b)
```


## Aliases

- `ModuleAlias2 = Int`

## Structs

- [`Struct`](Struct-.md)

