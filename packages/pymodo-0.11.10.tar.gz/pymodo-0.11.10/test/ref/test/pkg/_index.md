Mojo package [🡭](https://github.com/mlange-42/modo/blob/main/test/src/pkg/__init__.mojo)

# `pkg`

Package pkg.

## Modules

- [`submod`](submod/_index.md)

