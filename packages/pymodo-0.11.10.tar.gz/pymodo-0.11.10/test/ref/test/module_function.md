Mojo function [🡭](https://github.com/mlange-42/modo/blob/main/test/src/mod.mojo)

# `module_function`

```mojo
fn module_function[FunctionParameter: Intable](arg: Int) -> Int
```

[`ModAlias`](_index.md#aliases).

[`RenamedStruct.struct_method`](RenamedStruct-.md#struct_method)

**Parameters:**

- **FunctionParameter** (`Intable`): [`RenamedStruct.struct_method`](RenamedStruct-.md#struct_method).

**Args:**

- **arg** (`Int`): [`RenamedStruct.struct_method`](RenamedStruct-.md#struct_method).

**Returns:**

`Int`: Bla [`RenamedStruct.struct_method`](RenamedStruct-.md#struct_method).

**Raises:**

Error [`RenamedStruct.struct_method`](RenamedStruct-.md#struct_method).

