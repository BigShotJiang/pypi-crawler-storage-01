// Package modo provides a documentation generator (DocGen) for the Mojo programming language.
//
// ⚠️ Warning: Modo is primarily a command line tool, and the Go package is provided without any warranty or support.
// Semantic versioning refers to the binaries, so breaking changes to the package can happen at any time.
package main
