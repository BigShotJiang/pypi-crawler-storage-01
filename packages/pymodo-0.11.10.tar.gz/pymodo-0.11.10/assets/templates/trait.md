Mojo trait{{template "source_link" .}}

# `{{.Name}}`

{{template "summary" . -}}
{{template "description" . -}}
{{template "aliases" . -}}
{{template "fields" . -}}
{{template "parent_traits" . -}}
{{template "methods" . -}}