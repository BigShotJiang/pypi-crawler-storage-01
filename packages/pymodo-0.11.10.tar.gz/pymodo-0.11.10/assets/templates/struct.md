Mojo struct{{template "source_link" .}}

# `{{.Name}}`

{{template "signature_struct" .}}

{{template "summary" . -}}
{{template "description" . -}}
{{template "aliases" . -}}
{{template "parameters" . -}}
{{template "fields" . -}}
{{template "parent_traits" . -}}
{{template "methods" . -}}