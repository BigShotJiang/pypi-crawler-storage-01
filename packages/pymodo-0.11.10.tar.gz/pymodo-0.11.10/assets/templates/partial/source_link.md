{{define "source_link" -}}
{{if sourceUrl}} [🡭]({{sourceUrl}}/{{.Link}})
{{- end}}{{end}}