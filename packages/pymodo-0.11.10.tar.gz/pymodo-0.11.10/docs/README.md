# Modo🧯 documentation

The Modo🧯 [user guide](https://mlange-42.github.io/modo/) is created with Modo🧯 and Hugo.
The sources of the guide serve as a complete example for this use case.
Therefore, this directory contains a simple Mojo🔥 example package,
documented with Modo🧯.
For the Markdown sources of the user guide, see sub-directory [docs/src](docs/src/).

Build and serve the docs like this:

```shell
modo build
hugo serve docs/site/
```
