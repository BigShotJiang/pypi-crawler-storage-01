from httpx import Request as Request
from httpx import Response as Response
from httpx import Timeout as Timeout
from httpx import delete as delete
from httpx import get as get
from httpx import post as post
from httpx import put as put

GET = "GET"
DELETE = "DELETE"
POST = "POST"
PUT = "PUT"
