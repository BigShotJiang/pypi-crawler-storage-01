"""Main entry point for cursor-mcp-manager."""

from cursor_mcp_manager.server import main

if __name__ == "__main__":
    main()
