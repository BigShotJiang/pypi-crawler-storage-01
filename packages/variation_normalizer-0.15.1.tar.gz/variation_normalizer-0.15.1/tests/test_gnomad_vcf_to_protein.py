"""Module for testing gnomad_vcf_to_protein works correctly"""

import pytest
from ga4gh.vrs import models

from tests.conftest import assertion_checks
from variation.schemas.service_schema import ClinVarAssembly


@pytest.fixture(scope="module")
def test_handler(test_query_handler):
    """Create test fixture for gnomad vcf to protein handler"""
    return test_query_handler.gnomad_vcf_to_protein_handler


@pytest.fixture(scope="module")
def mmel1_l30m():
    """Create test fixture for MMEL1 L30M"""
    params = {
        "location": {
            "end": 30,
            "start": 29,
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.iQ8F_pnsiQOLohiV2qh3OWRZiftUt8jZ",
            },
            "sequence": "L",
            "type": "SequenceLocation",
        },
        "state": {"sequence": "M", "type": "LiteralSequenceExpression"},
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def cdk11a_e314del():
    """Create test fixture for CDK11A Glu314del"""
    params = {
        "location": {
            "end": 321,
            "start": 308,
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.N728VSRRMHJ1SrhJgKqJOCaa3l5Z4sqm",
            },
            "sequence": "EEEEEEEEEEEEE",
            "type": "SequenceLocation",
        },
        "state": {
            "length": 12,
            "repeatSubunitLength": 1,
            "sequence": "EEEEEEEEEEEE",
            "type": "ReferenceLengthExpression",
        },
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def protein_insertion2():
    """Create test fixture for LRP8 p.Gln25_Leu26insArg (CA860540)"""
    params = {
        "location": {
            "end": 25,
            "start": 25,
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.qgIh8--4F6IpxRwX_lVtD2BhepH5B5Ef",
            },
            "type": "SequenceLocation",
        },
        "state": {"sequence": "R", "type": "LiteralSequenceExpression"},
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def atad3a_loc():
    """Create test fixture for ATAD3A location"""
    return {
        "end": 7,
        "start": 6,
        "sequenceReference": {
            "type": "SequenceReference",
            "refgetAccession": "SQ.MHPOY_7fv8V9SktyvaTxulVFSK6XCxM8",
        },
        "sequence": "I",
        "type": "SequenceLocation",
    }


@pytest.fixture(scope="module")
def atad3a_i7v(atad3a_loc):
    """Create test fixture for ATAD3A Ile7Val"""
    params = {
        "location": atad3a_loc,
        "state": {"sequence": "V", "type": "LiteralSequenceExpression"},
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def atad3a_i7t(atad3a_loc):
    """Create test fixture for ATAD3A Ile7Thr"""
    params = {
        "location": atad3a_loc,
        "state": {"sequence": "T", "type": "LiteralSequenceExpression"},
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def atad3a_i7m(atad3a_loc):
    """Create test fixture for ATAD3A Ile7Met"""
    params = {
        "location": atad3a_loc,
        "state": {"sequence": "M", "type": "LiteralSequenceExpression"},
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def braf_v600l(braf_600loc):
    """Create test fixture for BRAF Val600Leu."""
    params = {
        "location": braf_600loc,
        "state": {"sequence": "L", "type": "LiteralSequenceExpression"},
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def braf_600_reference_agree(braf_600loc):
    """Create test fixture for BRAF Val600=."""
    params = {
        "location": braf_600loc,
        "state": {"sequence": "V", "type": "LiteralSequenceExpression"},
        "type": "Allele",
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def kras_g12d():
    """Fixture for KRAS G12D"""
    params = {
        "type": "Allele",
        "location": {
            "type": "SequenceLocation",
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.fytWhQSNGnA-86vDiQCxTSzgkk_WfQRS",
            },
            "start": 11,
            "end": 12,
            "sequence": "G",
        },
        "state": {"type": "LiteralSequenceExpression", "sequence": "D"},
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def multi_nuc_sub_pos():
    """Create test fixture for the protein consequence of a multinucleotide substitution on the
    positive strand (CA16042245)
    """
    params = {
        "type": "Allele",
        "location": {
            "type": "SequenceLocation",
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.HtNf7YrmmFih3cwRwYMlylPFMAs7-l9B",
            },
            "start": 242,
            "end": 244,
            "sequence": "LP",
        },
        "state": {"type": "LiteralSequenceExpression", "sequence": "PS"},
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def multi_nuc_sub_neg():
    """Create test fixture for the protein consequence of a multinucleotide substitution on the
    negative strand (CA1139661942)
    """
    params = {
        "type": "Allele",
        "location": {
            "type": "SequenceLocation",
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.bg8P_l39rOUQVLwsW3Dme-946Od8-3rB",
            },
            "start": 235,
            "end": 236,
            "sequence": "S",
        },
        "state": {"type": "LiteralSequenceExpression", "sequence": "G"},
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def delins_pos():
    """Create test fixture for the protein consequence of a delins on positive strand (CA645561524)"""
    params = {
        "type": "Allele",
        "location": {
            "type": "SequenceLocation",
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.vyo55F6mA6n2LgN4cagcdRzOuh38V4mE",
            },
            "start": 746,
            "end": 752,
            "sequence": "LREATS",
        },
        "state": {"type": "LiteralSequenceExpression", "sequence": "Q"},
    }
    return models.Allele(**params)


@pytest.fixture(scope="module")
def delins_neg():
    """Create test fixture for the protein consequence of a delins on negative strand (ClinVar ID 1217291)"""
    params = {
        "type": "Allele",
        "location": {
            "type": "SequenceLocation",
            "sequenceReference": {
                "type": "SequenceReference",
                "refgetAccession": "SQ.aDZLb9cs0cYskMKDIK-AXhaevHRA86JS",
            },
            "start": 239,
            "end": 259,
            "sequence": "PRLLFPTNSSSHLVALQGQP",
        },
        "state": {"type": "LiteralSequenceExpression", "sequence": "TLTA"},
    }
    return models.Allele(**params)


@pytest.mark.asyncio
async def test_substitution(
    test_handler,
    braf_v600e,
    braf_v600l,
    braf_600_reference_agree,
    mmel1_l30m,
    atad3a_i7v,
    atad3a_i7t,
    atad3a_i7m,
    kras_g12d,
    multi_nuc_sub_pos,
    multi_nuc_sub_neg,
):
    """Test that substitution queries return correct response"""
    # Reading Frame 1, Negative Strand
    resp = await test_handler.gnomad_vcf_to_protein("7-140753337-C-A")
    assertion_checks(resp, braf_v600l)
    assert resp.warnings == []

    # Reading Frame 2, Negative Strand
    resp = await test_handler.gnomad_vcf_to_protein("7-140753336-A-T")
    assertion_checks(resp, braf_v600e, check_vrs_id=True)
    assert resp.gene_context
    assert resp.warnings == []

    # Reading Frame 3, Negative Strand
    resp = await test_handler.gnomad_vcf_to_protein("7-140753335-C-A")
    assertion_checks(resp, braf_600_reference_agree)
    assert resp.warnings == []

    # Reading Frame 3, Negative Strand
    resp = await test_handler.gnomad_vcf_to_protein("1-2629397-G-T")
    assertion_checks(resp, mmel1_l30m)
    assert resp.warnings == []

    # Reading Frame 1, Positive Strand
    resp = await test_handler.gnomad_vcf_to_protein("1-1512287-A-G")
    assertion_checks(resp, atad3a_i7v)
    assert resp.warnings == []

    # Reading Frame 2, Positive Strand
    resp = await test_handler.gnomad_vcf_to_protein("1-1512288-T-C")
    assertion_checks(resp, atad3a_i7t)
    assert resp.warnings == []

    # Reading Frame 3, Positive Strand
    resp = await test_handler.gnomad_vcf_to_protein("1-1512289-T-G")
    assertion_checks(resp, atad3a_i7m)
    assert resp.warnings == []

    resp = await test_handler.gnomad_vcf_to_protein("12-25245350-C-T")
    assertion_checks(resp, kras_g12d)

    # multi nucleotide ref/alt on positive strand (CA16042245)
    resp = await test_handler.gnomad_vcf_to_protein("2-74530927-TGC-CAT")
    assertion_checks(resp, multi_nuc_sub_pos)

    # multi nucleotide ref/alt on negative strand (CA1139661942)
    resp = await test_handler.gnomad_vcf_to_protein("11-47348490-TG-CA")
    assertion_checks(resp, multi_nuc_sub_neg)


@pytest.mark.asyncio
async def test_reference_agree(test_handler, vhl_reference_agree):
    """Test that reference agree queries return correct response"""
    # https://www.ncbi.nlm.nih.gov/clinvar/variation/379039/?new_evidence=true
    resp = await test_handler.gnomad_vcf_to_protein("3-10142030-C-T")
    assertion_checks(resp, vhl_reference_agree)
    assert resp.gene_context
    assert resp.warnings == []


@pytest.mark.asyncio
async def test_insertion(test_handler, protein_insertion, protein_insertion2):
    """Test that insertion queries return correct response"""
    # positive strand (CA645561585)
    resp = await test_handler.gnomad_vcf_to_protein("7-55181319-C-CGGGTTA")
    assertion_checks(resp, protein_insertion)
    assert resp.variation.location.sequence is None
    assert resp.gene_context
    assert resp.warnings == []

    # negative strand (CA860540)
    resp = await test_handler.gnomad_vcf_to_protein("1-53327836-A-AGCC")
    assertion_checks(resp, protein_insertion2)
    assert resp.variation.location.sequence is None
    assert resp.gene_context
    assert resp.warnings == []


@pytest.mark.asyncio
async def test_deletion(test_handler, protein_deletion_np_range, cdk11a_e314del):
    """Test that deletion queries return correct response"""
    resp = await test_handler.gnomad_vcf_to_protein("17-39723966-TTGAGGGAAAACACAT-T")
    assertion_checks(resp, protein_deletion_np_range)
    assert resp.gene_context
    assert resp.warnings == []

    resp = await test_handler.gnomad_vcf_to_protein("1-1708855-TTCC-T")
    assertion_checks(resp, cdk11a_e314del)
    assert resp.gene_context
    assert resp.warnings == []


@pytest.mark.asyncio
async def test_delins(test_handler, delins_pos, delins_neg):
    """Test that delins queries return correct response"""
    # CA645561524, Positive Strand
    resp = await test_handler.gnomad_vcf_to_protein("7-55174776-TTAAGAGAAGCAACATCT-CAA")
    assertion_checks(resp, delins_pos)
    assert resp.gene_context

    # ClinVar ID 1217291, Negative Strand
    resp = await test_handler.gnomad_vcf_to_protein(
        "X-153870419-GCTGCCCCTGCAAGGCCACCAGGTGGCTGCTGGAGTTGGTGGGGAAGAGCAGGCGCGG-CTGTCAATGT"
    )
    assertion_checks(resp, delins_neg)
    assert resp.gene_context

    # CA16602420. Example where protein gene not found, but cDNA gene found
    resp = await test_handler.gnomad_vcf_to_protein("7-140453136-AC-TT")
    assert resp.variation
    assert resp.gene_context
    assert resp.warnings == []


@pytest.mark.asyncio
async def test_input_assembly(test_handler):
    """Test that input assembly works correctly (issue #625)"""
    resp = await test_handler.gnomad_vcf_to_protein(
        "1-35227334-G-A", input_assembly=ClinVarAssembly.GRCH37
    )
    assert resp.variation
    assert resp.gene_context
    assert resp.gene_context.name == "GJB4"


@pytest.mark.asyncio
async def test_invalid(test_handler):
    """Test that invalid queries return correct response"""
    resp = await test_handler.gnomad_vcf_to_protein("BRAF V600E")
    assert resp.variation is None
    assert resp.gene_context is None
    assert resp.warnings == [
        "BRAF V600E is not a gnomAD VCF-like query (`chr-pos-ref-alt`)"
    ]

    resp = await test_handler.gnomad_vcf_to_protein("7-140753336-T-G")
    assert resp.variation is None
    assert resp.gene_context is None
    assert set(resp.warnings) == {"Unable to get cDNA and protein representation"}

    resp = await test_handler.gnomad_vcf_to_protein("20-2-TC-TG")
    assert resp.variation is None
    assert resp.gene_context is None
    assert resp.warnings == ["20-2-TC-TG is not a valid gnomad vcf query"]
