# Un projecte de Girotec

Gestiona la API de Girotec amb aquest paquet d'èines.
Parla amb el distribuïdor del software ManPro per obtenir les credencials.
