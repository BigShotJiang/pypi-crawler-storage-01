from llama_index.readers.wikipedia.base import WikipediaReader

__all__ = ["WikipediaReader"]
