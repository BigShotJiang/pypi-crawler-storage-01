print("I am script 3")
