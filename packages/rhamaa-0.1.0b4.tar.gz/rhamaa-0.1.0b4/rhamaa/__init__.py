"""
RhamaaCLI - A powerful CLI tool to accelerate Wagtail web development
"""

__version__ = "0.1.0"