# Prihops

Prihops kütüphanesi Google drive den veri çekme ve ekleme olanagı sunarak veri saklamayı daha basit bir hâle getirir 

## Kullanım

- info() tarminale kütüphanenin versiyonunu verir
- Control() drive dosyasındaki metin veya başlığı kontrol eder
- delete() drive dosyasındaki metin veya başlığı siler
- get() drive dosyasındaki metin veya başlığı çeker
- give() drive dosyasına metin veya başlık ekler

### Telif Hakkı 

Prihops kütüphanesi ile yapılan herhangi bir uygulamada kütüphanenin herhangi bir işlevine üçretlendirme uygulanamaz
