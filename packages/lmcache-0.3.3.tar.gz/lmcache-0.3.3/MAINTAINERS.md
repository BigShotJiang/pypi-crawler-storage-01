# Maintainers List

Following is the current list of maintainers on this project

- @yihua98@uchicago.edu, Yihua Cheng, UChicago, Committer
- @jiayi3@uchicago.edu, Jiayi Yao, UChicago, Committer
- @kuntai@uchicago.edu, Kuntai Du, UChicago, Committer
- @sixian@uchicago.edu, Sixian Xiong, UChicago/Peking University, Committer
