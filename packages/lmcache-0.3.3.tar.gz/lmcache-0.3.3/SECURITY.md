# Security Policy

## Supported Versions

If you believe you have found a security vulnerability in LMCache, please let us know right away. We will investigate all vulnerability reports and do our best to quickly fix the problem.

## Reporting a Vulnerability

For now, please email details of the vulnerability to lmcacheteam@gmail.com. Please try to include some detailed examples, screenshots etc. or anything you feel which may help identify the problem fast.
