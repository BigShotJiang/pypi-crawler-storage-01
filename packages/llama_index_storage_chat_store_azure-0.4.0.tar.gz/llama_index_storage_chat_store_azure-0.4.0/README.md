# LlamaIndex Chat_Store Integration: Azure Chat Store
