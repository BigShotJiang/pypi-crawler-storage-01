from django.apps import AppConfig


class GitlabReleasesConfig(AppConfig):
    name = "gitlab_releases"
    verbose_name = "GitLab Releases"
