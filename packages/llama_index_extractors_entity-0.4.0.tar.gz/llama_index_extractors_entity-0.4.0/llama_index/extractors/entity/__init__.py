from llama_index.extractors.entity.base import EntityExtractor

__all__ = ["EntityExtractor"]
