# Copyright (c) Saga Inc.
# Distributed under the terms of the GNU Affero General Public License v3.0 License.

from mito_ai.db.crawlers.snowflake import crawl_snowflake

__all__ = ["crawl_snowflake"]
