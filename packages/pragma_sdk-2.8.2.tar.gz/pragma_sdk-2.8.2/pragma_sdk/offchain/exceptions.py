from pragma_sdk.common.exceptions import BasePragmaException


class PragmaAPIError(BasePragmaException): ...
