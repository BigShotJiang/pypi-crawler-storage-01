from pyspark.sql import SparkSession


def test_mock_member_claims(spark_session: SparkSession) -> None:
    pass
