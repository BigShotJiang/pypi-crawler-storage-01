from ._pyfastmath import gcd, is_prime, mod_exp, lcm, factorial, ncr, npr

__all__ = ['gcd', 'is_prime', 'mod_exp', 'lcm', 'factorial', 'ncr', 'npr']
