"""
AppGen - Modern Project Generator for Web Development
A modular, clean architecture for project generation.
"""
 
__version__ = "1.0.0"
__author__ = "AppGen Team" 