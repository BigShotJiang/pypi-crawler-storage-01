export default function Page() {
  return (
    <main style={{ padding: 40, fontFamily: "sans-serif" }}>
      <h1>Welcome to Next.js App Router (TypeScript)!</h1>
      <p>
        This is your starter page in the <code>app/</code> directory using
        TypeScript.
      </p>
    </main>
  );
}
