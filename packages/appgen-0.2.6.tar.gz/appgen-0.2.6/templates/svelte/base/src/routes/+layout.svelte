<script>
	import '../app.css';
</script>
 
<slot /> 