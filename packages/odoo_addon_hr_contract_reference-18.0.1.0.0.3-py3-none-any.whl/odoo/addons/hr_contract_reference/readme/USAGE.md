When you will create a new employee contract, the field reference will
be assigned automatically with the next number of the predefined
sequence.
