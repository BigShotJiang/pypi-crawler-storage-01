If you want to modify the format of the sequence, go to Settings -\>
Technical -\> Sequences & Identifiers -\> Sequences and search for the
"Contract Reference" sequence, where you modify its prefix and numbering
formats.
