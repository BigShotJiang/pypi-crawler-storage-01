# {{project_name}}

{{description}}

## Kurulum

```bash
pip install -r requirements.txt
```

## Kullanım

```bash
python main.py
```

## Yazar

{{author_name}}
