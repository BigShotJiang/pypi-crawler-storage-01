#!/usr/bin/env python3
# Test Python dosyası
print("Merhaba PyCloud OS!")
print("Bu dosya PyIDE ile açılmalı")

def test_function():
    """Test fonksiyonu"""
    return "PyCloud OS dosya açma testi başarılı!"

if __name__ == "__main__":
    print(test_function()) 