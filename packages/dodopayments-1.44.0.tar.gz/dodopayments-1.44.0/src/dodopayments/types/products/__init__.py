# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .image_update_params import ImageUpdateParams as ImageUpdateParams
from .image_update_response import ImageUpdateResponse as ImageUpdateResponse
