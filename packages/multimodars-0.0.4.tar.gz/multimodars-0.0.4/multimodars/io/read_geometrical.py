import numpy as np
from stl import mesh
