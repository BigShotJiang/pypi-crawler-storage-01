.. multimodars documentation master file, created by
   sphinx-quickstart on Wed Jul 23 22:38:42 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to multimodars!
=======================

A Rust-powered cardiac multi-image modality fusion package.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`