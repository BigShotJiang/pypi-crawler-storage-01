
This module allows configuring the recurrence of tasks created from sales orders directly in the product form.