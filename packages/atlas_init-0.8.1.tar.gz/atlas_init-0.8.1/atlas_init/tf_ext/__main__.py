from atlas_init.tf_ext.typer_app import typer_main

typer_main()
