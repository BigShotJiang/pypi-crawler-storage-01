declare module '*.svg' {
  const value: string;
  export default value;
}
