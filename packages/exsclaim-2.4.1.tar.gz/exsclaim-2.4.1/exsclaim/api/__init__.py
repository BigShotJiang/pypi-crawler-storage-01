from .models import *
from .settings import Settings
from .__main__ import *

settings = Settings()
