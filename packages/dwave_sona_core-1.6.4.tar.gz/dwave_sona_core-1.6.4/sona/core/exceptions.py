class InferencerError(Exception):
    pass


class InferencerNeedRetry(InferencerError):
    pass
