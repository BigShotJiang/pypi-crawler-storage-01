# agentic_framework/tools.py
import asyncio
from abc import ABC, abstractmethod
from pydantic import BaseModel
from typing import Dict, Any

class ToolResult(BaseModel):
    success: bool
    output: str
    metadata: Dict[str, Any] = {}

class Tool(ABC):
    name: str

    @abstractmethod
    async def run(self, input_str: str, context: Dict[str, Any]) -> ToolResult:
        ...

class CalculatorTool(Tool):
    name = "calculator"

    async def run(self, input_str: str, context: Dict[str, Any]) -> ToolResult:
        try:
            # Simple and unsafe eval; replace with safe parser in prod
            result = eval(input_str, {"__builtins__": {}})
            return ToolResult(success=True, output=str(result), metadata={})
        except Exception as e:
            return ToolResult(success=False, output=str(e), metadata={})

class SearchTool(Tool):
    name = "search"

    async def run(self, input_str: str, context: Dict[str, Any]) -> ToolResult:
        # Placeholder: integrate real search (Bing, internal index)
        await asyncio.sleep(0.1)  # simulate latency
        fake_output = f"[Search stub] results for '{input_str}'"
        return ToolResult(success=True, output=fake_output, metadata={})
