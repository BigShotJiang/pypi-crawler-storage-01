# agentic_framework/memory.py
import asyncio
from abc import ABC, abstractmethod
from collections import deque
from typing import Dict, List, Optional

class Memory(ABC):
    @abstractmethod
    async def add(self, agent_id: str, entry: str) -> None:
        ...

    @abstractmethod
    async def retrieve(self, agent_id: str, query: Optional[str] = None) -> List[str]:
        ...

class FullHistoryMemory(Memory):
    def __init__(self):
        self.store: Dict[str, List[str]] = {}

    async def add(self, agent_id: str, entry: str) -> None:
        self.store.setdefault(agent_id, []).append(entry)

    async def retrieve(self, agent_id: str, query: Optional[str] = None) -> List[str]:
        return self.store.get(agent_id, []).copy()

class LastNMemory(Memory):
    def __init__(self, n: int = 10):
        self.n = n
        self.store: Dict[str, deque] = {}

    async def add(self, agent_id: str, entry: str) -> None:
        dq = self.store.setdefault(agent_id, deque(maxlen=self.n))
        dq.append(entry)

    async def retrieve(self, agent_id: str, query: Optional[str] = None) -> List[str]:
        return list(self.store.get(agent_id, deque()))

class CompositeMemory(Memory):
    def __init__(self, *memories: Memory):
        self.memories = memories

    async def add(self, agent_id: str, entry: str) -> None:
        await asyncio.gather(*(m.add(agent_id, entry) for m in self.memories))

    async def retrieve(self, agent_id: str, query: Optional[str] = None) -> List[str]:
        results = await asyncio.gather(*(m.retrieve(agent_id, query) for m in self.memories))
        seen = set()
        flattened = []
        for lst in results:
            for item in lst:
                if item not in seen:
                    seen.add(item)
                    flattened.append(item)
        return flattened
