import asyncio
from agentic_framework.llm import OpenAIStructuredWrapper
from agentic_framework.orchestrator import JobOrchestrator

async def main():
    role = "Data Scientist"  # Change to any job role you want
    llm = OpenAIStructuredWrapper(model="gpt-4o-2024-08-06", temperature=0.3)  # Create LLM wrapper instance
    orchestrator = JobOrchestrator(llm)  # Pass the LLM instance to orchestrator

    print(f"Generating skill curriculum for role: {role}")
    full_plan = await orchestrator.build_full_plan(role)

    # Pretty print the result
    import json
    print(json.dumps(full_plan, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
