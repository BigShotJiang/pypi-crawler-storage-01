import asyncio
import logging
from typing import Any, Dict, List, Optional
from .llm import StructuredLLMInterface
from .memory import Memory
from .schemas import (
    CategoriesResponse,
    SkillsByCategory,
    TopicsBySkill,
)
from agentic_framework.prompts import ROLE_DECOMPOSE_PROMPT, CATEGORY_TO_SKILLS_PROMPT, SKILL_TO_TOPICS_PROMPT

logger = logging.getLogger("agents")
logging.basicConfig(level=logging.INFO)

class RoleDecomposerAgent:
    def __init__(self, llm: StructuredLLMInterface):
        self.llm = llm

    async def decompose(self, role: str) -> List[str]:
        prompt = ROLE_DECOMPOSE_PROMPT.format(role=role)
        raw, parsed = await self.llm.call(prompt, response_format=CategoriesResponse, temperature=0.3, max_tokens=400)
        if not parsed:
            logger.error("Role decomposition parse failure: %s", raw)
            raise RuntimeError("Failed to decompose role.")
        return [c.category for c in parsed.categories]

class CategoryAgent:
    def __init__(self, llm: StructuredLLMInterface):
        self.llm = llm

    async def extract_skills(self, role: str, category: str) -> List[str]:
        prompt = CATEGORY_TO_SKILLS_PROMPT.format(role=role, category=category)
        raw, parsed = await self.llm.call(prompt, response_format=SkillsByCategory, temperature=0.4, max_tokens=500)
        if not parsed:
            logger.warning("Skill extraction failed for category %s: %s", category, raw)
            return []
        return [s.skill for s in parsed.skills]

class SkillAgent:
    def __init__(self, llm: StructuredLLMInterface):
        self.llm = llm

    async def extract_topics(self, role: str, skill: str) -> List[str]:
        prompt = SKILL_TO_TOPICS_PROMPT.format(role=role, skill=skill)
        raw, parsed = await self.llm.call(prompt, response_format=TopicsBySkill, temperature=0.5, max_tokens=400)
        if not parsed:
            logger.warning("Topic extraction failed for skill %s: %s", skill, raw)
            return []
        return [t.topic for t in parsed.topics]
