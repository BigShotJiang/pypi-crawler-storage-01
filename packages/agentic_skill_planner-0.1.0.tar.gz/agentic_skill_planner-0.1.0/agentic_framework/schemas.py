# agentic_framework/schemas.py
from pydantic import BaseModel
from typing import List, Dict, Any

class Category(BaseModel):
    category: str

class CategoriesResponse(BaseModel):
    categories: List[Category]

class Skill(BaseModel):
    skill: str

class SkillsByCategory(BaseModel):
    category: str
    skills: List[Skill]

class Topic(BaseModel):
    topic: str

class TopicsBySkill(BaseModel):
    skill: str
    topics: List[Topic]

class FullSkillPlan(BaseModel):
    role: str
    breakdown: List[Dict[str, Any]]  # category -> skills -> topics
