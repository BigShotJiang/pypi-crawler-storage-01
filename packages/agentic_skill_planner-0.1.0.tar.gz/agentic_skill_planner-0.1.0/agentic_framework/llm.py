# agentic_framework/llm.py
import os
import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Optional, Tuple, Any

from dotenv import load_dotenv

logger = logging.getLogger("llm")
logging.basicConfig(level=logging.INFO)

load_dotenv()


class StructuredLLMInterface(ABC):
    @abstractmethod
    async def call(
        self,
        prompt: str,
        **kwargs,
    ) -> Tuple[str, Optional[Any]]:
        """
        Returns: (raw_text_output, parsed_obj_or_None)
        """
        ...


class OpenAIStructuredWrapper(StructuredLLMInterface):
    def __init__(self, model: str = "gpt-40-mini", temperature: float = 0.7):
        try:
            from openai import OpenAI
        except ImportError:
            raise RuntimeError("openai library is required. pip install openai")

        self.client = OpenAI()
        self.model = model
        self.temperature = temperature
        self.api_key = os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("OPENAI_API_KEY not set; calls may fail.")

    async def call(
        self,
        prompt: str,
        response_format: Optional[Any] = None,  # Expected: Pydantic model class
        **kwargs,
    ) -> Tuple[str, Optional[Any]]:
        def sync_call():
            if response_format is None:
                raise ValueError("response_format must be provided for structured output")

            # Always use structured parse (responses.parse)
            return self.client.responses.parse(
                model=self.model,
                input=[{"role": "user", "content": prompt}],
                text_format=response_format,
                temperature=kwargs.get("temperature", self.temperature),
                max_output_tokens=kwargs.get("max_tokens", 1024),
            )

        loop = asyncio.get_running_loop()
        raw = await loop.run_in_executor(None, sync_call)

        # The structured response includes 'output' as raw text and 'output_parsed' as parsed Pydantic model
        output_text = getattr(raw, "output", str(raw))
        parsed_obj = getattr(raw, "output_parsed", None)

        return output_text, parsed_obj
