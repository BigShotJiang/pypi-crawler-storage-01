#prompts.py
# prompts.py
ROLE_DECOMPOSE_PROMPT = """
You are a system that decomposes a job role into its broad skill categories.

Job role: "{role}"

Output strictly as JSON matching this schema:
{{
  "categories": [
    {{ "category": "Programming Languages" }},
    {{ "category": "Databases" }},
    {{ "category": "Machine Learning" }},
    {{ "category": "Cloud Platforms" }},
    {{ "category": "Data Engineering" }}
  ]
}}

Include the top 5–8 high-level categories. No extra text.
"""

CATEGORY_TO_SKILLS_PROMPT = """
You are given a high-level skill category for the job role "{role}".
Category: "{category}"

List the core skills (short names) that belong under this category, in JSON matching this schema:

{{
  "category": "{category}",
  "skills": [
    {{ "skill": "ExampleSkill1" }},
    {{ "skill": "ExampleSkill2" }}
  ]
}}

Do not include explanatory prose; only the JSON.
"""

SKILL_TO_TOPICS_PROMPT = """
You are given a specific skill "{skill}" for the job role "{role}".
Generate 5–8 high-value subtopics or concepts someone should master under this skill, in JSON matching this schema:

{{
  "skill": "{skill}",
  "topics": [
    {{ "topic": "subtopic1" }},
    {{ "topic": "subtopic2" }}
  ]
}}

Respond strictly with the JSON.
"""
