# tests/test_integration.py
import pytest
import asyncio
import os
from agentic_framework.llm import OpenAIStructuredWrapper
from agentic_framework.orchestrator import JobOrchestrator

@pytest.mark.asyncio
async def test_real_end_to_end_plan():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        pytest.skip("OPENAI_API_KEY not set; skipping integration test.")

    llm = OpenAIStructuredWrapper(model="gpt-4", temperature=0.3)
    orchestrator = JobOrchestrator(llm)
    role = "Data Scientist"
    plan = await orchestrator.build_full_plan(role)
    assert plan["role"] == role
    assert "breakdown" in plan
    assert isinstance(plan["breakdown"], list)
    # At least one category should be present
    assert len(plan["breakdown"]) > 0
    # Validate structure minimally
    for cat in plan["breakdown"]:
        assert "category" in cat
        assert "skills" in cat
        for skill in cat["skills"]:
            assert "skill" in skill
            assert "topics" in skill
