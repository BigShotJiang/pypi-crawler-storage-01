# tests/test_tools.py
import pytest
import asyncio
from agentic_framework.tools import CalculatorTool, SearchTool

@pytest.mark.asyncio
async def test_calculator_success():
    calc = CalculatorTool()
    result = await calc.run("2 + 3 * 4", context={})
    assert result.success
    assert result.output == "14"

@pytest.mark.asyncio
async def test_calculator_failure():
    calc = CalculatorTool()
    result = await calc.run("unknown_var + 1", context={})
    assert not result.success
    assert "name 'unknown_var' is not defined" in result.output

@pytest.mark.asyncio
async def test_search_stub():
    search = SearchTool()
    result = await search.run("data science best practices", context={})
    assert result.success
    assert "Search stub" in result.output or "results for" in result.output
