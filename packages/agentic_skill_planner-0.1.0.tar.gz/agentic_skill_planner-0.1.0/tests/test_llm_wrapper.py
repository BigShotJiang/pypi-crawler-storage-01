import asyncio
from typing import List
from pydantic import BaseModel
from agentic_framework.llm import OpenAIStructuredWrapper

# Simplified schemas for test
class Category(BaseModel):
    category: str

class CategoriesResponse(BaseModel):
    categories: List[Category]

async def main():
    llm = OpenAIStructuredWrapper(model="gpt-4o-2024-08-06", temperature=0.5)

    prompt = (
        "Generate a JSON object with a key 'categories' containing a list of category objects. "
        "Each category object should have a 'category' string. "
        "Example:\n"
        "{\n"
        "  \"categories\": [\n"
        "    {\"category\": \"Machine Learning\"},\n"
        "    {\"category\": \"Data Engineering\"},\n"
        "    {\"category\": \"Statistics\"}\n"
        "  ]\n"
        "}\n"
        "Respond with ONLY the JSON object."
    )

    raw_output, parsed_obj = await llm.call(prompt, response_format=CategoriesResponse)

    print("----- RAW OUTPUT -----")
    print(raw_output)
    print("\n----- PARSED OBJECT -----")
    print(parsed_obj)

    if parsed_obj:
        print("\nCategories:")
        for cat in parsed_obj.categories:
            print(cat.category)

if __name__ == "__main__":
    asyncio.run(main())
