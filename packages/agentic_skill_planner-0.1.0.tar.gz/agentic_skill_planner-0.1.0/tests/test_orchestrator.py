# tests/test_orchestrator.py
import asyncio
from agentic_framework.orchestrator import JobOrchestrator
from tests.conftest import dummy_llm  # pytest will inject

import pytest

@pytest.mark.asyncio
async def test_build_full_plan(dummy_llm):
    orchestrator = JobOrchestrator(dummy_llm)
    plan = await orchestrator.build_full_plan("Data Scientist")
    assert plan["role"] == "Data Scientist"
    breakdown = plan["breakdown"]
    assert isinstance(breakdown, list)
    # Should have at least the two categories from dummy
    cats = {entry["category"] for entry in breakdown}
    assert "Programming Languages" in cats
    assert "Cloud Platforms" in cats
    # Validate skills and topics are populated as per dummy logic
    for entry in breakdown:
        for skill_entry in entry["skills"]:
            assert "skill" in skill_entry
            assert "topics" in skill_entry
