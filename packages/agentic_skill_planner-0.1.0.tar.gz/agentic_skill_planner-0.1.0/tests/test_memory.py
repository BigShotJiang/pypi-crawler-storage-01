# tests/test_memory.py
import pytest
import asyncio
from agentic_framework.memory import FullHistoryMemory, LastNMemory, CompositeMemory

@pytest.mark.asyncio
async def test_full_history_memory():
    mem = FullHistoryMemory()
    await mem.add("a", "first")
    await mem.add("a", "second")
    history = await mem.retrieve("a")
    assert history == ["first", "second"]

@pytest.mark.asyncio
async def test_last_n_memory():
    mem = LastNMemory(n=2)
    await mem.add("a", "one")
    await mem.add("a", "two")
    await mem.add("a", "three")
    history = await mem.retrieve("a")
    assert history == ["two", "three"]  # only last 2

@pytest.mark.asyncio
async def test_composite_memory_dedup():
    full = FullHistoryMemory()
    lastn = LastNMemory(n=5)
    composite = CompositeMemory(full, lastn)
    await composite.add("agent1", "entry1")
    await composite.add("agent1", "entry2")
    await composite.add("agent1", "entry1")  # duplicate
    result = await composite.retrieve("agent1")
    # Should include entry1, entry2 only once each in order first seen
    assert result[0] == "entry1"
    assert result[1] == "entry2"
    assert len(result) == 2
