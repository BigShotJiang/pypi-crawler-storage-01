
"""
Unscale AI - Function tracing and monitoring library
"""

from .trace import trace, feedback

__version__ = "0.1.1"
__all__ = ["trace", "feedback"]
