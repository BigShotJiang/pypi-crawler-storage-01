"""
Test suite for PDF Page Counter package.
"""
