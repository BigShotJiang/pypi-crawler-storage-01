"""DiscoSeqSampler - Distributed Coordinated Sequence Sampler."""


__version__ = "0.1.0"
__author__ = "Feiteng Li"
__email__ = ""
__description__ = "Distributed Coordinated Sequence Sampler"

# 在这里导入主要的类和函数
# from .sampler import DiscoSeqSampler
# from .coordinator import Coordinator

__all__: list[str] = [
    # "DiscoSeqSampler",
    # "Coordinator",
]
