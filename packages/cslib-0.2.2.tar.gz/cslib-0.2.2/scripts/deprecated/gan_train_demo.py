# from clib.projects.gan import gan
# import config

# opts = gan.TrainOptions().parse(config.opts['GAN'])
# gan.train(opts)