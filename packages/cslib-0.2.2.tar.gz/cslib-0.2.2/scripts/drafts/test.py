''' Test `lab` Loading
'''

# from clib.utils import path_load_test
# import clib
# # This will print Hello World!
# path_load_test() # <- open this comment
# print(clib)

''' Test GPU on
'''
# import torch

# def test_gpu_on():
#     if torch.cuda.is_available():
#         print("CUDA is available! GPU will be used.")
#         device = torch.device("cuda")
#     else:
#         print("CUDA is not available. CPU will be used.")
#         device = torch.device("cpu")

#     x = torch.tensor([1.0, 2.0, 3.0])
#     x = x.to(device)

#     print(f"Tensor x is now on {x.device}")

# test_gpu_on()
