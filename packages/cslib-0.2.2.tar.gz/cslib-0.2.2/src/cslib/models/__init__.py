# 用作案例，具体的项目里边可以重新修改
# attension
from .seattention import *
from .cbam import *
from .simam import *