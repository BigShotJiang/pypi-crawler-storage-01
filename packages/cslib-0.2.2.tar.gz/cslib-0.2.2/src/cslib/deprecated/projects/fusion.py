from .collection import DeepFuse
from .collection import DenseFuse
from .collection import AUIF
from .collection import DIDFuse
# from .collection import SwinFuse
from .collection import MFEIF
from .collection import Res2Fusion
from .collection import UNFusion
from .collection import CDDFuse
from .collection import CoCoNet