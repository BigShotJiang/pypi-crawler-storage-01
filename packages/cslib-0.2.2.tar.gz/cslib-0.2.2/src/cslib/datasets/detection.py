from .collection.general_detection import GeneralDetection
from torchvision.datasets import \
    CocoDetection, CelebA, Cityscapes, Kitti, OxfordIIITPet, SBDataset, VOCDetection, VOCSegmentation, WIDERFace