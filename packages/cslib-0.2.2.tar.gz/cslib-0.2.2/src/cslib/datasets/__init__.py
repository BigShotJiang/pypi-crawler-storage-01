# 图像分类
from .classification import *

# 目标检测
from .detection import *

# 线性的数据
from .linear import *

# 图片相关
from .image import *

# 图像融合
from .fusion import *