"""Core components for executing evaluation pipelines."""
