# This file makes the 'adapters' directory a Python package.
