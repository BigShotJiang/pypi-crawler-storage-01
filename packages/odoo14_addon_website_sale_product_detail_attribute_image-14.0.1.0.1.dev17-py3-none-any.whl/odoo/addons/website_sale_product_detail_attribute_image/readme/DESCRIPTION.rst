This module extends the functionality of website sale module to allow to
display images, name and values related to product attributes in e-commerce
product page.
