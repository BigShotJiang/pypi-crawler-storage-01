* Go to Website > Configuration > Products > Attributes.
* Set an image in 'Website image' field to display this attribute in shop
  product detail.
* You can set alternative name for attribute in field "Website name".
* You can set alternative name for attribute value in field "Website name".
* Active 'Publish in website' field to display this attribute in
  shop product detail.
