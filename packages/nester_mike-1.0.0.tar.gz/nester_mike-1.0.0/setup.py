from distutils.core import setup

setup(
        name = 'nester_mike',
        version = '1.0.0',
        py_modules = ['nester_mike'],
        author = 'mike',
        author_email = '',
        url = '',
        description = 'A simple printer of nested lists',
        )
