import plsconvert.cli as cli


def main() -> None:
    cli.cli()
