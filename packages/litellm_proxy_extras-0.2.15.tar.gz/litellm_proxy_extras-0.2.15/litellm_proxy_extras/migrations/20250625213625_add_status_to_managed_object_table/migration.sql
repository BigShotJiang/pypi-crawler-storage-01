-- AlterTable
ALTER TABLE "LiteLLM_ManagedObjectTable" ADD COLUMN     "status" TEXT;

