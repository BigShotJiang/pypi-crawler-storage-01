def test_import_solar_apparent_time():
    import solar_apparent_time
