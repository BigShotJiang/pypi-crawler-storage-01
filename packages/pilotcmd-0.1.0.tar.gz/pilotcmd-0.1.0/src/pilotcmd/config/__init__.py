"""
Configuration management module.
"""

from .manager import ConfigManager, Config

__all__ = ["ConfigManager", "Config"]
