from acres import Loader

load = Loader(__spec__.name)
