from .glmClassifier import GLMClassifier
from .glmRegressor import GLMRegressor

__all__ = ["GLMClassifier", "GLMRegressor"]
