# bluesky_2_album

Return photo list and caption (markdown format) from bluesky.

## usage

```
import bluesky_2_album
result = bluesky_2_album.get(url)
result.imgs
result.cap
```

## how to install

`pip3 install bluesky_2_album`