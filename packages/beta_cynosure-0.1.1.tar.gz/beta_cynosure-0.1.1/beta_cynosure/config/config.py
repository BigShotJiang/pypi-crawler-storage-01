DATA_DIR = "output"
DFP_FILE = f"{DATA_DIR}/dfp_geral.csv"
ITR_FILE = f"{DATA_DIR}/itr_geral.csv"
