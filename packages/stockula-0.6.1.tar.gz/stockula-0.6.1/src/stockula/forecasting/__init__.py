"""Forecasting module using AutoTS."""

from .forecaster import StockForecaster

__all__ = ["StockForecaster"]
