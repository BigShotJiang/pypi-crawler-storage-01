================================
Identification of Trust (Flask)
================================

This is the Flask-dependent code for an implementation of the Identification of
Trust microsite.

