__version__ = 'v25.08'
__version_str__ = 'v25.08'
__branch__ = 'master'
__unclean__ = False
