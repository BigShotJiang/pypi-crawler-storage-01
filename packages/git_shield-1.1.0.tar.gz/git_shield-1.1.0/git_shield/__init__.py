"""
git-shield: Advanced secret detection for Git repositories
"""

__version__ = "1.0.0"
__author__ = "Vamil Porwal"
__email__ = "vamililporwal@gmail.com"
