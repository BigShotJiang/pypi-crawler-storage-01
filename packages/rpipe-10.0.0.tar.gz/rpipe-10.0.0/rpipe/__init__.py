__version__: str = "10.0.0"  # Must be "<major>.<minor>.<patch>", all numbers
