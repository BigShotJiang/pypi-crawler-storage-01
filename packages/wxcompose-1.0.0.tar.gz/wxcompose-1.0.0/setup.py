"""Package setup"""

from setuptools import setup


def setup_package():
    """Package setup"""
    setup()


if __name__ == "__main__":
    setup_package()
