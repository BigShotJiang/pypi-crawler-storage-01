"""Declarative UI style and view model binding for wxPython"""

__version__ = '1.0.0'
