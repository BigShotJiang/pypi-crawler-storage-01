"""Metrics wrappers API."""

from eva.vision.metrics.wrappers.monai import MonaiMetricWrapper

__all__ = ["MonaiMetricWrapper"]
