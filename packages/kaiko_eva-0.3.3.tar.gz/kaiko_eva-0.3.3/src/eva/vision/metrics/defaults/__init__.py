"""Default metric collections API."""

from eva.vision.metrics.defaults.segmentation import MulticlassSegmentationMetrics

__all__ = [
    "MulticlassSegmentationMetrics",
]
