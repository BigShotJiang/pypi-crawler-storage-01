"""Default segmentation metric collections API."""

from eva.vision.metrics.defaults.segmentation.multiclass import MulticlassSegmentationMetrics

__all__ = ["MulticlassSegmentationMetrics"]
