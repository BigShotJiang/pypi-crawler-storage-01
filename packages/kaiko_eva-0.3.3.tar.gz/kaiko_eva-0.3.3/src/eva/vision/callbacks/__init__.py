"""Vision callbacks API."""

from eva.vision.callbacks.loggers import SemanticSegmentationLogger

__all__ = ["SemanticSegmentationLogger"]
