"""Batch related loggers callbacks API."""

from eva.vision.callbacks.loggers.batch.segmentation import SemanticSegmentationLogger

__all__ = ["SemanticSegmentationLogger"]
