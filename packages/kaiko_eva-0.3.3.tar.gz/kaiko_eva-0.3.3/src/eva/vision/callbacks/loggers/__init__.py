"""Vision logging related callbacks API."""

from eva.vision.callbacks.loggers.batch import SemanticSegmentationLogger

__all__ = ["SemanticSegmentationLogger"]
