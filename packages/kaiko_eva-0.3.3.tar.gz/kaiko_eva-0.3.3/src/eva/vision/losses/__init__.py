"""Loss functions API."""

from eva.vision.losses.dice import DiceCELoss, DiceLoss

__all__ = ["DiceLoss", "DiceCELoss"]
