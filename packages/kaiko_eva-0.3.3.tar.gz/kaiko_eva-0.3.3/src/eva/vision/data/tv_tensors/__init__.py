"""Custom `tv_tensors` types for torchvision."""

from eva.vision.data.tv_tensors.volume import Volume

__all__ = ["Volume"]
