"""Dataloader collate API."""

from eva.vision.data.dataloaders.collate_fn.collection import collection_collate

__all__ = ["collection_collate"]
