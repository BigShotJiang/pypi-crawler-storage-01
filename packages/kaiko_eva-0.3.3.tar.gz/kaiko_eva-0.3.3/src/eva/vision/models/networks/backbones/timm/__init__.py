"""timm backbones API."""

from eva.vision.models.networks.backbones.timm.backbones import timm_model

__all__ = ["timm_model"]
