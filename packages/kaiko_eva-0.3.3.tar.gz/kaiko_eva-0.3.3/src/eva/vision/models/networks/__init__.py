"""Vision Networks API."""

from eva.vision.models.networks.abmil import ABMIL

__all__ = ["ABMIL"]
