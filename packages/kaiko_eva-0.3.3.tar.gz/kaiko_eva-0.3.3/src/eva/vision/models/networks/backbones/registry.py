"""Backbone Model Registry."""

from eva.core.utils.registry import Registry

backbone_registry = Registry()
