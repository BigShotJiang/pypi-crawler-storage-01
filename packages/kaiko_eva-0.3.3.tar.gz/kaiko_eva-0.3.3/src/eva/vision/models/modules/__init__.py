"""Vision modules API."""

from eva.vision.models.modules.semantic_segmentation import SemanticSegmentationModule

__all__ = ["SemanticSegmentationModule"]
