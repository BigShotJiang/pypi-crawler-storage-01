"""Language Networks API."""

from eva.language.models.modules.text import TextModule

__all__ = ["TextModule"]
