"""Language data API."""

from eva.language.data import datasets

__all__ = ["datasets"]
