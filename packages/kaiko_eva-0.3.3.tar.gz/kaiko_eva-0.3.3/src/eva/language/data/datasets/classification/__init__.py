"""Text classification datasets API."""

from eva.language.data.datasets.classification.pubmedqa import PubMedQA

__all__ = [
    "PubMedQA",
]
