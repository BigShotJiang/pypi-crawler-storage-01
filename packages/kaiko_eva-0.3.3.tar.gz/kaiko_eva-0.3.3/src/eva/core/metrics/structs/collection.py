"""Metric collection aggregator."""

import torchmetrics

MetricCollection = torchmetrics.MetricCollection
"""Defines a metric aggregator object."""
