"""Interface API."""

from eva.core.interface.interface import Interface

__all__ = ["Interface"]
