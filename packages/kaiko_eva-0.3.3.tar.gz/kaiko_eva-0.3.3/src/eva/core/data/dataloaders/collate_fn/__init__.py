"""Collate functions API."""

from eva.core.data.dataloaders.collate_fn.collate import text_collate_fn

__all__ = ["text_collate_fn"]
