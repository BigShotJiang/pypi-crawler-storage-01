"""Sampling related transformations."""

from eva.core.data.transforms.sampling.sample_from_axis import SampleFromAxis

__all__ = ["SampleFromAxis"]
