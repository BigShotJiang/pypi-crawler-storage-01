"""Base torch dataset module."""

from torch.utils import data

TorchDataset = data.Dataset
"""Base torch dataset class."""
