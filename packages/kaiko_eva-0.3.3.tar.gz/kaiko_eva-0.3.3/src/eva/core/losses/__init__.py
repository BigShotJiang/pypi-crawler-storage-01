"""Loss functions API."""

from eva.core.losses.cross_entropy import CrossEntropyLoss

__all__ = ["CrossEntropyLoss"]
