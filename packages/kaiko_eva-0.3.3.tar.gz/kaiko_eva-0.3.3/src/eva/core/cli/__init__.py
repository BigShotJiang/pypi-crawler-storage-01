"""CLI API."""

from eva.core.cli.cli import cli

__all__ = ["cli"]
