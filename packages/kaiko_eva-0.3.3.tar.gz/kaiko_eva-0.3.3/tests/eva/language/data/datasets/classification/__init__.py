"""Tests for the text classification datasets."""
