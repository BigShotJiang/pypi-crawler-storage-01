"""Model wrapper related tests."""
