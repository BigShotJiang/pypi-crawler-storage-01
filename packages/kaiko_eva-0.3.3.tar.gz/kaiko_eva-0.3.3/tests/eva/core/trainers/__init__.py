"""Tests for the trainers."""
