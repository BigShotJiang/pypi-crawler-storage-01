"""Embeddings writer callback unit tests."""
