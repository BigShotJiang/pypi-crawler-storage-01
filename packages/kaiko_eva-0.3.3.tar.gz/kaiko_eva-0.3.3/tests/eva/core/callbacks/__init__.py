"""Tests for the callbacks submodule."""
