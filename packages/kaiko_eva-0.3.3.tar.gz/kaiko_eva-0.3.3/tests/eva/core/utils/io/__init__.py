"""Tests the core io utilities."""
