"""Tests for the metrics submodule."""
