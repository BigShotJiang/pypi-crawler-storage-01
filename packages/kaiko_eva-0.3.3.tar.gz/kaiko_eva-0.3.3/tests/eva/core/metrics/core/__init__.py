"""Tests for the core metrics modules."""
