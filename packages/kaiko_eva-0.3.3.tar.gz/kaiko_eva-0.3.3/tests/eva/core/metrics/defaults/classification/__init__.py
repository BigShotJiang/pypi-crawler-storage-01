"""Tests default metric groups for classification tasks."""
