"""Tests for core transforms."""
