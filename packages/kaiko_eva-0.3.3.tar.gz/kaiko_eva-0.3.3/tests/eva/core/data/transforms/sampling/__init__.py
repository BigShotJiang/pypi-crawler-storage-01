"""Tests for sampling transforms."""
