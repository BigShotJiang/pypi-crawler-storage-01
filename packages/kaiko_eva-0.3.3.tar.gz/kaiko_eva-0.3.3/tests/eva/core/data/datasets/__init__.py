"""Tests for core datasets."""
