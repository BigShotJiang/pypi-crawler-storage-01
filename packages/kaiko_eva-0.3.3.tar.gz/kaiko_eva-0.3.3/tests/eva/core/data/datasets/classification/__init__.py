"""Tests for classification embeddings datasets."""
