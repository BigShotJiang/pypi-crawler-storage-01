"""Tests for the data submodule."""
