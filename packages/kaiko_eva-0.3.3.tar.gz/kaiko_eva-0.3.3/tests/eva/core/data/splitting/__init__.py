"""Tests core splitting module."""
