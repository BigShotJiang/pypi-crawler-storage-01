"""Tests for the vision segmentation metric collections."""
