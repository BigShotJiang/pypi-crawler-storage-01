"""Tests default metric groups for segmentation tasks."""
