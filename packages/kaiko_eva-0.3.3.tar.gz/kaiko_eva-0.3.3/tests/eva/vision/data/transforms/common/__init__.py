"""Tests for common vision transforms."""
