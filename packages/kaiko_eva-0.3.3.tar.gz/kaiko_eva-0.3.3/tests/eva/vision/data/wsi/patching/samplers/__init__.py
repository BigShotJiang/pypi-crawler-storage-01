"""WSI patch samplers tests."""
