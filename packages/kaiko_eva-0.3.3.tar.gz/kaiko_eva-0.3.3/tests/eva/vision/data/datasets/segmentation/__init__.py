"""Tests for the image segmentation datasets."""
