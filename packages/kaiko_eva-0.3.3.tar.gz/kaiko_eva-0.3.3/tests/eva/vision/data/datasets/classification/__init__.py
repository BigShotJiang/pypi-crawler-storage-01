"""Tests for the image classification datasets."""
