"""Vision related IO tests."""
