"""Vision utilities tests."""
