"""Tests for the vision model modules."""
