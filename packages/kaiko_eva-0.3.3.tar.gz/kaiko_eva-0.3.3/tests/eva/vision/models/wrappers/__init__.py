"""Tests for vision model wrappers."""
