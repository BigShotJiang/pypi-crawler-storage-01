"""Vision models tests."""
