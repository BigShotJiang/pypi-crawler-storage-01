"""Vision backbone tests."""
