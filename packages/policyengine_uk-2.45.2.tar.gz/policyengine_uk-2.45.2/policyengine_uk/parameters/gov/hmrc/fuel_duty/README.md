# Fuel duty
