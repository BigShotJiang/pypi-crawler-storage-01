try:
    from pydantic.v1 import *
except ImportError:  # pragma: no cover
    from pydantic import *
