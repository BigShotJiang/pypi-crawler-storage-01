from setuptools import setup, find_packages

setup(
    name='global-list',
    version='0.1.0',
    author='Karelskiy127 & AdderTeam',
    author_email='karjalanchel@gmail.com',
    description='A package that provides api.demonlist.org functions to python',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/CoolJayfather/pyDemonlistAPI',
    packages=find_packages(),
    classifiers=[
    'Programming Language :: Python :: 3',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    install_requires=[
        "requests",
        "countryflag",
    ],
)