===============================================================
task-worktime-list-by-user-phase.csv
===============================================================

タスク、フェーズ、ユーザーごとの作業時間と生産量が記載されています。

このCSVファイルは、他のCSVファイルやグラフの作成に利用するための中間ファイルです。
ユーザーが直接確認することを想定していません。


`タスクlist.csvのサンプル <https://github.com/kurusugawa-computer/annofab-cli/blob/main/docs/command_reference/statistics/visualize/out_dir/task-worktime-list-by-user-phase.csv>`_
