==================================================
task_history_event
==================================================

Description
=================================
タスク履歴イベント関係のコマンドです。

task_history_eventコマンドはベータ版です。予告なく変更される場合があります。

Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   download
   list_all
   list_worktime

Usage Details
=================================

.. argparse::
   :ref: annofabcli.task_history_event.subcommand_task_history_event.add_parser
   :prog: annofabcli task_history_event
   :nosubcommands:
