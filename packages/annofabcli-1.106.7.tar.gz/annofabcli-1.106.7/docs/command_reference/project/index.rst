==================================================
project
==================================================

Description
=================================
プロジェクト関係のコマンドです。


Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   change_status
   change_organization
   copy
   diff
   list
   put

Usage Details
=================================

.. argparse::
   :ref: annofabcli.project.subcommand_project.add_parser
   :prog: annofabcli project
   :nosubcommands:
