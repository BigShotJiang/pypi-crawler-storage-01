"""Honest calculator."""
