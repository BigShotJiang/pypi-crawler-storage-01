"""A classic Hangman game implementation."""
