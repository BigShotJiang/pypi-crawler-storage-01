"""A portfolio of Python projects from the Hyperskill platform."""
