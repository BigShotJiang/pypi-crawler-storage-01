"""A simple, rule-based chatbot project."""
