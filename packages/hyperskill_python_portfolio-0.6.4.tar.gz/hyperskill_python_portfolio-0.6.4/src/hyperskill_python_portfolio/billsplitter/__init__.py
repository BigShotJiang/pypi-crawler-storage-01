"""A tool to split a restaurant bill among friends."""
