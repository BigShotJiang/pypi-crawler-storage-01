"""The Rock-Paper-Scissors style game."""
