Use this translations directory to provide internationalized strings for your XBlock project.

For more information on how to enable translations, visit the Open edX XBlock tutorial on Internationalization:
http://edx.readthedocs.org/projects/xblock-tutorial/en/latest/edx_platform/edx_lms.html
