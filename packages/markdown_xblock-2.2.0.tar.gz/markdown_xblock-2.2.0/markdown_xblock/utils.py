# -*- coding: utf-8 -*-
"""
Helpers functions for HTML XBlock.
"""


def _(text):
    """
    Make '_' a no-op so we can scrape strings.
    """
    return text
