__extension_version__ = "0.41.0"
__extension_name__ = "pytket-qulacs"
