from faraday.server.app import get_app

app = get_app()
