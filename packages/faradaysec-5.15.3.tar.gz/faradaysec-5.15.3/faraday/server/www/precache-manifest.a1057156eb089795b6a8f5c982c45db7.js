self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "286022e6f6b30a45600deb133b444b86",
    "url": "/index.html"
  },
  {
    "revision": "7503e140c870b3679b8a",
    "url": "/static/css/2.3104f1fa.chunk.css"
  },
  {
    "revision": "1d4ea057a65926ccd7bc",
    "url": "/static/css/main.8a701783.chunk.css"
  },
  {
    "revision": "7503e140c870b3679b8a",
    "url": "/static/js/2.4ee2bc01.chunk.js"
  },
  {
    "revision": "ae5d48adfc601e9bfe0f04ece7b0204d",
    "url": "/static/js/2.4ee2bc01.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1d4ea057a65926ccd7bc",
    "url": "/static/js/main.9d6abf09.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "/static/js/main.9d6abf09.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d97a0b7a31c68e8630e8",
    "url": "/static/js/runtime-main.ea9693b3.js"
  },
  {
    "revision": "386f05946a76935fcabf319affff517a",
    "url": "/static/media/CentraNo2-Book.386f0594.otf"
  },
  {
    "revision": "63911e8535278ced52b8a37e819f6f5d",
    "url": "/static/media/CentraNo2-Medium.63911e85.otf"
  },
  {
    "revision": "b83098acdf43a5270ccc2be056c730ca",
    "url": "/static/media/Checkbox.b83098ac.svg"
  },
  {
    "revision": "195b4c920dfb75aec10eb8202a74fd24",
    "url": "/static/media/Checkbox_empty.195b4c92.svg"
  },
  {
    "revision": "52c5a6cce0495534e34e37827c84ab3b",
    "url": "/static/media/Checkbox_ok.52c5a6cc.svg"
  },
  {
    "revision": "89985cf25bb2a34ad2cc63d2bfb2a84d",
    "url": "/static/media/Sequel_Sans_Head_Bold.89985cf2.woff"
  },
  {
    "revision": "b99ba59e23c814bc054093ab4f2f13c5",
    "url": "/static/media/Sequel_Sans_Head_Book.b99ba59e.woff"
  },
  {
    "revision": "db87ffc97df8630a36ee4fd4de57befb",
    "url": "/static/media/Sequel_Sans_Head_Medium.db87ffc9.woff"
  },
  {
    "revision": "db35328c86daf92e038de92a310fff37",
    "url": "/static/media/Sequel_Sans_Head_Roman.db35328c.woff"
  },
  {
    "revision": "488735062d75f59a0288cebcbf440833",
    "url": "/static/media/Sequel_Sans_Head_SemiBold.48873506.woff"
  },
  {
    "revision": "1ce5f4e0741a0a005883ba1319f2c454",
    "url": "/static/media/activity-dashboard.1ce5f4e0.svg"
  },
  {
    "revision": "d1a2c9fe24b7078f978969e5879a0f89",
    "url": "/static/media/agent_small.d1a2c9fe.svg"
  },
  {
    "revision": "6f16d31d3b14f69648c50f9a39e1349c",
    "url": "/static/media/analytics.6f16d31d.svg"
  },
  {
    "revision": "dcbdf06d8345c5929cf9ed7e0d9d8c93",
    "url": "/static/media/api_link.dcbdf06d.svg"
  },
  {
    "revision": "d055fa7c289fc56810a79ae9eb50ca31",
    "url": "/static/media/archive.d055fa7c.svg"
  },
  {
    "revision": "d8661d880a792be0339c335178cd3eb3",
    "url": "/static/media/arrow-down.d8661d88.svg"
  },
  {
    "revision": "ec48cf401aa8f62075ddc6cde89fc125",
    "url": "/static/media/arrow-right.ec48cf40.svg"
  },
  {
    "revision": "581bf13b4b461598b9533ec6fb198c11",
    "url": "/static/media/assets.581bf13b.svg"
  },
  {
    "revision": "e231d6be0cad11858ffaf5904a488342",
    "url": "/static/media/automation.e231d6be.svg"
  },
  {
    "revision": "0e9ed0e58ed13bb7061605e68edcf4a9",
    "url": "/static/media/blank_reports_view.0e9ed0e5.svg"
  },
  {
    "revision": "1bcc7b2f507f890a90a1162aafbb6f96",
    "url": "/static/media/check2.1bcc7b2f.svg"
  },
  {
    "revision": "26371e5fd1c70bc5dbc1b786cf246022",
    "url": "/static/media/clear.26371e5f.svg"
  },
  {
    "revision": "a59d6f4bcab0cfc93a031a7bd85e9ca5",
    "url": "/static/media/codeql_logo.a59d6f4b.svg"
  },
  {
    "revision": "6f2e860cea98ea5ca163604209f3842b",
    "url": "/static/media/cog.6f2e860c.svg"
  },
  {
    "revision": "7e1b100630ed2b5d2df2cdbe4c0da25c",
    "url": "/static/media/copy.7e1b1006.svg"
  },
  {
    "revision": "852fb400cbf3c451f4a47ba0f36befb8",
    "url": "/static/media/copy_link.852fb400.svg"
  },
  {
    "revision": "e6c668772d895729176b2d1b1cb9841e",
    "url": "/static/media/crack_map_exec_logo.e6c66877.svg"
  },
  {
    "revision": "9c45605eca322e70883fbc4d776561bd",
    "url": "/static/media/dependabot_logo.9c45605e.svg"
  },
  {
    "revision": "366b7797dd26080e7fef64a2d7a06a8e",
    "url": "/static/media/details.366b7797.svg"
  },
  {
    "revision": "16a667bce9f0c87df26956047b904a2c",
    "url": "/static/media/device.16a667bc.svg"
  },
  {
    "revision": "eadbcf9c47406301a5b8335199349e41",
    "url": "/static/media/download-icon.eadbcf9c.svg"
  },
  {
    "revision": "b17c0ec9fb760c0518351522f7858811",
    "url": "/static/media/drag.b17c0ec9.svg"
  },
  {
    "revision": "3ebce7f36a60f5e6b93c4c9c73a1d5fa",
    "url": "/static/media/empty-feed.3ebce7f3.png"
  },
  {
    "revision": "364d0169fbbc8be38056a60e620b43e6",
    "url": "/static/media/error-mark.364d0169.svg"
  },
  {
    "revision": "2dcc3b35a99c20a1881bca0f74f874e7",
    "url": "/static/media/evidence-default.2dcc3b35.svg"
  },
  {
    "revision": "73360ffd92ffb46dce868557da961319",
    "url": "/static/media/exclamation_error.73360ffd.svg"
  },
  {
    "revision": "9a0b094dee0eb395c79dee17eaef5e64",
    "url": "/static/media/f_round.9a0b094d.svg"
  },
  {
    "revision": "ce97099f759b6406e988c84d2189eb18",
    "url": "/static/media/faraday-logo-dark.ce97099f.svg"
  },
  {
    "revision": "8385ead158847d5a2936b1110eefc29a",
    "url": "/static/media/faraday-logo-nav.8385ead1.svg"
  },
  {
    "revision": "6f6c122b0b1ee1e610089f9e0f50ac18",
    "url": "/static/media/faraday-logo.6f6c122b.svg"
  },
  {
    "revision": "13bdbd547f21dfc0396722edc30244d4",
    "url": "/static/media/faraday_loadingbar.13bdbd54.gif"
  },
  {
    "revision": "3af44fcb996a883c3b615929e4383a94",
    "url": "/static/media/faraday_logo.3af44fcb.svg"
  },
  {
    "revision": "57beba14e32bd34818518e541842f146",
    "url": "/static/media/faraday_logo_product.57beba14.svg"
  },
  {
    "revision": "efd0850b0928947b021aaaa5eac3864d",
    "url": "/static/media/ff_2fa.efd0850b.png"
  },
  {
    "revision": "018317e398516fe7b89c75747305e268",
    "url": "/static/media/ff_analytics.018317e3.png"
  },
  {
    "revision": "5083dd5669d9b26549517d8537bfb7a0",
    "url": "/static/media/ff_cloud_agents.5083dd56.png"
  },
  {
    "revision": "46352b012bafad122dd1810cb55c72de",
    "url": "/static/media/ff_duplicates.46352b01.png"
  },
  {
    "revision": "e96f786d0f77993538c17f082982ff57",
    "url": "/static/media/ff_ldap.e96f786d.png"
  },
  {
    "revision": "58bfcb9756f82ef2634b1e607d2687a9",
    "url": "/static/media/ff_planner.58bfcb97.png"
  },
  {
    "revision": "9d5a9bb82356ecf735beb180706f1419",
    "url": "/static/media/ff_reporting.9d5a9bb8.png"
  },
  {
    "revision": "119fe76fd01a1956224e7429230e3ac0",
    "url": "/static/media/ff_saml.119fe76f.png"
  },
  {
    "revision": "ccc5427bb24afc3fae370289a1e057bc",
    "url": "/static/media/ff_tags.ccc5427b.png"
  },
  {
    "revision": "e5bdca7ef29b312339f838df596e4e5c",
    "url": "/static/media/ff_users.e5bdca7e.png"
  },
  {
    "revision": "f998867178bc0d4940a38d8ed10c725c",
    "url": "/static/media/generic_file.f9988671.svg"
  },
  {
    "revision": "0bb6cf15c94e6458948e05d6f8ef332a",
    "url": "/static/media/github_logo.0bb6cf15.svg"
  },
  {
    "revision": "580f3d1256d7db67ef17bd8a4effbd44",
    "url": "/static/media/grid_view.580f3d12.svg"
  },
  {
    "revision": "5680b8ff741c9db5ea02cd8f90c2aefc",
    "url": "/static/media/help-sysreq.5680b8ff.svg"
  },
  {
    "revision": "61ace590cd922a0e0d270ac28a14f1fc",
    "url": "/static/media/help.61ace590.svg"
  },
  {
    "revision": "59d70ac8881f510d3f73712089fba74b",
    "url": "/static/media/home.59d70ac8.svg"
  },
  {
    "revision": "0d9a4fc0e5f19114cb089c055064d35d",
    "url": "/static/media/ico-vulnerability-templates.0d9a4fc0.svg"
  },
  {
    "revision": "fc841a37e099033913574c800e8fdf69",
    "url": "/static/media/ico-web-shell.fc841a37.svg"
  },
  {
    "revision": "efe44a0e99a1aefe2f8951a128e3af21",
    "url": "/static/media/icon-action-bar-column.efe44a0e.svg"
  },
  {
    "revision": "a362c51d2662186dc44f906cbf8034e2",
    "url": "/static/media/icon-action-bar-edit.a362c51d.svg"
  },
  {
    "revision": "fd9db67e10a700a3a831a11b916f4146",
    "url": "/static/media/icon-action-bar-more.fd9db67e.svg"
  },
  {
    "revision": "8879f3f64ab81fdfad3fe450d6cbefe0",
    "url": "/static/media/icon-action-bar-plus.8879f3f6.svg"
  },
  {
    "revision": "c0f5d2b316d9ff9c214e0e0490aec3f9",
    "url": "/static/media/icon-action-bar-tags.c0f5d2b3.svg"
  },
  {
    "revision": "d7973c771f653c405ba95fc302c27811",
    "url": "/static/media/icon-action-bar-token.d7973c77.svg"
  },
  {
    "revision": "b1589206e6453de1eedc000bf081248d",
    "url": "/static/media/icon-action-bar-trash.b1589206.svg"
  },
  {
    "revision": "e0400bf167104fd5929cbadaddc2709c",
    "url": "/static/media/icon-action-bar-trigger-disabled.e0400bf1.svg"
  },
  {
    "revision": "f9c88d810c1f6c72422be9cdff900aa6",
    "url": "/static/media/icon-action-bar-trigger.f9c88d81.svg"
  },
  {
    "revision": "c53f293611ad2375fba3af99eab44622",
    "url": "/static/media/icon-clipboard.c53f2936.svg"
  },
  {
    "revision": "9b3b0c8979995a5de58f778576f4d0f6",
    "url": "/static/media/icon-close-without-background.9b3b0c89.svg"
  },
  {
    "revision": "9a5cad5c8f7b2cdad7f6aa3111640f27",
    "url": "/static/media/icon-close.9a5cad5c.svg"
  },
  {
    "revision": "8bd11a4720f7b2218c3528db95915342",
    "url": "/static/media/icon-customfields.8bd11a47.svg"
  },
  {
    "revision": "a68d0409664685eabb8c3c1892227d1a",
    "url": "/static/media/icon-edit-enabled.a68d0409.svg"
  },
  {
    "revision": "fdee90dddb76735ac15956a7eb2edeac",
    "url": "/static/media/icon-evidence.fdee90dd.svg"
  },
  {
    "revision": "cb712c6461c665deb437c22f65ef350f",
    "url": "/static/media/icon-goto.cb712c64.svg"
  },
  {
    "revision": "b606975b964ed95fa62f53fb80cda338",
    "url": "/static/media/icon-pipeline-run.b606975b.svg"
  },
  {
    "revision": "86dfed5076697592c0794c396bcc2205",
    "url": "/static/media/icon-pipeline-running.86dfed50.svg"
  },
  {
    "revision": "79a1569da2ac14b75f2be9f7b9930a51",
    "url": "/static/media/icon-show-duplicates.79a1569d.svg"
  },
  {
    "revision": "6c7a2996c211c5920b30298dcfb2e623",
    "url": "/static/media/icon-toolbar-confirmed-on.6c7a2996.svg"
  },
  {
    "revision": "b342d6a5411f4f458de2739fa6504955",
    "url": "/static/media/icon-toolbar-delete.b342d6a5.svg"
  },
  {
    "revision": "dadec58ee6e4d46d928e901e8804ee59",
    "url": "/static/media/icon-toolbar-searchbar-loupe.dadec58e.svg"
  },
  {
    "revision": "1ebe0df44f0b499c280f2a34c5bacd3e",
    "url": "/static/media/icon-trash-red.1ebe0df4.svg"
  },
  {
    "revision": "e7b18936a2968cc857a5e0ae2259b35b",
    "url": "/static/media/icon_clearsearch.e7b18936.svg"
  },
  {
    "revision": "459e6ef92124e6406de96cdc55e1d750",
    "url": "/static/media/icon_close_error.459e6ef9.svg"
  },
  {
    "revision": "d52758c176ce1a101fabe6b644803b9e",
    "url": "/static/media/icon_drag.d52758c1.svg"
  },
  {
    "revision": "97c1ea0430a81fb0a6b13d1894a6e618",
    "url": "/static/media/icon_edit.97c1ea04.svg"
  },
  {
    "revision": "c7a0db306501ca45f572dab9b1f43637",
    "url": "/static/media/icon_filter_off.c7a0db30.svg"
  },
  {
    "revision": "6de198fd2d3255d34343aead738d8226",
    "url": "/static/media/icon_filter_on.6de198fd.svg"
  },
  {
    "revision": "1b34b217e86583c145619bdc15141299",
    "url": "/static/media/icon_help.1b34b217.svg"
  },
  {
    "revision": "663ddfddca1c2e2f982b0ff2d26d8efd",
    "url": "/static/media/icon_loupe.663ddfdd.svg"
  },
  {
    "revision": "f360b291984786bf8d81856ae46878c0",
    "url": "/static/media/icon_modal_asset.f360b291.svg"
  },
  {
    "revision": "0e650ab471d9a04cd30ba8ae6775062d",
    "url": "/static/media/icon_severity.0e650ab4.svg"
  },
  {
    "revision": "cd99484a1518ea847e45e7e3f906c024",
    "url": "/static/media/icon_upload.cd99484a.svg"
  },
  {
    "revision": "6fe4d738809db4fc5cf5b3db6b15c1f0",
    "url": "/static/media/icon_users.6fe4d738.svg"
  },
  {
    "revision": "225e604d61bfeed526d4262c278053d3",
    "url": "/static/media/info.225e604d.svg"
  },
  {
    "revision": "6d79bb919aa8d719ac2e2dabf16861ad",
    "url": "/static/media/jobs_pipelines_empty.6d79bb91.png"
  },
  {
    "revision": "2186340645a704ce6591d2757c4be9d1",
    "url": "/static/media/laptop_icon.21863406.svg"
  },
  {
    "revision": "d5f6e3f8ba54f7ba44fe9c1f99f538e3",
    "url": "/static/media/laquo.d5f6e3f8.svg"
  },
  {
    "revision": "cacc94c7561050e80dceefaeb018ceef",
    "url": "/static/media/list_view.cacc94c7.svg"
  },
  {
    "revision": "5b4dcff2b5bfc50d2b7e3bf133c820c3",
    "url": "/static/media/manage.5b4dcff2.svg"
  },
  {
    "revision": "f5a8e1d072affd3d1582f392b7000bc9",
    "url": "/static/media/mini-terminal.f5a8e1d0.svg"
  },
  {
    "revision": "15584cdcb6c689cdf634ad8617771b03",
    "url": "/static/media/minibot.15584cdc.svg"
  },
  {
    "revision": "a543e5a3fbd0ed17655d7aca9082f3ac",
    "url": "/static/media/moon-stars-svgrepo-com.a543e5a3.svg"
  },
  {
    "revision": "f8f1d51a17b5859ee1a9ff26987a8ab8",
    "url": "/static/media/moveVuln.f8f1d51a.svg"
  },
  {
    "revision": "033159cde1a2aeb9a57755baabb5d200",
    "url": "/static/media/new_vuln_modal_icon.033159cd.svg"
  },
  {
    "revision": "0e62ddad8dcb6b1efd4672a895d5f04d",
    "url": "/static/media/next.0e62ddad.svg"
  },
  {
    "revision": "407b029fdfe932b3e24d34ef872665b5",
    "url": "/static/media/next_arrow.407b029f.svg"
  },
  {
    "revision": "a93b0458fc584fa8e0e59d4d3d1f0f31",
    "url": "/static/media/noun-help.a93b0458.svg"
  },
  {
    "revision": "e0a4aa09ff8cd317ccf5165cbe92e17a",
    "url": "/static/media/preferences_icons_Account.e0a4aa09.svg"
  },
  {
    "revision": "1b59fc923c51062536ebecea2ea300b0",
    "url": "/static/media/preferences_icons_Authentication.1b59fc92.svg"
  },
  {
    "revision": "a1064973bcad42f43ab2c3bc1bec5bde",
    "url": "/static/media/preferences_icons_Ticketing.a1064973.svg"
  },
  {
    "revision": "ecd34f23bbf3132d8ecd247c8e4cda22",
    "url": "/static/media/prev.ecd34f23.svg"
  },
  {
    "revision": "b922c0be4fd19eb93104fd0f8a7450b8",
    "url": "/static/media/queue.b922c0be.svg"
  },
  {
    "revision": "0d7f0f5c89fdf068639c6ffe45a93b6c",
    "url": "/static/media/reload.0d7f0f5c.svg"
  },
  {
    "revision": "e8a3d4446c7f82140e11b6116907f025",
    "url": "/static/media/report_small.e8a3d444.svg"
  },
  {
    "revision": "f38dca7f45c9532be16d19cf18452b10",
    "url": "/static/media/reports.f38dca7f.svg"
  },
  {
    "revision": "eced93cffd37072412e73e7956f76c5c",
    "url": "/static/media/resize_bottom_right.eced93cf.svg"
  },
  {
    "revision": "80d070fae4f3c8c10b532e3fc40243fc",
    "url": "/static/media/reveal.80d070fa.svg"
  },
  {
    "revision": "d74f944af9fb65005cbe545da2b725bf",
    "url": "/static/media/save_template.d74f944a.svg"
  },
  {
    "revision": "c9744ba3be9862f8a3c5d80dd3e0b5d8",
    "url": "/static/media/scheduler_calendar.c9744ba3.svg"
  },
  {
    "revision": "0f83c980e9df15fad1f41dd1958525ea",
    "url": "/static/media/services.0f83c980.svg"
  },
  {
    "revision": "9ea9d3d6560f6341a878d1a297855b37",
    "url": "/static/media/shape.9ea9d3d6.svg"
  },
  {
    "revision": "4fbfe919b69433f94683389f56e6d9e9",
    "url": "/static/media/showHide.4fbfe919.svg"
  },
  {
    "revision": "062a68cea6cacd12647c45f56e783fb3",
    "url": "/static/media/sort.062a68ce.svg"
  },
  {
    "revision": "33d47a0514709be162ef72f775c91050",
    "url": "/static/media/star.33d47a05.svg"
  },
  {
    "revision": "660ac4e6cef831f95d023bc38417832e",
    "url": "/static/media/status.660ac4e6.svg"
  },
  {
    "revision": "ea7e249792c3f5f35ea097710207a7d7",
    "url": "/static/media/sun-dm.ea7e2497.svg"
  },
  {
    "revision": "35dc01bc87daad5c1268699b29a8adcc",
    "url": "/static/media/tasks_icon.35dc01bc.svg"
  },
  {
    "revision": "bc90870d145e59b1f4ef31be8fb0b718",
    "url": "/static/media/template.bc90870d.svg"
  },
  {
    "revision": "569858216a6a1b6e4421804664a35d8d",
    "url": "/static/media/tenable_sc_logo.56985821.svg"
  },
  {
    "revision": "7db0ca987fe7ae218d90239f58e3741a",
    "url": "/static/media/ticketing-license.7db0ca98.png"
  },
  {
    "revision": "dd65c743ec739b8f06844e6fc6630d2c",
    "url": "/static/media/tool_cisco_cybervision.dd65c743.png"
  },
  {
    "revision": "9b037d8bbf910a89f03b474a76563690",
    "url": "/static/media/tool_logo_appscan.9b037d8b.png"
  },
  {
    "revision": "ac5b15cb92ccb7e72a89a2c78be3f30f",
    "url": "/static/media/tool_logo_arachni.ac5b15cb.png"
  },
  {
    "revision": "f0295560a5f625aad3c52cb68c0efebb",
    "url": "/static/media/tool_logo_insightVM.f0295560.png"
  },
  {
    "revision": "8ed3098d2d824c401b34ff74436ed198",
    "url": "/static/media/tool_logo_nessus.8ed3098d.png"
  },
  {
    "revision": "9acc14592e879d269aaf398353634394",
    "url": "/static/media/tool_logo_nikto.9acc1459.png"
  },
  {
    "revision": "9a81da3542609ba9fdc5e7e4500ad688",
    "url": "/static/media/tool_logo_nmap.9a81da35.png"
  },
  {
    "revision": "88898507b2e67efd76db130b354817e4",
    "url": "/static/media/tool_logo_openvas.88898507.png"
  },
  {
    "revision": "8f7b2a7fb8e67fdde80a41fcefd5e036",
    "url": "/static/media/tool_logo_qualys.8f7b2a7f.png"
  },
  {
    "revision": "3af1625ae47f0ccfece27332895d5c36",
    "url": "/static/media/tool_logo_sonarQube.3af1625a.jpeg"
  },
  {
    "revision": "05c390dcacecc7b0c11abafe6a325e64",
    "url": "/static/media/tool_logo_tenable.05c390dc.png"
  },
  {
    "revision": "221ef0f2304f9561bb41534c79fd7291",
    "url": "/static/media/tool_logo_w3af.221ef0f2.png"
  },
  {
    "revision": "92adc6c58cad0bdfc8904759660cdfe6",
    "url": "/static/media/tool_logo_wpscan.92adc6c5.png"
  },
  {
    "revision": "62021c3954a3a0588d655b2dc80e9a89",
    "url": "/static/media/tool_logo_zap.62021c39.png"
  },
  {
    "revision": "e6d04612ca95949153ea247599be1e26",
    "url": "/static/media/tool_trash.e6d04612.svg"
  },
  {
    "revision": "1b4bc890db7a24c29cee2d4678e81f6d",
    "url": "/static/media/tool_wheel.1b4bc890.svg"
  },
  {
    "revision": "6e38883884ed6033621e18aaf72f2370",
    "url": "/static/media/unarchive.6e388838.svg"
  },
  {
    "revision": "f6b0014d4c13aa297ac6f712206d1498",
    "url": "/static/media/unknown_filetype.f6b0014d.svg"
  },
  {
    "revision": "6ac0b0d7ebf611e79ec74b1b9df7167f",
    "url": "/static/media/vuln-kb.6ac0b0d7.svg"
  },
  {
    "revision": "bc957e73b78ab55a952febd16a5f93ad",
    "url": "/static/media/vulnerabilities.bc957e73.svg"
  },
  {
    "revision": "33357364362f9b322bbdb4a43441781b",
    "url": "/static/media/warning-delete.33357364.svg"
  },
  {
    "revision": "51829f9b0e825e8d06b56335f30617ae",
    "url": "/static/media/wf_arrow_collapsed.51829f9b.svg"
  },
  {
    "revision": "06e6e9bdf4988f879c40fb56ba015a2f",
    "url": "/static/media/wf_arrow_expand.06e6e9bd.svg"
  },
  {
    "revision": "e869b8a07aa9e6d862b435196ea27f8c",
    "url": "/static/media/workspaces-license.e869b8a0.png"
  },
  {
    "revision": "d994c131e316f70f69cebf264cbeb172",
    "url": "/static/media/ws-lock.d994c131.svg"
  },
  {
    "revision": "b7653513b992eaf8289d2cd863c1171d",
    "url": "/static/media/ws-unlock.b7653513.svg"
  }
]);