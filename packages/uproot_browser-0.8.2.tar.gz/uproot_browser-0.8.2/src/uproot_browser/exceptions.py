"""Custom exceptions for uproot-browser"""

from __future__ import annotations


class EmptyTreeError(ValueError):
    pass
