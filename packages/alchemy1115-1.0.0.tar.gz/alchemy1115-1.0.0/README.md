```bash
uvx alchemy1115