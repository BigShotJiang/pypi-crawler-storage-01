Code examples for using pyjelly in practice.

The examples will be executed in alphabetical order, so you can number them accordingly.
