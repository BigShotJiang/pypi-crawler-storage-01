from .yolo11_obb import YOLO11OBB
from .yolov8_obb import YOLOv8OBB

__all__ = ["YOLOv8OBB", "YOLO11OBB"]
