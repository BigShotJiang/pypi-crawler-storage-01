"""分割结果类."""


class SemanticSegResult:
    """分割结果类."""

    ...
