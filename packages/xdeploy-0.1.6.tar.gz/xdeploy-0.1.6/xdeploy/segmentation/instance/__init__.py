from .yolo11_seg import YOLO11_SEG
from .yolov8_seg import YOLOV8_SEG

__all__ = ["YOLOV8_SEG", "YOLO11_SEG"]
