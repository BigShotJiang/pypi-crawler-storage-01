from __future__ import annotations

from .yolov8_seg import YOLOV8_SEG


class YOLO11_SEG(YOLOV8_SEG): ...
