from .paddleseg import PaddleSeg

__all__ = ["PaddleSeg"]
