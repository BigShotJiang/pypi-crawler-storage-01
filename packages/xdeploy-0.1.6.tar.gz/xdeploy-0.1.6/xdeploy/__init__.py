# XDeploy 项目 🚀, Apache-2.0 license

__version__ = "0.1.6"
