from .predict_system import PPOCRv4

__all__ = ["PPOCRv4"]
