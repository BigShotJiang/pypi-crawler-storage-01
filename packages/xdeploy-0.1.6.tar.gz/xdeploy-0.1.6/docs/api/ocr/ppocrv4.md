# Reference for `xdeploy/ocr/ppocr/predict_system.py`

## ::: xdeploy.ocr.PPOCRv4
