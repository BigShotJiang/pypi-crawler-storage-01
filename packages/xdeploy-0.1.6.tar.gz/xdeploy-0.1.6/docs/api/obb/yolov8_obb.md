# Reference for `xdeploy/obb/yolov8_obb.py`

## ::: xdeploy.obb.YOLOv8OBB
