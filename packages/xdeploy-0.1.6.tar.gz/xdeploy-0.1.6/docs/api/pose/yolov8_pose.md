# Reference for `xdeploy/pose/yolov8_pose.py`

## ::: xdeploy.pose.YOLOv8Pose
