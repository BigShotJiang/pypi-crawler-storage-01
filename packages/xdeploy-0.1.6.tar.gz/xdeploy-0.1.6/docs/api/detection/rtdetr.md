# Reference for `xdeploy/detection/rtdetr.py`

## ::: xdeploy.detection.rtdetr.RTDETR
