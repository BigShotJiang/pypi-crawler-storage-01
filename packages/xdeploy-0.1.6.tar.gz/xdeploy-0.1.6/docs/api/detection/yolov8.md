# Reference for `xdeploy/detection/yolov8.py`

## ::: xdeploy.detection.yolov8.YOLOv8
