# Reference for `xdeploy/classification/yolov8_cls.py`

## ::: xdeploy.classification.YOLOv8CLS
