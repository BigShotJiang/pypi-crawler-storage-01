# Reference for `xdeploy/utils/data_load.py`

## ::: xdeploy.utils.data_load
