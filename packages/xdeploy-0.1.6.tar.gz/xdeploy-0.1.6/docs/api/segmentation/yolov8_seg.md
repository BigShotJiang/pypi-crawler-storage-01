# Reference for `xdeploy/segmentation/instance/yolov8_seg.py`

## ::: xdeploy.segmentation.instance.YOLOV8_SEG
