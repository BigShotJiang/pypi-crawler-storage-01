# Reference for `xdeploy/segmentation/semantic/paddleseg.py`

## ::: xdeploy.segmentation.semantic.PaddleSeg
