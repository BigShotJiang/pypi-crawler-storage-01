from setuptools import setup, find_packages

setup (
        name='PyMABSolver',
        version='0.1',
        packages=find_packages (), 
        install_requires=[
            'matplotlib>=3.7.2'
    ],
)