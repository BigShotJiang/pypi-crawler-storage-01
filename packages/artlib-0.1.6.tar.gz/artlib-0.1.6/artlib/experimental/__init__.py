"""
Code within this module is highly experimental and therefore comes with no warranty on its use.
"""
