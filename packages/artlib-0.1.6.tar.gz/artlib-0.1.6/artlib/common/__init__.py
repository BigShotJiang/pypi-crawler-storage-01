"""This module implements several functions and classes used across ARTLib as well as
some functions like VAT which are useful in a variety of contexts."""
