# Copyright (c) QuantCo and pydiverse contributors 2025-2025
# SPDX-License-Identifier: BSD-3-Clause


def test_version():
    import pydiverse.common as pdc

    print(f"pdc.__version__ = \n{pdc.__version__}\n")
