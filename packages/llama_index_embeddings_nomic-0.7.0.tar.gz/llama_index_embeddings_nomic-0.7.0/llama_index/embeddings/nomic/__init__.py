from llama_index.embeddings.nomic.base import NomicEmbedding

__all__ = ["NomicEmbedding"]
