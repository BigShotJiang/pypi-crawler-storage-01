# LlamaIndex Embeddings Integration: Nomic
