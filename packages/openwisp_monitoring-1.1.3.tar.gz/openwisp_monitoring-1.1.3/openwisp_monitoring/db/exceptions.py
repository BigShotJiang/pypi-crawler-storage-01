class TimeseriesWriteException(Exception):
    pass
