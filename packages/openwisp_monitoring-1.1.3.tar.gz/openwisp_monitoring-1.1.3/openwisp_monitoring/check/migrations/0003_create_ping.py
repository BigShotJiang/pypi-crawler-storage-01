from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ('check', '0001_initial_squashed_0002_check_unique_together'),
    ]

    operations = []
