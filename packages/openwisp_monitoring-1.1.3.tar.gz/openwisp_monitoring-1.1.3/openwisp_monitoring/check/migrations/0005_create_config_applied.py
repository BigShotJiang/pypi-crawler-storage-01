from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ('check', '0004_rename_active_to_is_active'),
    ]

    operations = []
