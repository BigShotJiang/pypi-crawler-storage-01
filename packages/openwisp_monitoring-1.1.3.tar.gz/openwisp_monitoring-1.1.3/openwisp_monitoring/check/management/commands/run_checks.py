from . import BaseRunChecksCommand


class Command(BaseRunChecksCommand):
    pass
