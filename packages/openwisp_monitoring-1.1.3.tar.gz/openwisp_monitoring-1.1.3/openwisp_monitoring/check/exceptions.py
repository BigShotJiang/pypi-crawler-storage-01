class OperationalError(RuntimeError):
    pass
