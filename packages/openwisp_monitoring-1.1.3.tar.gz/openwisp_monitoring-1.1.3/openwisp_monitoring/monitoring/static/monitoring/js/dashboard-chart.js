'use strict';
django.jQuery(function ($) {
    $(document).ready(function () {
        triggerChartLoading();
    });
}(django.jQuery));

