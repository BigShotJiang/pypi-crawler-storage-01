from . import BaseMigrateTimeseriesCommand


class Command(BaseMigrateTimeseriesCommand):
    pass
