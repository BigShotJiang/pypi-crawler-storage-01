class InvalidChartConfigException(Exception):
    pass


class InvalidMetricConfigException(Exception):
    pass
