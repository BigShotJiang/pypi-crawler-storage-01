import numpy as np

MASK_DTYPE = np.uint8
SEG_DTYPE = np.int16
DATA_DTYPE = np.single
