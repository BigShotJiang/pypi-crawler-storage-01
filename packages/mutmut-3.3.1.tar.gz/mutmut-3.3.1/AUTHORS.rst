=======
Credits
=======

* Anders Hovmöller <boxed@killingar.net>
* Felipe Pontes <felipemfpontes@gmail.com>
* William Orr <will@worrbase.com>
* Trevin Gandhi <trevin.gandhi@petuum.com>
* Daniel Hahler <git@thequod.de>
* Marcelo Da Cruz Pinto
* Jakub Stolarski
* Hristo Georgiev
* Savo Kovačević <savo.s.kovacevic@gmail.com>
* Nathan Klapstein <nklapste@ualberta.ca>
* Brian Skinn <brian.skinn@gmail.com>
* Jim Jazwiecki <jim.jazwiecki@gmail.com>
* neroks <gneroks@gmail.com>
* John Vandenberg <jayvdb@gmail.com>
* Luca Simonetto <luca.simonetto.94@gmail.com>
* Emil Stenström <emil@emilstenstrom.se>
* Roxane Bellott <roxane.bellot@gmail.com>
* Tomáš Chvátal <tchvatal@suse.com>
* Frank Hoffmann <15r10nk-git@polarbit.de>
* Éloi Rivard <eloi@yaal.coop>
* Isidro Arias <isidroariass@hotmail.es>
* Will Gibson
* Dominic Amato <dominic.a.amato@gmail.com>
* A_A
* Luzin Boris <borisluzin2004@gmail.com>
