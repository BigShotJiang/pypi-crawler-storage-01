# Overview

ML / AI code.

# Notable packages

- **[cli](cli)** (cli: `om mc`) - A general purpose ai cli, inspired and in the spirit of
  [simonw's](https://github.com/simonw/llm) and others.

- **[minichain](minichain)** - *A thing that does the things langchain people use langchain to do.*
