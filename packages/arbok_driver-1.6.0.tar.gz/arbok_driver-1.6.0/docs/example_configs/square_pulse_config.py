square_pulse_conf = {
    'amplitude': {
        'value': 0.5,
        'unit': 'V',
    },
    't_square_pulse': {
        'value': 100,
        'unit': 'cycles'
    },
    'element': {
        'value': 'gate_1',
        'unit': 'gate label'
    }
}