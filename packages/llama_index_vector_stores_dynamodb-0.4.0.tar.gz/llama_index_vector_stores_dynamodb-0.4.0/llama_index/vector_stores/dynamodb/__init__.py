from llama_index.vector_stores.dynamodb.base import DynamoDBVectorStore

__all__ = ["DynamoDBVectorStore"]
