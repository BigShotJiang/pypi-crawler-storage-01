# LlamaIndex Vector_Stores Integration: Dynamodb
