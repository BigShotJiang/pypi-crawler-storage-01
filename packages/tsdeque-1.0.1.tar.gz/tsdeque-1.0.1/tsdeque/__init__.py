from tsdeque.core import ThreadSafeDeque
from tsdeque.logger import init_logger

__all__ = ["ThreadSafeDeque"]
__version__ = "1.0"

# init_logger()
