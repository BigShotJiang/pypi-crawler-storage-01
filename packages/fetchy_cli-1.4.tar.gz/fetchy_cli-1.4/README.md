# fetchy-cli
Fetch strings from your terminal!
