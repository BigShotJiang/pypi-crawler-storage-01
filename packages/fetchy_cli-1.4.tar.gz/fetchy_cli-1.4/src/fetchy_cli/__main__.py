# Copyright (c) 2024, espehon
# License: https://www.gnu.org/licenses/gpl-3.0.html

import sys

from fetchy import cli

if __name__ == "__main__":
    sys.exit(cli())