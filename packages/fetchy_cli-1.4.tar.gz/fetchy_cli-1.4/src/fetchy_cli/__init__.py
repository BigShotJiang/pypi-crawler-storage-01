# Copyright (c) 2024, espehon
# License: https://www.gnu.org/licenses/gpl-3.0.html
