"""
全局应用状态和依赖项
"""
from typing import Dict, Any

# 全局应用状态
app_state: Dict[str, Any] = {} 
