"""
Provide a sub-app for interacting with Applications data.
"""
