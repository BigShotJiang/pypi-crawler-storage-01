"""Util methods for variable definitions."""
