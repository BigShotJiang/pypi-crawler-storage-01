"""Utils for validating ssb standards."""
