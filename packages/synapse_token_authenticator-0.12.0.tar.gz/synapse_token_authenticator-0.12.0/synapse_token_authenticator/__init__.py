from synapse_token_authenticator.token_authenticator import (
    TokenAuthenticator,  # noqa: F401
)
