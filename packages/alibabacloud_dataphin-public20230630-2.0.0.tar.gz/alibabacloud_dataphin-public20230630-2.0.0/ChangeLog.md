2025-04-28 Version: 1.4.0
- Support API CreateDataServiceApi.
- Support API CreateRowPermission.
- Support API DeleteRowPermission.
- Support API GetAccountByRowPermissionId.
- Support API GetTableColumnLineageByTaskId.
- Support API GetTableLineageByTaskId.
- Support API ListRowPermission.
- Support API ListRowPermissionByUserId.
- Support API SyncDepartment.
- Support API SyncDepartmentUser.
- Support API UpdateRowPermission.


2025-04-17 Version: 1.3.0
- Support API ListApiByApp.


2025-04-16 Version: 1.2.1
- Generated python 2023-06-30 for dataphin-public.

2025-03-07 Version: 1.2.0
- Support API GetSparkLocalClientInfo.
- Support API ListAuthorizedDataServiceApiDetails.
- Update API OperateInstance: update param OperateCommand.


2024-12-30 Version: 1.1.0
- Support API CreateBatchTask.
- Support API CreateBizEntity.
- Support API CreateBizUnit.
- Support API CreateDataDomain.
- Support API CreatePipelineNode.
- Support API CreateStreamBatchJobMapping.
- Support API DeleteBatchTask.
- Support API DeleteBizEntity.
- Support API DeleteBizUnit.
- Support API DeleteDataDomain.
- Support API ExecuteAdHocTask.
- Support API GetAdHocTaskLog.
- Support API GetAdHocTaskResult.
- Support API GetAlertEvent.
- Support API GetBatchTaskInfo.
- Support API GetBatchTaskInfoByVersion.
- Support API GetBatchTaskUdfLineages.
- Support API GetBatchTaskVersions.
- Support API GetBizEntityInfo.
- Support API GetBizEntityInfoByVersion.
- Support API GetBizUnitInfo.
- Support API GetClusterQueueInfoByEnv.
- Support API GetDataDomainInfo.
- Support API GetDirectoryTree.
- Support API GetLatestSubmitDetail.
- Support API GetQueueEngineVersionByEnv.
- Support API ListAlertEvents.
- Support API ListAlertNotifications.
- Support API ListBizEntities.
- Support API ListBizUnits.
- Support API ListDataDomains.
- Support API ListPublishRecords.
- Support API ListSubmitRecords.
- Support API OfflineBatchTask.
- Support API OfflineBizEntity.
- Support API OnlineBizEntity.
- Support API ParseBatchTaskDependency.
- Support API PublishObjectList.
- Support API StopAdHocTask.
- Support API SubmitBatchTask.
- Support API UpdateBatchTask.
- Support API UpdateBatchTaskUdfLineages.
- Support API UpdateBizEntity.
- Support API UpdateBizUnit.
- Support API UpdateDataDomain.


2024-10-11 Version: 1.0.0
- Generated python 2023-06-30 for dataphin-public.

