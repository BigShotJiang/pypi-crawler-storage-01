---
name: Alternative API Documentation Tool Proposal
about: Suggest a new API documentation tool for this project
title: 'Proposal: '
labels: 'tool-proposal'
assignees: 'hasansezertasan'

---

**Link to this tool**
A link to the tool's website or repository.

**Does this tool have a CDN?**
Yes/No

**Additional context**
Add any other context or screenshots about the feature request here.
