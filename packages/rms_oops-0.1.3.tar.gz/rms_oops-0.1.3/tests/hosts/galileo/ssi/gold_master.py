################################################################################
# tests/hosts/galileo/ssi/gold_master.py
################################################################################

import oops.gold_master as gm
from tests.hosts.galileo.ssi import standard_obs

if __name__ == '__main__':
    gm.execute_as_command()

################################################################################
