################################################################################
# tests/hosts/cassini/unittester.py
################################################################################

import unittest

from tests.hosts.cassini.iss  import Test_Cassini_ISS_GoldMaster
# from tests.hosts.cassini.uvis import Test_Cassini_UVIS_GoldMaster
# from tests.hosts.cassini.vims import Test_Cassini_VIMS_GoldMaster

########################################
if __name__ == '__main__':
    unittest.main(verbosity=2)
################################################################################
