################################################################################
# tests/hosts/cassini/iss/gold_master.py
################################################################################

import oops.gold_master as gm
from tests.hosts.cassini.iss import standard_obs

if __name__ == '__main__':
    gm.execute_as_command()

################################################################################
