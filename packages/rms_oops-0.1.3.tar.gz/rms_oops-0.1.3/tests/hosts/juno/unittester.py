################################################################################
# oops/hosts/juno/unittester.py
################################################################################

import unittest

from oops.hosts.juno.junocam import Test_Juno_Junocam_GoldMaster
#from oops.hosts.juno.jiram   import Test_Juno_JIRAM_GoldMaster

########################################
if __name__ == '__main__':
    unittest.main(verbosity=2)
################################################################################
