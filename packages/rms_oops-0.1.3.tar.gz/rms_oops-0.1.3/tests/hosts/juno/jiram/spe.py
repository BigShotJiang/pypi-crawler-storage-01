################################################################################
# tests/hosts/juno/jiram/spe.py
################################################################################

import unittest
import oops.backplane.gold_master as gm
import oops.hosts.juno.jiram as jiram

from oops.unittester_support    import TEST_DATA_PREFIX


#===============================================================================
class Test_Juno_JIRAM_IMG(unittest.TestCase):

    #===========================================================================
    def runTest(self):
        pass


##############################################
if __name__ == '__main__':
    unittest.main(verbosity=2)
################################################################################
