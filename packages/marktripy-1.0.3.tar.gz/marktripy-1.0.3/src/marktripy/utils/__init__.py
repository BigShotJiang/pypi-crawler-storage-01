# this_file: marktripy/utils/__init__.py
"""Utility functions for marktripy."""
