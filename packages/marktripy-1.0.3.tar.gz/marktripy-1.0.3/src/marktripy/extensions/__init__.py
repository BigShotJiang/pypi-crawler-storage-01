# this_file: marktripy/extensions/__init__.py
"""Extension system for marktripy."""
