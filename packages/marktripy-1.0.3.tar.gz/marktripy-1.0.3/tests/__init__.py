# this_file: tests/__init__.py
"""Test suite for marktripy."""
