"""Linxura devices."""

LINXURA = "Linxura"
