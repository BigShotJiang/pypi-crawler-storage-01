"""Module for Netvox quirks implementations."""
