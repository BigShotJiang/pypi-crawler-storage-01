"""Human interface module for SPADE_LLM."""

from .web_server import run_server

__all__ = ["run_server"]
