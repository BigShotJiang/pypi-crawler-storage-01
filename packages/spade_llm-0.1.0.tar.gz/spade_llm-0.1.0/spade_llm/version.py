"""Version information for SPADE_LLM."""

__version__ = "0.1.0"
