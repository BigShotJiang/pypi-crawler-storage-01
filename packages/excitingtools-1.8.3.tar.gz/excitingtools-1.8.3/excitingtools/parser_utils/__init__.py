from excitingtools.parser_utils.erroneous_file_error import ErroneousFileError

__all__ = ["ErroneousFileError"]
