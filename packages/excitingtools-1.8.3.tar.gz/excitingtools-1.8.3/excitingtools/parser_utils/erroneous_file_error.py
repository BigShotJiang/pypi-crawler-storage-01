class ErroneousFileError(Exception):
    pass
