from enum import Enum


class AgentMode(Enum):
    OFF = "off"
    ON = "on" 