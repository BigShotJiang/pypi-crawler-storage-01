"""
User interfaces
"""

# This seems to be required? Some tests fail with:
# AttributeError: module 'upsies.uis' has no attribute 'prompts'
from . import prompts
