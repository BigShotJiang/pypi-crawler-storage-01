from yt_dlp_bonus.cli import app

app()
