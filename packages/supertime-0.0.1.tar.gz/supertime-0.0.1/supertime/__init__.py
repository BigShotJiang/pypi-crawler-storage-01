from supertime.function import supersleep  # noqa: F401
