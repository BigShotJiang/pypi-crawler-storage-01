# Subcommands package for vibectl-server CLI

# Intentionally left empty - modules will register their
# click groups in vibectl.server.main.
