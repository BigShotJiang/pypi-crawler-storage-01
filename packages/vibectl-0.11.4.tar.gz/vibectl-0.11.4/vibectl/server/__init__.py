"""vibectl server implementation."""
