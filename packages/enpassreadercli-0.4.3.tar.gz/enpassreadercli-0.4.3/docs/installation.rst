.. include:: ../INSTALLATION.rst
