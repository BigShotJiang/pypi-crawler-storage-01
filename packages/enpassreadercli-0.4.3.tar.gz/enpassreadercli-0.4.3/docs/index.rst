.. enpassreadercli documentation master file, created by
   sphinx-quickstart on 2021-03-27.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to enpassreadercli's documentation!
===========================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   contributing
   modules
   authors
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

