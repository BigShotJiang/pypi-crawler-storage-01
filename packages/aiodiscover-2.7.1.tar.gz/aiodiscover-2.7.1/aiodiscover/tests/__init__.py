"""Unit test package for aiodiscover."""
