"""
**This sub-package is a work in progress to encapsulate pythonic object-oriented CRSD structure 1.0.0
"""

__classification__ = "UNCLASSIFIED"
