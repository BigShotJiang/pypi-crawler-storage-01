"""
**This sub-package is a work in progress to encapsulate pythonic object-oriented CPHD structure 1.0.1
"""

__classification__ = "UNCLASSIFIED"
