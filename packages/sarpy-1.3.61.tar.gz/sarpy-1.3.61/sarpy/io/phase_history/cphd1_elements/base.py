

__classification__ = "UNCLASSIFIED"
__author__ = "Thomas McCullough"

DEFAULT_STRICT = False
FLOAT_FORMAT = '0.17E'
