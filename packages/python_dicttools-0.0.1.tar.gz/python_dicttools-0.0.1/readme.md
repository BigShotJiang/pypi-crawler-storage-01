# Python dictionary tools.

## Installation

You can install from [pypi](https://pypi.org/project/python-dicttools/)

```console
pip install -U python-dicttools
```

## Usage

```python
import dicttools
```
