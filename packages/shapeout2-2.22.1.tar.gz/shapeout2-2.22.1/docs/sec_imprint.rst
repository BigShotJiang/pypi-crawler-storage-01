.. _imprint:

Imprint/Impressum
=================

Imprint and disclaimer
----------------------
For more information, please refer to the imprint and disclaimer
(Impressum und Haftungsausschluss) at
https://www.zellmechanik.com/Imprint.html.


Privacy policy
--------------
This documentation is hosted on https://readthedocs.org/ whose `privacy
policy <https://docs.readthedocs.io/en/latest/privacy-policy.html>`_ applies.
