=========
Changelog
=========
List of changes in-between Shape-Out releases.

.. include_changelog:: ../CHANGELOG
