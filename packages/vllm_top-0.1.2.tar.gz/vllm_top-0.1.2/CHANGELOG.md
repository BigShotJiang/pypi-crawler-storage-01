# CHANGELOG.md

# Changelog

## [Unreleased]

## [0.1.0]
### Added
- Initial release of the vllm-top package.
- Implemented the VLLM_TOP class for monitoring vLLM metrics.
- Added methods for fetching, displaying, and averaging metrics.
- Created a command-line interface for one-time and continuous monitoring.

## [0.1.1]
### Changed
- Improved UI

## [0.1.2]
### Added
- Added port specification
