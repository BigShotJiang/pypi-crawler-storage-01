# SteadyText Benchmark Report

**Generated**: 2025-06-23 18:44:04

---


## Accuracy Benchmarks

**Test Date**: 2025-06-23T18:41:42.389744

### Simple Accuracy Tests

#### Determinism
- All outputs deterministic: ✓
- Determinism rate: 100.0%

#### Quality Checks

- code_generation: ✓
- explanation_length: ✗

#### Embedding Quality
- Similar text similarity: 0.694
- Different text similarity: 0.466
- Similarity ordering correct: ✓
