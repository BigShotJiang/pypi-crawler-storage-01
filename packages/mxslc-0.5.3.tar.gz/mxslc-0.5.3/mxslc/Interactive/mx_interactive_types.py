import MaterialX as mx
from ..mx_wrapper import Uniform

type Value = mx.Node | Uniform
