#!/bin/bash

printf '%s' '<speci&l>"chars and contr🿾ol chars'
