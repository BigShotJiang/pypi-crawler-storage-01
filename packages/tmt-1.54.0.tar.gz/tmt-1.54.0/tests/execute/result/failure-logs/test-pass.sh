#!/bin/bash
. /usr/share/beakerlib/beakerlib.sh || exit 1

rlJournalStart
    rlPhaseStartTest "Passing beakerlib test"
        rlRun "echo \"Some output\""
        rlRun "true"
    rlPhaseEnd
rlJournalEnd
