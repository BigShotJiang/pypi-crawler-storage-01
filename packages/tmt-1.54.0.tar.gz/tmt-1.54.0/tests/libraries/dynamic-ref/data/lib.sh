#!/bin/bash
#   library-prefix = first

firstWorks(){
  echo yes
}

firstLibraryLoaded(){
  return 0
}
