#!/bin/bash

echo "A simple test for importing target run having multiple lines"
