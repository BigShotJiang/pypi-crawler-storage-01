#!/bin/bash -e

test "$(whoami)" == "fedora"
