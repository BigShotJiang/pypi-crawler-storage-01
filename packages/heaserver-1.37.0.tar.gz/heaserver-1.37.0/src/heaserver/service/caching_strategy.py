from abc import ABC


class CachingStrategy(ABC):
    pass
