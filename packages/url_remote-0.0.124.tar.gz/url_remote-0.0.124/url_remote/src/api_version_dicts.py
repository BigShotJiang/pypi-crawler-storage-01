# TODO I think we have it both here and on another file authentication_api_version_dict.py - Let's have one copy
# TODO Shall we have one file for all those VERSION_DICTs or file per API? - I think we can have one file.
AUTHENTICATION_API_VERSION_DICT = {"play1": 1, "dvlp1": 1}

EVENT_API_VERSION_DICT = {"local": 1, "play1": 1, "dvlp1": 1}

# TODO Please also add SMARTLINK_API_VERSION_DICT
SMARTLINK_API_VERSION_DICT = {"play1": 1, "dvlp1": 1}

USER_REGISTRATION_API_VERSION_DICT = {"play1": 1, "dvlp1": 1}

GROUP_API_VERSION_DICT = {"play1": 1, "dvlp1": 1}

GENDER_API_VERSION_DICT = {"play1": 1, "dvlp1": 1}

LOGGER_API_VERSION_DICT = {"play1": 1, "dvlp1": 1}

GROUP_PROFILE_API_VERSION_DICT = {"play1": 1, "dvlp1": 1}
