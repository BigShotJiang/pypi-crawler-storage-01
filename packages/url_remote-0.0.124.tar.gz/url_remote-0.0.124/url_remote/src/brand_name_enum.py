from enum import Enum


class BrandName(Enum):
    CIRCLEZ = "Circlez"
