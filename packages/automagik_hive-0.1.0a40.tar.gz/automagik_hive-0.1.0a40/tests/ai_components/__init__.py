"""AI components test package."""
