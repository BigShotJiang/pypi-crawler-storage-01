"""SatNOGS Network Auth0 login module models"""
# from django.db import models

# Create your models here.
