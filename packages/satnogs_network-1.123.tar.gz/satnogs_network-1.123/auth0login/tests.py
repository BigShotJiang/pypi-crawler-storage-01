"""SatNOGS Network Auth0 login module test suites"""
# from django.test import TestCase

# Create your tests here.
