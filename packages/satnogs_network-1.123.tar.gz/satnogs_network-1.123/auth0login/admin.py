"""SatNOGS Network Auth0 login module admin class"""
# from django.contrib import admin

# Register your models here.
