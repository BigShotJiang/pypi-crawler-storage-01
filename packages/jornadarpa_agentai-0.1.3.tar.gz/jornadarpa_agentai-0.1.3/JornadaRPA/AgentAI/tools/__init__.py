from .tools_basic import tool_calc

def get_tools():
    return {
        "calc": tool_calc
    }