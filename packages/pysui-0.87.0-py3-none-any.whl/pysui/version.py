#    Copyright Frank V. Castellucci
#    SPDX-License-Identifier: Apache-2.0

# -*- coding: utf-8 -*-

# Read in command line and posting to PyPi
__version__ = "0.87.0"
"""Pysui Version."""
