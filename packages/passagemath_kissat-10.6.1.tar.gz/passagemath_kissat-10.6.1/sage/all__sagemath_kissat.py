# sage_setup: distribution = sagemath-kissat
# delvewheel: patch

from sage.all__sagemath_combinat import *
