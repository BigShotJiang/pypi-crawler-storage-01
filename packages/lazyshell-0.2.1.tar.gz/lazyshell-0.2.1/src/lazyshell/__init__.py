"""Lazy optional imports for Python projects."""

from .core import shell_import

__all__ = ["shell_import"]
__version__ = "0.2.0"
