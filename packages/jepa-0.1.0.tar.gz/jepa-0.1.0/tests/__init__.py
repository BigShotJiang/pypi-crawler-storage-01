"""
Test suite for JEPA framework.

This package contains comprehensive unit tests for all modules of the JEPA framework.
"""
