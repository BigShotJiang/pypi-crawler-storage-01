from qqmusic_api.utils.qimei import get_qimei


def test_get_qimei():
    get_qimei("13.2.5.8")
