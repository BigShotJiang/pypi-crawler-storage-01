import sys
sys.path.append("src/spec")

import create_extension_spec
create_extension_spec.main()
