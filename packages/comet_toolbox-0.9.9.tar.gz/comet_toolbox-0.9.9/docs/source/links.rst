.. _Nipype: https://nipype.readthedocs.io/en/latest/
.. _BIDS: https://bids.neuroimaging.io/
.. _`BIDS Derivatives`: https://bids-specification.readthedocs.io/en/stable/05-derivatives/01-introduction.html