Contributing
============

This toolbox is being developed and maintained by Micha Burkhardt.

If you have any wishes, suggestions, feedback, or encounter any bugs, please do not
hesitate to contact me via email or create an issue `here <https://github.com/mibur1/dfc-multiverse/issues>`_.

Contributions and collaboration are also welcome.