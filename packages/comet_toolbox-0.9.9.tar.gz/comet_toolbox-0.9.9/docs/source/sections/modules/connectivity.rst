comet.connectivity
------------------

.. toctree::
   :maxdepth: 4

.. automodule:: comet.connectivity
   :members:
   :undoc-members:
   :show-inheritance:
