comet.multiverse
----------------

.. toctree::
   :maxdepth: 4

.. automodule:: comet.multiverse
   :members:
   :undoc-members:
   :show-inheritance:
