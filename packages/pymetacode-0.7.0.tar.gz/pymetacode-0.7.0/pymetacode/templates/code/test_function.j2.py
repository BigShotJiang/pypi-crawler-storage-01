

class Test{{ function.name_camelcase }}(unittest.TestCase):
    def test_{{ function.name }}(self):
        pass
