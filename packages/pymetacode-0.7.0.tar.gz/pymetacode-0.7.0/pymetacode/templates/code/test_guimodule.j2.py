import unittest

from PySide6 import QtCore, QtWidgets

from {{ package.name }}.gui import {{ module.name }}
