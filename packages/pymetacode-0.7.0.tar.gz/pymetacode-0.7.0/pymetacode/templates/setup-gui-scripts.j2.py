    entry_points = {
        "gui_scripts": [
            "{{ package.name }} = {{ package.name }}.gui.app:main"
        ],
    },