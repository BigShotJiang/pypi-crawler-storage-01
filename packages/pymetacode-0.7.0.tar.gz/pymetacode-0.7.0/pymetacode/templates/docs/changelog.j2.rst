=========
Changelog
=========

This page contains a summary of changes between the official {{ package.name }} releases. Only the biggest changes are listed here.{% if package.urls.source %} A complete and detailed log of all changes is available through the `GitHub Repository Browser <{{ package.urls.source }}>`_.{% endif %}


Version 0.1.0
=============

Not yet released

* First public release

* ...

