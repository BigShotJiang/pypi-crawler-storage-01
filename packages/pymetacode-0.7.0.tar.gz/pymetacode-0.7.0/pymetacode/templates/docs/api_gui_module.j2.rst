{{ package.name }}.{{ module.name }} module
======={{ header_extension }}

.. automodule:: {{ package.name }}.{{ module.name }}
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: staticMetaObject
