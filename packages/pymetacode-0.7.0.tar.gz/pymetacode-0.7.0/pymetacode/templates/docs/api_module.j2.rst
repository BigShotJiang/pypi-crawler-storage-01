{{ package.name }}.{{ module.name }} module
======={{ header_extension }}

.. automodule:: {{ package.name }}.{{ module.name }}
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
