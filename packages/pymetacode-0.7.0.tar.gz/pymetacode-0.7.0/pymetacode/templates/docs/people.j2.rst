=============={{ rst_markup.header_equal }}
People behind {{ package.name }}
=============={{ rst_markup.header_equal }}

Who are the people behind the {{ package.name }} package?

...

