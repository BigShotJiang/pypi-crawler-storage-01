{{ subpackage.name }} subpackage
==========={{ header_extension }}

.. automodule:: {{ subpackage.name }}
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
    :maxdepth: 1

