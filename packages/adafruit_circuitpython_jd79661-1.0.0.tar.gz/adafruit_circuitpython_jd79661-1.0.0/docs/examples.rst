Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/jd79661_simpletest.py
    :caption: examples/jd79661_simpletest.py
    :linenos:
