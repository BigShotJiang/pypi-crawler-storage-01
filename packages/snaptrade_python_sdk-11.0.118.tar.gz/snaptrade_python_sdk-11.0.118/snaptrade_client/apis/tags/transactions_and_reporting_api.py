# coding: utf-8

from snaptrade_client.apis.tags.transactions_and_reporting_api_generated import TransactionsAndReportingApiGenerated

class TransactionsAndReportingApi(TransactionsAndReportingApiGenerated):
    pass
