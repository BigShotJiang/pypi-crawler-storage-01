from snaptrade_client.paths.authorizations_authorization_id_disable.post import ApiForpost


class AuthorizationsAuthorizationIdDisable(
    ApiForpost,
):
    pass
