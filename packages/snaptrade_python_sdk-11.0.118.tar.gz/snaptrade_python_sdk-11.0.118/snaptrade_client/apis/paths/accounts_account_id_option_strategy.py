from snaptrade_client.paths.accounts_account_id_option_strategy.post import ApiForpost


class AccountsAccountIdOptionStrategy(
    ApiForpost,
):
    pass
