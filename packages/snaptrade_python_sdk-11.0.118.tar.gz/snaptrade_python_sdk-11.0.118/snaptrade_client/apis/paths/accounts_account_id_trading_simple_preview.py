from snaptrade_client.paths.accounts_account_id_trading_simple_preview.post import ApiForpost


class AccountsAccountIdTradingSimplePreview(
    ApiForpost,
):
    pass
