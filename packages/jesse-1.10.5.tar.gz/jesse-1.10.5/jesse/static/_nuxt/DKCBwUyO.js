import{bH as a,O as e,a1 as t}from"./Jjv4biHX.js";const s=a((r,o)=>{if(e().plan==="free"||e().plan==="guest")return t("/")});export{s as default};
