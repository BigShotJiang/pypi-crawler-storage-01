2025-07-02 Version: 1.0.1
- Generated python 2022-10-19 for starrocks.

2025-06-30 Version: 1.0.0
- Update API ModifyCu: add request parameters PromotionOptionNo.
- Update API ModifyDiskNumber: add request parameters PromotionOptionNo.
- Update API ModifyDiskPerformanceLevel: add request parameters PromotionOptionNo.
- Update API ModifyDiskSize: add request parameters PromotionOptionNo.
- Update API ModifyNodeNumber: add request parameters PromotionOptionNo.


