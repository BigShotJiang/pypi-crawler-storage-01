"""
KRenamer - Korean Windows GUI File Renaming Tool
"""
__version__ = "1.0.0"