---
layout: default
title: "Patterns"
nav_order: 3
has_children: true
---