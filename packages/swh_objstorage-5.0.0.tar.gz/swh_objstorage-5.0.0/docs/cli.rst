.. _swh-objstorage-cli:

Command-line interface
======================

.. click:: swh.objstorage.cli:objstorage_cli_group
  :prog: swh objstorage
  :nested: full
