# quivr-core package

The RAG of Quivr.com

## License 📄

This project is licensed under the Apache 2.0 License

## Installation

```bash
pip install quivr-modified-milvus
```




