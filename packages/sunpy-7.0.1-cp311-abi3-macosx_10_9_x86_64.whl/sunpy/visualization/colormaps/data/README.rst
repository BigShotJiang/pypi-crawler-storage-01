This folder contains color table data. Each color table is in a single .csv files,
with the columns denoting red, green, blue values.
