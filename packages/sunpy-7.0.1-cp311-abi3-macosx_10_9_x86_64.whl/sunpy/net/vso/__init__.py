# for exposure to from sunpy.net.vso import *
from sunpy.net.vso.table_response import VSOQueryResponseTable
from sunpy.net.vso.vso import VSOClient

__all__ = ['VSOClient', 'VSOQueryResponseTable']
