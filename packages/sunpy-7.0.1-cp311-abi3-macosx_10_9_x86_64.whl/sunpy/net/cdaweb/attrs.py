from sunpy.net.attr import SimpleAttr

__all__ = ['Dataset']


class Dataset(SimpleAttr):
    """
    Dataset ID.
    """
