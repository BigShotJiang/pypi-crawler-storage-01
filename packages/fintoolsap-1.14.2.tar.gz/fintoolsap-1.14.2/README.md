# FinToolsAP

Author: Andrew Maurice Perry
Email: Andrewpe@berkeley.edu
Start Date: 06/20/2023

Overall Module Description:
This module implements several tools that are commonly used 
in finance and economics. Currently includes LocalDatabase and
Fama French functionally. 

Version Date: 11/06/2023
Version Updates: Production build of local database

-----------------------------------------------------------------------------------



Local Database
----------------------








