# sage_setup: distribution = sagemath-palp

from sage.all__sagemath_polyhedra import *
