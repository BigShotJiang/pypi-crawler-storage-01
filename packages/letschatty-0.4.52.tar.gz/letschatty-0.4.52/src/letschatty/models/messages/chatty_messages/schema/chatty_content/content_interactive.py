from pydantic import BaseModel

class ChattyContentInteractive(BaseModel):
    pass