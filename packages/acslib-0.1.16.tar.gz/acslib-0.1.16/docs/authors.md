{%
  include-markdown "../AUTHORS.md"
%}
