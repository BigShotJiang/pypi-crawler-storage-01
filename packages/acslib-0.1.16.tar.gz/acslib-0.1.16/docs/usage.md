# Usage

To use Access Control Systems Library in a project

```
    import acslib
```
