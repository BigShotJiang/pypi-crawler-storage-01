# Tests for snakemake-logger-plugin-rich
