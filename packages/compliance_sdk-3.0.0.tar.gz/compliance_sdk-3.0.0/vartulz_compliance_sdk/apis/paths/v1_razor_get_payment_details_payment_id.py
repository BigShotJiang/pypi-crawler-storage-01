from vartulz_compliance_sdk.paths.v1_razor_get_payment_details_payment_id.get import ApiForget


class V1RazorGetPaymentDetailsPaymentId(
    ApiForget,
):
    pass
