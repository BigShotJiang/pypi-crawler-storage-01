from vartulz_compliance_sdk.paths.v1_utility_signatory_details.post import ApiForpost


class V1UtilitySignatoryDetails(
    ApiForpost,
):
    pass
