from vartulz_compliance_sdk.paths.v1_barcode_get_bank_details.get import ApiForget


class V1BarcodeGetBankDetails(
    ApiForget,
):
    pass
