from vartulz_compliance_sdk.paths.v1_session_login.post import ApiForpost


class V1SessionLogin(
    ApiForpost,
):
    pass
