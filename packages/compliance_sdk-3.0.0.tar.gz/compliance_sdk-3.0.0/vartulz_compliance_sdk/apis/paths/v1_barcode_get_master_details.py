from vartulz_compliance_sdk.paths.v1_barcode_get_master_details.get import ApiForget


class V1BarcodeGetMasterDetails(
    ApiForget,
):
    pass
