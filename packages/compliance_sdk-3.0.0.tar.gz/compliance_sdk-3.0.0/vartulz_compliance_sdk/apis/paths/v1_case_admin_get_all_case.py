from vartulz_compliance_sdk.paths.v1_case_admin_get_all_case.get import ApiForget


class V1CaseAdminGetAllCase(
    ApiForget,
):
    pass
