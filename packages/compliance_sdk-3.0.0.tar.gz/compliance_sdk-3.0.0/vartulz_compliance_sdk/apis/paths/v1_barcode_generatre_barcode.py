from vartulz_compliance_sdk.paths.v1_barcode_generatre_barcode.get import ApiForget


class V1BarcodeGeneratreBarcode(
    ApiForget,
):
    pass
