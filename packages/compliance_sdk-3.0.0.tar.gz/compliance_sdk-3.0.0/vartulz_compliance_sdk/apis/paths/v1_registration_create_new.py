from vartulz_compliance_sdk.paths.v1_registration_create_new.post import ApiForpost


class V1RegistrationCreateNew(
    ApiForpost,
):
    pass
