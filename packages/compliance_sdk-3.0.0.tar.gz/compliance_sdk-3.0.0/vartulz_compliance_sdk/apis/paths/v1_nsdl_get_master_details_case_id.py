from vartulz_compliance_sdk.paths.v1_nsdl_get_master_details_case_id.get import ApiForget


class V1NsdlGetMasterDetailsCaseId(
    ApiForget,
):
    pass
