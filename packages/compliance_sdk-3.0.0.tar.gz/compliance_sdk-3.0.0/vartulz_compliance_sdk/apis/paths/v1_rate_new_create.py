from vartulz_compliance_sdk.paths.v1_rate_new_create.post import ApiForpost


class V1RateNewCreate(
    ApiForpost,
):
    pass
