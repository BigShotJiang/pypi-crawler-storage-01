from vartulz_compliance_sdk.paths.v1_barcode_get_aadhar_details.get import ApiForget


class V1BarcodeGetAadharDetails(
    ApiForget,
):
    pass
