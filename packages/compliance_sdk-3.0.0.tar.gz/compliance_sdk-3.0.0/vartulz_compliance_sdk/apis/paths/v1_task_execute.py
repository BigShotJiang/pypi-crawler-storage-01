from vartulz_compliance_sdk.paths.v1_task_execute.get import ApiForget


class V1TaskExecute(
    ApiForget,
):
    pass
