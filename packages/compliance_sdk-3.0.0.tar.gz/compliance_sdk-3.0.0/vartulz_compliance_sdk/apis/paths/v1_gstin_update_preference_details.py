from vartulz_compliance_sdk.paths.v1_gstin_update_preference_details.post import ApiForpost


class V1GstinUpdatePreferenceDetails(
    ApiForpost,
):
    pass
