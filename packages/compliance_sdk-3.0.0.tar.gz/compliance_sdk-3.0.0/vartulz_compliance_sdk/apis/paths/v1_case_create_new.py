from vartulz_compliance_sdk.paths.v1_case_create_new.post import ApiForpost


class V1CaseCreateNew(
    ApiForpost,
):
    pass
