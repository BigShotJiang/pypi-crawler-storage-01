from vartulz_compliance_sdk.paths.v1_utility_ret_type_getall.get import ApiForget


class V1UtilityRetTypeGetall(
    ApiForget,
):
    pass
