from vartulz_compliance_sdk.paths.v1_aadhar_get_all_aadhar.get import ApiForget


class V1AadharGetAllAadhar(
    ApiForget,
):
    pass
