from vartulz_compliance_sdk.paths.v1_company_get_details_company_code.get import ApiForget


class V1CompanyGetDetailsCompanyCode(
    ApiForget,
):
    pass
