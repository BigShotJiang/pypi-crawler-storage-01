from vartulz_compliance_sdk.paths.v1_profile_get_profile_company_id.get import ApiForget


class V1ProfileGetProfileCompanyId(
    ApiForget,
):
    pass
