from vartulz_compliance_sdk.paths.v1_rate_get_services.get import ApiForget


class V1RateGetServices(
    ApiForget,
):
    pass
