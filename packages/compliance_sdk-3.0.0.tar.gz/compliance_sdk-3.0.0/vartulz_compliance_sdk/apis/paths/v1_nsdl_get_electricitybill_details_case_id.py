from vartulz_compliance_sdk.paths.v1_nsdl_get_electricitybill_details_case_id.get import ApiForget


class V1NsdlGetElectricitybillDetailsCaseId(
    ApiForget,
):
    pass
