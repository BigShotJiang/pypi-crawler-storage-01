from vartulz_compliance_sdk.paths.v1_company_get_all_approved_rejected.get import ApiForget


class V1CompanyGetAllApprovedRejected(
    ApiForget,
):
    pass
