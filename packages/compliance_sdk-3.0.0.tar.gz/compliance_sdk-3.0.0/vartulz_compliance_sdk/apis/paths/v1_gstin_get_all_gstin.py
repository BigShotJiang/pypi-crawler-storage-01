from vartulz_compliance_sdk.paths.v1_gstin_get_all_gstin.post import ApiForpost


class V1GstinGetAllGstin(
    ApiForpost,
):
    pass
