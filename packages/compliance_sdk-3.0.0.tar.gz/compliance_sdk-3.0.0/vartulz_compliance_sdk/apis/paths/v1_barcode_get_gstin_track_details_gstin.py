from vartulz_compliance_sdk.paths.v1_barcode_get_gstin_track_details_gstin.get import ApiForget


class V1BarcodeGetGstinTrackDetailsGstin(
    ApiForget,
):
    pass
