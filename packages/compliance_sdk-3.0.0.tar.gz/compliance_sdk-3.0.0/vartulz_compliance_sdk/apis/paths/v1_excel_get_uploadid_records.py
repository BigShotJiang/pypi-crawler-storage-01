from vartulz_compliance_sdk.paths.v1_excel_get_uploadid_records.get import ApiForget


class V1ExcelGetUploadidRecords(
    ApiForget,
):
    pass
