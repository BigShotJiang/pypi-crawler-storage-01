from vartulz_compliance_sdk.paths.v1_utility_gstin_get_preference_details_gstin.get import ApiForget


class V1UtilityGstinGetPreferenceDetailsGstin(
    ApiForget,
):
    pass
