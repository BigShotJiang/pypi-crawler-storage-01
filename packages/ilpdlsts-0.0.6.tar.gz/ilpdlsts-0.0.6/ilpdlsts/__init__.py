# ilpdlsts/__init__.py
"""
ilpdlsts - Python Package for Santec Insertion Loss and Polarization Dependent Loss Swept Test System.
"""
