# IL PDL STS - Python

**Python Package for Santec Insertion Loss and Polarization Dependent Loss Swept Test System.**