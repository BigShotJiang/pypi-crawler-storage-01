To use this module, you need to:

1.  Create a sale order and set manual description in sale order lines.
2.  Confirm the order.
3.  Navigate to the delivery through the smart-button.
4.  You can check sales order line description is the same as
    description picking
