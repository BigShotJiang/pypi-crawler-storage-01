This module transfers the sales order line description to the picking
description, and allows to print such text on the picking reports. When
the sales order line description is changed, picking description is
updated.
