var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _a2, _t2, _e3, _b, _c, _d, _e2, _f;
"undefined" != typeof window && ((_a2 = window.__svelte ?? (window.__svelte = {})).v ?? (_a2.v = /* @__PURE__ */ new Set())).add("5");
let t = false;
t = true;
const e = "[!", i = {}, s = Symbol();
var n = Array.isArray, r = Array.prototype.indexOf, o = Array.from, a = Object.keys, l = Object.defineProperty, h = Object.getOwnPropertyDescriptor, c = Object.getOwnPropertyDescriptors, u = Object.prototype, d = Array.prototype, f = Object.getPrototypeOf, p = Object.isExtensible;
function m(t2) {
  return "function" == typeof t2;
}
const g = () => {
};
function v(t2) {
  return t2();
}
function b(t2) {
  for (var e2 = 0; e2 < t2.length; e2++) t2[e2]();
}
function _(t2, e2) {
  if (Array.isArray(t2)) return t2;
  if (!(Symbol.iterator in t2)) return Array.from(t2);
  const i2 = [];
  for (const s2 of t2) if (i2.push(s2), i2.length === e2) break;
  return i2;
}
const y = 32, x = 64, w = 256, k = 512, M = 1024, S = 2048, C = 4096, z = 8192, R = 16384, E = 32768, P = 65536, T = 1 << 20, L = 1 << 21, V = Symbol("$state"), O = Symbol("legacy props"), A = Symbol("");
function F(t2) {
  return t2 === this.v;
}
function N(t2, e2) {
  return t2 != t2 ? e2 == e2 : t2 !== e2 || null !== t2 && "object" == typeof t2 || "function" == typeof t2;
}
function I(t2, e2) {
  return t2 !== e2;
}
function B(t2) {
  return !N(t2, this.v);
}
function q(t2) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
let K = null;
function U(t2) {
  K = t2;
}
function G(e2, i2 = false, s2) {
  var n2 = K = { p: K, c: null, d: false, e: null, m: false, s: e2, x: null, l: null };
  t && !i2 && (K.l = { s: null, u: null, r1: [], r2: wt(false) }), we(() => {
    n2.d = true;
  });
}
function J(t2) {
  const e2 = K;
  if (null !== e2) {
    void 0 !== t2 && (e2.x = t2);
    const o2 = e2.e;
    if (null !== o2) {
      var i2 = gi, s2 = fi;
      e2.e = null;
      try {
        for (var n2 = 0; n2 < o2.length; n2++) {
          var r2 = o2[n2];
          vi(r2.effect), mi(r2.reaction), ze(r2.fn);
        }
      } finally {
        vi(i2), mi(s2);
      }
    }
    K = e2.p, e2.m = true;
  }
  return t2 || {};
}
function Q() {
  return !t || null !== K && null === K.l;
}
function tt(t2) {
  if ("object" != typeof t2 || null === t2 || V in t2) return t2;
  const e2 = f(t2);
  if (e2 !== u && e2 !== d) return t2;
  var i2 = /* @__PURE__ */ new Map(), r2 = n(t2), o2 = kt(0), a2 = fi, l2 = (t3) => {
    var e3 = fi;
    mi(a2);
    var i3 = t3();
    return mi(e3), i3;
  };
  return r2 && i2.set("length", kt(t2.length)), new Proxy(t2, { defineProperty: (t3, e3, s2) => ("value" in s2 && false !== s2.configurable && false !== s2.enumerable && false !== s2.writable || function() {
    throw new Error("https://svelte.dev/e/state_descriptors_fixed");
  }(), l2(() => {
    var t4 = i2.get(e3);
    void 0 === t4 ? (t4 = kt(s2.value), i2.set(e3, t4)) : zt(t4, s2.value, true);
  }), true), deleteProperty(t3, e3) {
    var n2 = i2.get(e3);
    if (void 0 === n2) {
      if (e3 in t3) {
        const t4 = l2(() => kt(s));
        i2.set(e3, t4), et(o2);
      }
    } else {
      if (r2 && "string" == typeof e3) {
        var a3 = i2.get("length"), h2 = Number(e3);
        Number.isInteger(h2) && h2 < a3.v && zt(a3, h2);
      }
      zt(n2, s), et(o2);
    }
    return true;
  }, get(e3, n2, r3) {
    var _a3;
    if (n2 === V) return t2;
    var o3 = i2.get(n2), a3 = n2 in e3;
    if (void 0 !== o3 || a3 && !((_a3 = h(e3, n2)) == null ? void 0 : _a3.writable) || (o3 = l2(() => kt(tt(a3 ? e3[n2] : s))), i2.set(n2, o3)), void 0 !== o3) {
      var c2 = hs(o3);
      return c2 === s ? void 0 : c2;
    }
    return Reflect.get(e3, n2, r3);
  }, getOwnPropertyDescriptor(t3, e3) {
    var n2 = Reflect.getOwnPropertyDescriptor(t3, e3);
    if (n2 && "value" in n2) {
      var r3 = i2.get(e3);
      r3 && (n2.value = hs(r3));
    } else if (void 0 === n2) {
      var o3 = i2.get(e3), a3 = o3 == null ? void 0 : o3.v;
      if (void 0 !== o3 && a3 !== s) return { enumerable: true, configurable: true, value: a3, writable: true };
    }
    return n2;
  }, has(t3, e3) {
    var _a3;
    if (e3 === V) return true;
    var n2 = i2.get(e3), r3 = void 0 !== n2 && n2.v !== s || Reflect.has(t3, e3);
    if ((void 0 !== n2 || null !== gi && (!r3 || ((_a3 = h(t3, e3)) == null ? void 0 : _a3.writable))) && (void 0 === n2 && (n2 = l2(() => kt(r3 ? tt(t3[e3]) : s)), i2.set(e3, n2)), hs(n2) === s)) return false;
    return r3;
  }, set(t3, e3, n2, a3) {
    var _a3;
    var c2 = i2.get(e3), u2 = e3 in t3;
    if (r2 && "length" === e3) for (var d2 = n2; d2 < c2.v; d2 += 1) {
      var f2 = i2.get(d2 + "");
      void 0 !== f2 ? zt(f2, s) : d2 in t3 && (f2 = l2(() => kt(s)), i2.set(d2 + "", f2));
    }
    void 0 === c2 ? u2 && !((_a3 = h(t3, e3)) == null ? void 0 : _a3.writable) || (c2 = l2(() => {
      var t4 = kt(void 0);
      return zt(t4, tt(n2)), t4;
    }), i2.set(e3, c2)) : (u2 = c2.v !== s, zt(c2, l2(() => tt(n2))));
    var p2 = Reflect.getOwnPropertyDescriptor(t3, e3);
    if ((p2 == null ? void 0 : p2.set) && p2.set.call(a3, n2), !u2) {
      if (r2 && "string" == typeof e3) {
        var m2 = i2.get("length"), g2 = Number(e3);
        Number.isInteger(g2) && g2 >= m2.v && zt(m2, g2 + 1);
      }
      et(o2);
    }
    return true;
  }, ownKeys(t3) {
    hs(o2);
    var e3 = Reflect.ownKeys(t3).filter((t4) => {
      var e4 = i2.get(t4);
      return void 0 === e4 || e4.v !== s;
    });
    for (var [n2, r3] of i2) r3.v === s || n2 in t3 || e3.push(n2);
    return e3;
  }, setPrototypeOf() {
    !function() {
      throw new Error("https://svelte.dev/e/state_prototype_fixed");
    }();
  } });
}
function et(t2, e2 = 1) {
  zt(t2, t2.v + e2);
}
function at(t2) {
  try {
    if (null !== t2 && "object" == typeof t2 && V in t2) return t2[V];
  } catch {
  }
  return t2;
}
function ct(t2, e2) {
  return Object.is(at(t2), at(e2));
}
function dt(t2) {
  var e2 = 2050, i2 = null !== fi && 2 & fi.f ? fi : null;
  null === gi || null !== i2 && 0 !== (i2.f & w) ? e2 |= w : gi.f |= T;
  return { ctx: K, deps: null, effects: null, equals: F, f: e2, fn: t2, reactions: null, rv: 0, v: null, wv: 0, parent: i2 ?? gi };
}
function mt(t2) {
  const e2 = dt(t2);
  return _i(e2), e2;
}
function gt(t2) {
  const e2 = dt(t2);
  return e2.equals = B, e2;
}
function bt(t2) {
  var e2 = t2.effects;
  if (null !== e2) {
    t2.effects = null;
    for (var i2 = 0; i2 < e2.length; i2 += 1) Ae(e2[i2]);
  }
}
function _t(t2) {
  var e2, i2 = gi;
  vi(function(t3) {
    for (var e3 = t3.parent; null !== e3; ) {
      if (!(2 & e3.f)) return e3;
      e3 = e3.parent;
    }
    return null;
  }(t2));
  try {
    bt(t2), e2 = Hi(t2);
  } finally {
    vi(i2);
  }
  return e2;
}
function yt(t2) {
  var e2 = _t(t2);
  (t2.equals(e2) || (t2.v = e2, t2.wv = Li()), oi) || ds(t2, !Pi && 0 === (t2.f & w) || null === t2.deps ? M : C);
}
const xt = /* @__PURE__ */ new Map();
function wt(t2, e2) {
  return { f: 0, v: t2, reactions: null, equals: F, rv: 0, wv: 0 };
}
function kt(t2, e2) {
  const i2 = wt(t2);
  return _i(i2), i2;
}
function Mt(e2, i2 = false) {
  var _a3;
  const s2 = wt(e2);
  return i2 || (s2.equals = B), t && null !== K && null !== K.l && ((_a3 = K.l).s ?? (_a3.s = [])).push(s2), s2;
}
function Ct(t2, e2) {
  return zt(t2, cs(() => hs(t2))), e2;
}
function zt(t2, e2, i2 = false) {
  return null !== fi && !pi && Q() && 18 & fi.f && !(bi == null ? void 0 : bi.includes(t2)) && function() {
    throw new Error("https://svelte.dev/e/state_unsafe_mutation");
  }(), Rt(t2, i2 ? tt(e2) : e2);
}
function Rt(t2, e2) {
  if (!t2.equals(e2)) {
    var i2 = t2.v;
    oi ? xt.set(t2, e2) : xt.set(t2, i2), t2.v = e2, 2 & t2.f && (0 !== (t2.f & S) && _t(t2), ds(t2, 0 === (t2.f & w) ? M : C)), t2.wv = Li(), Ot(t2, S), !Q() || null === gi || 0 === (gi.f & M) || 96 & gi.f || (null === ki ? function(t3) {
      ki = t3;
    }([t2]) : ki.push(t2));
  }
  return e2;
}
function Lt(t2, e2 = 1) {
  var i2 = hs(t2), s2 = 1 === e2 ? i2++ : i2--;
  return zt(t2, i2), s2;
}
function Ot(t2, e2) {
  var i2 = t2.reactions;
  if (null !== i2) for (var s2 = Q(), n2 = i2.length, r2 = 0; r2 < n2; r2++) {
    var o2 = i2[r2], a2 = o2.f;
    0 === (a2 & S) && ((s2 || o2 !== gi) && (ds(o2, e2), 1280 & a2 && (2 & a2 ? Ot(o2, C) : ss(o2))));
  }
}
function At(t2) {
  console.warn("https://svelte.dev/e/hydration_mismatch");
}
let It, Bt = false;
function Gt(t2) {
  Bt = t2;
}
function te(t2) {
  if (null === t2) throw At(), i;
  return It = t2;
}
function ee() {
  return te(pe(It));
}
function ie(t2) {
  if (Bt) {
    if (null !== pe(It)) throw At(), i;
    It = t2;
  }
}
function ne(t2 = 1) {
  if (Bt) {
    for (var e2 = t2, i2 = It; e2--; ) i2 = pe(i2);
    It = i2;
  }
}
function re() {
  for (var t2 = 0, i2 = It; ; ) {
    if (8 === i2.nodeType) {
      var s2 = i2.data;
      if ("]" === s2) {
        if (0 === t2) return i2;
        t2 -= 1;
      } else "[" !== s2 && s2 !== e || (t2 += 1);
    }
    var n2 = pe(i2);
    i2.remove(), i2 = n2;
  }
}
function oe(t2) {
  if (!t2 || 8 !== t2.nodeType) throw At(), i;
  return t2.data;
}
var ae, le, he, ce;
function ue() {
  if (void 0 === ae) {
    ae = window, le = /Firefox/.test(navigator.userAgent);
    var t2 = Element.prototype, e2 = Node.prototype, i2 = Text.prototype;
    he = h(e2, "firstChild").get, ce = h(e2, "nextSibling").get, p(t2) && (t2.__click = void 0, t2.__className = void 0, t2.__attributes = null, t2.__style = void 0, t2.__e = void 0), p(i2) && (i2.__t = void 0);
  }
}
function de(t2 = "") {
  return document.createTextNode(t2);
}
function fe(t2) {
  return he.call(t2);
}
function pe(t2) {
  return ce.call(t2);
}
function me(t2, e2) {
  if (!Bt) return fe(t2);
  var i2 = fe(It);
  if (null === i2) i2 = It.appendChild(de());
  else if (e2 && 3 !== i2.nodeType) {
    var s2 = de();
    return i2 == null ? void 0 : i2.before(s2), te(s2), s2;
  }
  return te(i2), i2;
}
function ge(t2, e2) {
  if (!Bt) {
    var i2 = fe(t2);
    return i2 instanceof Comment && "" === i2.data ? pe(i2) : i2;
  }
  return It;
}
function ve(t2, e2 = 1, i2 = false) {
  let s2 = Bt ? It : t2;
  for (var n2; e2--; ) n2 = s2, s2 = pe(s2);
  if (!Bt) return s2;
  var r2 = s2 == null ? void 0 : s2.nodeType;
  if (i2 && 3 !== r2) {
    var o2 = de();
    return null === s2 ? n2 == null ? void 0 : n2.after(o2) : s2.before(o2), te(o2), o2;
  }
  return te(s2), s2;
}
function be(t2) {
  t2.textContent = "";
}
function _e(t2) {
  null === gi && null === fi && function() {
    throw new Error("https://svelte.dev/e/effect_orphan");
  }(), null !== fi && 0 !== (fi.f & w) && null === gi && function() {
    throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
  }(), oi && function() {
    throw new Error("https://svelte.dev/e/effect_in_teardown");
  }();
}
function xe(t2, e2, i2, s2 = true) {
  var n2 = gi, r2 = { ctx: K, deps: null, nodes_start: null, nodes_end: null, f: t2 | S, first: null, fn: e2, last: null, next: null, parent: n2, prev: null, teardown: null, transitions: null, wv: 0 };
  if (i2) try {
    Yi(r2), r2.f |= E;
  } catch (t3) {
    throw Ae(r2), t3;
  }
  else null !== e2 && ss(r2);
  if (!(i2 && null === r2.deps && null === r2.first && null === r2.nodes_start && null === r2.teardown && !(1048704 & r2.f)) && s2 && (null !== n2 && function(t3, e3) {
    var i3 = e3.last;
    null === i3 ? e3.last = e3.first = t3 : (i3.next = t3, t3.prev = i3, e3.last = t3);
  }(r2, n2), null !== fi && 2 & fi.f)) {
    var o2 = fi;
    (o2.effects ?? (o2.effects = [])).push(r2);
  }
  return r2;
}
function we(t2) {
  const e2 = xe(8, null, false);
  return ds(e2, M), e2.teardown = t2, e2;
}
function Se(t2) {
  if (_e(), !(null !== gi && 0 !== (gi.f & y) && null !== K && !K.m)) return ze(t2);
  var e2 = K;
  (e2.e ?? (e2.e = [])).push({ fn: t2, effect: gi, reaction: fi });
}
function ze(t2) {
  return xe(4, t2, false);
}
function $e(t2, e2) {
  var i2 = K, s2 = { effect: null, ran: false };
  i2.l.r1.push(s2), s2.effect = Ee(() => {
    t2(), s2.ran || (s2.ran = true, zt(i2.l.r2, true), cs(e2));
  });
}
function De() {
  var t2 = K;
  Ee(() => {
    if (hs(t2.l.r2)) {
      for (var e2 of t2.l.r1) {
        var i2 = e2.effect;
        0 !== (i2.f & M) && ds(i2, C), Fi(i2) && Yi(i2), e2.ran = false;
      }
      t2.l.r2.v = false;
    }
  });
}
function Ee(t2) {
  return xe(8, t2, true);
}
function Pe(t2, e2 = [], i2 = dt) {
  const s2 = e2.map(i2);
  return Te(() => t2(...s2.map(hs)));
}
function Te(t2, e2 = 0) {
  return xe(24 | e2, t2, true);
}
function Le(t2, e2 = true) {
  return xe(40, t2, true, e2);
}
function Ve(t2) {
  var e2 = t2.teardown;
  if (null !== e2) {
    const t3 = oi, i2 = fi;
    ui(true), mi(null);
    try {
      e2.call(null);
    } finally {
      ui(t3), mi(i2);
    }
  }
}
function Oe(t2, e2 = false) {
  var i2 = t2.first;
  for (t2.first = t2.last = null; null !== i2; ) {
    var s2 = i2.next;
    0 !== (i2.f & x) ? i2.parent = null : Ae(i2, e2), i2 = s2;
  }
}
function Ae(t2, e2 = true) {
  var i2 = false;
  (e2 || 524288 & t2.f) && null !== t2.nodes_start && null !== t2.nodes_end && (Fe(t2.nodes_start, t2.nodes_end), i2 = true), Oe(t2, e2 && !i2), Ki(t2, 0), ds(t2, R);
  var s2 = t2.transitions;
  if (null !== s2) for (const t3 of s2) t3.stop();
  Ve(t2);
  var n2 = t2.parent;
  null !== n2 && null !== n2.first && Ne(t2), t2.next = t2.prev = t2.teardown = t2.ctx = t2.deps = t2.fn = t2.nodes_start = t2.nodes_end = null;
}
function Fe(t2, e2) {
  for (; null !== t2; ) {
    var i2 = t2 === e2 ? null : pe(t2);
    t2.remove(), t2 = i2;
  }
}
function Ne(t2) {
  var e2 = t2.parent, i2 = t2.prev, s2 = t2.next;
  null !== i2 && (i2.next = s2), null !== s2 && (s2.prev = i2), null !== e2 && (e2.first === t2 && (e2.first = s2), e2.last === t2 && (e2.last = i2));
}
function We(t2, e2) {
  var i2 = [];
  Be(t2, i2, true), Ie(i2, () => {
    Ae(t2), e2 && e2();
  });
}
function Ie(t2, e2) {
  var i2 = t2.length;
  if (i2 > 0) {
    var s2 = () => --i2 || e2();
    for (var n2 of t2) n2.out(s2);
  } else e2();
}
function Be(t2, e2, i2) {
  if (0 === (t2.f & z)) {
    if (t2.f ^= z, null !== t2.transitions) for (const s3 of t2.transitions) (s3.is_global || i2) && e2.push(s3);
    for (var s2 = t2.first; null !== s2; ) {
      var n2 = s2.next;
      Be(s2, e2, !!(0 !== (s2.f & P) || 0 !== (s2.f & y)) && i2), s2 = n2;
    }
  }
}
function je(t2) {
  He(t2, true);
}
function He(t2, e2) {
  if (0 !== (t2.f & z)) {
    t2.f ^= z, 0 === (t2.f & M) && (t2.f ^= M), Fi(t2) && (ds(t2, S), ss(t2));
    for (var i2 = t2.first; null !== i2; ) {
      var s2 = i2.next;
      He(i2, !!(0 !== (i2.f & P) || 0 !== (i2.f & y)) && e2), i2 = s2;
    }
    if (null !== t2.transitions) for (const i3 of t2.transitions) (i3.is_global || e2) && i3.in();
  }
}
const qe = "undefined" == typeof requestIdleCallback ? (t2) => setTimeout(t2, 1) : requestIdleCallback;
let Xe = [], Ke = [];
function Ue() {
  var t2 = Xe;
  Xe = [], b(t2);
}
function Ye() {
  var t2 = Ke;
  Ke = [], b(t2);
}
function Ge(t2) {
  0 === Xe.length && queueMicrotask(Ue), Xe.push(t2);
}
function Je(t2, e2) {
  for (; null !== e2; ) {
    if (128 & e2.f) try {
      return void e2.fn(t2);
    } catch {
    }
    e2 = e2.parent;
  }
  throw t2;
}
let Qe = false, Ze = null, ii = false, oi = false;
function ui(t2) {
  oi = t2;
}
let di = [], fi = null, pi = false;
function mi(t2) {
  fi = t2;
}
let gi = null;
function vi(t2) {
  gi = t2;
}
let bi = null;
function _i(t2) {
  null !== fi && fi.f & L && (null === bi ? bi = [t2] : bi.push(t2));
}
let xi = null, wi = 0, ki = null;
let Si = 1, Ei = 0, Pi = false;
function Li() {
  return ++Si;
}
function Fi(t2) {
  var _a3;
  var e2 = t2.f;
  if (0 !== (e2 & S)) return true;
  if (0 !== (e2 & C)) {
    var i2 = t2.deps, s2 = 0 !== (e2 & w);
    if (null !== i2) {
      var n2, r2, o2 = 0 !== (e2 & k), a2 = s2 && null !== gi && !Pi, l2 = i2.length;
      if (o2 || a2) {
        var h2 = t2, c2 = h2.parent;
        for (n2 = 0; n2 < l2; n2++) r2 = i2[n2], !o2 && ((_a3 = r2 == null ? void 0 : r2.reactions) == null ? void 0 : _a3.includes(h2)) || (r2.reactions ?? (r2.reactions = [])).push(h2);
        o2 && (h2.f ^= k), a2 && null !== c2 && 0 === (c2.f & w) && (h2.f ^= w);
      }
      for (n2 = 0; n2 < l2; n2++) if (Fi(r2 = i2[n2]) && yt(r2), r2.wv > t2.wv) return true;
    }
    s2 && (null === gi || Pi) || ds(t2, M);
  }
  return false;
}
function Ii(t2, e2, i2 = true) {
  var s2 = t2.reactions;
  if (null !== s2) for (var n2 = 0; n2 < s2.length; n2++) {
    var r2 = s2[n2];
    (bi == null ? void 0 : bi.includes(t2)) || (2 & r2.f ? Ii(r2, e2, false) : e2 === r2 && (i2 ? ds(r2, S) : 0 !== (r2.f & M) && ds(r2, C), ss(r2)));
  }
}
function Hi(t2) {
  var _a3;
  var e2 = xi, i2 = wi, s2 = ki, n2 = fi, r2 = Pi, o2 = bi, a2 = K, l2 = pi, h2 = t2.f;
  xi = null, wi = 0, ki = null, Pi = 0 !== (h2 & w) && (pi || !ii || null === fi), fi = 96 & h2 ? null : t2, bi = null, U(t2.ctx), pi = false, Ei++, t2.f |= L;
  try {
    var c2 = (0, t2.fn)(), u2 = t2.deps;
    if (null !== xi) {
      var d2;
      if (Ki(t2, wi), null !== u2 && wi > 0) for (u2.length = wi + xi.length, d2 = 0; d2 < xi.length; d2++) u2[wi + d2] = xi[d2];
      else t2.deps = u2 = xi;
      if (!Pi) for (d2 = wi; d2 < u2.length; d2++) ((_a3 = u2[d2]).reactions ?? (_a3.reactions = [])).push(t2);
    } else null !== u2 && wi < u2.length && (Ki(t2, wi), u2.length = wi);
    if (Q() && null !== ki && !pi && null !== u2 && !(6146 & t2.f)) for (d2 = 0; d2 < ki.length; d2++) Ii(ki[d2], t2);
    return null !== n2 && n2 !== t2 && (Ei++, null !== ki && (null === s2 ? s2 = ki : s2.push(...ki))), c2;
  } catch (t3) {
    !function(t4) {
      var e3 = gi;
      if (0 === (e3.f & E)) {
        if (!(128 & e3.f)) throw t4;
        e3.fn(t4);
      } else Je(t4, e3);
    }(t3);
  } finally {
    xi = e2, wi = i2, ki = s2, fi = n2, Pi = r2, bi = o2, U(a2), pi = l2, t2.f ^= L;
  }
}
function Xi(t2, e2) {
  let i2 = e2.reactions;
  if (null !== i2) {
    var s2 = r.call(i2, t2);
    if (-1 !== s2) {
      var n2 = i2.length - 1;
      0 === n2 ? i2 = e2.reactions = null : (i2[s2] = i2[n2], i2.pop());
    }
  }
  null === i2 && 2 & e2.f && (null === xi || !xi.includes(e2)) && (ds(e2, C), 768 & e2.f || (e2.f ^= k), bt(e2), Ki(e2, 0));
}
function Ki(t2, e2) {
  var i2 = t2.deps;
  if (null !== i2) for (var s2 = e2; s2 < i2.length; s2++) Xi(t2, i2[s2]);
}
function Yi(t2) {
  var e2 = t2.f;
  if (0 === (e2 & R)) {
    ds(t2, M);
    var i2 = gi, s2 = ii;
    gi = t2, ii = true;
    try {
      16 & e2 ? function(t3) {
        for (var e3 = t3.first; null !== e3; ) {
          var i3 = e3.next;
          0 === (e3.f & y) && Ae(e3), e3 = i3;
        }
      }(t2) : Oe(t2), Ve(t2);
      var n2 = Hi(t2);
      t2.teardown = "function" == typeof n2 ? n2 : null, t2.wv = Si;
    } finally {
      ii = s2, gi = i2;
    }
  }
}
function Zi() {
  try {
    !function() {
      throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
    }();
  } catch (t2) {
    if (null === Ze) throw t2;
    Je(t2, Ze);
  }
}
function ts() {
  var t2 = ii;
  try {
    var e2 = 0;
    for (ii = true; di.length > 0; ) {
      e2++ > 1e3 && Zi();
      var i2 = di, s2 = i2.length;
      di = [];
      for (var n2 = 0; n2 < s2; n2++) {
        es(ns(i2[n2]));
      }
      xt.clear();
    }
  } finally {
    Qe = false, ii = t2, Ze = null;
  }
}
function es(t2) {
  var e2 = t2.length;
  if (0 !== e2) for (var i2 = 0; i2 < e2; i2++) {
    var s2 = t2[i2];
    24576 & s2.f || Fi(s2) && (Yi(s2), null === s2.deps && null === s2.first && null === s2.nodes_start && (null === s2.teardown ? Ne(s2) : s2.fn = null));
  }
}
function ss(t2) {
  Qe || (Qe = true, queueMicrotask(ts));
  for (var e2 = Ze = t2; null !== e2.parent; ) {
    var i2 = (e2 = e2.parent).f;
    if (96 & i2) {
      if (0 === (i2 & M)) return;
      e2.f ^= M;
    }
  }
  di.push(e2);
}
function ns(t2) {
  for (var e2 = [], i2 = t2; null !== i2; ) {
    var s2 = i2.f, n2 = !!(96 & s2);
    if (!(n2 && 0 !== (s2 & M)) && 0 === (s2 & z)) {
      4 & s2 ? e2.push(i2) : n2 ? i2.f ^= M : Fi(i2) && Yi(i2);
      var r2 = i2.first;
      if (null !== r2) {
        i2 = r2;
        continue;
      }
    }
    var o2 = i2.parent;
    for (i2 = i2.next; null === i2 && null !== o2; ) i2 = o2.next, o2 = o2.parent;
  }
  return e2;
}
function rs(t2) {
  for (; ; ) {
    if (Xe.length > 0 && Ue(), Ke.length > 0 && Ye(), 0 === di.length) return Qe = false, void (Ze = null);
    Qe = true, ts();
  }
}
async function ls() {
  await Promise.resolve(), rs();
}
function hs(t2) {
  var e2 = !!(2 & t2.f);
  if (null === fi || pi) {
    if (e2 && null === t2.deps && null === t2.effects) {
      var i2 = t2, s2 = i2.parent;
      null !== s2 && 0 === (s2.f & w) && (i2.f ^= w);
    }
  } else if (!(bi == null ? void 0 : bi.includes(t2))) {
    var n2 = fi.deps;
    t2.rv < Ei && (t2.rv = Ei, null === xi && null !== n2 && n2[wi] === t2 ? wi++ : null === xi ? xi = [t2] : Pi && xi.includes(t2) || xi.push(t2));
  }
  return e2 && Fi(i2 = t2) && yt(i2), oi && xt.has(t2) ? xt.get(t2) : t2.v;
}
function cs(t2) {
  var e2 = pi;
  try {
    return pi = true, t2();
  } finally {
    pi = e2;
  }
}
const us = -7169;
function ds(t2, e2) {
  t2.f = t2.f & us | e2;
}
function fs(t2) {
  if ("object" == typeof t2 && t2 && !(t2 instanceof EventTarget)) {
    if (V in t2) ms(t2);
    else if (!Array.isArray(t2)) for (let e2 in t2) {
      const i2 = t2[e2];
      "object" == typeof i2 && i2 && V in i2 && ms(i2);
    }
  }
}
function ms(t2, e2 = /* @__PURE__ */ new Set()) {
  if (!("object" != typeof t2 || null === t2 || t2 instanceof EventTarget || e2.has(t2))) {
    e2.add(t2), t2 instanceof Date && t2.getTime();
    for (let i3 in t2) try {
      ms(t2[i3], e2);
    } catch (t3) {
    }
    const i2 = f(t2);
    if (i2 !== Object.prototype && i2 !== Array.prototype && i2 !== Map.prototype && i2 !== Set.prototype && i2 !== Date.prototype) {
      const e3 = c(i2);
      for (let i3 in e3) {
        const s2 = e3[i3].get;
        if (s2) try {
          s2.call(t2);
        } catch (t3) {
        }
      }
    }
  }
}
function gs(t2, e2) {
  if (e2) {
    const e3 = document.body;
    t2.autofocus = true, Ge(() => {
      document.activeElement === e3 && t2.focus();
    });
  }
}
let vs = false;
function bs() {
  vs || (vs = true, document.addEventListener("reset", (t2) => {
    Promise.resolve().then(() => {
      var _a3;
      if (!t2.defaultPrevented) for (const e2 of t2.target.elements) (_a3 = e2.__on_r) == null ? void 0 : _a3.call(e2);
    });
  }, { capture: true }));
}
function _s(t2) {
  var e2 = fi, i2 = gi;
  mi(null), vi(null);
  try {
    return t2();
  } finally {
    mi(e2), vi(i2);
  }
}
function ys(t2, e2, i2, s2 = i2) {
  t2.addEventListener(e2, () => _s(i2));
  const n2 = t2.__on_r;
  t2.__on_r = n2 ? () => {
    n2(), s2(true);
  } : () => s2(true), bs();
}
const xs = /* @__PURE__ */ new Set(), ws = /* @__PURE__ */ new Set();
function ks(t2, e2, i2, s2 = {}) {
  function n2(t3) {
    if (s2.capture || zs.call(e2, t3), !t3.cancelBubble) return _s(() => i2 == null ? void 0 : i2.call(this, t3));
  }
  return t2.startsWith("pointer") || t2.startsWith("touch") || "wheel" === t2 ? Ge(() => {
    e2.addEventListener(t2, n2, s2);
  }) : e2.addEventListener(t2, n2, s2), n2;
}
function Ms(t2, e2, i2, s2, n2) {
  var r2 = { capture: s2, passive: n2 }, o2 = ks(t2, e2, i2, r2);
  (e2 === document.body || e2 === window || e2 === document || e2 instanceof HTMLMediaElement) && we(() => {
    e2.removeEventListener(t2, o2, r2);
  });
}
function Ss(t2) {
  for (var e2 = 0; e2 < t2.length; e2++) xs.add(t2[e2]);
  for (var i2 of ws) i2(t2);
}
function zs(t2) {
  var _a3;
  var e2 = this, i2 = e2.ownerDocument, s2 = t2.type, r2 = ((_a3 = t2.composedPath) == null ? void 0 : _a3.call(t2)) || [], o2 = r2[0] || t2.target, a2 = 0, h2 = t2.__root;
  if (h2) {
    var c2 = r2.indexOf(h2);
    if (-1 !== c2 && (e2 === document || e2 === window)) return void (t2.__root = e2);
    var u2 = r2.indexOf(e2);
    if (-1 === u2) return;
    c2 <= u2 && (a2 = c2);
  }
  if ((o2 = r2[a2] || t2.target) !== e2) {
    l(t2, "currentTarget", { configurable: true, get: () => o2 || i2 });
    var d2 = fi, f2 = gi;
    mi(null), vi(null);
    try {
      for (var p2, m2 = []; null !== o2; ) {
        var g2 = o2.assignedSlot || o2.parentNode || o2.host || null;
        try {
          var v2 = o2["__" + s2];
          if (null != v2 && (!o2.disabled || t2.target === o2)) if (n(v2)) {
            var [b2, ..._2] = v2;
            b2.apply(o2, [t2, ..._2]);
          } else v2.call(o2, t2);
        } catch (t3) {
          p2 ? m2.push(t3) : p2 = t3;
        }
        if (t2.cancelBubble || g2 === e2 || null === g2) break;
        o2 = g2;
      }
      if (p2) {
        for (let t3 of m2) queueMicrotask(() => {
          throw t3;
        });
        throw p2;
      }
    } finally {
      t2.__root = e2, delete t2.currentTarget, mi(d2), vi(f2);
    }
  }
}
function $s(t2) {
  var e2 = document.createElement("template");
  return e2.innerHTML = t2.replaceAll("<!>", "<!---->"), e2.content;
}
function Ds(t2, e2) {
  var i2 = gi;
  null === i2.nodes_start && (i2.nodes_start = t2, i2.nodes_end = e2);
}
function Rs(t2, e2) {
  var i2, s2 = !!(1 & e2), n2 = !!(2 & e2), r2 = !t2.startsWith("<!>");
  return () => {
    if (Bt) return Ds(It, null), It;
    void 0 === i2 && (i2 = $s(r2 ? t2 : "<!>" + t2), s2 || (i2 = fe(i2)));
    var e3 = n2 || le ? document.importNode(i2, true) : i2.cloneNode(true);
    s2 ? Ds(fe(e3), e3.lastChild) : Ds(e3, e3);
    return e3;
  };
}
function Es(t2, e2) {
  return function(t3, e3, i2 = "svg") {
    var s2, n2 = `<${i2}>${t3.startsWith("<!>") ? "<!>" + t3 : t3}</${i2}>`;
    return () => {
      if (Bt) return Ds(It, null), It;
      if (!s2) {
        var t4 = fe($s(n2));
        s2 = fe(t4);
      }
      var e4 = s2.cloneNode(true);
      return Ds(e4, e4), e4;
    };
  }(t2, 0, "svg");
}
function Ps(t2 = "") {
  if (!Bt) {
    var e2 = de(t2 + "");
    return Ds(e2, e2), e2;
  }
  var i2 = It;
  return 3 !== i2.nodeType && (i2.before(i2 = de()), te(i2)), Ds(i2, i2), i2;
}
function Ts() {
  if (Bt) return Ds(It, null), It;
  var t2 = document.createDocumentFragment(), e2 = document.createComment(""), i2 = de();
  return t2.append(e2, i2), Ds(e2, i2), t2;
}
function As(t2, e2) {
  if (Bt) return gi.nodes_end = It, void ee();
  null !== t2 && t2.before(e2);
}
function Ns(t2) {
  return t2.endsWith("capture") && "gotpointercapture" !== t2 && "lostpointercapture" !== t2;
}
const Ws = ["beforeinput", "click", "change", "dblclick", "contextmenu", "focusin", "focusout", "input", "keydown", "keyup", "mousedown", "mousemove", "mouseout", "mouseover", "mouseup", "pointerdown", "pointermove", "pointerout", "pointerover", "pointerup", "touchend", "touchmove", "touchstart"];
function Is(t2) {
  return Ws.includes(t2);
}
const Bs = { formnovalidate: "formNoValidate", ismap: "isMap", nomodule: "noModule", playsinline: "playsInline", readonly: "readOnly", defaultvalue: "defaultValue", defaultchecked: "defaultChecked", srcobject: "srcObject", novalidate: "noValidate", allowfullscreen: "allowFullscreen", disablepictureinpicture: "disablePictureInPicture", disableremoteplayback: "disableRemotePlayback" };
function js(t2) {
  return t2 = t2.toLowerCase(), Bs[t2] ?? t2;
}
const Hs = ["touchstart", "touchmove"];
const qs = ["textarea", "script", "style", "title"];
let Xs = true;
function Ks(t2) {
  Xs = t2;
}
function Us(t2, e2) {
  var i2 = null == e2 ? "" : "object" == typeof e2 ? e2 + "" : e2;
  i2 !== (t2.__t ?? (t2.__t = t2.nodeValue)) && (t2.__t = i2, t2.nodeValue = i2 + "");
}
function Ys(t2, e2) {
  return Qs(t2, e2);
}
function Gs(t2, e2) {
  ue(), e2.intro = e2.intro ?? false;
  const s2 = e2.target, n2 = Bt, r2 = It;
  try {
    for (var o2 = fe(s2); o2 && (8 !== o2.nodeType || "[" !== o2.data); ) o2 = pe(o2);
    if (!o2) throw i;
    Gt(true), te(o2), ee();
    const n3 = Qs(t2, { ...e2, anchor: o2 });
    if (null === It || 8 !== It.nodeType || "]" !== It.data) throw At(), i;
    return Gt(false), n3;
  } catch (n3) {
    if (n3 === i) return false === e2.recover && function() {
      throw new Error("https://svelte.dev/e/hydration_failed");
    }(), ue(), be(s2), Gt(false), Ys(t2, e2);
    throw n3;
  } finally {
    Gt(n2), te(r2);
  }
}
const Js = /* @__PURE__ */ new Map();
function Qs(t2, { target: e2, anchor: i2, props: s2 = {}, events: n2, context: r2, intro: a2 = true }) {
  ue();
  var l2 = /* @__PURE__ */ new Set(), h2 = (t3) => {
    for (var i3 = 0; i3 < t3.length; i3++) {
      var s3 = t3[i3];
      if (!l2.has(s3)) {
        l2.add(s3);
        var n3 = (o2 = s3, Hs.includes(o2));
        e2.addEventListener(s3, zs, { passive: n3 });
        var r3 = Js.get(s3);
        void 0 === r3 ? (document.addEventListener(s3, zs, { passive: n3 }), Js.set(s3, 1)) : Js.set(s3, r3 + 1);
      }
    }
    var o2;
  };
  h2(o(xs)), ws.add(h2);
  var c2 = void 0, u2 = function(t3) {
    const e3 = xe(x, t3, true);
    return (t4 = {}) => new Promise((i3) => {
      t4.outro ? We(e3, () => {
        Ae(e3), i3(void 0);
      }) : (Ae(e3), i3(void 0));
    });
  }(() => {
    var o2 = i2 ?? e2.appendChild(de());
    return Le(() => {
      r2 && (G({}), K.c = r2);
      n2 && (s2.$$events = n2), Bt && Ds(o2, null), Xs = a2, c2 = t2(o2, s2) || {}, Xs = true, Bt && (gi.nodes_end = It), r2 && J();
    }), () => {
      var _a3;
      for (var t3 of l2) {
        e2.removeEventListener(t3, zs);
        var s3 = Js.get(t3);
        0 === --s3 ? (document.removeEventListener(t3, zs), Js.delete(t3)) : Js.set(t3, s3);
      }
      ws.delete(h2), o2 !== i2 && ((_a3 = o2.parentNode) == null ? void 0 : _a3.removeChild(o2));
    };
  });
  return Zs.set(c2, u2), c2;
}
let Zs = /* @__PURE__ */ new WeakMap();
function en(e2) {
  null === K && q(), t && null !== K.l ? function(t2) {
    var e3 = t2.l;
    return e3.u ?? (e3.u = { a: [], b: [], m: [] });
  }(K).m.push(e2) : Se(() => {
    const t2 = cs(e2);
    if ("function" == typeof t2) return t2;
  });
}
function sn(t2) {
  null === K && q(), en(() => () => cs(t2));
}
function rn() {
  const t2 = K;
  return null === t2 && q(), (e2, i2, s2) => {
    var _a3;
    const r2 = (_a3 = t2.s.$$events) == null ? void 0 : _a3[e2];
    if (r2) {
      const o2 = n(r2) ? r2.slice() : [r2], a2 = function(t3, e3, { bubbles: i3 = false, cancelable: s3 = false } = {}) {
        return new CustomEvent(t3, { detail: e3, bubbles: i3, cancelable: s3 });
      }(e2, i2, s2);
      for (const e3 of o2) e3.call(t2.x, a2);
      return !a2.defaultPrevented;
    }
    return true;
  };
}
function on(t2, i2, [n2, r2] = [0, 0]) {
  Bt && 0 === n2 && ee();
  var o2 = t2, a2 = null, l2 = null, h2 = s, c2 = false;
  const u2 = (t3, e2 = true) => {
    c2 = true, d2(e2, t3);
  }, d2 = (t3, i3) => {
    if (h2 === (h2 = t3)) return;
    let s2 = false;
    if (Bt && -1 !== r2) {
      if (0 === n2) {
        const t4 = oe(o2);
        "[" === t4 ? r2 = 0 : t4 === e ? r2 = 1 / 0 : (r2 = parseInt(t4.substring(1))) != r2 && (r2 = h2 ? 1 / 0 : -1);
      }
      !!h2 === r2 > n2 && (te(o2 = re()), Gt(false), s2 = true, r2 = -1);
    }
    h2 ? (a2 ? je(a2) : i3 && (a2 = Le(() => i3(o2))), l2 && We(l2, () => {
      l2 = null;
    })) : (l2 ? je(l2) : i3 && (l2 = Le(() => i3(o2, [n2 + 1, r2]))), a2 && We(a2, () => {
      a2 = null;
    })), s2 && Gt(true);
  };
  Te(() => {
    c2 = false, i2(u2), c2 || d2(null, null);
  }, n2 > 0 ? P : 0), Bt && (o2 = It);
}
function an(t2, e2, i2) {
  Bt && ee();
  var n2, r2 = t2, o2 = s, a2 = Q() ? I : N;
  Te(() => {
    a2(o2, o2 = e2()) && (n2 && We(n2), n2 = Le(() => i2(r2)));
  }), Bt && (r2 = It);
}
function ln(t2, e2) {
  return e2;
}
function hn(t2, i2, s2, r2, a2, l2 = null) {
  var h2 = t2, c2 = { flags: i2, items: /* @__PURE__ */ new Map(), first: null };
  if (!!(4 & i2)) {
    var u2 = t2;
    h2 = Bt ? te(fe(u2)) : u2.appendChild(de());
  }
  Bt && ee();
  var d2 = null, f2 = false, p2 = gt(() => {
    var t3 = s2();
    return n(t3) ? t3 : null == t3 ? [] : o(t3);
  });
  Te(() => {
    var t3 = hs(p2), n2 = t3.length;
    if (f2 && 0 === n2) return;
    f2 = 0 === n2;
    let u3 = false;
    Bt && (oe(h2) === e !== (0 === n2) && (te(h2 = re()), Gt(false), u3 = true));
    if (Bt) {
      for (var m2, g2 = null, v2 = 0; v2 < n2; v2++) {
        if (8 === It.nodeType && "]" === It.data) {
          h2 = It, u3 = true, Gt(false);
          break;
        }
        var b2 = t3[v2], _2 = r2(b2, v2);
        m2 = un(It, c2, g2, null, b2, _2, v2, a2, i2, s2), c2.items.set(_2, m2), g2 = m2;
      }
      n2 > 0 && te(re());
    }
    Bt || function(t4, e2, i3, s3, n3, r3, a3) {
      var _a3, _b3, _c3, _d3;
      var l3, h3, c3, u4, d3, f3, p3 = !!(8 & n3), m3 = !!(3 & n3), g3 = t4.length, v3 = e2.items, b3 = e2.first, _3 = b3, y2 = null, x2 = [], w2 = [];
      if (p3) for (f3 = 0; f3 < g3; f3 += 1) u4 = r3(c3 = t4[f3], f3), void 0 !== (d3 = v3.get(u4)) && ((_a3 = d3.a) == null ? void 0 : _a3.measure(), (h3 ?? (h3 = /* @__PURE__ */ new Set())).add(d3));
      for (f3 = 0; f3 < g3; f3 += 1) if (u4 = r3(c3 = t4[f3], f3), void 0 !== (d3 = v3.get(u4))) {
        if (m3 && cn(d3, c3, f3, n3), 0 !== (d3.e.f & z) && (je(d3.e), p3 && ((_b3 = d3.a) == null ? void 0 : _b3.unfix(), (h3 ?? (h3 = /* @__PURE__ */ new Set())).delete(d3))), d3 !== _3) {
          if (void 0 !== l3 && l3.has(d3)) {
            if (x2.length < w2.length) {
              var k2, M2 = w2[0];
              y2 = M2.prev;
              var S2 = x2[0], C2 = x2[x2.length - 1];
              for (k2 = 0; k2 < x2.length; k2 += 1) pn(x2[k2], M2, i3);
              for (k2 = 0; k2 < w2.length; k2 += 1) l3.delete(w2[k2]);
              mn(e2, S2.prev, C2.next), mn(e2, y2, S2), mn(e2, C2, M2), _3 = M2, y2 = C2, f3 -= 1, x2 = [], w2 = [];
            } else l3.delete(d3), pn(d3, _3, i3), mn(e2, d3.prev, d3.next), mn(e2, d3, null === y2 ? e2.first : y2.next), mn(e2, y2, d3), y2 = d3;
            continue;
          }
          for (x2 = [], w2 = []; null !== _3 && _3.k !== u4; ) 0 === (_3.e.f & z) && (l3 ?? (l3 = /* @__PURE__ */ new Set())).add(_3), w2.push(_3), _3 = _3.next;
          if (null === _3) continue;
          d3 = _3;
        }
        x2.push(d3), y2 = d3, _3 = d3.next;
      } else {
        y2 = un(_3 ? _3.e.nodes_start : i3, e2, y2, null === y2 ? e2.first : y2.next, c3, u4, f3, s3, n3, a3), v3.set(u4, y2), x2 = [], w2 = [], _3 = y2.next;
      }
      if (null !== _3 || void 0 !== l3) {
        for (var R2 = void 0 === l3 ? [] : o(l3); null !== _3; ) 0 === (_3.e.f & z) && R2.push(_3), _3 = _3.next;
        var E2 = R2.length;
        if (E2 > 0) {
          var P2 = 4 & n3 && 0 === g3 ? i3 : null;
          if (p3) {
            for (f3 = 0; f3 < E2; f3 += 1) (_c3 = R2[f3].a) == null ? void 0 : _c3.measure();
            for (f3 = 0; f3 < E2; f3 += 1) (_d3 = R2[f3].a) == null ? void 0 : _d3.fix();
          }
          !function(t5, e3, i4, s4) {
            for (var n4 = [], r4 = e3.length, o2 = 0; o2 < r4; o2++) Be(e3[o2].e, n4, true);
            var a4 = r4 > 0 && 0 === n4.length && null !== i4;
            if (a4) {
              var l4 = i4.parentNode;
              be(l4), l4.append(i4), s4.clear(), mn(t5, e3[0].prev, e3[r4 - 1].next);
            }
            Ie(n4, () => {
              for (var i5 = 0; i5 < r4; i5++) {
                var n5 = e3[i5];
                a4 || (s4.delete(n5.k), mn(t5, n5.prev, n5.next)), Ae(n5.e, !a4);
              }
            });
          }(e2, R2, P2, v3);
        }
      }
      p3 && Ge(() => {
        var _a4;
        if (void 0 !== h3) for (d3 of h3) (_a4 = d3.a) == null ? void 0 : _a4.apply();
      });
      gi.first = e2.first && e2.first.e, gi.last = y2 && y2.e;
    }(t3, c2, h2, a2, i2, r2, s2), null !== l2 && (0 === n2 ? d2 ? je(d2) : d2 = Le(() => l2(h2)) : null !== d2 && We(d2, () => {
      d2 = null;
    })), u3 && Gt(true), hs(p2);
  }), Bt && (h2 = It);
}
function cn(t2, e2, i2, s2) {
  1 & s2 && Rt(t2.v, e2), 2 & s2 ? Rt(t2.i, i2) : t2.i = i2;
}
function un(t2, e2, i2, s2, n2, r2, o2, a2, l2, h2) {
  var c2 = !!(1 & l2) ? !(16 & l2) ? Mt(n2) : wt(n2) : n2, u2 = 2 & l2 ? wt(o2) : o2, d2 = { i: u2, v: c2, k: r2, a: null, e: null, prev: i2, next: s2 };
  try {
    return d2.e = Le(() => a2(t2, c2, u2, h2), Bt), d2.e.prev = i2 && i2.e, d2.e.next = s2 && s2.e, null === i2 ? e2.first = d2 : (i2.next = d2, i2.e.next = d2.e), null !== s2 && (s2.prev = d2, s2.e.prev = d2.e), d2;
  } finally {
  }
}
function pn(t2, e2, i2) {
  for (var s2 = t2.next ? t2.next.e.nodes_start : i2, n2 = e2 ? e2.e.nodes_start : i2, r2 = t2.e.nodes_start; r2 !== s2; ) {
    var o2 = pe(r2);
    n2.before(r2), r2 = o2;
  }
}
function mn(t2, e2, i2) {
  null === e2 ? t2.first = i2 : (e2.next = i2, e2.e.next = i2 && i2.e), null !== i2 && (i2.prev = e2, i2.e.prev = e2 && e2.e);
}
function vn(t2, e2, s2 = false, n2 = false, r2 = false) {
  var o2 = t2, a2 = "";
  Pe(() => {
    var t3 = gi;
    if (a2 !== (a2 = e2() ?? "")) {
      if (null !== t3.nodes_start && (Fe(t3.nodes_start, t3.nodes_end), t3.nodes_start = t3.nodes_end = null), "" !== a2) {
        if (Bt) {
          It.data;
          for (var r3 = ee(), l2 = r3; null !== r3 && (8 !== r3.nodeType || "" !== r3.data); ) l2 = r3, r3 = pe(r3);
          if (null === r3) throw At(), i;
          return Ds(It, l2), void (o2 = te(r3));
        }
        var h2 = a2 + "";
        s2 ? h2 = `<svg>${h2}</svg>` : n2 && (h2 = `<math>${h2}</math>`);
        var c2 = $s(h2);
        if ((s2 || n2) && (c2 = fe(c2)), Ds(fe(c2), c2.lastChild), s2 || n2) for (; fe(c2); ) o2.before(fe(c2));
        else o2.before(c2);
      }
    } else Bt && ee();
  });
}
function bn(t2, e2, i2, s2, n2) {
  var _a3;
  Bt && ee();
  var r2 = (_a3 = e2.$$slots) == null ? void 0 : _a3[i2], o2 = false;
  true === r2 && (r2 = e2["default" === i2 ? "children" : i2], o2 = true), void 0 === r2 ? null !== n2 && n2(t2) : r2(t2, o2 ? () => s2 : s2);
}
function _n(t2, e2, i2) {
  Bt && ee();
  var s2, n2, r2 = t2;
  Te(() => {
    s2 !== (s2 = e2()) && (n2 && (We(n2), n2 = null), s2 && (n2 = Le(() => i2(r2, s2))));
  }, P), Bt && (r2 = It);
}
function Sn(t2, e2, i2, s2, n2, r2) {
  let o2 = Bt;
  var a2, l2;
  Bt && ee();
  var h2 = null;
  Bt && 1 === It.nodeType && (h2 = It, ee());
  var c2, u2 = Bt ? It : t2;
  Te(() => {
    const t3 = e2() || null;
    t3 !== a2 && (c2 && (null === t3 ? We(c2, () => {
      c2 = null, l2 = null;
    }) : t3 === l2 ? je(c2) : (Ae(c2), Ks(false))), t3 && t3 !== l2 && (c2 = Le(() => {
      if (Ds(h2 = Bt ? h2 : document.createElementNS("http://www.w3.org/2000/svg", t3), h2), s2) {
        Bt && (i3 = t3, qs.includes(i3)) && h2.append(document.createComment(""));
        var e3 = Bt ? fe(h2) : h2.appendChild(de());
        Bt && (null === e3 ? Gt(false) : te(e3)), s2(h2, e3);
      }
      var i3;
      gi.nodes_end = h2, u2.before(h2);
    })), (a2 = t3) && (l2 = a2), Ks(true));
  }, P), o2 && (Gt(true), te(u2));
}
function Cn(t2, e2) {
  Ge(() => {
    var i2 = t2.getRootNode(), s2 = i2.host ? i2 : i2.head ?? i2.ownerDocument.head;
    if (!s2.querySelector("#" + e2.hash)) {
      const t3 = document.createElement("style");
      t3.id = e2.hash, t3.textContent = e2.code, s2.appendChild(t3);
    }
  });
}
function zn(t2, e2) {
  var i2, s2 = void 0;
  Te(() => {
    s2 !== (s2 = e2()) && (i2 && (Ae(i2), i2 = null), s2 && (i2 = Le(() => {
      ze(() => s2(t2));
    })));
  });
}
function $n(t2) {
  var e2, i2, s2 = "";
  if ("string" == typeof t2 || "number" == typeof t2) s2 += t2;
  else if ("object" == typeof t2) if (Array.isArray(t2)) {
    var n2 = t2.length;
    for (e2 = 0; e2 < n2; e2++) t2[e2] && (i2 = $n(t2[e2])) && (s2 && (s2 += " "), s2 += i2);
  } else for (i2 in t2) t2[i2] && (s2 && (s2 += " "), s2 += i2);
  return s2;
}
function En(t2) {
  return "object" == typeof t2 ? function() {
    for (var t3, e2, i2 = 0, s2 = "", n2 = arguments.length; i2 < n2; i2++) (t3 = arguments[i2]) && (e2 = $n(t3)) && (s2 && (s2 += " "), s2 += e2);
    return s2;
  }(t2) : t2 ?? "";
}
const On = [..." 	\n\r\f \v\uFEFF"];
function An(t2, e2 = false) {
  var i2 = e2 ? " !important;" : ";", s2 = "";
  for (var n2 in t2) {
    var r2 = t2[n2];
    null != r2 && "" !== r2 && (s2 += " " + n2 + ": " + r2 + i2);
  }
  return s2;
}
function Fn(t2) {
  return "-" !== t2[0] || "-" !== t2[1] ? t2.toLowerCase() : t2;
}
function Nn(t2, e2, i2, s2, n2, r2) {
  var o2 = t2.__className;
  if (Bt || o2 !== i2 || void 0 === o2) {
    var a2 = function(t3, e3, i3) {
      var s3 = null == t3 ? "" : "" + t3;
      if (e3 && (s3 = s3 ? s3 + " " + e3 : e3), i3) {
        for (var n3 in i3) if (i3[n3]) s3 = s3 ? s3 + " " + n3 : n3;
        else if (s3.length) for (var r3 = n3.length, o3 = 0; (o3 = s3.indexOf(n3, o3)) >= 0; ) {
          var a3 = o3 + r3;
          0 !== o3 && !On.includes(s3[o3 - 1]) || a3 !== s3.length && !On.includes(s3[a3]) ? o3 = a3 : s3 = (0 === o3 ? "" : s3.substring(0, o3)) + s3.substring(a3 + 1);
        }
      }
      return "" === s3 ? null : s3;
    }(i2, s2, r2);
    Bt && a2 === t2.getAttribute("class") || (null == a2 ? t2.removeAttribute("class") : e2 ? t2.className = a2 : t2.setAttribute("class", a2)), t2.__className = i2;
  } else if (r2 && n2 !== r2) for (var l2 in r2) {
    var h2 = !!r2[l2];
    null != n2 && h2 === !!n2[l2] || t2.classList.toggle(l2, h2);
  }
  return r2;
}
function Wn(t2, e2 = {}, i2, s2) {
  for (var n2 in i2) {
    var r2 = i2[n2];
    e2[n2] !== r2 && (null == i2[n2] ? t2.style.removeProperty(n2) : t2.style.setProperty(n2, r2, s2));
  }
}
function In(t2, e2, i2, s2) {
  var n2 = t2.__style;
  if (Bt || n2 !== e2) {
    var r2 = function(t3, e3) {
      if (e3) {
        var i3, s3, n3 = "";
        if (Array.isArray(e3) ? (i3 = e3[0], s3 = e3[1]) : i3 = e3, t3) {
          t3 = String(t3).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
          var r3 = false, o2 = 0, a2 = false, l2 = [];
          i3 && l2.push(...Object.keys(i3).map(Fn)), s3 && l2.push(...Object.keys(s3).map(Fn));
          var h2 = 0, c2 = -1;
          const e4 = t3.length;
          for (var u2 = 0; u2 < e4; u2++) {
            var d2 = t3[u2];
            if (a2 ? "/" === d2 && "*" === t3[u2 - 1] && (a2 = false) : r3 ? r3 === d2 && (r3 = false) : "/" === d2 && "*" === t3[u2 + 1] ? a2 = true : '"' === d2 || "'" === d2 ? r3 = d2 : "(" === d2 ? o2++ : ")" === d2 && o2--, !a2 && false === r3 && 0 === o2) {
              if (":" === d2 && -1 === c2) c2 = u2;
              else if (";" === d2 || u2 === e4 - 1) {
                if (-1 !== c2) {
                  var f2 = Fn(t3.substring(h2, c2).trim());
                  l2.includes(f2) || (";" !== d2 && u2++, n3 += " " + t3.substring(h2, u2).trim() + ";");
                }
                h2 = u2 + 1, c2 = -1;
              }
            }
          }
        }
        return i3 && (n3 += An(i3)), s3 && (n3 += An(s3, true)), "" === (n3 = n3.trim()) ? null : n3;
      }
      return null == t3 ? null : String(t3);
    }(e2, s2);
    Bt && r2 === t2.getAttribute("style") || (null == r2 ? t2.removeAttribute("style") : t2.style.cssText = r2), t2.__style = e2;
  } else s2 && (Array.isArray(s2) ? (Wn(t2, i2 == null ? void 0 : i2[0], s2[0]), Wn(t2, i2 == null ? void 0 : i2[1], s2[1], "important")) : Wn(t2, i2, s2));
  return s2;
}
function Bn(t2, e2, i2) {
  if (t2.multiple) {
    if (null == e2) return;
    if (!n(e2)) return void console.warn("https://svelte.dev/e/select_multiple_invalid_value");
    for (var s2 of t2.options) s2.selected = e2.includes(qn(s2));
  } else {
    for (s2 of t2.options) {
      if (ct(qn(s2), e2)) return void (s2.selected = true);
    }
    i2 && void 0 === e2 || (t2.selectedIndex = -1);
  }
}
function qn(t2) {
  return "__value" in t2 ? t2.__value : t2.value;
}
const Xn = Symbol("class"), Kn = Symbol("style"), Yn = Symbol("is custom element"), Gn = Symbol("is html");
function Jn(t2) {
  if (Bt) {
    var e2 = false, i2 = () => {
      if (!e2) {
        if (e2 = true, t2.hasAttribute("value")) {
          var i3 = t2.value;
          er(t2, "value", null), t2.value = i3;
        }
        if (t2.hasAttribute("checked")) {
          var s2 = t2.checked;
          er(t2, "checked", null), t2.checked = s2;
        }
      }
    };
    t2.__on_r = i2, function(t3) {
      0 === Ke.length && qe(Ye), Ke.push(t3);
    }(i2), bs();
  }
}
function Qn(t2, e2) {
  var i2 = sr(t2);
  i2.value !== (i2.value = e2 ?? void 0) && (t2.value !== e2 || 0 === e2 && "PROGRESS" === t2.nodeName) && (t2.value = e2 ?? "");
}
function Zn(t2, e2) {
  var i2 = sr(t2);
  i2.checked !== (i2.checked = e2 ?? void 0) && (t2.checked = e2);
}
function tr(t2, e2) {
  e2 ? t2.hasAttribute("selected") || t2.setAttribute("selected", "") : t2.removeAttribute("selected");
}
function er(t2, e2, i2, s2) {
  var n2 = sr(t2);
  Bt && (n2[e2] = t2.getAttribute(e2), "src" === e2 || "srcset" === e2 || "href" === e2 && "LINK" === t2.nodeName) || n2[e2] !== (n2[e2] = i2) && ("loading" === e2 && (t2[A] = i2), null == i2 ? t2.removeAttribute(e2) : "string" != typeof i2 && rr(t2).includes(e2) ? t2[e2] = i2 : t2.setAttribute(e2, i2));
}
function ir(t2, e2, i2 = [], s2, n2 = false, r2 = dt) {
  const o2 = i2.map(r2);
  var a2 = void 0, l2 = {}, h2 = "SELECT" === t2.nodeName, c2 = false;
  Te(() => {
    var i3 = e2(...o2.map(hs));
    !function(t3, e3, i4, s3) {
      var n3 = sr(t3), r4 = n3[Yn], o3 = !n3[Gn];
      let a3 = Bt && r4;
      a3 && Gt(false);
      var l3 = e3 || {}, h3 = "OPTION" === t3.tagName;
      for (var c3 in e3) c3 in i4 || (i4[c3] = null);
      i4.class ? i4.class = En(i4.class) : i4[Xn] && (i4.class = null), i4[Kn] && (i4.style ?? (i4.style = null));
      var u2 = rr(t3);
      for (const v2 in i4) {
        let b2 = i4[v2];
        if (h3 && "value" === v2 && null == b2) t3.value = t3.__value = "", l3[v2] = b2;
        else if ("class" !== v2) if ("style" !== v2) {
          var d2 = l3[v2];
          if (b2 !== d2) {
            l3[v2] = b2;
            var f2 = v2[0] + v2[1];
            if ("$$" !== f2) if ("on" === f2) {
              const _2 = {}, y2 = "$$" + v2;
              let x2 = v2.slice(2);
              var p2 = Is(x2);
              if (Ns(x2) && (x2 = x2.slice(0, -7), _2.capture = true), !p2 && d2) {
                if (null != b2) continue;
                t3.removeEventListener(x2, l3[y2], _2), l3[y2] = null;
              }
              if (null != b2) if (p2) t3[`__${x2}`] = b2, Ss([x2]);
              else {
                let w2 = function(t4) {
                  l3[v2].call(this, t4);
                };
                l3[y2] = ks(x2, t3, w2, _2);
              }
              else p2 && (t3[`__${x2}`] = void 0);
            } else if ("style" === v2) er(t3, v2, b2);
            else if ("autofocus" === v2) gs(t3, Boolean(b2));
            else if (r4 || "__value" !== v2 && ("value" !== v2 || null == b2)) if ("selected" === v2 && h3) tr(t3, b2);
            else {
              var m2 = v2;
              o3 || (m2 = js(m2));
              var g2 = "defaultValue" === m2 || "defaultChecked" === m2;
              if (null != b2 || r4 || g2) g2 || u2.includes(m2) && (r4 || "string" != typeof b2) ? t3[m2] = b2 : "function" != typeof b2 && er(t3, m2, b2);
              else if (n3[v2] = null, "value" === m2 || "checked" === m2) {
                let k2 = t3;
                const M2 = void 0 === e3;
                if ("value" === m2) {
                  let S2 = k2.defaultValue;
                  k2.removeAttribute(m2), k2.defaultValue = S2, k2.value = k2.__value = M2 ? S2 : null;
                } else {
                  let C2 = k2.defaultChecked;
                  k2.removeAttribute(m2), k2.defaultChecked = C2, k2.checked = !!M2 && C2;
                }
              } else t3.removeAttribute(v2);
            }
            else t3.value = t3.__value = b2;
          }
        } else In(t3, b2, e3 == null ? void 0 : e3[Kn], i4[Kn]), l3[v2] = b2, l3[Kn] = i4[Kn];
        else Nn(t3, "http://www.w3.org/1999/xhtml" === t3.namespaceURI, b2, s3, e3 == null ? void 0 : e3[Xn], i4[Xn]), l3[v2] = b2, l3[Xn] = i4[Xn];
      }
      a3 && Gt(true);
    }(t2, a2, i3, s2, n2), c2 && h2 && "value" in i3 && Bn(t2, i3.value, false);
    for (let t3 of Object.getOwnPropertySymbols(l2)) i3[t3] || Ae(l2[t3]);
    for (let e3 of Object.getOwnPropertySymbols(i3)) {
      var r3 = i3[e3];
      "@attach" !== e3.description || a2 && r3 === a2[e3] || (l2[e3] && Ae(l2[e3]), l2[e3] = Le(() => zn(t2, () => r3)));
    }
    a2 = i3;
  }), h2 && function(t3, e3) {
    let i3 = true;
    ze(() => {
      e3 && Bn(t3, cs(e3), i3), i3 = false;
      var s3 = new MutationObserver(() => {
        var e4 = t3.__value;
        Bn(t3, e4);
      });
      return s3.observe(t3, { childList: true, subtree: true, attributes: true, attributeFilter: ["value"] }), () => {
        s3.disconnect();
      };
    });
  }(t2, () => a2.value), c2 = true;
}
function sr(t2) {
  return t2.__attributes ?? (t2.__attributes = { [Yn]: t2.nodeName.includes("-"), [Gn]: "http://www.w3.org/1999/xhtml" === t2.namespaceURI });
}
var nr = /* @__PURE__ */ new Map();
function rr(t2) {
  var e2, i2 = nr.get(t2.nodeName);
  if (i2) return i2;
  nr.set(t2.nodeName, i2 = []);
  for (var s2 = t2, n2 = Element.prototype; n2 !== s2; ) {
    for (var r2 in e2 = c(s2)) e2[r2].set && i2.push(r2);
    s2 = f(s2);
  }
  return i2;
}
const or = { tick: (t2) => requestAnimationFrame(t2), now: () => performance.now(), tasks: /* @__PURE__ */ new Set() };
function ar() {
  const t2 = or.now();
  or.tasks.forEach((e2) => {
    e2.c(t2) || (or.tasks.delete(e2), e2.f());
  }), 0 !== or.tasks.size && or.tick(ar);
}
function lr(t2, e2) {
  _s(() => {
    t2.dispatchEvent(new CustomEvent(e2));
  });
}
function hr(t2) {
  if ("float" === t2) return "cssFloat";
  if ("offset" === t2) return "cssOffset";
  if (t2.startsWith("--")) return t2;
  const e2 = t2.split("-");
  return 1 === e2.length ? e2[0] : e2[0] + e2.slice(1).map((t3) => t3[0].toUpperCase() + t3.slice(1)).join("");
}
function cr(t2) {
  const e2 = {}, i2 = t2.split(";");
  for (const t3 of i2) {
    const [i3, s2] = t3.split(":");
    if (!i3 || void 0 === s2) break;
    e2[hr(i3.trim())] = s2.trim();
  }
  return e2;
}
const ur = (t2) => t2;
function dr(t2, e2, i2, s2) {
  var n2, r2, o2 = !!(4 & t2), a2 = e2.inert, l2 = e2.style.overflow;
  var h2 = { is_global: o2, in() {
    e2.inert = a2, r2 == null ? void 0 : r2.abort(), lr(e2, "introstart"), r2 = fr(e2, function() {
      var t3 = fi, r3 = gi;
      mi(null), vi(null);
      try {
        return n2 ?? (n2 = i2()(e2, (s2 == null ? void 0 : s2()) ?? {}, { direction: "in" }));
      } finally {
        mi(t3), vi(r3);
      }
    }(), void 0, 1, () => {
      lr(e2, "introend"), r2 == null ? void 0 : r2.abort(), r2 = n2 = void 0, e2.style.overflow = l2;
    });
  }, out: (t3) => (t3 == null ? void 0 : t3(), void (n2 = void 0)), stop: () => {
    r2 == null ? void 0 : r2.abort();
  } }, c2 = gi;
  if ((c2.transitions ?? (c2.transitions = [])).push(h2), Xs) {
    var u2 = o2;
    if (!u2) {
      for (var d2 = c2.parent; d2 && 0 !== (d2.f & P); ) for (; (d2 = d2.parent) && !(16 & d2.f); ) ;
      u2 = !d2 || 0 !== (d2.f & E);
    }
    u2 && ze(() => {
      cs(() => h2.in());
    });
  }
}
function fr(t2, e2, i2, s2, n2) {
  if (m(e2)) {
    var r2, o2 = false;
    return Ge(() => {
      if (!o2) {
        var a3 = e2({ direction: "in" });
        r2 = fr(t2, a3, i2, s2, n2);
      }
    }), { abort: () => {
      o2 = true, r2 == null ? void 0 : r2.abort();
    }, deactivate: () => r2.deactivate(), reset: () => r2.reset(), t: () => r2.t() };
  }
  if (!(e2 == null ? void 0 : e2.duration)) return n2(), { abort: g, deactivate: g, reset: g, t: () => s2 };
  const { delay: a2 = 0, css: l2, tick: h2, easing: c2 = ur } = e2;
  var u2 = [];
  if (h2 && h2(0, 1), l2) {
    var d2 = cr(l2(0, 1));
    u2.push(d2, d2);
  }
  var f2 = () => 1 - s2, p2 = t2.animate(u2, { duration: a2, fill: "forwards" });
  return p2.onfinish = () => {
    p2.cancel();
    var i3 = 1 - s2, r3 = s2 - i3, o3 = e2.duration * Math.abs(r3), a3 = [];
    if (o3 > 0) {
      var u3 = false;
      if (l2) for (var d3 = Math.ceil(o3 / (1e3 / 60)), m2 = 0; m2 <= d3; m2 += 1) {
        var g2 = i3 + r3 * c2(m2 / d3), v2 = cr(l2(g2, 1 - g2));
        a3.push(v2), u3 || (u3 = "hidden" === v2.overflow);
      }
      u3 && (t2.style.overflow = "hidden"), f2 = () => {
        var t3 = p2.currentTime;
        return i3 + r3 * c2(t3 / o3);
      }, h2 && function(t3) {
        let e3;
        0 === or.tasks.size && or.tick(ar), new Promise((i4) => {
          or.tasks.add(e3 = { c: t3, f: i4 });
        });
      }(() => {
        if ("running" !== p2.playState) return false;
        var t3 = f2();
        return h2(t3, 1 - t3), true;
      });
    }
    (p2 = t2.animate(a3, { duration: o3, fill: "forwards" })).onfinish = () => {
      f2 = () => s2, h2 == null ? void 0 : h2(s2, 1 - s2), n2();
    };
  }, { abort: () => {
    p2 && (p2.cancel(), p2.effect = null, p2.onfinish = g);
  }, deactivate: () => {
    n2 = g;
  }, reset: () => {
  }, t: () => f2() };
}
function pr(t2, e2, i2 = e2) {
  var s2 = Q();
  ys(t2, "input", (n2) => {
    var r2 = n2 ? t2.defaultValue : t2.value;
    if (r2 = gr(t2) ? vr(r2) : r2, i2(r2), s2 && r2 !== (r2 = e2())) {
      var o2 = t2.selectionStart, a2 = t2.selectionEnd;
      t2.value = r2 ?? "", null !== a2 && (t2.selectionStart = o2, t2.selectionEnd = Math.min(a2, t2.value.length));
    }
  }), (Bt && t2.defaultValue !== t2.value || null == cs(e2) && t2.value) && i2(gr(t2) ? vr(t2.value) : t2.value), Ee(() => {
    var i3 = e2();
    gr(t2) && i3 === vr(t2.value) || ("date" !== t2.type || i3 || t2.value) && i3 !== t2.value && (t2.value = i3 ?? "");
  });
}
function mr(t2, e2, i2 = e2) {
  ys(t2, "change", (e3) => {
    var s2 = e3 ? t2.defaultChecked : t2.checked;
    i2(s2);
  }), (Bt && t2.defaultChecked !== t2.checked || null == cs(e2)) && i2(t2.checked), Ee(() => {
    var i3 = e2();
    t2.checked = Boolean(i3);
  });
}
function gr(t2) {
  var e2 = t2.type;
  return "number" === e2 || "range" === e2;
}
function vr(t2) {
  return "" === t2 ? null : +t2;
}
function br(t2, e2) {
  return t2 === e2 || (t2 == null ? void 0 : t2[V]) === e2;
}
function _r(t2 = {}, e2, i2, s2) {
  return ze(() => {
    var s3, n2;
    return Ee(() => {
      s3 = n2, n2 = [], cs(() => {
        t2 !== i2(...n2) && (e2(t2, ...n2), s3 && br(i2(...s3), t2) && e2(null, ...s3));
      });
    }), () => {
      Ge(() => {
        n2 && br(i2(...n2), t2) && e2(null, ...n2);
      });
    };
  }), t2;
}
function yr(t2 = false) {
  const e2 = K, i2 = e2.l.u;
  if (!i2) return;
  let s2 = () => fs(e2.s);
  if (t2) {
    let t3 = 0, i3 = {};
    const n2 = dt(() => {
      let s3 = false;
      const n3 = e2.s;
      for (const t4 in n3) n3[t4] !== i3[t4] && (i3[t4] = n3[t4], s3 = true);
      return s3 && t3++, t3;
    });
    s2 = () => hs(n2);
  }
  i2.b.length && function(t3) {
    _e(), Ee(t3);
  }(() => {
    xr(e2, s2), b(i2.b);
  }), Se(() => {
    const t3 = cs(() => i2.m.map(v));
    return () => {
      for (const e3 of t3) "function" == typeof e3 && e3();
    };
  }), i2.a.length && Se(() => {
    xr(e2, s2), b(i2.a);
  });
}
function xr(t2, e2) {
  if (t2.l.s) for (const e3 of t2.l.s) hs(e3);
  e2();
}
function wr(t2, e2, i2) {
  if (null == t2) return e2(void 0), g;
  const s2 = cs(() => t2.subscribe(e2, i2));
  return s2.unsubscribe ? () => s2.unsubscribe() : s2;
}
const kr = [];
function Mr(t2, e2 = g) {
  let i2 = null;
  const s2 = /* @__PURE__ */ new Set();
  function n2(e3) {
    if (N(t2, e3) && (t2 = e3, i2)) {
      const e4 = !kr.length;
      for (const e5 of s2) e5[1](), kr.push(e5, t2);
      if (e4) {
        for (let t3 = 0; t3 < kr.length; t3 += 2) kr[t3][0](kr[t3 + 1]);
        kr.length = 0;
      }
    }
  }
  function r2(e3) {
    n2(e3(t2));
  }
  return { set: n2, update: r2, subscribe: function(o2, a2 = g) {
    const l2 = [o2, a2];
    return s2.add(l2), 1 === s2.size && (i2 = e2(n2, r2) || g), o2(t2), () => {
      s2.delete(l2), 0 === s2.size && i2 && (i2(), i2 = null);
    };
  } };
}
let Sr = false, Cr = Symbol();
function zr(t2, e2, i2) {
  const s2 = i2[e2] ?? (i2[e2] = { store: null, source: Mt(void 0), unsubscribe: g });
  if (s2.store !== t2 && !(Cr in i2)) if (s2.unsubscribe(), s2.store = t2 ?? null, null == t2) s2.source.v = void 0, s2.unsubscribe = g;
  else {
    var n2 = true;
    s2.unsubscribe = wr(t2, (t3) => {
      n2 ? s2.source.v = t3 : zt(s2.source, t3);
    }), n2 = false;
  }
  return t2 && Cr in i2 ? function(t3) {
    let e3;
    return wr(t3, (t4) => e3 = t4)(), e3;
  }(t2) : hs(s2.source);
}
function $r() {
  const t2 = {};
  return [t2, function() {
    we(() => {
      for (var e2 in t2) {
        t2[e2].unsubscribe();
      }
      l(t2, Cr, { enumerable: false, value: true });
    });
  }];
}
const Dr = { get(t2, e2) {
  if (!t2.exclude.includes(e2)) return hs(t2.version), e2 in t2.special ? t2.special[e2]() : t2.props[e2];
}, set: (t2, e2, i2) => (e2 in t2.special || (t2.special[e2] = Lr({ get [e2]() {
  return t2.props[e2];
} }, e2, 4)), t2.special[e2](i2), Lt(t2.version), true), getOwnPropertyDescriptor(t2, e2) {
  if (!t2.exclude.includes(e2)) return e2 in t2.props ? { enumerable: true, configurable: true, value: t2.props[e2] } : void 0;
}, deleteProperty: (t2, e2) => (t2.exclude.includes(e2) || (t2.exclude.push(e2), Lt(t2.version)), true), has: (t2, e2) => !t2.exclude.includes(e2) && e2 in t2.props, ownKeys: (t2) => Reflect.ownKeys(t2.props).filter((e2) => !t2.exclude.includes(e2)) };
function Rr(t2, e2) {
  return new Proxy({ props: t2, exclude: e2, special: {}, version: wt(0) }, Dr);
}
const Er = { get(t2, e2) {
  let i2 = t2.props.length;
  for (; i2--; ) {
    let s2 = t2.props[i2];
    if (m(s2) && (s2 = s2()), "object" == typeof s2 && null !== s2 && e2 in s2) return s2[e2];
  }
}, set(t2, e2, i2) {
  let s2 = t2.props.length;
  for (; s2--; ) {
    let n2 = t2.props[s2];
    m(n2) && (n2 = n2());
    const r2 = h(n2, e2);
    if (r2 && r2.set) return r2.set(i2), true;
  }
  return false;
}, getOwnPropertyDescriptor(t2, e2) {
  let i2 = t2.props.length;
  for (; i2--; ) {
    let s2 = t2.props[i2];
    if (m(s2) && (s2 = s2()), "object" == typeof s2 && null !== s2 && e2 in s2) {
      const t3 = h(s2, e2);
      return t3 && !t3.configurable && (t3.configurable = true), t3;
    }
  }
}, has(t2, e2) {
  if (e2 === V || e2 === O) return false;
  for (let i2 of t2.props) if (m(i2) && (i2 = i2()), null != i2 && e2 in i2) return true;
  return false;
}, ownKeys(t2) {
  const e2 = [];
  for (let i2 of t2.props) if (m(i2) && (i2 = i2()), i2) {
    for (const t3 in i2) e2.includes(t3) || e2.push(t3);
    for (const t3 of Object.getOwnPropertySymbols(i2)) e2.includes(t3) || e2.push(t3);
  }
  return e2;
} };
function Pr(...t2) {
  return new Proxy({ props: t2 }, Er);
}
function Tr(t2) {
  var _a3;
  return ((_a3 = t2.ctx) == null ? void 0 : _a3.d) ?? false;
}
function Lr(e2, i2, s2, n2) {
  var _a3;
  var r2, o2 = !!(1 & s2), a2 = !t || !!(2 & s2), l2 = !!(8 & s2), c2 = !!(16 & s2), u2 = false;
  l2 ? [r2, u2] = function(t2) {
    var e3 = Sr;
    try {
      return Sr = false, [t2(), Sr];
    } finally {
      Sr = e3;
    }
  }(() => e2[i2]) : r2 = e2[i2];
  var d2, f2 = V in e2 || O in e2, p2 = l2 && (((_a3 = h(e2, i2)) == null ? void 0 : _a3.set) ?? (f2 && i2 in e2 && ((t2) => e2[i2] = t2))) || void 0, m2 = n2, g2 = true, v2 = false, b2 = () => (v2 = true, g2 && (g2 = false, m2 = c2 ? cs(n2) : n2), m2);
  if (void 0 === r2 && void 0 !== n2 && (p2 && a2 && function() {
    throw new Error("https://svelte.dev/e/props_invalid_value");
  }(), r2 = b2(), p2 && p2(r2)), a2) d2 = () => {
    var t2 = e2[i2];
    return void 0 === t2 ? b2() : (g2 = true, v2 = false, t2);
  };
  else {
    var _2 = (o2 ? dt : gt)(() => e2[i2]);
    _2.f |= 131072, d2 = () => {
      var t2 = hs(_2);
      return void 0 !== t2 && (m2 = void 0), void 0 === t2 ? m2 : t2;
    };
  }
  if (!(4 & s2) && a2) return d2;
  if (p2) {
    var y2 = e2.$$legacy;
    return function(t2, e3) {
      return arguments.length > 0 ? (a2 && e3 && !y2 && !u2 || p2(e3 ? d2() : t2), t2) : d2();
    };
  }
  var x2 = false, w2 = Mt(r2), k2 = dt(() => {
    var t2 = d2(), e3 = hs(w2);
    return x2 ? (x2 = false, e3) : w2.v = t2;
  });
  return l2 && hs(k2), o2 || (k2.equals = B), function(t2, e3) {
    if (arguments.length > 0) {
      const i3 = e3 ? hs(k2) : a2 && l2 ? tt(t2) : t2;
      if (!k2.equals(i3)) {
        if (x2 = true, zt(w2, i3), v2 && void 0 !== m2 && (m2 = i3), Tr(k2)) return t2;
        cs(() => hs(k2));
      }
      return t2;
    }
    return Tr(k2) ? k2.v : hs(k2);
  };
}
class Svelte4Component {
  constructor(t2) {
    __privateAdd(this, _t2);
    __privateAdd(this, _e3);
    var _a3;
    var e2 = /* @__PURE__ */ new Map(), i2 = (t3, i3) => {
      var s3 = Mt(i3);
      return e2.set(t3, s3), s3;
    };
    const s2 = new Proxy({ ...t2.props || {}, $$events: {} }, { get: (t3, s3) => hs(e2.get(s3) ?? i2(s3, Reflect.get(t3, s3))), has: (t3, s3) => s3 === O || (hs(e2.get(s3) ?? i2(s3, Reflect.get(t3, s3))), Reflect.has(t3, s3)), set: (t3, s3, n2) => (zt(e2.get(s3) ?? i2(s3, n2), n2), Reflect.set(t3, s3, n2)) });
    __privateSet(this, _e3, (t2.hydrate ? Gs : Ys)(t2.component, { target: t2.target, anchor: t2.anchor, props: s2, context: t2.context, intro: t2.intro ?? false, recover: t2.recover })), ((_a3 = t2 == null ? void 0 : t2.props) == null ? void 0 : _a3.$$host) && false !== t2.sync || rs(), __privateSet(this, _t2, s2.$$events);
    for (const t3 of Object.keys(__privateGet(this, _e3))) "$set" !== t3 && "$destroy" !== t3 && "$on" !== t3 && l(this, t3, { get() {
      return __privateGet(this, _e3)[t3];
    }, set(e3) {
      __privateGet(this, _e3)[t3] = e3;
    }, enumerable: true });
    __privateGet(this, _e3).$set = (t3) => {
      Object.assign(s2, t3);
    }, __privateGet(this, _e3).$destroy = () => {
      !function(t3, e3) {
        const i3 = Zs.get(t3);
        i3 ? (Zs.delete(t3), i3(e3)) : Promise.resolve();
      }(__privateGet(this, _e3));
    };
  }
  $set(t2) {
    __privateGet(this, _e3).$set(t2);
  }
  $on(t2, e2) {
    __privateGet(this, _t2)[t2] = __privateGet(this, _t2)[t2] || [];
    const i2 = (...t3) => e2.call(this, ...t3);
    return __privateGet(this, _t2)[t2].push(i2), () => {
      __privateGet(this, _t2)[t2] = __privateGet(this, _t2)[t2].filter((t3) => t3 !== i2);
    };
  }
  $destroy() {
    __privateGet(this, _e3).$destroy();
  }
}
_t2 = new WeakMap();
_e3 = new WeakMap();
let Vr;
function Or(t2, e2, i2, s2) {
  var _a3;
  const n2 = (_a3 = i2[t2]) == null ? void 0 : _a3.type;
  if (e2 = "Boolean" === n2 && "boolean" != typeof e2 ? null != e2 : e2, !s2 || !i2[t2]) return e2;
  if ("toAttribute" === s2) switch (n2) {
    case "Object":
    case "Array":
      return null == e2 ? null : JSON.stringify(e2);
    case "Boolean":
      return e2 ? "" : null;
    case "Number":
      return null == e2 ? null : e2;
    default:
      return e2;
  }
  else switch (n2) {
    case "Object":
    case "Array":
      return e2 && JSON.parse(e2);
    case "Boolean":
    default:
      return e2;
    case "Number":
      return null != e2 ? +e2 : e2;
  }
}
function Ar(t2, e2, i2, s2, n2, r2) {
  let o2 = class extends Vr {
    constructor() {
      super(t2, i2, n2), this.$$p_d = e2;
    }
    static get observedAttributes() {
      return a(e2).map((t3) => (e2[t3].attribute || t3).toLowerCase());
    }
  };
  return a(e2).forEach((t3) => {
    l(o2.prototype, t3, { get() {
      return this.$$c && t3 in this.$$c ? this.$$c[t3] : this.$$d[t3];
    }, set(i3) {
      var _a3;
      i3 = Or(t3, i3, e2), this.$$d[t3] = i3;
      var s3 = this.$$c;
      if (s3) {
        var n3 = (_a3 = h(s3, t3)) == null ? void 0 : _a3.get;
        n3 ? s3[t3] = i3 : s3.$set({ [t3]: i3 });
      }
    } });
  }), s2.forEach((t3) => {
    l(o2.prototype, t3, { get() {
      var _a3;
      return (_a3 = this.$$c) == null ? void 0 : _a3[t3];
    } });
  }), t2.element = o2, o2;
}
"function" == typeof HTMLElement && (Vr = class extends HTMLElement {
  constructor(t2, e2, i2) {
    super();
    __publicField(this, "$$ctor");
    __publicField(this, "$$s");
    __publicField(this, "$$c");
    __publicField(this, "$$cn", false);
    __publicField(this, "$$d", {});
    __publicField(this, "$$r", false);
    __publicField(this, "$$p_d", {});
    __publicField(this, "$$l", {});
    __publicField(this, "$$l_u", /* @__PURE__ */ new Map());
    __publicField(this, "$$me");
    this.$$ctor = t2, this.$$s = e2, i2 && this.attachShadow({ mode: "open" });
  }
  addEventListener(t2, e2, i2) {
    if (this.$$l[t2] = this.$$l[t2] || [], this.$$l[t2].push(e2), this.$$c) {
      const i3 = this.$$c.$on(t2, e2);
      this.$$l_u.set(e2, i3);
    }
    super.addEventListener(t2, e2, i2);
  }
  removeEventListener(t2, e2, i2) {
    if (super.removeEventListener(t2, e2, i2), this.$$c) {
      const t3 = this.$$l_u.get(e2);
      t3 && (t3(), this.$$l_u.delete(e2));
    }
  }
  async connectedCallback() {
    if (this.$$cn = true, !this.$$c) {
      let e2 = function(t3) {
        return (e3) => {
          const i3 = document.createElement("slot");
          "default" !== t3 && (i3.name = t3), As(e3, i3);
        };
      };
      if (await Promise.resolve(), !this.$$cn || this.$$c) return;
      const i2 = {}, s2 = function(t3) {
        const e3 = {};
        return t3.childNodes.forEach((t4) => {
          e3[t4.slot || "default"] = true;
        }), e3;
      }(this);
      for (const n2 of this.$$s) n2 in s2 && ("default" !== n2 || this.$$d.children ? i2[n2] = e2(n2) : (this.$$d.children = e2(n2), i2.default = true));
      for (const r2 of this.attributes) {
        const o2 = this.$$g_p(r2.name);
        o2 in this.$$d || (this.$$d[o2] = Or(o2, r2.value, this.$$p_d, "toProp"));
      }
      for (const l2 in this.$$p_d) l2 in this.$$d || void 0 === this[l2] || (this.$$d[l2] = this[l2], delete this[l2]);
      this.$$c = (t2 = { component: this.$$ctor, target: this.shadowRoot || this, props: { ...this.$$d, $$slots: i2, $$host: this } }, new Svelte4Component(t2)), this.$$me = function(t3) {
        const e3 = xe(x, t3, true);
        return () => {
          Ae(e3);
        };
      }(() => {
        Ee(() => {
          var _a3;
          this.$$r = true;
          for (const t3 of a(this.$$c)) {
            if (!((_a3 = this.$$p_d[t3]) == null ? void 0 : _a3.reflect)) continue;
            this.$$d[t3] = this.$$c[t3];
            const e3 = Or(t3, this.$$d[t3], this.$$p_d, "toAttribute");
            null == e3 ? this.removeAttribute(this.$$p_d[t3].attribute || t3) : this.setAttribute(this.$$p_d[t3].attribute || t3, e3);
          }
          this.$$r = false;
        });
      });
      for (const h2 in this.$$l) for (const c2 of this.$$l[h2]) {
        const u2 = this.$$c.$on(h2, c2);
        this.$$l_u.set(c2, u2);
      }
      this.$$l = {};
    }
    var t2;
  }
  attributeChangedCallback(t2, e2, i2) {
    var _a3;
    this.$$r || (t2 = this.$$g_p(t2), this.$$d[t2] = Or(t2, i2, this.$$p_d, "toProp"), (_a3 = this.$$c) == null ? void 0 : _a3.$set({ [t2]: this.$$d[t2] }));
  }
  disconnectedCallback() {
    this.$$cn = false, Promise.resolve().then(() => {
      !this.$$cn && this.$$c && (this.$$c.$destroy(), this.$$me(), this.$$c = void 0);
    });
  }
  $$g_p(t2) {
    return a(this.$$p_d).find((e2) => this.$$p_d[e2].attribute === t2 || !this.$$p_d[e2].attribute && e2.toLowerCase() === t2) || t2;
  }
});
const Fr = [{ backtest: ["startDate", "endDate", "version", "feeRatio", "taxRatio", "tradeAt", "market", "freq", "updateDate", "nextTradingDate", "livePerformanceStart", "stopLoss", "takeProfit"] }, { profitability: ["annualReturn", "alpha", "beta", "avgNStock", "maxNStock"] }, { risk: ["maxDrawdown", "avgDrawdown", "avgDrawdownDays", "valueAtRisk", "cvalueAtRisk"] }, { ratio: ["sharpeRatio", "sortinoRatio", "calmarRatio", "profitFactor", "tailRatio"] }, { winrate: ["winRate", "m12WinRate", "expectancy", "mae", "mfe"] }, { liquidity: ["capacity", "disposalStockRatio", "warningStockRatio", "fullDeliveryStockRatio", "buyHigh", "sellLow"] }];
function Nr(t2) {
  const e2 = {}, i2 = Fr;
  for (const s2 of i2) for (const i3 in s2) {
    e2[i3] = {};
    for (const n2 of s2[i3]) e2[i3][n2] = t2[i3][n2];
  }
  return e2;
}
const Wr = { profitability: { annualReturn: (t2) => t2 > 0.15, alpha: (t2) => t2 > 0.1, beta: (t2) => t2 < 0.8 && t2 > 0, avgNStock: (t2) => t2 >= 5, maxNStock: (t2) => t2 <= 20 }, risk: { maxDrawdown: (t2) => t2 > -0.3, avgDrawdown: (t2) => t2 > -0.1, avgDrawdownDays: (t2) => t2 < 40, volatility: (t2) => t2 < 0.2, valueAtRisk: (t2) => t2 > -0.07, cvalueAtRisk: (t2) => t2 > -0.1 }, ratio: { sharpeRatio: (t2) => t2 > 1.3, sortinoRatio: (t2) => t2 > 1.8, calmarRatio: (t2) => t2 > 0.9, profitFactor: (t2) => t2 > 1.5, tailRatio: (t2) => t2 > 1 }, winrate: { winRate: (t2) => t2 > 0.55, m12WinRate: (t2) => t2 > 0.7, expectancy: (t2) => t2 > 0.02, mae: (t2) => t2 > -0.1, mfe: (t2) => t2 > 0.1 }, liquidity: { capacity: (t2) => t2 > 5e5, disposalStockRatio: (t2) => t2 < 0.05, warningStockRatio: (t2) => t2 < 0.05, fullDeliveryStockRatio: (t2) => t2 < 0.05, buyHigh: (t2) => t2 < 0.05, sellLow: (t2) => t2 < 0.05 } };
function Ir(t2) {
  const e2 = { profitability: 0, risk: 0, ratio: 0, winrate: 0, liquidity: 0 };
  for (const i2 in Wr) for (const s2 in Wr[i2]) Wr[i2][s2](t2[i2][s2]) && (e2[i2]++, "liquidity" === i2 && "capacity" === s2 && (e2[i2] += 10));
  for (const t3 in e2) {
    let i2 = Object.keys(Wr[t3]).length;
    "liquidity" === t3 && (i2 += 10), e2[t3] = e2[t3] / i2;
  }
  return e2;
}
class MetricDisplay {
  constructor() {
    this.percentage = (t2) => (100 * t2).toFixed(1), this.sign = (t2) => "string" == typeof t2 && "-" != t2[0] || "number" == typeof t2 && t2 > 0 ? "+" + String(t2) : String(t2), this.color = (t2) => t2 > 0 ? "text-rise" : "text-fall", this.formatter = { annualReturn: (t2) => this.sign(this.percentage(t2)), alpha: (t2) => this.sign(this.percentage(t2)), avgNStock: (t2) => 0 === t2 ? "-" : t2.toFixed(0), maxNStock: (t2) => 0 === t2 ? "-" : t2.toFixed(0), maxDrawdown: (t2) => this.sign(this.percentage(t2)), avgDrawdown: (t2) => this.sign(this.percentage(t2)), valueAtRisk: (t2) => this.sign(this.percentage(t2)), cvalueAtRisk: (t2) => this.sign(this.percentage(t2)), winRate: (t2) => this.percentage(t2), m12WinRate: (t2) => this.percentage(t2), expectancy: (t2) => this.sign(this.percentage(t2)), mae: (t2) => this.sign(this.percentage(t2)), mfe: (t2) => this.sign(this.percentage(t2)), smallCapRatio: (t2) => this.percentage(t2), capacity: (t2) => (t2 / 1e4).toFixed(0), disposalStockRatio: (t2) => this.percentage(t2), warningStockRatio: (t2) => this.percentage(t2), fullDeliveryStockRatio: (t2) => this.percentage(t2), buyHigh: (t2) => this.percentage(t2), sellLow: (t2) => this.percentage(t2) }, this.units = { annualReturn: "%", alpha: "%", avgNStock: "檔", maxNStock: "檔", maxDrawdown: "%", avgDrawdown: "%", avgDrawdownDays: "天", valueAtRisk: "%", cvalueAtRisk: "%", winRate: "%", m12WinRate: "%", expectancy: "%", mae: "%", mfe: "%", smallCapRatio: "%", capacity: "萬", disposalStockRatio: "%", warningStockRatio: "%", fullDeliveryStockRatio: "%", buyHigh: "%", sellLow: "%" };
  }
  format(t2, e2) {
    if (t2 in this.formatter) try {
      return this.formatter[t2](e2);
    } catch {
    }
    try {
      return String(e2.toFixed(2));
    } catch {
    }
    return String(e2);
  }
  getUnit(t2) {
    return t2 in this.units ? this.units[t2] : "";
  }
}
function Br(t2, e2, i2, s2) {
  let n2 = e2.length, r2 = void 0 !== i2 ? i2 : 0, o2 = void 0 !== s2 ? s2 : n2 - 1, a2 = r2 + Math.floor((o2 - r2) / 2);
  0 !== n2 ? t2 >= e2[o2] ? e2.splice(o2 + 1, 0, t2) : t2 < e2[r2] ? e2.splice(r2, 0, t2) : r2 >= o2 || (t2 <= e2[a2] ? Br(t2, e2, r2, a2) : t2 > e2[a2] && Br(t2, e2, a2 + 1, o2)) : e2.push(t2);
}
function jr(t2, e2, i2) {
  let s2 = [], n2 = [];
  t2.slice(0, i2).forEach((t3) => Br(t3, s2));
  for (let r2 = i2; r2 < t2.length; r2++) n2.push(s2[Math.floor(i2 * e2)]), s2.splice(s2.indexOf(t2[r2 - i2]), 1), Br(t2[r2], s2);
  return n2.push(s2[Math.floor(i2 * e2)]), n2;
}
class Report {
  constructor(t2, e2, i2, s2, n2) {
    this.timestamps = t2, this.strategy = e2, this.benchmark = i2, this.trades = s2, this.metrics = n2;
  }
  createTradingviewSeries(t2, e2 = 0, i2 = -1, s2 = 500) {
    const n2 = this.timestamps.map((e3, i3) => ({ time: e3, value: this[t2][i3] })).slice(this.indexOfTimestamps(e2), this.indexOfTimestamps(i2) + 1), r2 = this.timestamps.map((t3, e3) => 0 === e3 || t3.substring(0, 7) !== this.timestamps[e3 - 1].substring(0, 7)), o2 = Math.round(n2.length / s2);
    return n2.filter((t3, e3) => e3 % o2 === 0 || e3 === n2.length - 1 || r2[e3]);
  }
  indexOfTimestamps(t2) {
    return "string" == typeof t2 ? function(t3, e2) {
      let i2 = 0, s2 = t3.length - 1, n2 = -1;
      for (; i2 <= s2; ) {
        const r2 = Math.ceil((i2 + s2) / 2);
        if (t3[r2] === e2) return r2;
        t3[r2] < e2 ? (n2 = r2, i2 = r2 + 1) : (n2 = r2, s2 = r2 - 1);
      }
      return e2 < t3[n2] && (n2 -= 1), n2;
    }(this.timestamps, t2) : t2 < 0 ? Math.min(Math.max(this.timestamps.length + t2, 0), this.timestamps.length - 1) : t2;
  }
  calculateAnnualReturn(t2) {
    const e2 = {};
    let i2 = this[t2][0];
    for (let s2 = 1; s2 < this.timestamps.length; s2++) {
      const n2 = new Date(this.timestamps[s2]).getFullYear();
      if (s2 === this.timestamps.length - 1 || new Date(this.timestamps[s2 + 1]).getFullYear() !== n2) {
        const r2 = this[t2][s2];
        e2[n2] = r2 / i2 - 1, i2 = r2;
      }
    }
    return e2;
  }
  calculateMonthlyReturn(t2) {
    const e2 = {};
    let i2 = this[t2][0];
    for (let s2 = 1; s2 < this.timestamps.length; s2++) {
      const n2 = new Date(this.timestamps[s2]), r2 = n2.getFullYear(), o2 = n2.getMonth() + 1;
      if (s2 === this.timestamps.length - 1 || new Date(this.timestamps[s2 + 1]).getMonth() + 1 !== o2) {
        const n3 = this[t2][s2];
        e2[`${r2}${o2}`] = n3 / i2 - 1, i2 = n3;
      }
    }
    return e2;
  }
  calculateMostRecentNDayReturn(t2, e2) {
    const i2 = this[t2], s2 = i2.length, n2 = {};
    for (const t3 of e2) {
      const e3 = parseInt(t3);
      if (s2 < e3) continue;
      const r2 = 100 * (i2[s2 - 1] / i2[s2 - e3 - 1] - 1);
      n2[t3] = r2;
    }
    return n2;
  }
  createTradingViewDrawdown(t2, e2 = 100) {
    const i2 = this[t2], s2 = [];
    let n2 = -1 / 0, r2 = i2[0];
    for (let t3 = 0; t3 < i2.length; t3++) n2 = Math.max(n2, i2[t3]), r2 = Math.min(r2, i2[t3]), s2.push((i2[t3] - n2) / n2 * 100);
    const o2 = Math.ceil(s2.length / e2);
    return this.timestamps.map((t3, e3) => ({ time: t3, value: s2[e3] })).filter((t3, e3) => e3 % o2 === 0 || e3 === s2.length - 1);
  }
  calculateDrawdown(t2) {
    let e2 = 0, i2 = 1, s2 = 1, n2 = 0, r2 = [];
    const o2 = this[t2];
    for (let t3 = 0; t3 < this.timestamps.length; t3 += 1) {
      const a3 = o2[t3];
      if (a3 > i2) t3 - e2 >= 2 && r2.push({ maxDrawdown: s2 - 1, start: e2, end: t3, at: n2 }), e2 = t3, i2 = a3, s2 = 1, n2 = t3;
      else {
        const e3 = a3 / i2;
        s2 > e3 && (s2 = e3, n2 = t3);
      }
    }
    s2 < 1 && this.timestamps.length - e2 >= 2 && r2.push({ maxDrawdown: s2 - 1, start: e2, end: this.timestamps.length - 1, at: n2 }), r2.sort((t3, e3) => -(t3.end - t3.start) + (e3.end - e3.start));
    const a2 = r2.slice(0, 5);
    r2.sort((t3, e3) => t3.maxDrawdown - e3.maxDrawdown);
    return [r2.slice(0, 5), a2];
  }
  calculateSharpe(t2, e2, i2) {
    let s2 = [], n2 = 0, r2 = 0;
    const o2 = this[t2];
    for (let t3 = 1; t3 < o2.length; t3++) {
      if (n2 += o2[t3] / o2[t3 - 1] - 1, t3 >= i2) {
        n2 -= o2[t3 - i2 + 1] / o2[t3 - i2] - 1;
      }
      const a2 = n2 / Math.min(t3, i2);
      r2 = 0;
      for (let e3 = Math.max(1, t3 - i2 + 1); e3 <= t3; e3++) {
        const t4 = o2[e3] / o2[e3 - 1] - 1;
        r2 += (t4 - a2) * (t4 - a2);
      }
      if (t3 >= i2 - 1) {
        const n3 = r2 / Math.min(t3, i2), o3 = (a2 - e2) / Math.sqrt(n3);
        s2.push({ time: this.timestamps[t3], value: o3 * Math.sqrt(i2) });
      }
    }
    return s2;
  }
  calculateSortino(t2, e2, i2) {
    let s2 = [], n2 = 0, r2 = 0, o2 = [], a2 = [];
    const l2 = this[t2];
    for (let t3 = 1; t3 < l2.length; t3++) {
      let h2 = l2[t3] / l2[t3 - 1] - 1;
      n2 += h2, o2.push(h2);
      let c2 = n2 / i2, u2 = (h2 - c2) * (h2 - c2);
      if (a2.push(u2), h2 < e2 && (r2 += u2), t3 >= i2) {
        let t4 = o2.shift(), i3 = a2.shift();
        n2 -= t4, t4 < e2 && (r2 -= i3);
      }
      if (t3 >= i2 - 1) {
        let t4 = r2 / i2, n3 = (c2 - e2) / Math.sqrt(t4);
        s2.push(n3);
      }
    }
    return s2.map((t3, e3) => ({ time: this.timestamps[e3 + i2 - 1], value: t3 * Math.sqrt(i2) }));
  }
  calculateVolitility(t2, e2, i2) {
    let s2 = [], n2 = 0, r2 = 0, o2 = [], a2 = [];
    const l2 = this[t2];
    for (let t3 = 1; t3 < l2.length; t3++) {
      let e3 = l2[t3] / l2[t3 - 1] - 1;
      n2 += e3, o2.push(e3);
      let h2 = n2 / i2, c2 = (e3 - h2) * (e3 - h2);
      if (r2 += c2, a2.push(c2), t3 >= i2) {
        n2 -= o2.shift(), r2 -= a2.shift();
      }
      if (t3 >= i2 - 1) {
        let t4 = r2 / i2, e4 = Math.sqrt(t4);
        s2.push(e4);
      }
    }
    return s2.map((t3, e3) => ({ time: this.timestamps[e3 + i2 - 1], value: t3 * Math.sqrt(i2) }));
  }
  calculateCorrelation(t2) {
    let e2 = this.strategy, i2 = this.benchmark, s2 = [];
    for (let n2 = 0; n2 < e2.length; n2++) {
      let r2 = 0, o2 = 0, a2 = 0, l2 = 0, h2 = 0;
      for (let s3 = Math.max(0, n2 - t2 + 1); s3 <= n2; s3++) r2 += e2[s3], o2 += i2[s3], a2 += e2[s3] * e2[s3], l2 += i2[s3] * i2[s3], h2 += e2[s3] * i2[s3];
      let c2 = Math.min(n2 + 1, t2), u2 = (c2 * h2 - r2 * o2) / Math.sqrt((c2 * a2 - r2 * r2) * (c2 * l2 - o2 * o2));
      s2.push(u2);
    }
    return s2.map((e3, i3) => ({ time: this.timestamps[i3 + t2 - 1], value: e3 })).filter((t3) => void 0 !== t3.time).slice(1, -1);
  }
  calculateTailRatio(t2, e2) {
    let i2 = this[t2];
    i2 = i2.map((t3, e3) => t3 / i2[e3 - 1] - 1), i2[0] = 0;
    const s2 = jr(i2, 0.95, e2), n2 = jr(i2, 0.05, e2);
    return s2.map((t3, e3) => Math.abs(t3 / n2[e3])).map((t3, i3) => ({ time: this.timestamps[i3 + e2 - 1], value: t3 }));
  }
}
function Hr(t2) {
  return t2 + 0.5 | 0;
}
const qr = (t2, e2, i2) => Math.max(Math.min(t2, i2), e2);
function Xr(t2) {
  return qr(Hr(2.55 * t2), 0, 255);
}
function Kr(t2) {
  return qr(Hr(255 * t2), 0, 255);
}
function Ur(t2) {
  return qr(Hr(t2 / 2.55) / 100, 0, 1);
}
function Yr(t2) {
  return qr(Hr(100 * t2), 0, 100);
}
const Gr = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, A: 10, B: 11, C: 12, D: 13, E: 14, F: 15, a: 10, b: 11, c: 12, d: 13, e: 14, f: 15 }, Jr = [..."0123456789ABCDEF"], Qr = (t2) => Jr[15 & t2], Zr = (t2) => Jr[(240 & t2) >> 4] + Jr[15 & t2], to = (t2) => (240 & t2) >> 4 == (15 & t2);
function eo(t2) {
  var e2 = ((t3) => to(t3.r) && to(t3.g) && to(t3.b) && to(t3.a))(t2) ? Qr : Zr;
  return t2 ? "#" + e2(t2.r) + e2(t2.g) + e2(t2.b) + ((t3, e3) => t3 < 255 ? e3(t3) : "")(t2.a, e2) : void 0;
}
const io = /^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;
function so(t2, e2, i2) {
  const s2 = e2 * Math.min(i2, 1 - i2), n2 = (e3, n3 = (e3 + t2 / 30) % 12) => i2 - s2 * Math.max(Math.min(n3 - 3, 9 - n3, 1), -1);
  return [n2(0), n2(8), n2(4)];
}
function no(t2, e2, i2) {
  const s2 = (s3, n2 = (s3 + t2 / 60) % 6) => i2 - i2 * e2 * Math.max(Math.min(n2, 4 - n2, 1), 0);
  return [s2(5), s2(3), s2(1)];
}
function ro(t2, e2, i2) {
  const s2 = so(t2, 1, 0.5);
  let n2;
  for (e2 + i2 > 1 && (n2 = 1 / (e2 + i2), e2 *= n2, i2 *= n2), n2 = 0; n2 < 3; n2++) s2[n2] *= 1 - e2 - i2, s2[n2] += e2;
  return s2;
}
function oo(t2) {
  const e2 = t2.r / 255, i2 = t2.g / 255, s2 = t2.b / 255, n2 = Math.max(e2, i2, s2), r2 = Math.min(e2, i2, s2), o2 = (n2 + r2) / 2;
  let a2, l2, h2;
  return n2 !== r2 && (h2 = n2 - r2, l2 = o2 > 0.5 ? h2 / (2 - n2 - r2) : h2 / (n2 + r2), a2 = function(t3, e3, i3, s3, n3) {
    return t3 === n3 ? (e3 - i3) / s3 + (e3 < i3 ? 6 : 0) : e3 === n3 ? (i3 - t3) / s3 + 2 : (t3 - e3) / s3 + 4;
  }(e2, i2, s2, h2, n2), a2 = 60 * a2 + 0.5), [0 | a2, l2 || 0, o2];
}
function ao(t2, e2, i2, s2) {
  return (Array.isArray(e2) ? t2(e2[0], e2[1], e2[2]) : t2(e2, i2, s2)).map(Kr);
}
function lo(t2, e2, i2) {
  return ao(so, t2, e2, i2);
}
function ho(t2) {
  return (t2 % 360 + 360) % 360;
}
function co(t2) {
  const e2 = io.exec(t2);
  let i2, s2 = 255;
  if (!e2) return;
  e2[5] !== i2 && (s2 = e2[6] ? Xr(+e2[5]) : Kr(+e2[5]));
  const n2 = ho(+e2[2]), r2 = +e2[3] / 100, o2 = +e2[4] / 100;
  return i2 = "hwb" === e2[1] ? function(t3, e3, i3) {
    return ao(ro, t3, e3, i3);
  }(n2, r2, o2) : "hsv" === e2[1] ? function(t3, e3, i3) {
    return ao(no, t3, e3, i3);
  }(n2, r2, o2) : lo(n2, r2, o2), { r: i2[0], g: i2[1], b: i2[2], a: s2 };
}
const uo = { x: "dark", Z: "light", Y: "re", X: "blu", W: "gr", V: "medium", U: "slate", A: "ee", T: "ol", S: "or", B: "ra", C: "lateg", D: "ights", R: "in", Q: "turquois", E: "hi", P: "ro", O: "al", N: "le", M: "de", L: "yello", F: "en", K: "ch", G: "arks", H: "ea", I: "ightg", J: "wh" }, fo = { OiceXe: "f0f8ff", antiquewEte: "faebd7", aqua: "ffff", aquamarRe: "7fffd4", azuY: "f0ffff", beige: "f5f5dc", bisque: "ffe4c4", black: "0", blanKedOmond: "ffebcd", Xe: "ff", XeviTet: "8a2be2", bPwn: "a52a2a", burlywood: "deb887", caMtXe: "5f9ea0", KartYuse: "7fff00", KocTate: "d2691e", cSO: "ff7f50", cSnflowerXe: "6495ed", cSnsilk: "fff8dc", crimson: "dc143c", cyan: "ffff", xXe: "8b", xcyan: "8b8b", xgTMnPd: "b8860b", xWay: "a9a9a9", xgYF: "6400", xgYy: "a9a9a9", xkhaki: "bdb76b", xmagFta: "8b008b", xTivegYF: "556b2f", xSange: "ff8c00", xScEd: "9932cc", xYd: "8b0000", xsOmon: "e9967a", xsHgYF: "8fbc8f", xUXe: "483d8b", xUWay: "2f4f4f", xUgYy: "2f4f4f", xQe: "ced1", xviTet: "9400d3", dAppRk: "ff1493", dApskyXe: "bfff", dimWay: "696969", dimgYy: "696969", dodgerXe: "1e90ff", fiYbrick: "b22222", flSOwEte: "fffaf0", foYstWAn: "228b22", fuKsia: "ff00ff", gaRsbSo: "dcdcdc", ghostwEte: "f8f8ff", gTd: "ffd700", gTMnPd: "daa520", Way: "808080", gYF: "8000", gYFLw: "adff2f", gYy: "808080", honeyMw: "f0fff0", hotpRk: "ff69b4", RdianYd: "cd5c5c", Rdigo: "4b0082", ivSy: "fffff0", khaki: "f0e68c", lavFMr: "e6e6fa", lavFMrXsh: "fff0f5", lawngYF: "7cfc00", NmoncEffon: "fffacd", ZXe: "add8e6", ZcSO: "f08080", Zcyan: "e0ffff", ZgTMnPdLw: "fafad2", ZWay: "d3d3d3", ZgYF: "90ee90", ZgYy: "d3d3d3", ZpRk: "ffb6c1", ZsOmon: "ffa07a", ZsHgYF: "20b2aa", ZskyXe: "87cefa", ZUWay: "778899", ZUgYy: "778899", ZstAlXe: "b0c4de", ZLw: "ffffe0", lime: "ff00", limegYF: "32cd32", lRF: "faf0e6", magFta: "ff00ff", maPon: "800000", VaquamarRe: "66cdaa", VXe: "cd", VScEd: "ba55d3", VpurpN: "9370db", VsHgYF: "3cb371", VUXe: "7b68ee", VsprRggYF: "fa9a", VQe: "48d1cc", VviTetYd: "c71585", midnightXe: "191970", mRtcYam: "f5fffa", mistyPse: "ffe4e1", moccasR: "ffe4b5", navajowEte: "ffdead", navy: "80", Tdlace: "fdf5e6", Tive: "808000", TivedBb: "6b8e23", Sange: "ffa500", SangeYd: "ff4500", ScEd: "da70d6", pOegTMnPd: "eee8aa", pOegYF: "98fb98", pOeQe: "afeeee", pOeviTetYd: "db7093", papayawEp: "ffefd5", pHKpuff: "ffdab9", peru: "cd853f", pRk: "ffc0cb", plum: "dda0dd", powMrXe: "b0e0e6", purpN: "800080", YbeccapurpN: "663399", Yd: "ff0000", Psybrown: "bc8f8f", PyOXe: "4169e1", saddNbPwn: "8b4513", sOmon: "fa8072", sandybPwn: "f4a460", sHgYF: "2e8b57", sHshell: "fff5ee", siFna: "a0522d", silver: "c0c0c0", skyXe: "87ceeb", UXe: "6a5acd", UWay: "708090", UgYy: "708090", snow: "fffafa", sprRggYF: "ff7f", stAlXe: "4682b4", tan: "d2b48c", teO: "8080", tEstN: "d8bfd8", tomato: "ff6347", Qe: "40e0d0", viTet: "ee82ee", JHt: "f5deb3", wEte: "ffffff", wEtesmoke: "f5f5f5", Lw: "ffff00", LwgYF: "9acd32" };
let po;
function mo(t2) {
  po || (po = function() {
    const t3 = {}, e3 = Object.keys(fo), i2 = Object.keys(uo);
    let s2, n2, r2, o2, a2;
    for (s2 = 0; s2 < e3.length; s2++) {
      for (o2 = a2 = e3[s2], n2 = 0; n2 < i2.length; n2++) r2 = i2[n2], a2 = a2.replace(r2, uo[r2]);
      r2 = parseInt(fo[o2], 16), t3[a2] = [r2 >> 16 & 255, r2 >> 8 & 255, 255 & r2];
    }
    return t3;
  }(), po.transparent = [0, 0, 0, 0]);
  const e2 = po[t2.toLowerCase()];
  return e2 && { r: e2[0], g: e2[1], b: e2[2], a: 4 === e2.length ? e2[3] : 255 };
}
const go = /^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/;
const vo = (t2) => t2 <= 31308e-7 ? 12.92 * t2 : 1.055 * Math.pow(t2, 1 / 2.4) - 0.055, bo = (t2) => t2 <= 0.04045 ? t2 / 12.92 : Math.pow((t2 + 0.055) / 1.055, 2.4);
function _o(t2, e2, i2) {
  if (t2) {
    let s2 = oo(t2);
    s2[e2] = Math.max(0, Math.min(s2[e2] + s2[e2] * i2, 0 === e2 ? 360 : 1)), s2 = lo(s2), t2.r = s2[0], t2.g = s2[1], t2.b = s2[2];
  }
}
function yo(t2, e2) {
  return t2 ? Object.assign(e2 || {}, t2) : t2;
}
function xo(t2) {
  var e2 = { r: 0, g: 0, b: 0, a: 255 };
  return Array.isArray(t2) ? t2.length >= 3 && (e2 = { r: t2[0], g: t2[1], b: t2[2], a: 255 }, t2.length > 3 && (e2.a = Kr(t2[3]))) : (e2 = yo(t2, { r: 0, g: 0, b: 0, a: 1 })).a = Kr(e2.a), e2;
}
function wo(t2) {
  return "r" === t2.charAt(0) ? function(t3) {
    const e2 = go.exec(t3);
    let i2, s2, n2, r2 = 255;
    if (e2) {
      if (e2[7] !== i2) {
        const t4 = +e2[7];
        r2 = e2[8] ? Xr(t4) : qr(255 * t4, 0, 255);
      }
      return i2 = +e2[1], s2 = +e2[3], n2 = +e2[5], i2 = 255 & (e2[2] ? Xr(i2) : qr(i2, 0, 255)), s2 = 255 & (e2[4] ? Xr(s2) : qr(s2, 0, 255)), n2 = 255 & (e2[6] ? Xr(n2) : qr(n2, 0, 255)), { r: i2, g: s2, b: n2, a: r2 };
    }
  }(t2) : co(t2);
}
class Color {
  constructor(t2) {
    if (t2 instanceof Color) return t2;
    const e2 = typeof t2;
    let i2;
    var s2, n2, r2;
    "object" === e2 ? i2 = xo(t2) : "string" === e2 && (r2 = (s2 = t2).length, "#" === s2[0] && (4 === r2 || 5 === r2 ? n2 = { r: 255 & 17 * Gr[s2[1]], g: 255 & 17 * Gr[s2[2]], b: 255 & 17 * Gr[s2[3]], a: 5 === r2 ? 17 * Gr[s2[4]] : 255 } : 7 !== r2 && 9 !== r2 || (n2 = { r: Gr[s2[1]] << 4 | Gr[s2[2]], g: Gr[s2[3]] << 4 | Gr[s2[4]], b: Gr[s2[5]] << 4 | Gr[s2[6]], a: 9 === r2 ? Gr[s2[7]] << 4 | Gr[s2[8]] : 255 })), i2 = n2 || mo(t2) || wo(t2)), this._rgb = i2, this._valid = !!i2;
  }
  get valid() {
    return this._valid;
  }
  get rgb() {
    var t2 = yo(this._rgb);
    return t2 && (t2.a = Ur(t2.a)), t2;
  }
  set rgb(t2) {
    this._rgb = xo(t2);
  }
  rgbString() {
    return this._valid ? function(t2) {
      return t2 && (t2.a < 255 ? `rgba(${t2.r}, ${t2.g}, ${t2.b}, ${Ur(t2.a)})` : `rgb(${t2.r}, ${t2.g}, ${t2.b})`);
    }(this._rgb) : void 0;
  }
  hexString() {
    return this._valid ? eo(this._rgb) : void 0;
  }
  hslString() {
    return this._valid ? function(t2) {
      if (!t2) return;
      const e2 = oo(t2), i2 = e2[0], s2 = Yr(e2[1]), n2 = Yr(e2[2]);
      return t2.a < 255 ? `hsla(${i2}, ${s2}%, ${n2}%, ${Ur(t2.a)})` : `hsl(${i2}, ${s2}%, ${n2}%)`;
    }(this._rgb) : void 0;
  }
  mix(t2, e2) {
    if (t2) {
      const i2 = this.rgb, s2 = t2.rgb;
      let n2;
      const r2 = e2 === n2 ? 0.5 : e2, o2 = 2 * r2 - 1, a2 = i2.a - s2.a, l2 = ((o2 * a2 === -1 ? o2 : (o2 + a2) / (1 + o2 * a2)) + 1) / 2;
      n2 = 1 - l2, i2.r = 255 & l2 * i2.r + n2 * s2.r + 0.5, i2.g = 255 & l2 * i2.g + n2 * s2.g + 0.5, i2.b = 255 & l2 * i2.b + n2 * s2.b + 0.5, i2.a = r2 * i2.a + (1 - r2) * s2.a, this.rgb = i2;
    }
    return this;
  }
  interpolate(t2, e2) {
    return t2 && (this._rgb = function(t3, e3, i2) {
      const s2 = bo(Ur(t3.r)), n2 = bo(Ur(t3.g)), r2 = bo(Ur(t3.b));
      return { r: Kr(vo(s2 + i2 * (bo(Ur(e3.r)) - s2))), g: Kr(vo(n2 + i2 * (bo(Ur(e3.g)) - n2))), b: Kr(vo(r2 + i2 * (bo(Ur(e3.b)) - r2))), a: t3.a + i2 * (e3.a - t3.a) };
    }(this._rgb, t2._rgb, e2)), this;
  }
  clone() {
    return new Color(this.rgb);
  }
  alpha(t2) {
    return this._rgb.a = Kr(t2), this;
  }
  clearer(t2) {
    return this._rgb.a *= 1 - t2, this;
  }
  greyscale() {
    const t2 = this._rgb, e2 = Hr(0.3 * t2.r + 0.59 * t2.g + 0.11 * t2.b);
    return t2.r = t2.g = t2.b = e2, this;
  }
  opaquer(t2) {
    return this._rgb.a *= 1 + t2, this;
  }
  negate() {
    const t2 = this._rgb;
    return t2.r = 255 - t2.r, t2.g = 255 - t2.g, t2.b = 255 - t2.b, this;
  }
  lighten(t2) {
    return _o(this._rgb, 2, t2), this;
  }
  darken(t2) {
    return _o(this._rgb, 2, -t2), this;
  }
  saturate(t2) {
    return _o(this._rgb, 1, t2), this;
  }
  desaturate(t2) {
    return _o(this._rgb, 1, -t2), this;
  }
  rotate(t2) {
    return function(t3, e2) {
      var i2 = oo(t3);
      i2[0] = ho(i2[0] + e2), i2 = lo(i2), t3.r = i2[0], t3.g = i2[1], t3.b = i2[2];
    }(this._rgb, t2), this;
  }
}
function ko() {
}
const Mo = /* @__PURE__ */ (() => {
  let t2 = 0;
  return () => t2++;
})();
function So(t2) {
  return null == t2;
}
function Co(t2) {
  if (Array.isArray && Array.isArray(t2)) return true;
  const e2 = Object.prototype.toString.call(t2);
  return "[object" === e2.slice(0, 7) && "Array]" === e2.slice(-6);
}
function zo(t2) {
  return null !== t2 && "[object Object]" === Object.prototype.toString.call(t2);
}
function $o(t2) {
  return ("number" == typeof t2 || t2 instanceof Number) && isFinite(+t2);
}
function Do(t2, e2) {
  return $o(t2) ? t2 : e2;
}
function Ro(t2, e2) {
  return void 0 === t2 ? e2 : t2;
}
const Eo = (t2, e2) => "string" == typeof t2 && t2.endsWith("%") ? parseFloat(t2) / 100 * e2 : +t2;
function Po(t2, e2, i2) {
  if (t2 && "function" == typeof t2.call) return t2.apply(i2, e2);
}
function To(t2, e2, i2, s2) {
  let n2, r2, o2;
  if (Co(t2)) for (r2 = t2.length, n2 = 0; n2 < r2; n2++) e2.call(i2, t2[n2], n2);
  else if (zo(t2)) for (o2 = Object.keys(t2), r2 = o2.length, n2 = 0; n2 < r2; n2++) e2.call(i2, t2[o2[n2]], o2[n2]);
}
function Lo(t2, e2) {
  let i2, s2, n2, r2;
  if (!t2 || !e2 || t2.length !== e2.length) return false;
  for (i2 = 0, s2 = t2.length; i2 < s2; ++i2) if (n2 = t2[i2], r2 = e2[i2], n2.datasetIndex !== r2.datasetIndex || n2.index !== r2.index) return false;
  return true;
}
function Vo(t2) {
  if (Co(t2)) return t2.map(Vo);
  if (zo(t2)) {
    const e2 = /* @__PURE__ */ Object.create(null), i2 = Object.keys(t2), s2 = i2.length;
    let n2 = 0;
    for (; n2 < s2; ++n2) e2[i2[n2]] = Vo(t2[i2[n2]]);
    return e2;
  }
  return t2;
}
function Oo(t2) {
  return -1 === ["__proto__", "prototype", "constructor"].indexOf(t2);
}
function Ao(t2, e2, i2, s2) {
  if (!Oo(t2)) return;
  const n2 = e2[t2], r2 = i2[t2];
  zo(n2) && zo(r2) ? Fo(n2, r2, s2) : e2[t2] = Vo(r2);
}
function Fo(t2, e2, i2) {
  const s2 = Co(e2) ? e2 : [e2], n2 = s2.length;
  if (!zo(t2)) return t2;
  const r2 = (i2 = i2 || {}).merger || Ao;
  let o2;
  for (let e3 = 0; e3 < n2; ++e3) {
    if (o2 = s2[e3], !zo(o2)) continue;
    const n3 = Object.keys(o2);
    for (let e4 = 0, s3 = n3.length; e4 < s3; ++e4) r2(n3[e4], t2, o2, i2);
  }
  return t2;
}
function No(t2, e2) {
  return Fo(t2, e2, { merger: Wo });
}
function Wo(t2, e2, i2) {
  if (!Oo(t2)) return;
  const s2 = e2[t2], n2 = i2[t2];
  zo(s2) && zo(n2) ? No(s2, n2) : Object.prototype.hasOwnProperty.call(e2, t2) || (e2[t2] = Vo(n2));
}
const Io = { "": (t2) => t2, x: (t2) => t2.x, y: (t2) => t2.y };
function Bo(t2, e2) {
  const i2 = Io[e2] || (Io[e2] = function(t3) {
    const e3 = function(t4) {
      const e4 = t4.split("."), i3 = [];
      let s2 = "";
      for (const t5 of e4) s2 += t5, s2.endsWith("\\") ? s2 = s2.slice(0, -1) + "." : (i3.push(s2), s2 = "");
      return i3;
    }(t3);
    return (t4) => {
      for (const i3 of e3) {
        if ("" === i3) break;
        t4 = t4 && t4[i3];
      }
      return t4;
    };
  }(e2));
  return i2(t2);
}
function jo(t2) {
  return t2.charAt(0).toUpperCase() + t2.slice(1);
}
const Ho = (t2) => void 0 !== t2, qo = (t2) => "function" == typeof t2, Xo = (t2, e2) => {
  if (t2.size !== e2.size) return false;
  for (const i2 of t2) if (!e2.has(i2)) return false;
  return true;
};
const Ko = Math.PI, Uo = 2 * Ko, Yo = Uo + Ko, Go = Number.POSITIVE_INFINITY, Jo = Ko / 180, Qo = Ko / 2, Zo = Ko / 4, ta = 2 * Ko / 3, ea = Math.log10, ia = Math.sign;
function sa(t2, e2, i2) {
  return Math.abs(t2 - e2) < i2;
}
function na(t2) {
  const e2 = Math.round(t2);
  t2 = sa(t2, e2, t2 / 1e3) ? e2 : t2;
  const i2 = Math.pow(10, Math.floor(ea(t2))), s2 = t2 / i2;
  return (s2 <= 1 ? 1 : s2 <= 2 ? 2 : s2 <= 5 ? 5 : 10) * i2;
}
function ra(t2) {
  return !function(t3) {
    return "symbol" == typeof t3 || "object" == typeof t3 && null !== t3 && !(Symbol.toPrimitive in t3 || "toString" in t3 || "valueOf" in t3);
  }(t2) && !isNaN(parseFloat(t2)) && isFinite(t2);
}
function oa(t2, e2, i2) {
  let s2, n2, r2;
  for (s2 = 0, n2 = t2.length; s2 < n2; s2++) r2 = t2[s2][i2], isNaN(r2) || (e2.min = Math.min(e2.min, r2), e2.max = Math.max(e2.max, r2));
}
function aa(t2) {
  return t2 * (Ko / 180);
}
function la(t2) {
  return t2 * (180 / Ko);
}
function ha(t2) {
  if (!$o(t2)) return;
  let e2 = 1, i2 = 0;
  for (; Math.round(t2 * e2) / e2 !== t2; ) e2 *= 10, i2++;
  return i2;
}
function ca(t2, e2) {
  const i2 = e2.x - t2.x, s2 = e2.y - t2.y, n2 = Math.sqrt(i2 * i2 + s2 * s2);
  let r2 = Math.atan2(s2, i2);
  return r2 < -0.5 * Ko && (r2 += Uo), { angle: r2, distance: n2 };
}
function ua(t2, e2) {
  return Math.sqrt(Math.pow(e2.x - t2.x, 2) + Math.pow(e2.y - t2.y, 2));
}
function da(t2, e2) {
  return (t2 - e2 + Yo) % Uo - Ko;
}
function fa(t2) {
  return (t2 % Uo + Uo) % Uo;
}
function pa(t2, e2, i2, s2) {
  const n2 = fa(t2), r2 = fa(e2), o2 = fa(i2), a2 = fa(r2 - n2), l2 = fa(o2 - n2), h2 = fa(n2 - r2), c2 = fa(n2 - o2);
  return n2 === r2 || n2 === o2 || s2 && r2 === o2 || a2 > l2 && h2 < c2;
}
function ma(t2, e2, i2) {
  return Math.max(e2, Math.min(i2, t2));
}
function ga(t2, e2, i2, s2 = 1e-6) {
  return t2 >= Math.min(e2, i2) - s2 && t2 <= Math.max(e2, i2) + s2;
}
function va(t2, e2, i2) {
  i2 = i2 || ((i3) => t2[i3] < e2);
  let s2, n2 = t2.length - 1, r2 = 0;
  for (; n2 - r2 > 1; ) s2 = r2 + n2 >> 1, i2(s2) ? r2 = s2 : n2 = s2;
  return { lo: r2, hi: n2 };
}
const ba = (t2, e2, i2, s2) => va(t2, i2, s2 ? (s3) => {
  const n2 = t2[s3][e2];
  return n2 < i2 || n2 === i2 && t2[s3 + 1][e2] === i2;
} : (s3) => t2[s3][e2] < i2), _a = (t2, e2, i2) => va(t2, i2, (s2) => t2[s2][e2] >= i2);
const ya = ["push", "pop", "shift", "splice", "unshift"];
function xa(t2, e2) {
  const i2 = t2._chartjs;
  if (!i2) return;
  const s2 = i2.listeners, n2 = s2.indexOf(e2);
  -1 !== n2 && s2.splice(n2, 1), s2.length > 0 || (ya.forEach((e3) => {
    delete t2[e3];
  }), delete t2._chartjs);
}
function wa(t2) {
  const e2 = new Set(t2);
  return e2.size === t2.length ? t2 : Array.from(e2);
}
const ka = "undefined" == typeof window ? function(t2) {
  return t2();
} : window.requestAnimationFrame;
function Ma(t2, e2) {
  let i2 = [], s2 = false;
  return function(...n2) {
    i2 = n2, s2 || (s2 = true, ka.call(window, () => {
      s2 = false, t2.apply(e2, i2);
    }));
  };
}
const Sa = (t2) => "start" === t2 ? "left" : "end" === t2 ? "right" : "center", Ca = (t2, e2, i2) => "start" === t2 ? e2 : "end" === t2 ? i2 : (e2 + i2) / 2;
function za(t2, e2, i2) {
  const s2 = e2.length;
  let n2 = 0, r2 = s2;
  if (t2._sorted) {
    const { iScale: o2, vScale: a2, _parsed: l2 } = t2, h2 = t2.dataset && t2.dataset.options ? t2.dataset.options.spanGaps : null, c2 = o2.axis, { min: u2, max: d2, minDefined: f2, maxDefined: p2 } = o2.getUserBounds();
    if (f2) {
      if (n2 = Math.min(ba(l2, c2, u2).lo, i2 ? s2 : ba(e2, c2, o2.getPixelForValue(u2)).lo), h2) {
        const t3 = l2.slice(0, n2 + 1).reverse().findIndex((t4) => !So(t4[a2.axis]));
        n2 -= Math.max(0, t3);
      }
      n2 = ma(n2, 0, s2 - 1);
    }
    if (p2) {
      let t3 = Math.max(ba(l2, o2.axis, d2, true).hi + 1, i2 ? 0 : ba(e2, c2, o2.getPixelForValue(d2), true).hi + 1);
      if (h2) {
        const e3 = l2.slice(t3 - 1).findIndex((t4) => !So(t4[a2.axis]));
        t3 += Math.max(0, e3);
      }
      r2 = ma(t3, n2, s2) - n2;
    } else r2 = s2 - n2;
  }
  return { start: n2, count: r2 };
}
function $a(t2) {
  const { xScale: e2, yScale: i2, _scaleRanges: s2 } = t2, n2 = { xmin: e2.min, xmax: e2.max, ymin: i2.min, ymax: i2.max };
  if (!s2) return t2._scaleRanges = n2, true;
  const r2 = s2.xmin !== e2.min || s2.xmax !== e2.max || s2.ymin !== i2.min || s2.ymax !== i2.max;
  return Object.assign(s2, n2), r2;
}
const Da = (t2) => 0 === t2 || 1 === t2, Ra = (t2, e2, i2) => -Math.pow(2, 10 * (t2 -= 1)) * Math.sin((t2 - e2) * Uo / i2), Ea = (t2, e2, i2) => Math.pow(2, -10 * t2) * Math.sin((t2 - e2) * Uo / i2) + 1, Pa = { linear: (t2) => t2, easeInQuad: (t2) => t2 * t2, easeOutQuad: (t2) => -t2 * (t2 - 2), easeInOutQuad: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 : -0.5 * (--t2 * (t2 - 2) - 1), easeInCubic: (t2) => t2 * t2 * t2, easeOutCubic: (t2) => (t2 -= 1) * t2 * t2 + 1, easeInOutCubic: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 * t2 : 0.5 * ((t2 -= 2) * t2 * t2 + 2), easeInQuart: (t2) => t2 * t2 * t2 * t2, easeOutQuart: (t2) => -((t2 -= 1) * t2 * t2 * t2 - 1), easeInOutQuart: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 * t2 * t2 : -0.5 * ((t2 -= 2) * t2 * t2 * t2 - 2), easeInQuint: (t2) => t2 * t2 * t2 * t2 * t2, easeOutQuint: (t2) => (t2 -= 1) * t2 * t2 * t2 * t2 + 1, easeInOutQuint: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 * t2 * t2 * t2 : 0.5 * ((t2 -= 2) * t2 * t2 * t2 * t2 + 2), easeInSine: (t2) => 1 - Math.cos(t2 * Qo), easeOutSine: (t2) => Math.sin(t2 * Qo), easeInOutSine: (t2) => -0.5 * (Math.cos(Ko * t2) - 1), easeInExpo: (t2) => 0 === t2 ? 0 : Math.pow(2, 10 * (t2 - 1)), easeOutExpo: (t2) => 1 === t2 ? 1 : 1 - Math.pow(2, -10 * t2), easeInOutExpo: (t2) => Da(t2) ? t2 : t2 < 0.5 ? 0.5 * Math.pow(2, 10 * (2 * t2 - 1)) : 0.5 * (2 - Math.pow(2, -10 * (2 * t2 - 1))), easeInCirc: (t2) => t2 >= 1 ? t2 : -(Math.sqrt(1 - t2 * t2) - 1), easeOutCirc: (t2) => Math.sqrt(1 - (t2 -= 1) * t2), easeInOutCirc: (t2) => (t2 /= 0.5) < 1 ? -0.5 * (Math.sqrt(1 - t2 * t2) - 1) : 0.5 * (Math.sqrt(1 - (t2 -= 2) * t2) + 1), easeInElastic: (t2) => Da(t2) ? t2 : Ra(t2, 0.075, 0.3), easeOutElastic: (t2) => Da(t2) ? t2 : Ea(t2, 0.075, 0.3), easeInOutElastic(t2) {
  const e2 = 0.1125;
  return Da(t2) ? t2 : t2 < 0.5 ? 0.5 * Ra(2 * t2, e2, 0.45) : 0.5 + 0.5 * Ea(2 * t2 - 1, e2, 0.45);
}, easeInBack(t2) {
  const e2 = 1.70158;
  return t2 * t2 * ((e2 + 1) * t2 - e2);
}, easeOutBack(t2) {
  const e2 = 1.70158;
  return (t2 -= 1) * t2 * ((e2 + 1) * t2 + e2) + 1;
}, easeInOutBack(t2) {
  let e2 = 1.70158;
  return (t2 /= 0.5) < 1 ? t2 * t2 * ((1 + (e2 *= 1.525)) * t2 - e2) * 0.5 : 0.5 * ((t2 -= 2) * t2 * ((1 + (e2 *= 1.525)) * t2 + e2) + 2);
}, easeInBounce: (t2) => 1 - Pa.easeOutBounce(1 - t2), easeOutBounce(t2) {
  const e2 = 7.5625, i2 = 2.75;
  return t2 < 1 / i2 ? e2 * t2 * t2 : t2 < 2 / i2 ? e2 * (t2 -= 1.5 / i2) * t2 + 0.75 : t2 < 2.5 / i2 ? e2 * (t2 -= 2.25 / i2) * t2 + 0.9375 : e2 * (t2 -= 2.625 / i2) * t2 + 0.984375;
}, easeInOutBounce: (t2) => t2 < 0.5 ? 0.5 * Pa.easeInBounce(2 * t2) : 0.5 * Pa.easeOutBounce(2 * t2 - 1) + 0.5 };
function Ta(t2) {
  if (t2 && "object" == typeof t2) {
    const e2 = t2.toString();
    return "[object CanvasPattern]" === e2 || "[object CanvasGradient]" === e2;
  }
  return false;
}
function La(t2) {
  return Ta(t2) ? t2 : new Color(t2);
}
function Va(t2) {
  return Ta(t2) ? t2 : new Color(t2).saturate(0.5).darken(0.1).hexString();
}
const Oa = ["x", "y", "borderWidth", "radius", "tension"], Aa = ["color", "borderColor", "backgroundColor"];
const Fa = /* @__PURE__ */ new Map();
function Na(t2, e2, i2) {
  return function(t3, e3) {
    e3 = e3 || {};
    const i3 = t3 + JSON.stringify(e3);
    let s2 = Fa.get(i3);
    return s2 || (s2 = new Intl.NumberFormat(t3, e3), Fa.set(i3, s2)), s2;
  }(e2, i2).format(t2);
}
const Wa = { values: (t2) => Co(t2) ? t2 : "" + t2, numeric(t2, e2, i2) {
  if (0 === t2) return "0";
  const s2 = this.chart.options.locale;
  let n2, r2 = t2;
  if (i2.length > 1) {
    const e3 = Math.max(Math.abs(i2[0].value), Math.abs(i2[i2.length - 1].value));
    (e3 < 1e-4 || e3 > 1e15) && (n2 = "scientific"), r2 = function(t3, e4) {
      let i3 = e4.length > 3 ? e4[2].value - e4[1].value : e4[1].value - e4[0].value;
      Math.abs(i3) >= 1 && t3 !== Math.floor(t3) && (i3 = t3 - Math.floor(t3));
      return i3;
    }(t2, i2);
  }
  const o2 = ea(Math.abs(r2)), a2 = isNaN(o2) ? 1 : Math.max(Math.min(-1 * Math.floor(o2), 20), 0), l2 = { notation: n2, minimumFractionDigits: a2, maximumFractionDigits: a2 };
  return Object.assign(l2, this.options.ticks.format), Na(t2, s2, l2);
}, logarithmic(t2, e2, i2) {
  if (0 === t2) return "0";
  const s2 = i2[e2].significand || t2 / Math.pow(10, Math.floor(ea(t2)));
  return [1, 2, 3, 5, 10, 15].includes(s2) || e2 > 0.8 * i2.length ? Wa.numeric.call(this, t2, e2, i2) : "";
} };
var Ia = { formatters: Wa };
const Ba = /* @__PURE__ */ Object.create(null), ja = /* @__PURE__ */ Object.create(null);
function Ha(t2, e2) {
  if (!e2) return t2;
  const i2 = e2.split(".");
  for (let e3 = 0, s2 = i2.length; e3 < s2; ++e3) {
    const s3 = i2[e3];
    t2 = t2[s3] || (t2[s3] = /* @__PURE__ */ Object.create(null));
  }
  return t2;
}
function qa(t2, e2, i2) {
  return "string" == typeof e2 ? Fo(Ha(t2, e2), i2) : Fo(Ha(t2, ""), e2);
}
class Defaults {
  constructor(t2, e2) {
    this.animation = void 0, this.backgroundColor = "rgba(0,0,0,0.1)", this.borderColor = "rgba(0,0,0,0.1)", this.color = "#666", this.datasets = {}, this.devicePixelRatio = (t3) => t3.chart.platform.getDevicePixelRatio(), this.elements = {}, this.events = ["mousemove", "mouseout", "click", "touchstart", "touchmove"], this.font = { family: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif", size: 12, style: "normal", lineHeight: 1.2, weight: null }, this.hover = {}, this.hoverBackgroundColor = (t3, e3) => Va(e3.backgroundColor), this.hoverBorderColor = (t3, e3) => Va(e3.borderColor), this.hoverColor = (t3, e3) => Va(e3.color), this.indexAxis = "x", this.interaction = { mode: "nearest", intersect: true, includeInvisible: false }, this.maintainAspectRatio = true, this.onHover = null, this.onClick = null, this.parsing = true, this.plugins = {}, this.responsive = true, this.scale = void 0, this.scales = {}, this.showLine = true, this.drawActiveElementsOnTop = true, this.describe(t2), this.apply(e2);
  }
  set(t2, e2) {
    return qa(this, t2, e2);
  }
  get(t2) {
    return Ha(this, t2);
  }
  describe(t2, e2) {
    return qa(ja, t2, e2);
  }
  override(t2, e2) {
    return qa(Ba, t2, e2);
  }
  route(t2, e2, i2, s2) {
    const n2 = Ha(this, t2), r2 = Ha(this, i2), o2 = "_" + e2;
    Object.defineProperties(n2, { [o2]: { value: n2[e2], writable: true }, [e2]: { enumerable: true, get() {
      const t3 = this[o2], e3 = r2[s2];
      return zo(t3) ? Object.assign({}, e3, t3) : Ro(t3, e3);
    }, set(t3) {
      this[o2] = t3;
    } } });
  }
  apply(t2) {
    t2.forEach((t3) => t3(this));
  }
}
var Xa = new Defaults({ _scriptable: (t2) => !t2.startsWith("on"), _indexable: (t2) => "events" !== t2, hover: { _fallback: "interaction" }, interaction: { _scriptable: false, _indexable: false } }, [function(t2) {
  t2.set("animation", { delay: void 0, duration: 1e3, easing: "easeOutQuart", fn: void 0, from: void 0, loop: void 0, to: void 0, type: void 0 }), t2.describe("animation", { _fallback: false, _indexable: false, _scriptable: (t3) => "onProgress" !== t3 && "onComplete" !== t3 && "fn" !== t3 }), t2.set("animations", { colors: { type: "color", properties: Aa }, numbers: { type: "number", properties: Oa } }), t2.describe("animations", { _fallback: "animation" }), t2.set("transitions", { active: { animation: { duration: 400 } }, resize: { animation: { duration: 0 } }, show: { animations: { colors: { from: "transparent" }, visible: { type: "boolean", duration: 0 } } }, hide: { animations: { colors: { to: "transparent" }, visible: { type: "boolean", easing: "linear", fn: (t3) => 0 | t3 } } } });
}, function(t2) {
  t2.set("layout", { autoPadding: true, padding: { top: 0, right: 0, bottom: 0, left: 0 } });
}, function(t2) {
  t2.set("scale", { display: true, offset: false, reverse: false, beginAtZero: false, bounds: "ticks", clip: true, grace: 0, grid: { display: true, lineWidth: 1, drawOnChartArea: true, drawTicks: true, tickLength: 8, tickWidth: (t3, e2) => e2.lineWidth, tickColor: (t3, e2) => e2.color, offset: false }, border: { display: true, dash: [], dashOffset: 0, width: 1 }, title: { display: false, text: "", padding: { top: 4, bottom: 4 } }, ticks: { minRotation: 0, maxRotation: 50, mirror: false, textStrokeWidth: 0, textStrokeColor: "", padding: 3, display: true, autoSkip: true, autoSkipPadding: 3, labelOffset: 0, callback: Ia.formatters.values, minor: {}, major: {}, align: "center", crossAlign: "near", showLabelBackdrop: false, backdropColor: "rgba(255, 255, 255, 0.75)", backdropPadding: 2 } }), t2.route("scale.ticks", "color", "", "color"), t2.route("scale.grid", "color", "", "borderColor"), t2.route("scale.border", "color", "", "borderColor"), t2.route("scale.title", "color", "", "color"), t2.describe("scale", { _fallback: false, _scriptable: (t3) => !t3.startsWith("before") && !t3.startsWith("after") && "callback" !== t3 && "parser" !== t3, _indexable: (t3) => "borderDash" !== t3 && "tickBorderDash" !== t3 && "dash" !== t3 }), t2.describe("scales", { _fallback: "scale" }), t2.describe("scale.ticks", { _scriptable: (t3) => "backdropPadding" !== t3 && "callback" !== t3, _indexable: (t3) => "backdropPadding" !== t3 });
}]);
function Ka(t2, e2, i2, s2, n2) {
  let r2 = e2[n2];
  return r2 || (r2 = e2[n2] = t2.measureText(n2).width, i2.push(n2)), r2 > s2 && (s2 = r2), s2;
}
function Ua(t2, e2, i2, s2) {
  let n2 = (s2 = s2 || {}).data = s2.data || {}, r2 = s2.garbageCollect = s2.garbageCollect || [];
  s2.font !== e2 && (n2 = s2.data = {}, r2 = s2.garbageCollect = [], s2.font = e2), t2.save(), t2.font = e2;
  let o2 = 0;
  const a2 = i2.length;
  let l2, h2, c2, u2, d2;
  for (l2 = 0; l2 < a2; l2++) if (u2 = i2[l2], null == u2 || Co(u2)) {
    if (Co(u2)) for (h2 = 0, c2 = u2.length; h2 < c2; h2++) d2 = u2[h2], null == d2 || Co(d2) || (o2 = Ka(t2, n2, r2, o2, d2));
  } else o2 = Ka(t2, n2, r2, o2, u2);
  t2.restore();
  const f2 = r2.length / 2;
  if (f2 > i2.length) {
    for (l2 = 0; l2 < f2; l2++) delete n2[r2[l2]];
    r2.splice(0, f2);
  }
  return o2;
}
function Ya(t2, e2, i2) {
  const s2 = t2.currentDevicePixelRatio, n2 = 0 !== i2 ? Math.max(i2 / 2, 0.5) : 0;
  return Math.round((e2 - n2) * s2) / s2 + n2;
}
function Ga(t2, e2) {
  (e2 || t2) && ((e2 = e2 || t2.getContext("2d")).save(), e2.resetTransform(), e2.clearRect(0, 0, t2.width, t2.height), e2.restore());
}
function Ja(t2, e2, i2, s2) {
  Qa(t2, e2, i2, s2, null);
}
function Qa(t2, e2, i2, s2, n2) {
  let r2, o2, a2, l2, h2, c2, u2, d2;
  const f2 = e2.pointStyle, p2 = e2.rotation, m2 = e2.radius;
  let g2 = (p2 || 0) * Jo;
  if (f2 && "object" == typeof f2 && (r2 = f2.toString(), "[object HTMLImageElement]" === r2 || "[object HTMLCanvasElement]" === r2)) return t2.save(), t2.translate(i2, s2), t2.rotate(g2), t2.drawImage(f2, -f2.width / 2, -f2.height / 2, f2.width, f2.height), void t2.restore();
  if (!(isNaN(m2) || m2 <= 0)) {
    switch (t2.beginPath(), f2) {
      default:
        n2 ? t2.ellipse(i2, s2, n2 / 2, m2, 0, 0, Uo) : t2.arc(i2, s2, m2, 0, Uo), t2.closePath();
        break;
      case "triangle":
        c2 = n2 ? n2 / 2 : m2, t2.moveTo(i2 + Math.sin(g2) * c2, s2 - Math.cos(g2) * m2), g2 += ta, t2.lineTo(i2 + Math.sin(g2) * c2, s2 - Math.cos(g2) * m2), g2 += ta, t2.lineTo(i2 + Math.sin(g2) * c2, s2 - Math.cos(g2) * m2), t2.closePath();
        break;
      case "rectRounded":
        h2 = 0.516 * m2, l2 = m2 - h2, o2 = Math.cos(g2 + Zo) * l2, u2 = Math.cos(g2 + Zo) * (n2 ? n2 / 2 - h2 : l2), a2 = Math.sin(g2 + Zo) * l2, d2 = Math.sin(g2 + Zo) * (n2 ? n2 / 2 - h2 : l2), t2.arc(i2 - u2, s2 - a2, h2, g2 - Ko, g2 - Qo), t2.arc(i2 + d2, s2 - o2, h2, g2 - Qo, g2), t2.arc(i2 + u2, s2 + a2, h2, g2, g2 + Qo), t2.arc(i2 - d2, s2 + o2, h2, g2 + Qo, g2 + Ko), t2.closePath();
        break;
      case "rect":
        if (!p2) {
          l2 = Math.SQRT1_2 * m2, c2 = n2 ? n2 / 2 : l2, t2.rect(i2 - c2, s2 - l2, 2 * c2, 2 * l2);
          break;
        }
        g2 += Zo;
      case "rectRot":
        u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + d2, s2 - o2), t2.lineTo(i2 + u2, s2 + a2), t2.lineTo(i2 - d2, s2 + o2), t2.closePath();
        break;
      case "crossRot":
        g2 += Zo;
      case "cross":
        u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + u2, s2 + a2), t2.moveTo(i2 + d2, s2 - o2), t2.lineTo(i2 - d2, s2 + o2);
        break;
      case "star":
        u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + u2, s2 + a2), t2.moveTo(i2 + d2, s2 - o2), t2.lineTo(i2 - d2, s2 + o2), g2 += Zo, u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + u2, s2 + a2), t2.moveTo(i2 + d2, s2 - o2), t2.lineTo(i2 - d2, s2 + o2);
        break;
      case "line":
        o2 = n2 ? n2 / 2 : Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, t2.moveTo(i2 - o2, s2 - a2), t2.lineTo(i2 + o2, s2 + a2);
        break;
      case "dash":
        t2.moveTo(i2, s2), t2.lineTo(i2 + Math.cos(g2) * (n2 ? n2 / 2 : m2), s2 + Math.sin(g2) * m2);
        break;
      case false:
        t2.closePath();
    }
    t2.fill(), e2.borderWidth > 0 && t2.stroke();
  }
}
function Za(t2, e2, i2) {
  return i2 = i2 || 0.5, !e2 || t2 && t2.x > e2.left - i2 && t2.x < e2.right + i2 && t2.y > e2.top - i2 && t2.y < e2.bottom + i2;
}
function tl(t2, e2) {
  t2.save(), t2.beginPath(), t2.rect(e2.left, e2.top, e2.right - e2.left, e2.bottom - e2.top), t2.clip();
}
function el(t2) {
  t2.restore();
}
function il(t2, e2, i2, s2, n2) {
  if (!e2) return t2.lineTo(i2.x, i2.y);
  if ("middle" === n2) {
    const s3 = (e2.x + i2.x) / 2;
    t2.lineTo(s3, e2.y), t2.lineTo(s3, i2.y);
  } else "after" === n2 != !!s2 ? t2.lineTo(e2.x, i2.y) : t2.lineTo(i2.x, e2.y);
  t2.lineTo(i2.x, i2.y);
}
function sl(t2, e2, i2, s2) {
  if (!e2) return t2.lineTo(i2.x, i2.y);
  t2.bezierCurveTo(s2 ? e2.cp1x : e2.cp2x, s2 ? e2.cp1y : e2.cp2y, s2 ? i2.cp2x : i2.cp1x, s2 ? i2.cp2y : i2.cp1y, i2.x, i2.y);
}
function nl(t2, e2, i2, s2, n2) {
  if (n2.strikethrough || n2.underline) {
    const r2 = t2.measureText(s2), o2 = e2 - r2.actualBoundingBoxLeft, a2 = e2 + r2.actualBoundingBoxRight, l2 = i2 - r2.actualBoundingBoxAscent, h2 = i2 + r2.actualBoundingBoxDescent, c2 = n2.strikethrough ? (l2 + h2) / 2 : h2;
    t2.strokeStyle = t2.fillStyle, t2.beginPath(), t2.lineWidth = n2.decorationWidth || 2, t2.moveTo(o2, c2), t2.lineTo(a2, c2), t2.stroke();
  }
}
function rl(t2, e2) {
  const i2 = t2.fillStyle;
  t2.fillStyle = e2.color, t2.fillRect(e2.left, e2.top, e2.width, e2.height), t2.fillStyle = i2;
}
function ol(t2, e2, i2, s2, n2, r2 = {}) {
  const o2 = Co(e2) ? e2 : [e2], a2 = r2.strokeWidth > 0 && "" !== r2.strokeColor;
  let l2, h2;
  for (t2.save(), t2.font = n2.string, function(t3, e3) {
    e3.translation && t3.translate(e3.translation[0], e3.translation[1]), So(e3.rotation) || t3.rotate(e3.rotation), e3.color && (t3.fillStyle = e3.color), e3.textAlign && (t3.textAlign = e3.textAlign), e3.textBaseline && (t3.textBaseline = e3.textBaseline);
  }(t2, r2), l2 = 0; l2 < o2.length; ++l2) h2 = o2[l2], r2.backdrop && rl(t2, r2.backdrop), a2 && (r2.strokeColor && (t2.strokeStyle = r2.strokeColor), So(r2.strokeWidth) || (t2.lineWidth = r2.strokeWidth), t2.strokeText(h2, i2, s2, r2.maxWidth)), t2.fillText(h2, i2, s2, r2.maxWidth), nl(t2, i2, s2, h2, r2), s2 += Number(n2.lineHeight);
  t2.restore();
}
function al(t2, e2) {
  const { x: i2, y: s2, w: n2, h: r2, radius: o2 } = e2;
  t2.arc(i2 + o2.topLeft, s2 + o2.topLeft, o2.topLeft, 1.5 * Ko, Ko, true), t2.lineTo(i2, s2 + r2 - o2.bottomLeft), t2.arc(i2 + o2.bottomLeft, s2 + r2 - o2.bottomLeft, o2.bottomLeft, Ko, Qo, true), t2.lineTo(i2 + n2 - o2.bottomRight, s2 + r2), t2.arc(i2 + n2 - o2.bottomRight, s2 + r2 - o2.bottomRight, o2.bottomRight, Qo, 0, true), t2.lineTo(i2 + n2, s2 + o2.topRight), t2.arc(i2 + n2 - o2.topRight, s2 + o2.topRight, o2.topRight, 0, -Qo, true), t2.lineTo(i2 + o2.topLeft, s2);
}
const ll = /^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/, hl = /^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;
function cl(t2, e2) {
  const i2 = ("" + t2).match(ll);
  if (!i2 || "normal" === i2[1]) return 1.2 * e2;
  switch (t2 = +i2[2], i2[3]) {
    case "px":
      return t2;
    case "%":
      t2 /= 100;
  }
  return e2 * t2;
}
const ul = (t2) => +t2 || 0;
function dl(t2, e2) {
  const i2 = {}, s2 = zo(e2), n2 = s2 ? Object.keys(e2) : e2, r2 = zo(t2) ? s2 ? (i3) => Ro(t2[i3], t2[e2[i3]]) : (e3) => t2[e3] : () => t2;
  for (const t3 of n2) i2[t3] = ul(r2(t3));
  return i2;
}
function fl(t2) {
  return dl(t2, { top: "y", right: "x", bottom: "y", left: "x" });
}
function pl(t2) {
  return dl(t2, ["topLeft", "topRight", "bottomLeft", "bottomRight"]);
}
function ml(t2) {
  const e2 = fl(t2);
  return e2.width = e2.left + e2.right, e2.height = e2.top + e2.bottom, e2;
}
function gl(t2, e2) {
  t2 = t2 || {}, e2 = e2 || Xa.font;
  let i2 = Ro(t2.size, e2.size);
  "string" == typeof i2 && (i2 = parseInt(i2, 10));
  let s2 = Ro(t2.style, e2.style);
  s2 && !("" + s2).match(hl) && (console.warn('Invalid font style specified: "' + s2 + '"'), s2 = void 0);
  const n2 = { family: Ro(t2.family, e2.family), lineHeight: cl(Ro(t2.lineHeight, e2.lineHeight), i2), size: i2, style: s2, weight: Ro(t2.weight, e2.weight), string: "" };
  return n2.string = function(t3) {
    return !t3 || So(t3.size) || So(t3.family) ? null : (t3.style ? t3.style + " " : "") + (t3.weight ? t3.weight + " " : "") + t3.size + "px " + t3.family;
  }(n2), n2;
}
function vl(t2, e2, i2, s2) {
  let n2, r2, o2;
  for (n2 = 0, r2 = t2.length; n2 < r2; ++n2) if (o2 = t2[n2], void 0 !== o2 && void 0 !== o2) return o2;
}
function bl(t2, e2) {
  return Object.assign(Object.create(t2), e2);
}
function _l(t2, e2 = [""], i2, s2, n2 = () => t2[0]) {
  const r2 = i2 || t2;
  void 0 === s2 && (s2 = Rl("_fallback", t2));
  const o2 = { [Symbol.toStringTag]: "Object", _cacheable: true, _scopes: t2, _rootScopes: r2, _fallback: s2, _getTarget: n2, override: (i3) => _l([i3, ...t2], e2, r2, s2) };
  return new Proxy(o2, { deleteProperty: (e3, i3) => (delete e3[i3], delete e3._keys, delete t2[0][i3], true), get: (i3, s3) => Ml(i3, s3, () => function(t3, e3, i4, s4) {
    let n3;
    for (const r3 of e3) if (n3 = Rl(wl(r3, t3), i4), void 0 !== n3) return kl(t3, n3) ? $l(i4, s4, t3, n3) : n3;
  }(s3, e2, t2, i3)), getOwnPropertyDescriptor: (t3, e3) => Reflect.getOwnPropertyDescriptor(t3._scopes[0], e3), getPrototypeOf: () => Reflect.getPrototypeOf(t2[0]), has: (t3, e3) => El(t3).includes(e3), ownKeys: (t3) => El(t3), set(t3, e3, i3) {
    const s3 = t3._storage || (t3._storage = n2());
    return t3[e3] = s3[e3] = i3, delete t3._keys, true;
  } });
}
function yl(t2, e2, i2, s2) {
  const n2 = { _cacheable: false, _proxy: t2, _context: e2, _subProxy: i2, _stack: /* @__PURE__ */ new Set(), _descriptors: xl(t2, s2), setContext: (e3) => yl(t2, e3, i2, s2), override: (n3) => yl(t2.override(n3), e2, i2, s2) };
  return new Proxy(n2, { deleteProperty: (e3, i3) => (delete e3[i3], delete t2[i3], true), get: (t3, e3, i3) => Ml(t3, e3, () => function(t4, e4, i4) {
    const { _proxy: s3, _context: n3, _subProxy: r2, _descriptors: o2 } = t4;
    let a2 = s3[e4];
    qo(a2) && o2.isScriptable(e4) && (a2 = function(t5, e5, i5, s4) {
      const { _proxy: n4, _context: r3, _subProxy: o3, _stack: a3 } = i5;
      if (a3.has(t5)) throw new Error("Recursion detected: " + Array.from(a3).join("->") + "->" + t5);
      a3.add(t5);
      let l2 = e5(r3, o3 || s4);
      a3.delete(t5), kl(t5, l2) && (l2 = $l(n4._scopes, n4, t5, l2));
      return l2;
    }(e4, a2, t4, i4));
    Co(a2) && a2.length && (a2 = function(t5, e5, i5, s4) {
      const { _proxy: n4, _context: r3, _subProxy: o3, _descriptors: a3 } = i5;
      if (void 0 !== r3.index && s4(t5)) return e5[r3.index % e5.length];
      if (zo(e5[0])) {
        const i6 = e5, s5 = n4._scopes.filter((t6) => t6 !== i6);
        e5 = [];
        for (const l2 of i6) {
          const i7 = $l(s5, n4, t5, l2);
          e5.push(yl(i7, r3, o3 && o3[t5], a3));
        }
      }
      return e5;
    }(e4, a2, t4, o2.isIndexable));
    kl(e4, a2) && (a2 = yl(a2, n3, r2 && r2[e4], o2));
    return a2;
  }(t3, e3, i3)), getOwnPropertyDescriptor: (e3, i3) => e3._descriptors.allKeys ? Reflect.has(t2, i3) ? { enumerable: true, configurable: true } : void 0 : Reflect.getOwnPropertyDescriptor(t2, i3), getPrototypeOf: () => Reflect.getPrototypeOf(t2), has: (e3, i3) => Reflect.has(t2, i3), ownKeys: () => Reflect.ownKeys(t2), set: (e3, i3, s3) => (t2[i3] = s3, delete e3[i3], true) });
}
function xl(t2, e2 = { scriptable: true, indexable: true }) {
  const { _scriptable: i2 = e2.scriptable, _indexable: s2 = e2.indexable, _allKeys: n2 = e2.allKeys } = t2;
  return { allKeys: n2, scriptable: i2, indexable: s2, isScriptable: qo(i2) ? i2 : () => i2, isIndexable: qo(s2) ? s2 : () => s2 };
}
const wl = (t2, e2) => t2 ? t2 + jo(e2) : e2, kl = (t2, e2) => zo(e2) && "adapters" !== t2 && (null === Object.getPrototypeOf(e2) || e2.constructor === Object);
function Ml(t2, e2, i2) {
  if (Object.prototype.hasOwnProperty.call(t2, e2) || "constructor" === e2) return t2[e2];
  const s2 = i2();
  return t2[e2] = s2, s2;
}
function Sl(t2, e2, i2) {
  return qo(t2) ? t2(e2, i2) : t2;
}
const Cl = (t2, e2) => true === t2 ? e2 : "string" == typeof t2 ? Bo(e2, t2) : void 0;
function zl(t2, e2, i2, s2, n2) {
  for (const r2 of e2) {
    const e3 = Cl(i2, r2);
    if (e3) {
      t2.add(e3);
      const r3 = Sl(e3._fallback, i2, n2);
      if (void 0 !== r3 && r3 !== i2 && r3 !== s2) return r3;
    } else if (false === e3 && void 0 !== s2 && i2 !== s2) return null;
  }
  return false;
}
function $l(t2, e2, i2, s2) {
  const n2 = e2._rootScopes, r2 = Sl(e2._fallback, i2, s2), o2 = [...t2, ...n2], a2 = /* @__PURE__ */ new Set();
  a2.add(s2);
  let l2 = Dl(a2, o2, i2, r2 || i2, s2);
  return null !== l2 && ((void 0 === r2 || r2 === i2 || (l2 = Dl(a2, o2, r2, l2, s2), null !== l2)) && _l(Array.from(a2), [""], n2, r2, () => function(t3, e3, i3) {
    const s3 = t3._getTarget();
    e3 in s3 || (s3[e3] = {});
    const n3 = s3[e3];
    if (Co(n3) && zo(i3)) return i3;
    return n3 || {};
  }(e2, i2, s2)));
}
function Dl(t2, e2, i2, s2, n2) {
  for (; i2; ) i2 = zl(t2, e2, i2, s2, n2);
  return i2;
}
function Rl(t2, e2) {
  for (const i2 of e2) {
    if (!i2) continue;
    const e3 = i2[t2];
    if (void 0 !== e3) return e3;
  }
}
function El(t2) {
  let e2 = t2._keys;
  return e2 || (e2 = t2._keys = function(t3) {
    const e3 = /* @__PURE__ */ new Set();
    for (const i2 of t3) for (const t4 of Object.keys(i2).filter((t5) => !t5.startsWith("_"))) e3.add(t4);
    return Array.from(e3);
  }(t2._scopes)), e2;
}
function Pl(t2, e2, i2, s2) {
  const { iScale: n2 } = t2, { key: r2 = "r" } = this._parsing, o2 = new Array(s2);
  let a2, l2, h2, c2;
  for (a2 = 0, l2 = s2; a2 < l2; ++a2) h2 = a2 + i2, c2 = e2[h2], o2[a2] = { r: n2.parse(Bo(c2, r2), h2) };
  return o2;
}
const Tl = Number.EPSILON || 1e-14, Ll = (t2, e2) => e2 < t2.length && !t2[e2].skip && t2[e2], Vl = (t2) => "x" === t2 ? "y" : "x";
function Ol(t2, e2, i2, s2) {
  const n2 = t2.skip ? e2 : t2, r2 = e2, o2 = i2.skip ? e2 : i2, a2 = ua(r2, n2), l2 = ua(o2, r2);
  let h2 = a2 / (a2 + l2), c2 = l2 / (a2 + l2);
  h2 = isNaN(h2) ? 0 : h2, c2 = isNaN(c2) ? 0 : c2;
  const u2 = s2 * h2, d2 = s2 * c2;
  return { previous: { x: r2.x - u2 * (o2.x - n2.x), y: r2.y - u2 * (o2.y - n2.y) }, next: { x: r2.x + d2 * (o2.x - n2.x), y: r2.y + d2 * (o2.y - n2.y) } };
}
function Al(t2, e2 = "x") {
  const i2 = Vl(e2), s2 = t2.length, n2 = Array(s2).fill(0), r2 = Array(s2);
  let o2, a2, l2, h2 = Ll(t2, 0);
  for (o2 = 0; o2 < s2; ++o2) if (a2 = l2, l2 = h2, h2 = Ll(t2, o2 + 1), l2) {
    if (h2) {
      const t3 = h2[e2] - l2[e2];
      n2[o2] = 0 !== t3 ? (h2[i2] - l2[i2]) / t3 : 0;
    }
    r2[o2] = a2 ? h2 ? ia(n2[o2 - 1]) !== ia(n2[o2]) ? 0 : (n2[o2 - 1] + n2[o2]) / 2 : n2[o2 - 1] : n2[o2];
  }
  !function(t3, e3, i3) {
    const s3 = t3.length;
    let n3, r3, o3, a3, l3, h3 = Ll(t3, 0);
    for (let c2 = 0; c2 < s3 - 1; ++c2) l3 = h3, h3 = Ll(t3, c2 + 1), l3 && h3 && (sa(e3[c2], 0, Tl) ? i3[c2] = i3[c2 + 1] = 0 : (n3 = i3[c2] / e3[c2], r3 = i3[c2 + 1] / e3[c2], a3 = Math.pow(n3, 2) + Math.pow(r3, 2), a3 <= 9 || (o3 = 3 / Math.sqrt(a3), i3[c2] = n3 * o3 * e3[c2], i3[c2 + 1] = r3 * o3 * e3[c2])));
  }(t2, n2, r2), function(t3, e3, i3 = "x") {
    const s3 = Vl(i3), n3 = t3.length;
    let r3, o3, a3, l3 = Ll(t3, 0);
    for (let h3 = 0; h3 < n3; ++h3) {
      if (o3 = a3, a3 = l3, l3 = Ll(t3, h3 + 1), !a3) continue;
      const n4 = a3[i3], c2 = a3[s3];
      o3 && (r3 = (n4 - o3[i3]) / 3, a3[`cp1${i3}`] = n4 - r3, a3[`cp1${s3}`] = c2 - r3 * e3[h3]), l3 && (r3 = (l3[i3] - n4) / 3, a3[`cp2${i3}`] = n4 + r3, a3[`cp2${s3}`] = c2 + r3 * e3[h3]);
    }
  }(t2, r2, e2);
}
function Fl(t2, e2, i2) {
  return Math.max(Math.min(t2, i2), e2);
}
function Nl(t2, e2, i2, s2, n2) {
  let r2, o2, a2, l2;
  if (e2.spanGaps && (t2 = t2.filter((t3) => !t3.skip)), "monotone" === e2.cubicInterpolationMode) Al(t2, n2);
  else {
    let i3 = s2 ? t2[t2.length - 1] : t2[0];
    for (r2 = 0, o2 = t2.length; r2 < o2; ++r2) a2 = t2[r2], l2 = Ol(i3, a2, t2[Math.min(r2 + 1, o2 - (s2 ? 0 : 1)) % o2], e2.tension), a2.cp1x = l2.previous.x, a2.cp1y = l2.previous.y, a2.cp2x = l2.next.x, a2.cp2y = l2.next.y, i3 = a2;
  }
  e2.capBezierPoints && function(t3, e3) {
    let i3, s3, n3, r3, o3, a3 = Za(t3[0], e3);
    for (i3 = 0, s3 = t3.length; i3 < s3; ++i3) o3 = r3, r3 = a3, a3 = i3 < s3 - 1 && Za(t3[i3 + 1], e3), r3 && (n3 = t3[i3], o3 && (n3.cp1x = Fl(n3.cp1x, e3.left, e3.right), n3.cp1y = Fl(n3.cp1y, e3.top, e3.bottom)), a3 && (n3.cp2x = Fl(n3.cp2x, e3.left, e3.right), n3.cp2y = Fl(n3.cp2y, e3.top, e3.bottom)));
  }(t2, i2);
}
function Wl() {
  return "undefined" != typeof window && "undefined" != typeof document;
}
function Il(t2) {
  let e2 = t2.parentNode;
  return e2 && "[object ShadowRoot]" === e2.toString() && (e2 = e2.host), e2;
}
function Bl(t2, e2, i2) {
  let s2;
  return "string" == typeof t2 ? (s2 = parseInt(t2, 10), -1 !== t2.indexOf("%") && (s2 = s2 / 100 * e2.parentNode[i2])) : s2 = t2, s2;
}
const jl = (t2) => t2.ownerDocument.defaultView.getComputedStyle(t2, null);
const Hl = ["top", "right", "bottom", "left"];
function ql(t2, e2, i2) {
  const s2 = {};
  i2 = i2 ? "-" + i2 : "";
  for (let n2 = 0; n2 < 4; n2++) {
    const r2 = Hl[n2];
    s2[r2] = parseFloat(t2[e2 + "-" + r2 + i2]) || 0;
  }
  return s2.width = s2.left + s2.right, s2.height = s2.top + s2.bottom, s2;
}
function Xl(t2, e2) {
  if ("native" in t2) return t2;
  const { canvas: i2, currentDevicePixelRatio: s2 } = e2, n2 = jl(i2), r2 = "border-box" === n2.boxSizing, o2 = ql(n2, "padding"), a2 = ql(n2, "border", "width"), { x: l2, y: h2, box: c2 } = function(t3, e3) {
    const i3 = t3.touches, s3 = i3 && i3.length ? i3[0] : t3, { offsetX: n3, offsetY: r3 } = s3;
    let o3, a3, l3 = false;
    if (((t4, e4, i4) => (t4 > 0 || e4 > 0) && (!i4 || !i4.shadowRoot))(n3, r3, t3.target)) o3 = n3, a3 = r3;
    else {
      const t4 = e3.getBoundingClientRect();
      o3 = s3.clientX - t4.left, a3 = s3.clientY - t4.top, l3 = true;
    }
    return { x: o3, y: a3, box: l3 };
  }(t2, i2), u2 = o2.left + (c2 && a2.left), d2 = o2.top + (c2 && a2.top);
  let { width: f2, height: p2 } = e2;
  return r2 && (f2 -= o2.width + a2.width, p2 -= o2.height + a2.height), { x: Math.round((l2 - u2) / f2 * i2.width / s2), y: Math.round((h2 - d2) / p2 * i2.height / s2) };
}
const Kl = (t2) => Math.round(10 * t2) / 10;
function Ul(t2, e2, i2, s2) {
  const n2 = jl(t2), r2 = ql(n2, "margin"), o2 = Bl(n2.maxWidth, t2, "clientWidth") || Go, a2 = Bl(n2.maxHeight, t2, "clientHeight") || Go, l2 = function(t3, e3, i3) {
    let s3, n3;
    if (void 0 === e3 || void 0 === i3) {
      const r3 = t3 && Il(t3);
      if (r3) {
        const t4 = r3.getBoundingClientRect(), o3 = jl(r3), a3 = ql(o3, "border", "width"), l3 = ql(o3, "padding");
        e3 = t4.width - l3.width - a3.width, i3 = t4.height - l3.height - a3.height, s3 = Bl(o3.maxWidth, r3, "clientWidth"), n3 = Bl(o3.maxHeight, r3, "clientHeight");
      } else e3 = t3.clientWidth, i3 = t3.clientHeight;
    }
    return { width: e3, height: i3, maxWidth: s3 || Go, maxHeight: n3 || Go };
  }(t2, e2, i2);
  let { width: h2, height: c2 } = l2;
  if ("content-box" === n2.boxSizing) {
    const t3 = ql(n2, "border", "width"), e3 = ql(n2, "padding");
    h2 -= e3.width + t3.width, c2 -= e3.height + t3.height;
  }
  h2 = Math.max(0, h2 - r2.width), c2 = Math.max(0, s2 ? h2 / s2 : c2 - r2.height), h2 = Kl(Math.min(h2, o2, l2.maxWidth)), c2 = Kl(Math.min(c2, a2, l2.maxHeight)), h2 && !c2 && (c2 = Kl(h2 / 2));
  return (void 0 !== e2 || void 0 !== i2) && s2 && l2.height && c2 > l2.height && (c2 = l2.height, h2 = Kl(Math.floor(c2 * s2))), { width: h2, height: c2 };
}
function Yl(t2, e2, i2) {
  const s2 = e2 || 1, n2 = Math.floor(t2.height * s2), r2 = Math.floor(t2.width * s2);
  t2.height = Math.floor(t2.height), t2.width = Math.floor(t2.width);
  const o2 = t2.canvas;
  return o2.style && (i2 || !o2.style.height && !o2.style.width) && (o2.style.height = `${t2.height}px`, o2.style.width = `${t2.width}px`), (t2.currentDevicePixelRatio !== s2 || o2.height !== n2 || o2.width !== r2) && (t2.currentDevicePixelRatio = s2, o2.height = n2, o2.width = r2, t2.ctx.setTransform(s2, 0, 0, s2, 0, 0), true);
}
const Gl = function() {
  let t2 = false;
  try {
    const e2 = { get passive() {
      return t2 = true, false;
    } };
    Wl() && (window.addEventListener("test", null, e2), window.removeEventListener("test", null, e2));
  } catch (t3) {
  }
  return t2;
}();
function Jl(t2, e2) {
  const i2 = function(t3, e3) {
    return jl(t3).getPropertyValue(e3);
  }(t2, e2), s2 = i2 && i2.match(/^(\d+)(\.\d+)?px$/);
  return s2 ? +s2[1] : void 0;
}
function Ql(t2, e2, i2, s2) {
  return { x: t2.x + i2 * (e2.x - t2.x), y: t2.y + i2 * (e2.y - t2.y) };
}
function Zl(t2, e2, i2, s2) {
  return { x: t2.x + i2 * (e2.x - t2.x), y: "middle" === s2 ? i2 < 0.5 ? t2.y : e2.y : "after" === s2 ? i2 < 1 ? t2.y : e2.y : i2 > 0 ? e2.y : t2.y };
}
function th(t2, e2, i2, s2) {
  const n2 = { x: t2.cp2x, y: t2.cp2y }, r2 = { x: e2.cp1x, y: e2.cp1y }, o2 = Ql(t2, n2, i2), a2 = Ql(n2, r2, i2), l2 = Ql(r2, e2, i2), h2 = Ql(o2, a2, i2), c2 = Ql(a2, l2, i2);
  return Ql(h2, c2, i2);
}
function eh(t2, e2, i2) {
  return t2 ? /* @__PURE__ */ function(t3, e3) {
    return { x: (i3) => t3 + t3 + e3 - i3, setWidth(t4) {
      e3 = t4;
    }, textAlign: (t4) => "center" === t4 ? t4 : "right" === t4 ? "left" : "right", xPlus: (t4, e4) => t4 - e4, leftForLtr: (t4, e4) => t4 - e4 };
  }(e2, i2) : { x: (t3) => t3, setWidth(t3) {
  }, textAlign: (t3) => t3, xPlus: (t3, e3) => t3 + e3, leftForLtr: (t3, e3) => t3 };
}
function ih(t2, e2) {
  let i2, s2;
  "ltr" !== e2 && "rtl" !== e2 || (i2 = t2.canvas.style, s2 = [i2.getPropertyValue("direction"), i2.getPropertyPriority("direction")], i2.setProperty("direction", e2, "important"), t2.prevTextDirection = s2);
}
function sh(t2, e2) {
  void 0 !== e2 && (delete t2.prevTextDirection, t2.canvas.style.setProperty("direction", e2[0], e2[1]));
}
function nh(t2) {
  return "angle" === t2 ? { between: pa, compare: da, normalize: fa } : { between: ga, compare: (t3, e2) => t3 - e2, normalize: (t3) => t3 };
}
function rh({ start: t2, end: e2, count: i2, loop: s2, style: n2 }) {
  return { start: t2 % i2, end: e2 % i2, loop: s2 && (e2 - t2 + 1) % i2 == 0, style: n2 };
}
function oh(t2, e2, i2) {
  if (!i2) return [t2];
  const { property: s2, start: n2, end: r2 } = i2, o2 = e2.length, { compare: a2, between: l2, normalize: h2 } = nh(s2), { start: c2, end: u2, loop: d2, style: f2 } = function(t3, e3, i3) {
    const { property: s3, start: n3, end: r3 } = i3, { between: o3, normalize: a3 } = nh(s3), l3 = e3.length;
    let h3, c3, { start: u3, end: d3, loop: f3 } = t3;
    if (f3) {
      for (u3 += l3, d3 += l3, h3 = 0, c3 = l3; h3 < c3 && o3(a3(e3[u3 % l3][s3]), n3, r3); ++h3) u3--, d3--;
      u3 %= l3, d3 %= l3;
    }
    return d3 < u3 && (d3 += l3), { start: u3, end: d3, loop: f3, style: t3.style };
  }(t2, e2, i2), p2 = [];
  let m2, g2, v2, b2 = false, _2 = null;
  const y2 = () => b2 || l2(n2, v2, m2) && 0 !== a2(n2, v2), x2 = () => !b2 || 0 === a2(r2, m2) || l2(r2, v2, m2);
  for (let t3 = c2, i3 = c2; t3 <= u2; ++t3) g2 = e2[t3 % o2], g2.skip || (m2 = h2(g2[s2]), m2 !== v2 && (b2 = l2(m2, n2, r2), null === _2 && y2() && (_2 = 0 === a2(m2, n2) ? t3 : i3), null !== _2 && x2() && (p2.push(rh({ start: _2, end: t3, loop: d2, count: o2, style: f2 })), _2 = null), i3 = t3, v2 = m2));
  return null !== _2 && p2.push(rh({ start: _2, end: u2, loop: d2, count: o2, style: f2 })), p2;
}
function ah(t2, e2) {
  const i2 = [], s2 = t2.segments;
  for (let n2 = 0; n2 < s2.length; n2++) {
    const r2 = oh(s2[n2], t2.points, e2);
    r2.length && i2.push(...r2);
  }
  return i2;
}
function lh(t2, e2, i2, s2) {
  return s2 && s2.setContext && i2 ? function(t3, e3, i3, s3) {
    const n2 = t3._chart.getContext(), r2 = hh(t3.options), { _datasetIndex: o2, options: { spanGaps: a2 } } = t3, l2 = i3.length, h2 = [];
    let c2 = r2, u2 = e3[0].start, d2 = u2;
    function f2(t4, e4, s4, n3) {
      const r3 = a2 ? -1 : 1;
      if (t4 !== e4) {
        for (t4 += l2; i3[t4 % l2].skip; ) t4 -= r3;
        for (; i3[e4 % l2].skip; ) e4 += r3;
        t4 % l2 !== e4 % l2 && (h2.push({ start: t4 % l2, end: e4 % l2, loop: s4, style: n3 }), c2 = n3, u2 = e4 % l2);
      }
    }
    for (const t4 of e3) {
      u2 = a2 ? u2 : t4.start;
      let e4, r3 = i3[u2 % l2];
      for (d2 = u2 + 1; d2 <= t4.end; d2++) {
        const a3 = i3[d2 % l2];
        e4 = hh(s3.setContext(bl(n2, { type: "segment", p0: r3, p1: a3, p0DataIndex: (d2 - 1) % l2, p1DataIndex: d2 % l2, datasetIndex: o2 }))), ch(e4, c2) && f2(u2, d2 - 1, t4.loop, c2), r3 = a3, c2 = e4;
      }
      u2 < d2 - 1 && f2(u2, d2 - 1, t4.loop, c2);
    }
    return h2;
  }(t2, e2, i2, s2) : e2;
}
function hh(t2) {
  return { backgroundColor: t2.backgroundColor, borderCapStyle: t2.borderCapStyle, borderDash: t2.borderDash, borderDashOffset: t2.borderDashOffset, borderJoinStyle: t2.borderJoinStyle, borderWidth: t2.borderWidth, borderColor: t2.borderColor };
}
function ch(t2, e2) {
  if (!e2) return false;
  const i2 = [], s2 = function(t3, e3) {
    return Ta(e3) ? (i2.includes(e3) || i2.push(e3), i2.indexOf(e3)) : e3;
  };
  return JSON.stringify(t2, s2) !== JSON.stringify(e2, s2);
}
function uh(t2, e2, i2) {
  return t2.options.clip ? t2[i2] : e2[i2];
}
function dh(t2, e2) {
  const i2 = e2._clip;
  if (i2.disabled) return false;
  const s2 = function(t3, e3) {
    const { xScale: i3, yScale: s3 } = t3;
    return i3 && s3 ? { left: uh(i3, e3, "left"), right: uh(i3, e3, "right"), top: uh(s3, e3, "top"), bottom: uh(s3, e3, "bottom") } : e3;
  }(e2, t2.chartArea);
  return { left: false === i2.left ? 0 : s2.left - (true === i2.left ? 0 : i2.left), right: false === i2.right ? t2.width : s2.right + (true === i2.right ? 0 : i2.right), top: false === i2.top ? 0 : s2.top - (true === i2.top ? 0 : i2.top), bottom: false === i2.bottom ? t2.height : s2.bottom + (true === i2.bottom ? 0 : i2.bottom) };
}
class Animator {
  constructor() {
    this._request = null, this._charts = /* @__PURE__ */ new Map(), this._running = false, this._lastDate = void 0;
  }
  _notify(t2, e2, i2, s2) {
    const n2 = e2.listeners[s2], r2 = e2.duration;
    n2.forEach((s3) => s3({ chart: t2, initial: e2.initial, numSteps: r2, currentStep: Math.min(i2 - e2.start, r2) }));
  }
  _refresh() {
    this._request || (this._running = true, this._request = ka.call(window, () => {
      this._update(), this._request = null, this._running && this._refresh();
    }));
  }
  _update(t2 = Date.now()) {
    let e2 = 0;
    this._charts.forEach((i2, s2) => {
      if (!i2.running || !i2.items.length) return;
      const n2 = i2.items;
      let r2, o2 = n2.length - 1, a2 = false;
      for (; o2 >= 0; --o2) r2 = n2[o2], r2._active ? (r2._total > i2.duration && (i2.duration = r2._total), r2.tick(t2), a2 = true) : (n2[o2] = n2[n2.length - 1], n2.pop());
      a2 && (s2.draw(), this._notify(s2, i2, t2, "progress")), n2.length || (i2.running = false, this._notify(s2, i2, t2, "complete"), i2.initial = false), e2 += n2.length;
    }), this._lastDate = t2, 0 === e2 && (this._running = false);
  }
  _getAnims(t2) {
    const e2 = this._charts;
    let i2 = e2.get(t2);
    return i2 || (i2 = { running: false, initial: true, items: [], listeners: { complete: [], progress: [] } }, e2.set(t2, i2)), i2;
  }
  listen(t2, e2, i2) {
    this._getAnims(t2).listeners[e2].push(i2);
  }
  add(t2, e2) {
    e2 && e2.length && this._getAnims(t2).items.push(...e2);
  }
  has(t2) {
    return this._getAnims(t2).items.length > 0;
  }
  start(t2) {
    const e2 = this._charts.get(t2);
    e2 && (e2.running = true, e2.start = Date.now(), e2.duration = e2.items.reduce((t3, e3) => Math.max(t3, e3._duration), 0), this._refresh());
  }
  running(t2) {
    if (!this._running) return false;
    const e2 = this._charts.get(t2);
    return !!(e2 && e2.running && e2.items.length);
  }
  stop(t2) {
    const e2 = this._charts.get(t2);
    if (!e2 || !e2.items.length) return;
    const i2 = e2.items;
    let s2 = i2.length - 1;
    for (; s2 >= 0; --s2) i2[s2].cancel();
    e2.items = [], this._notify(t2, e2, Date.now(), "complete");
  }
  remove(t2) {
    return this._charts.delete(t2);
  }
}
var fh = new Animator();
const ph = "transparent", mh = { boolean: (t2, e2, i2) => i2 > 0.5 ? e2 : t2, color(t2, e2, i2) {
  const s2 = La(t2 || ph), n2 = s2.valid && La(e2 || ph);
  return n2 && n2.valid ? n2.mix(s2, i2).hexString() : e2;
}, number: (t2, e2, i2) => t2 + (e2 - t2) * i2 };
class Animation {
  constructor(t2, e2, i2, s2) {
    const n2 = e2[i2];
    s2 = vl([t2.to, s2, n2, t2.from]);
    const r2 = vl([t2.from, n2, s2]);
    this._active = true, this._fn = t2.fn || mh[t2.type || typeof r2], this._easing = Pa[t2.easing] || Pa.linear, this._start = Math.floor(Date.now() + (t2.delay || 0)), this._duration = this._total = Math.floor(t2.duration), this._loop = !!t2.loop, this._target = e2, this._prop = i2, this._from = r2, this._to = s2, this._promises = void 0;
  }
  active() {
    return this._active;
  }
  update(t2, e2, i2) {
    if (this._active) {
      this._notify(false);
      const s2 = this._target[this._prop], n2 = i2 - this._start, r2 = this._duration - n2;
      this._start = i2, this._duration = Math.floor(Math.max(r2, t2.duration)), this._total += n2, this._loop = !!t2.loop, this._to = vl([t2.to, e2, s2, t2.from]), this._from = vl([t2.from, s2, e2]);
    }
  }
  cancel() {
    this._active && (this.tick(Date.now()), this._active = false, this._notify(false));
  }
  tick(t2) {
    const e2 = t2 - this._start, i2 = this._duration, s2 = this._prop, n2 = this._from, r2 = this._loop, o2 = this._to;
    let a2;
    if (this._active = n2 !== o2 && (r2 || e2 < i2), !this._active) return this._target[s2] = o2, void this._notify(true);
    e2 < 0 ? this._target[s2] = n2 : (a2 = e2 / i2 % 2, a2 = r2 && a2 > 1 ? 2 - a2 : a2, a2 = this._easing(Math.min(1, Math.max(0, a2))), this._target[s2] = this._fn(n2, o2, a2));
  }
  wait() {
    const t2 = this._promises || (this._promises = []);
    return new Promise((e2, i2) => {
      t2.push({ res: e2, rej: i2 });
    });
  }
  _notify(t2) {
    const e2 = t2 ? "res" : "rej", i2 = this._promises || [];
    for (let t3 = 0; t3 < i2.length; t3++) i2[t3][e2]();
  }
}
class Animations {
  constructor(t2, e2) {
    this._chart = t2, this._properties = /* @__PURE__ */ new Map(), this.configure(e2);
  }
  configure(t2) {
    if (!zo(t2)) return;
    const e2 = Object.keys(Xa.animation), i2 = this._properties;
    Object.getOwnPropertyNames(t2).forEach((s2) => {
      const n2 = t2[s2];
      if (!zo(n2)) return;
      const r2 = {};
      for (const t3 of e2) r2[t3] = n2[t3];
      (Co(n2.properties) && n2.properties || [s2]).forEach((t3) => {
        t3 !== s2 && i2.has(t3) || i2.set(t3, r2);
      });
    });
  }
  _animateOptions(t2, e2) {
    const i2 = e2.options, s2 = function(t3, e3) {
      if (!e3) return;
      let i3 = t3.options;
      if (!i3) return void (t3.options = e3);
      i3.$shared && (t3.options = i3 = Object.assign({}, i3, { $shared: false, $animations: {} }));
      return i3;
    }(t2, i2);
    if (!s2) return [];
    const n2 = this._createAnimations(s2, i2);
    return i2.$shared && function(t3, e3) {
      const i3 = [], s3 = Object.keys(e3);
      for (let e4 = 0; e4 < s3.length; e4++) {
        const n3 = t3[s3[e4]];
        n3 && n3.active() && i3.push(n3.wait());
      }
      return Promise.all(i3);
    }(t2.options.$animations, i2).then(() => {
      t2.options = i2;
    }, () => {
    }), n2;
  }
  _createAnimations(t2, e2) {
    const i2 = this._properties, s2 = [], n2 = t2.$animations || (t2.$animations = {}), r2 = Object.keys(e2), o2 = Date.now();
    let a2;
    for (a2 = r2.length - 1; a2 >= 0; --a2) {
      const l2 = r2[a2];
      if ("$" === l2.charAt(0)) continue;
      if ("options" === l2) {
        s2.push(...this._animateOptions(t2, e2));
        continue;
      }
      const h2 = e2[l2];
      let c2 = n2[l2];
      const u2 = i2.get(l2);
      if (c2) {
        if (u2 && c2.active()) {
          c2.update(u2, h2, o2);
          continue;
        }
        c2.cancel();
      }
      u2 && u2.duration ? (n2[l2] = c2 = new Animation(u2, t2, l2, h2), s2.push(c2)) : t2[l2] = h2;
    }
    return s2;
  }
  update(t2, e2) {
    if (0 === this._properties.size) return void Object.assign(t2, e2);
    const i2 = this._createAnimations(t2, e2);
    return i2.length ? (fh.add(this._chart, i2), true) : void 0;
  }
}
function gh(t2, e2) {
  const i2 = t2 && t2.options || {}, s2 = i2.reverse, n2 = void 0 === i2.min ? e2 : 0, r2 = void 0 === i2.max ? e2 : 0;
  return { start: s2 ? r2 : n2, end: s2 ? n2 : r2 };
}
function vh(t2, e2) {
  const i2 = [], s2 = t2._getSortedDatasetMetas(e2);
  let n2, r2;
  for (n2 = 0, r2 = s2.length; n2 < r2; ++n2) i2.push(s2[n2].index);
  return i2;
}
function bh(t2, e2, i2, s2 = {}) {
  const n2 = t2.keys, r2 = "single" === s2.mode;
  let o2, a2, l2, h2;
  if (null === e2) return;
  let c2 = false;
  for (o2 = 0, a2 = n2.length; o2 < a2; ++o2) {
    if (l2 = +n2[o2], l2 === i2) {
      if (c2 = true, s2.all) continue;
      break;
    }
    h2 = t2.values[l2], $o(h2) && (r2 || 0 === e2 || ia(e2) === ia(h2)) && (e2 += h2);
  }
  return c2 || s2.all ? e2 : 0;
}
function _h(t2, e2) {
  const i2 = t2 && t2.options.stacked;
  return i2 || void 0 === i2 && void 0 !== e2.stack;
}
function yh(t2, e2, i2) {
  const s2 = t2[e2] || (t2[e2] = {});
  return s2[i2] || (s2[i2] = {});
}
function xh(t2, e2, i2, s2) {
  for (const n2 of e2.getMatchingVisibleMetas(s2).reverse()) {
    const e3 = t2[n2.index];
    if (i2 && e3 > 0 || !i2 && e3 < 0) return n2.index;
  }
  return null;
}
function wh(t2, e2) {
  const { chart: i2, _cachedMeta: s2 } = t2, n2 = i2._stacks || (i2._stacks = {}), { iScale: r2, vScale: o2, index: a2 } = s2, l2 = r2.axis, h2 = o2.axis, c2 = function(t3, e3, i3) {
    return `${t3.id}.${e3.id}.${i3.stack || i3.type}`;
  }(r2, o2, s2), u2 = e2.length;
  let d2;
  for (let t3 = 0; t3 < u2; ++t3) {
    const i3 = e2[t3], { [l2]: r3, [h2]: u3 } = i3;
    d2 = (i3._stacks || (i3._stacks = {}))[h2] = yh(n2, c2, r3), d2[a2] = u3, d2._top = xh(d2, o2, true, s2.type), d2._bottom = xh(d2, o2, false, s2.type);
    (d2._visualValues || (d2._visualValues = {}))[a2] = u3;
  }
}
function kh(t2, e2) {
  const i2 = t2.scales;
  return Object.keys(i2).filter((t3) => i2[t3].axis === e2).shift();
}
function Mh(t2, e2) {
  const i2 = t2.controller.index, s2 = t2.vScale && t2.vScale.axis;
  if (s2) {
    e2 = e2 || t2._parsed;
    for (const t3 of e2) {
      const e3 = t3._stacks;
      if (!e3 || void 0 === e3[s2] || void 0 === e3[s2][i2]) return;
      delete e3[s2][i2], void 0 !== e3[s2]._visualValues && void 0 !== e3[s2]._visualValues[i2] && delete e3[s2]._visualValues[i2];
    }
  }
}
const Sh = (t2) => "reset" === t2 || "none" === t2, Ch = (t2, e2) => e2 ? t2 : Object.assign({}, t2);
class DatasetController {
  constructor(t2, e2) {
    this.chart = t2, this._ctx = t2.ctx, this.index = e2, this._cachedDataOpts = {}, this._cachedMeta = this.getMeta(), this._type = this._cachedMeta.type, this.options = void 0, this._parsing = false, this._data = void 0, this._objectData = void 0, this._sharedOptions = void 0, this._drawStart = void 0, this._drawCount = void 0, this.enableOptionSharing = false, this.supportsDecimation = false, this.$context = void 0, this._syncList = [], this.datasetElementType = new.target.datasetElementType, this.dataElementType = new.target.dataElementType, this.initialize();
  }
  initialize() {
    const t2 = this._cachedMeta;
    this.configure(), this.linkScales(), t2._stacked = _h(t2.vScale, t2), this.addElements(), this.options.fill && !this.chart.isPluginEnabled("filler") && console.warn("Tried to use the 'fill' option without the 'Filler' plugin enabled. Please import and register the 'Filler' plugin and make sure it is not disabled in the options");
  }
  updateIndex(t2) {
    this.index !== t2 && Mh(this._cachedMeta), this.index = t2;
  }
  linkScales() {
    const t2 = this.chart, e2 = this._cachedMeta, i2 = this.getDataset(), s2 = (t3, e3, i3, s3) => "x" === t3 ? e3 : "r" === t3 ? s3 : i3, n2 = e2.xAxisID = Ro(i2.xAxisID, kh(t2, "x")), r2 = e2.yAxisID = Ro(i2.yAxisID, kh(t2, "y")), o2 = e2.rAxisID = Ro(i2.rAxisID, kh(t2, "r")), a2 = e2.indexAxis, l2 = e2.iAxisID = s2(a2, n2, r2, o2), h2 = e2.vAxisID = s2(a2, r2, n2, o2);
    e2.xScale = this.getScaleForId(n2), e2.yScale = this.getScaleForId(r2), e2.rScale = this.getScaleForId(o2), e2.iScale = this.getScaleForId(l2), e2.vScale = this.getScaleForId(h2);
  }
  getDataset() {
    return this.chart.data.datasets[this.index];
  }
  getMeta() {
    return this.chart.getDatasetMeta(this.index);
  }
  getScaleForId(t2) {
    return this.chart.scales[t2];
  }
  _getOtherScale(t2) {
    const e2 = this._cachedMeta;
    return t2 === e2.iScale ? e2.vScale : e2.iScale;
  }
  reset() {
    this._update("reset");
  }
  _destroy() {
    const t2 = this._cachedMeta;
    this._data && xa(this._data, this), t2._stacked && Mh(t2);
  }
  _dataCheck() {
    const t2 = this.getDataset(), e2 = t2.data || (t2.data = []), i2 = this._data;
    if (zo(e2)) {
      const t3 = this._cachedMeta;
      this._data = function(t4, e3) {
        const { iScale: i3, vScale: s3 } = e3, n3 = "x" === i3.axis ? "x" : "y", r2 = "x" === s3.axis ? "x" : "y", o2 = Object.keys(t4), a2 = new Array(o2.length);
        let l2, h2, c2;
        for (l2 = 0, h2 = o2.length; l2 < h2; ++l2) c2 = o2[l2], a2[l2] = { [n3]: c2, [r2]: t4[c2] };
        return a2;
      }(e2, t3);
    } else if (i2 !== e2) {
      if (i2) {
        xa(i2, this);
        const t3 = this._cachedMeta;
        Mh(t3), t3._parsed = [];
      }
      e2 && Object.isExtensible(e2) && (n2 = this, (s2 = e2)._chartjs ? s2._chartjs.listeners.push(n2) : (Object.defineProperty(s2, "_chartjs", { configurable: true, enumerable: false, value: { listeners: [n2] } }), ya.forEach((t3) => {
        const e3 = "_onData" + jo(t3), i3 = s2[t3];
        Object.defineProperty(s2, t3, { configurable: true, enumerable: false, value(...t4) {
          const n3 = i3.apply(this, t4);
          return s2._chartjs.listeners.forEach((i4) => {
            "function" == typeof i4[e3] && i4[e3](...t4);
          }), n3;
        } });
      }))), this._syncList = [], this._data = e2;
    }
    var s2, n2;
  }
  addElements() {
    const t2 = this._cachedMeta;
    this._dataCheck(), this.datasetElementType && (t2.dataset = new this.datasetElementType());
  }
  buildOrUpdateElements(t2) {
    const e2 = this._cachedMeta, i2 = this.getDataset();
    let s2 = false;
    this._dataCheck();
    const n2 = e2._stacked;
    e2._stacked = _h(e2.vScale, e2), e2.stack !== i2.stack && (s2 = true, Mh(e2), e2.stack = i2.stack), this._resyncElements(t2), (s2 || n2 !== e2._stacked) && (wh(this, e2._parsed), e2._stacked = _h(e2.vScale, e2));
  }
  configure() {
    const t2 = this.chart.config, e2 = t2.datasetScopeKeys(this._type), i2 = t2.getOptionScopes(this.getDataset(), e2, true);
    this.options = t2.createResolver(i2, this.getContext()), this._parsing = this.options.parsing, this._cachedDataOpts = {};
  }
  parse(t2, e2) {
    const { _cachedMeta: i2, _data: s2 } = this, { iScale: n2, _stacked: r2 } = i2, o2 = n2.axis;
    let a2, l2, h2, c2 = 0 === t2 && e2 === s2.length || i2._sorted, u2 = t2 > 0 && i2._parsed[t2 - 1];
    if (false === this._parsing) i2._parsed = s2, i2._sorted = true, h2 = s2;
    else {
      h2 = Co(s2[t2]) ? this.parseArrayData(i2, s2, t2, e2) : zo(s2[t2]) ? this.parseObjectData(i2, s2, t2, e2) : this.parsePrimitiveData(i2, s2, t2, e2);
      const n3 = () => null === l2[o2] || u2 && l2[o2] < u2[o2];
      for (a2 = 0; a2 < e2; ++a2) i2._parsed[a2 + t2] = l2 = h2[a2], c2 && (n3() && (c2 = false), u2 = l2);
      i2._sorted = c2;
    }
    r2 && wh(this, h2);
  }
  parsePrimitiveData(t2, e2, i2, s2) {
    const { iScale: n2, vScale: r2 } = t2, o2 = n2.axis, a2 = r2.axis, l2 = n2.getLabels(), h2 = n2 === r2, c2 = new Array(s2);
    let u2, d2, f2;
    for (u2 = 0, d2 = s2; u2 < d2; ++u2) f2 = u2 + i2, c2[u2] = { [o2]: h2 || n2.parse(l2[f2], f2), [a2]: r2.parse(e2[f2], f2) };
    return c2;
  }
  parseArrayData(t2, e2, i2, s2) {
    const { xScale: n2, yScale: r2 } = t2, o2 = new Array(s2);
    let a2, l2, h2, c2;
    for (a2 = 0, l2 = s2; a2 < l2; ++a2) h2 = a2 + i2, c2 = e2[h2], o2[a2] = { x: n2.parse(c2[0], h2), y: r2.parse(c2[1], h2) };
    return o2;
  }
  parseObjectData(t2, e2, i2, s2) {
    const { xScale: n2, yScale: r2 } = t2, { xAxisKey: o2 = "x", yAxisKey: a2 = "y" } = this._parsing, l2 = new Array(s2);
    let h2, c2, u2, d2;
    for (h2 = 0, c2 = s2; h2 < c2; ++h2) u2 = h2 + i2, d2 = e2[u2], l2[h2] = { x: n2.parse(Bo(d2, o2), u2), y: r2.parse(Bo(d2, a2), u2) };
    return l2;
  }
  getParsed(t2) {
    return this._cachedMeta._parsed[t2];
  }
  getDataElement(t2) {
    return this._cachedMeta.data[t2];
  }
  applyStack(t2, e2, i2) {
    const s2 = this.chart, n2 = this._cachedMeta, r2 = e2[t2.axis];
    return bh({ keys: vh(s2, true), values: e2._stacks[t2.axis]._visualValues }, r2, n2.index, { mode: i2 });
  }
  updateRangeFromParsed(t2, e2, i2, s2) {
    const n2 = i2[e2.axis];
    let r2 = null === n2 ? NaN : n2;
    const o2 = s2 && i2._stacks[e2.axis];
    s2 && o2 && (s2.values = o2, r2 = bh(s2, n2, this._cachedMeta.index)), t2.min = Math.min(t2.min, r2), t2.max = Math.max(t2.max, r2);
  }
  getMinMax(t2, e2) {
    const i2 = this._cachedMeta, s2 = i2._parsed, n2 = i2._sorted && t2 === i2.iScale, r2 = s2.length, o2 = this._getOtherScale(t2), a2 = ((t3, e3, i3) => t3 && !e3.hidden && e3._stacked && { keys: vh(i3, true), values: null })(e2, i2, this.chart), l2 = { min: Number.POSITIVE_INFINITY, max: Number.NEGATIVE_INFINITY }, { min: h2, max: c2 } = function(t3) {
      const { min: e3, max: i3, minDefined: s3, maxDefined: n3 } = t3.getUserBounds();
      return { min: s3 ? e3 : Number.NEGATIVE_INFINITY, max: n3 ? i3 : Number.POSITIVE_INFINITY };
    }(o2);
    let u2, d2;
    function f2() {
      d2 = s2[u2];
      const e3 = d2[o2.axis];
      return !$o(d2[t2.axis]) || h2 > e3 || c2 < e3;
    }
    for (u2 = 0; u2 < r2 && (f2() || (this.updateRangeFromParsed(l2, t2, d2, a2), !n2)); ++u2) ;
    if (n2) {
      for (u2 = r2 - 1; u2 >= 0; --u2) if (!f2()) {
        this.updateRangeFromParsed(l2, t2, d2, a2);
        break;
      }
    }
    return l2;
  }
  getAllParsedValues(t2) {
    const e2 = this._cachedMeta._parsed, i2 = [];
    let s2, n2, r2;
    for (s2 = 0, n2 = e2.length; s2 < n2; ++s2) r2 = e2[s2][t2.axis], $o(r2) && i2.push(r2);
    return i2;
  }
  getMaxOverflow() {
    return false;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = e2.iScale, s2 = e2.vScale, n2 = this.getParsed(t2);
    return { label: i2 ? "" + i2.getLabelForValue(n2[i2.axis]) : "", value: s2 ? "" + s2.getLabelForValue(n2[s2.axis]) : "" };
  }
  _update(t2) {
    const e2 = this._cachedMeta;
    this.update(t2 || "default"), e2._clip = function(t3) {
      let e3, i2, s2, n2;
      return zo(t3) ? (e3 = t3.top, i2 = t3.right, s2 = t3.bottom, n2 = t3.left) : e3 = i2 = s2 = n2 = t3, { top: e3, right: i2, bottom: s2, left: n2, disabled: false === t3 };
    }(Ro(this.options.clip, function(t3, e3, i2) {
      if (false === i2) return false;
      const s2 = gh(t3, i2), n2 = gh(e3, i2);
      return { top: n2.end, right: s2.end, bottom: n2.start, left: s2.start };
    }(e2.xScale, e2.yScale, this.getMaxOverflow())));
  }
  update(t2) {
  }
  draw() {
    const t2 = this._ctx, e2 = this.chart, i2 = this._cachedMeta, s2 = i2.data || [], n2 = e2.chartArea, r2 = [], o2 = this._drawStart || 0, a2 = this._drawCount || s2.length - o2, l2 = this.options.drawActiveElementsOnTop;
    let h2;
    for (i2.dataset && i2.dataset.draw(t2, n2, o2, a2), h2 = o2; h2 < o2 + a2; ++h2) {
      const e3 = s2[h2];
      e3.hidden || (e3.active && l2 ? r2.push(e3) : e3.draw(t2, n2));
    }
    for (h2 = 0; h2 < r2.length; ++h2) r2[h2].draw(t2, n2);
  }
  getStyle(t2, e2) {
    const i2 = e2 ? "active" : "default";
    return void 0 === t2 && this._cachedMeta.dataset ? this.resolveDatasetElementOptions(i2) : this.resolveDataElementOptions(t2 || 0, i2);
  }
  getContext(t2, e2, i2) {
    const s2 = this.getDataset();
    let n2;
    if (t2 >= 0 && t2 < this._cachedMeta.data.length) {
      const e3 = this._cachedMeta.data[t2];
      n2 = e3.$context || (e3.$context = function(t3, e4, i3) {
        return bl(t3, { active: false, dataIndex: e4, parsed: void 0, raw: void 0, element: i3, index: e4, mode: "default", type: "data" });
      }(this.getContext(), t2, e3)), n2.parsed = this.getParsed(t2), n2.raw = s2.data[t2], n2.index = n2.dataIndex = t2;
    } else n2 = this.$context || (this.$context = function(t3, e3) {
      return bl(t3, { active: false, dataset: void 0, datasetIndex: e3, index: e3, mode: "default", type: "dataset" });
    }(this.chart.getContext(), this.index)), n2.dataset = s2, n2.index = n2.datasetIndex = this.index;
    return n2.active = !!e2, n2.mode = i2, n2;
  }
  resolveDatasetElementOptions(t2) {
    return this._resolveElementOptions(this.datasetElementType.id, t2);
  }
  resolveDataElementOptions(t2, e2) {
    return this._resolveElementOptions(this.dataElementType.id, e2, t2);
  }
  _resolveElementOptions(t2, e2 = "default", i2) {
    const s2 = "active" === e2, n2 = this._cachedDataOpts, r2 = t2 + "-" + e2, o2 = n2[r2], a2 = this.enableOptionSharing && Ho(i2);
    if (o2) return Ch(o2, a2);
    const l2 = this.chart.config, h2 = l2.datasetElementScopeKeys(this._type, t2), c2 = s2 ? [`${t2}Hover`, "hover", t2, ""] : [t2, ""], u2 = l2.getOptionScopes(this.getDataset(), h2), d2 = Object.keys(Xa.elements[t2]), f2 = l2.resolveNamedOptions(u2, d2, () => this.getContext(i2, s2, e2), c2);
    return f2.$shared && (f2.$shared = a2, n2[r2] = Object.freeze(Ch(f2, a2))), f2;
  }
  _resolveAnimations(t2, e2, i2) {
    const s2 = this.chart, n2 = this._cachedDataOpts, r2 = `animation-${e2}`, o2 = n2[r2];
    if (o2) return o2;
    let a2;
    if (false !== s2.options.animation) {
      const s3 = this.chart.config, n3 = s3.datasetAnimationScopeKeys(this._type, e2), r3 = s3.getOptionScopes(this.getDataset(), n3);
      a2 = s3.createResolver(r3, this.getContext(t2, i2, e2));
    }
    const l2 = new Animations(s2, a2 && a2.animations);
    return a2 && a2._cacheable && (n2[r2] = Object.freeze(l2)), l2;
  }
  getSharedOptions(t2) {
    if (t2.$shared) return this._sharedOptions || (this._sharedOptions = Object.assign({}, t2));
  }
  includeOptions(t2, e2) {
    return !e2 || Sh(t2) || this.chart._animationsDisabled;
  }
  _getSharedOptions(t2, e2) {
    const i2 = this.resolveDataElementOptions(t2, e2), s2 = this._sharedOptions, n2 = this.getSharedOptions(i2), r2 = this.includeOptions(e2, n2) || n2 !== s2;
    return this.updateSharedOptions(n2, e2, i2), { sharedOptions: n2, includeOptions: r2 };
  }
  updateElement(t2, e2, i2, s2) {
    Sh(s2) ? Object.assign(t2, i2) : this._resolveAnimations(e2, s2).update(t2, i2);
  }
  updateSharedOptions(t2, e2, i2) {
    t2 && !Sh(e2) && this._resolveAnimations(void 0, e2).update(t2, i2);
  }
  _setStyle(t2, e2, i2, s2) {
    t2.active = s2;
    const n2 = this.getStyle(e2, s2);
    this._resolveAnimations(e2, i2, s2).update(t2, { options: !s2 && this.getSharedOptions(n2) || n2 });
  }
  removeHoverStyle(t2, e2, i2) {
    this._setStyle(t2, i2, "active", false);
  }
  setHoverStyle(t2, e2, i2) {
    this._setStyle(t2, i2, "active", true);
  }
  _removeDatasetHoverStyle() {
    const t2 = this._cachedMeta.dataset;
    t2 && this._setStyle(t2, void 0, "active", false);
  }
  _setDatasetHoverStyle() {
    const t2 = this._cachedMeta.dataset;
    t2 && this._setStyle(t2, void 0, "active", true);
  }
  _resyncElements(t2) {
    const e2 = this._data, i2 = this._cachedMeta.data;
    for (const [t3, e3, i3] of this._syncList) this[t3](e3, i3);
    this._syncList = [];
    const s2 = i2.length, n2 = e2.length, r2 = Math.min(n2, s2);
    r2 && this.parse(0, r2), n2 > s2 ? this._insertElements(s2, n2 - s2, t2) : n2 < s2 && this._removeElements(n2, s2 - n2);
  }
  _insertElements(t2, e2, i2 = true) {
    const s2 = this._cachedMeta, n2 = s2.data, r2 = t2 + e2;
    let o2;
    const a2 = (t3) => {
      for (t3.length += e2, o2 = t3.length - 1; o2 >= r2; o2--) t3[o2] = t3[o2 - e2];
    };
    for (a2(n2), o2 = t2; o2 < r2; ++o2) n2[o2] = new this.dataElementType();
    this._parsing && a2(s2._parsed), this.parse(t2, e2), i2 && this.updateElements(n2, t2, e2, "reset");
  }
  updateElements(t2, e2, i2, s2) {
  }
  _removeElements(t2, e2) {
    const i2 = this._cachedMeta;
    if (this._parsing) {
      const s2 = i2._parsed.splice(t2, e2);
      i2._stacked && Mh(i2, s2);
    }
    i2.data.splice(t2, e2);
  }
  _sync(t2) {
    if (this._parsing) this._syncList.push(t2);
    else {
      const [e2, i2, s2] = t2;
      this[e2](i2, s2);
    }
    this.chart._dataChanges.push([this.index, ...t2]);
  }
  _onDataPush() {
    const t2 = arguments.length;
    this._sync(["_insertElements", this.getDataset().data.length - t2, t2]);
  }
  _onDataPop() {
    this._sync(["_removeElements", this._cachedMeta.data.length - 1, 1]);
  }
  _onDataShift() {
    this._sync(["_removeElements", 0, 1]);
  }
  _onDataSplice(t2, e2) {
    e2 && this._sync(["_removeElements", t2, e2]);
    const i2 = arguments.length - 2;
    i2 && this._sync(["_insertElements", t2, i2]);
  }
  _onDataUnshift() {
    this._sync(["_insertElements", 0, arguments.length]);
  }
}
__publicField(DatasetController, "defaults", {});
__publicField(DatasetController, "datasetElementType", null);
__publicField(DatasetController, "dataElementType", null);
function zh(t2) {
  const e2 = t2.iScale, i2 = function(t3, e3) {
    if (!t3._cache.$bar) {
      const i3 = t3.getMatchingVisibleMetas(e3);
      let s3 = [];
      for (let e4 = 0, n3 = i3.length; e4 < n3; e4++) s3 = s3.concat(i3[e4].controller.getAllParsedValues(t3));
      t3._cache.$bar = wa(s3.sort((t4, e4) => t4 - e4));
    }
    return t3._cache.$bar;
  }(e2, t2.type);
  let s2, n2, r2, o2, a2 = e2._length;
  const l2 = () => {
    32767 !== r2 && -32768 !== r2 && (Ho(o2) && (a2 = Math.min(a2, Math.abs(r2 - o2) || a2)), o2 = r2);
  };
  for (s2 = 0, n2 = i2.length; s2 < n2; ++s2) r2 = e2.getPixelForValue(i2[s2]), l2();
  for (o2 = void 0, s2 = 0, n2 = e2.ticks.length; s2 < n2; ++s2) r2 = e2.getPixelForTick(s2), l2();
  return a2;
}
function $h(t2, e2, i2, s2) {
  return Co(t2) ? function(t3, e3, i3, s3) {
    const n2 = i3.parse(t3[0], s3), r2 = i3.parse(t3[1], s3), o2 = Math.min(n2, r2), a2 = Math.max(n2, r2);
    let l2 = o2, h2 = a2;
    Math.abs(o2) > Math.abs(a2) && (l2 = a2, h2 = o2), e3[i3.axis] = h2, e3._custom = { barStart: l2, barEnd: h2, start: n2, end: r2, min: o2, max: a2 };
  }(t2, e2, i2, s2) : e2[i2.axis] = i2.parse(t2, s2), e2;
}
function Dh(t2, e2, i2, s2) {
  const n2 = t2.iScale, r2 = t2.vScale, o2 = n2.getLabels(), a2 = n2 === r2, l2 = [];
  let h2, c2, u2, d2;
  for (h2 = i2, c2 = i2 + s2; h2 < c2; ++h2) d2 = e2[h2], u2 = {}, u2[n2.axis] = a2 || n2.parse(o2[h2], h2), l2.push($h(d2, u2, r2, h2));
  return l2;
}
function Rh(t2) {
  return t2 && void 0 !== t2.barStart && void 0 !== t2.barEnd;
}
function Eh(t2, e2, i2, s2) {
  let n2 = e2.borderSkipped;
  const r2 = {};
  if (!n2) return void (t2.borderSkipped = r2);
  if (true === n2) return void (t2.borderSkipped = { top: true, right: true, bottom: true, left: true });
  const { start: o2, end: a2, reverse: l2, top: h2, bottom: c2 } = function(t3) {
    let e3, i3, s3, n3, r3;
    return t3.horizontal ? (e3 = t3.base > t3.x, i3 = "left", s3 = "right") : (e3 = t3.base < t3.y, i3 = "bottom", s3 = "top"), e3 ? (n3 = "end", r3 = "start") : (n3 = "start", r3 = "end"), { start: i3, end: s3, reverse: e3, top: n3, bottom: r3 };
  }(t2);
  "middle" === n2 && i2 && (t2.enableBorderRadius = true, (i2._top || 0) === s2 ? n2 = h2 : (i2._bottom || 0) === s2 ? n2 = c2 : (r2[Ph(c2, o2, a2, l2)] = true, n2 = h2)), r2[Ph(n2, o2, a2, l2)] = true, t2.borderSkipped = r2;
}
function Ph(t2, e2, i2, s2) {
  var n2, r2, o2;
  return s2 ? (o2 = i2, t2 = Th(t2 = (n2 = t2) === (r2 = e2) ? o2 : n2 === o2 ? r2 : n2, i2, e2)) : t2 = Th(t2, e2, i2), t2;
}
function Th(t2, e2, i2) {
  return "start" === t2 ? e2 : "end" === t2 ? i2 : t2;
}
function Lh(t2, { inflateAmount: e2 }, i2) {
  t2.inflateAmount = "auto" === e2 ? 1 === i2 ? 0.33 : 0 : e2;
}
class BarController extends DatasetController {
  parsePrimitiveData(t2, e2, i2, s2) {
    return Dh(t2, e2, i2, s2);
  }
  parseArrayData(t2, e2, i2, s2) {
    return Dh(t2, e2, i2, s2);
  }
  parseObjectData(t2, e2, i2, s2) {
    const { iScale: n2, vScale: r2 } = t2, { xAxisKey: o2 = "x", yAxisKey: a2 = "y" } = this._parsing, l2 = "x" === n2.axis ? o2 : a2, h2 = "x" === r2.axis ? o2 : a2, c2 = [];
    let u2, d2, f2, p2;
    for (u2 = i2, d2 = i2 + s2; u2 < d2; ++u2) p2 = e2[u2], f2 = {}, f2[n2.axis] = n2.parse(Bo(p2, l2), u2), c2.push($h(Bo(p2, h2), f2, r2, u2));
    return c2;
  }
  updateRangeFromParsed(t2, e2, i2, s2) {
    super.updateRangeFromParsed(t2, e2, i2, s2);
    const n2 = i2._custom;
    n2 && e2 === this._cachedMeta.vScale && (t2.min = Math.min(t2.min, n2.min), t2.max = Math.max(t2.max, n2.max));
  }
  getMaxOverflow() {
    return 0;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, { iScale: i2, vScale: s2 } = e2, n2 = this.getParsed(t2), r2 = n2._custom, o2 = Rh(r2) ? "[" + r2.start + ", " + r2.end + "]" : "" + s2.getLabelForValue(n2[s2.axis]);
    return { label: "" + i2.getLabelForValue(n2[i2.axis]), value: o2 };
  }
  initialize() {
    this.enableOptionSharing = true, super.initialize();
    this._cachedMeta.stack = this.getDataset().stack;
  }
  update(t2) {
    const e2 = this._cachedMeta;
    this.updateElements(e2.data, 0, e2.data.length, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { index: r2, _cachedMeta: { vScale: o2 } } = this, a2 = o2.getBasePixel(), l2 = o2.isHorizontal(), h2 = this._getRuler(), { sharedOptions: c2, includeOptions: u2 } = this._getSharedOptions(e2, s2);
    for (let d2 = e2; d2 < e2 + i2; d2++) {
      const e3 = this.getParsed(d2), i3 = n2 || So(e3[o2.axis]) ? { base: a2, head: a2 } : this._calculateBarValuePixels(d2), f2 = this._calculateBarIndexPixels(d2, h2), p2 = (e3._stacks || {})[o2.axis], m2 = { horizontal: l2, base: i3.base, enableBorderRadius: !p2 || Rh(e3._custom) || r2 === p2._top || r2 === p2._bottom, x: l2 ? i3.head : f2.center, y: l2 ? f2.center : i3.head, height: l2 ? f2.size : Math.abs(i3.size), width: l2 ? Math.abs(i3.size) : f2.size };
      u2 && (m2.options = c2 || this.resolveDataElementOptions(d2, t2[d2].active ? "active" : s2));
      const g2 = m2.options || t2[d2].options;
      Eh(m2, g2, p2, r2), Lh(m2, g2, h2.ratio), this.updateElement(t2[d2], d2, m2, s2);
    }
  }
  _getStacks(t2, e2) {
    const { iScale: i2 } = this._cachedMeta, s2 = i2.getMatchingVisibleMetas(this._type).filter((t3) => t3.controller.options.grouped), n2 = i2.options.stacked, r2 = [], o2 = this._cachedMeta.controller.getParsed(e2), a2 = o2 && o2[i2.axis], l2 = (t3) => {
      const e3 = t3._parsed.find((t4) => t4[i2.axis] === a2), s3 = e3 && e3[t3.vScale.axis];
      if (So(s3) || isNaN(s3)) return true;
    };
    for (const i3 of s2) if ((void 0 === e2 || !l2(i3)) && ((false === n2 || -1 === r2.indexOf(i3.stack) || void 0 === n2 && void 0 === i3.stack) && r2.push(i3.stack), i3.index === t2)) break;
    return r2.length || r2.push(void 0), r2;
  }
  _getStackCount(t2) {
    return this._getStacks(void 0, t2).length;
  }
  _getStackIndex(t2, e2, i2) {
    const s2 = this._getStacks(t2, i2), n2 = void 0 !== e2 ? s2.indexOf(e2) : -1;
    return -1 === n2 ? s2.length - 1 : n2;
  }
  _getRuler() {
    const t2 = this.options, e2 = this._cachedMeta, i2 = e2.iScale, s2 = [];
    let n2, r2;
    for (n2 = 0, r2 = e2.data.length; n2 < r2; ++n2) s2.push(i2.getPixelForValue(this.getParsed(n2)[i2.axis], n2));
    const o2 = t2.barThickness;
    return { min: o2 || zh(e2), pixels: s2, start: i2._startPixel, end: i2._endPixel, stackCount: this._getStackCount(), scale: i2, grouped: t2.grouped, ratio: o2 ? 1 : t2.categoryPercentage * t2.barPercentage };
  }
  _calculateBarValuePixels(t2) {
    const { _cachedMeta: { vScale: e2, _stacked: i2, index: s2 }, options: { base: n2, minBarLength: r2 } } = this, o2 = n2 || 0, a2 = this.getParsed(t2), l2 = a2._custom, h2 = Rh(l2);
    let c2, u2, d2 = a2[e2.axis], f2 = 0, p2 = i2 ? this.applyStack(e2, a2, i2) : d2;
    p2 !== d2 && (f2 = p2 - d2, p2 = d2), h2 && (d2 = l2.barStart, p2 = l2.barEnd - l2.barStart, 0 !== d2 && ia(d2) !== ia(l2.barEnd) && (f2 = 0), f2 += d2);
    const m2 = So(n2) || h2 ? f2 : n2;
    let g2 = e2.getPixelForValue(m2);
    if (c2 = this.chart.getDataVisibility(t2) ? e2.getPixelForValue(f2 + p2) : g2, u2 = c2 - g2, Math.abs(u2) < r2) {
      u2 = function(t4, e3, i3) {
        return 0 !== t4 ? ia(t4) : (e3.isHorizontal() ? 1 : -1) * (e3.min >= i3 ? 1 : -1);
      }(u2, e2, o2) * r2, d2 === o2 && (g2 -= u2 / 2);
      const t3 = e2.getPixelForDecimal(0), n3 = e2.getPixelForDecimal(1), l3 = Math.min(t3, n3), f3 = Math.max(t3, n3);
      g2 = Math.max(Math.min(g2, f3), l3), c2 = g2 + u2, i2 && !h2 && (a2._stacks[e2.axis]._visualValues[s2] = e2.getValueForPixel(c2) - e2.getValueForPixel(g2));
    }
    if (g2 === e2.getPixelForValue(o2)) {
      const t3 = ia(u2) * e2.getLineWidthForValue(o2) / 2;
      g2 += t3, u2 -= t3;
    }
    return { size: u2, base: g2, head: c2, center: c2 + u2 / 2 };
  }
  _calculateBarIndexPixels(t2, e2) {
    const i2 = e2.scale, s2 = this.options, n2 = s2.skipNull, r2 = Ro(s2.maxBarThickness, 1 / 0);
    let o2, a2;
    if (e2.grouped) {
      const i3 = n2 ? this._getStackCount(t2) : e2.stackCount, l2 = "flex" === s2.barThickness ? function(t3, e3, i4, s3) {
        const n3 = e3.pixels, r3 = n3[t3];
        let o3 = t3 > 0 ? n3[t3 - 1] : null, a3 = t3 < n3.length - 1 ? n3[t3 + 1] : null;
        const l3 = i4.categoryPercentage;
        null === o3 && (o3 = r3 - (null === a3 ? e3.end - e3.start : a3 - r3)), null === a3 && (a3 = r3 + r3 - o3);
        const h3 = r3 - (r3 - Math.min(o3, a3)) / 2 * l3;
        return { chunk: Math.abs(a3 - o3) / 2 * l3 / s3, ratio: i4.barPercentage, start: h3 };
      }(t2, e2, s2, i3) : function(t3, e3, i4, s3) {
        const n3 = i4.barThickness;
        let r3, o3;
        return So(n3) ? (r3 = e3.min * i4.categoryPercentage, o3 = i4.barPercentage) : (r3 = n3 * s3, o3 = 1), { chunk: r3 / s3, ratio: o3, start: e3.pixels[t3] - r3 / 2 };
      }(t2, e2, s2, i3), h2 = this._getStackIndex(this.index, this._cachedMeta.stack, n2 ? t2 : void 0);
      o2 = l2.start + l2.chunk * h2 + l2.chunk / 2, a2 = Math.min(r2, l2.chunk * l2.ratio);
    } else o2 = i2.getPixelForValue(this.getParsed(t2)[i2.axis], t2), a2 = Math.min(r2, e2.min * e2.ratio);
    return { base: o2 - a2 / 2, head: o2 + a2 / 2, center: o2, size: a2 };
  }
  draw() {
    const t2 = this._cachedMeta, e2 = t2.vScale, i2 = t2.data, s2 = i2.length;
    let n2 = 0;
    for (; n2 < s2; ++n2) null === this.getParsed(n2)[e2.axis] || i2[n2].hidden || i2[n2].draw(this._ctx);
  }
}
__publicField(BarController, "id", "bar");
__publicField(BarController, "defaults", { datasetElementType: false, dataElementType: "bar", categoryPercentage: 0.8, barPercentage: 0.9, grouped: true, animations: { numbers: { type: "number", properties: ["x", "y", "base", "width", "height"] } } });
__publicField(BarController, "overrides", { scales: { _index_: { type: "category", offset: true, grid: { offset: true } }, _value_: { type: "linear", beginAtZero: true } } });
class BubbleController extends DatasetController {
  initialize() {
    this.enableOptionSharing = true, super.initialize();
  }
  parsePrimitiveData(t2, e2, i2, s2) {
    const n2 = super.parsePrimitiveData(t2, e2, i2, s2);
    for (let t3 = 0; t3 < n2.length; t3++) n2[t3]._custom = this.resolveDataElementOptions(t3 + i2).radius;
    return n2;
  }
  parseArrayData(t2, e2, i2, s2) {
    const n2 = super.parseArrayData(t2, e2, i2, s2);
    for (let t3 = 0; t3 < n2.length; t3++) {
      const s3 = e2[i2 + t3];
      n2[t3]._custom = Ro(s3[2], this.resolveDataElementOptions(t3 + i2).radius);
    }
    return n2;
  }
  parseObjectData(t2, e2, i2, s2) {
    const n2 = super.parseObjectData(t2, e2, i2, s2);
    for (let t3 = 0; t3 < n2.length; t3++) {
      const s3 = e2[i2 + t3];
      n2[t3]._custom = Ro(s3 && s3.r && +s3.r, this.resolveDataElementOptions(t3 + i2).radius);
    }
    return n2;
  }
  getMaxOverflow() {
    const t2 = this._cachedMeta.data;
    let e2 = 0;
    for (let i2 = t2.length - 1; i2 >= 0; --i2) e2 = Math.max(e2, t2[i2].size(this.resolveDataElementOptions(i2)) / 2);
    return e2 > 0 && e2;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart.data.labels || [], { xScale: s2, yScale: n2 } = e2, r2 = this.getParsed(t2), o2 = s2.getLabelForValue(r2.x), a2 = n2.getLabelForValue(r2.y), l2 = r2._custom;
    return { label: i2[t2] || "", value: "(" + o2 + ", " + a2 + (l2 ? ", " + l2 : "") + ")" };
  }
  update(t2) {
    const e2 = this._cachedMeta.data;
    this.updateElements(e2, 0, e2.length, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { iScale: r2, vScale: o2 } = this._cachedMeta, { sharedOptions: a2, includeOptions: l2 } = this._getSharedOptions(e2, s2), h2 = r2.axis, c2 = o2.axis;
    for (let u2 = e2; u2 < e2 + i2; u2++) {
      const e3 = t2[u2], i3 = !n2 && this.getParsed(u2), d2 = {}, f2 = d2[h2] = n2 ? r2.getPixelForDecimal(0.5) : r2.getPixelForValue(i3[h2]), p2 = d2[c2] = n2 ? o2.getBasePixel() : o2.getPixelForValue(i3[c2]);
      d2.skip = isNaN(f2) || isNaN(p2), l2 && (d2.options = a2 || this.resolveDataElementOptions(u2, e3.active ? "active" : s2), n2 && (d2.options.radius = 0)), this.updateElement(e3, u2, d2, s2);
    }
  }
  resolveDataElementOptions(t2, e2) {
    const i2 = this.getParsed(t2);
    let s2 = super.resolveDataElementOptions(t2, e2);
    s2.$shared && (s2 = Object.assign({}, s2, { $shared: false }));
    const n2 = s2.radius;
    return "active" !== e2 && (s2.radius = 0), s2.radius += Ro(i2 && i2._custom, n2), s2;
  }
}
__publicField(BubbleController, "id", "bubble");
__publicField(BubbleController, "defaults", { datasetElementType: false, dataElementType: "point", animations: { numbers: { type: "number", properties: ["x", "y", "borderWidth", "radius"] } } });
__publicField(BubbleController, "overrides", { scales: { x: { type: "linear" }, y: { type: "linear" } } });
class DoughnutController extends DatasetController {
  constructor(t2, e2) {
    super(t2, e2), this.enableOptionSharing = true, this.innerRadius = void 0, this.outerRadius = void 0, this.offsetX = void 0, this.offsetY = void 0;
  }
  linkScales() {
  }
  parse(t2, e2) {
    const i2 = this.getDataset().data, s2 = this._cachedMeta;
    if (false === this._parsing) s2._parsed = i2;
    else {
      let n2, r2, o2 = (t3) => +i2[t3];
      if (zo(i2[t2])) {
        const { key: t3 = "value" } = this._parsing;
        o2 = (e3) => +Bo(i2[e3], t3);
      }
      for (n2 = t2, r2 = t2 + e2; n2 < r2; ++n2) s2._parsed[n2] = o2(n2);
    }
  }
  _getRotation() {
    return aa(this.options.rotation - 90);
  }
  _getCircumference() {
    return aa(this.options.circumference);
  }
  _getRotationExtents() {
    let t2 = Uo, e2 = -Uo;
    for (let i2 = 0; i2 < this.chart.data.datasets.length; ++i2) if (this.chart.isDatasetVisible(i2) && this.chart.getDatasetMeta(i2).type === this._type) {
      const s2 = this.chart.getDatasetMeta(i2).controller, n2 = s2._getRotation(), r2 = s2._getCircumference();
      t2 = Math.min(t2, n2), e2 = Math.max(e2, n2 + r2);
    }
    return { rotation: t2, circumference: e2 - t2 };
  }
  update(t2) {
    const e2 = this.chart, { chartArea: i2 } = e2, s2 = this._cachedMeta, n2 = s2.data, r2 = this.getMaxBorderWidth() + this.getMaxOffset(n2) + this.options.spacing, o2 = Math.max((Math.min(i2.width, i2.height) - r2) / 2, 0), a2 = Math.min((l2 = this.options.cutout, h2 = o2, "string" == typeof l2 && l2.endsWith("%") ? parseFloat(l2) / 100 : +l2 / h2), 1);
    var l2, h2;
    const c2 = this._getRingWeight(this.index), { circumference: u2, rotation: d2 } = this._getRotationExtents(), { ratioX: f2, ratioY: p2, offsetX: m2, offsetY: g2 } = function(t3, e3, i3) {
      let s3 = 1, n3 = 1, r3 = 0, o3 = 0;
      if (e3 < Uo) {
        const a3 = t3, l3 = a3 + e3, h3 = Math.cos(a3), c3 = Math.sin(a3), u3 = Math.cos(l3), d3 = Math.sin(l3), f3 = (t4, e4, s4) => pa(t4, a3, l3, true) ? 1 : Math.max(e4, e4 * i3, s4, s4 * i3), p3 = (t4, e4, s4) => pa(t4, a3, l3, true) ? -1 : Math.min(e4, e4 * i3, s4, s4 * i3), m3 = f3(0, h3, u3), g3 = f3(Qo, c3, d3), v3 = p3(Ko, h3, u3), b3 = p3(Ko + Qo, c3, d3);
        s3 = (m3 - v3) / 2, n3 = (g3 - b3) / 2, r3 = -(m3 + v3) / 2, o3 = -(g3 + b3) / 2;
      }
      return { ratioX: s3, ratioY: n3, offsetX: r3, offsetY: o3 };
    }(d2, u2, a2), v2 = (i2.width - r2) / f2, b2 = (i2.height - r2) / p2, _2 = Math.max(Math.min(v2, b2) / 2, 0), y2 = Eo(this.options.radius, _2), x2 = (y2 - Math.max(y2 * a2, 0)) / this._getVisibleDatasetWeightTotal();
    this.offsetX = m2 * y2, this.offsetY = g2 * y2, s2.total = this.calculateTotal(), this.outerRadius = y2 - x2 * this._getRingWeightOffset(this.index), this.innerRadius = Math.max(this.outerRadius - x2 * c2, 0), this.updateElements(n2, 0, n2.length, t2);
  }
  _circumference(t2, e2) {
    const i2 = this.options, s2 = this._cachedMeta, n2 = this._getCircumference();
    return e2 && i2.animation.animateRotate || !this.chart.getDataVisibility(t2) || null === s2._parsed[t2] || s2.data[t2].hidden ? 0 : this.calculateCircumference(s2._parsed[t2] * n2 / Uo);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, r2 = this.chart, o2 = r2.chartArea, a2 = r2.options.animation, l2 = (o2.left + o2.right) / 2, h2 = (o2.top + o2.bottom) / 2, c2 = n2 && a2.animateScale, u2 = c2 ? 0 : this.innerRadius, d2 = c2 ? 0 : this.outerRadius, { sharedOptions: f2, includeOptions: p2 } = this._getSharedOptions(e2, s2);
    let m2, g2 = this._getRotation();
    for (m2 = 0; m2 < e2; ++m2) g2 += this._circumference(m2, n2);
    for (m2 = e2; m2 < e2 + i2; ++m2) {
      const e3 = this._circumference(m2, n2), i3 = t2[m2], r3 = { x: l2 + this.offsetX, y: h2 + this.offsetY, startAngle: g2, endAngle: g2 + e3, circumference: e3, outerRadius: d2, innerRadius: u2 };
      p2 && (r3.options = f2 || this.resolveDataElementOptions(m2, i3.active ? "active" : s2)), g2 += e3, this.updateElement(i3, m2, r3, s2);
    }
  }
  calculateTotal() {
    const t2 = this._cachedMeta, e2 = t2.data;
    let i2, s2 = 0;
    for (i2 = 0; i2 < e2.length; i2++) {
      const n2 = t2._parsed[i2];
      null === n2 || isNaN(n2) || !this.chart.getDataVisibility(i2) || e2[i2].hidden || (s2 += Math.abs(n2));
    }
    return s2;
  }
  calculateCircumference(t2) {
    const e2 = this._cachedMeta.total;
    return e2 > 0 && !isNaN(t2) ? Uo * (Math.abs(t2) / e2) : 0;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart, s2 = i2.data.labels || [], n2 = Na(e2._parsed[t2], i2.options.locale);
    return { label: s2[t2] || "", value: n2 };
  }
  getMaxBorderWidth(t2) {
    let e2 = 0;
    const i2 = this.chart;
    let s2, n2, r2, o2, a2;
    if (!t2) {
      for (s2 = 0, n2 = i2.data.datasets.length; s2 < n2; ++s2) if (i2.isDatasetVisible(s2)) {
        r2 = i2.getDatasetMeta(s2), t2 = r2.data, o2 = r2.controller;
        break;
      }
    }
    if (!t2) return 0;
    for (s2 = 0, n2 = t2.length; s2 < n2; ++s2) a2 = o2.resolveDataElementOptions(s2), "inner" !== a2.borderAlign && (e2 = Math.max(e2, a2.borderWidth || 0, a2.hoverBorderWidth || 0));
    return e2;
  }
  getMaxOffset(t2) {
    let e2 = 0;
    for (let i2 = 0, s2 = t2.length; i2 < s2; ++i2) {
      const t3 = this.resolveDataElementOptions(i2);
      e2 = Math.max(e2, t3.offset || 0, t3.hoverOffset || 0);
    }
    return e2;
  }
  _getRingWeightOffset(t2) {
    let e2 = 0;
    for (let i2 = 0; i2 < t2; ++i2) this.chart.isDatasetVisible(i2) && (e2 += this._getRingWeight(i2));
    return e2;
  }
  _getRingWeight(t2) {
    return Math.max(Ro(this.chart.data.datasets[t2].weight, 1), 0);
  }
  _getVisibleDatasetWeightTotal() {
    return this._getRingWeightOffset(this.chart.data.datasets.length) || 1;
  }
}
__publicField(DoughnutController, "id", "doughnut");
__publicField(DoughnutController, "defaults", { datasetElementType: false, dataElementType: "arc", animation: { animateRotate: true, animateScale: false }, animations: { numbers: { type: "number", properties: ["circumference", "endAngle", "innerRadius", "outerRadius", "startAngle", "x", "y", "offset", "borderWidth", "spacing"] } }, cutout: "50%", rotation: 0, circumference: 360, radius: "100%", spacing: 0, indexAxis: "r" });
__publicField(DoughnutController, "descriptors", { _scriptable: (t2) => "spacing" !== t2, _indexable: (t2) => "spacing" !== t2 && !t2.startsWith("borderDash") && !t2.startsWith("hoverBorderDash") });
__publicField(DoughnutController, "overrides", { aspectRatio: 1, plugins: { legend: { labels: { generateLabels(t2) {
  const e2 = t2.data;
  if (e2.labels.length && e2.datasets.length) {
    const { labels: { pointStyle: i2, color: s2 } } = t2.legend.options;
    return e2.labels.map((e3, n2) => {
      const r2 = t2.getDatasetMeta(0).controller.getStyle(n2);
      return { text: e3, fillStyle: r2.backgroundColor, strokeStyle: r2.borderColor, fontColor: s2, lineWidth: r2.borderWidth, pointStyle: i2, hidden: !t2.getDataVisibility(n2), index: n2 };
    });
  }
  return [];
} }, onClick(t2, e2, i2) {
  i2.chart.toggleDataVisibility(e2.index), i2.chart.update();
} } } });
class LineController extends DatasetController {
  initialize() {
    this.enableOptionSharing = true, this.supportsDecimation = true, super.initialize();
  }
  update(t2) {
    const e2 = this._cachedMeta, { dataset: i2, data: s2 = [], _dataset: n2 } = e2, r2 = this.chart._animationsDisabled;
    let { start: o2, count: a2 } = za(e2, s2, r2);
    this._drawStart = o2, this._drawCount = a2, $a(e2) && (o2 = 0, a2 = s2.length), i2._chart = this.chart, i2._datasetIndex = this.index, i2._decimated = !!n2._decimated, i2.points = s2;
    const l2 = this.resolveDatasetElementOptions(t2);
    this.options.showLine || (l2.borderWidth = 0), l2.segment = this.options.segment, this.updateElement(i2, void 0, { animated: !r2, options: l2 }, t2), this.updateElements(s2, o2, a2, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { iScale: r2, vScale: o2, _stacked: a2, _dataset: l2 } = this._cachedMeta, { sharedOptions: h2, includeOptions: c2 } = this._getSharedOptions(e2, s2), u2 = r2.axis, d2 = o2.axis, { spanGaps: f2, segment: p2 } = this.options, m2 = ra(f2) ? f2 : Number.POSITIVE_INFINITY, g2 = this.chart._animationsDisabled || n2 || "none" === s2, v2 = e2 + i2, b2 = t2.length;
    let _2 = e2 > 0 && this.getParsed(e2 - 1);
    for (let i3 = 0; i3 < b2; ++i3) {
      const f3 = t2[i3], b3 = g2 ? f3 : {};
      if (i3 < e2 || i3 >= v2) {
        b3.skip = true;
        continue;
      }
      const y2 = this.getParsed(i3), x2 = So(y2[d2]), w2 = b3[u2] = r2.getPixelForValue(y2[u2], i3), k2 = b3[d2] = n2 || x2 ? o2.getBasePixel() : o2.getPixelForValue(a2 ? this.applyStack(o2, y2, a2) : y2[d2], i3);
      b3.skip = isNaN(w2) || isNaN(k2) || x2, b3.stop = i3 > 0 && Math.abs(y2[u2] - _2[u2]) > m2, p2 && (b3.parsed = y2, b3.raw = l2.data[i3]), c2 && (b3.options = h2 || this.resolveDataElementOptions(i3, f3.active ? "active" : s2)), g2 || this.updateElement(f3, i3, b3, s2), _2 = y2;
    }
  }
  getMaxOverflow() {
    const t2 = this._cachedMeta, e2 = t2.dataset, i2 = e2.options && e2.options.borderWidth || 0, s2 = t2.data || [];
    if (!s2.length) return i2;
    const n2 = s2[0].size(this.resolveDataElementOptions(0)), r2 = s2[s2.length - 1].size(this.resolveDataElementOptions(s2.length - 1));
    return Math.max(i2, n2, r2) / 2;
  }
  draw() {
    const t2 = this._cachedMeta;
    t2.dataset.updateControlPoints(this.chart.chartArea, t2.iScale.axis), super.draw();
  }
}
__publicField(LineController, "id", "line");
__publicField(LineController, "defaults", { datasetElementType: "line", dataElementType: "point", showLine: true, spanGaps: false });
__publicField(LineController, "overrides", { scales: { _index_: { type: "category" }, _value_: { type: "linear" } } });
class PolarAreaController extends DatasetController {
  constructor(t2, e2) {
    super(t2, e2), this.innerRadius = void 0, this.outerRadius = void 0;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart, s2 = i2.data.labels || [], n2 = Na(e2._parsed[t2].r, i2.options.locale);
    return { label: s2[t2] || "", value: n2 };
  }
  parseObjectData(t2, e2, i2, s2) {
    return Pl.bind(this)(t2, e2, i2, s2);
  }
  update(t2) {
    const e2 = this._cachedMeta.data;
    this._updateRadius(), this.updateElements(e2, 0, e2.length, t2);
  }
  getMinMax() {
    const t2 = this._cachedMeta, e2 = { min: Number.POSITIVE_INFINITY, max: Number.NEGATIVE_INFINITY };
    return t2.data.forEach((t3, i2) => {
      const s2 = this.getParsed(i2).r;
      !isNaN(s2) && this.chart.getDataVisibility(i2) && (s2 < e2.min && (e2.min = s2), s2 > e2.max && (e2.max = s2));
    }), e2;
  }
  _updateRadius() {
    const t2 = this.chart, e2 = t2.chartArea, i2 = t2.options, s2 = Math.min(e2.right - e2.left, e2.bottom - e2.top), n2 = Math.max(s2 / 2, 0), r2 = (n2 - Math.max(i2.cutoutPercentage ? n2 / 100 * i2.cutoutPercentage : 1, 0)) / t2.getVisibleDatasetCount();
    this.outerRadius = n2 - r2 * this.index, this.innerRadius = this.outerRadius - r2;
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, r2 = this.chart, o2 = r2.options.animation, a2 = this._cachedMeta.rScale, l2 = a2.xCenter, h2 = a2.yCenter, c2 = a2.getIndexAngle(0) - 0.5 * Ko;
    let u2, d2 = c2;
    const f2 = 360 / this.countVisibleElements();
    for (u2 = 0; u2 < e2; ++u2) d2 += this._computeAngle(u2, s2, f2);
    for (u2 = e2; u2 < e2 + i2; u2++) {
      const e3 = t2[u2];
      let i3 = d2, p2 = d2 + this._computeAngle(u2, s2, f2), m2 = r2.getDataVisibility(u2) ? a2.getDistanceFromCenterForValue(this.getParsed(u2).r) : 0;
      d2 = p2, n2 && (o2.animateScale && (m2 = 0), o2.animateRotate && (i3 = p2 = c2));
      const g2 = { x: l2, y: h2, innerRadius: 0, outerRadius: m2, startAngle: i3, endAngle: p2, options: this.resolveDataElementOptions(u2, e3.active ? "active" : s2) };
      this.updateElement(e3, u2, g2, s2);
    }
  }
  countVisibleElements() {
    const t2 = this._cachedMeta;
    let e2 = 0;
    return t2.data.forEach((t3, i2) => {
      !isNaN(this.getParsed(i2).r) && this.chart.getDataVisibility(i2) && e2++;
    }), e2;
  }
  _computeAngle(t2, e2, i2) {
    return this.chart.getDataVisibility(t2) ? aa(this.resolveDataElementOptions(t2, e2).angle || i2) : 0;
  }
}
__publicField(PolarAreaController, "id", "polarArea");
__publicField(PolarAreaController, "defaults", { dataElementType: "arc", animation: { animateRotate: true, animateScale: true }, animations: { numbers: { type: "number", properties: ["x", "y", "startAngle", "endAngle", "innerRadius", "outerRadius"] } }, indexAxis: "r", startAngle: 0 });
__publicField(PolarAreaController, "overrides", { aspectRatio: 1, plugins: { legend: { labels: { generateLabels(t2) {
  const e2 = t2.data;
  if (e2.labels.length && e2.datasets.length) {
    const { labels: { pointStyle: i2, color: s2 } } = t2.legend.options;
    return e2.labels.map((e3, n2) => {
      const r2 = t2.getDatasetMeta(0).controller.getStyle(n2);
      return { text: e3, fillStyle: r2.backgroundColor, strokeStyle: r2.borderColor, fontColor: s2, lineWidth: r2.borderWidth, pointStyle: i2, hidden: !t2.getDataVisibility(n2), index: n2 };
    });
  }
  return [];
} }, onClick(t2, e2, i2) {
  i2.chart.toggleDataVisibility(e2.index), i2.chart.update();
} } }, scales: { r: { type: "radialLinear", angleLines: { display: false }, beginAtZero: true, grid: { circular: true }, pointLabels: { display: false }, startAngle: 0 } } });
var Vh = Object.freeze({ __proto__: null, BarController, BubbleController, DoughnutController, LineController, PieController: (_b = class extends DoughnutController {
}, __publicField(_b, "id", "pie"), __publicField(_b, "defaults", { cutout: 0, rotation: 0, circumference: 360, radius: "100%" }), _b), PolarAreaController, RadarController: (_c = class extends DatasetController {
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta.vScale, i2 = this.getParsed(t2);
    return { label: e2.getLabels()[t2], value: "" + e2.getLabelForValue(i2[e2.axis]) };
  }
  parseObjectData(t2, e2, i2, s2) {
    return Pl.bind(this)(t2, e2, i2, s2);
  }
  update(t2) {
    const e2 = this._cachedMeta, i2 = e2.dataset, s2 = e2.data || [], n2 = e2.iScale.getLabels();
    if (i2.points = s2, "resize" !== t2) {
      const e3 = this.resolveDatasetElementOptions(t2);
      this.options.showLine || (e3.borderWidth = 0);
      const r2 = { _loop: true, _fullLoop: n2.length === s2.length, options: e3 };
      this.updateElement(i2, void 0, r2, t2);
    }
    this.updateElements(s2, 0, s2.length, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = this._cachedMeta.rScale, r2 = "reset" === s2;
    for (let o2 = e2; o2 < e2 + i2; o2++) {
      const e3 = t2[o2], i3 = this.resolveDataElementOptions(o2, e3.active ? "active" : s2), a2 = n2.getPointPositionForValue(o2, this.getParsed(o2).r), l2 = r2 ? n2.xCenter : a2.x, h2 = r2 ? n2.yCenter : a2.y, c2 = { x: l2, y: h2, angle: a2.angle, skip: isNaN(l2) || isNaN(h2), options: i3 };
      this.updateElement(e3, o2, c2, s2);
    }
  }
}, __publicField(_c, "id", "radar"), __publicField(_c, "defaults", { datasetElementType: "line", dataElementType: "point", indexAxis: "r", showLine: true, elements: { line: { fill: "start" } } }), __publicField(_c, "overrides", { aspectRatio: 1, scales: { r: { type: "radialLinear" } } }), _c), ScatterController: (_d = class extends DatasetController {
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart.data.labels || [], { xScale: s2, yScale: n2 } = e2, r2 = this.getParsed(t2), o2 = s2.getLabelForValue(r2.x), a2 = n2.getLabelForValue(r2.y);
    return { label: i2[t2] || "", value: "(" + o2 + ", " + a2 + ")" };
  }
  update(t2) {
    const e2 = this._cachedMeta, { data: i2 = [] } = e2, s2 = this.chart._animationsDisabled;
    let { start: n2, count: r2 } = za(e2, i2, s2);
    if (this._drawStart = n2, this._drawCount = r2, $a(e2) && (n2 = 0, r2 = i2.length), this.options.showLine) {
      this.datasetElementType || this.addElements();
      const { dataset: n3, _dataset: r3 } = e2;
      n3._chart = this.chart, n3._datasetIndex = this.index, n3._decimated = !!r3._decimated, n3.points = i2;
      const o2 = this.resolveDatasetElementOptions(t2);
      o2.segment = this.options.segment, this.updateElement(n3, void 0, { animated: !s2, options: o2 }, t2);
    } else this.datasetElementType && (delete e2.dataset, this.datasetElementType = false);
    this.updateElements(i2, n2, r2, t2);
  }
  addElements() {
    const { showLine: t2 } = this.options;
    !this.datasetElementType && t2 && (this.datasetElementType = this.chart.registry.getElement("line")), super.addElements();
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { iScale: r2, vScale: o2, _stacked: a2, _dataset: l2 } = this._cachedMeta, h2 = this.resolveDataElementOptions(e2, s2), c2 = this.getSharedOptions(h2), u2 = this.includeOptions(s2, c2), d2 = r2.axis, f2 = o2.axis, { spanGaps: p2, segment: m2 } = this.options, g2 = ra(p2) ? p2 : Number.POSITIVE_INFINITY, v2 = this.chart._animationsDisabled || n2 || "none" === s2;
    let b2 = e2 > 0 && this.getParsed(e2 - 1);
    for (let h3 = e2; h3 < e2 + i2; ++h3) {
      const e3 = t2[h3], i3 = this.getParsed(h3), p3 = v2 ? e3 : {}, _2 = So(i3[f2]), y2 = p3[d2] = r2.getPixelForValue(i3[d2], h3), x2 = p3[f2] = n2 || _2 ? o2.getBasePixel() : o2.getPixelForValue(a2 ? this.applyStack(o2, i3, a2) : i3[f2], h3);
      p3.skip = isNaN(y2) || isNaN(x2) || _2, p3.stop = h3 > 0 && Math.abs(i3[d2] - b2[d2]) > g2, m2 && (p3.parsed = i3, p3.raw = l2.data[h3]), u2 && (p3.options = c2 || this.resolveDataElementOptions(h3, e3.active ? "active" : s2)), v2 || this.updateElement(e3, h3, p3, s2), b2 = i3;
    }
    this.updateSharedOptions(c2, s2, h2);
  }
  getMaxOverflow() {
    const t2 = this._cachedMeta, e2 = t2.data || [];
    if (!this.options.showLine) {
      let t3 = 0;
      for (let i3 = e2.length - 1; i3 >= 0; --i3) t3 = Math.max(t3, e2[i3].size(this.resolveDataElementOptions(i3)) / 2);
      return t3 > 0 && t3;
    }
    const i2 = t2.dataset, s2 = i2.options && i2.options.borderWidth || 0;
    if (!e2.length) return s2;
    const n2 = e2[0].size(this.resolveDataElementOptions(0)), r2 = e2[e2.length - 1].size(this.resolveDataElementOptions(e2.length - 1));
    return Math.max(s2, n2, r2) / 2;
  }
}, __publicField(_d, "id", "scatter"), __publicField(_d, "defaults", { datasetElementType: false, dataElementType: "point", showLine: false, fill: false }), __publicField(_d, "overrides", { interaction: { mode: "point" }, scales: { x: { type: "linear" }, y: { type: "linear" } } }), _d) });
function Oh() {
  throw new Error("This method is not implemented: Check that a complete date adapter is provided.");
}
class DateAdapterBase {
  constructor(t2) {
    __publicField(this, "options");
    this.options = t2 || {};
  }
  static override(t2) {
    Object.assign(DateAdapterBase.prototype, t2);
  }
  init() {
  }
  formats() {
    return Oh();
  }
  parse() {
    return Oh();
  }
  format() {
    return Oh();
  }
  add() {
    return Oh();
  }
  diff() {
    return Oh();
  }
  startOf() {
    return Oh();
  }
  endOf() {
    return Oh();
  }
}
var Ah = DateAdapterBase;
function Fh(t2, e2, i2, s2) {
  const { controller: n2, data: r2, _sorted: o2 } = t2, a2 = n2._cachedMeta.iScale, l2 = t2.dataset && t2.dataset.options ? t2.dataset.options.spanGaps : null;
  if (a2 && e2 === a2.axis && "r" !== e2 && o2 && r2.length) {
    const o3 = a2._reversePixels ? _a : ba;
    if (!s2) {
      const s3 = o3(r2, e2, i2);
      if (l2) {
        const { vScale: e3 } = n2._cachedMeta, { _parsed: i3 } = t2, r3 = i3.slice(0, s3.lo + 1).reverse().findIndex((t3) => !So(t3[e3.axis]));
        s3.lo -= Math.max(0, r3);
        const o4 = i3.slice(s3.hi).findIndex((t3) => !So(t3[e3.axis]));
        s3.hi += Math.max(0, o4);
      }
      return s3;
    }
    if (n2._sharedOptions) {
      const t3 = r2[0], s3 = "function" == typeof t3.getRange && t3.getRange(e2);
      if (s3) {
        const t4 = o3(r2, e2, i2 - s3), n3 = o3(r2, e2, i2 + s3);
        return { lo: t4.lo, hi: n3.hi };
      }
    }
  }
  return { lo: 0, hi: r2.length - 1 };
}
function Nh(t2, e2, i2, s2, n2) {
  const r2 = t2.getSortedVisibleDatasetMetas(), o2 = i2[e2];
  for (let t3 = 0, i3 = r2.length; t3 < i3; ++t3) {
    const { index: i4, data: a2 } = r2[t3], { lo: l2, hi: h2 } = Fh(r2[t3], e2, o2, n2);
    for (let t4 = l2; t4 <= h2; ++t4) {
      const e3 = a2[t4];
      e3.skip || s2(e3, i4, t4);
    }
  }
}
function Wh(t2, e2, i2, s2, n2) {
  const r2 = [];
  if (!n2 && !t2.isPointInArea(e2)) return r2;
  return Nh(t2, i2, e2, function(i3, o2, a2) {
    (n2 || Za(i3, t2.chartArea, 0)) && i3.inRange(e2.x, e2.y, s2) && r2.push({ element: i3, datasetIndex: o2, index: a2 });
  }, true), r2;
}
function Ih(t2, e2, i2, s2, n2, r2) {
  let o2 = [];
  const a2 = function(t3) {
    const e3 = -1 !== t3.indexOf("x"), i3 = -1 !== t3.indexOf("y");
    return function(t4, s3) {
      const n3 = e3 ? Math.abs(t4.x - s3.x) : 0, r3 = i3 ? Math.abs(t4.y - s3.y) : 0;
      return Math.sqrt(Math.pow(n3, 2) + Math.pow(r3, 2));
    };
  }(i2);
  let l2 = Number.POSITIVE_INFINITY;
  return Nh(t2, i2, e2, function(i3, h2, c2) {
    const u2 = i3.inRange(e2.x, e2.y, n2);
    if (s2 && !u2) return;
    const d2 = i3.getCenterPoint(n2);
    if (!(!!r2 || t2.isPointInArea(d2)) && !u2) return;
    const f2 = a2(e2, d2);
    f2 < l2 ? (o2 = [{ element: i3, datasetIndex: h2, index: c2 }], l2 = f2) : f2 === l2 && o2.push({ element: i3, datasetIndex: h2, index: c2 });
  }), o2;
}
function Bh(t2, e2, i2, s2, n2, r2) {
  return r2 || t2.isPointInArea(e2) ? "r" !== i2 || s2 ? Ih(t2, e2, i2, s2, n2, r2) : function(t3, e3, i3, s3) {
    let n3 = [];
    return Nh(t3, i3, e3, function(t4, i4, r3) {
      const { startAngle: o2, endAngle: a2 } = t4.getProps(["startAngle", "endAngle"], s3), { angle: l2 } = ca(t4, { x: e3.x, y: e3.y });
      pa(l2, o2, a2) && n3.push({ element: t4, datasetIndex: i4, index: r3 });
    }), n3;
  }(t2, e2, i2, n2) : [];
}
function jh(t2, e2, i2, s2, n2) {
  const r2 = [], o2 = "x" === i2 ? "inXRange" : "inYRange";
  let a2 = false;
  return Nh(t2, i2, e2, (t3, s3, l2) => {
    t3[o2] && t3[o2](e2[i2], n2) && (r2.push({ element: t3, datasetIndex: s3, index: l2 }), a2 = a2 || t3.inRange(e2.x, e2.y, n2));
  }), s2 && !a2 ? [] : r2;
}
var Hh = { modes: { index(t2, e2, i2, s2) {
  const n2 = Xl(e2, t2), r2 = i2.axis || "x", o2 = i2.includeInvisible || false, a2 = i2.intersect ? Wh(t2, n2, r2, s2, o2) : Bh(t2, n2, r2, false, s2, o2), l2 = [];
  return a2.length ? (t2.getSortedVisibleDatasetMetas().forEach((t3) => {
    const e3 = a2[0].index, i3 = t3.data[e3];
    i3 && !i3.skip && l2.push({ element: i3, datasetIndex: t3.index, index: e3 });
  }), l2) : [];
}, dataset(t2, e2, i2, s2) {
  const n2 = Xl(e2, t2), r2 = i2.axis || "xy", o2 = i2.includeInvisible || false;
  let a2 = i2.intersect ? Wh(t2, n2, r2, s2, o2) : Bh(t2, n2, r2, false, s2, o2);
  if (a2.length > 0) {
    const e3 = a2[0].datasetIndex, i3 = t2.getDatasetMeta(e3).data;
    a2 = [];
    for (let t3 = 0; t3 < i3.length; ++t3) a2.push({ element: i3[t3], datasetIndex: e3, index: t3 });
  }
  return a2;
}, point: (t2, e2, i2, s2) => Wh(t2, Xl(e2, t2), i2.axis || "xy", s2, i2.includeInvisible || false), nearest(t2, e2, i2, s2) {
  const n2 = Xl(e2, t2), r2 = i2.axis || "xy", o2 = i2.includeInvisible || false;
  return Bh(t2, n2, r2, i2.intersect, s2, o2);
}, x: (t2, e2, i2, s2) => jh(t2, Xl(e2, t2), "x", i2.intersect, s2), y: (t2, e2, i2, s2) => jh(t2, Xl(e2, t2), "y", i2.intersect, s2) } };
const qh = ["left", "top", "right", "bottom"];
function Xh(t2, e2) {
  return t2.filter((t3) => t3.pos === e2);
}
function Kh(t2, e2) {
  return t2.filter((t3) => -1 === qh.indexOf(t3.pos) && t3.box.axis === e2);
}
function Uh(t2, e2) {
  return t2.sort((t3, i2) => {
    const s2 = e2 ? i2 : t3, n2 = e2 ? t3 : i2;
    return s2.weight === n2.weight ? s2.index - n2.index : s2.weight - n2.weight;
  });
}
function Yh(t2, e2) {
  const i2 = function(t3) {
    const e3 = {};
    for (const i3 of t3) {
      const { stack: t4, pos: s3, stackWeight: n3 } = i3;
      if (!t4 || !qh.includes(s3)) continue;
      const r3 = e3[t4] || (e3[t4] = { count: 0, placed: 0, weight: 0, size: 0 });
      r3.count++, r3.weight += n3;
    }
    return e3;
  }(t2), { vBoxMaxWidth: s2, hBoxMaxHeight: n2 } = e2;
  let r2, o2, a2;
  for (r2 = 0, o2 = t2.length; r2 < o2; ++r2) {
    a2 = t2[r2];
    const { fullSize: o3 } = a2.box, l2 = i2[a2.stack], h2 = l2 && a2.stackWeight / l2.weight;
    a2.horizontal ? (a2.width = h2 ? h2 * s2 : o3 && e2.availableWidth, a2.height = n2) : (a2.width = s2, a2.height = h2 ? h2 * n2 : o3 && e2.availableHeight);
  }
  return i2;
}
function Gh(t2, e2, i2, s2) {
  return Math.max(t2[i2], e2[i2]) + Math.max(t2[s2], e2[s2]);
}
function Jh(t2, e2) {
  t2.top = Math.max(t2.top, e2.top), t2.left = Math.max(t2.left, e2.left), t2.bottom = Math.max(t2.bottom, e2.bottom), t2.right = Math.max(t2.right, e2.right);
}
function Qh(t2, e2, i2, s2) {
  const { pos: n2, box: r2 } = i2, o2 = t2.maxPadding;
  if (!zo(n2)) {
    i2.size && (t2[n2] -= i2.size);
    const e3 = s2[i2.stack] || { size: 0, count: 1 };
    e3.size = Math.max(e3.size, i2.horizontal ? r2.height : r2.width), i2.size = e3.size / e3.count, t2[n2] += i2.size;
  }
  r2.getPadding && Jh(o2, r2.getPadding());
  const a2 = Math.max(0, e2.outerWidth - Gh(o2, t2, "left", "right")), l2 = Math.max(0, e2.outerHeight - Gh(o2, t2, "top", "bottom")), h2 = a2 !== t2.w, c2 = l2 !== t2.h;
  return t2.w = a2, t2.h = l2, i2.horizontal ? { same: h2, other: c2 } : { same: c2, other: h2 };
}
function Zh(t2, e2) {
  const i2 = e2.maxPadding;
  function s2(t3) {
    const s3 = { left: 0, top: 0, right: 0, bottom: 0 };
    return t3.forEach((t4) => {
      s3[t4] = Math.max(e2[t4], i2[t4]);
    }), s3;
  }
  return s2(t2 ? ["left", "right"] : ["top", "bottom"]);
}
function tc(t2, e2, i2, s2) {
  const n2 = [];
  let r2, o2, a2, l2, h2, c2;
  for (r2 = 0, o2 = t2.length, h2 = 0; r2 < o2; ++r2) {
    a2 = t2[r2], l2 = a2.box, l2.update(a2.width || e2.w, a2.height || e2.h, Zh(a2.horizontal, e2));
    const { same: o3, other: u2 } = Qh(e2, i2, a2, s2);
    h2 |= o3 && n2.length, c2 = c2 || u2, l2.fullSize || n2.push(a2);
  }
  return h2 && tc(n2, e2, i2, s2) || c2;
}
function ec(t2, e2, i2, s2, n2) {
  t2.top = i2, t2.left = e2, t2.right = e2 + s2, t2.bottom = i2 + n2, t2.width = s2, t2.height = n2;
}
function ic(t2, e2, i2, s2) {
  const n2 = i2.padding;
  let { x: r2, y: o2 } = e2;
  for (const a2 of t2) {
    const t3 = a2.box, l2 = s2[a2.stack] || { placed: 0, weight: 1 }, h2 = a2.stackWeight / l2.weight || 1;
    if (a2.horizontal) {
      const s3 = e2.w * h2, r3 = l2.size || t3.height;
      Ho(l2.start) && (o2 = l2.start), t3.fullSize ? ec(t3, n2.left, o2, i2.outerWidth - n2.right - n2.left, r3) : ec(t3, e2.left + l2.placed, o2, s3, r3), l2.start = o2, l2.placed += s3, o2 = t3.bottom;
    } else {
      const s3 = e2.h * h2, o3 = l2.size || t3.width;
      Ho(l2.start) && (r2 = l2.start), t3.fullSize ? ec(t3, r2, n2.top, o3, i2.outerHeight - n2.bottom - n2.top) : ec(t3, r2, e2.top + l2.placed, o3, s3), l2.start = r2, l2.placed += s3, r2 = t3.right;
    }
  }
  e2.x = r2, e2.y = o2;
}
var sc = { addBox(t2, e2) {
  t2.boxes || (t2.boxes = []), e2.fullSize = e2.fullSize || false, e2.position = e2.position || "top", e2.weight = e2.weight || 0, e2._layers = e2._layers || function() {
    return [{ z: 0, draw(t3) {
      e2.draw(t3);
    } }];
  }, t2.boxes.push(e2);
}, removeBox(t2, e2) {
  const i2 = t2.boxes ? t2.boxes.indexOf(e2) : -1;
  -1 !== i2 && t2.boxes.splice(i2, 1);
}, configure(t2, e2, i2) {
  e2.fullSize = i2.fullSize, e2.position = i2.position, e2.weight = i2.weight;
}, update(t2, e2, i2, s2) {
  if (!t2) return;
  const n2 = ml(t2.options.layout.padding), r2 = Math.max(e2 - n2.width, 0), o2 = Math.max(i2 - n2.height, 0), a2 = function(t3) {
    const e3 = function(t4) {
      const e4 = [];
      let i4, s4, n4, r4, o4, a4;
      for (i4 = 0, s4 = (t4 || []).length; i4 < s4; ++i4) n4 = t4[i4], { position: r4, options: { stack: o4, stackWeight: a4 = 1 } } = n4, e4.push({ index: i4, box: n4, pos: r4, horizontal: n4.isHorizontal(), weight: n4.weight, stack: o4 && r4 + o4, stackWeight: a4 });
      return e4;
    }(t3), i3 = Uh(e3.filter((t4) => t4.box.fullSize), true), s3 = Uh(Xh(e3, "left"), true), n3 = Uh(Xh(e3, "right")), r3 = Uh(Xh(e3, "top"), true), o3 = Uh(Xh(e3, "bottom")), a3 = Kh(e3, "x"), l3 = Kh(e3, "y");
    return { fullSize: i3, leftAndTop: s3.concat(r3), rightAndBottom: n3.concat(l3).concat(o3).concat(a3), chartArea: Xh(e3, "chartArea"), vertical: s3.concat(n3).concat(l3), horizontal: r3.concat(o3).concat(a3) };
  }(t2.boxes), l2 = a2.vertical, h2 = a2.horizontal;
  To(t2.boxes, (t3) => {
    "function" == typeof t3.beforeLayout && t3.beforeLayout();
  });
  const c2 = l2.reduce((t3, e3) => e3.box.options && false === e3.box.options.display ? t3 : t3 + 1, 0) || 1, u2 = Object.freeze({ outerWidth: e2, outerHeight: i2, padding: n2, availableWidth: r2, availableHeight: o2, vBoxMaxWidth: r2 / 2 / c2, hBoxMaxHeight: o2 / 2 }), d2 = Object.assign({}, n2);
  Jh(d2, ml(s2));
  const f2 = Object.assign({ maxPadding: d2, w: r2, h: o2, x: n2.left, y: n2.top }, n2), p2 = Yh(l2.concat(h2), u2);
  tc(a2.fullSize, f2, u2, p2), tc(l2, f2, u2, p2), tc(h2, f2, u2, p2) && tc(l2, f2, u2, p2), function(t3) {
    const e3 = t3.maxPadding;
    function i3(i4) {
      const s3 = Math.max(e3[i4] - t3[i4], 0);
      return t3[i4] += s3, s3;
    }
    t3.y += i3("top"), t3.x += i3("left"), i3("right"), i3("bottom");
  }(f2), ic(a2.leftAndTop, f2, u2, p2), f2.x += f2.w, f2.y += f2.h, ic(a2.rightAndBottom, f2, u2, p2), t2.chartArea = { left: f2.left, top: f2.top, right: f2.left + f2.w, bottom: f2.top + f2.h, height: f2.h, width: f2.w }, To(a2.chartArea, (e3) => {
    const i3 = e3.box;
    Object.assign(i3, t2.chartArea), i3.update(f2.w, f2.h, { left: 0, top: 0, right: 0, bottom: 0 });
  });
} };
class BasePlatform {
  acquireContext(t2, e2) {
  }
  releaseContext(t2) {
    return false;
  }
  addEventListener(t2, e2, i2) {
  }
  removeEventListener(t2, e2, i2) {
  }
  getDevicePixelRatio() {
    return 1;
  }
  getMaximumSize(t2, e2, i2, s2) {
    return e2 = Math.max(0, e2 || t2.width), i2 = i2 || t2.height, { width: e2, height: Math.max(0, s2 ? Math.floor(e2 / s2) : i2) };
  }
  isAttached(t2) {
    return true;
  }
  updateConfig(t2) {
  }
}
class BasicPlatform extends BasePlatform {
  acquireContext(t2) {
    return t2 && t2.getContext && t2.getContext("2d") || null;
  }
  updateConfig(t2) {
    t2.options.animation = false;
  }
}
const nc = "$chartjs", rc = { touchstart: "mousedown", touchmove: "mousemove", touchend: "mouseup", pointerenter: "mouseenter", pointerdown: "mousedown", pointermove: "mousemove", pointerup: "mouseup", pointerleave: "mouseout", pointerout: "mouseout" }, oc = (t2) => null === t2 || "" === t2;
const ac = !!Gl && { passive: true };
function lc(t2, e2, i2) {
  t2 && t2.canvas && t2.canvas.removeEventListener(e2, i2, ac);
}
function hc(t2, e2) {
  for (const i2 of t2) if (i2 === e2 || i2.contains(e2)) return true;
}
function cc(t2, e2, i2) {
  const s2 = t2.canvas, n2 = new MutationObserver((t3) => {
    let e3 = false;
    for (const i3 of t3) e3 = e3 || hc(i3.addedNodes, s2), e3 = e3 && !hc(i3.removedNodes, s2);
    e3 && i2();
  });
  return n2.observe(document, { childList: true, subtree: true }), n2;
}
function uc(t2, e2, i2) {
  const s2 = t2.canvas, n2 = new MutationObserver((t3) => {
    let e3 = false;
    for (const i3 of t3) e3 = e3 || hc(i3.removedNodes, s2), e3 = e3 && !hc(i3.addedNodes, s2);
    e3 && i2();
  });
  return n2.observe(document, { childList: true, subtree: true }), n2;
}
const dc = /* @__PURE__ */ new Map();
let fc = 0;
function pc() {
  const t2 = window.devicePixelRatio;
  t2 !== fc && (fc = t2, dc.forEach((e2, i2) => {
    i2.currentDevicePixelRatio !== t2 && e2();
  }));
}
function mc(t2, e2, i2) {
  const s2 = t2.canvas, n2 = s2 && Il(s2);
  if (!n2) return;
  const r2 = Ma((t3, e3) => {
    const s3 = n2.clientWidth;
    i2(t3, e3), s3 < n2.clientWidth && i2();
  }, window), o2 = new ResizeObserver((t3) => {
    const e3 = t3[0], i3 = e3.contentRect.width, s3 = e3.contentRect.height;
    0 === i3 && 0 === s3 || r2(i3, s3);
  });
  return o2.observe(n2), function(t3, e3) {
    dc.size || window.addEventListener("resize", pc), dc.set(t3, e3);
  }(t2, r2), o2;
}
function gc(t2, e2, i2) {
  i2 && i2.disconnect(), "resize" === e2 && function(t3) {
    dc.delete(t3), dc.size || window.removeEventListener("resize", pc);
  }(t2);
}
function vc(t2, e2, i2) {
  const s2 = t2.canvas, n2 = Ma((e3) => {
    null !== t2.ctx && i2(function(t3, e4) {
      const i3 = rc[t3.type] || t3.type, { x: s3, y: n3 } = Xl(t3, e4);
      return { type: i3, chart: e4, native: t3, x: void 0 !== s3 ? s3 : null, y: void 0 !== n3 ? n3 : null };
    }(e3, t2));
  }, t2);
  return function(t3, e3, i3) {
    t3 && t3.addEventListener(e3, i3, ac);
  }(s2, e2, n2), n2;
}
class DomPlatform extends BasePlatform {
  acquireContext(t2, e2) {
    const i2 = t2 && t2.getContext && t2.getContext("2d");
    return i2 && i2.canvas === t2 ? (function(t3, e3) {
      const i3 = t3.style, s2 = t3.getAttribute("height"), n2 = t3.getAttribute("width");
      if (t3[nc] = { initial: { height: s2, width: n2, style: { display: i3.display, height: i3.height, width: i3.width } } }, i3.display = i3.display || "block", i3.boxSizing = i3.boxSizing || "border-box", oc(n2)) {
        const e4 = Jl(t3, "width");
        void 0 !== e4 && (t3.width = e4);
      }
      if (oc(s2)) if ("" === t3.style.height) t3.height = t3.width / (e3 || 2);
      else {
        const e4 = Jl(t3, "height");
        void 0 !== e4 && (t3.height = e4);
      }
    }(t2, e2), i2) : null;
  }
  releaseContext(t2) {
    const e2 = t2.canvas;
    if (!e2[nc]) return false;
    const i2 = e2[nc].initial;
    ["height", "width"].forEach((t3) => {
      const s3 = i2[t3];
      So(s3) ? e2.removeAttribute(t3) : e2.setAttribute(t3, s3);
    });
    const s2 = i2.style || {};
    return Object.keys(s2).forEach((t3) => {
      e2.style[t3] = s2[t3];
    }), e2.width = e2.width, delete e2[nc], true;
  }
  addEventListener(t2, e2, i2) {
    this.removeEventListener(t2, e2);
    const s2 = t2.$proxies || (t2.$proxies = {}), n2 = { attach: cc, detach: uc, resize: mc }[e2] || vc;
    s2[e2] = n2(t2, e2, i2);
  }
  removeEventListener(t2, e2) {
    const i2 = t2.$proxies || (t2.$proxies = {}), s2 = i2[e2];
    if (!s2) return;
    ({ attach: gc, detach: gc, resize: gc }[e2] || lc)(t2, e2, s2), i2[e2] = void 0;
  }
  getDevicePixelRatio() {
    return window.devicePixelRatio;
  }
  getMaximumSize(t2, e2, i2, s2) {
    return Ul(t2, e2, i2, s2);
  }
  isAttached(t2) {
    const e2 = t2 && Il(t2);
    return !(!e2 || !e2.isConnected);
  }
}
let bc = (_e2 = class {
  constructor() {
    __publicField(this, "x");
    __publicField(this, "y");
    __publicField(this, "active", false);
    __publicField(this, "options");
    __publicField(this, "$animations");
  }
  tooltipPosition(t2) {
    const { x: e2, y: i2 } = this.getProps(["x", "y"], t2);
    return { x: e2, y: i2 };
  }
  hasValue() {
    return ra(this.x) && ra(this.y);
  }
  getProps(t2, e2) {
    const i2 = this.$animations;
    if (!e2 || !i2) return this;
    const s2 = {};
    return t2.forEach((t3) => {
      s2[t3] = i2[t3] && i2[t3].active() ? i2[t3]._to : this[t3];
    }), s2;
  }
}, __publicField(_e2, "defaults", {}), __publicField(_e2, "defaultRoutes"), _e2);
function _c2(t2, e2) {
  const i2 = t2.options.ticks, s2 = function(t3) {
    const e3 = t3.options.offset, i3 = t3._tickSize(), s3 = t3._length / i3 + (e3 ? 0 : 1), n3 = t3._maxLength / i3;
    return Math.floor(Math.min(s3, n3));
  }(t2), n2 = Math.min(i2.maxTicksLimit || s2, s2), r2 = i2.major.enabled ? function(t3) {
    const e3 = [];
    let i3, s3;
    for (i3 = 0, s3 = t3.length; i3 < s3; i3++) t3[i3].major && e3.push(i3);
    return e3;
  }(e2) : [], o2 = r2.length, a2 = r2[0], l2 = r2[o2 - 1], h2 = [];
  if (o2 > n2) return function(t3, e3, i3, s3) {
    let n3, r3 = 0, o3 = i3[0];
    for (s3 = Math.ceil(s3), n3 = 0; n3 < t3.length; n3++) n3 === o3 && (e3.push(t3[n3]), r3++, o3 = i3[r3 * s3]);
  }(e2, h2, r2, o2 / n2), h2;
  const c2 = function(t3, e3, i3) {
    const s3 = function(t4) {
      const e4 = t4.length;
      let i4, s4;
      if (e4 < 2) return false;
      for (s4 = t4[0], i4 = 1; i4 < e4; ++i4) if (t4[i4] - t4[i4 - 1] !== s4) return false;
      return s4;
    }(t3), n3 = e3.length / i3;
    if (!s3) return Math.max(n3, 1);
    const r3 = function(t4) {
      const e4 = [], i4 = Math.sqrt(t4);
      let s4;
      for (s4 = 1; s4 < i4; s4++) t4 % s4 === 0 && (e4.push(s4), e4.push(t4 / s4));
      return i4 === (0 | i4) && e4.push(i4), e4.sort((t5, e5) => t5 - e5).pop(), e4;
    }(s3);
    for (let t4 = 0, e4 = r3.length - 1; t4 < e4; t4++) {
      const e5 = r3[t4];
      if (e5 > n3) return e5;
    }
    return Math.max(n3, 1);
  }(r2, e2, n2);
  if (o2 > 0) {
    let t3, i3;
    const s3 = o2 > 1 ? Math.round((l2 - a2) / (o2 - 1)) : null;
    for (yc(e2, h2, c2, So(s3) ? 0 : a2 - s3, a2), t3 = 0, i3 = o2 - 1; t3 < i3; t3++) yc(e2, h2, c2, r2[t3], r2[t3 + 1]);
    return yc(e2, h2, c2, l2, So(s3) ? e2.length : l2 + s3), h2;
  }
  return yc(e2, h2, c2), h2;
}
function yc(t2, e2, i2, s2, n2) {
  const r2 = Ro(s2, 0), o2 = Math.min(Ro(n2, t2.length), t2.length);
  let a2, l2, h2, c2 = 0;
  for (i2 = Math.ceil(i2), n2 && (a2 = n2 - s2, i2 = a2 / Math.floor(a2 / i2)), h2 = r2; h2 < 0; ) c2++, h2 = Math.round(r2 + c2 * i2);
  for (l2 = Math.max(r2, 0); l2 < o2; l2++) l2 === h2 && (e2.push(t2[l2]), c2++, h2 = Math.round(r2 + c2 * i2));
}
const xc = (t2, e2, i2) => "top" === e2 || "left" === e2 ? t2[e2] + i2 : t2[e2] - i2, wc = (t2, e2) => Math.min(e2 || t2, t2);
function kc(t2, e2) {
  const i2 = [], s2 = t2.length / e2, n2 = t2.length;
  let r2 = 0;
  for (; r2 < n2; r2 += s2) i2.push(t2[Math.floor(r2)]);
  return i2;
}
function Mc(t2, e2, i2) {
  const s2 = t2.ticks.length, n2 = Math.min(e2, s2 - 1), r2 = t2._startPixel, o2 = t2._endPixel, a2 = 1e-6;
  let l2, h2 = t2.getPixelForTick(n2);
  if (!(i2 && (l2 = 1 === s2 ? Math.max(h2 - r2, o2 - h2) : 0 === e2 ? (t2.getPixelForTick(1) - h2) / 2 : (h2 - t2.getPixelForTick(n2 - 1)) / 2, h2 += n2 < e2 ? l2 : -l2, h2 < r2 - a2 || h2 > o2 + a2))) return h2;
}
function Sc(t2) {
  return t2.drawTicks ? t2.tickLength : 0;
}
function Cc(t2, e2) {
  if (!t2.display) return 0;
  const i2 = gl(t2.font, e2), s2 = ml(t2.padding);
  return (Co(t2.text) ? t2.text.length : 1) * i2.lineHeight + s2.height;
}
function zc(t2, e2, i2) {
  let s2 = Sa(t2);
  return (i2 && "right" !== e2 || !i2 && "right" === e2) && (s2 = /* @__PURE__ */ ((t3) => "left" === t3 ? "right" : "right" === t3 ? "left" : t3)(s2)), s2;
}
class Scale extends bc {
  constructor(t2) {
    super(), this.id = t2.id, this.type = t2.type, this.options = void 0, this.ctx = t2.ctx, this.chart = t2.chart, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this._margins = { left: 0, right: 0, top: 0, bottom: 0 }, this.maxWidth = void 0, this.maxHeight = void 0, this.paddingTop = void 0, this.paddingBottom = void 0, this.paddingLeft = void 0, this.paddingRight = void 0, this.axis = void 0, this.labelRotation = void 0, this.min = void 0, this.max = void 0, this._range = void 0, this.ticks = [], this._gridLineItems = null, this._labelItems = null, this._labelSizes = null, this._length = 0, this._maxLength = 0, this._longestTextCache = {}, this._startPixel = void 0, this._endPixel = void 0, this._reversePixels = false, this._userMax = void 0, this._userMin = void 0, this._suggestedMax = void 0, this._suggestedMin = void 0, this._ticksLength = 0, this._borderValue = 0, this._cache = {}, this._dataLimitsCached = false, this.$context = void 0;
  }
  init(t2) {
    this.options = t2.setContext(this.getContext()), this.axis = t2.axis, this._userMin = this.parse(t2.min), this._userMax = this.parse(t2.max), this._suggestedMin = this.parse(t2.suggestedMin), this._suggestedMax = this.parse(t2.suggestedMax);
  }
  parse(t2, e2) {
    return t2;
  }
  getUserBounds() {
    let { _userMin: t2, _userMax: e2, _suggestedMin: i2, _suggestedMax: s2 } = this;
    return t2 = Do(t2, Number.POSITIVE_INFINITY), e2 = Do(e2, Number.NEGATIVE_INFINITY), i2 = Do(i2, Number.POSITIVE_INFINITY), s2 = Do(s2, Number.NEGATIVE_INFINITY), { min: Do(t2, i2), max: Do(e2, s2), minDefined: $o(t2), maxDefined: $o(e2) };
  }
  getMinMax(t2) {
    let e2, { min: i2, max: s2, minDefined: n2, maxDefined: r2 } = this.getUserBounds();
    if (n2 && r2) return { min: i2, max: s2 };
    const o2 = this.getMatchingVisibleMetas();
    for (let a2 = 0, l2 = o2.length; a2 < l2; ++a2) e2 = o2[a2].controller.getMinMax(this, t2), n2 || (i2 = Math.min(i2, e2.min)), r2 || (s2 = Math.max(s2, e2.max));
    return i2 = r2 && i2 > s2 ? s2 : i2, s2 = n2 && i2 > s2 ? i2 : s2, { min: Do(i2, Do(s2, i2)), max: Do(s2, Do(i2, s2)) };
  }
  getPadding() {
    return { left: this.paddingLeft || 0, top: this.paddingTop || 0, right: this.paddingRight || 0, bottom: this.paddingBottom || 0 };
  }
  getTicks() {
    return this.ticks;
  }
  getLabels() {
    const t2 = this.chart.data;
    return this.options.labels || (this.isHorizontal() ? t2.xLabels : t2.yLabels) || t2.labels || [];
  }
  getLabelItems(t2 = this.chart.chartArea) {
    return this._labelItems || (this._labelItems = this._computeLabelItems(t2));
  }
  beforeLayout() {
    this._cache = {}, this._dataLimitsCached = false;
  }
  beforeUpdate() {
    Po(this.options.beforeUpdate, [this]);
  }
  update(t2, e2, i2) {
    const { beginAtZero: s2, grace: n2, ticks: r2 } = this.options, o2 = r2.sampleSize;
    this.beforeUpdate(), this.maxWidth = t2, this.maxHeight = e2, this._margins = i2 = Object.assign({ left: 0, right: 0, top: 0, bottom: 0 }, i2), this.ticks = null, this._labelSizes = null, this._gridLineItems = null, this._labelItems = null, this.beforeSetDimensions(), this.setDimensions(), this.afterSetDimensions(), this._maxLength = this.isHorizontal() ? this.width + i2.left + i2.right : this.height + i2.top + i2.bottom, this._dataLimitsCached || (this.beforeDataLimits(), this.determineDataLimits(), this.afterDataLimits(), this._range = function(t3, e3, i3) {
      const { min: s3, max: n3 } = t3, r3 = Eo(e3, (n3 - s3) / 2), o3 = (t4, e4) => i3 && 0 === t4 ? 0 : t4 + e4;
      return { min: o3(s3, -Math.abs(r3)), max: o3(n3, r3) };
    }(this, n2, s2), this._dataLimitsCached = true), this.beforeBuildTicks(), this.ticks = this.buildTicks() || [], this.afterBuildTicks();
    const a2 = o2 < this.ticks.length;
    this._convertTicksToLabels(a2 ? kc(this.ticks, o2) : this.ticks), this.configure(), this.beforeCalculateLabelRotation(), this.calculateLabelRotation(), this.afterCalculateLabelRotation(), r2.display && (r2.autoSkip || "auto" === r2.source) && (this.ticks = _c2(this, this.ticks), this._labelSizes = null, this.afterAutoSkip()), a2 && this._convertTicksToLabels(this.ticks), this.beforeFit(), this.fit(), this.afterFit(), this.afterUpdate();
  }
  configure() {
    let t2, e2, i2 = this.options.reverse;
    this.isHorizontal() ? (t2 = this.left, e2 = this.right) : (t2 = this.top, e2 = this.bottom, i2 = !i2), this._startPixel = t2, this._endPixel = e2, this._reversePixels = i2, this._length = e2 - t2, this._alignToPixels = this.options.alignToPixels;
  }
  afterUpdate() {
    Po(this.options.afterUpdate, [this]);
  }
  beforeSetDimensions() {
    Po(this.options.beforeSetDimensions, [this]);
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = 0, this.right = this.width) : (this.height = this.maxHeight, this.top = 0, this.bottom = this.height), this.paddingLeft = 0, this.paddingTop = 0, this.paddingRight = 0, this.paddingBottom = 0;
  }
  afterSetDimensions() {
    Po(this.options.afterSetDimensions, [this]);
  }
  _callHooks(t2) {
    this.chart.notifyPlugins(t2, this.getContext()), Po(this.options[t2], [this]);
  }
  beforeDataLimits() {
    this._callHooks("beforeDataLimits");
  }
  determineDataLimits() {
  }
  afterDataLimits() {
    this._callHooks("afterDataLimits");
  }
  beforeBuildTicks() {
    this._callHooks("beforeBuildTicks");
  }
  buildTicks() {
    return [];
  }
  afterBuildTicks() {
    this._callHooks("afterBuildTicks");
  }
  beforeTickToLabelConversion() {
    Po(this.options.beforeTickToLabelConversion, [this]);
  }
  generateTickLabels(t2) {
    const e2 = this.options.ticks;
    let i2, s2, n2;
    for (i2 = 0, s2 = t2.length; i2 < s2; i2++) n2 = t2[i2], n2.label = Po(e2.callback, [n2.value, i2, t2], this);
  }
  afterTickToLabelConversion() {
    Po(this.options.afterTickToLabelConversion, [this]);
  }
  beforeCalculateLabelRotation() {
    Po(this.options.beforeCalculateLabelRotation, [this]);
  }
  calculateLabelRotation() {
    const t2 = this.options, e2 = t2.ticks, i2 = wc(this.ticks.length, t2.ticks.maxTicksLimit), s2 = e2.minRotation || 0, n2 = e2.maxRotation;
    let r2, o2, a2, l2 = s2;
    if (!this._isVisible() || !e2.display || s2 >= n2 || i2 <= 1 || !this.isHorizontal()) return void (this.labelRotation = s2);
    const h2 = this._getLabelSizes(), c2 = h2.widest.width, u2 = h2.highest.height, d2 = ma(this.chart.width - c2, 0, this.maxWidth);
    r2 = t2.offset ? this.maxWidth / i2 : d2 / (i2 - 1), c2 + 6 > r2 && (r2 = d2 / (i2 - (t2.offset ? 0.5 : 1)), o2 = this.maxHeight - Sc(t2.grid) - e2.padding - Cc(t2.title, this.chart.options.font), a2 = Math.sqrt(c2 * c2 + u2 * u2), l2 = la(Math.min(Math.asin(ma((h2.highest.height + 6) / r2, -1, 1)), Math.asin(ma(o2 / a2, -1, 1)) - Math.asin(ma(u2 / a2, -1, 1)))), l2 = Math.max(s2, Math.min(n2, l2))), this.labelRotation = l2;
  }
  afterCalculateLabelRotation() {
    Po(this.options.afterCalculateLabelRotation, [this]);
  }
  afterAutoSkip() {
  }
  beforeFit() {
    Po(this.options.beforeFit, [this]);
  }
  fit() {
    const t2 = { width: 0, height: 0 }, { chart: e2, options: { ticks: i2, title: s2, grid: n2 } } = this, r2 = this._isVisible(), o2 = this.isHorizontal();
    if (r2) {
      const r3 = Cc(s2, e2.options.font);
      if (o2 ? (t2.width = this.maxWidth, t2.height = Sc(n2) + r3) : (t2.height = this.maxHeight, t2.width = Sc(n2) + r3), i2.display && this.ticks.length) {
        const { first: e3, last: s3, widest: n3, highest: r4 } = this._getLabelSizes(), a2 = 2 * i2.padding, l2 = aa(this.labelRotation), h2 = Math.cos(l2), c2 = Math.sin(l2);
        if (o2) {
          const e4 = i2.mirror ? 0 : c2 * n3.width + h2 * r4.height;
          t2.height = Math.min(this.maxHeight, t2.height + e4 + a2);
        } else {
          const e4 = i2.mirror ? 0 : h2 * n3.width + c2 * r4.height;
          t2.width = Math.min(this.maxWidth, t2.width + e4 + a2);
        }
        this._calculatePadding(e3, s3, c2, h2);
      }
    }
    this._handleMargins(), o2 ? (this.width = this._length = e2.width - this._margins.left - this._margins.right, this.height = t2.height) : (this.width = t2.width, this.height = this._length = e2.height - this._margins.top - this._margins.bottom);
  }
  _calculatePadding(t2, e2, i2, s2) {
    const { ticks: { align: n2, padding: r2 }, position: o2 } = this.options, a2 = 0 !== this.labelRotation, l2 = "top" !== o2 && "x" === this.axis;
    if (this.isHorizontal()) {
      const o3 = this.getPixelForTick(0) - this.left, h2 = this.right - this.getPixelForTick(this.ticks.length - 1);
      let c2 = 0, u2 = 0;
      a2 ? l2 ? (c2 = s2 * t2.width, u2 = i2 * e2.height) : (c2 = i2 * t2.height, u2 = s2 * e2.width) : "start" === n2 ? u2 = e2.width : "end" === n2 ? c2 = t2.width : "inner" !== n2 && (c2 = t2.width / 2, u2 = e2.width / 2), this.paddingLeft = Math.max((c2 - o3 + r2) * this.width / (this.width - o3), 0), this.paddingRight = Math.max((u2 - h2 + r2) * this.width / (this.width - h2), 0);
    } else {
      let i3 = e2.height / 2, s3 = t2.height / 2;
      "start" === n2 ? (i3 = 0, s3 = t2.height) : "end" === n2 && (i3 = e2.height, s3 = 0), this.paddingTop = i3 + r2, this.paddingBottom = s3 + r2;
    }
  }
  _handleMargins() {
    this._margins && (this._margins.left = Math.max(this.paddingLeft, this._margins.left), this._margins.top = Math.max(this.paddingTop, this._margins.top), this._margins.right = Math.max(this.paddingRight, this._margins.right), this._margins.bottom = Math.max(this.paddingBottom, this._margins.bottom));
  }
  afterFit() {
    Po(this.options.afterFit, [this]);
  }
  isHorizontal() {
    const { axis: t2, position: e2 } = this.options;
    return "top" === e2 || "bottom" === e2 || "x" === t2;
  }
  isFullSize() {
    return this.options.fullSize;
  }
  _convertTicksToLabels(t2) {
    let e2, i2;
    for (this.beforeTickToLabelConversion(), this.generateTickLabels(t2), e2 = 0, i2 = t2.length; e2 < i2; e2++) So(t2[e2].label) && (t2.splice(e2, 1), i2--, e2--);
    this.afterTickToLabelConversion();
  }
  _getLabelSizes() {
    let t2 = this._labelSizes;
    if (!t2) {
      const e2 = this.options.ticks.sampleSize;
      let i2 = this.ticks;
      e2 < i2.length && (i2 = kc(i2, e2)), this._labelSizes = t2 = this._computeLabelSizes(i2, i2.length, this.options.ticks.maxTicksLimit);
    }
    return t2;
  }
  _computeLabelSizes(t2, e2, i2) {
    const { ctx: s2, _longestTextCache: n2 } = this, r2 = [], o2 = [], a2 = Math.floor(e2 / wc(e2, i2));
    let l2, h2, c2, u2, d2, f2, p2, m2, g2, v2, b2, _2 = 0, y2 = 0;
    for (l2 = 0; l2 < e2; l2 += a2) {
      if (u2 = t2[l2].label, d2 = this._resolveTickFontOptions(l2), s2.font = f2 = d2.string, p2 = n2[f2] = n2[f2] || { data: {}, gc: [] }, m2 = d2.lineHeight, g2 = v2 = 0, So(u2) || Co(u2)) {
        if (Co(u2)) for (h2 = 0, c2 = u2.length; h2 < c2; ++h2) b2 = u2[h2], So(b2) || Co(b2) || (g2 = Ka(s2, p2.data, p2.gc, g2, b2), v2 += m2);
      } else g2 = Ka(s2, p2.data, p2.gc, g2, u2), v2 = m2;
      r2.push(g2), o2.push(v2), _2 = Math.max(g2, _2), y2 = Math.max(v2, y2);
    }
    !function(t3, e3) {
      To(t3, (t4) => {
        const i3 = t4.gc, s3 = i3.length / 2;
        let n3;
        if (s3 > e3) {
          for (n3 = 0; n3 < s3; ++n3) delete t4.data[i3[n3]];
          i3.splice(0, s3);
        }
      });
    }(n2, e2);
    const x2 = r2.indexOf(_2), w2 = o2.indexOf(y2), k2 = (t3) => ({ width: r2[t3] || 0, height: o2[t3] || 0 });
    return { first: k2(0), last: k2(e2 - 1), widest: k2(x2), highest: k2(w2), widths: r2, heights: o2 };
  }
  getLabelForValue(t2) {
    return t2;
  }
  getPixelForValue(t2, e2) {
    return NaN;
  }
  getValueForPixel(t2) {
  }
  getPixelForTick(t2) {
    const e2 = this.ticks;
    return t2 < 0 || t2 > e2.length - 1 ? null : this.getPixelForValue(e2[t2].value);
  }
  getPixelForDecimal(t2) {
    this._reversePixels && (t2 = 1 - t2);
    const e2 = this._startPixel + t2 * this._length;
    return ma(this._alignToPixels ? Ya(this.chart, e2, 0) : e2, -32768, 32767);
  }
  getDecimalForPixel(t2) {
    const e2 = (t2 - this._startPixel) / this._length;
    return this._reversePixels ? 1 - e2 : e2;
  }
  getBasePixel() {
    return this.getPixelForValue(this.getBaseValue());
  }
  getBaseValue() {
    const { min: t2, max: e2 } = this;
    return t2 < 0 && e2 < 0 ? e2 : t2 > 0 && e2 > 0 ? t2 : 0;
  }
  getContext(t2) {
    const e2 = this.ticks || [];
    if (t2 >= 0 && t2 < e2.length) {
      const i2 = e2[t2];
      return i2.$context || (i2.$context = function(t3, e3, i3) {
        return bl(t3, { tick: i3, index: e3, type: "tick" });
      }(this.getContext(), t2, i2));
    }
    return this.$context || (this.$context = bl(this.chart.getContext(), { scale: this, type: "scale" }));
  }
  _tickSize() {
    const t2 = this.options.ticks, e2 = aa(this.labelRotation), i2 = Math.abs(Math.cos(e2)), s2 = Math.abs(Math.sin(e2)), n2 = this._getLabelSizes(), r2 = t2.autoSkipPadding || 0, o2 = n2 ? n2.widest.width + r2 : 0, a2 = n2 ? n2.highest.height + r2 : 0;
    return this.isHorizontal() ? a2 * i2 > o2 * s2 ? o2 / i2 : a2 / s2 : a2 * s2 < o2 * i2 ? a2 / i2 : o2 / s2;
  }
  _isVisible() {
    const t2 = this.options.display;
    return "auto" !== t2 ? !!t2 : this.getMatchingVisibleMetas().length > 0;
  }
  _computeGridLineItems(t2) {
    const e2 = this.axis, i2 = this.chart, s2 = this.options, { grid: n2, position: r2, border: o2 } = s2, a2 = n2.offset, l2 = this.isHorizontal(), h2 = this.ticks.length + (a2 ? 1 : 0), c2 = Sc(n2), u2 = [], d2 = o2.setContext(this.getContext()), f2 = d2.display ? d2.width : 0, p2 = f2 / 2, m2 = function(t3) {
      return Ya(i2, t3, f2);
    };
    let g2, v2, b2, _2, y2, x2, w2, k2, M2, S2, C2, z2;
    if ("top" === r2) g2 = m2(this.bottom), x2 = this.bottom - c2, k2 = g2 - p2, S2 = m2(t2.top) + p2, z2 = t2.bottom;
    else if ("bottom" === r2) g2 = m2(this.top), S2 = t2.top, z2 = m2(t2.bottom) - p2, x2 = g2 + p2, k2 = this.top + c2;
    else if ("left" === r2) g2 = m2(this.right), y2 = this.right - c2, w2 = g2 - p2, M2 = m2(t2.left) + p2, C2 = t2.right;
    else if ("right" === r2) g2 = m2(this.left), M2 = t2.left, C2 = m2(t2.right) - p2, y2 = g2 + p2, w2 = this.left + c2;
    else if ("x" === e2) {
      if ("center" === r2) g2 = m2((t2.top + t2.bottom) / 2 + 0.5);
      else if (zo(r2)) {
        const t3 = Object.keys(r2)[0], e3 = r2[t3];
        g2 = m2(this.chart.scales[t3].getPixelForValue(e3));
      }
      S2 = t2.top, z2 = t2.bottom, x2 = g2 + p2, k2 = x2 + c2;
    } else if ("y" === e2) {
      if ("center" === r2) g2 = m2((t2.left + t2.right) / 2);
      else if (zo(r2)) {
        const t3 = Object.keys(r2)[0], e3 = r2[t3];
        g2 = m2(this.chart.scales[t3].getPixelForValue(e3));
      }
      y2 = g2 - p2, w2 = y2 - c2, M2 = t2.left, C2 = t2.right;
    }
    const R2 = Ro(s2.ticks.maxTicksLimit, h2), E2 = Math.max(1, Math.ceil(h2 / R2));
    for (v2 = 0; v2 < h2; v2 += E2) {
      const t3 = this.getContext(v2), e3 = n2.setContext(t3), s3 = o2.setContext(t3), r3 = e3.lineWidth, h3 = e3.color, c3 = s3.dash || [], d3 = s3.dashOffset, f3 = e3.tickWidth, p3 = e3.tickColor, m3 = e3.tickBorderDash || [], g3 = e3.tickBorderDashOffset;
      b2 = Mc(this, v2, a2), void 0 !== b2 && (_2 = Ya(i2, b2, r3), l2 ? y2 = w2 = M2 = C2 = _2 : x2 = k2 = S2 = z2 = _2, u2.push({ tx1: y2, ty1: x2, tx2: w2, ty2: k2, x1: M2, y1: S2, x2: C2, y2: z2, width: r3, color: h3, borderDash: c3, borderDashOffset: d3, tickWidth: f3, tickColor: p3, tickBorderDash: m3, tickBorderDashOffset: g3 }));
    }
    return this._ticksLength = h2, this._borderValue = g2, u2;
  }
  _computeLabelItems(t2) {
    const e2 = this.axis, i2 = this.options, { position: s2, ticks: n2 } = i2, r2 = this.isHorizontal(), o2 = this.ticks, { align: a2, crossAlign: l2, padding: h2, mirror: c2 } = n2, u2 = Sc(i2.grid), d2 = u2 + h2, f2 = c2 ? -h2 : d2, p2 = -aa(this.labelRotation), m2 = [];
    let g2, v2, b2, _2, y2, x2, w2, k2, M2, S2, C2, z2, R2 = "middle";
    if ("top" === s2) x2 = this.bottom - f2, w2 = this._getXAxisLabelAlignment();
    else if ("bottom" === s2) x2 = this.top + f2, w2 = this._getXAxisLabelAlignment();
    else if ("left" === s2) {
      const t3 = this._getYAxisLabelAlignment(u2);
      w2 = t3.textAlign, y2 = t3.x;
    } else if ("right" === s2) {
      const t3 = this._getYAxisLabelAlignment(u2);
      w2 = t3.textAlign, y2 = t3.x;
    } else if ("x" === e2) {
      if ("center" === s2) x2 = (t2.top + t2.bottom) / 2 + d2;
      else if (zo(s2)) {
        const t3 = Object.keys(s2)[0], e3 = s2[t3];
        x2 = this.chart.scales[t3].getPixelForValue(e3) + d2;
      }
      w2 = this._getXAxisLabelAlignment();
    } else if ("y" === e2) {
      if ("center" === s2) y2 = (t2.left + t2.right) / 2 - d2;
      else if (zo(s2)) {
        const t3 = Object.keys(s2)[0], e3 = s2[t3];
        y2 = this.chart.scales[t3].getPixelForValue(e3);
      }
      w2 = this._getYAxisLabelAlignment(u2).textAlign;
    }
    "y" === e2 && ("start" === a2 ? R2 = "top" : "end" === a2 && (R2 = "bottom"));
    const E2 = this._getLabelSizes();
    for (g2 = 0, v2 = o2.length; g2 < v2; ++g2) {
      b2 = o2[g2], _2 = b2.label;
      const t3 = n2.setContext(this.getContext(g2));
      k2 = this.getPixelForTick(g2) + n2.labelOffset, M2 = this._resolveTickFontOptions(g2), S2 = M2.lineHeight, C2 = Co(_2) ? _2.length : 1;
      const e3 = C2 / 2, i3 = t3.color, a3 = t3.textStrokeColor, h3 = t3.textStrokeWidth;
      let u3, d3 = w2;
      if (r2 ? (y2 = k2, "inner" === w2 && (d3 = g2 === v2 - 1 ? this.options.reverse ? "left" : "right" : 0 === g2 ? this.options.reverse ? "right" : "left" : "center"), z2 = "top" === s2 ? "near" === l2 || 0 !== p2 ? -C2 * S2 + S2 / 2 : "center" === l2 ? -E2.highest.height / 2 - e3 * S2 + S2 : -E2.highest.height + S2 / 2 : "near" === l2 || 0 !== p2 ? S2 / 2 : "center" === l2 ? E2.highest.height / 2 - e3 * S2 : E2.highest.height - C2 * S2, c2 && (z2 *= -1), 0 === p2 || t3.showLabelBackdrop || (y2 += S2 / 2 * Math.sin(p2))) : (x2 = k2, z2 = (1 - C2) * S2 / 2), t3.showLabelBackdrop) {
        const e4 = ml(t3.backdropPadding), i4 = E2.heights[g2], s3 = E2.widths[g2];
        let n3 = z2 - e4.top, r3 = 0 - e4.left;
        switch (R2) {
          case "middle":
            n3 -= i4 / 2;
            break;
          case "bottom":
            n3 -= i4;
        }
        switch (w2) {
          case "center":
            r3 -= s3 / 2;
            break;
          case "right":
            r3 -= s3;
            break;
          case "inner":
            g2 === v2 - 1 ? r3 -= s3 : g2 > 0 && (r3 -= s3 / 2);
        }
        u3 = { left: r3, top: n3, width: s3 + e4.width, height: i4 + e4.height, color: t3.backdropColor };
      }
      m2.push({ label: _2, font: M2, textOffset: z2, options: { rotation: p2, color: i3, strokeColor: a3, strokeWidth: h3, textAlign: d3, textBaseline: R2, translation: [y2, x2], backdrop: u3 } });
    }
    return m2;
  }
  _getXAxisLabelAlignment() {
    const { position: t2, ticks: e2 } = this.options;
    if (-aa(this.labelRotation)) return "top" === t2 ? "left" : "right";
    let i2 = "center";
    return "start" === e2.align ? i2 = "left" : "end" === e2.align ? i2 = "right" : "inner" === e2.align && (i2 = "inner"), i2;
  }
  _getYAxisLabelAlignment(t2) {
    const { position: e2, ticks: { crossAlign: i2, mirror: s2, padding: n2 } } = this.options, r2 = t2 + n2, o2 = this._getLabelSizes().widest.width;
    let a2, l2;
    return "left" === e2 ? s2 ? (l2 = this.right + n2, "near" === i2 ? a2 = "left" : "center" === i2 ? (a2 = "center", l2 += o2 / 2) : (a2 = "right", l2 += o2)) : (l2 = this.right - r2, "near" === i2 ? a2 = "right" : "center" === i2 ? (a2 = "center", l2 -= o2 / 2) : (a2 = "left", l2 = this.left)) : "right" === e2 ? s2 ? (l2 = this.left + n2, "near" === i2 ? a2 = "right" : "center" === i2 ? (a2 = "center", l2 -= o2 / 2) : (a2 = "left", l2 -= o2)) : (l2 = this.left + r2, "near" === i2 ? a2 = "left" : "center" === i2 ? (a2 = "center", l2 += o2 / 2) : (a2 = "right", l2 = this.right)) : a2 = "right", { textAlign: a2, x: l2 };
  }
  _computeLabelArea() {
    if (this.options.ticks.mirror) return;
    const t2 = this.chart, e2 = this.options.position;
    return "left" === e2 || "right" === e2 ? { top: 0, left: this.left, bottom: t2.height, right: this.right } : "top" === e2 || "bottom" === e2 ? { top: this.top, left: 0, bottom: this.bottom, right: t2.width } : void 0;
  }
  drawBackground() {
    const { ctx: t2, options: { backgroundColor: e2 }, left: i2, top: s2, width: n2, height: r2 } = this;
    e2 && (t2.save(), t2.fillStyle = e2, t2.fillRect(i2, s2, n2, r2), t2.restore());
  }
  getLineWidthForValue(t2) {
    const e2 = this.options.grid;
    if (!this._isVisible() || !e2.display) return 0;
    const i2 = this.ticks.findIndex((e3) => e3.value === t2);
    if (i2 >= 0) {
      return e2.setContext(this.getContext(i2)).lineWidth;
    }
    return 0;
  }
  drawGrid(t2) {
    const e2 = this.options.grid, i2 = this.ctx, s2 = this._gridLineItems || (this._gridLineItems = this._computeGridLineItems(t2));
    let n2, r2;
    const o2 = (t3, e3, s3) => {
      s3.width && s3.color && (i2.save(), i2.lineWidth = s3.width, i2.strokeStyle = s3.color, i2.setLineDash(s3.borderDash || []), i2.lineDashOffset = s3.borderDashOffset, i2.beginPath(), i2.moveTo(t3.x, t3.y), i2.lineTo(e3.x, e3.y), i2.stroke(), i2.restore());
    };
    if (e2.display) for (n2 = 0, r2 = s2.length; n2 < r2; ++n2) {
      const t3 = s2[n2];
      e2.drawOnChartArea && o2({ x: t3.x1, y: t3.y1 }, { x: t3.x2, y: t3.y2 }, t3), e2.drawTicks && o2({ x: t3.tx1, y: t3.ty1 }, { x: t3.tx2, y: t3.ty2 }, { color: t3.tickColor, width: t3.tickWidth, borderDash: t3.tickBorderDash, borderDashOffset: t3.tickBorderDashOffset });
    }
  }
  drawBorder() {
    const { chart: t2, ctx: e2, options: { border: i2, grid: s2 } } = this, n2 = i2.setContext(this.getContext()), r2 = i2.display ? n2.width : 0;
    if (!r2) return;
    const o2 = s2.setContext(this.getContext(0)).lineWidth, a2 = this._borderValue;
    let l2, h2, c2, u2;
    this.isHorizontal() ? (l2 = Ya(t2, this.left, r2) - r2 / 2, h2 = Ya(t2, this.right, o2) + o2 / 2, c2 = u2 = a2) : (c2 = Ya(t2, this.top, r2) - r2 / 2, u2 = Ya(t2, this.bottom, o2) + o2 / 2, l2 = h2 = a2), e2.save(), e2.lineWidth = n2.width, e2.strokeStyle = n2.color, e2.beginPath(), e2.moveTo(l2, c2), e2.lineTo(h2, u2), e2.stroke(), e2.restore();
  }
  drawLabels(t2) {
    if (!this.options.ticks.display) return;
    const e2 = this.ctx, i2 = this._computeLabelArea();
    i2 && tl(e2, i2);
    const s2 = this.getLabelItems(t2);
    for (const t3 of s2) {
      const i3 = t3.options, s3 = t3.font;
      ol(e2, t3.label, 0, t3.textOffset, s3, i3);
    }
    i2 && el(e2);
  }
  drawTitle() {
    const { ctx: t2, options: { position: e2, title: i2, reverse: s2 } } = this;
    if (!i2.display) return;
    const n2 = gl(i2.font), r2 = ml(i2.padding), o2 = i2.align;
    let a2 = n2.lineHeight / 2;
    "bottom" === e2 || "center" === e2 || zo(e2) ? (a2 += r2.bottom, Co(i2.text) && (a2 += n2.lineHeight * (i2.text.length - 1))) : a2 += r2.top;
    const { titleX: l2, titleY: h2, maxWidth: c2, rotation: u2 } = function(t3, e3, i3, s3) {
      const { top: n3, left: r3, bottom: o3, right: a3, chart: l3 } = t3, { chartArea: h3, scales: c3 } = l3;
      let u3, d2, f2, p2 = 0;
      const m2 = o3 - n3, g2 = a3 - r3;
      if (t3.isHorizontal()) {
        if (d2 = Ca(s3, r3, a3), zo(i3)) {
          const t4 = Object.keys(i3)[0], s4 = i3[t4];
          f2 = c3[t4].getPixelForValue(s4) + m2 - e3;
        } else f2 = "center" === i3 ? (h3.bottom + h3.top) / 2 + m2 - e3 : xc(t3, i3, e3);
        u3 = a3 - r3;
      } else {
        if (zo(i3)) {
          const t4 = Object.keys(i3)[0], s4 = i3[t4];
          d2 = c3[t4].getPixelForValue(s4) - g2 + e3;
        } else d2 = "center" === i3 ? (h3.left + h3.right) / 2 - g2 + e3 : xc(t3, i3, e3);
        f2 = Ca(s3, o3, n3), p2 = "left" === i3 ? -Qo : Qo;
      }
      return { titleX: d2, titleY: f2, maxWidth: u3, rotation: p2 };
    }(this, a2, e2, o2);
    ol(t2, i2.text, 0, 0, n2, { color: i2.color, maxWidth: c2, rotation: u2, textAlign: zc(o2, e2, s2), textBaseline: "middle", translation: [l2, h2] });
  }
  draw(t2) {
    this._isVisible() && (this.drawBackground(), this.drawGrid(t2), this.drawBorder(), this.drawTitle(), this.drawLabels(t2));
  }
  _layers() {
    const t2 = this.options, e2 = t2.ticks && t2.ticks.z || 0, i2 = Ro(t2.grid && t2.grid.z, -1), s2 = Ro(t2.border && t2.border.z, 0);
    return this._isVisible() && this.draw === Scale.prototype.draw ? [{ z: i2, draw: (t3) => {
      this.drawBackground(), this.drawGrid(t3), this.drawTitle();
    } }, { z: s2, draw: () => {
      this.drawBorder();
    } }, { z: e2, draw: (t3) => {
      this.drawLabels(t3);
    } }] : [{ z: e2, draw: (t3) => {
      this.draw(t3);
    } }];
  }
  getMatchingVisibleMetas(t2) {
    const e2 = this.chart.getSortedVisibleDatasetMetas(), i2 = this.axis + "AxisID", s2 = [];
    let n2, r2;
    for (n2 = 0, r2 = e2.length; n2 < r2; ++n2) {
      const r3 = e2[n2];
      r3[i2] !== this.id || t2 && r3.type !== t2 || s2.push(r3);
    }
    return s2;
  }
  _resolveTickFontOptions(t2) {
    return gl(this.options.ticks.setContext(this.getContext(t2)).font);
  }
  _maxDigits() {
    const t2 = this._resolveTickFontOptions(0).lineHeight;
    return (this.isHorizontal() ? this.width : this.height) / t2;
  }
}
class TypedRegistry {
  constructor(t2, e2, i2) {
    this.type = t2, this.scope = e2, this.override = i2, this.items = /* @__PURE__ */ Object.create(null);
  }
  isForType(t2) {
    return Object.prototype.isPrototypeOf.call(this.type.prototype, t2.prototype);
  }
  register(t2) {
    const e2 = Object.getPrototypeOf(t2);
    let i2;
    (function(t3) {
      return "id" in t3 && "defaults" in t3;
    })(e2) && (i2 = this.register(e2));
    const s2 = this.items, n2 = t2.id, r2 = this.scope + "." + n2;
    if (!n2) throw new Error("class does not have id: " + t2);
    return n2 in s2 || (s2[n2] = t2, function(t3, e3, i3) {
      const s3 = Fo(/* @__PURE__ */ Object.create(null), [i3 ? Xa.get(i3) : {}, Xa.get(e3), t3.defaults]);
      Xa.set(e3, s3), t3.defaultRoutes && function(t4, e4) {
        Object.keys(e4).forEach((i4) => {
          const s4 = i4.split("."), n3 = s4.pop(), r3 = [t4].concat(s4).join("."), o2 = e4[i4].split("."), a2 = o2.pop(), l2 = o2.join(".");
          Xa.route(r3, n3, l2, a2);
        });
      }(e3, t3.defaultRoutes);
      t3.descriptors && Xa.describe(e3, t3.descriptors);
    }(t2, r2, i2), this.override && Xa.override(t2.id, t2.overrides)), r2;
  }
  get(t2) {
    return this.items[t2];
  }
  unregister(t2) {
    const e2 = this.items, i2 = t2.id, s2 = this.scope;
    i2 in e2 && delete e2[i2], s2 && i2 in Xa[s2] && (delete Xa[s2][i2], this.override && delete Ba[i2]);
  }
}
class Registry {
  constructor() {
    this.controllers = new TypedRegistry(DatasetController, "datasets", true), this.elements = new TypedRegistry(bc, "elements"), this.plugins = new TypedRegistry(Object, "plugins"), this.scales = new TypedRegistry(Scale, "scales"), this._typedRegistries = [this.controllers, this.scales, this.elements];
  }
  add(...t2) {
    this._each("register", t2);
  }
  remove(...t2) {
    this._each("unregister", t2);
  }
  addControllers(...t2) {
    this._each("register", t2, this.controllers);
  }
  addElements(...t2) {
    this._each("register", t2, this.elements);
  }
  addPlugins(...t2) {
    this._each("register", t2, this.plugins);
  }
  addScales(...t2) {
    this._each("register", t2, this.scales);
  }
  getController(t2) {
    return this._get(t2, this.controllers, "controller");
  }
  getElement(t2) {
    return this._get(t2, this.elements, "element");
  }
  getPlugin(t2) {
    return this._get(t2, this.plugins, "plugin");
  }
  getScale(t2) {
    return this._get(t2, this.scales, "scale");
  }
  removeControllers(...t2) {
    this._each("unregister", t2, this.controllers);
  }
  removeElements(...t2) {
    this._each("unregister", t2, this.elements);
  }
  removePlugins(...t2) {
    this._each("unregister", t2, this.plugins);
  }
  removeScales(...t2) {
    this._each("unregister", t2, this.scales);
  }
  _each(t2, e2, i2) {
    [...e2].forEach((e3) => {
      const s2 = i2 || this._getRegistryForType(e3);
      i2 || s2.isForType(e3) || s2 === this.plugins && e3.id ? this._exec(t2, s2, e3) : To(e3, (e4) => {
        const s3 = i2 || this._getRegistryForType(e4);
        this._exec(t2, s3, e4);
      });
    });
  }
  _exec(t2, e2, i2) {
    const s2 = jo(t2);
    Po(i2["before" + s2], [], i2), e2[t2](i2), Po(i2["after" + s2], [], i2);
  }
  _getRegistryForType(t2) {
    for (let e2 = 0; e2 < this._typedRegistries.length; e2++) {
      const i2 = this._typedRegistries[e2];
      if (i2.isForType(t2)) return i2;
    }
    return this.plugins;
  }
  _get(t2, e2, i2) {
    const s2 = e2.get(t2);
    if (void 0 === s2) throw new Error('"' + t2 + '" is not a registered ' + i2 + ".");
    return s2;
  }
}
var $c = new Registry();
class PluginService {
  constructor() {
    this._init = [];
  }
  notify(t2, e2, i2, s2) {
    "beforeInit" === e2 && (this._init = this._createDescriptors(t2, true), this._notify(this._init, t2, "install"));
    const n2 = s2 ? this._descriptors(t2).filter(s2) : this._descriptors(t2), r2 = this._notify(n2, t2, e2, i2);
    return "afterDestroy" === e2 && (this._notify(n2, t2, "stop"), this._notify(this._init, t2, "uninstall")), r2;
  }
  _notify(t2, e2, i2, s2) {
    s2 = s2 || {};
    for (const n2 of t2) {
      const t3 = n2.plugin;
      if (false === Po(t3[i2], [e2, s2, n2.options], t3) && s2.cancelable) return false;
    }
    return true;
  }
  invalidate() {
    So(this._cache) || (this._oldCache = this._cache, this._cache = void 0);
  }
  _descriptors(t2) {
    if (this._cache) return this._cache;
    const e2 = this._cache = this._createDescriptors(t2);
    return this._notifyStateChanges(t2), e2;
  }
  _createDescriptors(t2, e2) {
    const i2 = t2 && t2.config, s2 = Ro(i2.options && i2.options.plugins, {}), n2 = function(t3) {
      const e3 = {}, i3 = [], s3 = Object.keys($c.plugins.items);
      for (let t4 = 0; t4 < s3.length; t4++) i3.push($c.getPlugin(s3[t4]));
      const n3 = t3.plugins || [];
      for (let t4 = 0; t4 < n3.length; t4++) {
        const s4 = n3[t4];
        -1 === i3.indexOf(s4) && (i3.push(s4), e3[s4.id] = true);
      }
      return { plugins: i3, localIds: e3 };
    }(i2);
    return false !== s2 || e2 ? function(t3, { plugins: e3, localIds: i3 }, s3, n3) {
      const r2 = [], o2 = t3.getContext();
      for (const a2 of e3) {
        const e4 = a2.id, l2 = Dc(s3[e4], n3);
        null !== l2 && r2.push({ plugin: a2, options: Rc(t3.config, { plugin: a2, local: i3[e4] }, l2, o2) });
      }
      return r2;
    }(t2, n2, s2, e2) : [];
  }
  _notifyStateChanges(t2) {
    const e2 = this._oldCache || [], i2 = this._cache, s2 = (t3, e3) => t3.filter((t4) => !e3.some((e4) => t4.plugin.id === e4.plugin.id));
    this._notify(s2(e2, i2), t2, "stop"), this._notify(s2(i2, e2), t2, "start");
  }
}
function Dc(t2, e2) {
  return e2 || false !== t2 ? true === t2 ? {} : t2 : null;
}
function Rc(t2, { plugin: e2, local: i2 }, s2, n2) {
  const r2 = t2.pluginScopeKeys(e2), o2 = t2.getOptionScopes(s2, r2);
  return i2 && e2.defaults && o2.push(e2.defaults), t2.createResolver(o2, n2, [""], { scriptable: false, indexable: false, allKeys: true });
}
function Ec(t2, e2) {
  const i2 = Xa.datasets[t2] || {};
  return ((e2.datasets || {})[t2] || {}).indexAxis || e2.indexAxis || i2.indexAxis || "x";
}
function Pc(t2) {
  if ("x" === t2 || "y" === t2 || "r" === t2) return t2;
}
function Tc(t2, ...e2) {
  if (Pc(t2)) return t2;
  for (const s2 of e2) {
    const e3 = s2.axis || ("top" === (i2 = s2.position) || "bottom" === i2 ? "x" : "left" === i2 || "right" === i2 ? "y" : void 0) || t2.length > 1 && Pc(t2[0].toLowerCase());
    if (e3) return e3;
  }
  var i2;
  throw new Error(`Cannot determine type of '${t2}' axis. Please provide 'axis' or 'position' option.`);
}
function Lc(t2, e2, i2) {
  if (i2[e2 + "AxisID"] === t2) return { axis: e2 };
}
function Vc(t2, e2) {
  const i2 = Ba[t2.type] || { scales: {} }, s2 = e2.scales || {}, n2 = Ec(t2.type, e2), r2 = /* @__PURE__ */ Object.create(null);
  return Object.keys(s2).forEach((e3) => {
    const o2 = s2[e3];
    if (!zo(o2)) return console.error(`Invalid scale configuration for scale: ${e3}`);
    if (o2._proxy) return console.warn(`Ignoring resolver passed as options for scale: ${e3}`);
    const a2 = Tc(e3, o2, function(t3, e4) {
      if (e4.data && e4.data.datasets) {
        const i3 = e4.data.datasets.filter((e5) => e5.xAxisID === t3 || e5.yAxisID === t3);
        if (i3.length) return Lc(t3, "x", i3[0]) || Lc(t3, "y", i3[0]);
      }
      return {};
    }(e3, t2), Xa.scales[o2.type]), l2 = /* @__PURE__ */ function(t3, e4) {
      return t3 === e4 ? "_index_" : "_value_";
    }(a2, n2), h2 = i2.scales || {};
    r2[e3] = No(/* @__PURE__ */ Object.create(null), [{ axis: a2 }, o2, h2[a2], h2[l2]]);
  }), t2.data.datasets.forEach((i3) => {
    const n3 = i3.type || t2.type, o2 = i3.indexAxis || Ec(n3, e2), a2 = (Ba[n3] || {}).scales || {};
    Object.keys(a2).forEach((t3) => {
      const e3 = function(t4, e4) {
        let i4 = t4;
        return "_index_" === t4 ? i4 = e4 : "_value_" === t4 && (i4 = "x" === e4 ? "y" : "x"), i4;
      }(t3, o2), n4 = i3[e3 + "AxisID"] || e3;
      r2[n4] = r2[n4] || /* @__PURE__ */ Object.create(null), No(r2[n4], [{ axis: e3 }, s2[n4], a2[t3]]);
    });
  }), Object.keys(r2).forEach((t3) => {
    const e3 = r2[t3];
    No(e3, [Xa.scales[e3.type], Xa.scale]);
  }), r2;
}
function Oc(t2) {
  const e2 = t2.options || (t2.options = {});
  e2.plugins = Ro(e2.plugins, {}), e2.scales = Vc(t2, e2);
}
function Ac(t2) {
  return (t2 = t2 || {}).datasets = t2.datasets || [], t2.labels = t2.labels || [], t2;
}
const Fc = /* @__PURE__ */ new Map(), Nc = /* @__PURE__ */ new Set();
function Wc(t2, e2) {
  let i2 = Fc.get(t2);
  return i2 || (i2 = e2(), Fc.set(t2, i2), Nc.add(i2)), i2;
}
const Ic = (t2, e2, i2) => {
  const s2 = Bo(e2, i2);
  void 0 !== s2 && t2.add(s2);
};
class Config {
  constructor(t2) {
    this._config = function(t3) {
      return (t3 = t3 || {}).data = Ac(t3.data), Oc(t3), t3;
    }(t2), this._scopeCache = /* @__PURE__ */ new Map(), this._resolverCache = /* @__PURE__ */ new Map();
  }
  get platform() {
    return this._config.platform;
  }
  get type() {
    return this._config.type;
  }
  set type(t2) {
    this._config.type = t2;
  }
  get data() {
    return this._config.data;
  }
  set data(t2) {
    this._config.data = Ac(t2);
  }
  get options() {
    return this._config.options;
  }
  set options(t2) {
    this._config.options = t2;
  }
  get plugins() {
    return this._config.plugins;
  }
  update() {
    const t2 = this._config;
    this.clearCache(), Oc(t2);
  }
  clearCache() {
    this._scopeCache.clear(), this._resolverCache.clear();
  }
  datasetScopeKeys(t2) {
    return Wc(t2, () => [[`datasets.${t2}`, ""]]);
  }
  datasetAnimationScopeKeys(t2, e2) {
    return Wc(`${t2}.transition.${e2}`, () => [[`datasets.${t2}.transitions.${e2}`, `transitions.${e2}`], [`datasets.${t2}`, ""]]);
  }
  datasetElementScopeKeys(t2, e2) {
    return Wc(`${t2}-${e2}`, () => [[`datasets.${t2}.elements.${e2}`, `datasets.${t2}`, `elements.${e2}`, ""]]);
  }
  pluginScopeKeys(t2) {
    const e2 = t2.id;
    return Wc(`${this.type}-plugin-${e2}`, () => [[`plugins.${e2}`, ...t2.additionalOptionScopes || []]]);
  }
  _cachedScopes(t2, e2) {
    const i2 = this._scopeCache;
    let s2 = i2.get(t2);
    return s2 && !e2 || (s2 = /* @__PURE__ */ new Map(), i2.set(t2, s2)), s2;
  }
  getOptionScopes(t2, e2, i2) {
    const { options: s2, type: n2 } = this, r2 = this._cachedScopes(t2, i2), o2 = r2.get(e2);
    if (o2) return o2;
    const a2 = /* @__PURE__ */ new Set();
    e2.forEach((e3) => {
      t2 && (a2.add(t2), e3.forEach((e4) => Ic(a2, t2, e4))), e3.forEach((t3) => Ic(a2, s2, t3)), e3.forEach((t3) => Ic(a2, Ba[n2] || {}, t3)), e3.forEach((t3) => Ic(a2, Xa, t3)), e3.forEach((t3) => Ic(a2, ja, t3));
    });
    const l2 = Array.from(a2);
    return 0 === l2.length && l2.push(/* @__PURE__ */ Object.create(null)), Nc.has(e2) && r2.set(e2, l2), l2;
  }
  chartOptionScopes() {
    const { options: t2, type: e2 } = this;
    return [t2, Ba[e2] || {}, Xa.datasets[e2] || {}, { type: e2 }, Xa, ja];
  }
  resolveNamedOptions(t2, e2, i2, s2 = [""]) {
    const n2 = { $shared: true }, { resolver: r2, subPrefixes: o2 } = Bc(this._resolverCache, t2, s2);
    let a2 = r2;
    if (function(t3, e3) {
      const { isScriptable: i3, isIndexable: s3 } = xl(t3);
      for (const n3 of e3) {
        const e4 = i3(n3), r3 = s3(n3), o3 = (r3 || e4) && t3[n3];
        if (e4 && (qo(o3) || jc(o3)) || r3 && Co(o3)) return true;
      }
      return false;
    }(r2, e2)) {
      n2.$shared = false;
      a2 = yl(r2, i2 = qo(i2) ? i2() : i2, this.createResolver(t2, i2, o2));
    }
    for (const t3 of e2) n2[t3] = a2[t3];
    return n2;
  }
  createResolver(t2, e2, i2 = [""], s2) {
    const { resolver: n2 } = Bc(this._resolverCache, t2, i2);
    return zo(e2) ? yl(n2, e2, void 0, s2) : n2;
  }
}
function Bc(t2, e2, i2) {
  let s2 = t2.get(e2);
  s2 || (s2 = /* @__PURE__ */ new Map(), t2.set(e2, s2));
  const n2 = i2.join();
  let r2 = s2.get(n2);
  if (!r2) {
    r2 = { resolver: _l(e2, i2), subPrefixes: i2.filter((t3) => !t3.toLowerCase().includes("hover")) }, s2.set(n2, r2);
  }
  return r2;
}
const jc = (t2) => zo(t2) && Object.getOwnPropertyNames(t2).some((e2) => qo(t2[e2]));
const Hc = ["top", "bottom", "left", "right", "chartArea"];
function qc(t2, e2) {
  return "top" === t2 || "bottom" === t2 || -1 === Hc.indexOf(t2) && "x" === e2;
}
function Xc(t2, e2) {
  return function(i2, s2) {
    return i2[t2] === s2[t2] ? i2[e2] - s2[e2] : i2[t2] - s2[t2];
  };
}
function Kc(t2) {
  const e2 = t2.chart, i2 = e2.options.animation;
  e2.notifyPlugins("afterRender"), Po(i2 && i2.onComplete, [t2], e2);
}
function Uc(t2) {
  const e2 = t2.chart, i2 = e2.options.animation;
  Po(i2 && i2.onProgress, [t2], e2);
}
function Yc(t2) {
  return Wl() && "string" == typeof t2 ? t2 = document.getElementById(t2) : t2 && t2.length && (t2 = t2[0]), t2 && t2.canvas && (t2 = t2.canvas), t2;
}
const Gc = {}, Jc = (t2) => {
  const e2 = Yc(t2);
  return Object.values(Gc).filter((t3) => t3.canvas === e2).pop();
};
function Qc(t2, e2, i2) {
  const s2 = Object.keys(t2);
  for (const n2 of s2) {
    const s3 = +n2;
    if (s3 >= e2) {
      const r2 = t2[n2];
      delete t2[n2], (i2 > 0 || s3 > e2) && (t2[s3 + i2] = r2);
    }
  }
}
class Chart {
  static register(...t2) {
    $c.add(...t2), Zc();
  }
  static unregister(...t2) {
    $c.remove(...t2), Zc();
  }
  constructor(t2, e2) {
    const i2 = this.config = new Config(e2), s2 = Yc(t2), n2 = Jc(s2);
    if (n2) throw new Error("Canvas is already in use. Chart with ID '" + n2.id + "' must be destroyed before the canvas with ID '" + n2.canvas.id + "' can be reused.");
    const r2 = i2.createResolver(i2.chartOptionScopes(), this.getContext());
    this.platform = new (i2.platform || function(t3) {
      return !Wl() || "undefined" != typeof OffscreenCanvas && t3 instanceof OffscreenCanvas ? BasicPlatform : DomPlatform;
    }(s2))(), this.platform.updateConfig(i2);
    const o2 = this.platform.acquireContext(s2, r2.aspectRatio), a2 = o2 && o2.canvas, l2 = a2 && a2.height, h2 = a2 && a2.width;
    this.id = Mo(), this.ctx = o2, this.canvas = a2, this.width = h2, this.height = l2, this._options = r2, this._aspectRatio = this.aspectRatio, this._layers = [], this._metasets = [], this._stacks = void 0, this.boxes = [], this.currentDevicePixelRatio = void 0, this.chartArea = void 0, this._active = [], this._lastEvent = void 0, this._listeners = {}, this._responsiveListeners = void 0, this._sortedMetasets = [], this.scales = {}, this._plugins = new PluginService(), this.$proxies = {}, this._hiddenIndices = {}, this.attached = false, this._animationsDisabled = void 0, this.$context = void 0, this._doResize = /* @__PURE__ */ function(t3, e3) {
      let i3;
      return function(...s3) {
        return e3 ? (clearTimeout(i3), i3 = setTimeout(t3, e3, s3)) : t3.apply(this, s3), e3;
      };
    }((t3) => this.update(t3), r2.resizeDelay || 0), this._dataChanges = [], Gc[this.id] = this, o2 && a2 ? (fh.listen(this, "complete", Kc), fh.listen(this, "progress", Uc), this._initialize(), this.attached && this.update()) : console.error("Failed to create chart: can't acquire context from the given item");
  }
  get aspectRatio() {
    const { options: { aspectRatio: t2, maintainAspectRatio: e2 }, width: i2, height: s2, _aspectRatio: n2 } = this;
    return So(t2) ? e2 && n2 ? n2 : s2 ? i2 / s2 : null : t2;
  }
  get data() {
    return this.config.data;
  }
  set data(t2) {
    this.config.data = t2;
  }
  get options() {
    return this._options;
  }
  set options(t2) {
    this.config.options = t2;
  }
  get registry() {
    return $c;
  }
  _initialize() {
    return this.notifyPlugins("beforeInit"), this.options.responsive ? this.resize() : Yl(this, this.options.devicePixelRatio), this.bindEvents(), this.notifyPlugins("afterInit"), this;
  }
  clear() {
    return Ga(this.canvas, this.ctx), this;
  }
  stop() {
    return fh.stop(this), this;
  }
  resize(t2, e2) {
    fh.running(this) ? this._resizeBeforeDraw = { width: t2, height: e2 } : this._resize(t2, e2);
  }
  _resize(t2, e2) {
    const i2 = this.options, s2 = this.canvas, n2 = i2.maintainAspectRatio && this.aspectRatio, r2 = this.platform.getMaximumSize(s2, t2, e2, n2), o2 = i2.devicePixelRatio || this.platform.getDevicePixelRatio(), a2 = this.width ? "resize" : "attach";
    this.width = r2.width, this.height = r2.height, this._aspectRatio = this.aspectRatio, Yl(this, o2, true) && (this.notifyPlugins("resize", { size: r2 }), Po(i2.onResize, [this, r2], this), this.attached && this._doResize(a2) && this.render());
  }
  ensureScalesHaveIDs() {
    To(this.options.scales || {}, (t2, e2) => {
      t2.id = e2;
    });
  }
  buildOrUpdateScales() {
    const t2 = this.options, e2 = t2.scales, i2 = this.scales, s2 = Object.keys(i2).reduce((t3, e3) => (t3[e3] = false, t3), {});
    let n2 = [];
    e2 && (n2 = n2.concat(Object.keys(e2).map((t3) => {
      const i3 = e2[t3], s3 = Tc(t3, i3), n3 = "r" === s3, r2 = "x" === s3;
      return { options: i3, dposition: n3 ? "chartArea" : r2 ? "bottom" : "left", dtype: n3 ? "radialLinear" : r2 ? "category" : "linear" };
    }))), To(n2, (e3) => {
      const n3 = e3.options, r2 = n3.id, o2 = Tc(r2, n3), a2 = Ro(n3.type, e3.dtype);
      void 0 !== n3.position && qc(n3.position, o2) === qc(e3.dposition) || (n3.position = e3.dposition), s2[r2] = true;
      let l2 = null;
      if (r2 in i2 && i2[r2].type === a2) l2 = i2[r2];
      else {
        l2 = new ($c.getScale(a2))({ id: r2, type: a2, ctx: this.ctx, chart: this }), i2[l2.id] = l2;
      }
      l2.init(n3, t2);
    }), To(s2, (t3, e3) => {
      t3 || delete i2[e3];
    }), To(i2, (t3) => {
      sc.configure(this, t3, t3.options), sc.addBox(this, t3);
    });
  }
  _updateMetasets() {
    const t2 = this._metasets, e2 = this.data.datasets.length, i2 = t2.length;
    if (t2.sort((t3, e3) => t3.index - e3.index), i2 > e2) {
      for (let t3 = e2; t3 < i2; ++t3) this._destroyDatasetMeta(t3);
      t2.splice(e2, i2 - e2);
    }
    this._sortedMetasets = t2.slice(0).sort(Xc("order", "index"));
  }
  _removeUnreferencedMetasets() {
    const { _metasets: t2, data: { datasets: e2 } } = this;
    t2.length > e2.length && delete this._stacks, t2.forEach((t3, i2) => {
      0 === e2.filter((e3) => e3 === t3._dataset).length && this._destroyDatasetMeta(i2);
    });
  }
  buildOrUpdateControllers() {
    const t2 = [], e2 = this.data.datasets;
    let i2, s2;
    for (this._removeUnreferencedMetasets(), i2 = 0, s2 = e2.length; i2 < s2; i2++) {
      const s3 = e2[i2];
      let n2 = this.getDatasetMeta(i2);
      const r2 = s3.type || this.config.type;
      if (n2.type && n2.type !== r2 && (this._destroyDatasetMeta(i2), n2 = this.getDatasetMeta(i2)), n2.type = r2, n2.indexAxis = s3.indexAxis || Ec(r2, this.options), n2.order = s3.order || 0, n2.index = i2, n2.label = "" + s3.label, n2.visible = this.isDatasetVisible(i2), n2.controller) n2.controller.updateIndex(i2), n2.controller.linkScales();
      else {
        const e3 = $c.getController(r2), { datasetElementType: s4, dataElementType: o2 } = Xa.datasets[r2];
        Object.assign(e3, { dataElementType: $c.getElement(o2), datasetElementType: s4 && $c.getElement(s4) }), n2.controller = new e3(this, i2), t2.push(n2.controller);
      }
    }
    return this._updateMetasets(), t2;
  }
  _resetElements() {
    To(this.data.datasets, (t2, e2) => {
      this.getDatasetMeta(e2).controller.reset();
    }, this);
  }
  reset() {
    this._resetElements(), this.notifyPlugins("reset");
  }
  update(t2) {
    const e2 = this.config;
    e2.update();
    const i2 = this._options = e2.createResolver(e2.chartOptionScopes(), this.getContext()), s2 = this._animationsDisabled = !i2.animation;
    if (this._updateScales(), this._checkEventBindings(), this._updateHiddenIndices(), this._plugins.invalidate(), false === this.notifyPlugins("beforeUpdate", { mode: t2, cancelable: true })) return;
    const n2 = this.buildOrUpdateControllers();
    this.notifyPlugins("beforeElementsUpdate");
    let r2 = 0;
    for (let t3 = 0, e3 = this.data.datasets.length; t3 < e3; t3++) {
      const { controller: e4 } = this.getDatasetMeta(t3), i3 = !s2 && -1 === n2.indexOf(e4);
      e4.buildOrUpdateElements(i3), r2 = Math.max(+e4.getMaxOverflow(), r2);
    }
    r2 = this._minPadding = i2.layout.autoPadding ? r2 : 0, this._updateLayout(r2), s2 || To(n2, (t3) => {
      t3.reset();
    }), this._updateDatasets(t2), this.notifyPlugins("afterUpdate", { mode: t2 }), this._layers.sort(Xc("z", "_idx"));
    const { _active: o2, _lastEvent: a2 } = this;
    a2 ? this._eventHandler(a2, true) : o2.length && this._updateHoverStyles(o2, o2, true), this.render();
  }
  _updateScales() {
    To(this.scales, (t2) => {
      sc.removeBox(this, t2);
    }), this.ensureScalesHaveIDs(), this.buildOrUpdateScales();
  }
  _checkEventBindings() {
    const t2 = this.options, e2 = new Set(Object.keys(this._listeners)), i2 = new Set(t2.events);
    Xo(e2, i2) && !!this._responsiveListeners === t2.responsive || (this.unbindEvents(), this.bindEvents());
  }
  _updateHiddenIndices() {
    const { _hiddenIndices: t2 } = this, e2 = this._getUniformDataChanges() || [];
    for (const { method: i2, start: s2, count: n2 } of e2) {
      Qc(t2, s2, "_removeElements" === i2 ? -n2 : n2);
    }
  }
  _getUniformDataChanges() {
    const t2 = this._dataChanges;
    if (!t2 || !t2.length) return;
    this._dataChanges = [];
    const e2 = this.data.datasets.length, i2 = (e3) => new Set(t2.filter((t3) => t3[0] === e3).map((t3, e4) => e4 + "," + t3.splice(1).join(","))), s2 = i2(0);
    for (let t3 = 1; t3 < e2; t3++) if (!Xo(s2, i2(t3))) return;
    return Array.from(s2).map((t3) => t3.split(",")).map((t3) => ({ method: t3[1], start: +t3[2], count: +t3[3] }));
  }
  _updateLayout(t2) {
    if (false === this.notifyPlugins("beforeLayout", { cancelable: true })) return;
    sc.update(this, this.width, this.height, t2);
    const e2 = this.chartArea, i2 = e2.width <= 0 || e2.height <= 0;
    this._layers = [], To(this.boxes, (t3) => {
      i2 && "chartArea" === t3.position || (t3.configure && t3.configure(), this._layers.push(...t3._layers()));
    }, this), this._layers.forEach((t3, e3) => {
      t3._idx = e3;
    }), this.notifyPlugins("afterLayout");
  }
  _updateDatasets(t2) {
    if (false !== this.notifyPlugins("beforeDatasetsUpdate", { mode: t2, cancelable: true })) {
      for (let t3 = 0, e2 = this.data.datasets.length; t3 < e2; ++t3) this.getDatasetMeta(t3).controller.configure();
      for (let e2 = 0, i2 = this.data.datasets.length; e2 < i2; ++e2) this._updateDataset(e2, qo(t2) ? t2({ datasetIndex: e2 }) : t2);
      this.notifyPlugins("afterDatasetsUpdate", { mode: t2 });
    }
  }
  _updateDataset(t2, e2) {
    const i2 = this.getDatasetMeta(t2), s2 = { meta: i2, index: t2, mode: e2, cancelable: true };
    false !== this.notifyPlugins("beforeDatasetUpdate", s2) && (i2.controller._update(e2), s2.cancelable = false, this.notifyPlugins("afterDatasetUpdate", s2));
  }
  render() {
    false !== this.notifyPlugins("beforeRender", { cancelable: true }) && (fh.has(this) ? this.attached && !fh.running(this) && fh.start(this) : (this.draw(), Kc({ chart: this })));
  }
  draw() {
    let t2;
    if (this._resizeBeforeDraw) {
      const { width: t3, height: e3 } = this._resizeBeforeDraw;
      this._resizeBeforeDraw = null, this._resize(t3, e3);
    }
    if (this.clear(), this.width <= 0 || this.height <= 0) return;
    if (false === this.notifyPlugins("beforeDraw", { cancelable: true })) return;
    const e2 = this._layers;
    for (t2 = 0; t2 < e2.length && e2[t2].z <= 0; ++t2) e2[t2].draw(this.chartArea);
    for (this._drawDatasets(); t2 < e2.length; ++t2) e2[t2].draw(this.chartArea);
    this.notifyPlugins("afterDraw");
  }
  _getSortedDatasetMetas(t2) {
    const e2 = this._sortedMetasets, i2 = [];
    let s2, n2;
    for (s2 = 0, n2 = e2.length; s2 < n2; ++s2) {
      const n3 = e2[s2];
      t2 && !n3.visible || i2.push(n3);
    }
    return i2;
  }
  getSortedVisibleDatasetMetas() {
    return this._getSortedDatasetMetas(true);
  }
  _drawDatasets() {
    if (false === this.notifyPlugins("beforeDatasetsDraw", { cancelable: true })) return;
    const t2 = this.getSortedVisibleDatasetMetas();
    for (let e2 = t2.length - 1; e2 >= 0; --e2) this._drawDataset(t2[e2]);
    this.notifyPlugins("afterDatasetsDraw");
  }
  _drawDataset(t2) {
    const e2 = this.ctx, i2 = { meta: t2, index: t2.index, cancelable: true }, s2 = dh(this, t2);
    false !== this.notifyPlugins("beforeDatasetDraw", i2) && (s2 && tl(e2, s2), t2.controller.draw(), s2 && el(e2), i2.cancelable = false, this.notifyPlugins("afterDatasetDraw", i2));
  }
  isPointInArea(t2) {
    return Za(t2, this.chartArea, this._minPadding);
  }
  getElementsAtEventForMode(t2, e2, i2, s2) {
    const n2 = Hh.modes[e2];
    return "function" == typeof n2 ? n2(this, t2, i2, s2) : [];
  }
  getDatasetMeta(t2) {
    const e2 = this.data.datasets[t2], i2 = this._metasets;
    let s2 = i2.filter((t3) => t3 && t3._dataset === e2).pop();
    return s2 || (s2 = { type: null, data: [], dataset: null, controller: null, hidden: null, xAxisID: null, yAxisID: null, order: e2 && e2.order || 0, index: t2, _dataset: e2, _parsed: [], _sorted: false }, i2.push(s2)), s2;
  }
  getContext() {
    return this.$context || (this.$context = bl(null, { chart: this, type: "chart" }));
  }
  getVisibleDatasetCount() {
    return this.getSortedVisibleDatasetMetas().length;
  }
  isDatasetVisible(t2) {
    const e2 = this.data.datasets[t2];
    if (!e2) return false;
    const i2 = this.getDatasetMeta(t2);
    return "boolean" == typeof i2.hidden ? !i2.hidden : !e2.hidden;
  }
  setDatasetVisibility(t2, e2) {
    this.getDatasetMeta(t2).hidden = !e2;
  }
  toggleDataVisibility(t2) {
    this._hiddenIndices[t2] = !this._hiddenIndices[t2];
  }
  getDataVisibility(t2) {
    return !this._hiddenIndices[t2];
  }
  _updateVisibility(t2, e2, i2) {
    const s2 = i2 ? "show" : "hide", n2 = this.getDatasetMeta(t2), r2 = n2.controller._resolveAnimations(void 0, s2);
    Ho(e2) ? (n2.data[e2].hidden = !i2, this.update()) : (this.setDatasetVisibility(t2, i2), r2.update(n2, { visible: i2 }), this.update((e3) => e3.datasetIndex === t2 ? s2 : void 0));
  }
  hide(t2, e2) {
    this._updateVisibility(t2, e2, false);
  }
  show(t2, e2) {
    this._updateVisibility(t2, e2, true);
  }
  _destroyDatasetMeta(t2) {
    const e2 = this._metasets[t2];
    e2 && e2.controller && e2.controller._destroy(), delete this._metasets[t2];
  }
  _stop() {
    let t2, e2;
    for (this.stop(), fh.remove(this), t2 = 0, e2 = this.data.datasets.length; t2 < e2; ++t2) this._destroyDatasetMeta(t2);
  }
  destroy() {
    this.notifyPlugins("beforeDestroy");
    const { canvas: t2, ctx: e2 } = this;
    this._stop(), this.config.clearCache(), t2 && (this.unbindEvents(), Ga(t2, e2), this.platform.releaseContext(e2), this.canvas = null, this.ctx = null), delete Gc[this.id], this.notifyPlugins("afterDestroy");
  }
  toBase64Image(...t2) {
    return this.canvas.toDataURL(...t2);
  }
  bindEvents() {
    this.bindUserEvents(), this.options.responsive ? this.bindResponsiveEvents() : this.attached = true;
  }
  bindUserEvents() {
    const t2 = this._listeners, e2 = this.platform, i2 = (i3, s3) => {
      e2.addEventListener(this, i3, s3), t2[i3] = s3;
    }, s2 = (t3, e3, i3) => {
      t3.offsetX = e3, t3.offsetY = i3, this._eventHandler(t3);
    };
    To(this.options.events, (t3) => i2(t3, s2));
  }
  bindResponsiveEvents() {
    this._responsiveListeners || (this._responsiveListeners = {});
    const t2 = this._responsiveListeners, e2 = this.platform, i2 = (i3, s3) => {
      e2.addEventListener(this, i3, s3), t2[i3] = s3;
    }, s2 = (i3, s3) => {
      t2[i3] && (e2.removeEventListener(this, i3, s3), delete t2[i3]);
    }, n2 = (t3, e3) => {
      this.canvas && this.resize(t3, e3);
    };
    let r2;
    const o2 = () => {
      s2("attach", o2), this.attached = true, this.resize(), i2("resize", n2), i2("detach", r2);
    };
    r2 = () => {
      this.attached = false, s2("resize", n2), this._stop(), this._resize(0, 0), i2("attach", o2);
    }, e2.isAttached(this.canvas) ? o2() : r2();
  }
  unbindEvents() {
    To(this._listeners, (t2, e2) => {
      this.platform.removeEventListener(this, e2, t2);
    }), this._listeners = {}, To(this._responsiveListeners, (t2, e2) => {
      this.platform.removeEventListener(this, e2, t2);
    }), this._responsiveListeners = void 0;
  }
  updateHoverStyle(t2, e2, i2) {
    const s2 = i2 ? "set" : "remove";
    let n2, r2, o2, a2;
    for ("dataset" === e2 && (n2 = this.getDatasetMeta(t2[0].datasetIndex), n2.controller["_" + s2 + "DatasetHoverStyle"]()), o2 = 0, a2 = t2.length; o2 < a2; ++o2) {
      r2 = t2[o2];
      const e3 = r2 && this.getDatasetMeta(r2.datasetIndex).controller;
      e3 && e3[s2 + "HoverStyle"](r2.element, r2.datasetIndex, r2.index);
    }
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t2) {
    const e2 = this._active || [], i2 = t2.map(({ datasetIndex: t3, index: e3 }) => {
      const i3 = this.getDatasetMeta(t3);
      if (!i3) throw new Error("No dataset found at index " + t3);
      return { datasetIndex: t3, element: i3.data[e3], index: e3 };
    });
    !Lo(i2, e2) && (this._active = i2, this._lastEvent = null, this._updateHoverStyles(i2, e2));
  }
  notifyPlugins(t2, e2, i2) {
    return this._plugins.notify(this, t2, e2, i2);
  }
  isPluginEnabled(t2) {
    return 1 === this._plugins._cache.filter((e2) => e2.plugin.id === t2).length;
  }
  _updateHoverStyles(t2, e2, i2) {
    const s2 = this.options.hover, n2 = (t3, e3) => t3.filter((t4) => !e3.some((e4) => t4.datasetIndex === e4.datasetIndex && t4.index === e4.index)), r2 = n2(e2, t2), o2 = i2 ? t2 : n2(t2, e2);
    r2.length && this.updateHoverStyle(r2, s2.mode, false), o2.length && s2.mode && this.updateHoverStyle(o2, s2.mode, true);
  }
  _eventHandler(t2, e2) {
    const i2 = { event: t2, replay: e2, cancelable: true, inChartArea: this.isPointInArea(t2) }, s2 = (e3) => (e3.options.events || this.options.events).includes(t2.native.type);
    if (false === this.notifyPlugins("beforeEvent", i2, s2)) return;
    const n2 = this._handleEvent(t2, e2, i2.inChartArea);
    return i2.cancelable = false, this.notifyPlugins("afterEvent", i2, s2), (n2 || i2.changed) && this.render(), this;
  }
  _handleEvent(t2, e2, i2) {
    const { _active: s2 = [], options: n2 } = this, r2 = e2, o2 = this._getActiveElements(t2, s2, i2, r2), a2 = function(t3) {
      return "mouseup" === t3.type || "click" === t3.type || "contextmenu" === t3.type;
    }(t2), l2 = function(t3, e3, i3, s3) {
      return i3 && "mouseout" !== t3.type ? s3 ? e3 : t3 : null;
    }(t2, this._lastEvent, i2, a2);
    i2 && (this._lastEvent = null, Po(n2.onHover, [t2, o2, this], this), a2 && Po(n2.onClick, [t2, o2, this], this));
    const h2 = !Lo(o2, s2);
    return (h2 || e2) && (this._active = o2, this._updateHoverStyles(o2, s2, e2)), this._lastEvent = l2, h2;
  }
  _getActiveElements(t2, e2, i2, s2) {
    if ("mouseout" === t2.type) return [];
    if (!i2) return e2;
    const n2 = this.options.hover;
    return this.getElementsAtEventForMode(t2, n2.mode, n2, s2);
  }
}
__publicField(Chart, "defaults", Xa);
__publicField(Chart, "instances", Gc);
__publicField(Chart, "overrides", Ba);
__publicField(Chart, "registry", $c);
__publicField(Chart, "version", "4.4.9");
__publicField(Chart, "getChart", Jc);
function Zc() {
  return To(Chart.instances, (t2) => t2._plugins.invalidate());
}
function tu(t2, e2, i2, s2) {
  const n2 = dl(t2.options.borderRadius, ["outerStart", "outerEnd", "innerStart", "innerEnd"]);
  const r2 = (i2 - e2) / 2, o2 = Math.min(r2, s2 * e2 / 2), a2 = (t3) => {
    const e3 = (i2 - Math.min(r2, t3)) * s2 / 2;
    return ma(t3, 0, Math.min(r2, e3));
  };
  return { outerStart: a2(n2.outerStart), outerEnd: a2(n2.outerEnd), innerStart: ma(n2.innerStart, 0, o2), innerEnd: ma(n2.innerEnd, 0, o2) };
}
function eu(t2, e2, i2, s2) {
  return { x: i2 + t2 * Math.cos(e2), y: s2 + t2 * Math.sin(e2) };
}
function iu(t2, e2, i2, s2, n2, r2) {
  const { x: o2, y: a2, startAngle: l2, pixelMargin: h2, innerRadius: c2 } = e2, u2 = Math.max(e2.outerRadius + s2 + i2 - h2, 0), d2 = c2 > 0 ? c2 + s2 + i2 + h2 : 0;
  let f2 = 0;
  const p2 = n2 - l2;
  if (s2) {
    const t3 = ((c2 > 0 ? c2 - s2 : 0) + (u2 > 0 ? u2 - s2 : 0)) / 2;
    f2 = (p2 - (0 !== t3 ? p2 * t3 / (t3 + s2) : p2)) / 2;
  }
  const m2 = (p2 - Math.max(1e-3, p2 * u2 - i2 / Ko) / u2) / 2, g2 = l2 + m2 + f2, v2 = n2 - m2 - f2, { outerStart: b2, outerEnd: _2, innerStart: y2, innerEnd: x2 } = tu(e2, d2, u2, v2 - g2), w2 = u2 - b2, k2 = u2 - _2, M2 = g2 + b2 / w2, S2 = v2 - _2 / k2, C2 = d2 + y2, z2 = d2 + x2, R2 = g2 + y2 / C2, E2 = v2 - x2 / z2;
  if (t2.beginPath(), r2) {
    const e3 = (M2 + S2) / 2;
    if (t2.arc(o2, a2, u2, M2, e3), t2.arc(o2, a2, u2, e3, S2), _2 > 0) {
      const e4 = eu(k2, S2, o2, a2);
      t2.arc(e4.x, e4.y, _2, S2, v2 + Qo);
    }
    const i3 = eu(z2, v2, o2, a2);
    if (t2.lineTo(i3.x, i3.y), x2 > 0) {
      const e4 = eu(z2, E2, o2, a2);
      t2.arc(e4.x, e4.y, x2, v2 + Qo, E2 + Math.PI);
    }
    const s3 = (v2 - x2 / d2 + (g2 + y2 / d2)) / 2;
    if (t2.arc(o2, a2, d2, v2 - x2 / d2, s3, true), t2.arc(o2, a2, d2, s3, g2 + y2 / d2, true), y2 > 0) {
      const e4 = eu(C2, R2, o2, a2);
      t2.arc(e4.x, e4.y, y2, R2 + Math.PI, g2 - Qo);
    }
    const n3 = eu(w2, g2, o2, a2);
    if (t2.lineTo(n3.x, n3.y), b2 > 0) {
      const e4 = eu(w2, M2, o2, a2);
      t2.arc(e4.x, e4.y, b2, g2 - Qo, M2);
    }
  } else {
    t2.moveTo(o2, a2);
    const e3 = Math.cos(M2) * u2 + o2, i3 = Math.sin(M2) * u2 + a2;
    t2.lineTo(e3, i3);
    const s3 = Math.cos(S2) * u2 + o2, n3 = Math.sin(S2) * u2 + a2;
    t2.lineTo(s3, n3);
  }
  t2.closePath();
}
function su(t2, e2, i2, s2, n2) {
  const { fullCircles: r2, startAngle: o2, circumference: a2, options: l2 } = e2, { borderWidth: h2, borderJoinStyle: c2, borderDash: u2, borderDashOffset: d2 } = l2, f2 = "inner" === l2.borderAlign;
  if (!h2) return;
  t2.setLineDash(u2 || []), t2.lineDashOffset = d2, f2 ? (t2.lineWidth = 2 * h2, t2.lineJoin = c2 || "round") : (t2.lineWidth = h2, t2.lineJoin = c2 || "bevel");
  let p2 = e2.endAngle;
  if (r2) {
    iu(t2, e2, i2, s2, p2, n2);
    for (let e3 = 0; e3 < r2; ++e3) t2.stroke();
    isNaN(a2) || (p2 = o2 + (a2 % Uo || Uo));
  }
  f2 && function(t3, e3, i3) {
    const { startAngle: s3, pixelMargin: n3, x: r3, y: o3, outerRadius: a3, innerRadius: l3 } = e3;
    let h3 = n3 / a3;
    t3.beginPath(), t3.arc(r3, o3, a3, s3 - h3, i3 + h3), l3 > n3 ? (h3 = n3 / l3, t3.arc(r3, o3, l3, i3 + h3, s3 - h3, true)) : t3.arc(r3, o3, n3, i3 + Qo, s3 - Qo), t3.closePath(), t3.clip();
  }(t2, e2, p2), r2 || (iu(t2, e2, i2, s2, p2, n2), t2.stroke());
}
class ArcElement extends bc {
  constructor(t2) {
    super();
    __publicField(this, "circumference");
    __publicField(this, "endAngle");
    __publicField(this, "fullCircles");
    __publicField(this, "innerRadius");
    __publicField(this, "outerRadius");
    __publicField(this, "pixelMargin");
    __publicField(this, "startAngle");
    this.options = void 0, this.circumference = void 0, this.startAngle = void 0, this.endAngle = void 0, this.innerRadius = void 0, this.outerRadius = void 0, this.pixelMargin = 0, this.fullCircles = 0, t2 && Object.assign(this, t2);
  }
  inRange(t2, e2, i2) {
    const s2 = this.getProps(["x", "y"], i2), { angle: n2, distance: r2 } = ca(s2, { x: t2, y: e2 }), { startAngle: o2, endAngle: a2, innerRadius: l2, outerRadius: h2, circumference: c2 } = this.getProps(["startAngle", "endAngle", "innerRadius", "outerRadius", "circumference"], i2), u2 = (this.options.spacing + this.options.borderWidth) / 2, d2 = Ro(c2, a2 - o2), f2 = pa(n2, o2, a2) && o2 !== a2, p2 = d2 >= Uo || f2, m2 = ga(r2, l2 + u2, h2 + u2);
    return p2 && m2;
  }
  getCenterPoint(t2) {
    const { x: e2, y: i2, startAngle: s2, endAngle: n2, innerRadius: r2, outerRadius: o2 } = this.getProps(["x", "y", "startAngle", "endAngle", "innerRadius", "outerRadius"], t2), { offset: a2, spacing: l2 } = this.options, h2 = (s2 + n2) / 2, c2 = (r2 + o2 + l2 + a2) / 2;
    return { x: e2 + Math.cos(h2) * c2, y: i2 + Math.sin(h2) * c2 };
  }
  tooltipPosition(t2) {
    return this.getCenterPoint(t2);
  }
  draw(t2) {
    const { options: e2, circumference: i2 } = this, s2 = (e2.offset || 0) / 4, n2 = (e2.spacing || 0) / 2, r2 = e2.circular;
    if (this.pixelMargin = "inner" === e2.borderAlign ? 0.33 : 0, this.fullCircles = i2 > Uo ? Math.floor(i2 / Uo) : 0, 0 === i2 || this.innerRadius < 0 || this.outerRadius < 0) return;
    t2.save();
    const o2 = (this.startAngle + this.endAngle) / 2;
    t2.translate(Math.cos(o2) * s2, Math.sin(o2) * s2);
    const a2 = s2 * (1 - Math.sin(Math.min(Ko, i2 || 0)));
    t2.fillStyle = e2.backgroundColor, t2.strokeStyle = e2.borderColor, function(t3, e3, i3, s3, n3) {
      const { fullCircles: r3, startAngle: o3, circumference: a3 } = e3;
      let l2 = e3.endAngle;
      if (r3) {
        iu(t3, e3, i3, s3, l2, n3);
        for (let e4 = 0; e4 < r3; ++e4) t3.fill();
        isNaN(a3) || (l2 = o3 + (a3 % Uo || Uo));
      }
      iu(t3, e3, i3, s3, l2, n3), t3.fill();
    }(t2, this, a2, n2, r2), su(t2, this, a2, n2, r2), t2.restore();
  }
}
__publicField(ArcElement, "id", "arc");
__publicField(ArcElement, "defaults", { borderAlign: "center", borderColor: "#fff", borderDash: [], borderDashOffset: 0, borderJoinStyle: void 0, borderRadius: 0, borderWidth: 2, offset: 0, spacing: 0, angle: void 0, circular: true });
__publicField(ArcElement, "defaultRoutes", { backgroundColor: "backgroundColor" });
__publicField(ArcElement, "descriptors", { _scriptable: true, _indexable: (t2) => "borderDash" !== t2 });
function nu(t2, e2, i2 = e2) {
  t2.lineCap = Ro(i2.borderCapStyle, e2.borderCapStyle), t2.setLineDash(Ro(i2.borderDash, e2.borderDash)), t2.lineDashOffset = Ro(i2.borderDashOffset, e2.borderDashOffset), t2.lineJoin = Ro(i2.borderJoinStyle, e2.borderJoinStyle), t2.lineWidth = Ro(i2.borderWidth, e2.borderWidth), t2.strokeStyle = Ro(i2.borderColor, e2.borderColor);
}
function ru(t2, e2, i2) {
  t2.lineTo(i2.x, i2.y);
}
function ou(t2, e2, i2 = {}) {
  const s2 = t2.length, { start: n2 = 0, end: r2 = s2 - 1 } = i2, { start: o2, end: a2 } = e2, l2 = Math.max(n2, o2), h2 = Math.min(r2, a2), c2 = n2 < o2 && r2 < o2 || n2 > a2 && r2 > a2;
  return { count: s2, start: l2, loop: e2.loop, ilen: h2 < l2 && !c2 ? s2 + h2 - l2 : h2 - l2 };
}
function au(t2, e2, i2, s2) {
  const { points: n2, options: r2 } = e2, { count: o2, start: a2, loop: l2, ilen: h2 } = ou(n2, i2, s2), c2 = function(t3) {
    return t3.stepped ? il : t3.tension || "monotone" === t3.cubicInterpolationMode ? sl : ru;
  }(r2);
  let u2, d2, f2, { move: p2 = true, reverse: m2 } = s2 || {};
  for (u2 = 0; u2 <= h2; ++u2) d2 = n2[(a2 + (m2 ? h2 - u2 : u2)) % o2], d2.skip || (p2 ? (t2.moveTo(d2.x, d2.y), p2 = false) : c2(t2, f2, d2, m2, r2.stepped), f2 = d2);
  return l2 && (d2 = n2[(a2 + (m2 ? h2 : 0)) % o2], c2(t2, f2, d2, m2, r2.stepped)), !!l2;
}
function lu(t2, e2, i2, s2) {
  const n2 = e2.points, { count: r2, start: o2, ilen: a2 } = ou(n2, i2, s2), { move: l2 = true, reverse: h2 } = s2 || {};
  let c2, u2, d2, f2, p2, m2, g2 = 0, v2 = 0;
  const b2 = (t3) => (o2 + (h2 ? a2 - t3 : t3)) % r2, _2 = () => {
    f2 !== p2 && (t2.lineTo(g2, p2), t2.lineTo(g2, f2), t2.lineTo(g2, m2));
  };
  for (l2 && (u2 = n2[b2(0)], t2.moveTo(u2.x, u2.y)), c2 = 0; c2 <= a2; ++c2) {
    if (u2 = n2[b2(c2)], u2.skip) continue;
    const e3 = u2.x, i3 = u2.y, s3 = 0 | e3;
    s3 === d2 ? (i3 < f2 ? f2 = i3 : i3 > p2 && (p2 = i3), g2 = (v2 * g2 + e3) / ++v2) : (_2(), t2.lineTo(e3, i3), d2 = s3, v2 = 0, f2 = p2 = i3), m2 = i3;
  }
  _2();
}
function hu(t2) {
  const e2 = t2.options, i2 = e2.borderDash && e2.borderDash.length;
  return !(t2._decimated || t2._loop || e2.tension || "monotone" === e2.cubicInterpolationMode || e2.stepped || i2) ? lu : au;
}
const cu = "function" == typeof Path2D;
function uu(t2, e2, i2, s2) {
  cu && !e2.options.segment ? function(t3, e3, i3, s3) {
    let n2 = e3._path;
    n2 || (n2 = e3._path = new Path2D(), e3.path(n2, i3, s3) && n2.closePath()), nu(t3, e3.options), t3.stroke(n2);
  }(t2, e2, i2, s2) : function(t3, e3, i3, s3) {
    const { segments: n2, options: r2 } = e3, o2 = hu(e3);
    for (const a2 of n2) nu(t3, r2, a2.style), t3.beginPath(), o2(t3, e3, a2, { start: i3, end: i3 + s3 - 1 }) && t3.closePath(), t3.stroke();
  }(t2, e2, i2, s2);
}
class LineElement extends bc {
  constructor(t2) {
    super(), this.animated = true, this.options = void 0, this._chart = void 0, this._loop = void 0, this._fullLoop = void 0, this._path = void 0, this._points = void 0, this._segments = void 0, this._decimated = false, this._pointsUpdated = false, this._datasetIndex = void 0, t2 && Object.assign(this, t2);
  }
  updateControlPoints(t2, e2) {
    const i2 = this.options;
    if ((i2.tension || "monotone" === i2.cubicInterpolationMode) && !i2.stepped && !this._pointsUpdated) {
      const s2 = i2.spanGaps ? this._loop : this._fullLoop;
      Nl(this._points, i2, t2, s2, e2), this._pointsUpdated = true;
    }
  }
  set points(t2) {
    this._points = t2, delete this._segments, delete this._path, this._pointsUpdated = false;
  }
  get points() {
    return this._points;
  }
  get segments() {
    return this._segments || (this._segments = function(t2, e2) {
      const i2 = t2.points, s2 = t2.options.spanGaps, n2 = i2.length;
      if (!n2) return [];
      const r2 = !!t2._loop, { start: o2, end: a2 } = function(t3, e3, i3, s3) {
        let n3 = 0, r3 = e3 - 1;
        if (i3 && !s3) for (; n3 < e3 && !t3[n3].skip; ) n3++;
        for (; n3 < e3 && t3[n3].skip; ) n3++;
        for (n3 %= e3, i3 && (r3 += n3); r3 > n3 && t3[r3 % e3].skip; ) r3--;
        return r3 %= e3, { start: n3, end: r3 };
      }(i2, n2, r2, s2);
      return lh(t2, true === s2 ? [{ start: o2, end: a2, loop: r2 }] : function(t3, e3, i3, s3) {
        const n3 = t3.length, r3 = [];
        let o3, a3 = e3, l2 = t3[e3];
        for (o3 = e3 + 1; o3 <= i3; ++o3) {
          const i4 = t3[o3 % n3];
          i4.skip || i4.stop ? l2.skip || (s3 = false, r3.push({ start: e3 % n3, end: (o3 - 1) % n3, loop: s3 }), e3 = a3 = i4.stop ? o3 : null) : (a3 = o3, l2.skip && (e3 = o3)), l2 = i4;
        }
        return null !== a3 && r3.push({ start: e3 % n3, end: a3 % n3, loop: s3 }), r3;
      }(i2, o2, a2 < o2 ? a2 + n2 : a2, !!t2._fullLoop && 0 === o2 && a2 === n2 - 1), i2, e2);
    }(this, this.options.segment));
  }
  first() {
    const t2 = this.segments, e2 = this.points;
    return t2.length && e2[t2[0].start];
  }
  last() {
    const t2 = this.segments, e2 = this.points, i2 = t2.length;
    return i2 && e2[t2[i2 - 1].end];
  }
  interpolate(t2, e2) {
    const i2 = this.options, s2 = t2[e2], n2 = this.points, r2 = ah(this, { property: e2, start: s2, end: s2 });
    if (!r2.length) return;
    const o2 = [], a2 = function(t3) {
      return t3.stepped ? Zl : t3.tension || "monotone" === t3.cubicInterpolationMode ? th : Ql;
    }(i2);
    let l2, h2;
    for (l2 = 0, h2 = r2.length; l2 < h2; ++l2) {
      const { start: h3, end: c2 } = r2[l2], u2 = n2[h3], d2 = n2[c2];
      if (u2 === d2) {
        o2.push(u2);
        continue;
      }
      const f2 = a2(u2, d2, Math.abs((s2 - u2[e2]) / (d2[e2] - u2[e2])), i2.stepped);
      f2[e2] = t2[e2], o2.push(f2);
    }
    return 1 === o2.length ? o2[0] : o2;
  }
  pathSegment(t2, e2, i2) {
    return hu(this)(t2, this, e2, i2);
  }
  path(t2, e2, i2) {
    const s2 = this.segments, n2 = hu(this);
    let r2 = this._loop;
    e2 = e2 || 0, i2 = i2 || this.points.length - e2;
    for (const o2 of s2) r2 &= n2(t2, this, o2, { start: e2, end: e2 + i2 - 1 });
    return !!r2;
  }
  draw(t2, e2, i2, s2) {
    const n2 = this.options || {};
    (this.points || []).length && n2.borderWidth && (t2.save(), uu(t2, this, i2, s2), t2.restore()), this.animated && (this._pointsUpdated = false, this._path = void 0);
  }
}
__publicField(LineElement, "id", "line");
__publicField(LineElement, "defaults", { borderCapStyle: "butt", borderDash: [], borderDashOffset: 0, borderJoinStyle: "miter", borderWidth: 3, capBezierPoints: true, cubicInterpolationMode: "default", fill: false, spanGaps: false, stepped: false, tension: 0 });
__publicField(LineElement, "defaultRoutes", { backgroundColor: "backgroundColor", borderColor: "borderColor" });
__publicField(LineElement, "descriptors", { _scriptable: true, _indexable: (t2) => "borderDash" !== t2 && "fill" !== t2 });
function du(t2, e2, i2, s2) {
  const n2 = t2.options, { [i2]: r2 } = t2.getProps([i2], s2);
  return Math.abs(e2 - r2) < n2.radius + n2.hitRadius;
}
class PointElement extends bc {
  constructor(t2) {
    super();
    __publicField(this, "parsed");
    __publicField(this, "skip");
    __publicField(this, "stop");
    this.options = void 0, this.parsed = void 0, this.skip = void 0, this.stop = void 0, t2 && Object.assign(this, t2);
  }
  inRange(t2, e2, i2) {
    const s2 = this.options, { x: n2, y: r2 } = this.getProps(["x", "y"], i2);
    return Math.pow(t2 - n2, 2) + Math.pow(e2 - r2, 2) < Math.pow(s2.hitRadius + s2.radius, 2);
  }
  inXRange(t2, e2) {
    return du(this, t2, "x", e2);
  }
  inYRange(t2, e2) {
    return du(this, t2, "y", e2);
  }
  getCenterPoint(t2) {
    const { x: e2, y: i2 } = this.getProps(["x", "y"], t2);
    return { x: e2, y: i2 };
  }
  size(t2) {
    let e2 = (t2 = t2 || this.options || {}).radius || 0;
    e2 = Math.max(e2, e2 && t2.hoverRadius || 0);
    return 2 * (e2 + (e2 && t2.borderWidth || 0));
  }
  draw(t2, e2) {
    const i2 = this.options;
    this.skip || i2.radius < 0.1 || !Za(this, e2, this.size(i2) / 2) || (t2.strokeStyle = i2.borderColor, t2.lineWidth = i2.borderWidth, t2.fillStyle = i2.backgroundColor, Ja(t2, i2, this.x, this.y));
  }
  getRange() {
    const t2 = this.options || {};
    return t2.radius + t2.hitRadius;
  }
}
__publicField(PointElement, "id", "point");
__publicField(PointElement, "defaults", { borderWidth: 1, hitRadius: 1, hoverBorderWidth: 1, hoverRadius: 4, pointStyle: "circle", radius: 3, rotation: 0 });
__publicField(PointElement, "defaultRoutes", { backgroundColor: "backgroundColor", borderColor: "borderColor" });
function fu(t2, e2) {
  const { x: i2, y: s2, base: n2, width: r2, height: o2 } = t2.getProps(["x", "y", "base", "width", "height"], e2);
  let a2, l2, h2, c2, u2;
  return t2.horizontal ? (u2 = o2 / 2, a2 = Math.min(i2, n2), l2 = Math.max(i2, n2), h2 = s2 - u2, c2 = s2 + u2) : (u2 = r2 / 2, a2 = i2 - u2, l2 = i2 + u2, h2 = Math.min(s2, n2), c2 = Math.max(s2, n2)), { left: a2, top: h2, right: l2, bottom: c2 };
}
function pu(t2, e2, i2, s2) {
  return t2 ? 0 : ma(e2, i2, s2);
}
function mu(t2) {
  const e2 = fu(t2), i2 = e2.right - e2.left, s2 = e2.bottom - e2.top, n2 = function(t3, e3, i3) {
    const s3 = t3.options.borderWidth, n3 = t3.borderSkipped, r3 = fl(s3);
    return { t: pu(n3.top, r3.top, 0, i3), r: pu(n3.right, r3.right, 0, e3), b: pu(n3.bottom, r3.bottom, 0, i3), l: pu(n3.left, r3.left, 0, e3) };
  }(t2, i2 / 2, s2 / 2), r2 = function(t3, e3, i3) {
    const { enableBorderRadius: s3 } = t3.getProps(["enableBorderRadius"]), n3 = t3.options.borderRadius, r3 = pl(n3), o2 = Math.min(e3, i3), a2 = t3.borderSkipped, l2 = s3 || zo(n3);
    return { topLeft: pu(!l2 || a2.top || a2.left, r3.topLeft, 0, o2), topRight: pu(!l2 || a2.top || a2.right, r3.topRight, 0, o2), bottomLeft: pu(!l2 || a2.bottom || a2.left, r3.bottomLeft, 0, o2), bottomRight: pu(!l2 || a2.bottom || a2.right, r3.bottomRight, 0, o2) };
  }(t2, i2 / 2, s2 / 2);
  return { outer: { x: e2.left, y: e2.top, w: i2, h: s2, radius: r2 }, inner: { x: e2.left + n2.l, y: e2.top + n2.t, w: i2 - n2.l - n2.r, h: s2 - n2.t - n2.b, radius: { topLeft: Math.max(0, r2.topLeft - Math.max(n2.t, n2.l)), topRight: Math.max(0, r2.topRight - Math.max(n2.t, n2.r)), bottomLeft: Math.max(0, r2.bottomLeft - Math.max(n2.b, n2.l)), bottomRight: Math.max(0, r2.bottomRight - Math.max(n2.b, n2.r)) } } };
}
function gu(t2, e2, i2, s2) {
  const n2 = null === e2, r2 = null === i2, o2 = t2 && !(n2 && r2) && fu(t2, s2);
  return o2 && (n2 || ga(e2, o2.left, o2.right)) && (r2 || ga(i2, o2.top, o2.bottom));
}
function vu(t2, e2) {
  t2.rect(e2.x, e2.y, e2.w, e2.h);
}
function bu(t2, e2, i2 = {}) {
  const s2 = t2.x !== i2.x ? -e2 : 0, n2 = t2.y !== i2.y ? -e2 : 0, r2 = (t2.x + t2.w !== i2.x + i2.w ? e2 : 0) - s2, o2 = (t2.y + t2.h !== i2.y + i2.h ? e2 : 0) - n2;
  return { x: t2.x + s2, y: t2.y + n2, w: t2.w + r2, h: t2.h + o2, radius: t2.radius };
}
class BarElement extends bc {
  constructor(t2) {
    super(), this.options = void 0, this.horizontal = void 0, this.base = void 0, this.width = void 0, this.height = void 0, this.inflateAmount = void 0, t2 && Object.assign(this, t2);
  }
  draw(t2) {
    const { inflateAmount: e2, options: { borderColor: i2, backgroundColor: s2 } } = this, { inner: n2, outer: r2 } = mu(this), o2 = (a2 = r2.radius).topLeft || a2.topRight || a2.bottomLeft || a2.bottomRight ? al : vu;
    var a2;
    t2.save(), r2.w === n2.w && r2.h === n2.h || (t2.beginPath(), o2(t2, bu(r2, e2, n2)), t2.clip(), o2(t2, bu(n2, -e2, r2)), t2.fillStyle = i2, t2.fill("evenodd")), t2.beginPath(), o2(t2, bu(n2, e2)), t2.fillStyle = s2, t2.fill(), t2.restore();
  }
  inRange(t2, e2, i2) {
    return gu(this, t2, e2, i2);
  }
  inXRange(t2, e2) {
    return gu(this, t2, null, e2);
  }
  inYRange(t2, e2) {
    return gu(this, null, t2, e2);
  }
  getCenterPoint(t2) {
    const { x: e2, y: i2, base: s2, horizontal: n2 } = this.getProps(["x", "y", "base", "horizontal"], t2);
    return { x: n2 ? (e2 + s2) / 2 : e2, y: n2 ? i2 : (i2 + s2) / 2 };
  }
  getRange(t2) {
    return "x" === t2 ? this.width / 2 : this.height / 2;
  }
}
__publicField(BarElement, "id", "bar");
__publicField(BarElement, "defaults", { borderSkipped: "start", borderWidth: 0, borderRadius: 0, inflateAmount: "auto", pointStyle: void 0 });
__publicField(BarElement, "defaultRoutes", { backgroundColor: "backgroundColor", borderColor: "borderColor" });
var _u = Object.freeze({ __proto__: null, ArcElement, BarElement, LineElement, PointElement });
const yu = ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"], xu = yu.map((t2) => t2.replace("rgb(", "rgba(").replace(")", ", 0.5)"));
function wu(t2) {
  return yu[t2 % yu.length];
}
function ku(t2) {
  return xu[t2 % xu.length];
}
function Mu(t2) {
  let e2 = 0;
  return (i2, s2) => {
    const n2 = t2.getDatasetMeta(s2).controller;
    n2 instanceof DoughnutController ? e2 = function(t3, e3) {
      return t3.backgroundColor = t3.data.map(() => wu(e3++)), e3;
    }(i2, e2) : n2 instanceof PolarAreaController ? e2 = function(t3, e3) {
      return t3.backgroundColor = t3.data.map(() => ku(e3++)), e3;
    }(i2, e2) : n2 && (e2 = function(t3, e3) {
      return t3.borderColor = wu(e3), t3.backgroundColor = ku(e3), ++e3;
    }(i2, e2));
  };
}
function Su(t2) {
  let e2;
  for (e2 in t2) if (t2[e2].borderColor || t2[e2].backgroundColor) return true;
  return false;
}
var Cu = { id: "colors", defaults: { enabled: true, forceOverride: false }, beforeLayout(t2, e2, i2) {
  if (!i2.enabled) return;
  const { data: { datasets: s2 }, options: n2 } = t2.config, { elements: r2 } = n2, o2 = Su(s2) || (a2 = n2) && (a2.borderColor || a2.backgroundColor) || r2 && Su(r2) || "rgba(0,0,0,0.1)" !== Xa.borderColor || "rgba(0,0,0,0.1)" !== Xa.backgroundColor;
  var a2;
  if (!i2.forceOverride && o2) return;
  const l2 = Mu(t2);
  s2.forEach(l2);
} };
function zu(t2) {
  if (t2._decimated) {
    const e2 = t2._data;
    delete t2._decimated, delete t2._data, Object.defineProperty(t2, "data", { configurable: true, enumerable: true, writable: true, value: e2 });
  }
}
function $u(t2) {
  t2.data.datasets.forEach((t3) => {
    zu(t3);
  });
}
var Du = { id: "decimation", defaults: { algorithm: "min-max", enabled: false }, beforeElementsUpdate: (t2, e2, i2) => {
  if (!i2.enabled) return void $u(t2);
  const s2 = t2.width;
  t2.data.datasets.forEach((e3, n2) => {
    const { _data: r2, indexAxis: o2 } = e3, a2 = t2.getDatasetMeta(n2), l2 = r2 || e3.data;
    if ("y" === vl([o2, t2.options.indexAxis])) return;
    if (!a2.controller.supportsDecimation) return;
    const h2 = t2.scales[a2.xAxisID];
    if ("linear" !== h2.type && "time" !== h2.type) return;
    if (t2.options.parsing) return;
    let { start: c2, count: u2 } = function(t3, e4) {
      const i3 = e4.length;
      let s3, n3 = 0;
      const { iScale: r3 } = t3, { min: o3, max: a3, minDefined: l3, maxDefined: h3 } = r3.getUserBounds();
      return l3 && (n3 = ma(ba(e4, r3.axis, o3).lo, 0, i3 - 1)), s3 = h3 ? ma(ba(e4, r3.axis, a3).hi + 1, n3, i3) - n3 : i3 - n3, { start: n3, count: s3 };
    }(a2, l2);
    if (u2 <= (i2.threshold || 4 * s2)) return void zu(e3);
    let d2;
    switch (So(r2) && (e3._data = l2, delete e3.data, Object.defineProperty(e3, "data", { configurable: true, enumerable: true, get: function() {
      return this._decimated;
    }, set: function(t3) {
      this._data = t3;
    } })), i2.algorithm) {
      case "lttb":
        d2 = function(t3, e4, i3, s3, n3) {
          const r3 = n3.samples || s3;
          if (r3 >= i3) return t3.slice(e4, e4 + i3);
          const o3 = [], a3 = (i3 - 2) / (r3 - 2);
          let l3 = 0;
          const h3 = e4 + i3 - 1;
          let c3, u3, d3, f2, p2, m2 = e4;
          for (o3[l3++] = t3[m2], c3 = 0; c3 < r3 - 2; c3++) {
            let s4, n4 = 0, r4 = 0;
            const h4 = Math.floor((c3 + 1) * a3) + 1 + e4, g2 = Math.min(Math.floor((c3 + 2) * a3) + 1, i3) + e4, v2 = g2 - h4;
            for (s4 = h4; s4 < g2; s4++) n4 += t3[s4].x, r4 += t3[s4].y;
            n4 /= v2, r4 /= v2;
            const b2 = Math.floor(c3 * a3) + 1 + e4, _2 = Math.min(Math.floor((c3 + 1) * a3) + 1, i3) + e4, { x: y2, y: x2 } = t3[m2];
            for (d3 = f2 = -1, s4 = b2; s4 < _2; s4++) f2 = 0.5 * Math.abs((y2 - n4) * (t3[s4].y - x2) - (y2 - t3[s4].x) * (r4 - x2)), f2 > d3 && (d3 = f2, u3 = t3[s4], p2 = s4);
            o3[l3++] = u3, m2 = p2;
          }
          return o3[l3++] = t3[h3], o3;
        }(l2, c2, u2, s2, i2);
        break;
      case "min-max":
        d2 = function(t3, e4, i3, s3) {
          let n3, r3, o3, a3, l3, h3, c3, u3, d3, f2, p2 = 0, m2 = 0;
          const g2 = [], v2 = e4 + i3 - 1, b2 = t3[e4].x, _2 = t3[v2].x - b2;
          for (n3 = e4; n3 < e4 + i3; ++n3) {
            r3 = t3[n3], o3 = (r3.x - b2) / _2 * s3, a3 = r3.y;
            const e5 = 0 | o3;
            if (e5 === l3) a3 < d3 ? (d3 = a3, h3 = n3) : a3 > f2 && (f2 = a3, c3 = n3), p2 = (m2 * p2 + r3.x) / ++m2;
            else {
              const i4 = n3 - 1;
              if (!So(h3) && !So(c3)) {
                const e6 = Math.min(h3, c3), s4 = Math.max(h3, c3);
                e6 !== u3 && e6 !== i4 && g2.push({ ...t3[e6], x: p2 }), s4 !== u3 && s4 !== i4 && g2.push({ ...t3[s4], x: p2 });
              }
              n3 > 0 && i4 !== u3 && g2.push(t3[i4]), g2.push(r3), l3 = e5, m2 = 0, d3 = f2 = a3, h3 = c3 = u3 = n3;
            }
          }
          return g2;
        }(l2, c2, u2, s2);
        break;
      default:
        throw new Error(`Unsupported decimation algorithm '${i2.algorithm}'`);
    }
    e3._decimated = d2;
  });
}, destroy(t2) {
  $u(t2);
} };
function Ru(t2, e2, i2, s2) {
  if (s2) return;
  let n2 = e2[t2], r2 = i2[t2];
  return "angle" === t2 && (n2 = fa(n2), r2 = fa(r2)), { property: t2, start: n2, end: r2 };
}
function Eu(t2, e2, i2) {
  for (; e2 > t2; e2--) {
    const t3 = i2[e2];
    if (!isNaN(t3.x) && !isNaN(t3.y)) break;
  }
  return e2;
}
function Pu(t2, e2, i2, s2) {
  return t2 && e2 ? s2(t2[i2], e2[i2]) : t2 ? t2[i2] : e2 ? e2[i2] : 0;
}
function Tu(t2, e2) {
  let i2 = [], s2 = false;
  return Co(t2) ? (s2 = true, i2 = t2) : i2 = function(t3, e3) {
    const { x: i3 = null, y: s3 = null } = t3 || {}, n2 = e3.points, r2 = [];
    return e3.segments.forEach(({ start: t4, end: e4 }) => {
      e4 = Eu(t4, e4, n2);
      const o2 = n2[t4], a2 = n2[e4];
      null !== s3 ? (r2.push({ x: o2.x, y: s3 }), r2.push({ x: a2.x, y: s3 })) : null !== i3 && (r2.push({ x: i3, y: o2.y }), r2.push({ x: i3, y: a2.y }));
    }), r2;
  }(t2, e2), i2.length ? new LineElement({ points: i2, options: { tension: 0 }, _loop: s2, _fullLoop: s2 }) : null;
}
function Lu(t2) {
  return t2 && false !== t2.fill;
}
function Vu(t2, e2, i2) {
  let s2 = t2[e2].fill;
  const n2 = [e2];
  let r2;
  if (!i2) return s2;
  for (; false !== s2 && -1 === n2.indexOf(s2); ) {
    if (!$o(s2)) return s2;
    if (r2 = t2[s2], !r2) return false;
    if (r2.visible) return s2;
    n2.push(s2), s2 = r2.fill;
  }
  return false;
}
function Ou(t2, e2, i2) {
  const s2 = function(t3) {
    const e3 = t3.options, i3 = e3.fill;
    let s3 = Ro(i3 && i3.target, i3);
    void 0 === s3 && (s3 = !!e3.backgroundColor);
    if (false === s3 || null === s3) return false;
    if (true === s3) return "origin";
    return s3;
  }(t2);
  if (zo(s2)) return !isNaN(s2.value) && s2;
  let n2 = parseFloat(s2);
  return $o(n2) && Math.floor(n2) === n2 ? function(t3, e3, i3, s3) {
    "-" !== t3 && "+" !== t3 || (i3 = e3 + i3);
    if (i3 === e3 || i3 < 0 || i3 >= s3) return false;
    return i3;
  }(s2[0], e2, n2, i2) : ["origin", "start", "end", "stack", "shape"].indexOf(s2) >= 0 && s2;
}
function Au(t2, e2, i2) {
  const s2 = [];
  for (let n2 = 0; n2 < i2.length; n2++) {
    const r2 = i2[n2], { first: o2, last: a2, point: l2 } = Fu(r2, e2, "x");
    if (!(!l2 || o2 && a2)) {
      if (o2) s2.unshift(l2);
      else if (t2.push(l2), !a2) break;
    }
  }
  t2.push(...s2);
}
function Fu(t2, e2, i2) {
  const s2 = t2.interpolate(e2, i2);
  if (!s2) return {};
  const n2 = s2[i2], r2 = t2.segments, o2 = t2.points;
  let a2 = false, l2 = false;
  for (let t3 = 0; t3 < r2.length; t3++) {
    const e3 = r2[t3], s3 = o2[e3.start][i2], h2 = o2[e3.end][i2];
    if (ga(n2, s3, h2)) {
      a2 = n2 === s3, l2 = n2 === h2;
      break;
    }
  }
  return { first: a2, last: l2, point: s2 };
}
class simpleArc {
  constructor(t2) {
    this.x = t2.x, this.y = t2.y, this.radius = t2.radius;
  }
  pathSegment(t2, e2, i2) {
    const { x: s2, y: n2, radius: r2 } = this;
    return e2 = e2 || { start: 0, end: Uo }, t2.arc(s2, n2, r2, e2.end, e2.start, true), !i2.bounds;
  }
  interpolate(t2) {
    const { x: e2, y: i2, radius: s2 } = this, n2 = t2.angle;
    return { x: e2 + Math.cos(n2) * s2, y: i2 + Math.sin(n2) * s2, angle: n2 };
  }
}
function Nu(t2) {
  const { chart: e2, fill: i2, line: s2 } = t2;
  if ($o(i2)) return function(t3, e3) {
    const i3 = t3.getDatasetMeta(e3), s3 = i3 && t3.isDatasetVisible(e3);
    return s3 ? i3.dataset : null;
  }(e2, i2);
  if ("stack" === i2) return function(t3) {
    const { scale: e3, index: i3, line: s3 } = t3, n3 = [], r2 = s3.segments, o2 = s3.points, a2 = function(t4, e4) {
      const i4 = [], s4 = t4.getMatchingVisibleMetas("line");
      for (let t5 = 0; t5 < s4.length; t5++) {
        const n4 = s4[t5];
        if (n4.index === e4) break;
        n4.hidden || i4.unshift(n4.dataset);
      }
      return i4;
    }(e3, i3);
    a2.push(Tu({ x: null, y: e3.bottom }, s3));
    for (let t4 = 0; t4 < r2.length; t4++) {
      const e4 = r2[t4];
      for (let t5 = e4.start; t5 <= e4.end; t5++) Au(n3, o2[t5], a2);
    }
    return new LineElement({ points: n3, options: {} });
  }(t2);
  if ("shape" === i2) return true;
  const n2 = function(t3) {
    const e3 = t3.scale || {};
    if (e3.getPointPositionForValue) return function(t4) {
      const { scale: e4, fill: i3 } = t4, s3 = e4.options, n3 = e4.getLabels().length, r2 = s3.reverse ? e4.max : e4.min, o2 = function(t5, e5, i4) {
        let s4;
        return s4 = "start" === t5 ? i4 : "end" === t5 ? e5.options.reverse ? e5.min : e5.max : zo(t5) ? t5.value : e5.getBaseValue(), s4;
      }(i3, e4, r2), a2 = [];
      if (s3.grid.circular) {
        const t5 = e4.getPointPositionForValue(0, r2);
        return new simpleArc({ x: t5.x, y: t5.y, radius: e4.getDistanceFromCenterForValue(o2) });
      }
      for (let t5 = 0; t5 < n3; ++t5) a2.push(e4.getPointPositionForValue(t5, o2));
      return a2;
    }(t3);
    return function(t4) {
      const { scale: e4 = {}, fill: i3 } = t4, s3 = function(t5, e5) {
        let i4 = null;
        return "start" === t5 ? i4 = e5.bottom : "end" === t5 ? i4 = e5.top : zo(t5) ? i4 = e5.getPixelForValue(t5.value) : e5.getBasePixel && (i4 = e5.getBasePixel()), i4;
      }(i3, e4);
      if ($o(s3)) {
        const t5 = e4.isHorizontal();
        return { x: t5 ? s3 : null, y: t5 ? null : s3 };
      }
      return null;
    }(t3);
  }(t2);
  return n2 instanceof simpleArc ? n2 : Tu(n2, s2);
}
function Wu(t2, e2, i2) {
  const s2 = Nu(e2), { chart: n2, index: r2, line: o2, scale: a2, axis: l2 } = e2, h2 = o2.options, c2 = h2.fill, u2 = h2.backgroundColor, { above: d2 = u2, below: f2 = u2 } = c2 || {}, p2 = n2.getDatasetMeta(r2), m2 = dh(n2, p2);
  s2 && o2.points.length && (tl(t2, i2), function(t3, e3) {
    const { line: i3, target: s3, above: n3, below: r3, area: o3, scale: a3, clip: l3 } = e3, h3 = i3._loop ? "angle" : e3.axis;
    t3.save(), "x" === h3 && r3 !== n3 && (Iu(t3, s3, o3.top), Bu(t3, { line: i3, target: s3, color: n3, scale: a3, property: h3, clip: l3 }), t3.restore(), t3.save(), Iu(t3, s3, o3.bottom));
    Bu(t3, { line: i3, target: s3, color: r3, scale: a3, property: h3, clip: l3 }), t3.restore();
  }(t2, { line: o2, target: s2, above: d2, below: f2, area: i2, scale: a2, axis: l2, clip: m2 }), el(t2));
}
function Iu(t2, e2, i2) {
  const { segments: s2, points: n2 } = e2;
  let r2 = true, o2 = false;
  t2.beginPath();
  for (const a2 of s2) {
    const { start: s3, end: l2 } = a2, h2 = n2[s3], c2 = n2[Eu(s3, l2, n2)];
    r2 ? (t2.moveTo(h2.x, h2.y), r2 = false) : (t2.lineTo(h2.x, i2), t2.lineTo(h2.x, h2.y)), o2 = !!e2.pathSegment(t2, a2, { move: o2 }), o2 ? t2.closePath() : t2.lineTo(c2.x, i2);
  }
  t2.lineTo(e2.first().x, i2), t2.closePath(), t2.clip();
}
function Bu(t2, e2) {
  const { line: i2, target: s2, property: n2, color: r2, scale: o2, clip: a2 } = e2, l2 = function(t3, e3, i3) {
    const s3 = t3.segments, n3 = t3.points, r3 = e3.points, o3 = [];
    for (const t4 of s3) {
      let { start: s4, end: a3 } = t4;
      a3 = Eu(s4, a3, n3);
      const l3 = Ru(i3, n3[s4], n3[a3], t4.loop);
      if (!e3.segments) {
        o3.push({ source: t4, target: l3, start: n3[s4], end: n3[a3] });
        continue;
      }
      const h2 = ah(e3, l3);
      for (const e4 of h2) {
        const s5 = Ru(i3, r3[e4.start], r3[e4.end], e4.loop), a4 = oh(t4, n3, s5);
        for (const t5 of a4) o3.push({ source: t5, target: e4, start: { [i3]: Pu(l3, s5, "start", Math.max) }, end: { [i3]: Pu(l3, s5, "end", Math.min) } });
      }
    }
    return o3;
  }(i2, s2, n2);
  for (const { source: e3, target: h2, start: c2, end: u2 } of l2) {
    const { style: { backgroundColor: l3 = r2 } = {} } = e3, d2 = true !== s2;
    t2.save(), t2.fillStyle = l3, ju(t2, o2, a2, d2 && Ru(n2, c2, u2)), t2.beginPath();
    const f2 = !!i2.pathSegment(t2, e3);
    let p2;
    if (d2) {
      f2 ? t2.closePath() : Hu(t2, s2, u2, n2);
      const e4 = !!s2.pathSegment(t2, h2, { move: f2, reverse: true });
      p2 = f2 && e4, p2 || Hu(t2, s2, c2, n2);
    }
    t2.closePath(), t2.fill(p2 ? "evenodd" : "nonzero"), t2.restore();
  }
}
function ju(t2, e2, i2, s2) {
  const n2 = e2.chart.chartArea, { property: r2, start: o2, end: a2 } = s2 || {};
  if ("x" === r2 || "y" === r2) {
    let e3, s3, l2, h2;
    "x" === r2 ? (e3 = o2, s3 = n2.top, l2 = a2, h2 = n2.bottom) : (e3 = n2.left, s3 = o2, l2 = n2.right, h2 = a2), t2.beginPath(), i2 && (e3 = Math.max(e3, i2.left), l2 = Math.min(l2, i2.right), s3 = Math.max(s3, i2.top), h2 = Math.min(h2, i2.bottom)), t2.rect(e3, s3, l2 - e3, h2 - s3), t2.clip();
  }
}
function Hu(t2, e2, i2, s2) {
  const n2 = e2.interpolate(i2, s2);
  n2 && t2.lineTo(n2.x, n2.y);
}
var qu = { id: "filler", afterDatasetsUpdate(t2, e2, i2) {
  const s2 = (t2.data.datasets || []).length, n2 = [];
  let r2, o2, a2, l2;
  for (o2 = 0; o2 < s2; ++o2) r2 = t2.getDatasetMeta(o2), a2 = r2.dataset, l2 = null, a2 && a2.options && a2 instanceof LineElement && (l2 = { visible: t2.isDatasetVisible(o2), index: o2, fill: Ou(a2, o2, s2), chart: t2, axis: r2.controller.options.indexAxis, scale: r2.vScale, line: a2 }), r2.$filler = l2, n2.push(l2);
  for (o2 = 0; o2 < s2; ++o2) l2 = n2[o2], l2 && false !== l2.fill && (l2.fill = Vu(n2, o2, i2.propagate));
}, beforeDraw(t2, e2, i2) {
  const s2 = "beforeDraw" === i2.drawTime, n2 = t2.getSortedVisibleDatasetMetas(), r2 = t2.chartArea;
  for (let e3 = n2.length - 1; e3 >= 0; --e3) {
    const i3 = n2[e3].$filler;
    i3 && (i3.line.updateControlPoints(r2, i3.axis), s2 && i3.fill && Wu(t2.ctx, i3, r2));
  }
}, beforeDatasetsDraw(t2, e2, i2) {
  if ("beforeDatasetsDraw" !== i2.drawTime) return;
  const s2 = t2.getSortedVisibleDatasetMetas();
  for (let e3 = s2.length - 1; e3 >= 0; --e3) {
    const i3 = s2[e3].$filler;
    Lu(i3) && Wu(t2.ctx, i3, t2.chartArea);
  }
}, beforeDatasetDraw(t2, e2, i2) {
  const s2 = e2.meta.$filler;
  Lu(s2) && "beforeDatasetDraw" === i2.drawTime && Wu(t2.ctx, s2, t2.chartArea);
}, defaults: { propagate: true, drawTime: "beforeDatasetDraw" } };
const Xu = (t2, e2) => {
  let { boxHeight: i2 = e2, boxWidth: s2 = e2 } = t2;
  return t2.usePointStyle && (i2 = Math.min(i2, e2), s2 = t2.pointStyleWidth || Math.min(s2, e2)), { boxWidth: s2, boxHeight: i2, itemHeight: Math.max(e2, i2) };
};
class Legend extends bc {
  constructor(t2) {
    super(), this._added = false, this.legendHitBoxes = [], this._hoveredItem = null, this.doughnutMode = false, this.chart = t2.chart, this.options = t2.options, this.ctx = t2.ctx, this.legendItems = void 0, this.columnSizes = void 0, this.lineWidths = void 0, this.maxHeight = void 0, this.maxWidth = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.height = void 0, this.width = void 0, this._margins = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t2, e2, i2) {
    this.maxWidth = t2, this.maxHeight = e2, this._margins = i2, this.setDimensions(), this.buildLabels(), this.fit();
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = this._margins.left, this.right = this.width) : (this.height = this.maxHeight, this.top = this._margins.top, this.bottom = this.height);
  }
  buildLabels() {
    const t2 = this.options.labels || {};
    let e2 = Po(t2.generateLabels, [this.chart], this) || [];
    t2.filter && (e2 = e2.filter((e3) => t2.filter(e3, this.chart.data))), t2.sort && (e2 = e2.sort((e3, i2) => t2.sort(e3, i2, this.chart.data))), this.options.reverse && e2.reverse(), this.legendItems = e2;
  }
  fit() {
    const { options: t2, ctx: e2 } = this;
    if (!t2.display) return void (this.width = this.height = 0);
    const i2 = t2.labels, s2 = gl(i2.font), n2 = s2.size, r2 = this._computeTitleHeight(), { boxWidth: o2, itemHeight: a2 } = Xu(i2, n2);
    let l2, h2;
    e2.font = s2.string, this.isHorizontal() ? (l2 = this.maxWidth, h2 = this._fitRows(r2, n2, o2, a2) + 10) : (h2 = this.maxHeight, l2 = this._fitCols(r2, s2, o2, a2) + 10), this.width = Math.min(l2, t2.maxWidth || this.maxWidth), this.height = Math.min(h2, t2.maxHeight || this.maxHeight);
  }
  _fitRows(t2, e2, i2, s2) {
    const { ctx: n2, maxWidth: r2, options: { labels: { padding: o2 } } } = this, a2 = this.legendHitBoxes = [], l2 = this.lineWidths = [0], h2 = s2 + o2;
    let c2 = t2;
    n2.textAlign = "left", n2.textBaseline = "middle";
    let u2 = -1, d2 = -h2;
    return this.legendItems.forEach((t3, f2) => {
      const p2 = i2 + e2 / 2 + n2.measureText(t3.text).width;
      (0 === f2 || l2[l2.length - 1] + p2 + 2 * o2 > r2) && (c2 += h2, l2[l2.length - (f2 > 0 ? 0 : 1)] = 0, d2 += h2, u2++), a2[f2] = { left: 0, top: d2, row: u2, width: p2, height: s2 }, l2[l2.length - 1] += p2 + o2;
    }), c2;
  }
  _fitCols(t2, e2, i2, s2) {
    const { ctx: n2, maxHeight: r2, options: { labels: { padding: o2 } } } = this, a2 = this.legendHitBoxes = [], l2 = this.columnSizes = [], h2 = r2 - t2;
    let c2 = o2, u2 = 0, d2 = 0, f2 = 0, p2 = 0;
    return this.legendItems.forEach((t3, r3) => {
      const { itemWidth: m2, itemHeight: g2 } = function(t4, e3, i3, s3, n3) {
        const r4 = function(t5, e4, i4, s4) {
          let n4 = t5.text;
          n4 && "string" != typeof n4 && (n4 = n4.reduce((t6, e5) => t6.length > e5.length ? t6 : e5));
          return e4 + i4.size / 2 + s4.measureText(n4).width;
        }(s3, t4, e3, i3), o3 = function(t5, e4, i4) {
          let s4 = t5;
          "string" != typeof e4.text && (s4 = Ku(e4, i4));
          return s4;
        }(n3, s3, e3.lineHeight);
        return { itemWidth: r4, itemHeight: o3 };
      }(i2, e2, n2, t3, s2);
      r3 > 0 && d2 + g2 + 2 * o2 > h2 && (c2 += u2 + o2, l2.push({ width: u2, height: d2 }), f2 += u2 + o2, p2++, u2 = d2 = 0), a2[r3] = { left: f2, top: d2, col: p2, width: m2, height: g2 }, u2 = Math.max(u2, m2), d2 += g2 + o2;
    }), c2 += u2, l2.push({ width: u2, height: d2 }), c2;
  }
  adjustHitBoxes() {
    if (!this.options.display) return;
    const t2 = this._computeTitleHeight(), { legendHitBoxes: e2, options: { align: i2, labels: { padding: s2 }, rtl: n2 } } = this, r2 = eh(n2, this.left, this.width);
    if (this.isHorizontal()) {
      let n3 = 0, o2 = Ca(i2, this.left + s2, this.right - this.lineWidths[n3]);
      for (const a2 of e2) n3 !== a2.row && (n3 = a2.row, o2 = Ca(i2, this.left + s2, this.right - this.lineWidths[n3])), a2.top += this.top + t2 + s2, a2.left = r2.leftForLtr(r2.x(o2), a2.width), o2 += a2.width + s2;
    } else {
      let n3 = 0, o2 = Ca(i2, this.top + t2 + s2, this.bottom - this.columnSizes[n3].height);
      for (const a2 of e2) a2.col !== n3 && (n3 = a2.col, o2 = Ca(i2, this.top + t2 + s2, this.bottom - this.columnSizes[n3].height)), a2.top = o2, a2.left += this.left + s2, a2.left = r2.leftForLtr(r2.x(a2.left), a2.width), o2 += a2.height + s2;
    }
  }
  isHorizontal() {
    return "top" === this.options.position || "bottom" === this.options.position;
  }
  draw() {
    if (this.options.display) {
      const t2 = this.ctx;
      tl(t2, this), this._draw(), el(t2);
    }
  }
  _draw() {
    const { options: t2, columnSizes: e2, lineWidths: i2, ctx: s2 } = this, { align: n2, labels: r2 } = t2, o2 = Xa.color, a2 = eh(t2.rtl, this.left, this.width), l2 = gl(r2.font), { padding: h2 } = r2, c2 = l2.size, u2 = c2 / 2;
    let d2;
    this.drawTitle(), s2.textAlign = a2.textAlign("left"), s2.textBaseline = "middle", s2.lineWidth = 0.5, s2.font = l2.string;
    const { boxWidth: f2, boxHeight: p2, itemHeight: m2 } = Xu(r2, c2), g2 = this.isHorizontal(), v2 = this._computeTitleHeight();
    d2 = g2 ? { x: Ca(n2, this.left + h2, this.right - i2[0]), y: this.top + h2 + v2, line: 0 } : { x: this.left + h2, y: Ca(n2, this.top + v2 + h2, this.bottom - e2[0].height), line: 0 }, ih(this.ctx, t2.textDirection);
    const b2 = m2 + h2;
    this.legendItems.forEach((_2, y2) => {
      s2.strokeStyle = _2.fontColor, s2.fillStyle = _2.fontColor;
      const x2 = s2.measureText(_2.text).width, w2 = a2.textAlign(_2.textAlign || (_2.textAlign = r2.textAlign)), k2 = f2 + u2 + x2;
      let M2 = d2.x, S2 = d2.y;
      a2.setWidth(this.width), g2 ? y2 > 0 && M2 + k2 + h2 > this.right && (S2 = d2.y += b2, d2.line++, M2 = d2.x = Ca(n2, this.left + h2, this.right - i2[d2.line])) : y2 > 0 && S2 + b2 > this.bottom && (M2 = d2.x = M2 + e2[d2.line].width + h2, d2.line++, S2 = d2.y = Ca(n2, this.top + v2 + h2, this.bottom - e2[d2.line].height));
      if (function(t3, e3, i3) {
        if (isNaN(f2) || f2 <= 0 || isNaN(p2) || p2 < 0) return;
        s2.save();
        const n3 = Ro(i3.lineWidth, 1);
        if (s2.fillStyle = Ro(i3.fillStyle, o2), s2.lineCap = Ro(i3.lineCap, "butt"), s2.lineDashOffset = Ro(i3.lineDashOffset, 0), s2.lineJoin = Ro(i3.lineJoin, "miter"), s2.lineWidth = n3, s2.strokeStyle = Ro(i3.strokeStyle, o2), s2.setLineDash(Ro(i3.lineDash, [])), r2.usePointStyle) {
          const o3 = { radius: p2 * Math.SQRT2 / 2, pointStyle: i3.pointStyle, rotation: i3.rotation, borderWidth: n3 }, l3 = a2.xPlus(t3, f2 / 2);
          Qa(s2, o3, l3, e3 + u2, r2.pointStyleWidth && f2);
        } else {
          const r3 = e3 + Math.max((c2 - p2) / 2, 0), o3 = a2.leftForLtr(t3, f2), l3 = pl(i3.borderRadius);
          s2.beginPath(), Object.values(l3).some((t4) => 0 !== t4) ? al(s2, { x: o3, y: r3, w: f2, h: p2, radius: l3 }) : s2.rect(o3, r3, f2, p2), s2.fill(), 0 !== n3 && s2.stroke();
        }
        s2.restore();
      }(a2.x(M2), S2, _2), M2 = ((t3, e3, i3, s3) => t3 === (s3 ? "left" : "right") ? i3 : "center" === t3 ? (e3 + i3) / 2 : e3)(w2, M2 + f2 + u2, g2 ? M2 + k2 : this.right, t2.rtl), function(t3, e3, i3) {
        ol(s2, i3.text, t3, e3 + m2 / 2, l2, { strikethrough: i3.hidden, textAlign: a2.textAlign(i3.textAlign) });
      }(a2.x(M2), S2, _2), g2) d2.x += k2 + h2;
      else if ("string" != typeof _2.text) {
        const t3 = l2.lineHeight;
        d2.y += Ku(_2, t3) + h2;
      } else d2.y += b2;
    }), sh(this.ctx, t2.textDirection);
  }
  drawTitle() {
    const t2 = this.options, e2 = t2.title, i2 = gl(e2.font), s2 = ml(e2.padding);
    if (!e2.display) return;
    const n2 = eh(t2.rtl, this.left, this.width), r2 = this.ctx, o2 = e2.position, a2 = i2.size / 2, l2 = s2.top + a2;
    let h2, c2 = this.left, u2 = this.width;
    if (this.isHorizontal()) u2 = Math.max(...this.lineWidths), h2 = this.top + l2, c2 = Ca(t2.align, c2, this.right - u2);
    else {
      const e3 = this.columnSizes.reduce((t3, e4) => Math.max(t3, e4.height), 0);
      h2 = l2 + Ca(t2.align, this.top, this.bottom - e3 - t2.labels.padding - this._computeTitleHeight());
    }
    const d2 = Ca(o2, c2, c2 + u2);
    r2.textAlign = n2.textAlign(Sa(o2)), r2.textBaseline = "middle", r2.strokeStyle = e2.color, r2.fillStyle = e2.color, r2.font = i2.string, ol(r2, e2.text, d2, h2, i2);
  }
  _computeTitleHeight() {
    const t2 = this.options.title, e2 = gl(t2.font), i2 = ml(t2.padding);
    return t2.display ? e2.lineHeight + i2.height : 0;
  }
  _getLegendItemAt(t2, e2) {
    let i2, s2, n2;
    if (ga(t2, this.left, this.right) && ga(e2, this.top, this.bottom)) {
      for (n2 = this.legendHitBoxes, i2 = 0; i2 < n2.length; ++i2) if (s2 = n2[i2], ga(t2, s2.left, s2.left + s2.width) && ga(e2, s2.top, s2.top + s2.height)) return this.legendItems[i2];
    }
    return null;
  }
  handleEvent(t2) {
    const e2 = this.options;
    if (!function(t3, e3) {
      if (("mousemove" === t3 || "mouseout" === t3) && (e3.onHover || e3.onLeave)) return true;
      if (e3.onClick && ("click" === t3 || "mouseup" === t3)) return true;
      return false;
    }(t2.type, e2)) return;
    const i2 = this._getLegendItemAt(t2.x, t2.y);
    if ("mousemove" === t2.type || "mouseout" === t2.type) {
      const s2 = this._hoveredItem, n2 = ((t3, e3) => null !== t3 && null !== e3 && t3.datasetIndex === e3.datasetIndex && t3.index === e3.index)(s2, i2);
      s2 && !n2 && Po(e2.onLeave, [t2, s2, this], this), this._hoveredItem = i2, i2 && !n2 && Po(e2.onHover, [t2, i2, this], this);
    } else i2 && Po(e2.onClick, [t2, i2, this], this);
  }
}
function Ku(t2, e2) {
  return e2 * (t2.text ? t2.text.length : 0);
}
var Uu = { id: "legend", _element: Legend, start(t2, e2, i2) {
  const s2 = t2.legend = new Legend({ ctx: t2.ctx, options: i2, chart: t2 });
  sc.configure(t2, s2, i2), sc.addBox(t2, s2);
}, stop(t2) {
  sc.removeBox(t2, t2.legend), delete t2.legend;
}, beforeUpdate(t2, e2, i2) {
  const s2 = t2.legend;
  sc.configure(t2, s2, i2), s2.options = i2;
}, afterUpdate(t2) {
  const e2 = t2.legend;
  e2.buildLabels(), e2.adjustHitBoxes();
}, afterEvent(t2, e2) {
  e2.replay || t2.legend.handleEvent(e2.event);
}, defaults: { display: true, position: "top", align: "center", fullSize: true, reverse: false, weight: 1e3, onClick(t2, e2, i2) {
  const s2 = e2.datasetIndex, n2 = i2.chart;
  n2.isDatasetVisible(s2) ? (n2.hide(s2), e2.hidden = true) : (n2.show(s2), e2.hidden = false);
}, onHover: null, onLeave: null, labels: { color: (t2) => t2.chart.options.color, boxWidth: 40, padding: 10, generateLabels(t2) {
  const e2 = t2.data.datasets, { labels: { usePointStyle: i2, pointStyle: s2, textAlign: n2, color: r2, useBorderRadius: o2, borderRadius: a2 } } = t2.legend.options;
  return t2._getSortedDatasetMetas().map((t3) => {
    const l2 = t3.controller.getStyle(i2 ? 0 : void 0), h2 = ml(l2.borderWidth);
    return { text: e2[t3.index].label, fillStyle: l2.backgroundColor, fontColor: r2, hidden: !t3.visible, lineCap: l2.borderCapStyle, lineDash: l2.borderDash, lineDashOffset: l2.borderDashOffset, lineJoin: l2.borderJoinStyle, lineWidth: (h2.width + h2.height) / 4, strokeStyle: l2.borderColor, pointStyle: s2 || l2.pointStyle, rotation: l2.rotation, textAlign: n2 || l2.textAlign, borderRadius: o2 && (a2 || l2.borderRadius), datasetIndex: t3.index };
  }, this);
} }, title: { color: (t2) => t2.chart.options.color, display: false, position: "center", text: "" } }, descriptors: { _scriptable: (t2) => !t2.startsWith("on"), labels: { _scriptable: (t2) => !["generateLabels", "filter", "sort"].includes(t2) } } };
class Title extends bc {
  constructor(t2) {
    super(), this.chart = t2.chart, this.options = t2.options, this.ctx = t2.ctx, this._padding = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t2, e2) {
    const i2 = this.options;
    if (this.left = 0, this.top = 0, !i2.display) return void (this.width = this.height = this.right = this.bottom = 0);
    this.width = this.right = t2, this.height = this.bottom = e2;
    const s2 = Co(i2.text) ? i2.text.length : 1;
    this._padding = ml(i2.padding);
    const n2 = s2 * gl(i2.font).lineHeight + this._padding.height;
    this.isHorizontal() ? this.height = n2 : this.width = n2;
  }
  isHorizontal() {
    const t2 = this.options.position;
    return "top" === t2 || "bottom" === t2;
  }
  _drawArgs(t2) {
    const { top: e2, left: i2, bottom: s2, right: n2, options: r2 } = this, o2 = r2.align;
    let a2, l2, h2, c2 = 0;
    return this.isHorizontal() ? (l2 = Ca(o2, i2, n2), h2 = e2 + t2, a2 = n2 - i2) : ("left" === r2.position ? (l2 = i2 + t2, h2 = Ca(o2, s2, e2), c2 = -0.5 * Ko) : (l2 = n2 - t2, h2 = Ca(o2, e2, s2), c2 = 0.5 * Ko), a2 = s2 - e2), { titleX: l2, titleY: h2, maxWidth: a2, rotation: c2 };
  }
  draw() {
    const t2 = this.ctx, e2 = this.options;
    if (!e2.display) return;
    const i2 = gl(e2.font), s2 = i2.lineHeight / 2 + this._padding.top, { titleX: n2, titleY: r2, maxWidth: o2, rotation: a2 } = this._drawArgs(s2);
    ol(t2, e2.text, 0, 0, i2, { color: e2.color, maxWidth: o2, rotation: a2, textAlign: Sa(e2.align), textBaseline: "middle", translation: [n2, r2] });
  }
}
var Yu = { id: "title", _element: Title, start(t2, e2, i2) {
  !function(t3, e3) {
    const i3 = new Title({ ctx: t3.ctx, options: e3, chart: t3 });
    sc.configure(t3, i3, e3), sc.addBox(t3, i3), t3.titleBlock = i3;
  }(t2, i2);
}, stop(t2) {
  const e2 = t2.titleBlock;
  sc.removeBox(t2, e2), delete t2.titleBlock;
}, beforeUpdate(t2, e2, i2) {
  const s2 = t2.titleBlock;
  sc.configure(t2, s2, i2), s2.options = i2;
}, defaults: { align: "center", display: false, font: { weight: "bold" }, fullSize: true, padding: 10, position: "top", text: "", weight: 2e3 }, defaultRoutes: { color: "color" }, descriptors: { _scriptable: true, _indexable: false } };
const Gu = /* @__PURE__ */ new WeakMap();
var Ju = { id: "subtitle", start(t2, e2, i2) {
  const s2 = new Title({ ctx: t2.ctx, options: i2, chart: t2 });
  sc.configure(t2, s2, i2), sc.addBox(t2, s2), Gu.set(t2, s2);
}, stop(t2) {
  sc.removeBox(t2, Gu.get(t2)), Gu.delete(t2);
}, beforeUpdate(t2, e2, i2) {
  const s2 = Gu.get(t2);
  sc.configure(t2, s2, i2), s2.options = i2;
}, defaults: { align: "center", display: false, font: { weight: "normal" }, fullSize: true, padding: 0, position: "top", text: "", weight: 1500 }, defaultRoutes: { color: "color" }, descriptors: { _scriptable: true, _indexable: false } };
const Qu = { average(t2) {
  if (!t2.length) return false;
  let e2, i2, s2 = /* @__PURE__ */ new Set(), n2 = 0, r2 = 0;
  for (e2 = 0, i2 = t2.length; e2 < i2; ++e2) {
    const i3 = t2[e2].element;
    if (i3 && i3.hasValue()) {
      const t3 = i3.tooltipPosition();
      s2.add(t3.x), n2 += t3.y, ++r2;
    }
  }
  if (0 === r2 || 0 === s2.size) return false;
  const o2 = [...s2].reduce((t3, e3) => t3 + e3) / s2.size;
  return { x: o2, y: n2 / r2 };
}, nearest(t2, e2) {
  if (!t2.length) return false;
  let i2, s2, n2, r2 = e2.x, o2 = e2.y, a2 = Number.POSITIVE_INFINITY;
  for (i2 = 0, s2 = t2.length; i2 < s2; ++i2) {
    const s3 = t2[i2].element;
    if (s3 && s3.hasValue()) {
      const t3 = ua(e2, s3.getCenterPoint());
      t3 < a2 && (a2 = t3, n2 = s3);
    }
  }
  if (n2) {
    const t3 = n2.tooltipPosition();
    r2 = t3.x, o2 = t3.y;
  }
  return { x: r2, y: o2 };
} };
function Zu(t2, e2) {
  return e2 && (Co(e2) ? Array.prototype.push.apply(t2, e2) : t2.push(e2)), t2;
}
function td(t2) {
  return ("string" == typeof t2 || t2 instanceof String) && t2.indexOf("\n") > -1 ? t2.split("\n") : t2;
}
function ed(t2, e2) {
  const { element: i2, datasetIndex: s2, index: n2 } = e2, r2 = t2.getDatasetMeta(s2).controller, { label: o2, value: a2 } = r2.getLabelAndValue(n2);
  return { chart: t2, label: o2, parsed: r2.getParsed(n2), raw: t2.data.datasets[s2].data[n2], formattedValue: a2, dataset: r2.getDataset(), dataIndex: n2, datasetIndex: s2, element: i2 };
}
function id(t2, e2) {
  const i2 = t2.chart.ctx, { body: s2, footer: n2, title: r2 } = t2, { boxWidth: o2, boxHeight: a2 } = e2, l2 = gl(e2.bodyFont), h2 = gl(e2.titleFont), c2 = gl(e2.footerFont), u2 = r2.length, d2 = n2.length, f2 = s2.length, p2 = ml(e2.padding);
  let m2 = p2.height, g2 = 0, v2 = s2.reduce((t3, e3) => t3 + e3.before.length + e3.lines.length + e3.after.length, 0);
  if (v2 += t2.beforeBody.length + t2.afterBody.length, u2 && (m2 += u2 * h2.lineHeight + (u2 - 1) * e2.titleSpacing + e2.titleMarginBottom), v2) {
    m2 += f2 * (e2.displayColors ? Math.max(a2, l2.lineHeight) : l2.lineHeight) + (v2 - f2) * l2.lineHeight + (v2 - 1) * e2.bodySpacing;
  }
  d2 && (m2 += e2.footerMarginTop + d2 * c2.lineHeight + (d2 - 1) * e2.footerSpacing);
  let b2 = 0;
  const _2 = function(t3) {
    g2 = Math.max(g2, i2.measureText(t3).width + b2);
  };
  return i2.save(), i2.font = h2.string, To(t2.title, _2), i2.font = l2.string, To(t2.beforeBody.concat(t2.afterBody), _2), b2 = e2.displayColors ? o2 + 2 + e2.boxPadding : 0, To(s2, (t3) => {
    To(t3.before, _2), To(t3.lines, _2), To(t3.after, _2);
  }), b2 = 0, i2.font = c2.string, To(t2.footer, _2), i2.restore(), g2 += p2.width, { width: g2, height: m2 };
}
function sd(t2, e2, i2, s2) {
  const { x: n2, width: r2 } = i2, { width: o2, chartArea: { left: a2, right: l2 } } = t2;
  let h2 = "center";
  return "center" === s2 ? h2 = n2 <= (a2 + l2) / 2 ? "left" : "right" : n2 <= r2 / 2 ? h2 = "left" : n2 >= o2 - r2 / 2 && (h2 = "right"), function(t3, e3, i3, s3) {
    const { x: n3, width: r3 } = s3, o3 = i3.caretSize + i3.caretPadding;
    return "left" === t3 && n3 + r3 + o3 > e3.width || "right" === t3 && n3 - r3 - o3 < 0 || void 0;
  }(h2, t2, e2, i2) && (h2 = "center"), h2;
}
function nd(t2, e2, i2) {
  const s2 = i2.yAlign || e2.yAlign || function(t3, e3) {
    const { y: i3, height: s3 } = e3;
    return i3 < s3 / 2 ? "top" : i3 > t3.height - s3 / 2 ? "bottom" : "center";
  }(t2, i2);
  return { xAlign: i2.xAlign || e2.xAlign || sd(t2, e2, i2, s2), yAlign: s2 };
}
function rd(t2, e2, i2, s2) {
  const { caretSize: n2, caretPadding: r2, cornerRadius: o2 } = t2, { xAlign: a2, yAlign: l2 } = i2, h2 = n2 + r2, { topLeft: c2, topRight: u2, bottomLeft: d2, bottomRight: f2 } = pl(o2);
  let p2 = function(t3, e3) {
    let { x: i3, width: s3 } = t3;
    return "right" === e3 ? i3 -= s3 : "center" === e3 && (i3 -= s3 / 2), i3;
  }(e2, a2);
  const m2 = function(t3, e3, i3) {
    let { y: s3, height: n3 } = t3;
    return "top" === e3 ? s3 += i3 : s3 -= "bottom" === e3 ? n3 + i3 : n3 / 2, s3;
  }(e2, l2, h2);
  return "center" === l2 ? "left" === a2 ? p2 += h2 : "right" === a2 && (p2 -= h2) : "left" === a2 ? p2 -= Math.max(c2, d2) + n2 : "right" === a2 && (p2 += Math.max(u2, f2) + n2), { x: ma(p2, 0, s2.width - e2.width), y: ma(m2, 0, s2.height - e2.height) };
}
function od(t2, e2, i2) {
  const s2 = ml(i2.padding);
  return "center" === e2 ? t2.x + t2.width / 2 : "right" === e2 ? t2.x + t2.width - s2.right : t2.x + s2.left;
}
function ad(t2) {
  return Zu([], td(t2));
}
function ld(t2, e2) {
  const i2 = e2 && e2.dataset && e2.dataset.tooltip && e2.dataset.tooltip.callbacks;
  return i2 ? t2.override(i2) : t2;
}
const hd = { beforeTitle: ko, title(t2) {
  if (t2.length > 0) {
    const e2 = t2[0], i2 = e2.chart.data.labels, s2 = i2 ? i2.length : 0;
    if (this && this.options && "dataset" === this.options.mode) return e2.dataset.label || "";
    if (e2.label) return e2.label;
    if (s2 > 0 && e2.dataIndex < s2) return i2[e2.dataIndex];
  }
  return "";
}, afterTitle: ko, beforeBody: ko, beforeLabel: ko, label(t2) {
  if (this && this.options && "dataset" === this.options.mode) return t2.label + ": " + t2.formattedValue || t2.formattedValue;
  let e2 = t2.dataset.label || "";
  e2 && (e2 += ": ");
  const i2 = t2.formattedValue;
  return So(i2) || (e2 += i2), e2;
}, labelColor(t2) {
  const e2 = t2.chart.getDatasetMeta(t2.datasetIndex).controller.getStyle(t2.dataIndex);
  return { borderColor: e2.borderColor, backgroundColor: e2.backgroundColor, borderWidth: e2.borderWidth, borderDash: e2.borderDash, borderDashOffset: e2.borderDashOffset, borderRadius: 0 };
}, labelTextColor() {
  return this.options.bodyColor;
}, labelPointStyle(t2) {
  const e2 = t2.chart.getDatasetMeta(t2.datasetIndex).controller.getStyle(t2.dataIndex);
  return { pointStyle: e2.pointStyle, rotation: e2.rotation };
}, afterLabel: ko, afterBody: ko, beforeFooter: ko, footer: ko, afterFooter: ko };
function cd(t2, e2, i2, s2) {
  const n2 = t2[e2].call(i2, s2);
  return void 0 === n2 ? hd[e2].call(i2, s2) : n2;
}
class Tooltip extends bc {
  constructor(t2) {
    super(), this.opacity = 0, this._active = [], this._eventPosition = void 0, this._size = void 0, this._cachedAnimations = void 0, this._tooltipItems = [], this.$animations = void 0, this.$context = void 0, this.chart = t2.chart, this.options = t2.options, this.dataPoints = void 0, this.title = void 0, this.beforeBody = void 0, this.body = void 0, this.afterBody = void 0, this.footer = void 0, this.xAlign = void 0, this.yAlign = void 0, this.x = void 0, this.y = void 0, this.height = void 0, this.width = void 0, this.caretX = void 0, this.caretY = void 0, this.labelColors = void 0, this.labelPointStyles = void 0, this.labelTextColors = void 0;
  }
  initialize(t2) {
    this.options = t2, this._cachedAnimations = void 0, this.$context = void 0;
  }
  _resolveAnimations() {
    const t2 = this._cachedAnimations;
    if (t2) return t2;
    const e2 = this.chart, i2 = this.options.setContext(this.getContext()), s2 = i2.enabled && e2.options.animation && i2.animations, n2 = new Animations(this.chart, s2);
    return s2._cacheable && (this._cachedAnimations = Object.freeze(n2)), n2;
  }
  getContext() {
    return this.$context || (this.$context = (t2 = this.chart.getContext(), e2 = this, i2 = this._tooltipItems, bl(t2, { tooltip: e2, tooltipItems: i2, type: "tooltip" })));
    var t2, e2, i2;
  }
  getTitle(t2, e2) {
    const { callbacks: i2 } = e2, s2 = cd(i2, "beforeTitle", this, t2), n2 = cd(i2, "title", this, t2), r2 = cd(i2, "afterTitle", this, t2);
    let o2 = [];
    return o2 = Zu(o2, td(s2)), o2 = Zu(o2, td(n2)), o2 = Zu(o2, td(r2)), o2;
  }
  getBeforeBody(t2, e2) {
    return ad(cd(e2.callbacks, "beforeBody", this, t2));
  }
  getBody(t2, e2) {
    const { callbacks: i2 } = e2, s2 = [];
    return To(t2, (t3) => {
      const e3 = { before: [], lines: [], after: [] }, n2 = ld(i2, t3);
      Zu(e3.before, td(cd(n2, "beforeLabel", this, t3))), Zu(e3.lines, cd(n2, "label", this, t3)), Zu(e3.after, td(cd(n2, "afterLabel", this, t3))), s2.push(e3);
    }), s2;
  }
  getAfterBody(t2, e2) {
    return ad(cd(e2.callbacks, "afterBody", this, t2));
  }
  getFooter(t2, e2) {
    const { callbacks: i2 } = e2, s2 = cd(i2, "beforeFooter", this, t2), n2 = cd(i2, "footer", this, t2), r2 = cd(i2, "afterFooter", this, t2);
    let o2 = [];
    return o2 = Zu(o2, td(s2)), o2 = Zu(o2, td(n2)), o2 = Zu(o2, td(r2)), o2;
  }
  _createItems(t2) {
    const e2 = this._active, i2 = this.chart.data, s2 = [], n2 = [], r2 = [];
    let o2, a2, l2 = [];
    for (o2 = 0, a2 = e2.length; o2 < a2; ++o2) l2.push(ed(this.chart, e2[o2]));
    return t2.filter && (l2 = l2.filter((e3, s3, n3) => t2.filter(e3, s3, n3, i2))), t2.itemSort && (l2 = l2.sort((e3, s3) => t2.itemSort(e3, s3, i2))), To(l2, (e3) => {
      const i3 = ld(t2.callbacks, e3);
      s2.push(cd(i3, "labelColor", this, e3)), n2.push(cd(i3, "labelPointStyle", this, e3)), r2.push(cd(i3, "labelTextColor", this, e3));
    }), this.labelColors = s2, this.labelPointStyles = n2, this.labelTextColors = r2, this.dataPoints = l2, l2;
  }
  update(t2, e2) {
    const i2 = this.options.setContext(this.getContext()), s2 = this._active;
    let n2, r2 = [];
    if (s2.length) {
      const t3 = Qu[i2.position].call(this, s2, this._eventPosition);
      r2 = this._createItems(i2), this.title = this.getTitle(r2, i2), this.beforeBody = this.getBeforeBody(r2, i2), this.body = this.getBody(r2, i2), this.afterBody = this.getAfterBody(r2, i2), this.footer = this.getFooter(r2, i2);
      const e3 = this._size = id(this, i2), o2 = Object.assign({}, t3, e3), a2 = nd(this.chart, i2, o2), l2 = rd(i2, o2, a2, this.chart);
      this.xAlign = a2.xAlign, this.yAlign = a2.yAlign, n2 = { opacity: 1, x: l2.x, y: l2.y, width: e3.width, height: e3.height, caretX: t3.x, caretY: t3.y };
    } else 0 !== this.opacity && (n2 = { opacity: 0 });
    this._tooltipItems = r2, this.$context = void 0, n2 && this._resolveAnimations().update(this, n2), t2 && i2.external && i2.external.call(this, { chart: this.chart, tooltip: this, replay: e2 });
  }
  drawCaret(t2, e2, i2, s2) {
    const n2 = this.getCaretPosition(t2, i2, s2);
    e2.lineTo(n2.x1, n2.y1), e2.lineTo(n2.x2, n2.y2), e2.lineTo(n2.x3, n2.y3);
  }
  getCaretPosition(t2, e2, i2) {
    const { xAlign: s2, yAlign: n2 } = this, { caretSize: r2, cornerRadius: o2 } = i2, { topLeft: a2, topRight: l2, bottomLeft: h2, bottomRight: c2 } = pl(o2), { x: u2, y: d2 } = t2, { width: f2, height: p2 } = e2;
    let m2, g2, v2, b2, _2, y2;
    return "center" === n2 ? (_2 = d2 + p2 / 2, "left" === s2 ? (m2 = u2, g2 = m2 - r2, b2 = _2 + r2, y2 = _2 - r2) : (m2 = u2 + f2, g2 = m2 + r2, b2 = _2 - r2, y2 = _2 + r2), v2 = m2) : (g2 = "left" === s2 ? u2 + Math.max(a2, h2) + r2 : "right" === s2 ? u2 + f2 - Math.max(l2, c2) - r2 : this.caretX, "top" === n2 ? (b2 = d2, _2 = b2 - r2, m2 = g2 - r2, v2 = g2 + r2) : (b2 = d2 + p2, _2 = b2 + r2, m2 = g2 + r2, v2 = g2 - r2), y2 = b2), { x1: m2, x2: g2, x3: v2, y1: b2, y2: _2, y3: y2 };
  }
  drawTitle(t2, e2, i2) {
    const s2 = this.title, n2 = s2.length;
    let r2, o2, a2;
    if (n2) {
      const l2 = eh(i2.rtl, this.x, this.width);
      for (t2.x = od(this, i2.titleAlign, i2), e2.textAlign = l2.textAlign(i2.titleAlign), e2.textBaseline = "middle", r2 = gl(i2.titleFont), o2 = i2.titleSpacing, e2.fillStyle = i2.titleColor, e2.font = r2.string, a2 = 0; a2 < n2; ++a2) e2.fillText(s2[a2], l2.x(t2.x), t2.y + r2.lineHeight / 2), t2.y += r2.lineHeight + o2, a2 + 1 === n2 && (t2.y += i2.titleMarginBottom - o2);
    }
  }
  _drawColorBox(t2, e2, i2, s2, n2) {
    const r2 = this.labelColors[i2], o2 = this.labelPointStyles[i2], { boxHeight: a2, boxWidth: l2 } = n2, h2 = gl(n2.bodyFont), c2 = od(this, "left", n2), u2 = s2.x(c2), d2 = a2 < h2.lineHeight ? (h2.lineHeight - a2) / 2 : 0, f2 = e2.y + d2;
    if (n2.usePointStyle) {
      const e3 = { radius: Math.min(l2, a2) / 2, pointStyle: o2.pointStyle, rotation: o2.rotation, borderWidth: 1 }, i3 = s2.leftForLtr(u2, l2) + l2 / 2, h3 = f2 + a2 / 2;
      t2.strokeStyle = n2.multiKeyBackground, t2.fillStyle = n2.multiKeyBackground, Ja(t2, e3, i3, h3), t2.strokeStyle = r2.borderColor, t2.fillStyle = r2.backgroundColor, Ja(t2, e3, i3, h3);
    } else {
      t2.lineWidth = zo(r2.borderWidth) ? Math.max(...Object.values(r2.borderWidth)) : r2.borderWidth || 1, t2.strokeStyle = r2.borderColor, t2.setLineDash(r2.borderDash || []), t2.lineDashOffset = r2.borderDashOffset || 0;
      const e3 = s2.leftForLtr(u2, l2), i3 = s2.leftForLtr(s2.xPlus(u2, 1), l2 - 2), o3 = pl(r2.borderRadius);
      Object.values(o3).some((t3) => 0 !== t3) ? (t2.beginPath(), t2.fillStyle = n2.multiKeyBackground, al(t2, { x: e3, y: f2, w: l2, h: a2, radius: o3 }), t2.fill(), t2.stroke(), t2.fillStyle = r2.backgroundColor, t2.beginPath(), al(t2, { x: i3, y: f2 + 1, w: l2 - 2, h: a2 - 2, radius: o3 }), t2.fill()) : (t2.fillStyle = n2.multiKeyBackground, t2.fillRect(e3, f2, l2, a2), t2.strokeRect(e3, f2, l2, a2), t2.fillStyle = r2.backgroundColor, t2.fillRect(i3, f2 + 1, l2 - 2, a2 - 2));
    }
    t2.fillStyle = this.labelTextColors[i2];
  }
  drawBody(t2, e2, i2) {
    const { body: s2 } = this, { bodySpacing: n2, bodyAlign: r2, displayColors: o2, boxHeight: a2, boxWidth: l2, boxPadding: h2 } = i2, c2 = gl(i2.bodyFont);
    let u2 = c2.lineHeight, d2 = 0;
    const f2 = eh(i2.rtl, this.x, this.width), p2 = function(i3) {
      e2.fillText(i3, f2.x(t2.x + d2), t2.y + u2 / 2), t2.y += u2 + n2;
    }, m2 = f2.textAlign(r2);
    let g2, v2, b2, _2, y2, x2, w2;
    for (e2.textAlign = r2, e2.textBaseline = "middle", e2.font = c2.string, t2.x = od(this, m2, i2), e2.fillStyle = i2.bodyColor, To(this.beforeBody, p2), d2 = o2 && "right" !== m2 ? "center" === r2 ? l2 / 2 + h2 : l2 + 2 + h2 : 0, _2 = 0, x2 = s2.length; _2 < x2; ++_2) {
      for (g2 = s2[_2], v2 = this.labelTextColors[_2], e2.fillStyle = v2, To(g2.before, p2), b2 = g2.lines, o2 && b2.length && (this._drawColorBox(e2, t2, _2, f2, i2), u2 = Math.max(c2.lineHeight, a2)), y2 = 0, w2 = b2.length; y2 < w2; ++y2) p2(b2[y2]), u2 = c2.lineHeight;
      To(g2.after, p2);
    }
    d2 = 0, u2 = c2.lineHeight, To(this.afterBody, p2), t2.y -= n2;
  }
  drawFooter(t2, e2, i2) {
    const s2 = this.footer, n2 = s2.length;
    let r2, o2;
    if (n2) {
      const a2 = eh(i2.rtl, this.x, this.width);
      for (t2.x = od(this, i2.footerAlign, i2), t2.y += i2.footerMarginTop, e2.textAlign = a2.textAlign(i2.footerAlign), e2.textBaseline = "middle", r2 = gl(i2.footerFont), e2.fillStyle = i2.footerColor, e2.font = r2.string, o2 = 0; o2 < n2; ++o2) e2.fillText(s2[o2], a2.x(t2.x), t2.y + r2.lineHeight / 2), t2.y += r2.lineHeight + i2.footerSpacing;
    }
  }
  drawBackground(t2, e2, i2, s2) {
    const { xAlign: n2, yAlign: r2 } = this, { x: o2, y: a2 } = t2, { width: l2, height: h2 } = i2, { topLeft: c2, topRight: u2, bottomLeft: d2, bottomRight: f2 } = pl(s2.cornerRadius);
    e2.fillStyle = s2.backgroundColor, e2.strokeStyle = s2.borderColor, e2.lineWidth = s2.borderWidth, e2.beginPath(), e2.moveTo(o2 + c2, a2), "top" === r2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2 + l2 - u2, a2), e2.quadraticCurveTo(o2 + l2, a2, o2 + l2, a2 + u2), "center" === r2 && "right" === n2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2 + l2, a2 + h2 - f2), e2.quadraticCurveTo(o2 + l2, a2 + h2, o2 + l2 - f2, a2 + h2), "bottom" === r2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2 + d2, a2 + h2), e2.quadraticCurveTo(o2, a2 + h2, o2, a2 + h2 - d2), "center" === r2 && "left" === n2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2, a2 + c2), e2.quadraticCurveTo(o2, a2, o2 + c2, a2), e2.closePath(), e2.fill(), s2.borderWidth > 0 && e2.stroke();
  }
  _updateAnimationTarget(t2) {
    const e2 = this.chart, i2 = this.$animations, s2 = i2 && i2.x, n2 = i2 && i2.y;
    if (s2 || n2) {
      const i3 = Qu[t2.position].call(this, this._active, this._eventPosition);
      if (!i3) return;
      const r2 = this._size = id(this, t2), o2 = Object.assign({}, i3, this._size), a2 = nd(e2, t2, o2), l2 = rd(t2, o2, a2, e2);
      s2._to === l2.x && n2._to === l2.y || (this.xAlign = a2.xAlign, this.yAlign = a2.yAlign, this.width = r2.width, this.height = r2.height, this.caretX = i3.x, this.caretY = i3.y, this._resolveAnimations().update(this, l2));
    }
  }
  _willRender() {
    return !!this.opacity;
  }
  draw(t2) {
    const e2 = this.options.setContext(this.getContext());
    let i2 = this.opacity;
    if (!i2) return;
    this._updateAnimationTarget(e2);
    const s2 = { width: this.width, height: this.height }, n2 = { x: this.x, y: this.y };
    i2 = Math.abs(i2) < 1e-3 ? 0 : i2;
    const r2 = ml(e2.padding), o2 = this.title.length || this.beforeBody.length || this.body.length || this.afterBody.length || this.footer.length;
    e2.enabled && o2 && (t2.save(), t2.globalAlpha = i2, this.drawBackground(n2, t2, s2, e2), ih(t2, e2.textDirection), n2.y += r2.top, this.drawTitle(n2, t2, e2), this.drawBody(n2, t2, e2), this.drawFooter(n2, t2, e2), sh(t2, e2.textDirection), t2.restore());
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t2, e2) {
    const i2 = this._active, s2 = t2.map(({ datasetIndex: t3, index: e3 }) => {
      const i3 = this.chart.getDatasetMeta(t3);
      if (!i3) throw new Error("Cannot find a dataset at index " + t3);
      return { datasetIndex: t3, element: i3.data[e3], index: e3 };
    }), n2 = !Lo(i2, s2), r2 = this._positionChanged(s2, e2);
    (n2 || r2) && (this._active = s2, this._eventPosition = e2, this._ignoreReplayEvents = true, this.update(true));
  }
  handleEvent(t2, e2, i2 = true) {
    if (e2 && this._ignoreReplayEvents) return false;
    this._ignoreReplayEvents = false;
    const s2 = this.options, n2 = this._active || [], r2 = this._getActiveElements(t2, n2, e2, i2), o2 = this._positionChanged(r2, t2), a2 = e2 || !Lo(r2, n2) || o2;
    return a2 && (this._active = r2, (s2.enabled || s2.external) && (this._eventPosition = { x: t2.x, y: t2.y }, this.update(true, e2))), a2;
  }
  _getActiveElements(t2, e2, i2, s2) {
    const n2 = this.options;
    if ("mouseout" === t2.type) return [];
    if (!s2) return e2.filter((t3) => this.chart.data.datasets[t3.datasetIndex] && void 0 !== this.chart.getDatasetMeta(t3.datasetIndex).controller.getParsed(t3.index));
    const r2 = this.chart.getElementsAtEventForMode(t2, n2.mode, n2, i2);
    return n2.reverse && r2.reverse(), r2;
  }
  _positionChanged(t2, e2) {
    const { caretX: i2, caretY: s2, options: n2 } = this, r2 = Qu[n2.position].call(this, t2, e2);
    return false !== r2 && (i2 !== r2.x || s2 !== r2.y);
  }
}
__publicField(Tooltip, "positioners", Qu);
var ud = { id: "tooltip", _element: Tooltip, positioners: Qu, afterInit(t2, e2, i2) {
  i2 && (t2.tooltip = new Tooltip({ chart: t2, options: i2 }));
}, beforeUpdate(t2, e2, i2) {
  t2.tooltip && t2.tooltip.initialize(i2);
}, reset(t2, e2, i2) {
  t2.tooltip && t2.tooltip.initialize(i2);
}, afterDraw(t2) {
  const e2 = t2.tooltip;
  if (e2 && e2._willRender()) {
    const i2 = { tooltip: e2 };
    if (false === t2.notifyPlugins("beforeTooltipDraw", { ...i2, cancelable: true })) return;
    e2.draw(t2.ctx), t2.notifyPlugins("afterTooltipDraw", i2);
  }
}, afterEvent(t2, e2) {
  if (t2.tooltip) {
    const i2 = e2.replay;
    t2.tooltip.handleEvent(e2.event, i2, e2.inChartArea) && (e2.changed = true);
  }
}, defaults: { enabled: true, external: null, position: "average", backgroundColor: "rgba(0,0,0,0.8)", titleColor: "#fff", titleFont: { weight: "bold" }, titleSpacing: 2, titleMarginBottom: 6, titleAlign: "left", bodyColor: "#fff", bodySpacing: 2, bodyFont: {}, bodyAlign: "left", footerColor: "#fff", footerSpacing: 2, footerMarginTop: 6, footerFont: { weight: "bold" }, footerAlign: "left", padding: 6, caretPadding: 2, caretSize: 5, cornerRadius: 6, boxHeight: (t2, e2) => e2.bodyFont.size, boxWidth: (t2, e2) => e2.bodyFont.size, multiKeyBackground: "#fff", displayColors: true, boxPadding: 0, borderColor: "rgba(0,0,0,0)", borderWidth: 0, animation: { duration: 400, easing: "easeOutQuart" }, animations: { numbers: { type: "number", properties: ["x", "y", "width", "height", "caretX", "caretY"] }, opacity: { easing: "linear", duration: 200 } }, callbacks: hd }, defaultRoutes: { bodyFont: "font", footerFont: "font", titleFont: "font" }, descriptors: { _scriptable: (t2) => "filter" !== t2 && "itemSort" !== t2 && "external" !== t2, _indexable: false, callbacks: { _scriptable: false, _indexable: false }, animation: { _fallback: false }, animations: { _fallback: "animation" } }, additionalOptionScopes: ["interaction"] }, dd = Object.freeze({ __proto__: null, Colors: Cu, Decimation: Du, Filler: qu, Legend: Uu, SubTitle: Ju, Title: Yu, Tooltip: ud });
function fd(t2, e2, i2, s2) {
  const n2 = t2.indexOf(e2);
  if (-1 === n2) return ((t3, e3, i3, s3) => ("string" == typeof e3 ? (i3 = t3.push(e3) - 1, s3.unshift({ index: i3, label: e3 })) : isNaN(e3) && (i3 = null), i3))(t2, e2, i2, s2);
  return n2 !== t2.lastIndexOf(e2) ? i2 : n2;
}
function pd(t2) {
  const e2 = this.getLabels();
  return t2 >= 0 && t2 < e2.length ? e2[t2] : t2;
}
class CategoryScale extends Scale {
  constructor(t2) {
    super(t2), this._startValue = void 0, this._valueRange = 0, this._addedLabels = [];
  }
  init(t2) {
    const e2 = this._addedLabels;
    if (e2.length) {
      const t3 = this.getLabels();
      for (const { index: i2, label: s2 } of e2) t3[i2] === s2 && t3.splice(i2, 1);
      this._addedLabels = [];
    }
    super.init(t2);
  }
  parse(t2, e2) {
    if (So(t2)) return null;
    const i2 = this.getLabels();
    return ((t3, e3) => null === t3 ? null : ma(Math.round(t3), 0, e3))(e2 = isFinite(e2) && i2[e2] === t2 ? e2 : fd(i2, t2, Ro(e2, t2), this._addedLabels), i2.length - 1);
  }
  determineDataLimits() {
    const { minDefined: t2, maxDefined: e2 } = this.getUserBounds();
    let { min: i2, max: s2 } = this.getMinMax(true);
    "ticks" === this.options.bounds && (t2 || (i2 = 0), e2 || (s2 = this.getLabels().length - 1)), this.min = i2, this.max = s2;
  }
  buildTicks() {
    const t2 = this.min, e2 = this.max, i2 = this.options.offset, s2 = [];
    let n2 = this.getLabels();
    n2 = 0 === t2 && e2 === n2.length - 1 ? n2 : n2.slice(t2, e2 + 1), this._valueRange = Math.max(n2.length - (i2 ? 0 : 1), 1), this._startValue = this.min - (i2 ? 0.5 : 0);
    for (let i3 = t2; i3 <= e2; i3++) s2.push({ value: i3 });
    return s2;
  }
  getLabelForValue(t2) {
    return pd.call(this, t2);
  }
  configure() {
    super.configure(), this.isHorizontal() || (this._reversePixels = !this._reversePixels);
  }
  getPixelForValue(t2) {
    return "number" != typeof t2 && (t2 = this.parse(t2)), null === t2 ? NaN : this.getPixelForDecimal((t2 - this._startValue) / this._valueRange);
  }
  getPixelForTick(t2) {
    const e2 = this.ticks;
    return t2 < 0 || t2 > e2.length - 1 ? null : this.getPixelForValue(e2[t2].value);
  }
  getValueForPixel(t2) {
    return Math.round(this._startValue + this.getDecimalForPixel(t2) * this._valueRange);
  }
  getBasePixel() {
    return this.bottom;
  }
}
__publicField(CategoryScale, "id", "category");
__publicField(CategoryScale, "defaults", { ticks: { callback: pd } });
function md(t2, e2) {
  const i2 = [], { bounds: s2, step: n2, min: r2, max: o2, precision: a2, count: l2, maxTicks: h2, maxDigits: c2, includeBounds: u2 } = t2, d2 = n2 || 1, f2 = h2 - 1, { min: p2, max: m2 } = e2, g2 = !So(r2), v2 = !So(o2), b2 = !So(l2), _2 = (m2 - p2) / (c2 + 1);
  let y2, x2, w2, k2, M2 = na((m2 - p2) / f2 / d2) * d2;
  if (M2 < 1e-14 && !g2 && !v2) return [{ value: p2 }, { value: m2 }];
  k2 = Math.ceil(m2 / M2) - Math.floor(p2 / M2), k2 > f2 && (M2 = na(k2 * M2 / f2 / d2) * d2), So(a2) || (y2 = Math.pow(10, a2), M2 = Math.ceil(M2 * y2) / y2), "ticks" === s2 ? (x2 = Math.floor(p2 / M2) * M2, w2 = Math.ceil(m2 / M2) * M2) : (x2 = p2, w2 = m2), g2 && v2 && n2 && function(t3, e3) {
    const i3 = Math.round(t3);
    return i3 - e3 <= t3 && i3 + e3 >= t3;
  }((o2 - r2) / n2, M2 / 1e3) ? (k2 = Math.round(Math.min((o2 - r2) / M2, h2)), M2 = (o2 - r2) / k2, x2 = r2, w2 = o2) : b2 ? (x2 = g2 ? r2 : x2, w2 = v2 ? o2 : w2, k2 = l2 - 1, M2 = (w2 - x2) / k2) : (k2 = (w2 - x2) / M2, k2 = sa(k2, Math.round(k2), M2 / 1e3) ? Math.round(k2) : Math.ceil(k2));
  const S2 = Math.max(ha(M2), ha(x2));
  y2 = Math.pow(10, So(a2) ? S2 : a2), x2 = Math.round(x2 * y2) / y2, w2 = Math.round(w2 * y2) / y2;
  let C2 = 0;
  for (g2 && (u2 && x2 !== r2 ? (i2.push({ value: r2 }), x2 < r2 && C2++, sa(Math.round((x2 + C2 * M2) * y2) / y2, r2, gd(r2, _2, t2)) && C2++) : x2 < r2 && C2++); C2 < k2; ++C2) {
    const t3 = Math.round((x2 + C2 * M2) * y2) / y2;
    if (v2 && t3 > o2) break;
    i2.push({ value: t3 });
  }
  return v2 && u2 && w2 !== o2 ? i2.length && sa(i2[i2.length - 1].value, o2, gd(o2, _2, t2)) ? i2[i2.length - 1].value = o2 : i2.push({ value: o2 }) : v2 && w2 !== o2 || i2.push({ value: w2 }), i2;
}
function gd(t2, e2, { horizontal: i2, minRotation: s2 }) {
  const n2 = aa(s2), r2 = (i2 ? Math.sin(n2) : Math.cos(n2)) || 1e-3, o2 = 0.75 * e2 * ("" + t2).length;
  return Math.min(e2 / r2, o2);
}
class LinearScaleBase extends Scale {
  constructor(t2) {
    super(t2), this.start = void 0, this.end = void 0, this._startValue = void 0, this._endValue = void 0, this._valueRange = 0;
  }
  parse(t2, e2) {
    return So(t2) || ("number" == typeof t2 || t2 instanceof Number) && !isFinite(+t2) ? null : +t2;
  }
  handleTickRangeOptions() {
    const { beginAtZero: t2 } = this.options, { minDefined: e2, maxDefined: i2 } = this.getUserBounds();
    let { min: s2, max: n2 } = this;
    const r2 = (t3) => s2 = e2 ? s2 : t3, o2 = (t3) => n2 = i2 ? n2 : t3;
    if (t2) {
      const t3 = ia(s2), e3 = ia(n2);
      t3 < 0 && e3 < 0 ? o2(0) : t3 > 0 && e3 > 0 && r2(0);
    }
    if (s2 === n2) {
      let e3 = 0 === n2 ? 1 : Math.abs(0.05 * n2);
      o2(n2 + e3), t2 || r2(s2 - e3);
    }
    this.min = s2, this.max = n2;
  }
  getTickLimit() {
    const t2 = this.options.ticks;
    let e2, { maxTicksLimit: i2, stepSize: s2 } = t2;
    return s2 ? (e2 = Math.ceil(this.max / s2) - Math.floor(this.min / s2) + 1, e2 > 1e3 && (console.warn(`scales.${this.id}.ticks.stepSize: ${s2} would result generating up to ${e2} ticks. Limiting to 1000.`), e2 = 1e3)) : (e2 = this.computeTickLimit(), i2 = i2 || 11), i2 && (e2 = Math.min(i2, e2)), e2;
  }
  computeTickLimit() {
    return Number.POSITIVE_INFINITY;
  }
  buildTicks() {
    const t2 = this.options, e2 = t2.ticks;
    let i2 = this.getTickLimit();
    i2 = Math.max(2, i2);
    const s2 = md({ maxTicks: i2, bounds: t2.bounds, min: t2.min, max: t2.max, precision: e2.precision, step: e2.stepSize, count: e2.count, maxDigits: this._maxDigits(), horizontal: this.isHorizontal(), minRotation: e2.minRotation || 0, includeBounds: false !== e2.includeBounds }, this._range || this);
    return "ticks" === t2.bounds && oa(s2, this, "value"), t2.reverse ? (s2.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), s2;
  }
  configure() {
    const t2 = this.ticks;
    let e2 = this.min, i2 = this.max;
    if (super.configure(), this.options.offset && t2.length) {
      const s2 = (i2 - e2) / Math.max(t2.length - 1, 1) / 2;
      e2 -= s2, i2 += s2;
    }
    this._startValue = e2, this._endValue = i2, this._valueRange = i2 - e2;
  }
  getLabelForValue(t2) {
    return Na(t2, this.chart.options.locale, this.options.ticks.format);
  }
}
class LinearScale extends LinearScaleBase {
  determineDataLimits() {
    const { min: t2, max: e2 } = this.getMinMax(true);
    this.min = $o(t2) ? t2 : 0, this.max = $o(e2) ? e2 : 1, this.handleTickRangeOptions();
  }
  computeTickLimit() {
    const t2 = this.isHorizontal(), e2 = t2 ? this.width : this.height, i2 = aa(this.options.ticks.minRotation), s2 = (t2 ? Math.sin(i2) : Math.cos(i2)) || 1e-3, n2 = this._resolveTickFontOptions(0);
    return Math.ceil(e2 / Math.min(40, n2.lineHeight / s2));
  }
  getPixelForValue(t2) {
    return null === t2 ? NaN : this.getPixelForDecimal((t2 - this._startValue) / this._valueRange);
  }
  getValueForPixel(t2) {
    return this._startValue + this.getDecimalForPixel(t2) * this._valueRange;
  }
}
__publicField(LinearScale, "id", "linear");
__publicField(LinearScale, "defaults", { ticks: { callback: Ia.formatters.numeric } });
const vd = (t2) => Math.floor(ea(t2)), bd = (t2, e2) => Math.pow(10, vd(t2) + e2);
function _d2(t2) {
  return 1 === t2 / Math.pow(10, vd(t2));
}
function yd(t2, e2, i2) {
  const s2 = Math.pow(10, i2), n2 = Math.floor(t2 / s2);
  return Math.ceil(e2 / s2) - n2;
}
function xd(t2, { min: e2, max: i2 }) {
  e2 = Do(t2.min, e2);
  const s2 = [], n2 = vd(e2);
  let r2 = function(t3, e3) {
    let i3 = vd(e3 - t3);
    for (; yd(t3, e3, i3) > 10; ) i3++;
    for (; yd(t3, e3, i3) < 10; ) i3--;
    return Math.min(i3, vd(t3));
  }(e2, i2), o2 = r2 < 0 ? Math.pow(10, Math.abs(r2)) : 1;
  const a2 = Math.pow(10, r2), l2 = n2 > r2 ? Math.pow(10, n2) : 0, h2 = Math.round((e2 - l2) * o2) / o2, c2 = Math.floor((e2 - l2) / a2 / 10) * a2 * 10;
  let u2 = Math.floor((h2 - c2) / Math.pow(10, r2)), d2 = Do(t2.min, Math.round((l2 + c2 + u2 * Math.pow(10, r2)) * o2) / o2);
  for (; d2 < i2; ) s2.push({ value: d2, major: _d2(d2), significand: u2 }), u2 >= 10 ? u2 = u2 < 15 ? 15 : 20 : u2++, u2 >= 20 && (r2++, u2 = 2, o2 = r2 >= 0 ? 1 : o2), d2 = Math.round((l2 + c2 + u2 * Math.pow(10, r2)) * o2) / o2;
  const f2 = Do(t2.max, d2);
  return s2.push({ value: f2, major: _d2(f2), significand: u2 }), s2;
}
class LogarithmicScale extends Scale {
  constructor(t2) {
    super(t2), this.start = void 0, this.end = void 0, this._startValue = void 0, this._valueRange = 0;
  }
  parse(t2, e2) {
    const i2 = LinearScaleBase.prototype.parse.apply(this, [t2, e2]);
    if (0 !== i2) return $o(i2) && i2 > 0 ? i2 : null;
    this._zero = true;
  }
  determineDataLimits() {
    const { min: t2, max: e2 } = this.getMinMax(true);
    this.min = $o(t2) ? Math.max(0, t2) : null, this.max = $o(e2) ? Math.max(0, e2) : null, this.options.beginAtZero && (this._zero = true), this._zero && this.min !== this._suggestedMin && !$o(this._userMin) && (this.min = t2 === bd(this.min, 0) ? bd(this.min, -1) : bd(this.min, 0)), this.handleTickRangeOptions();
  }
  handleTickRangeOptions() {
    const { minDefined: t2, maxDefined: e2 } = this.getUserBounds();
    let i2 = this.min, s2 = this.max;
    const n2 = (e3) => i2 = t2 ? i2 : e3, r2 = (t3) => s2 = e2 ? s2 : t3;
    i2 === s2 && (i2 <= 0 ? (n2(1), r2(10)) : (n2(bd(i2, -1)), r2(bd(s2, 1)))), i2 <= 0 && n2(bd(s2, -1)), s2 <= 0 && r2(bd(i2, 1)), this.min = i2, this.max = s2;
  }
  buildTicks() {
    const t2 = this.options, e2 = xd({ min: this._userMin, max: this._userMax }, this);
    return "ticks" === t2.bounds && oa(e2, this, "value"), t2.reverse ? (e2.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), e2;
  }
  getLabelForValue(t2) {
    return void 0 === t2 ? "0" : Na(t2, this.chart.options.locale, this.options.ticks.format);
  }
  configure() {
    const t2 = this.min;
    super.configure(), this._startValue = ea(t2), this._valueRange = ea(this.max) - ea(t2);
  }
  getPixelForValue(t2) {
    return void 0 !== t2 && 0 !== t2 || (t2 = this.min), null === t2 || isNaN(t2) ? NaN : this.getPixelForDecimal(t2 === this.min ? 0 : (ea(t2) - this._startValue) / this._valueRange);
  }
  getValueForPixel(t2) {
    const e2 = this.getDecimalForPixel(t2);
    return Math.pow(10, this._startValue + e2 * this._valueRange);
  }
}
__publicField(LogarithmicScale, "id", "logarithmic");
__publicField(LogarithmicScale, "defaults", { ticks: { callback: Ia.formatters.logarithmic, major: { enabled: true } } });
function wd(t2) {
  const e2 = t2.ticks;
  if (e2.display && t2.display) {
    const t3 = ml(e2.backdropPadding);
    return Ro(e2.font && e2.font.size, Xa.font.size) + t3.height;
  }
  return 0;
}
function kd(t2, e2, i2, s2, n2) {
  return t2 === s2 || t2 === n2 ? { start: e2 - i2 / 2, end: e2 + i2 / 2 } : t2 < s2 || t2 > n2 ? { start: e2 - i2, end: e2 } : { start: e2, end: e2 + i2 };
}
function Md(t2) {
  const e2 = { l: t2.left + t2._padding.left, r: t2.right - t2._padding.right, t: t2.top + t2._padding.top, b: t2.bottom - t2._padding.bottom }, i2 = Object.assign({}, e2), s2 = [], n2 = [], r2 = t2._pointLabels.length, o2 = t2.options.pointLabels, a2 = o2.centerPointLabels ? Ko / r2 : 0;
  for (let u2 = 0; u2 < r2; u2++) {
    const r3 = o2.setContext(t2.getPointLabelContext(u2));
    n2[u2] = r3.padding;
    const d2 = t2.getPointPosition(u2, t2.drawingArea + n2[u2], a2), f2 = gl(r3.font), p2 = (l2 = t2.ctx, h2 = f2, c2 = Co(c2 = t2._pointLabels[u2]) ? c2 : [c2], { w: Ua(l2, h2.string, c2), h: c2.length * h2.lineHeight });
    s2[u2] = p2;
    const m2 = fa(t2.getIndexAngle(u2) + a2), g2 = Math.round(la(m2));
    Sd(i2, e2, m2, kd(g2, d2.x, p2.w, 0, 180), kd(g2, d2.y, p2.h, 90, 270));
  }
  var l2, h2, c2;
  t2.setCenterPoint(e2.l - i2.l, i2.r - e2.r, e2.t - i2.t, i2.b - e2.b), t2._pointLabelItems = function(t3, e3, i3) {
    const s3 = [], n3 = t3._pointLabels.length, r3 = t3.options, { centerPointLabels: o3, display: a3 } = r3.pointLabels, l3 = { extra: wd(r3) / 2, additionalAngle: o3 ? Ko / n3 : 0 };
    let h3;
    for (let r4 = 0; r4 < n3; r4++) {
      l3.padding = i3[r4], l3.size = e3[r4];
      const n4 = Cd(t3, r4, l3);
      s3.push(n4), "auto" === a3 && (n4.visible = zd(n4, h3), n4.visible && (h3 = n4));
    }
    return s3;
  }(t2, s2, n2);
}
function Sd(t2, e2, i2, s2, n2) {
  const r2 = Math.abs(Math.sin(i2)), o2 = Math.abs(Math.cos(i2));
  let a2 = 0, l2 = 0;
  s2.start < e2.l ? (a2 = (e2.l - s2.start) / r2, t2.l = Math.min(t2.l, e2.l - a2)) : s2.end > e2.r && (a2 = (s2.end - e2.r) / r2, t2.r = Math.max(t2.r, e2.r + a2)), n2.start < e2.t ? (l2 = (e2.t - n2.start) / o2, t2.t = Math.min(t2.t, e2.t - l2)) : n2.end > e2.b && (l2 = (n2.end - e2.b) / o2, t2.b = Math.max(t2.b, e2.b + l2));
}
function Cd(t2, e2, i2) {
  const s2 = t2.drawingArea, { extra: n2, additionalAngle: r2, padding: o2, size: a2 } = i2, l2 = t2.getPointPosition(e2, s2 + n2 + o2, r2), h2 = Math.round(la(fa(l2.angle + Qo))), c2 = function(t3, e3, i3) {
    90 === i3 || 270 === i3 ? t3 -= e3 / 2 : (i3 > 270 || i3 < 90) && (t3 -= e3);
    return t3;
  }(l2.y, a2.h, h2), u2 = function(t3) {
    if (0 === t3 || 180 === t3) return "center";
    if (t3 < 180) return "left";
    return "right";
  }(h2), d2 = function(t3, e3, i3) {
    "right" === i3 ? t3 -= e3 : "center" === i3 && (t3 -= e3 / 2);
    return t3;
  }(l2.x, a2.w, u2);
  return { visible: true, x: l2.x, y: c2, textAlign: u2, left: d2, top: c2, right: d2 + a2.w, bottom: c2 + a2.h };
}
function zd(t2, e2) {
  if (!e2) return true;
  const { left: i2, top: s2, right: n2, bottom: r2 } = t2;
  return !(Za({ x: i2, y: s2 }, e2) || Za({ x: i2, y: r2 }, e2) || Za({ x: n2, y: s2 }, e2) || Za({ x: n2, y: r2 }, e2));
}
function $d(t2, e2, i2) {
  const { left: s2, top: n2, right: r2, bottom: o2 } = i2, { backdropColor: a2 } = e2;
  if (!So(a2)) {
    const i3 = pl(e2.borderRadius), l2 = ml(e2.backdropPadding);
    t2.fillStyle = a2;
    const h2 = s2 - l2.left, c2 = n2 - l2.top, u2 = r2 - s2 + l2.width, d2 = o2 - n2 + l2.height;
    Object.values(i3).some((t3) => 0 !== t3) ? (t2.beginPath(), al(t2, { x: h2, y: c2, w: u2, h: d2, radius: i3 }), t2.fill()) : t2.fillRect(h2, c2, u2, d2);
  }
}
function Dd(t2, e2, i2, s2) {
  const { ctx: n2 } = t2;
  if (i2) n2.arc(t2.xCenter, t2.yCenter, e2, 0, Uo);
  else {
    let i3 = t2.getPointPosition(0, e2);
    n2.moveTo(i3.x, i3.y);
    for (let r2 = 1; r2 < s2; r2++) i3 = t2.getPointPosition(r2, e2), n2.lineTo(i3.x, i3.y);
  }
}
class RadialLinearScale extends LinearScaleBase {
  constructor(t2) {
    super(t2), this.xCenter = void 0, this.yCenter = void 0, this.drawingArea = void 0, this._pointLabels = [], this._pointLabelItems = [];
  }
  setDimensions() {
    const t2 = this._padding = ml(wd(this.options) / 2), e2 = this.width = this.maxWidth - t2.width, i2 = this.height = this.maxHeight - t2.height;
    this.xCenter = Math.floor(this.left + e2 / 2 + t2.left), this.yCenter = Math.floor(this.top + i2 / 2 + t2.top), this.drawingArea = Math.floor(Math.min(e2, i2) / 2);
  }
  determineDataLimits() {
    const { min: t2, max: e2 } = this.getMinMax(false);
    this.min = $o(t2) && !isNaN(t2) ? t2 : 0, this.max = $o(e2) && !isNaN(e2) ? e2 : 0, this.handleTickRangeOptions();
  }
  computeTickLimit() {
    return Math.ceil(this.drawingArea / wd(this.options));
  }
  generateTickLabels(t2) {
    LinearScaleBase.prototype.generateTickLabels.call(this, t2), this._pointLabels = this.getLabels().map((t3, e2) => {
      const i2 = Po(this.options.pointLabels.callback, [t3, e2], this);
      return i2 || 0 === i2 ? i2 : "";
    }).filter((t3, e2) => this.chart.getDataVisibility(e2));
  }
  fit() {
    const t2 = this.options;
    t2.display && t2.pointLabels.display ? Md(this) : this.setCenterPoint(0, 0, 0, 0);
  }
  setCenterPoint(t2, e2, i2, s2) {
    this.xCenter += Math.floor((t2 - e2) / 2), this.yCenter += Math.floor((i2 - s2) / 2), this.drawingArea -= Math.min(this.drawingArea / 2, Math.max(t2, e2, i2, s2));
  }
  getIndexAngle(t2) {
    return fa(t2 * (Uo / (this._pointLabels.length || 1)) + aa(this.options.startAngle || 0));
  }
  getDistanceFromCenterForValue(t2) {
    if (So(t2)) return NaN;
    const e2 = this.drawingArea / (this.max - this.min);
    return this.options.reverse ? (this.max - t2) * e2 : (t2 - this.min) * e2;
  }
  getValueForDistanceFromCenter(t2) {
    if (So(t2)) return NaN;
    const e2 = t2 / (this.drawingArea / (this.max - this.min));
    return this.options.reverse ? this.max - e2 : this.min + e2;
  }
  getPointLabelContext(t2) {
    const e2 = this._pointLabels || [];
    if (t2 >= 0 && t2 < e2.length) {
      const i2 = e2[t2];
      return function(t3, e3, i3) {
        return bl(t3, { label: i3, index: e3, type: "pointLabel" });
      }(this.getContext(), t2, i2);
    }
  }
  getPointPosition(t2, e2, i2 = 0) {
    const s2 = this.getIndexAngle(t2) - Qo + i2;
    return { x: Math.cos(s2) * e2 + this.xCenter, y: Math.sin(s2) * e2 + this.yCenter, angle: s2 };
  }
  getPointPositionForValue(t2, e2) {
    return this.getPointPosition(t2, this.getDistanceFromCenterForValue(e2));
  }
  getBasePosition(t2) {
    return this.getPointPositionForValue(t2 || 0, this.getBaseValue());
  }
  getPointLabelPosition(t2) {
    const { left: e2, top: i2, right: s2, bottom: n2 } = this._pointLabelItems[t2];
    return { left: e2, top: i2, right: s2, bottom: n2 };
  }
  drawBackground() {
    const { backgroundColor: t2, grid: { circular: e2 } } = this.options;
    if (t2) {
      const i2 = this.ctx;
      i2.save(), i2.beginPath(), Dd(this, this.getDistanceFromCenterForValue(this._endValue), e2, this._pointLabels.length), i2.closePath(), i2.fillStyle = t2, i2.fill(), i2.restore();
    }
  }
  drawGrid() {
    const t2 = this.ctx, e2 = this.options, { angleLines: i2, grid: s2, border: n2 } = e2, r2 = this._pointLabels.length;
    let o2, a2, l2;
    if (e2.pointLabels.display && function(t3, e3) {
      const { ctx: i3, options: { pointLabels: s3 } } = t3;
      for (let n3 = e3 - 1; n3 >= 0; n3--) {
        const e4 = t3._pointLabelItems[n3];
        if (!e4.visible) continue;
        const r3 = s3.setContext(t3.getPointLabelContext(n3));
        $d(i3, r3, e4);
        const o3 = gl(r3.font), { x: a3, y: l3, textAlign: h2 } = e4;
        ol(i3, t3._pointLabels[n3], a3, l3 + o3.lineHeight / 2, o3, { color: r3.color, textAlign: h2, textBaseline: "middle" });
      }
    }(this, r2), s2.display && this.ticks.forEach((t3, e3) => {
      if (0 !== e3 || 0 === e3 && this.min < 0) {
        a2 = this.getDistanceFromCenterForValue(t3.value);
        const i3 = this.getContext(e3), o3 = s2.setContext(i3), l3 = n2.setContext(i3);
        !function(t4, e4, i4, s3, n3) {
          const r3 = t4.ctx, o4 = e4.circular, { color: a3, lineWidth: l4 } = e4;
          !o4 && !s3 || !a3 || !l4 || i4 < 0 || (r3.save(), r3.strokeStyle = a3, r3.lineWidth = l4, r3.setLineDash(n3.dash || []), r3.lineDashOffset = n3.dashOffset, r3.beginPath(), Dd(t4, i4, o4, s3), r3.closePath(), r3.stroke(), r3.restore());
        }(this, o3, a2, r2, l3);
      }
    }), i2.display) {
      for (t2.save(), o2 = r2 - 1; o2 >= 0; o2--) {
        const s3 = i2.setContext(this.getPointLabelContext(o2)), { color: n3, lineWidth: r3 } = s3;
        r3 && n3 && (t2.lineWidth = r3, t2.strokeStyle = n3, t2.setLineDash(s3.borderDash), t2.lineDashOffset = s3.borderDashOffset, a2 = this.getDistanceFromCenterForValue(e2.reverse ? this.min : this.max), l2 = this.getPointPosition(o2, a2), t2.beginPath(), t2.moveTo(this.xCenter, this.yCenter), t2.lineTo(l2.x, l2.y), t2.stroke());
      }
      t2.restore();
    }
  }
  drawBorder() {
  }
  drawLabels() {
    const t2 = this.ctx, e2 = this.options, i2 = e2.ticks;
    if (!i2.display) return;
    const s2 = this.getIndexAngle(0);
    let n2, r2;
    t2.save(), t2.translate(this.xCenter, this.yCenter), t2.rotate(s2), t2.textAlign = "center", t2.textBaseline = "middle", this.ticks.forEach((s3, o2) => {
      if (0 === o2 && this.min >= 0 && !e2.reverse) return;
      const a2 = i2.setContext(this.getContext(o2)), l2 = gl(a2.font);
      if (n2 = this.getDistanceFromCenterForValue(this.ticks[o2].value), a2.showLabelBackdrop) {
        t2.font = l2.string, r2 = t2.measureText(s3.label).width, t2.fillStyle = a2.backdropColor;
        const e3 = ml(a2.backdropPadding);
        t2.fillRect(-r2 / 2 - e3.left, -n2 - l2.size / 2 - e3.top, r2 + e3.width, l2.size + e3.height);
      }
      ol(t2, s3.label, 0, -n2, l2, { color: a2.color, strokeColor: a2.textStrokeColor, strokeWidth: a2.textStrokeWidth });
    }), t2.restore();
  }
  drawTitle() {
  }
}
__publicField(RadialLinearScale, "id", "radialLinear");
__publicField(RadialLinearScale, "defaults", { display: true, animate: true, position: "chartArea", angleLines: { display: true, lineWidth: 1, borderDash: [], borderDashOffset: 0 }, grid: { circular: false }, startAngle: 0, ticks: { showLabelBackdrop: true, callback: Ia.formatters.numeric }, pointLabels: { backdropColor: void 0, backdropPadding: 2, display: true, font: { size: 10 }, callback: (t2) => t2, padding: 5, centerPointLabels: false } });
__publicField(RadialLinearScale, "defaultRoutes", { "angleLines.color": "borderColor", "pointLabels.color": "color", "ticks.color": "color" });
__publicField(RadialLinearScale, "descriptors", { angleLines: { _fallback: "grid" } });
const Rd = { millisecond: { common: true, size: 1, steps: 1e3 }, second: { common: true, size: 1e3, steps: 60 }, minute: { common: true, size: 6e4, steps: 60 }, hour: { common: true, size: 36e5, steps: 24 }, day: { common: true, size: 864e5, steps: 30 }, week: { common: false, size: 6048e5, steps: 4 }, month: { common: true, size: 2628e6, steps: 12 }, quarter: { common: false, size: 7884e6, steps: 4 }, year: { common: true, size: 3154e7 } }, Ed = Object.keys(Rd);
function Pd(t2, e2) {
  return t2 - e2;
}
function Td(t2, e2) {
  if (So(e2)) return null;
  const i2 = t2._adapter, { parser: s2, round: n2, isoWeekday: r2 } = t2._parseOpts;
  let o2 = e2;
  return "function" == typeof s2 && (o2 = s2(o2)), $o(o2) || (o2 = "string" == typeof s2 ? i2.parse(o2, s2) : i2.parse(o2)), null === o2 ? null : (n2 && (o2 = "week" !== n2 || !ra(r2) && true !== r2 ? i2.startOf(o2, n2) : i2.startOf(o2, "isoWeek", r2)), +o2);
}
function Ld(t2, e2, i2, s2) {
  const n2 = Ed.length;
  for (let r2 = Ed.indexOf(t2); r2 < n2 - 1; ++r2) {
    const t3 = Rd[Ed[r2]], n3 = t3.steps ? t3.steps : Number.MAX_SAFE_INTEGER;
    if (t3.common && Math.ceil((i2 - e2) / (n3 * t3.size)) <= s2) return Ed[r2];
  }
  return Ed[n2 - 1];
}
function Vd(t2, e2, i2) {
  if (i2) {
    if (i2.length) {
      const { lo: s2, hi: n2 } = va(i2, e2);
      t2[i2[s2] >= e2 ? i2[s2] : i2[n2]] = true;
    }
  } else t2[e2] = true;
}
function Od(t2, e2, i2) {
  const s2 = [], n2 = {}, r2 = e2.length;
  let o2, a2;
  for (o2 = 0; o2 < r2; ++o2) a2 = e2[o2], n2[a2] = o2, s2.push({ value: a2, major: false });
  return 0 !== r2 && i2 ? function(t3, e3, i3, s3) {
    const n3 = t3._adapter, r3 = +n3.startOf(e3[0].value, s3), o3 = e3[e3.length - 1].value;
    let a3, l2;
    for (a3 = r3; a3 <= o3; a3 = +n3.add(a3, 1, s3)) l2 = i3[a3], l2 >= 0 && (e3[l2].major = true);
    return e3;
  }(t2, s2, n2, i2) : s2;
}
class TimeScale extends Scale {
  constructor(t2) {
    super(t2), this._cache = { data: [], labels: [], all: [] }, this._unit = "day", this._majorUnit = void 0, this._offsets = {}, this._normalized = false, this._parseOpts = void 0;
  }
  init(t2, e2 = {}) {
    const i2 = t2.time || (t2.time = {}), s2 = this._adapter = new Ah(t2.adapters.date);
    s2.init(e2), No(i2.displayFormats, s2.formats()), this._parseOpts = { parser: i2.parser, round: i2.round, isoWeekday: i2.isoWeekday }, super.init(t2), this._normalized = e2.normalized;
  }
  parse(t2, e2) {
    return void 0 === t2 ? null : Td(this, t2);
  }
  beforeLayout() {
    super.beforeLayout(), this._cache = { data: [], labels: [], all: [] };
  }
  determineDataLimits() {
    const t2 = this.options, e2 = this._adapter, i2 = t2.time.unit || "day";
    let { min: s2, max: n2, minDefined: r2, maxDefined: o2 } = this.getUserBounds();
    function a2(t3) {
      r2 || isNaN(t3.min) || (s2 = Math.min(s2, t3.min)), o2 || isNaN(t3.max) || (n2 = Math.max(n2, t3.max));
    }
    r2 && o2 || (a2(this._getLabelBounds()), "ticks" === t2.bounds && "labels" === t2.ticks.source || a2(this.getMinMax(false))), s2 = $o(s2) && !isNaN(s2) ? s2 : +e2.startOf(Date.now(), i2), n2 = $o(n2) && !isNaN(n2) ? n2 : +e2.endOf(Date.now(), i2) + 1, this.min = Math.min(s2, n2 - 1), this.max = Math.max(s2 + 1, n2);
  }
  _getLabelBounds() {
    const t2 = this.getLabelTimestamps();
    let e2 = Number.POSITIVE_INFINITY, i2 = Number.NEGATIVE_INFINITY;
    return t2.length && (e2 = t2[0], i2 = t2[t2.length - 1]), { min: e2, max: i2 };
  }
  buildTicks() {
    const t2 = this.options, e2 = t2.time, i2 = t2.ticks, s2 = "labels" === i2.source ? this.getLabelTimestamps() : this._generate();
    "ticks" === t2.bounds && s2.length && (this.min = this._userMin || s2[0], this.max = this._userMax || s2[s2.length - 1]);
    const n2 = this.min, r2 = function(t3, e3, i3) {
      let s3 = 0, n3 = t3.length;
      for (; s3 < n3 && t3[s3] < e3; ) s3++;
      for (; n3 > s3 && t3[n3 - 1] > i3; ) n3--;
      return s3 > 0 || n3 < t3.length ? t3.slice(s3, n3) : t3;
    }(s2, n2, this.max);
    return this._unit = e2.unit || (i2.autoSkip ? Ld(e2.minUnit, this.min, this.max, this._getLabelCapacity(n2)) : function(t3, e3, i3, s3, n3) {
      for (let r3 = Ed.length - 1; r3 >= Ed.indexOf(i3); r3--) {
        const i4 = Ed[r3];
        if (Rd[i4].common && t3._adapter.diff(n3, s3, i4) >= e3 - 1) return i4;
      }
      return Ed[i3 ? Ed.indexOf(i3) : 0];
    }(this, r2.length, e2.minUnit, this.min, this.max)), this._majorUnit = i2.major.enabled && "year" !== this._unit ? function(t3) {
      for (let e3 = Ed.indexOf(t3) + 1, i3 = Ed.length; e3 < i3; ++e3) if (Rd[Ed[e3]].common) return Ed[e3];
    }(this._unit) : void 0, this.initOffsets(s2), t2.reverse && r2.reverse(), Od(this, r2, this._majorUnit);
  }
  afterAutoSkip() {
    this.options.offsetAfterAutoskip && this.initOffsets(this.ticks.map((t2) => +t2.value));
  }
  initOffsets(t2 = []) {
    let e2, i2, s2 = 0, n2 = 0;
    this.options.offset && t2.length && (e2 = this.getDecimalForValue(t2[0]), s2 = 1 === t2.length ? 1 - e2 : (this.getDecimalForValue(t2[1]) - e2) / 2, i2 = this.getDecimalForValue(t2[t2.length - 1]), n2 = 1 === t2.length ? i2 : (i2 - this.getDecimalForValue(t2[t2.length - 2])) / 2);
    const r2 = t2.length < 3 ? 0.5 : 0.25;
    s2 = ma(s2, 0, r2), n2 = ma(n2, 0, r2), this._offsets = { start: s2, end: n2, factor: 1 / (s2 + 1 + n2) };
  }
  _generate() {
    const t2 = this._adapter, e2 = this.min, i2 = this.max, s2 = this.options, n2 = s2.time, r2 = n2.unit || Ld(n2.minUnit, e2, i2, this._getLabelCapacity(e2)), o2 = Ro(s2.ticks.stepSize, 1), a2 = "week" === r2 && n2.isoWeekday, l2 = ra(a2) || true === a2, h2 = {};
    let c2, u2, d2 = e2;
    if (l2 && (d2 = +t2.startOf(d2, "isoWeek", a2)), d2 = +t2.startOf(d2, l2 ? "day" : r2), t2.diff(i2, e2, r2) > 1e5 * o2) throw new Error(e2 + " and " + i2 + " are too far apart with stepSize of " + o2 + " " + r2);
    const f2 = "data" === s2.ticks.source && this.getDataTimestamps();
    for (c2 = d2, u2 = 0; c2 < i2; c2 = +t2.add(c2, o2, r2), u2++) Vd(h2, c2, f2);
    return c2 !== i2 && "ticks" !== s2.bounds && 1 !== u2 || Vd(h2, c2, f2), Object.keys(h2).sort(Pd).map((t3) => +t3);
  }
  getLabelForValue(t2) {
    const e2 = this._adapter, i2 = this.options.time;
    return i2.tooltipFormat ? e2.format(t2, i2.tooltipFormat) : e2.format(t2, i2.displayFormats.datetime);
  }
  format(t2, e2) {
    const i2 = this.options.time.displayFormats, s2 = this._unit, n2 = e2 || i2[s2];
    return this._adapter.format(t2, n2);
  }
  _tickFormatFunction(t2, e2, i2, s2) {
    const n2 = this.options, r2 = n2.ticks.callback;
    if (r2) return Po(r2, [t2, e2, i2], this);
    const o2 = n2.time.displayFormats, a2 = this._unit, l2 = this._majorUnit, h2 = a2 && o2[a2], c2 = l2 && o2[l2], u2 = i2[e2], d2 = l2 && c2 && u2 && u2.major;
    return this._adapter.format(t2, s2 || (d2 ? c2 : h2));
  }
  generateTickLabels(t2) {
    let e2, i2, s2;
    for (e2 = 0, i2 = t2.length; e2 < i2; ++e2) s2 = t2[e2], s2.label = this._tickFormatFunction(s2.value, e2, t2);
  }
  getDecimalForValue(t2) {
    return null === t2 ? NaN : (t2 - this.min) / (this.max - this.min);
  }
  getPixelForValue(t2) {
    const e2 = this._offsets, i2 = this.getDecimalForValue(t2);
    return this.getPixelForDecimal((e2.start + i2) * e2.factor);
  }
  getValueForPixel(t2) {
    const e2 = this._offsets, i2 = this.getDecimalForPixel(t2) / e2.factor - e2.end;
    return this.min + i2 * (this.max - this.min);
  }
  _getLabelSize(t2) {
    const e2 = this.options.ticks, i2 = this.ctx.measureText(t2).width, s2 = aa(this.isHorizontal() ? e2.maxRotation : e2.minRotation), n2 = Math.cos(s2), r2 = Math.sin(s2), o2 = this._resolveTickFontOptions(0).size;
    return { w: i2 * n2 + o2 * r2, h: i2 * r2 + o2 * n2 };
  }
  _getLabelCapacity(t2) {
    const e2 = this.options.time, i2 = e2.displayFormats, s2 = i2[e2.unit] || i2.millisecond, n2 = this._tickFormatFunction(t2, 0, Od(this, [t2], this._majorUnit), s2), r2 = this._getLabelSize(n2), o2 = Math.floor(this.isHorizontal() ? this.width / r2.w : this.height / r2.h) - 1;
    return o2 > 0 ? o2 : 1;
  }
  getDataTimestamps() {
    let t2, e2, i2 = this._cache.data || [];
    if (i2.length) return i2;
    const s2 = this.getMatchingVisibleMetas();
    if (this._normalized && s2.length) return this._cache.data = s2[0].controller.getAllParsedValues(this);
    for (t2 = 0, e2 = s2.length; t2 < e2; ++t2) i2 = i2.concat(s2[t2].controller.getAllParsedValues(this));
    return this._cache.data = this.normalize(i2);
  }
  getLabelTimestamps() {
    const t2 = this._cache.labels || [];
    let e2, i2;
    if (t2.length) return t2;
    const s2 = this.getLabels();
    for (e2 = 0, i2 = s2.length; e2 < i2; ++e2) t2.push(Td(this, s2[e2]));
    return this._cache.labels = this._normalized ? t2 : this.normalize(t2);
  }
  normalize(t2) {
    return wa(t2.sort(Pd));
  }
}
__publicField(TimeScale, "id", "time");
__publicField(TimeScale, "defaults", { bounds: "data", adapters: {}, time: { parser: false, unit: false, round: false, isoWeekday: false, minUnit: "millisecond", displayFormats: {} }, ticks: { source: "auto", callback: false, major: { enabled: false } } });
function Ad(t2, e2, i2) {
  let s2, n2, r2, o2, a2 = 0, l2 = t2.length - 1;
  i2 ? (e2 >= t2[a2].pos && e2 <= t2[l2].pos && ({ lo: a2, hi: l2 } = ba(t2, "pos", e2)), { pos: s2, time: r2 } = t2[a2], { pos: n2, time: o2 } = t2[l2]) : (e2 >= t2[a2].time && e2 <= t2[l2].time && ({ lo: a2, hi: l2 } = ba(t2, "time", e2)), { time: s2, pos: r2 } = t2[a2], { time: n2, pos: o2 } = t2[l2]);
  const h2 = n2 - s2;
  return h2 ? r2 + (o2 - r2) * (e2 - s2) / h2 : r2;
}
var Fd = Object.freeze({ __proto__: null, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale: (_f = class extends TimeScale {
  constructor(t2) {
    super(t2), this._table = [], this._minPos = void 0, this._tableRange = void 0;
  }
  initOffsets() {
    const t2 = this._getTimestampsForTable(), e2 = this._table = this.buildLookupTable(t2);
    this._minPos = Ad(e2, this.min), this._tableRange = Ad(e2, this.max) - this._minPos, super.initOffsets(t2);
  }
  buildLookupTable(t2) {
    const { min: e2, max: i2 } = this, s2 = [], n2 = [];
    let r2, o2, a2, l2, h2;
    for (r2 = 0, o2 = t2.length; r2 < o2; ++r2) l2 = t2[r2], l2 >= e2 && l2 <= i2 && s2.push(l2);
    if (s2.length < 2) return [{ time: e2, pos: 0 }, { time: i2, pos: 1 }];
    for (r2 = 0, o2 = s2.length; r2 < o2; ++r2) h2 = s2[r2 + 1], a2 = s2[r2 - 1], l2 = s2[r2], Math.round((h2 + a2) / 2) !== l2 && n2.push({ time: l2, pos: r2 / (o2 - 1) });
    return n2;
  }
  _generate() {
    const t2 = this.min, e2 = this.max;
    let i2 = super.getDataTimestamps();
    return i2.includes(t2) && i2.length || i2.splice(0, 0, t2), i2.includes(e2) && 1 !== i2.length || i2.push(e2), i2.sort((t3, e3) => t3 - e3);
  }
  _getTimestampsForTable() {
    let t2 = this._cache.all || [];
    if (t2.length) return t2;
    const e2 = this.getDataTimestamps(), i2 = this.getLabelTimestamps();
    return t2 = e2.length && i2.length ? this.normalize(e2.concat(i2)) : e2.length ? e2 : i2, t2 = this._cache.all = t2, t2;
  }
  getDecimalForValue(t2) {
    return (Ad(this._table, t2) - this._minPos) / this._tableRange;
  }
  getValueForPixel(t2) {
    const e2 = this._offsets, i2 = this.getDecimalForPixel(t2) / e2.factor - e2.end;
    return Ad(this._table, i2 * this._tableRange + this._minPos, true);
  }
}, __publicField(_f, "id", "timeseries"), __publicField(_f, "defaults", TimeScale.defaults), _f) });
const Nd = [Vh, _u, dd, Fd], Wd = ["en", "zh-tw"], Id = "PARAGLIDE_LOCALE", Bd = ["cookie", "baseLocale"];
globalThis.__paraglide = {};
let jd = false, Hd = () => {
  let t2;
  for (const e2 of Bd) if ("cookie" === e2 ? t2 = Ud() : "baseLocale" === e2 && (t2 = "zh-tw"), void 0 !== t2) {
    const e3 = Kd(t2);
    return jd || (jd = true, qd(e3, { reload: false })), e3;
  }
  throw new Error("No locale found. Read the docs https://inlang.com/m/gerre34r/library-inlang-paraglideJs/errors#no-locale-found");
}, qd = (t2, e2) => {
  const i2 = { reload: true, ...e2 };
  let s2;
  try {
    s2 = Hd();
  } catch {
  }
  for (const e3 of Bd) if ("cookie" === e3) {
    if ("undefined" == typeof document || "undefined" == typeof window) continue;
    const e4 = window.location.hostname;
    document.cookie = `${Id}=${t2}; path=/; max-age=34560000; domain=${e4}`;
  } else if ("baseLocale" === e3) continue;
  i2.reload && window.location && t2 !== s2 && window.location.reload();
};
function Xd(t2) {
  return !!t2 && Wd.includes(t2);
}
function Kd(t2) {
  if (false === Xd(t2)) throw new Error(`Invalid locale: ${t2}. Expected one of: ${Wd.join(", ")}`);
  return t2;
}
function Ud() {
  if ("undefined" == typeof document || !document.cookie) return;
  const t2 = document.cookie.match(new RegExp(`(^| )${Id}=([^;]+)`)), e2 = t2 == null ? void 0 : t2[2];
  return Xd(e2) ? e2 : void 0;
}
const Yd = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? "Annual compensation" : "zh-tw" === i2 ? "年報酬" : "profitability_yearlyReturn";
}, Gd = () => "用科學，重新定義投資", Jd = Gd, Qd = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Jd() : "zh-tw" === i2 ? "用科學，重新定義投資" : "title";
}, Zd = () => "數據為你導航，投資不再憑運氣！", tf = Zd, ef = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? tf() : "zh-tw" === i2 ? "數據為你導航，投資不再憑運氣！" : "subtitle";
}, sf = () => "開始使用", nf = sf, rf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nf() : "zh-tw" === i2 ? "開始使用" : "actionButton";
}, of = () => "策略", af = of, lf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? af() : "zh-tw" === i2 ? "策略" : "strategy";
}, hf = () => "大盤", cf = hf, uf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cf() : "zh-tw" === i2 ? "大盤" : "benchmark";
}, df = () => "平均", ff = df, pf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ff() : "zh-tw" === i2 ? "平均" : "average";
}, mf = () => "歷史績效", gf = mf, vf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gf() : "zh-tw" === i2 ? "歷史績效" : "profitability_historicalReturn";
}, bf = () => "持股報酬", _f2 = bf, yf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _f2() : "zh-tw" === i2 ? "持股報酬" : "profitability_stockList";
}, xf = () => "月報酬", wf = xf, kf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wf() : "zh-tw" === i2 ? "月報酬" : "profitability_monthlyReturn";
}, Mf = () => "月勝率", Sf = Mf, Cf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sf() : "zh-tw" === i2 ? "月勝率" : "profitability_monthlyWinRatio";
}, zf = () => "平均月報酬", $f = zf, Df = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $f() : "zh-tw" === i2 ? "平均月報酬" : "profitability_avgMonthlyReturn";
}, Rf = () => "與大盤年報酬比較", Ef = Rf, Pf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ef() : "zh-tw" === i2 ? "與大盤年報酬比較" : "profitability_YearlyCompareWithBenchmark";
}, Tf = () => "贏大盤", Lf = Tf, Vf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lf() : "zh-tw" === i2 ? "贏大盤" : "profitability_yearlyWinRate";
}, Of = () => "超額報酬", Af = Of, Ff = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Af() : "zh-tw" === i2 ? "超額報酬" : "profitability_exceedReturn";
}, Nf = () => "回檔幅度", Wf = Nf, If = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wf() : "zh-tw" === i2 ? "回檔幅度" : "risk_drawdownPercentage";
}, Bf = () => "虧損歷史", jf = Bf, Hf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jf() : "zh-tw" === i2 ? "虧損歷史" : "risk_drawdowPeriods";
}, qf = () => "獲利能力", Xf = qf, Kf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xf() : "zh-tw" === i2 ? "獲利能力" : "tabs_profitability";
}, Uf = () => "抗風險能力", Yf = Uf, Gf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yf() : "zh-tw" === i2 ? "抗風險能力" : "tabs_risk";
}, Jf = () => "風險報酬比", Qf = Jf, Zf = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qf() : "zh-tw" === i2 ? "風險報酬比" : "tabs_ratio";
}, tp = () => "勝率期望值", ep = tp, ip = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ep() : "zh-tw" === i2 ? "勝率期望值" : "tabs_winrate";
}, sp = () => "交易流動性", np = sp, rp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? np() : "zh-tw" === i2 ? "交易流動性" : "tabs_liquidity";
}, op = () => "開始日期", ap = op, lp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ap() : "zh-tw" === i2 ? "開始日期" : "metrics_backtest_startDate";
}, hp = () => "結束日期", cp = hp, up = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cp() : "zh-tw" === i2 ? "結束日期" : "metrics_backtest_endDate";
}, dp = () => "版本", fp = dp, pp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fp() : "zh-tw" === i2 ? "版本" : "metrics_backtest_version";
}, mp = () => "費用比率", gp = mp, vp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gp() : "zh-tw" === i2 ? "費用比率" : "metrics_backtest_feeRatio";
}, bp = () => "稅收比率", _p = bp, yp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _p() : "zh-tw" === i2 ? "稅收比率" : "metrics_backtest_taxRatio";
}, xp = () => "交易於（收盤或開盤）", wp = xp, kp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wp() : "zh-tw" === i2 ? "交易於（收盤或開盤）" : "metrics_backtest_tradeAt";
}, Mp = () => "市場", Sp = Mp, Cp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sp() : "zh-tw" === i2 ? "市場" : "metrics_backtest_market";
}, zp = () => "頻率", $p = zp, Dp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $p() : "zh-tw" === i2 ? "頻率" : "metrics_backtest_freq";
}, Rp = () => "更新日期", Ep = Rp, Pp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ep() : "zh-tw" === i2 ? "更新日期" : "metrics_backtest_updateDate";
}, Tp = () => "下一交易日", Lp = Tp, Vp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lp() : "zh-tw" === i2 ? "下一交易日" : "metrics_backtest_nextTradingDate";
}, Op = () => "實時表現開始日期", Ap = Op, Fp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ap() : "zh-tw" === i2 ? "實時表現開始日期" : "metrics_backtest_livePerformanceStart";
}, Np = () => "止損百分比", Wp = Np, Ip = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wp() : "zh-tw" === i2 ? "止損百分比" : "metrics_backtest_stopLoss";
}, Bp = () => "獲利百分比", jp = Bp, Hp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jp() : "zh-tw" === i2 ? "獲利百分比" : "metrics_backtest_takeProfit";
}, qp = () => "年度回報", Xp = qp, Kp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xp() : "zh-tw" === i2 ? "年度回報" : "metrics_profitability_annualReturn";
}, Up = () => "Alpha", Yp = Up, Gp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yp() : "zh-tw" === i2 ? "Alpha" : "metrics_profitability_alpha";
}, Jp = () => "Beta", Qp = Jp, Zp = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qp() : "zh-tw" === i2 ? "Beta" : "metrics_profitability_beta";
}, tm = () => "平均持有", em = tm, im = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? em() : "zh-tw" === i2 ? "平均持有" : "metrics_profitability_avgNStock";
}, sm = () => "最多持有", nm = sm, rm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nm() : "zh-tw" === i2 ? "最多持有" : "metrics_profitability_maxNStock";
}, om = () => "最大回檔", am = om, lm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? am() : "zh-tw" === i2 ? "最大回檔" : "metrics_risk_maxDrawdown";
}, hm = () => "平均回檔幅度", cm = hm, um = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cm() : "zh-tw" === i2 ? "平均回檔幅度" : "metrics_risk_avgDrawdown";
}, dm = () => "平均回檔時間", fm = dm, pm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fm() : "zh-tw" === i2 ? "平均回檔時間" : "metrics_risk_avgDrawdownDays";
}, mm = () => "波動性", gm = mm, vm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gm() : "zh-tw" === i2 ? "波動性" : "metrics_risk_volatility";
}, bm = () => "Value at Risk", _m = bm, ym = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _m() : "zh-tw" === i2 ? "Value at Risk" : "metrics_risk_valueAtRisk";
}, xm = () => "Conditional VaR", wm = xm, km = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wm() : "zh-tw" === i2 ? "Conditional VaR" : "metrics_risk_cvalueAtRisk";
}, Mm = () => "再次創新高時間排名", Sm = Mm, Cm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sm() : "zh-tw" === i2 ? "再次創新高時間排名" : "metrics_risk_newHighTimeRank";
}, zm = () => "策略前十大", $m = zm, Dm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $m() : "zh-tw" === i2 ? "策略前十大" : "metrics_risk_worst10Strategy";
}, Rm = () => "大盤前十大", Em = Rm, Pm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Em() : "zh-tw" === i2 ? "大盤前十大" : "metrics_risk_worst10Benchmark";
}, Tm = () => "days", Lm = Tm, Vm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lm() : "zh-tw" === i2 ? "days" : "metrics_risk_days";
}, Om = () => "夏普值", Am = Om, Fm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Am() : "zh-tw" === i2 ? "夏普值" : "metrics_ratio_sharpeRatio";
}, Nm = () => "Sortino Ratio", Wm = Nm, Im = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wm() : "zh-tw" === i2 ? "Sortino Ratio" : "metrics_ratio_sortinoRatio";
}, Bm = () => "Calmar Ratio", jm = Bm, Hm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jm() : "zh-tw" === i2 ? "Calmar Ratio" : "metrics_ratio_calmarRatio";
}, qm = () => "Profit Factor", Xm = qm, Km = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xm() : "zh-tw" === i2 ? "Profit Factor" : "metrics_ratio_profitFactor";
}, Um = () => "Tail Ratio", Ym = Um, Gm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ym() : "zh-tw" === i2 ? "Tail Ratio" : "metrics_ratio_tailRatio";
}, Jm = () => "小於大盤", Qm = Jm, Zm = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qm() : "zh-tw" === i2 ? "小於大盤" : "metrics_ratio_worseThanBenchmark";
}, tg = () => "逐筆交易勝率", eg = tg, ig = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? eg() : "zh-tw" === i2 ? "逐筆交易勝率" : "metrics_winrate_winRate";
}, sg = () => "使用策略12個月勝大盤", ng = sg, rg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ng() : "zh-tw" === i2 ? "使用策略12個月勝大盤" : "metrics_winrate_m12WinRate";
}, og = () => "期望值", ag = og, lg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ag() : "zh-tw" === i2 ? "期望值" : "metrics_winrate_expectancy";
}, hg = () => "最大不利偏移", cg = hg, ug = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cg() : "zh-tw" === i2 ? "最大不利偏移" : "metrics_winrate_mae";
}, dg = () => "最大有利偏移", fg = dg, pg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fg() : "zh-tw" === i2 ? "最大有利偏移" : "metrics_winrate_mfe";
}, mg = () => "小市值比率", gg = mg, vg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gg() : "zh-tw" === i2 ? "小市值比率" : "metrics_liquidity_smallCapRatio";
}, bg = () => "胃納量", _g = bg, yg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _g() : "zh-tw" === i2 ? "胃納量" : "metrics_liquidity_capacity";
}, xg = () => "處置股", wg = xg, kg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wg() : "zh-tw" === i2 ? "處置股" : "metrics_liquidity_disposalStockRatio";
}, Mg = () => "警告股", Sg = Mg, Cg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sg() : "zh-tw" === i2 ? "警告股" : "metrics_liquidity_warningStockRatio";
}, zg = () => "全額交付股", $g = zg, Dg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $g() : "zh-tw" === i2 ? "全額交付股" : "metrics_liquidity_fullDeliveryStockRatio";
}, Rg = () => "買在漲停", Eg = Rg, Pg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Eg() : "zh-tw" === i2 ? "買在漲停" : "metrics_liquidity_buyHigh";
}, Tg = () => "賣在跌停", Lg = Tg, Vg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lg() : "zh-tw" === i2 ? "賣在跌停" : "metrics_liquidity_sellLow";
}, Og = () => "名稱代號", Ag = Og, Fg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ag() : "zh-tw" === i2 ? "名稱代號" : "metrics_stocks_stockId";
}, Ng = () => "報酬", Wg = Ng, Ig = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wg() : "zh-tw" === i2 ? "報酬" : "metrics_stocks_return";
}, Bg = () => "進場", jg = Bg, Hg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jg() : "zh-tw" === i2 ? "進場" : "metrics_stocks_entry";
}, qg = () => "出場", Xg = qg, Kg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xg() : "zh-tw" === i2 ? "出場" : "metrics_stocks_exit";
}, Ug = () => "持倉", Yg = Ug, Gg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yg() : "zh-tw" === i2 ? "持倉" : "metrics_stocks_position";
}, Jg = () => "進場價格", Qg = Jg, Zg = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qg() : "zh-tw" === i2 ? "進場價格" : "metrics_stocks_entryPrice";
}, tv = () => "出場價格", ev = tv, iv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ev() : "zh-tw" === i2 ? "出場價格" : "metrics_stocks_exitPrice";
}, sv = () => "進場訊號", nv = sv, rv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nv() : "zh-tw" === i2 ? "進場訊號" : "metrics_stocks_entrySig";
}, ov = () => "出場訊號", av = ov, lv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? av() : "zh-tw" === i2 ? "出場訊號" : "metrics_stocks_exitSig";
}, hv = () => "不利偏移", cv = hv, uv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cv() : "zh-tw" === i2 ? "不利偏移" : "metrics_stocks_mae";
}, dv = () => "有利偏移", fv = dv, pv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fv() : "zh-tw" === i2 ? "有利偏移" : "metrics_stocks_gmfe";
}, mv = () => "虧損前有利偏移", gv = mv, vv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gv() : "zh-tw" === i2 ? "虧損前有利偏移" : "metrics_stocks_bmfe";
}, bv = () => "最大回檔", _v = bv, yv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _v() : "zh-tw" === i2 ? "最大回檔" : "metrics_stocks_mdd";
}, xv = () => "持倉天数", wv = xv, kv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wv() : "zh-tw" === i2 ? "持倉天数" : "metrics_stocks_pdays";
}, Mv = () => "儲存草稿", Sv = Mv, Cv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sv() : "zh-tw" === i2 ? "儲存草稿" : "notebook_private_draft";
}, zv = () => "儲存", $v = zv, Dv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $v() : "zh-tw" === i2 ? "儲存" : "notebook_save_draft";
}, Rv = () => "準備發布", Ev = Rv, Pv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ev() : "zh-tw" === i2 ? "準備發布" : "notebook_go_public";
}, Tv = () => "更新發布", Lv = Tv, Vv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lv() : "zh-tw" === i2 ? "更新發布" : "notebook_update_public";
}, Ov = () => "Python", Av = Ov, Fv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Av() : "zh-tw" === i2 ? "Python" : "notebook_category_python";
}, Nv = () => "股市", Wv = Nv, Iv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wv() : "zh-tw" === i2 ? "股市" : "notebook_category_market";
}, Bv = () => "演算法", jv = Bv, Hv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jv() : "zh-tw" === i2 ? "演算法" : "notebook_category_algorithm";
}, qv = () => "工具", Xv = qv, Kv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xv() : "zh-tw" === i2 ? "工具" : "notebook_category_tool";
}, Uv = () => "策略指標", Yv = Uv, Gv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yv() : "zh-tw" === i2 ? "策略指標" : "notebook_category_metric";
}, Jv = () => "財經指標", Qv = Jv, Zv = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qv() : "zh-tw" === i2 ? "財經指標" : "notebook_category_indicator";
}, tb = () => "機器學習AI", eb = tb, ib = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? eb() : "zh-tw" === i2 ? "機器學習AI" : "notebook_category_ai";
}, sb = () => "停損", nb = sb, rb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nb() : "zh-tw" === i2 ? "停損" : "position_sl";
}, ob = () => "停利", ab = ob, lb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ab() : "zh-tw" === i2 ? "停利" : "position_tp";
}, hb = () => "移動出場", cb = hb, ub = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cb() : "zh-tw" === i2 ? "移動出場" : "position_ts";
}, db = () => "換股頻率", fb = db, pb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fb() : "zh-tw" === i2 ? "換股頻率" : "position_resample";
}, mb = () => "進場時機", gb = mb, vb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gb() : "zh-tw" === i2 ? "進場時機" : "position_entryTradePrice";
}, bb = () => "出場時機", _b2 = bb, yb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _b2() : "zh-tw" === i2 ? "出場時機" : "position_exitTradePrice";
}, xb = () => "預定換股日", wb = xb, kb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wb() : "zh-tw" === i2 ? "預定換股日" : "position_scheduled";
}, Mb = () => "回測頻率", Sb = Mb, Cb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sb() : "zh-tw" === i2 ? "回測頻率" : "position_dataFreq";
}, zb = () => "更新時間", $b = zb, Db = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $b() : "zh-tw" === i2 ? "更新時間" : "position_created";
}, Rb = () => "進場日期", Eb = Rb, Pb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Eb() : "zh-tw" === i2 ? "進場日期" : "position_entryDate";
}, Tb = () => "出場日期", Lb = Tb, Vb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lb() : "zh-tw" === i2 ? "出場日期" : "position_exitDate";
}, Ob = () => "價格", Ab = Ob, Fb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ab() : "zh-tw" === i2 ? "價格" : "position_currentPrice";
}, Nb = () => "盈虧", Wb = Nb, Ib = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wb() : "zh-tw" === i2 ? "盈虧" : "position_profit";
}, Bb = () => "當前持股比例", jb = Bb, Hb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jb() : "zh-tw" === i2 ? "當前持股比例" : "position_currentWeight";
}, qb = () => "持股比例", Xb = qb, Kb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xb() : "zh-tw" === i2 ? "持股比例" : "position_nextWeight";
}, Ub = () => "多空力道", Yb = Ub, Gb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yb() : "zh-tw" === i2 ? "多空力道" : "position_RSV";
}, Jb = () => "每30分鐘", Qb = Jb, Zb = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qb() : "zh-tw" === i2 ? "每30分鐘" : "position_resampleValue_30M";
}, t_ = () => "每1小時", e_ = t_, i_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? e_() : "zh-tw" === i2 ? "每1小時" : "position_resampleValue_H";
}, s_ = () => "每4小時", n_ = s_, r_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? n_() : "zh-tw" === i2 ? "每4小時" : "position_resampleValue_4H";
}, o_ = () => "每8小時", a_ = o_, l_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? a_() : "zh-tw" === i2 ? "每8小時" : "position_resampleValue_8H";
}, h_ = () => "每1天", c_ = h_, u_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? c_() : "zh-tw" === i2 ? "每1天" : "position_resampleValue_D";
}, d_ = () => "每週", f_ = d_, p_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? f_() : "zh-tw" === i2 ? "每週" : "position_resampleValue_W";
}, m_ = () => "每2週", g_ = m_, v_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? g_() : "zh-tw" === i2 ? "每2週" : "position_resampleValue_2W";
}, b_ = () => "每3週", __ = b_, y_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? __() : "zh-tw" === i2 ? "每3週" : "position_resampleValue_3W";
}, x_ = () => "每4週", w_ = x_, k_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? w_() : "zh-tw" === i2 ? "每4週" : "position_resampleValue_4W";
}, M_ = () => "每月底", S_ = M_, C_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? S_() : "zh-tw" === i2 ? "每月底" : "position_resampleValue_M";
}, z_ = () => "每2個月", $_ = z_, D_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $_() : "zh-tw" === i2 ? "每2個月" : "position_resampleValue_2M";
}, R_ = () => "每月底", E_ = R_, P_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? E_() : "zh-tw" === i2 ? "每月底" : "position_resampleValue_ME";
}, T_ = () => "每月收入公佈日", L_ = T_, V_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? L_() : "zh-tw" === i2 ? "每月收入公佈日" : "position_resampleValue_MRE";
}, O_ = () => "每1季底", A_ = O_, F_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? A_() : "zh-tw" === i2 ? "每1季底" : "position_resampleValue_Q";
}, N_ = () => "每1季底", W_ = N_, I_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? W_() : "zh-tw" === i2 ? "每1季底" : "position_resampleValue_QE";
}, B_ = () => "每半年", j_ = B_, H_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? j_() : "zh-tw" === i2 ? "每半年" : "position_resampleValue_HY";
}, q_ = () => "每1年", X_ = q_, K_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? X_() : "zh-tw" === i2 ? "每1年" : "position_resampleValue_Y";
}, U_ = () => "不固定", Y_ = U_, G_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Y_() : "zh-tw" === i2 ? "不固定" : "position_resampleValue_null";
}, J_ = () => "開盤", Q_ = J_, Z_ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Q_() : "zh-tw" === i2 ? "開盤" : "position_open";
}, ty = () => "收盤", ey = ty, iy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ey() : "zh-tw" === i2 ? "收盤" : "position_close";
}, sy = () => "開收均價", ny = sy, ry = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ny() : "zh-tw" === i2 ? "開收均價" : "position_open_close_avg";
}, oy = () => "高低均價", ay = oy, ly = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ay() : "zh-tw" === i2 ? "高低均價" : "position_high_low_avg";
}, hy = () => "進場", cy = hy, uy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cy() : "zh-tw" === i2 ? "進場" : "position_type_entry";
}, dy = () => "將進場", fy = dy, py = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fy() : "zh-tw" === i2 ? "將進場" : "position_type_entry_f";
}, my = () => "出場", gy = my, vy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gy() : "zh-tw" === i2 ? "出場" : "position_type_exit";
}, by = () => "已出場", _y = by, yy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _y() : "zh-tw" === i2 ? "已出場" : "position_type_exit_p";
}, xy = () => "持有", wy = xy, ky = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wy() : "zh-tw" === i2 ? "持有" : "position_type_hold";
}, My = () => "停損", Sy = My, Cy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sy() : "zh-tw" === i2 ? "停損" : "position_type_sl";
}, zy = () => "停利", $y = zy, Dy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $y() : "zh-tw" === i2 ? "停利" : "position_type_tp";
}, Ry = () => "已停損", Ey = Ry, Py = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ey() : "zh-tw" === i2 ? "已停損" : "position_type_sl_";
}, Ty = () => "已停利", Ly = Ty, Vy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ly() : "zh-tw" === i2 ? "已停利" : "position_type_tp_";
}, Oy = () => "標的名稱", Ay = Oy, Fy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ay() : "zh-tw" === i2 ? "標的名稱" : "position_assetName";
}, Ny = () => "動作", Wy = Ny, Iy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wy() : "zh-tw" === i2 ? "動作" : "position_action";
}, By = () => "夏普與大盤比較", jy = By, Hy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jy() : "zh-tw" === i2 ? "夏普與大盤比較" : "metrics_ratio_yearlySharpeRatio";
}, qy = () => "大於大盤：", Xy = qy, Ky = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xy() : "zh-tw" === i2 ? "大於大盤：" : "metrics_ratio_betterThanBenchmark";
}, Uy = () => "年", Yy = Uy, Gy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yy() : "zh-tw" === i2 ? "年" : "metrics_ratio_year";
}, Jy = () => "大於大盤的時間：", Qy = Jy, Zy = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qy() : "zh-tw" === i2 ? "大於大盤的時間：" : "metrics_ratio_timeBetterThanBenchmark";
}, tx = () => "極端風報比與大盤比較", ex = tx, ix = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ex() : "zh-tw" === i2 ? "極端風報比與大盤比較" : "metrics_ratio_yearlyTailRatio";
}, sx = () => "策略報酬率波動 (Volitility)", nx = sx, rx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nx() : "zh-tw" === i2 ? "策略報酬率波動 (Volitility)" : "metrics_ratio_volatility";
}, ox = () => "報酬分布", ax = ox, lx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ax() : "zh-tw" === i2 ? "報酬分布" : "metrics_winrate_returnDistribution";
}, hx = () => "有 5% 的機率，交易將有", cx = hx, ux = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cx() : "zh-tw" === i2 ? "有 5% 的機率，交易將有" : "metrics_winrate_distributionInfo1";
}, dx = () => " % 以上的虧損", fx = dx, px = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fx() : "zh-tw" === i2 ? " % 以上的虧損" : "metrics_winrate_distributionInfo2";
}, mx = () => "報酬率", gx = mx, vx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gx() : "zh-tw" === i2 ? "報酬率" : "metrics_winrate_return";
}, bx = () => "交易最大偏移", _x = bx, yx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _x() : "zh-tw" === i2 ? "交易最大偏移" : "metrics_winrate_maemfe";
}, xx = () => "停損設定：", wx = xx, kx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wx() : "zh-tw" === i2 ? "停損設定：" : "metrics_winrate_stoploss";
}, Mx = () => "無", Sx = Mx, Cx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sx() : "zh-tw" === i2 ? "無" : "metrics_winrate_none";
}, zx = () => "停損造成的額外盈虧：", $x = zx, Dx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $x() : "zh-tw" === i2 ? "停損造成的額外盈虧：" : "metrics_winrate_extraProfitLoss";
}, Rx = () => "停損的交易比例：", Ex = Rx, Px = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ex() : "zh-tw" === i2 ? "停損的交易比例：" : "metrics_winrate_stoplossRatio";
}, Tx = () => "報酬與最大不利偏移", Lx = Tx, Vx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lx() : "zh-tw" === i2 ? "報酬與最大不利偏移" : "metrics_winrate_maeReturn";
}, Ox = () => "模擬停損", Ax = Ox, Fx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ax() : "zh-tw" === i2 ? "模擬停損" : "metrics_winrate_simulatedStopLoss";
}, Nx = () => "模擬停利", Wx = Nx, Ix = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wx() : "zh-tw" === i2 ? "模擬停利" : "metrics_winrate_simulatedTakeProfit";
}, Bx = () => "停利設定：", jx = Bx, Hx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jx() : "zh-tw" === i2 ? "停利設定：" : "metrics_winrate_takeProfit";
}, qx = () => "停利造成的額外盈虧：", Xx = qx, Kx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xx() : "zh-tw" === i2 ? "停利造成的額外盈虧：" : "metrics_winrate_extraProfitLossTakingProfit";
}, Ux = () => "停利的交易比例：", Yx = Ux, Gx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yx() : "zh-tw" === i2 ? "停利的交易比例：" : "metrics_winrate_takeProfitRatio";
}, Jx = () => "報酬與最大有利偏移", Qx = Jx, Zx = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qx() : "zh-tw" === i2 ? "報酬與最大有利偏移" : "metrics_winrate_mfeReturn";
}, tw = () => "投資組合胃納量", ew = tw, iw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ew() : "zh-tw" === i2 ? "投資組合胃納量" : "metrics_liquidity_portfolioCapacity";
}, sw = () => "安全流動性交易的佔比", nw = sw, rw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nw() : "zh-tw" === i2 ? "安全流動性交易的佔比" : "metrics_liquidity_safeLiquidityTradeRatio";
}, ow = () => "平均報酬", aw = ow, lw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? aw() : "zh-tw" === i2 ? "平均報酬" : "metrics_liquidity_averageReturn";
}, hw = () => "投資總資金", cw = hw, uw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cw() : "zh-tw" === i2 ? "投資總資金" : "metrics_liquidity_totalInvestment";
}, dw = () => "交易標的的市值", fw = dw, pw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fw() : "zh-tw" === i2 ? "交易標的的市值" : "metrics_liquidity_marketCap";
}, mw = () => "交易的佔比", gw = mw, vw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gw() : "zh-tw" === i2 ? "交易的佔比" : "metrics_liquidity_tradeRatio";
}, bw = () => "市值門檻", _w = bw, yw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _w() : "zh-tw" === i2 ? "市值門檻" : "metrics_liquidity_tradeRatioMarketCap";
}, xw = () => "買進成交量門檻", ww = xw, kw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ww() : "zh-tw" === i2 ? "買進成交量門檻" : "metrics_liquidity_tradeRatioEntryVolume";
}, Mw = () => "交易的佔比", Sw = Mw, Cw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sw() : "zh-tw" === i2 ? "交易的佔比" : "metrics_liquidity_tradeRatioExitVolume";
}, zw = () => "當天成交量", $w = zw, Dw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $w() : "zh-tw" === i2 ? "當天成交量" : "metrics_liquidity_volumeThreshold";
}, Rw = () => "出場當天成交量", Ew = Rw, Pw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ew() : "zh-tw" === i2 ? "出場當天成交量" : "metrics_liquidity_exitVolume";
}, Tw = () => "進場當天成交量", Lw = Tw, Vw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lw() : "zh-tw" === i2 ? "進場當天成交量" : "metrics_liquidity_entryVolume";
}, Ow = () => "市值門檻", Aw = Ow, Fw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Aw() : "zh-tw" === i2 ? "市值門檻" : "metrics_liquidity_marketCapThreshold";
}, Nw = (t2) => `當資金量達到 ${t2.v1} 時，將有 ${t2.v2}%的機率，買到流動性低的股票(低成交量、價差大、價格易波動)。`, Ww = Nw, Iw = (t2, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ww(t2) : "zh-tw" === i2 ? Nw(t2) : "metrics_liquidity_portfolioCapacityDescription";
}, Bw = (t2) => `市值 ${t2.v1} 以上的交易佔 ${t2.v2}%。`, jw = Bw, Hw = (t2, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jw(t2) : "zh-tw" === i2 ? Bw(t2) : "metrics_liquidity_marketCapDescription";
}, qw = (t2) => `買入當天成交量 ${t2.v1} 張以上的交易佔 ${t2.v2}%。`, Xw = qw, Kw = (t2, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xw(t2) : "zh-tw" === i2 ? qw(t2) : "metrics_liquidity_entryVolumeDescription";
}, Uw = (t2) => `賣出當天成交量 ${t2.v1} 張以上的交易佔 ${t2.v2}%。`, Yw = Uw, Gw = (t2, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yw(t2) : "zh-tw" === i2 ? Uw(t2) : "metrics_liquidity_exitVolumeDescription";
}, Jw = () => "極端風報比", Qw = Jw, Zw = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qw() : "zh-tw" === i2 ? "極端風報比" : "metrics_ratio_rollingTailRatio";
}, tk = () => "大盤年報酬", ek = tk, ik = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ek() : "zh-tw" === i2 ? "大盤年報酬" : "profitability_benchmarkYearlyReturn";
}, sk = () => "年", nk = sk, rk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nk() : "zh-tw" === i2 ? "年" : "profitability_year";
}, ok = () => "跌幅排名", ak = ok, lk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ak() : "zh-tw" === i2 ? "跌幅排名" : "metrics_risk_worstDrawdownPeriod";
}, hk = () => "全部", ck = hk, uk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ck() : "zh-tw" === i2 ? "全部" : "profitability_all";
}, dk = () => "近年", fk = dk, pk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fk() : "zh-tw" === i2 ? "近年" : "profitability_recent";
}, mk = () => "回測的開始日期", gk = mk, vk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gk() : "zh-tw" === i2 ? "回測的開始日期" : "metric_description_backtest_startDate";
}, bk = () => "回測的結束日期", _k = bk, yk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _k() : "zh-tw" === i2 ? "回測的結束日期" : "metric_description_backtest_endDate";
}, xk = () => "回測的版本", wk = xk, kk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wk() : "zh-tw" === i2 ? "回測的版本" : "metric_description_backtest_version";
}, Mk = () => "交易的手續費比率", Sk = Mk, Ck = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Sk() : "zh-tw" === i2 ? "交易的手續費比率" : "metric_description_backtest_feeRatio";
}, zk = () => "交易的稅率", $k = zk, Dk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $k() : "zh-tw" === i2 ? "交易的稅率" : "metric_description_backtest_taxRatio";
}, Rk = () => "交易是在市場收盤還是開盤時執行", Ek = Rk, Pk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ek() : "zh-tw" === i2 ? "交易是在市場收盤還是開盤時執行" : "metric_description_backtest_tradeAt";
}, Tk = () => "進行回測的市場", Lk = Tk, Vk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Lk() : "zh-tw" === i2 ? "進行回測的市場" : "metric_description_backtest_market";
}, Ok = () => "回測使用的數據頻率", Ak = Ok, Fk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Ak() : "zh-tw" === i2 ? "回測使用的數據頻率" : "metric_description_backtest_freq";
}, Nk = () => "回測最後更新的日期", Wk = Nk, Ik = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Wk() : "zh-tw" === i2 ? "回測最後更新的日期" : "metric_description_backtest_updateDate";
}, Bk = () => "回測後的下一個交易日期", jk = Bk, Hk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jk() : "zh-tw" === i2 ? "回測後的下一個交易日期" : "metric_description_backtest_nextTradingDate";
}, qk = () => "實時性能跟踪開始的日期", Xk = qk, Kk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Xk() : "zh-tw" === i2 ? "實時性能跟踪開始的日期" : "metric_description_backtest_livePerformanceStart";
}, Uk = () => "允許的最大損失以停止交易", Yk = Uk, Gk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Yk() : "zh-tw" === i2 ? "允許的最大損失以停止交易" : "metric_description_backtest_stopLoss";
}, Jk = () => "退出交易的利潤目標", Qk = Jk, Zk = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? Qk() : "zh-tw" === i2 ? "退出交易的利潤目標" : "metric_description_backtest_takeProfit";
}, tM = () => "策略的年度回報", eM = tM, iM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? eM() : "zh-tw" === i2 ? "策略的年度回報" : "metric_description_profitability_annualReturn";
}, sM = () => "相對於基準的策略的風險調整後表現的衡量", nM = sM, rM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nM() : "zh-tw" === i2 ? "相對於基準的策略的風險調整後表現的衡量" : "metric_description_profitability_alpha";
}, oM = () => "策略對市場變動的敏感性的衡量", aM = oM, lM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? aM() : "zh-tw" === i2 ? "策略對市場變動的敏感性的衡量" : "metric_description_profitability_beta";
}, hM = () => "投資組合中持有的平均股票數", cM = hM, uM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cM() : "zh-tw" === i2 ? "投資組合中持有的平均股票數" : "metric_description_profitability_avgNStock";
}, dM = () => "投資組合中持有的最大股票數", fM = dM, pM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fM() : "zh-tw" === i2 ? "投資組合中持有的最大股票數" : "metric_description_profitability_maxNStock";
}, mM = () => "從高點到低谷的最大百分比下降", gM = mM, vM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gM() : "zh-tw" === i2 ? "從高點到低谷的最大百分比下降" : "metric_description_risk_maxDrawdown";
}, bM = () => "從高點到低谷的平均百分比下降", _M = bM, yM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _M() : "zh-tw" === i2 ? "從高點到低谷的平均百分比下降" : "metric_description_risk_avgDrawdown";
}, xM = () => "平均回撤天數", wM = xM, kM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wM() : "zh-tw" === i2 ? "平均回撤天數" : "metric_description_risk_avgDrawdownDays";
}, MM = () => "策略回報的標準差", SM = MM, CM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? SM() : "zh-tw" === i2 ? "策略回報的標準差" : "metric_description_risk_volatility";
}, zM = () => "給定信心區間的指定期間內預期的最大損失", $M = zM, DM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $M() : "zh-tw" === i2 ? "給定信心區間的指定期間內預期的最大損失" : "metric_description_risk_valueAtRisk";
}, RM = () => "發生指定不良事件後的預期損失", EM = RM, PM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? EM() : "zh-tw" === i2 ? "發生指定不良事件後的預期損失" : "metric_description_risk_cvalueAtRisk";
}, TM = () => "風險調整後表現的衡量", LM = TM, VM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? LM() : "zh-tw" === i2 ? "風險調整後表現的衡量" : "metric_description_ratio_sharpeRatio";
}, OM = () => "只考慮下行波動性的風險調整後表現的衡量", AM = OM, FM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? AM() : "zh-tw" === i2 ? "只考慮下行波動性的風險調整後表現的衡量" : "metric_description_ratio_sortinoRatio";
}, NM = () => "年度回報與最大回撤的比率", WM = NM, IM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? WM() : "zh-tw" === i2 ? "年度回報與最大回撤的比率" : "metric_description_ratio_calmarRatio";
}, BM = () => "總利潤與總損失的比率", jM = BM, HM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jM() : "zh-tw" === i2 ? "總利潤與總損失的比率" : "metric_description_ratio_profitFactor";
}, qM = () => "右尾（贏）與左尾（輸）的比率", XM = qM, KM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? XM() : "zh-tw" === i2 ? "右尾（贏）與左尾（輸）的比率" : "metric_description_ratio_tailRatio";
}, UM = () => "盈利交易的百分比", YM = UM, GM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? YM() : "zh-tw" === i2 ? "盈利交易的百分比" : "metric_description_winrate_winRate";
}, JM = () => "12個月滾動勝率", QM = JM, ZM = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? QM() : "zh-tw" === i2 ? "12個月滾動勝率" : "metric_description_winrate_m12WinRate";
}, tS = () => "每筆交易預期贏得（或損失）的平均金額", eS = tS, iS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? eS() : "zh-tw" === i2 ? "每筆交易預期贏得（或損失）的平均金額" : "metric_description_winrate_expectancy";
}, sS = () => "最大不利運動，或交易盈利前的最大損失", nS = sS, rS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nS() : "zh-tw" === i2 ? "最大不利運動，或交易盈利前的最大損失" : "metric_description_winrate_mae";
}, oS = () => "最大有利運動，或交易變成損失前的最大利潤", aS = oS, lS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? aS() : "zh-tw" === i2 ? "最大有利運動，或交易變成損失前的最大利潤" : "metric_description_winrate_mfe";
}, hS = () => "不影響市場價格可以部署的最大資本金額", cS = hS, uS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cS() : "zh-tw" === i2 ? "不影響市場價格可以部署的最大資本金額" : "metric_description_liquidity_capacity";
}, dS = () => "可以輕易出售的股票比率", fS = dS, pS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fS() : "zh-tw" === i2 ? "可以輕易出售的股票比率" : "metric_description_liquidity_disposalStockRatio";
}, mS = () => "可能存在流動性問題的股票比率", gS = mS, vS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gS() : "zh-tw" === i2 ? "可能存在流動性問題的股票比率" : "metric_description_liquidity_warningStockRatio";
}, bS = () => "需要全額交付的股票比率", _S = bS, yS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _S() : "zh-tw" === i2 ? "需要全額交付的股票比率" : "metric_description_liquidity_fullDeliveryStockRatio";
}, xS = () => "購買高價股票的傾向", wS = xS, kS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wS() : "zh-tw" === i2 ? "購買高價股票的傾向" : "metric_description_liquidity_buyHigh";
}, MS = () => "賣出低價股票的傾向", SS = MS, CS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? SS() : "zh-tw" === i2 ? "賣出低價股票的傾向" : "metric_description_liquidity_sellLow";
}, zS = () => "達成條件", $S = zS, DS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $S() : "zh-tw" === i2 ? "達成條件" : "metrics_condition";
}, RS = () => "程式碼", ES = RS, PS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? ES() : "zh-tw" === i2 ? "程式碼" : "strategy_code";
}, TS = () => "報酬", LS = TS, VS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? LS() : "zh-tw" === i2 ? "報酬" : "strategy_return";
}, OS = () => "贏大盤", AS = OS, FS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? AS() : "zh-tw" === i2 ? "贏大盤" : "strategy_betterThanBenchmark";
}, NS = () => "輸大盤", WS = NS, IS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? WS() : "zh-tw" === i2 ? "輸大盤" : "strategy_worseThanBenchmark";
}, BS = () => "年度報酬", jS = BS, HS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? jS() : "zh-tw" === i2 ? "年度報酬" : "strategy_annualReturn";
}, qS = () => "最大回檔", XS = qS, KS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? XS() : "zh-tw" === i2 ? "最大回檔" : "strategy_maxDrawdown";
}, US = () => "夏普比率", YS = US, GS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? YS() : "zh-tw" === i2 ? "夏普比率" : "strategy_sharpeRatio";
}, JS = () => "週", QS = JS, ZS = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? QS() : "zh-tw" === i2 ? "週" : "strategy_period_W";
}, tC = () => "月", eC = tC, iC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? eC() : "zh-tw" === i2 ? "月" : "strategy_period_M";
}, sC = () => "季", nC = sC, rC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? nC() : "zh-tw" === i2 ? "季" : "strategy_period_Q";
}, oC = () => "半年", aC = oC, lC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? aC() : "zh-tw" === i2 ? "半年" : "strategy_period_HY";
}, hC = () => "年", cC = hC, uC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? cC() : "zh-tw" === i2 ? "年" : "strategy_period_Y";
}, dC = () => "全部", fC = dC, pC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? fC() : "zh-tw" === i2 ? "全部" : "strategy_period_All";
}, mC = () => "選股", gC = mC, vC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? gC() : "zh-tw" === i2 ? "選股" : "strategy_tabs_position";
}, bC = () => "分析", _C = bC, yC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? _C() : "zh-tw" === i2 ? "分析" : "strategy_tabs_analyze";
}, xC = () => "教學", wC = xC, kC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? wC() : "zh-tw" === i2 ? "教學" : "strategy_tabs_course";
}, MC = () => "每週一", SC = MC, CC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? SC() : "zh-tw" === i2 ? "每週一" : "position_resampleValue_W_Mon";
}, zC = () => "每週二", $C = zC, DC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? $C() : "zh-tw" === i2 ? "每週二" : "position_resampleValue_W_Tue";
}, RC = () => "每週三", EC = RC, PC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? EC() : "zh-tw" === i2 ? "每週三" : "position_resampleValue_W_Wed";
}, TC = () => "每週四", LC = TC, VC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? LC() : "zh-tw" === i2 ? "每週四" : "position_resampleValue_W_Thu";
}, OC = () => "每週五", AC = OC, FC = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? Hd();
  return "en" === i2 ? AC() : "zh-tw" === i2 ? "每週五" : "position_resampleValue_W_Fri";
}, NC = Object.freeze(Object.defineProperty({ __proto__: null, actionButton: rf, average: pf, benchmark: uf, metric_description_backtest_endDate: yk, metric_description_backtest_feeRatio: Ck, metric_description_backtest_freq: Fk, metric_description_backtest_livePerformanceStart: Kk, metric_description_backtest_market: Vk, metric_description_backtest_nextTradingDate: Hk, metric_description_backtest_startDate: vk, metric_description_backtest_stopLoss: Gk, metric_description_backtest_takeProfit: Zk, metric_description_backtest_taxRatio: Dk, metric_description_backtest_tradeAt: Pk, metric_description_backtest_updateDate: Ik, metric_description_backtest_version: kk, metric_description_liquidity_buyHigh: kS, metric_description_liquidity_capacity: uS, metric_description_liquidity_disposalStockRatio: pS, metric_description_liquidity_fullDeliveryStockRatio: yS, metric_description_liquidity_sellLow: CS, metric_description_liquidity_warningStockRatio: vS, metric_description_profitability_alpha: rM, metric_description_profitability_annualReturn: iM, metric_description_profitability_avgNStock: uM, metric_description_profitability_beta: lM, metric_description_profitability_maxNStock: pM, metric_description_ratio_calmarRatio: IM, metric_description_ratio_profitFactor: HM, metric_description_ratio_sharpeRatio: VM, metric_description_ratio_sortinoRatio: FM, metric_description_ratio_tailRatio: KM, metric_description_risk_avgDrawdown: yM, metric_description_risk_avgDrawdownDays: kM, metric_description_risk_cvalueAtRisk: PM, metric_description_risk_maxDrawdown: vM, metric_description_risk_valueAtRisk: DM, metric_description_risk_volatility: CM, metric_description_winrate_expectancy: iS, metric_description_winrate_m12WinRate: ZM, metric_description_winrate_mae: rS, metric_description_winrate_mfe: lS, metric_description_winrate_winRate: GM, metrics_backtest_endDate: up, metrics_backtest_feeRatio: vp, metrics_backtest_freq: Dp, metrics_backtest_livePerformanceStart: Fp, metrics_backtest_market: Cp, metrics_backtest_nextTradingDate: Vp, metrics_backtest_startDate: lp, metrics_backtest_stopLoss: Ip, metrics_backtest_takeProfit: Hp, metrics_backtest_taxRatio: yp, metrics_backtest_tradeAt: kp, metrics_backtest_updateDate: Pp, metrics_backtest_version: pp, metrics_condition: DS, metrics_liquidity_averageReturn: lw, metrics_liquidity_buyHigh: Pg, metrics_liquidity_capacity: yg, metrics_liquidity_disposalStockRatio: kg, metrics_liquidity_entryVolume: Vw, metrics_liquidity_entryVolumeDescription: Kw, metrics_liquidity_exitVolume: Pw, metrics_liquidity_exitVolumeDescription: Gw, metrics_liquidity_fullDeliveryStockRatio: Dg, metrics_liquidity_marketCap: pw, metrics_liquidity_marketCapDescription: Hw, metrics_liquidity_marketCapThreshold: Fw, metrics_liquidity_portfolioCapacity: iw, metrics_liquidity_portfolioCapacityDescription: Iw, metrics_liquidity_safeLiquidityTradeRatio: rw, metrics_liquidity_sellLow: Vg, metrics_liquidity_smallCapRatio: vg, metrics_liquidity_totalInvestment: uw, metrics_liquidity_tradeRatio: vw, metrics_liquidity_tradeRatioEntryVolume: kw, metrics_liquidity_tradeRatioExitVolume: Cw, metrics_liquidity_tradeRatioMarketCap: yw, metrics_liquidity_volumeThreshold: Dw, metrics_liquidity_warningStockRatio: Cg, metrics_profitability_alpha: Gp, metrics_profitability_annualReturn: Kp, metrics_profitability_avgNStock: im, metrics_profitability_beta: Zp, metrics_profitability_maxNStock: rm, metrics_ratio_betterThanBenchmark: Ky, metrics_ratio_calmarRatio: Hm, metrics_ratio_profitFactor: Km, metrics_ratio_rollingTailRatio: Zw, metrics_ratio_sharpeRatio: Fm, metrics_ratio_sortinoRatio: Im, metrics_ratio_tailRatio: Gm, metrics_ratio_timeBetterThanBenchmark: Zy, metrics_ratio_volatility: rx, metrics_ratio_worseThanBenchmark: Zm, metrics_ratio_year: Gy, metrics_ratio_yearlySharpeRatio: Hy, metrics_ratio_yearlyTailRatio: ix, metrics_risk_avgDrawdown: um, metrics_risk_avgDrawdownDays: pm, metrics_risk_cvalueAtRisk: km, metrics_risk_days: Vm, metrics_risk_maxDrawdown: lm, metrics_risk_newHighTimeRank: Cm, metrics_risk_valueAtRisk: ym, metrics_risk_volatility: vm, metrics_risk_worst10Benchmark: Pm, metrics_risk_worst10Strategy: Dm, metrics_risk_worstDrawdownPeriod: lk, metrics_stocks_bmfe: vv, metrics_stocks_entry: Hg, metrics_stocks_entryPrice: Zg, metrics_stocks_entrySig: rv, metrics_stocks_exit: Kg, metrics_stocks_exitPrice: iv, metrics_stocks_exitSig: lv, metrics_stocks_gmfe: pv, metrics_stocks_mae: uv, metrics_stocks_mdd: yv, metrics_stocks_pdays: kv, metrics_stocks_position: Gg, metrics_stocks_return: Ig, metrics_stocks_stockId: Fg, metrics_winrate_distributionInfo1: ux, metrics_winrate_distributionInfo2: px, metrics_winrate_expectancy: lg, metrics_winrate_extraProfitLoss: Dx, metrics_winrate_extraProfitLossTakingProfit: Kx, metrics_winrate_m12WinRate: rg, metrics_winrate_mae: ug, metrics_winrate_maeReturn: Vx, metrics_winrate_maemfe: yx, metrics_winrate_mfe: pg, metrics_winrate_mfeReturn: Zx, metrics_winrate_none: Cx, metrics_winrate_return: vx, metrics_winrate_returnDistribution: lx, metrics_winrate_simulatedStopLoss: Fx, metrics_winrate_simulatedTakeProfit: Ix, metrics_winrate_stoploss: kx, metrics_winrate_stoplossRatio: Px, metrics_winrate_takeProfit: Hx, metrics_winrate_takeProfitRatio: Gx, metrics_winrate_winRate: ig, notebook_category_ai: ib, notebook_category_algorithm: Hv, notebook_category_indicator: Zv, notebook_category_market: Iv, notebook_category_metric: Gv, notebook_category_python: Fv, notebook_category_tool: Kv, notebook_go_public: Pv, notebook_private_draft: Cv, notebook_save_draft: Dv, notebook_update_public: Vv, position_RSV: Gb, position_action: Iy, position_assetName: Fy, position_close: iy, position_created: Db, position_currentPrice: Fb, position_currentWeight: Hb, position_dataFreq: Cb, position_entryDate: Pb, position_entryTradePrice: vb, position_exitDate: Vb, position_exitTradePrice: yb, position_high_low_avg: ly, position_nextWeight: Kb, position_open: Z_, position_open_close_avg: ry, position_profit: Ib, position_resample: pb, position_resampleValue_2M: D_, position_resampleValue_2W: v_, position_resampleValue_30M: Zb, position_resampleValue_3W: y_, position_resampleValue_4H: r_, position_resampleValue_4W: k_, position_resampleValue_8H: l_, position_resampleValue_D: u_, position_resampleValue_H: i_, position_resampleValue_HY: H_, position_resampleValue_M: C_, position_resampleValue_ME: P_, position_resampleValue_MRE: V_, position_resampleValue_Q: F_, position_resampleValue_QE: I_, position_resampleValue_W: p_, position_resampleValue_W_Fri: FC, position_resampleValue_W_Mon: CC, position_resampleValue_W_Thu: VC, position_resampleValue_W_Tue: DC, position_resampleValue_W_Wed: PC, position_resampleValue_Y: K_, position_resampleValue_null: G_, position_scheduled: kb, position_sl: rb, position_tp: lb, position_ts: ub, position_type_entry: uy, position_type_entry_f: py, position_type_exit: vy, position_type_exit_p: yy, position_type_hold: ky, position_type_sl: Cy, position_type_sl_: Py, position_type_tp: Dy, position_type_tp_: Vy, profitability_YearlyCompareWithBenchmark: Pf, profitability_all: uk, profitability_avgMonthlyReturn: Df, profitability_benchmarkYearlyReturn: ik, profitability_exceedReturn: Ff, profitability_historicalReturn: vf, profitability_monthlyReturn: kf, profitability_monthlyWinRatio: Cf, profitability_recent: pk, profitability_stockList: yf, profitability_year: rk, profitability_yearlyReturn: Yd, profitability_yearlyWinRate: Vf, risk_drawdowPeriods: Hf, risk_drawdownPercentage: If, strategy: lf, strategy_annualReturn: HS, strategy_betterThanBenchmark: FS, strategy_code: PS, strategy_maxDrawdown: KS, strategy_period_All: pC, strategy_period_HY: lC, strategy_period_M: iC, strategy_period_Q: rC, strategy_period_W: ZS, strategy_period_Y: uC, strategy_return: VS, strategy_sharpeRatio: GS, strategy_tabs_analyze: yC, strategy_tabs_course: kC, strategy_tabs_position: vC, strategy_worseThanBenchmark: IS, subtitle: ef, tabs_liquidity: rp, tabs_profitability: Kf, tabs_ratio: Zf, tabs_risk: Gf, tabs_winrate: ip, title: Qd }, Symbol.toStringTag, { value: "Module" })), WC = Object.freeze(Object.defineProperty({ __proto__: null, actionButton: rf, average: pf, benchmark: uf, m: NC, metric_description_backtest_endDate: yk, metric_description_backtest_feeRatio: Ck, metric_description_backtest_freq: Fk, metric_description_backtest_livePerformanceStart: Kk, metric_description_backtest_market: Vk, metric_description_backtest_nextTradingDate: Hk, metric_description_backtest_startDate: vk, metric_description_backtest_stopLoss: Gk, metric_description_backtest_takeProfit: Zk, metric_description_backtest_taxRatio: Dk, metric_description_backtest_tradeAt: Pk, metric_description_backtest_updateDate: Ik, metric_description_backtest_version: kk, metric_description_liquidity_buyHigh: kS, metric_description_liquidity_capacity: uS, metric_description_liquidity_disposalStockRatio: pS, metric_description_liquidity_fullDeliveryStockRatio: yS, metric_description_liquidity_sellLow: CS, metric_description_liquidity_warningStockRatio: vS, metric_description_profitability_alpha: rM, metric_description_profitability_annualReturn: iM, metric_description_profitability_avgNStock: uM, metric_description_profitability_beta: lM, metric_description_profitability_maxNStock: pM, metric_description_ratio_calmarRatio: IM, metric_description_ratio_profitFactor: HM, metric_description_ratio_sharpeRatio: VM, metric_description_ratio_sortinoRatio: FM, metric_description_ratio_tailRatio: KM, metric_description_risk_avgDrawdown: yM, metric_description_risk_avgDrawdownDays: kM, metric_description_risk_cvalueAtRisk: PM, metric_description_risk_maxDrawdown: vM, metric_description_risk_valueAtRisk: DM, metric_description_risk_volatility: CM, metric_description_winrate_expectancy: iS, metric_description_winrate_m12WinRate: ZM, metric_description_winrate_mae: rS, metric_description_winrate_mfe: lS, metric_description_winrate_winRate: GM, metrics_backtest_endDate: up, metrics_backtest_feeRatio: vp, metrics_backtest_freq: Dp, metrics_backtest_livePerformanceStart: Fp, metrics_backtest_market: Cp, metrics_backtest_nextTradingDate: Vp, metrics_backtest_startDate: lp, metrics_backtest_stopLoss: Ip, metrics_backtest_takeProfit: Hp, metrics_backtest_taxRatio: yp, metrics_backtest_tradeAt: kp, metrics_backtest_updateDate: Pp, metrics_backtest_version: pp, metrics_condition: DS, metrics_liquidity_averageReturn: lw, metrics_liquidity_buyHigh: Pg, metrics_liquidity_capacity: yg, metrics_liquidity_disposalStockRatio: kg, metrics_liquidity_entryVolume: Vw, metrics_liquidity_entryVolumeDescription: Kw, metrics_liquidity_exitVolume: Pw, metrics_liquidity_exitVolumeDescription: Gw, metrics_liquidity_fullDeliveryStockRatio: Dg, metrics_liquidity_marketCap: pw, metrics_liquidity_marketCapDescription: Hw, metrics_liquidity_marketCapThreshold: Fw, metrics_liquidity_portfolioCapacity: iw, metrics_liquidity_portfolioCapacityDescription: Iw, metrics_liquidity_safeLiquidityTradeRatio: rw, metrics_liquidity_sellLow: Vg, metrics_liquidity_smallCapRatio: vg, metrics_liquidity_totalInvestment: uw, metrics_liquidity_tradeRatio: vw, metrics_liquidity_tradeRatioEntryVolume: kw, metrics_liquidity_tradeRatioExitVolume: Cw, metrics_liquidity_tradeRatioMarketCap: yw, metrics_liquidity_volumeThreshold: Dw, metrics_liquidity_warningStockRatio: Cg, metrics_profitability_alpha: Gp, metrics_profitability_annualReturn: Kp, metrics_profitability_avgNStock: im, metrics_profitability_beta: Zp, metrics_profitability_maxNStock: rm, metrics_ratio_betterThanBenchmark: Ky, metrics_ratio_calmarRatio: Hm, metrics_ratio_profitFactor: Km, metrics_ratio_rollingTailRatio: Zw, metrics_ratio_sharpeRatio: Fm, metrics_ratio_sortinoRatio: Im, metrics_ratio_tailRatio: Gm, metrics_ratio_timeBetterThanBenchmark: Zy, metrics_ratio_volatility: rx, metrics_ratio_worseThanBenchmark: Zm, metrics_ratio_year: Gy, metrics_ratio_yearlySharpeRatio: Hy, metrics_ratio_yearlyTailRatio: ix, metrics_risk_avgDrawdown: um, metrics_risk_avgDrawdownDays: pm, metrics_risk_cvalueAtRisk: km, metrics_risk_days: Vm, metrics_risk_maxDrawdown: lm, metrics_risk_newHighTimeRank: Cm, metrics_risk_valueAtRisk: ym, metrics_risk_volatility: vm, metrics_risk_worst10Benchmark: Pm, metrics_risk_worst10Strategy: Dm, metrics_risk_worstDrawdownPeriod: lk, metrics_stocks_bmfe: vv, metrics_stocks_entry: Hg, metrics_stocks_entryPrice: Zg, metrics_stocks_entrySig: rv, metrics_stocks_exit: Kg, metrics_stocks_exitPrice: iv, metrics_stocks_exitSig: lv, metrics_stocks_gmfe: pv, metrics_stocks_mae: uv, metrics_stocks_mdd: yv, metrics_stocks_pdays: kv, metrics_stocks_position: Gg, metrics_stocks_return: Ig, metrics_stocks_stockId: Fg, metrics_winrate_distributionInfo1: ux, metrics_winrate_distributionInfo2: px, metrics_winrate_expectancy: lg, metrics_winrate_extraProfitLoss: Dx, metrics_winrate_extraProfitLossTakingProfit: Kx, metrics_winrate_m12WinRate: rg, metrics_winrate_mae: ug, metrics_winrate_maeReturn: Vx, metrics_winrate_maemfe: yx, metrics_winrate_mfe: pg, metrics_winrate_mfeReturn: Zx, metrics_winrate_none: Cx, metrics_winrate_return: vx, metrics_winrate_returnDistribution: lx, metrics_winrate_simulatedStopLoss: Fx, metrics_winrate_simulatedTakeProfit: Ix, metrics_winrate_stoploss: kx, metrics_winrate_stoplossRatio: Px, metrics_winrate_takeProfit: Hx, metrics_winrate_takeProfitRatio: Gx, metrics_winrate_winRate: ig, notebook_category_ai: ib, notebook_category_algorithm: Hv, notebook_category_indicator: Zv, notebook_category_market: Iv, notebook_category_metric: Gv, notebook_category_python: Fv, notebook_category_tool: Kv, notebook_go_public: Pv, notebook_private_draft: Cv, notebook_save_draft: Dv, notebook_update_public: Vv, position_RSV: Gb, position_action: Iy, position_assetName: Fy, position_close: iy, position_created: Db, position_currentPrice: Fb, position_currentWeight: Hb, position_dataFreq: Cb, position_entryDate: Pb, position_entryTradePrice: vb, position_exitDate: Vb, position_exitTradePrice: yb, position_high_low_avg: ly, position_nextWeight: Kb, position_open: Z_, position_open_close_avg: ry, position_profit: Ib, position_resample: pb, position_resampleValue_2M: D_, position_resampleValue_2W: v_, position_resampleValue_30M: Zb, position_resampleValue_3W: y_, position_resampleValue_4H: r_, position_resampleValue_4W: k_, position_resampleValue_8H: l_, position_resampleValue_D: u_, position_resampleValue_H: i_, position_resampleValue_HY: H_, position_resampleValue_M: C_, position_resampleValue_ME: P_, position_resampleValue_MRE: V_, position_resampleValue_Q: F_, position_resampleValue_QE: I_, position_resampleValue_W: p_, position_resampleValue_W_Fri: FC, position_resampleValue_W_Mon: CC, position_resampleValue_W_Thu: VC, position_resampleValue_W_Tue: DC, position_resampleValue_W_Wed: PC, position_resampleValue_Y: K_, position_resampleValue_null: G_, position_scheduled: kb, position_sl: rb, position_tp: lb, position_ts: ub, position_type_entry: uy, position_type_entry_f: py, position_type_exit: vy, position_type_exit_p: yy, position_type_hold: ky, position_type_sl: Cy, position_type_sl_: Py, position_type_tp: Dy, position_type_tp_: Vy, profitability_YearlyCompareWithBenchmark: Pf, profitability_all: uk, profitability_avgMonthlyReturn: Df, profitability_benchmarkYearlyReturn: ik, profitability_exceedReturn: Ff, profitability_historicalReturn: vf, profitability_monthlyReturn: kf, profitability_monthlyWinRatio: Cf, profitability_recent: pk, profitability_stockList: yf, profitability_year: rk, profitability_yearlyReturn: Yd, profitability_yearlyWinRate: Vf, risk_drawdowPeriods: Hf, risk_drawdownPercentage: If, strategy: lf, strategy_annualReturn: HS, strategy_betterThanBenchmark: FS, strategy_code: PS, strategy_maxDrawdown: KS, strategy_period_All: pC, strategy_period_HY: lC, strategy_period_M: iC, strategy_period_Q: rC, strategy_period_W: ZS, strategy_period_Y: uC, strategy_return: VS, strategy_sharpeRatio: GS, strategy_tabs_analyze: yC, strategy_tabs_course: kC, strategy_tabs_position: vC, strategy_worseThanBenchmark: IS, subtitle: ef, tabs_liquidity: rp, tabs_profitability: Kf, tabs_ratio: Zf, tabs_risk: Gf, tabs_winrate: ip, title: Qd }, Symbol.toStringTag, { value: "Module" }));
var IC = function(t2) {
  var e2 = wt(0);
  return function() {
    return 1 === arguments.length ? (zt(e2, hs(e2) + 1), arguments[0]) : (hs(e2), t2());
  };
}(() => Chart), BC = Rs('<div class="grid grid-cols-6 mx-6 md:mx-12 gap-6 md:gap-12 lg:gap-24 text-base-content-200"><div class="col-span-6 md:col-span-3"><div class="text-base-content/70 font-light text-3xl mb-9 justify-center"> </div> <div class="card-content"><p class="font-light"> </p> <div class="flex mt-9"><p class="text-primary"> </p> <div class="flex-grow"></div> <p class="text-secondary"> </p></div> <canvas width="400" height="200"></canvas> <p class="mt-6 text-center"> </p></div></div> <div class="col-span-6 md:col-span-3"><div class="text-base-content/70 font-light text-3xl mb-9 justify-center"> </div> <div class="card-content"><p class="text-base-content-200 font-light"> </p> <div class="flex mt-9"><p class="text-primary"> </p> <div class="flex-grow"></div> <p class="text-secondary"> </p></div> <canvas width="400" height="200"></canvas> <p class="mt-6 text-center"> </p></div></div> <div class="col-span-6"><div class="flex flex-col justify-center items-center"><div><div class="text-base-content/70 font-light text-3xl mb-9 justify-center"> </div> <div class="card-content"><p class="font-light"> </p> <div class="flex mt-9"><p class="text-primary"> </p> <div class="flex-grow"></div> <p class="text-secondary"> </p></div> <canvas width="400" height="200"></canvas> <p class="text-center mt-6"> </p></div></div></div></div></div>');
function jC(t2, e2) {
  G(e2, false);
  const i2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return WC[e3] ? WC[e3]() : e3;
  };
  IC().register(LinearScale, BarController, CategoryScale, BarElement, LineController, LineElement, PointElement, ud), IC(IC().defaults.font.color = "red");
  let s2 = Lr(e2, "browser", 12), n2 = Lr(e2, "report", 12), r2 = Lr(e2, "theme", 12, "light");
  function o2(t3, e3) {
    const i3 = t3.filter((t4) => null !== t4);
    if (0 === i3.length) return 0;
    const s3 = i3.sort((t4, e4) => t4 - e4), n3 = (s3.length - 1) * e3, r3 = Math.floor(n3), o3 = n3 - r3;
    return void 0 !== s3[r3 + 1] ? s3[r3] + o3 * (s3[r3 + 1] - s3[r3]) : s3[r3];
  }
  function a2(t3, e3, i3 = 5) {
    let s3 = {}, n3 = {};
    t3 = t3.filter((t4) => null !== t4[e3] && void 0 !== t4[e3]);
    for (let r3 of function(t4, e4 = 5) {
      let i4 = [], s4 = [5, 10];
      for (; i4.length < t4; ) {
        for (let n4 of s4) if (i4.push(n4 * Math.pow(10, e4)), i4.length === t4) break;
        e4 += 1;
      }
      return i4;
    }(100, i3)) {
      let i4 = t3.map((t4) => t4[e3]);
      i4.sort((t4, e4) => t4 - e4);
      let a3 = i4.findIndex((t4) => t4 > r3) / i4.length, l3 = t3.filter((t4) => t4[e3] > r3).map((t4) => t4.return);
      if (0 === a3 && (n3 = {}, s3 = {}), n3[r3] = o2(l3, 0.5), s3[r3] = 1 - a3, s3[r3] < 0.2) break;
    }
    return { portion: s3, mean: n3 };
  }
  function l2(t3, e3 = "zh") {
    return Math.abs(t3) >= 1e8 ? t3 / 1e8 + "億" : Math.abs(t3) >= 1e7 ? t3 / 1e7 + "千萬" : Math.abs(t3) >= 1e6 ? t3 / 1e6 + "百萬" : Math.abs(t3) >= 1e4 ? t3 / 1e4 + "萬" : t3;
  }
  function h2(t3, e3, i3) {
    return new (IC())(e3, { type: "bar", data: { labels: Object.keys(t3.portion), datasets: [{ label: "Data", data: Object.values(t3.portion), backgroundColor: "light" === r2() ? "#725bf5" : "#7a64f5", yAxisID: "y-axis-1", barPercentage: 0.2, order: 1 }, { label: "Line Data", data: Object.values(t3.mean), type: "line", fill: false, borderColor: "#f16365", borderWidth: 5, pointBackgroundColor: "#f16365", pointBorderColor: "#f16365", yAxisID: "y-axis-2", order: 0 }] }, options: { responsive: true, maintainAspectRatio: true, scales: { x: { type: "category", ticks: { color: "light" === r2() ? "#000000aa" : "#FFFFFFaa", callback: (e4) => l2(Object.keys(t3.portion)[e4], "zh") + i3 + "以上" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } }, "y-axis-1": { display: true, position: "left", beginAtZero: true, ticks: { callback: (t4) => (100 * t4).toFixed(0) + "%", color: "light" === r2() ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } }, "y-axis-2": { display: true, position: "right", ticks: { callback: (t4) => (100 * t4).toFixed(1) + "%", color: "light" === r2() ? "#000000aa" : "#FFFFFFaa" }, grid: { drawOnChartArea: false, color: "#77777755", tickBorderDash: [2, 2] } } }, plugins: { legend: { display: false } } } });
  }
  n2().trades.forEach((t3) => {
    t3.acceptMoneyFlow = (0.05 * t3["turnover@entry_date"] / t3.position + 0.05 * t3["turnover@entry_date"] / t3.position) / 2, t3["volume_@entry_date"] = t3["volume@entry_date"] / 1e3, t3["volume_@exit_date"] = t3["volume@exit_date"] / 1e3;
  });
  const c2 = a2(n2().trades, "acceptMoneyFlow", 5);
  a2(n2().trades, "market_value@entry_date", 5);
  const u2 = a2(n2().trades, "volume_@entry_date", 1), d2 = a2(n2().trades, "volume_@exit_date", 1);
  let f2 = {}, p2 = Mt({});
  function m2() {
    f2.moneyFlow && (f2.moneyFlow.destroy(), delete f2.moneyFlow);
    const t3 = hs(p2).moneyFlow.getContext("2d");
    f2.moneyFlow = h2(c2, t3, "元"), f2.marketValue && (f2.marketValue.destroy(), delete f2.marketValue), f2.entryVolume && f2.entryVolume.destroy();
    const e3 = hs(p2).entryVolume.getContext("2d");
    f2.entryVolume = h2(u2, e3, "張"), f2.exitVolume && f2.exitVolume.destroy();
    const i3 = hs(p2).exitVolume.getContext("2d");
    f2.exitVolume = h2(d2, i3, "張");
  }
  let g2 = Mt(false);
  en(() => {
    s2() && (m2(), zt(g2, true));
  }), $e(() => (fs(r2()), hs(g2)), () => {
    r2() && hs(g2) && m2();
  }), De(), yr();
  var v2 = BC(), b2 = me(v2), _2 = me(b2), y2 = me(_2, true);
  ie(_2);
  var x2 = ve(_2, 2), w2 = me(x2), k2 = me(w2, true);
  ie(w2);
  var M2 = ve(w2, 2), S2 = me(M2), C2 = me(S2, true);
  ie(S2);
  var z2 = ve(S2, 4), R2 = me(z2, true);
  ie(z2), ie(M2);
  var E2 = ve(M2, 2);
  _r(E2, (t3) => Ct(p2, hs(p2).moneyFlow = t3), () => {
    var _a3;
    return (_a3 = hs(p2)) == null ? void 0 : _a3.moneyFlow;
  });
  var P2 = ve(E2, 2), T2 = me(P2, true);
  ie(P2), ie(x2), ie(b2);
  var L2 = ve(b2, 2), V2 = me(L2), O2 = me(V2, true);
  ie(V2);
  var A2 = ve(V2, 2), F2 = me(A2), N2 = me(F2, true);
  ie(F2);
  var I2 = ve(F2, 2), B2 = me(I2), q2 = me(B2, true);
  ie(B2);
  var K2 = ve(B2, 4), U2 = me(K2, true);
  ie(K2), ie(I2);
  var Q2 = ve(I2, 2);
  _r(Q2, (t3) => Ct(p2, hs(p2).entryVolume = t3), () => {
    var _a3;
    return (_a3 = hs(p2)) == null ? void 0 : _a3.entryVolume;
  });
  var tt2 = ve(Q2, 2), et2 = me(tt2, true);
  ie(tt2), ie(A2), ie(L2);
  var at2 = ve(L2, 2), ct2 = me(at2), dt2 = me(ct2), mt2 = me(dt2), bt2 = me(mt2, true);
  ie(mt2);
  var _t3 = ve(mt2, 2), yt2 = me(_t3), xt2 = me(yt2, true);
  ie(yt2);
  var wt2 = ve(yt2, 2), kt2 = me(wt2), Rt2 = me(kt2, true);
  ie(kt2);
  var Lt2 = ve(kt2, 4), Ot2 = me(Lt2, true);
  ie(Lt2), ie(wt2);
  var At2 = ve(wt2, 2);
  _r(At2, (t3) => Ct(p2, hs(p2).exitVolume = t3), () => {
    var _a3;
    return (_a3 = hs(p2)) == null ? void 0 : _a3.exitVolume;
  });
  var It2 = ve(At2, 2), Bt2 = me(It2, true);
  return ie(It2), ie(_t3), ie(dt2), ie(ct2), ie(at2), ie(v2), Pe((t3, e3, i3, s3, n3, r3, o3, a3, l3, h3, c3, u3, d3, f3, p3) => {
    Us(y2, t3), Us(k2, e3), Us(C2, i3), Us(R2, s3), Us(T2, n3), Us(O2, r3), Us(N2, o3), Us(q2, a3), Us(U2, l3), Us(et2, h3), Us(bt2, c3), Us(xt2, u3), Us(Rt2, d3), Us(Ot2, f3), Us(Bt2, p3);
  }, [() => i2("metrics_liquidity_portfolioCapacity"), () => Iw({ v1: l2(Object.keys(c2.mean)[1], "zh"), v2: (100 * (1 - Object.values(c2.portion)[1])).toFixed(1) }), () => i2("metrics.liquidity.safeLiquidityTradeRatio"), () => i2("metrics.liquidity.averageReturn"), () => i2("metrics.liquidity.totalInvestment"), () => i2("metrics.liquidity.entryVolume"), () => Kw({ v1: l2(Object.keys(u2.mean)[2]), v2: (100 * Object.values(u2.portion)[2]).toFixed(1) }), () => i2("metrics.liquidity.tradeRatio"), () => i2("metrics.liquidity.averageReturn"), () => i2("metrics.liquidity.volumeThreshold"), () => i2("metrics.liquidity.exitVolume"), () => Gw({ v1: l2(Object.keys(d2.mean)[2]), v2: (100 * Object.values(d2.portion)[2]).toFixed(1) }), () => i2("metrics.liquidity.tradeRatioExitVolume"), () => i2("metrics.liquidity.averageReturn"), () => i2("metrics.liquidity.volumeThreshold")], gt), As(t2, v2), J({ get browser() {
    return s2();
  }, set browser(t3) {
    s2(t3), rs();
  }, get report() {
    return n2();
  }, set report(t3) {
    n2(t3), rs();
  }, get theme() {
    return r2();
  }, set theme(t3) {
    r2(t3), rs();
  } });
}
function HC(t2) {
  var e2 = t2.width, i2 = t2.height;
  if (e2 < 0) throw new Error("Negative width is not allowed for Size");
  if (i2 < 0) throw new Error("Negative height is not allowed for Size");
  return { width: e2, height: i2 };
}
function qC(t2, e2) {
  return t2.width === e2.width && t2.height === e2.height;
}
Ar(jC, { browser: {}, report: {}, theme: {} }, [], [], true);
var XC = function() {
  function t2(t3) {
    var e2 = this;
    this._resolutionListener = function() {
      return e2._onResolutionChanged();
    }, this._resolutionMediaQueryList = null, this._observers = [], this._window = t3, this._installResolutionListener();
  }
  return t2.prototype.dispose = function() {
    this._uninstallResolutionListener(), this._window = null;
  }, Object.defineProperty(t2.prototype, "value", { get: function() {
    return this._window.devicePixelRatio;
  }, enumerable: false, configurable: true }), t2.prototype.subscribe = function(t3) {
    var e2 = this, i2 = { next: t3 };
    return this._observers.push(i2), { unsubscribe: function() {
      e2._observers = e2._observers.filter(function(t4) {
        return t4 !== i2;
      });
    } };
  }, t2.prototype._installResolutionListener = function() {
    if (null !== this._resolutionMediaQueryList) throw new Error("Resolution listener is already installed");
    var t3 = this._window.devicePixelRatio;
    this._resolutionMediaQueryList = this._window.matchMedia("all and (resolution: ".concat(t3, "dppx)")), this._resolutionMediaQueryList.addListener(this._resolutionListener);
  }, t2.prototype._uninstallResolutionListener = function() {
    null !== this._resolutionMediaQueryList && (this._resolutionMediaQueryList.removeListener(this._resolutionListener), this._resolutionMediaQueryList = null);
  }, t2.prototype._reinstallResolutionListener = function() {
    this._uninstallResolutionListener(), this._installResolutionListener();
  }, t2.prototype._onResolutionChanged = function() {
    var t3 = this;
    this._observers.forEach(function(e2) {
      return e2.next(t3._window.devicePixelRatio);
    }), this._reinstallResolutionListener();
  }, t2;
}();
var KC = function() {
  function t2(t3, e2, i2) {
    var s2;
    this._canvasElement = null, this._bitmapSizeChangedListeners = [], this._suggestedBitmapSize = null, this._suggestedBitmapSizeChangedListeners = [], this._devicePixelRatioObservable = null, this._canvasElementResizeObserver = null, this._canvasElement = t3, this._canvasElementClientSize = HC({ width: this._canvasElement.clientWidth, height: this._canvasElement.clientHeight }), this._transformBitmapSize = null != e2 ? e2 : function(t4) {
      return t4;
    }, this._allowResizeObserver = null === (s2 = null == i2 ? void 0 : i2.allowResizeObserver) || void 0 === s2 || s2, this._chooseAndInitObserver();
  }
  return t2.prototype.dispose = function() {
    var t3, e2;
    if (null === this._canvasElement) throw new Error("Object is disposed");
    null === (t3 = this._canvasElementResizeObserver) || void 0 === t3 || t3.disconnect(), this._canvasElementResizeObserver = null, null === (e2 = this._devicePixelRatioObservable) || void 0 === e2 || e2.dispose(), this._devicePixelRatioObservable = null, this._suggestedBitmapSizeChangedListeners.length = 0, this._bitmapSizeChangedListeners.length = 0, this._canvasElement = null;
  }, Object.defineProperty(t2.prototype, "canvasElement", { get: function() {
    if (null === this._canvasElement) throw new Error("Object is disposed");
    return this._canvasElement;
  }, enumerable: false, configurable: true }), Object.defineProperty(t2.prototype, "canvasElementClientSize", { get: function() {
    return this._canvasElementClientSize;
  }, enumerable: false, configurable: true }), Object.defineProperty(t2.prototype, "bitmapSize", { get: function() {
    return HC({ width: this.canvasElement.width, height: this.canvasElement.height });
  }, enumerable: false, configurable: true }), t2.prototype.resizeCanvasElement = function(t3) {
    this._canvasElementClientSize = HC(t3), this.canvasElement.style.width = "".concat(this._canvasElementClientSize.width, "px"), this.canvasElement.style.height = "".concat(this._canvasElementClientSize.height, "px"), this._invalidateBitmapSize();
  }, t2.prototype.subscribeBitmapSizeChanged = function(t3) {
    this._bitmapSizeChangedListeners.push(t3);
  }, t2.prototype.unsubscribeBitmapSizeChanged = function(t3) {
    this._bitmapSizeChangedListeners = this._bitmapSizeChangedListeners.filter(function(e2) {
      return e2 !== t3;
    });
  }, Object.defineProperty(t2.prototype, "suggestedBitmapSize", { get: function() {
    return this._suggestedBitmapSize;
  }, enumerable: false, configurable: true }), t2.prototype.subscribeSuggestedBitmapSizeChanged = function(t3) {
    this._suggestedBitmapSizeChangedListeners.push(t3);
  }, t2.prototype.unsubscribeSuggestedBitmapSizeChanged = function(t3) {
    this._suggestedBitmapSizeChangedListeners = this._suggestedBitmapSizeChangedListeners.filter(function(e2) {
      return e2 !== t3;
    });
  }, t2.prototype.applySuggestedBitmapSize = function() {
    if (null !== this._suggestedBitmapSize) {
      var t3 = this._suggestedBitmapSize;
      this._suggestedBitmapSize = null, this._resizeBitmap(t3), this._emitSuggestedBitmapSizeChanged(t3, this._suggestedBitmapSize);
    }
  }, t2.prototype._resizeBitmap = function(t3) {
    var e2 = this.bitmapSize;
    qC(e2, t3) || (this.canvasElement.width = t3.width, this.canvasElement.height = t3.height, this._emitBitmapSizeChanged(e2, t3));
  }, t2.prototype._emitBitmapSizeChanged = function(t3, e2) {
    var i2 = this;
    this._bitmapSizeChangedListeners.forEach(function(s2) {
      return s2.call(i2, t3, e2);
    });
  }, t2.prototype._suggestNewBitmapSize = function(t3) {
    var e2 = this._suggestedBitmapSize, i2 = HC(this._transformBitmapSize(t3, this._canvasElementClientSize)), s2 = qC(this.bitmapSize, i2) ? null : i2;
    null === e2 && null === s2 || null !== e2 && null !== s2 && qC(e2, s2) || (this._suggestedBitmapSize = s2, this._emitSuggestedBitmapSizeChanged(e2, s2));
  }, t2.prototype._emitSuggestedBitmapSizeChanged = function(t3, e2) {
    var i2 = this;
    this._suggestedBitmapSizeChangedListeners.forEach(function(s2) {
      return s2.call(i2, t3, e2);
    });
  }, t2.prototype._chooseAndInitObserver = function() {
    var t3 = this;
    this._allowResizeObserver ? new Promise(function(t4) {
      var e2 = new ResizeObserver(function(i2) {
        t4(i2.every(function(t5) {
          return "devicePixelContentBoxSize" in t5;
        })), e2.disconnect();
      });
      e2.observe(document.body, { box: "device-pixel-content-box" });
    }).catch(function() {
      return false;
    }).then(function(e2) {
      return e2 ? t3._initResizeObserver() : t3._initDevicePixelRatioObservable();
    }) : this._initDevicePixelRatioObservable();
  }, t2.prototype._initDevicePixelRatioObservable = function() {
    var t3 = this;
    if (null !== this._canvasElement) {
      var e2 = UC(this._canvasElement);
      if (null === e2) throw new Error("No window is associated with the canvas");
      this._devicePixelRatioObservable = function(t4) {
        return new XC(t4);
      }(e2), this._devicePixelRatioObservable.subscribe(function() {
        return t3._invalidateBitmapSize();
      }), this._invalidateBitmapSize();
    }
  }, t2.prototype._invalidateBitmapSize = function() {
    var t3, e2;
    if (null !== this._canvasElement) {
      var i2 = UC(this._canvasElement);
      if (null !== i2) {
        var s2 = null !== (e2 = null === (t3 = this._devicePixelRatioObservable) || void 0 === t3 ? void 0 : t3.value) && void 0 !== e2 ? e2 : i2.devicePixelRatio, n2 = this._canvasElement.getClientRects(), r2 = void 0 !== n2[0] ? function(t4, e3) {
          return HC({ width: Math.round(t4.left * e3 + t4.width * e3) - Math.round(t4.left * e3), height: Math.round(t4.top * e3 + t4.height * e3) - Math.round(t4.top * e3) });
        }(n2[0], s2) : HC({ width: this._canvasElementClientSize.width * s2, height: this._canvasElementClientSize.height * s2 });
        this._suggestNewBitmapSize(r2);
      }
    }
  }, t2.prototype._initResizeObserver = function() {
    var t3 = this;
    null !== this._canvasElement && (this._canvasElementResizeObserver = new ResizeObserver(function(e2) {
      var i2 = e2.find(function(e3) {
        return e3.target === t3._canvasElement;
      });
      if (i2 && i2.devicePixelContentBoxSize && i2.devicePixelContentBoxSize[0]) {
        var s2 = i2.devicePixelContentBoxSize[0], n2 = HC({ width: s2.inlineSize, height: s2.blockSize });
        t3._suggestNewBitmapSize(n2);
      }
    }), this._canvasElementResizeObserver.observe(this._canvasElement, { box: "device-pixel-content-box" }));
  }, t2;
}();
function UC(t2) {
  return t2.ownerDocument.defaultView;
}
var YC = function() {
  function t2(t3, e2, i2) {
    if (0 === e2.width || 0 === e2.height) throw new TypeError("Rendering target could only be created on a media with positive width and height");
    if (this._mediaSize = e2, 0 === i2.width || 0 === i2.height) throw new TypeError("Rendering target could only be created using a bitmap with positive integer width and height");
    this._bitmapSize = i2, this._context = t3;
  }
  return t2.prototype.useMediaCoordinateSpace = function(t3) {
    try {
      return this._context.save(), this._context.setTransform(1, 0, 0, 1, 0, 0), this._context.scale(this._horizontalPixelRatio, this._verticalPixelRatio), t3({ context: this._context, mediaSize: this._mediaSize });
    } finally {
      this._context.restore();
    }
  }, t2.prototype.useBitmapCoordinateSpace = function(t3) {
    try {
      return this._context.save(), this._context.setTransform(1, 0, 0, 1, 0, 0), t3({ context: this._context, mediaSize: this._mediaSize, bitmapSize: this._bitmapSize, horizontalPixelRatio: this._horizontalPixelRatio, verticalPixelRatio: this._verticalPixelRatio });
    } finally {
      this._context.restore();
    }
  }, Object.defineProperty(t2.prototype, "_horizontalPixelRatio", { get: function() {
    return this._bitmapSize.width / this._mediaSize.width;
  }, enumerable: false, configurable: true }), Object.defineProperty(t2.prototype, "_verticalPixelRatio", { get: function() {
    return this._bitmapSize.height / this._mediaSize.height;
  }, enumerable: false, configurable: true }), t2;
}();
function GC(t2, e2) {
  var i2 = t2.canvasElementClientSize;
  if (0 === i2.width || 0 === i2.height) return null;
  var s2 = t2.bitmapSize;
  if (0 === s2.width || 0 === s2.height) return null;
  var n2 = t2.canvasElement.getContext("2d", e2);
  return null === n2 ? null : new YC(n2, i2, s2);
}
const JC = { upColor: "#26a69a", downColor: "#ef5350", wickVisible: true, borderVisible: true, borderColor: "#378658", borderUpColor: "#26a69a", borderDownColor: "#ef5350", wickColor: "#737375", wickUpColor: "#26a69a", wickDownColor: "#ef5350" }, QC = { upColor: "#26a69a", downColor: "#ef5350", openVisible: true, thinBars: true }, ZC = { color: "#2196f3", lineStyle: 0, lineWidth: 3, lineType: 0, lineVisible: true, crosshairMarkerVisible: true, crosshairMarkerRadius: 4, crosshairMarkerBorderColor: "", crosshairMarkerBorderWidth: 2, crosshairMarkerBackgroundColor: "", lastPriceAnimation: 0, pointMarkersVisible: false }, tz = { topColor: "rgba( 46, 220, 135, 0.4)", bottomColor: "rgba( 40, 221, 100, 0)", invertFilledArea: false, lineColor: "#33D778", lineStyle: 0, lineWidth: 3, lineType: 0, lineVisible: true, crosshairMarkerVisible: true, crosshairMarkerRadius: 4, crosshairMarkerBorderColor: "", crosshairMarkerBorderWidth: 2, crosshairMarkerBackgroundColor: "", lastPriceAnimation: 0, pointMarkersVisible: false }, ez = { baseValue: { type: "price", price: 0 }, topFillColor1: "rgba(38, 166, 154, 0.28)", topFillColor2: "rgba(38, 166, 154, 0.05)", topLineColor: "rgba(38, 166, 154, 1)", bottomFillColor1: "rgba(239, 83, 80, 0.05)", bottomFillColor2: "rgba(239, 83, 80, 0.28)", bottomLineColor: "rgba(239, 83, 80, 1)", lineWidth: 3, lineStyle: 0, lineType: 0, lineVisible: true, crosshairMarkerVisible: true, crosshairMarkerRadius: 4, crosshairMarkerBorderColor: "", crosshairMarkerBorderWidth: 2, crosshairMarkerBackgroundColor: "", lastPriceAnimation: 0, pointMarkersVisible: false }, iz = { color: "#26a69a", base: 0 }, sz = { color: "#2196f3" }, nz = { title: "", visible: true, lastValueVisible: true, priceLineVisible: true, priceLineSource: 0, priceLineWidth: 1, priceLineColor: "", priceLineStyle: 2, baseLineVisible: true, baseLineWidth: 1, baseLineColor: "#B2B5BE", baseLineStyle: 0, priceFormat: { type: "price", precision: 2, minMove: 0.01 } };
var rz, oz, az;
function lz(t2, e2) {
  const i2 = { 0: [], 1: [t2.lineWidth, t2.lineWidth], 2: [2 * t2.lineWidth, 2 * t2.lineWidth], 3: [6 * t2.lineWidth, 6 * t2.lineWidth], 4: [t2.lineWidth, 4 * t2.lineWidth] }[e2];
  t2.setLineDash(i2);
}
function hz(t2, e2, i2, s2) {
  t2.beginPath();
  const n2 = t2.lineWidth % 2 ? 0.5 : 0;
  t2.moveTo(i2, e2 + n2), t2.lineTo(s2, e2 + n2), t2.stroke();
}
function cz(t2, e2) {
  if (!t2) throw new Error("Assertion failed" + (e2 ? ": " + e2 : ""));
}
function uz(t2) {
  if (void 0 === t2) throw new Error("Value is undefined");
  return t2;
}
function dz(t2) {
  if (null === t2) throw new Error("Value is null");
  return t2;
}
function fz(t2) {
  return dz(uz(t2));
}
(az = rz || (rz = {}))[az.Simple = 0] = "Simple", az[az.WithSteps = 1] = "WithSteps", az[az.Curved = 2] = "Curved", function(t2) {
  t2[t2.Solid = 0] = "Solid", t2[t2.Dotted = 1] = "Dotted", t2[t2.Dashed = 2] = "Dashed", t2[t2.LargeDashed = 3] = "LargeDashed", t2[t2.SparseDotted = 4] = "SparseDotted";
}(oz || (oz = {}));
const pz = { khaki: "#f0e68c", azure: "#f0ffff", aliceblue: "#f0f8ff", ghostwhite: "#f8f8ff", gold: "#ffd700", goldenrod: "#daa520", gainsboro: "#dcdcdc", gray: "#808080", green: "#008000", honeydew: "#f0fff0", floralwhite: "#fffaf0", lightblue: "#add8e6", lightcoral: "#f08080", lemonchiffon: "#fffacd", hotpink: "#ff69b4", lightyellow: "#ffffe0", greenyellow: "#adff2f", lightgoldenrodyellow: "#fafad2", limegreen: "#32cd32", linen: "#faf0e6", lightcyan: "#e0ffff", magenta: "#f0f", maroon: "#800000", olive: "#808000", orange: "#ffa500", oldlace: "#fdf5e6", mediumblue: "#0000cd", transparent: "#0000", lime: "#0f0", lightpink: "#ffb6c1", mistyrose: "#ffe4e1", moccasin: "#ffe4b5", midnightblue: "#191970", orchid: "#da70d6", mediumorchid: "#ba55d3", mediumturquoise: "#48d1cc", orangered: "#ff4500", royalblue: "#4169e1", powderblue: "#b0e0e6", red: "#f00", coral: "#ff7f50", turquoise: "#40e0d0", white: "#fff", whitesmoke: "#f5f5f5", wheat: "#f5deb3", teal: "#008080", steelblue: "#4682b4", bisque: "#ffe4c4", aquamarine: "#7fffd4", aqua: "#0ff", sienna: "#a0522d", silver: "#c0c0c0", springgreen: "#00ff7f", antiquewhite: "#faebd7", burlywood: "#deb887", brown: "#a52a2a", beige: "#f5f5dc", chocolate: "#d2691e", chartreuse: "#7fff00", cornflowerblue: "#6495ed", cornsilk: "#fff8dc", crimson: "#dc143c", cadetblue: "#5f9ea0", tomato: "#ff6347", fuchsia: "#f0f", blue: "#00f", salmon: "#fa8072", blanchedalmond: "#ffebcd", slateblue: "#6a5acd", slategray: "#708090", thistle: "#d8bfd8", tan: "#d2b48c", cyan: "#0ff", darkblue: "#00008b", darkcyan: "#008b8b", darkgoldenrod: "#b8860b", darkgray: "#a9a9a9", blueviolet: "#8a2be2", black: "#000", darkmagenta: "#8b008b", darkslateblue: "#483d8b", darkkhaki: "#bdb76b", darkorchid: "#9932cc", darkorange: "#ff8c00", darkgreen: "#006400", darkred: "#8b0000", dodgerblue: "#1e90ff", darkslategray: "#2f4f4f", dimgray: "#696969", deepskyblue: "#00bfff", firebrick: "#b22222", forestgreen: "#228b22", indigo: "#4b0082", ivory: "#fffff0", lavenderblush: "#fff0f5", feldspar: "#d19275", indianred: "#cd5c5c", lightgreen: "#90ee90", lightgrey: "#d3d3d3", lightskyblue: "#87cefa", lightslategray: "#789", lightslateblue: "#8470ff", snow: "#fffafa", lightseagreen: "#20b2aa", lightsalmon: "#ffa07a", darksalmon: "#e9967a", darkviolet: "#9400d3", mediumpurple: "#9370d8", mediumaquamarine: "#66cdaa", skyblue: "#87ceeb", lavender: "#e6e6fa", lightsteelblue: "#b0c4de", mediumvioletred: "#c71585", mintcream: "#f5fffa", navajowhite: "#ffdead", navy: "#000080", olivedrab: "#6b8e23", palevioletred: "#d87093", violetred: "#d02090", yellow: "#ff0", yellowgreen: "#9acd32", lawngreen: "#7cfc00", pink: "#ffc0cb", paleturquoise: "#afeeee", palegoldenrod: "#eee8aa", darkolivegreen: "#556b2f", darkseagreen: "#8fbc8f", darkturquoise: "#00ced1", peachpuff: "#ffdab9", deeppink: "#ff1493", violet: "#ee82ee", palegreen: "#98fb98", mediumseagreen: "#3cb371", peru: "#cd853f", saddlebrown: "#8b4513", sandybrown: "#f4a460", rosybrown: "#bc8f8f", purple: "#800080", seagreen: "#2e8b57", seashell: "#fff5ee", papayawhip: "#ffefd5", mediumslateblue: "#7b68ee", plum: "#dda0dd", mediumspringgreen: "#00fa9a" };
function mz(t2) {
  return t2 < 0 ? 0 : t2 > 255 ? 255 : Math.round(t2) || 0;
}
function gz(t2) {
  return t2 <= 0 || t2 > 1 ? Math.min(Math.max(t2, 0), 1) : Math.round(1e4 * t2) / 1e4;
}
const vz = /^#([0-9a-f])([0-9a-f])([0-9a-f])([0-9a-f])?$/i, bz = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i, _z = /^rgb\(\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*\)$/, yz = /^rgba\(\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d*\.?\d+)\s*\)$/;
function xz(t2) {
  (t2 = t2.toLowerCase()) in pz && (t2 = pz[t2]);
  {
    const e2 = yz.exec(t2) || _z.exec(t2);
    if (e2) return [mz(parseInt(e2[1], 10)), mz(parseInt(e2[2], 10)), mz(parseInt(e2[3], 10)), gz(e2.length < 5 ? 1 : parseFloat(e2[4]))];
  }
  {
    const e2 = bz.exec(t2);
    if (e2) return [mz(parseInt(e2[1], 16)), mz(parseInt(e2[2], 16)), mz(parseInt(e2[3], 16)), 1];
  }
  {
    const e2 = vz.exec(t2);
    if (e2) return [mz(17 * parseInt(e2[1], 16)), mz(17 * parseInt(e2[2], 16)), mz(17 * parseInt(e2[3], 16)), 1];
  }
  throw new Error(`Cannot parse color: ${t2}`);
}
function wz(t2) {
  return 0.199 * t2[0] + 0.687 * t2[1] + 0.114 * t2[2];
}
function kz(t2) {
  const e2 = xz(t2);
  return { t: `rgb(${e2[0]}, ${e2[1]}, ${e2[2]})`, i: wz(e2) > 160 ? "black" : "white" };
}
class D {
  constructor() {
    this.h = [];
  }
  l(t2, e2, i2) {
    const s2 = { o: t2, _: e2, u: true === i2 };
    this.h.push(s2);
  }
  v(t2) {
    const e2 = this.h.findIndex((e3) => t2 === e3.o);
    e2 > -1 && this.h.splice(e2, 1);
  }
  p(t2) {
    this.h = this.h.filter((e2) => e2._ !== t2);
  }
  m(t2, e2, i2) {
    const s2 = [...this.h];
    this.h = this.h.filter((t3) => !t3.u), s2.forEach((s3) => s3.o(t2, e2, i2));
  }
  M() {
    return this.h.length > 0;
  }
  S() {
    this.h = [];
  }
}
function Mz(t2, ...e2) {
  for (const i2 of e2) for (const e3 in i2) void 0 !== i2[e3] && Object.prototype.hasOwnProperty.call(i2, e3) && !["__proto__", "constructor", "prototype"].includes(e3) && ("object" != typeof i2[e3] || void 0 === t2[e3] || Array.isArray(i2[e3]) ? t2[e3] = i2[e3] : Mz(t2[e3], i2[e3]));
  return t2;
}
function Sz(t2) {
  return "number" == typeof t2 && isFinite(t2);
}
function Cz(t2) {
  return "number" == typeof t2 && t2 % 1 == 0;
}
function zz(t2) {
  return "string" == typeof t2;
}
function $z(t2) {
  return "boolean" == typeof t2;
}
function Dz(t2) {
  const e2 = t2;
  if (!e2 || "object" != typeof e2) return e2;
  let i2, s2, n2;
  for (s2 in i2 = Array.isArray(e2) ? [] : {}, e2) e2.hasOwnProperty(s2) && (n2 = e2[s2], i2[s2] = n2 && "object" == typeof n2 ? Dz(n2) : n2);
  return i2;
}
function Rz(t2) {
  return null !== t2;
}
function Ez(t2) {
  return null === t2 ? void 0 : t2;
}
const Pz = "-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif";
function Tz(t2, e2, i2) {
  return void 0 === e2 && (e2 = Pz), `${i2 = void 0 !== i2 ? `${i2} ` : ""}${t2}px ${e2}`;
}
class W {
  constructor(t2) {
    this.k = { C: 1, T: 5, P: NaN, R: "", D: "", V: "", O: "", B: 0, A: 0, I: 0, L: 0, N: 0 }, this.F = t2;
  }
  W() {
    const t2 = this.k, e2 = this.j(), i2 = this.H();
    return t2.P === e2 && t2.D === i2 || (t2.P = e2, t2.D = i2, t2.R = Tz(e2, i2), t2.L = 2.5 / 12 * e2, t2.B = t2.L, t2.A = e2 / 12 * t2.T, t2.I = e2 / 12 * t2.T, t2.N = 0), t2.V = this.$(), t2.O = this.U(), this.k;
  }
  $() {
    return this.F.W().layout.textColor;
  }
  U() {
    return this.F.q();
  }
  j() {
    return this.F.W().layout.fontSize;
  }
  H() {
    return this.F.W().layout.fontFamily;
  }
}
class j {
  constructor() {
    this.Y = [];
  }
  Z(t2) {
    this.Y = t2;
  }
  X(t2, e2, i2) {
    this.Y.forEach((s2) => {
      s2.X(t2, e2, i2);
    });
  }
}
class H {
  X(t2, e2, i2) {
    t2.useBitmapCoordinateSpace((t3) => this.K(t3, e2, i2));
  }
}
class $ extends H {
  constructor() {
    super(...arguments), this.G = null;
  }
  J(t2) {
    this.G = t2;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    if (null === this.G || null === this.G.tt) return;
    const s2 = this.G.tt, n2 = this.G, r2 = Math.max(1, Math.floor(e2)) % 2 / 2, o2 = (o3) => {
      t2.beginPath();
      for (let a2 = s2.to - 1; a2 >= s2.from; --a2) {
        const s3 = n2.it[a2], l2 = Math.round(s3.nt * e2) + r2, h2 = s3.st * i2, c2 = o3 * i2 + r2;
        t2.moveTo(l2, h2), t2.arc(l2, h2, c2, 0, 2 * Math.PI);
      }
      t2.fill();
    };
    n2.et > 0 && (t2.fillStyle = n2.rt, o2(n2.ht + n2.et)), t2.fillStyle = n2.lt, o2(n2.ht);
  }
}
function Lz() {
  return { it: [{ nt: 0, st: 0, ot: 0, _t: 0 }], lt: "", rt: "", ht: 0, et: 0, tt: null };
}
const Vz = { from: 0, to: 1 };
class Y {
  constructor(t2, e2) {
    this.ut = new j(), this.ct = [], this.dt = [], this.ft = true, this.F = t2, this.vt = e2, this.ut.Z(this.ct);
  }
  bt(t2) {
    const e2 = this.F.wt();
    e2.length !== this.ct.length && (this.dt = e2.map(Lz), this.ct = this.dt.map((t3) => {
      const e3 = new $();
      return e3.J(t3), e3;
    }), this.ut.Z(this.ct)), this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.ut;
  }
  Mt() {
    const t2 = 2 === this.vt.W().mode, e2 = this.F.wt(), i2 = this.vt.xt(), s2 = this.F.St();
    e2.forEach((e3, n2) => {
      var r2;
      const o2 = this.dt[n2], a2 = e3.kt(i2);
      if (t2 || null === a2 || !e3.yt()) return void (o2.tt = null);
      const l2 = dz(e3.Ct());
      o2.lt = a2.Tt, o2.ht = a2.ht, o2.et = a2.Pt, o2.it[0]._t = a2._t, o2.it[0].st = e3.Dt().Rt(a2._t, l2.Vt), o2.rt = null !== (r2 = a2.Ot) && void 0 !== r2 ? r2 : this.F.Bt(o2.it[0].st / e3.Dt().At()), o2.it[0].ot = i2, o2.it[0].nt = s2.It(i2), o2.tt = Vz;
    });
  }
}
class Z extends H {
  constructor(t2) {
    super(), this.zt = t2;
  }
  K({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (null === this.zt) return;
    const n2 = this.zt.Lt.yt, r2 = this.zt.Et.yt;
    if (!n2 && !r2) return;
    const o2 = Math.round(this.zt.nt * i2), a2 = Math.round(this.zt.st * s2);
    t2.lineCap = "butt", n2 && o2 >= 0 && (t2.lineWidth = Math.floor(this.zt.Lt.et * i2), t2.strokeStyle = this.zt.Lt.V, t2.fillStyle = this.zt.Lt.V, lz(t2, this.zt.Lt.Nt), function(t3, e3, i3, s3) {
      t3.beginPath();
      const n3 = t3.lineWidth % 2 ? 0.5 : 0;
      t3.moveTo(e3 + n3, 0), t3.lineTo(e3 + n3, s3), t3.stroke();
    }(t2, o2, 0, e2.height)), r2 && a2 >= 0 && (t2.lineWidth = Math.floor(this.zt.Et.et * s2), t2.strokeStyle = this.zt.Et.V, t2.fillStyle = this.zt.Et.V, lz(t2, this.zt.Et.Nt), hz(t2, a2, 0, e2.width));
  }
}
class X {
  constructor(t2) {
    this.ft = true, this.Ft = { Lt: { et: 1, Nt: 0, V: "", yt: false }, Et: { et: 1, Nt: 0, V: "", yt: false }, nt: 0, st: 0 }, this.Wt = new Z(this.Ft), this.jt = t2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.Wt;
  }
  Mt() {
    const t2 = this.jt.yt(), e2 = dz(this.jt.Ht()), i2 = e2.$t().W().crosshair, s2 = this.Ft;
    if (2 === i2.mode) return s2.Et.yt = false, void (s2.Lt.yt = false);
    s2.Et.yt = t2 && this.jt.Ut(e2), s2.Lt.yt = t2 && this.jt.qt(), s2.Et.et = i2.horzLine.width, s2.Et.Nt = i2.horzLine.style, s2.Et.V = i2.horzLine.color, s2.Lt.et = i2.vertLine.width, s2.Lt.Nt = i2.vertLine.style, s2.Lt.V = i2.vertLine.color, s2.nt = this.jt.Yt(), s2.st = this.jt.Zt();
  }
}
function Oz(t2, e2, i2, s2, n2, r2) {
  t2.fillRect(e2 + r2, i2, s2 - 2 * r2, r2), t2.fillRect(e2 + r2, i2 + n2 - r2, s2 - 2 * r2, r2), t2.fillRect(e2, i2, r2, n2), t2.fillRect(e2 + s2 - r2, i2, r2, n2);
}
function Az(t2, e2, i2, s2, n2, r2) {
  t2.save(), t2.globalCompositeOperation = "copy", t2.fillStyle = r2, t2.fillRect(e2, i2, s2, n2), t2.restore();
}
function Fz(t2, e2, i2, s2, n2, r2) {
  t2.beginPath(), t2.roundRect ? t2.roundRect(e2, i2, s2, n2, r2) : (t2.lineTo(e2 + s2 - r2[1], i2), 0 !== r2[1] && t2.arcTo(e2 + s2, i2, e2 + s2, i2 + r2[1], r2[1]), t2.lineTo(e2 + s2, i2 + n2 - r2[2]), 0 !== r2[2] && t2.arcTo(e2 + s2, i2 + n2, e2 + s2 - r2[2], i2 + n2, r2[2]), t2.lineTo(e2 + r2[3], i2 + n2), 0 !== r2[3] && t2.arcTo(e2, i2 + n2, e2, i2 + n2 - r2[3], r2[3]), t2.lineTo(e2, i2 + r2[0]), 0 !== r2[0] && t2.arcTo(e2, i2, e2 + r2[0], i2, r2[0]));
}
function Nz(t2, e2, i2, s2, n2, r2, o2 = 0, a2 = [0, 0, 0, 0], l2 = "") {
  if (t2.save(), !o2 || !l2 || l2 === r2) return Fz(t2, e2, i2, s2, n2, a2), t2.fillStyle = r2, t2.fill(), void t2.restore();
  const h2 = o2 / 2;
  var c2;
  Fz(t2, e2 + h2, i2 + h2, s2 - o2, n2 - o2, (c2 = -h2, a2.map((t3) => 0 === t3 ? t3 : t3 + c2))), "transparent" !== r2 && (t2.fillStyle = r2, t2.fill()), "transparent" !== l2 && (t2.lineWidth = o2, t2.strokeStyle = l2, t2.closePath(), t2.stroke()), t2.restore();
}
function Wz(t2, e2, i2, s2, n2, r2, o2) {
  t2.save(), t2.globalCompositeOperation = "copy";
  const a2 = t2.createLinearGradient(0, 0, 0, n2);
  a2.addColorStop(0, r2), a2.addColorStop(1, o2), t2.fillStyle = a2, t2.fillRect(e2, i2, s2, n2), t2.restore();
}
class it {
  constructor(t2, e2) {
    this.J(t2, e2);
  }
  J(t2, e2) {
    this.zt = t2, this.Xt = e2;
  }
  At(t2, e2) {
    return this.zt.yt ? t2.P + t2.L + t2.B : 0;
  }
  X(t2, e2, i2, s2) {
    if (!this.zt.yt || 0 === this.zt.Kt.length) return;
    const n2 = this.zt.V, r2 = this.Xt.t, o2 = t2.useBitmapCoordinateSpace((t3) => {
      const o3 = t3.context;
      o3.font = e2.R;
      const a2 = this.Gt(t3, e2, i2, s2), l2 = a2.Jt;
      return a2.Qt ? Nz(o3, l2.ti, l2.ii, l2.ni, l2.si, r2, l2.ei, [l2.ht, 0, 0, l2.ht], r2) : Nz(o3, l2.ri, l2.ii, l2.ni, l2.si, r2, l2.ei, [0, l2.ht, l2.ht, 0], r2), this.zt.hi && (o3.fillStyle = n2, o3.fillRect(l2.ri, l2.li, l2.ai - l2.ri, l2.oi)), this.zt._i && (o3.fillStyle = e2.O, o3.fillRect(a2.Qt ? l2.ui - l2.ei : 0, l2.ii, l2.ei, l2.ci - l2.ii)), a2;
    });
    t2.useMediaCoordinateSpace(({ context: t3 }) => {
      const i3 = o2.di;
      t3.font = e2.R, t3.textAlign = o2.Qt ? "right" : "left", t3.textBaseline = "middle", t3.fillStyle = n2, t3.fillText(this.zt.Kt, i3.fi, (i3.ii + i3.ci) / 2 + i3.pi);
    });
  }
  Gt(t2, e2, i2, s2) {
    var n2;
    const { context: r2, bitmapSize: o2, mediaSize: a2, horizontalPixelRatio: l2, verticalPixelRatio: h2 } = t2, c2 = this.zt.hi || !this.zt.mi ? e2.T : 0, u2 = this.zt.bi ? e2.C : 0, d2 = e2.L + this.Xt.wi, f2 = e2.B + this.Xt.gi, p2 = e2.A, m2 = e2.I, g2 = this.zt.Kt, v2 = e2.P, b2 = i2.Mi(r2, g2), _2 = Math.ceil(i2.xi(r2, g2)), y2 = v2 + d2 + f2, x2 = e2.C + p2 + m2 + _2 + c2, w2 = Math.max(1, Math.floor(h2));
    let k2 = Math.round(y2 * h2);
    k2 % 2 != w2 % 2 && (k2 += 1);
    const M2 = u2 > 0 ? Math.max(1, Math.floor(u2 * l2)) : 0, S2 = Math.round(x2 * l2), C2 = Math.round(c2 * l2), z2 = null !== (n2 = this.Xt.Si) && void 0 !== n2 ? n2 : this.Xt.ki, R2 = Math.round(z2 * h2) - Math.floor(0.5 * h2), E2 = Math.floor(R2 + w2 / 2 - k2 / 2), P2 = E2 + k2, T2 = "right" === s2, L2 = T2 ? a2.width - u2 : u2, V2 = T2 ? o2.width - M2 : M2;
    let O2, A2, F2;
    return T2 ? (O2 = V2 - S2, A2 = V2 - C2, F2 = L2 - c2 - p2 - u2) : (O2 = V2 + S2, A2 = V2 + C2, F2 = L2 + c2 + p2), { Qt: T2, Jt: { ii: E2, li: R2, ci: P2, ni: S2, si: k2, ht: 2 * l2, ei: M2, ti: O2, ri: V2, ai: A2, oi: w2, ui: o2.width }, di: { ii: E2 / h2, ci: P2 / h2, fi: F2, pi: b2 } };
  }
}
class nt {
  constructor(t2) {
    this.yi = { ki: 0, t: "#000", gi: 0, wi: 0 }, this.Ci = { Kt: "", yt: false, hi: true, mi: false, Ot: "", V: "#FFF", _i: false, bi: false }, this.Ti = { Kt: "", yt: false, hi: false, mi: true, Ot: "", V: "#FFF", _i: true, bi: true }, this.ft = true, this.Pi = new (t2 || it)(this.Ci, this.yi), this.Ri = new (t2 || it)(this.Ti, this.yi);
  }
  Kt() {
    return this.Di(), this.Ci.Kt;
  }
  ki() {
    return this.Di(), this.yi.ki;
  }
  bt() {
    this.ft = true;
  }
  At(t2, e2 = false) {
    return Math.max(this.Pi.At(t2, e2), this.Ri.At(t2, e2));
  }
  Vi() {
    return this.yi.Si || 0;
  }
  Oi(t2) {
    this.yi.Si = t2;
  }
  Bi() {
    return this.Di(), this.Ci.yt || this.Ti.yt;
  }
  Ai() {
    return this.Di(), this.Ci.yt;
  }
  gt(t2) {
    return this.Di(), this.Ci.hi = this.Ci.hi && t2.W().ticksVisible, this.Ti.hi = this.Ti.hi && t2.W().ticksVisible, this.Pi.J(this.Ci, this.yi), this.Ri.J(this.Ti, this.yi), this.Pi;
  }
  Ii() {
    return this.Di(), this.Pi.J(this.Ci, this.yi), this.Ri.J(this.Ti, this.yi), this.Ri;
  }
  Di() {
    this.ft && (this.Ci.hi = true, this.Ti.hi = false, this.zi(this.Ci, this.Ti, this.yi));
  }
}
class st extends nt {
  constructor(t2, e2, i2) {
    super(), this.jt = t2, this.Li = e2, this.Ei = i2;
  }
  zi(t2, e2, i2) {
    if (t2.yt = false, 2 === this.jt.W().mode) return;
    const s2 = this.jt.W().horzLine;
    if (!s2.labelVisible) return;
    const n2 = this.Li.Ct();
    if (!this.jt.yt() || this.Li.Ni() || null === n2) return;
    const r2 = kz(s2.labelBackgroundColor);
    i2.t = r2.t, t2.V = r2.i;
    const o2 = 2 / 12 * this.Li.P();
    i2.wi = o2, i2.gi = o2;
    const a2 = this.Ei(this.Li);
    i2.ki = a2.ki, t2.Kt = this.Li.Fi(a2._t, n2), t2.yt = true;
  }
}
const Iz = /[1-9]/g;
class rt {
  constructor() {
    this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  X(t2, e2) {
    if (null === this.zt || false === this.zt.yt || 0 === this.zt.Kt.length) return;
    const i2 = t2.useMediaCoordinateSpace(({ context: t3 }) => (t3.font = e2.R, Math.round(e2.Wi.xi(t3, dz(this.zt).Kt, Iz))));
    if (i2 <= 0) return;
    const s2 = e2.ji, n2 = i2 + 2 * s2, r2 = n2 / 2, o2 = this.zt.Hi;
    let a2 = this.zt.ki, l2 = Math.floor(a2 - r2) + 0.5;
    l2 < 0 ? (a2 += Math.abs(0 - l2), l2 = Math.floor(a2 - r2) + 0.5) : l2 + n2 > o2 && (a2 -= Math.abs(o2 - (l2 + n2)), l2 = Math.floor(a2 - r2) + 0.5);
    const h2 = l2 + n2, c2 = Math.ceil(0 + e2.C + e2.T + e2.L + e2.P + e2.B);
    t2.useBitmapCoordinateSpace(({ context: t3, horizontalPixelRatio: i3, verticalPixelRatio: s3 }) => {
      const n3 = dz(this.zt);
      t3.fillStyle = n3.t;
      const r3 = Math.round(l2 * i3), o3 = Math.round(0 * s3), a3 = Math.round(h2 * i3), u2 = Math.round(c2 * s3), d2 = Math.round(2 * i3);
      if (t3.beginPath(), t3.moveTo(r3, o3), t3.lineTo(r3, u2 - d2), t3.arcTo(r3, u2, r3 + d2, u2, d2), t3.lineTo(a3 - d2, u2), t3.arcTo(a3, u2, a3, u2 - d2, d2), t3.lineTo(a3, o3), t3.fill(), n3.hi) {
        const r4 = Math.round(n3.ki * i3), a4 = o3, l3 = Math.round((a4 + e2.T) * s3);
        t3.fillStyle = n3.V;
        const h3 = Math.max(1, Math.floor(i3)), c3 = Math.floor(0.5 * i3);
        t3.fillRect(r4 - c3, a4, h3, l3 - a4);
      }
    }), t2.useMediaCoordinateSpace(({ context: t3 }) => {
      const i3 = dz(this.zt), n3 = 0 + e2.C + e2.T + e2.L + e2.P / 2;
      t3.font = e2.R, t3.textAlign = "left", t3.textBaseline = "middle", t3.fillStyle = i3.V;
      const r3 = e2.Wi.Mi(t3, "Apr0");
      t3.translate(l2 + s2, n3 + r3), t3.fillText(i3.Kt, 0, 0);
    });
  }
}
class ht {
  constructor(t2, e2, i2) {
    this.ft = true, this.Wt = new rt(), this.Ft = { yt: false, t: "#4c525e", V: "white", Kt: "", Hi: 0, ki: NaN, hi: true }, this.vt = t2, this.$i = e2, this.Ei = i2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.Wt.J(this.Ft), this.Wt;
  }
  Mt() {
    const t2 = this.Ft;
    if (t2.yt = false, 2 === this.vt.W().mode) return;
    const e2 = this.vt.W().vertLine;
    if (!e2.labelVisible) return;
    const i2 = this.$i.St();
    if (i2.Ni()) return;
    t2.Hi = i2.Hi();
    const s2 = this.Ei();
    if (null === s2) return;
    t2.ki = s2.ki;
    const n2 = i2.Ui(this.vt.xt());
    t2.Kt = i2.qi(dz(n2)), t2.yt = true;
    const r2 = kz(e2.labelBackgroundColor);
    t2.t = r2.t, t2.V = r2.i, t2.hi = i2.W().ticksVisible;
  }
}
class lt {
  constructor() {
    this.Yi = null, this.Zi = 0;
  }
  Xi() {
    return this.Zi;
  }
  Ki(t2) {
    this.Zi = t2;
  }
  Dt() {
    return this.Yi;
  }
  Gi(t2) {
    this.Yi = t2;
  }
  Ji(t2) {
    return [];
  }
  Qi() {
    return [];
  }
  yt() {
    return true;
  }
}
var Bz;
!function(t2) {
  t2[t2.Normal = 0] = "Normal", t2[t2.Magnet = 1] = "Magnet", t2[t2.Hidden = 2] = "Hidden";
}(Bz || (Bz = {}));
class ot extends lt {
  constructor(t2, e2) {
    super(), this.tn = null, this.nn = NaN, this.sn = 0, this.en = true, this.rn = /* @__PURE__ */ new Map(), this.hn = false, this.ln = NaN, this.an = NaN, this._n = NaN, this.un = NaN, this.$i = t2, this.cn = e2, this.dn = new Y(t2, this), this.fn = /* @__PURE__ */ ((t3, e3) => (i3) => {
      const s2 = e3(), n2 = t3();
      if (i3 === dz(this.tn).vn()) return { _t: n2, ki: s2 };
      {
        const t4 = dz(i3.Ct());
        return { _t: i3.pn(s2, t4), ki: s2 };
      }
    })(() => this.nn, () => this.an);
    const i2 = /* @__PURE__ */ ((t3, e3) => () => {
      const i3 = this.$i.St().mn(t3()), s2 = e3();
      return i3 && Number.isFinite(s2) ? { ot: i3, ki: s2 } : null;
    })(() => this.sn, () => this.Yt());
    this.bn = new ht(this, t2, i2), this.wn = new X(this);
  }
  W() {
    return this.cn;
  }
  gn(t2, e2) {
    this._n = t2, this.un = e2;
  }
  Mn() {
    this._n = NaN, this.un = NaN;
  }
  xn() {
    return this._n;
  }
  Sn() {
    return this.un;
  }
  kn(t2, e2, i2) {
    this.hn || (this.hn = true), this.en = true, this.yn(t2, e2, i2);
  }
  xt() {
    return this.sn;
  }
  Yt() {
    return this.ln;
  }
  Zt() {
    return this.an;
  }
  yt() {
    return this.en;
  }
  Cn() {
    this.en = false, this.Tn(), this.nn = NaN, this.ln = NaN, this.an = NaN, this.tn = null, this.Mn();
  }
  Pn(t2) {
    return null !== this.tn ? [this.wn, this.dn] : [];
  }
  Ut(t2) {
    return t2 === this.tn && this.cn.horzLine.visible;
  }
  qt() {
    return this.cn.vertLine.visible;
  }
  Rn(t2, e2) {
    this.en && this.tn === t2 || this.rn.clear();
    const i2 = [];
    return this.tn === t2 && i2.push(this.Dn(this.rn, e2, this.fn)), i2;
  }
  Qi() {
    return this.en ? [this.bn] : [];
  }
  Ht() {
    return this.tn;
  }
  Vn() {
    this.wn.bt(), this.rn.forEach((t2) => t2.bt()), this.bn.bt(), this.dn.bt();
  }
  On(t2) {
    return t2 && !t2.vn().Ni() ? t2.vn() : null;
  }
  yn(t2, e2, i2) {
    this.Bn(t2, e2, i2) && this.Vn();
  }
  Bn(t2, e2, i2) {
    const s2 = this.ln, n2 = this.an, r2 = this.nn, o2 = this.sn, a2 = this.tn, l2 = this.On(i2);
    this.sn = t2, this.ln = isNaN(t2) ? NaN : this.$i.St().It(t2), this.tn = i2;
    const h2 = null !== l2 ? l2.Ct() : null;
    return null !== l2 && null !== h2 ? (this.nn = e2, this.an = l2.Rt(e2, h2)) : (this.nn = NaN, this.an = NaN), s2 !== this.ln || n2 !== this.an || o2 !== this.sn || r2 !== this.nn || a2 !== this.tn;
  }
  Tn() {
    const t2 = this.$i.wt().map((t3) => t3.In().An()).filter(Rz), e2 = 0 === t2.length ? null : Math.max(...t2);
    this.sn = null !== e2 ? e2 : NaN;
  }
  Dn(t2, e2, i2) {
    let s2 = t2.get(e2);
    return void 0 === s2 && (s2 = new st(this, e2, i2), t2.set(e2, s2)), s2;
  }
}
function jz(t2) {
  return "left" === t2 || "right" === t2;
}
class ut {
  constructor(t2) {
    this.zn = /* @__PURE__ */ new Map(), this.Ln = [], this.En = t2;
  }
  Nn(t2, e2) {
    const i2 = function(t3, e3) {
      return void 0 === t3 ? e3 : { Fn: Math.max(t3.Fn, e3.Fn), Wn: t3.Wn || e3.Wn };
    }(this.zn.get(t2), e2);
    this.zn.set(t2, i2);
  }
  jn() {
    return this.En;
  }
  Hn(t2) {
    const e2 = this.zn.get(t2);
    return void 0 === e2 ? { Fn: this.En } : { Fn: Math.max(this.En, e2.Fn), Wn: e2.Wn };
  }
  $n() {
    this.Un(), this.Ln = [{ qn: 0 }];
  }
  Yn(t2) {
    this.Un(), this.Ln = [{ qn: 1, Vt: t2 }];
  }
  Zn(t2) {
    this.Xn(), this.Ln.push({ qn: 5, Vt: t2 });
  }
  Un() {
    this.Xn(), this.Ln.push({ qn: 6 });
  }
  Kn() {
    this.Un(), this.Ln = [{ qn: 4 }];
  }
  Gn(t2) {
    this.Un(), this.Ln.push({ qn: 2, Vt: t2 });
  }
  Jn(t2) {
    this.Un(), this.Ln.push({ qn: 3, Vt: t2 });
  }
  Qn() {
    return this.Ln;
  }
  ts(t2) {
    for (const e2 of t2.Ln) this.ns(e2);
    this.En = Math.max(this.En, t2.En), t2.zn.forEach((t3, e2) => {
      this.Nn(e2, t3);
    });
  }
  static ss() {
    return new ut(2);
  }
  static es() {
    return new ut(3);
  }
  ns(t2) {
    switch (t2.qn) {
      case 0:
        this.$n();
        break;
      case 1:
        this.Yn(t2.Vt);
        break;
      case 2:
        this.Gn(t2.Vt);
        break;
      case 3:
        this.Jn(t2.Vt);
        break;
      case 4:
        this.Kn();
        break;
      case 5:
        this.Zn(t2.Vt);
        break;
      case 6:
        this.Xn();
    }
  }
  Xn() {
    const t2 = this.Ln.findIndex((t3) => 5 === t3.qn);
    -1 !== t2 && this.Ln.splice(t2, 1);
  }
}
function Hz(t2, e2) {
  if (!Sz(t2)) return "n/a";
  if (!Cz(e2)) throw new TypeError("invalid length");
  if (e2 < 0 || e2 > 16) throw new TypeError("invalid length");
  return 0 === e2 ? t2.toString() : ("0000000000000000" + t2.toString()).slice(-e2);
}
class ft {
  constructor(t2, e2) {
    if (e2 || (e2 = 1), Sz(t2) && Cz(t2) || (t2 = 100), t2 < 0) throw new TypeError("invalid base");
    this.Li = t2, this.rs = e2, this.hs();
  }
  format(t2) {
    const e2 = t2 < 0 ? "−" : "";
    return t2 = Math.abs(t2), e2 + this.ls(t2);
  }
  hs() {
    if (this._s = 0, this.Li > 0 && this.rs > 0) {
      let t2 = this.Li;
      for (; t2 > 1; ) t2 /= 10, this._s++;
    }
  }
  ls(t2) {
    const e2 = this.Li / this.rs;
    let i2 = Math.floor(t2), s2 = "";
    const n2 = void 0 !== this._s ? this._s : NaN;
    if (e2 > 1) {
      let r2 = +(Math.round(t2 * e2) - i2 * e2).toFixed(this._s);
      r2 >= e2 && (r2 -= e2, i2 += 1), s2 = "." + Hz(+r2.toFixed(this._s) * this.rs, n2);
    } else i2 = Math.round(i2 * e2) / e2, n2 > 0 && (s2 = "." + Hz(0, n2));
    return i2.toFixed(0) + s2;
  }
}
class vt extends ft {
  constructor(t2 = 100) {
    super(t2);
  }
  format(t2) {
    return `${super.format(t2)}%`;
  }
}
class pt {
  constructor(t2) {
    this.us = t2;
  }
  format(t2) {
    let e2 = "";
    return t2 < 0 && (e2 = "-", t2 = -t2), t2 < 995 ? e2 + this.cs(t2) : t2 < 999995 ? e2 + this.cs(t2 / 1e3) + "K" : t2 < 999999995 ? (t2 = 1e3 * Math.round(t2 / 1e3), e2 + this.cs(t2 / 1e6) + "M") : (t2 = 1e6 * Math.round(t2 / 1e6), e2 + this.cs(t2 / 1e9) + "B");
  }
  cs(t2) {
    let e2;
    const i2 = Math.pow(10, this.us);
    return e2 = (t2 = Math.round(t2 * i2) / i2) >= 1e-15 && t2 < 1 ? t2.toFixed(this.us).replace(/\.?0+$/, "") : String(t2), e2.replace(/(\.[1-9]*)0+$/, (t3, e3) => e3);
  }
}
function qz(t2, e2, i2, s2, n2, r2, o2) {
  if (0 === e2.length || s2.from >= e2.length || s2.to <= 0) return;
  const { context: a2, horizontalPixelRatio: l2, verticalPixelRatio: h2 } = t2, c2 = e2[s2.from];
  let u2 = r2(t2, c2), d2 = c2;
  if (s2.to - s2.from < 2) {
    const e3 = n2 / 2;
    a2.beginPath();
    const i3 = { nt: c2.nt - e3, st: c2.st }, s3 = { nt: c2.nt + e3, st: c2.st };
    a2.moveTo(i3.nt * l2, i3.st * h2), a2.lineTo(s3.nt * l2, s3.st * h2), o2(t2, u2, i3, s3);
  } else {
    const n3 = (e3, i3) => {
      o2(t2, u2, d2, i3), a2.beginPath(), u2 = e3, d2 = i3;
    };
    let f2 = d2;
    a2.beginPath(), a2.moveTo(c2.nt * l2, c2.st * h2);
    for (let o3 = s2.from + 1; o3 < s2.to; ++o3) {
      f2 = e2[o3];
      const s3 = r2(t2, f2);
      switch (i2) {
        case 0:
          a2.lineTo(f2.nt * l2, f2.st * h2);
          break;
        case 1:
          a2.lineTo(f2.nt * l2, e2[o3 - 1].st * h2), s3 !== u2 && (n3(s3, f2), a2.lineTo(f2.nt * l2, e2[o3 - 1].st * h2)), a2.lineTo(f2.nt * l2, f2.st * h2);
          break;
        case 2: {
          const [t3, i3] = Yz(e2, o3 - 1, o3);
          a2.bezierCurveTo(t3.nt * l2, t3.st * h2, i3.nt * l2, i3.st * h2, f2.nt * l2, f2.st * h2);
          break;
        }
      }
      1 !== i2 && s3 !== u2 && (n3(s3, f2), a2.moveTo(f2.nt * l2, f2.st * h2));
    }
    (d2 !== f2 || d2 === f2 && 1 === i2) && o2(t2, u2, d2, f2);
  }
}
const Xz = 6;
function Kz(t2, e2) {
  return { nt: t2.nt - e2.nt, st: t2.st - e2.st };
}
function Uz(t2, e2) {
  return { nt: t2.nt / e2, st: t2.st / e2 };
}
function Yz(t2, e2, i2) {
  const s2 = Math.max(0, e2 - 1), n2 = Math.min(t2.length - 1, i2 + 1);
  var r2, o2;
  return [(r2 = t2[e2], o2 = Uz(Kz(t2[i2], t2[s2]), Xz), { nt: r2.nt + o2.nt, st: r2.st + o2.st }), Kz(t2[i2], Uz(Kz(t2[n2], t2[e2]), Xz))];
}
function Gz(t2, e2, i2, s2, n2) {
  const { context: r2, horizontalPixelRatio: o2, verticalPixelRatio: a2 } = e2;
  r2.lineTo(n2.nt * o2, t2 * a2), r2.lineTo(s2.nt * o2, t2 * a2), r2.closePath(), r2.fillStyle = i2, r2.fill();
}
class St extends H {
  constructor() {
    super(...arguments), this.G = null;
  }
  J(t2) {
    this.G = t2;
  }
  K(t2) {
    var e2;
    if (null === this.G) return;
    const { it: i2, tt: s2, ds: n2, et: r2, Nt: o2, fs: a2 } = this.G, l2 = null !== (e2 = this.G.vs) && void 0 !== e2 ? e2 : this.G.ps ? 0 : t2.mediaSize.height;
    if (null === s2) return;
    const h2 = t2.context;
    h2.lineCap = "butt", h2.lineJoin = "round", h2.lineWidth = r2, lz(h2, o2), h2.lineWidth = 1, qz(t2, i2, a2, s2, n2, this.bs.bind(this), Gz.bind(null, l2));
  }
}
function Jz(t2, e2, i2) {
  return Math.min(Math.max(t2, e2), i2);
}
function Qz(t2, e2, i2) {
  return e2 - t2 <= i2;
}
function Zz(t2) {
  const e2 = Math.ceil(t2);
  return e2 % 2 == 0 ? e2 - 1 : e2;
}
class Tt {
  ws(t2, e2) {
    const i2 = this.gs, { Ms: s2, xs: n2, Ss: r2, ks: o2, ys: a2, vs: l2 } = e2;
    if (void 0 === this.Cs || void 0 === i2 || i2.Ms !== s2 || i2.xs !== n2 || i2.Ss !== r2 || i2.ks !== o2 || i2.vs !== l2 || i2.ys !== a2) {
      const i3 = t2.context.createLinearGradient(0, 0, 0, a2);
      if (i3.addColorStop(0, s2), null != l2) {
        const e3 = Jz(l2 * t2.verticalPixelRatio / a2, 0, 1);
        i3.addColorStop(e3, n2), i3.addColorStop(e3, r2);
      }
      i3.addColorStop(1, o2), this.Cs = i3, this.gs = e2;
    }
    return this.Cs;
  }
}
class Pt extends St {
  constructor() {
    super(...arguments), this.Ts = new Tt();
  }
  bs(t2, e2) {
    return this.Ts.ws(t2, { Ms: e2.Ps, xs: "", Ss: "", ks: e2.Rs, ys: t2.bitmapSize.height });
  }
}
function t$(t2, e2) {
  const i2 = t2.context;
  i2.strokeStyle = e2, i2.stroke();
}
class Dt extends H {
  constructor() {
    super(...arguments), this.G = null;
  }
  J(t2) {
    this.G = t2;
  }
  K(t2) {
    if (null === this.G) return;
    const { it: e2, tt: i2, ds: s2, fs: n2, et: r2, Nt: o2, Ds: a2 } = this.G;
    if (null === i2) return;
    const l2 = t2.context;
    l2.lineCap = "butt", l2.lineWidth = r2 * t2.verticalPixelRatio, lz(l2, o2), l2.lineJoin = "round";
    const h2 = this.Vs.bind(this);
    void 0 !== n2 && qz(t2, e2, n2, i2, s2, h2, t$), a2 && function(t3, e3, i3, s3, n3) {
      const { horizontalPixelRatio: r3, verticalPixelRatio: o3, context: a3 } = t3;
      let l3 = null;
      const h3 = Math.max(1, Math.floor(r3)) % 2 / 2, c2 = i3 * o3 + h3;
      for (let i4 = s3.to - 1; i4 >= s3.from; --i4) {
        const s4 = e3[i4];
        if (s4) {
          const e4 = n3(t3, s4);
          e4 !== l3 && (a3.beginPath(), null !== l3 && a3.fill(), a3.fillStyle = e4, l3 = e4);
          const i5 = Math.round(s4.nt * r3) + h3, u2 = s4.st * o3;
          a3.moveTo(i5, u2), a3.arc(i5, u2, c2, 0, 2 * Math.PI);
        }
      }
      a3.fill();
    }(t2, e2, a2, i2, h2);
  }
}
class Vt extends Dt {
  Vs(t2, e2) {
    return e2.lt;
  }
}
function e$(t2, e2, i2, s2, n2 = 0, r2 = e2.length) {
  let o2 = r2 - n2;
  for (; 0 < o2; ) {
    const r3 = o2 >> 1, a2 = n2 + r3;
    s2(e2[a2], i2) === t2 ? (n2 = a2 + 1, o2 -= r3 + 1) : o2 = r3;
  }
  return n2;
}
const i$ = e$.bind(null, true), s$ = e$.bind(null, false);
function n$(t2, e2) {
  return t2.ot < e2;
}
function r$(t2, e2) {
  return e2 < t2.ot;
}
function o$(t2, e2, i2) {
  const s2 = e2.Os(), n2 = e2.ui(), r2 = i$(t2, s2, n$), o2 = s$(t2, n2, r$);
  if (!i2) return { from: r2, to: o2 };
  let a2 = r2, l2 = o2;
  return r2 > 0 && r2 < t2.length && t2[r2].ot >= s2 && (a2 = r2 - 1), o2 > 0 && o2 < t2.length && t2[o2 - 1].ot <= n2 && (l2 = o2 + 1), { from: a2, to: l2 };
}
class Et {
  constructor(t2, e2, i2) {
    this.Bs = true, this.As = true, this.Is = true, this.zs = [], this.Ls = null, this.Es = t2, this.Ns = e2, this.Fs = i2;
  }
  bt(t2) {
    this.Bs = true, "data" === t2 && (this.As = true), "options" === t2 && (this.Is = true);
  }
  gt() {
    return this.Es.yt() ? (this.Ws(), null === this.Ls ? null : this.js) : null;
  }
  Hs() {
    this.zs = this.zs.map((t2) => Object.assign(Object.assign({}, t2), this.Es.Us().$s(t2.ot)));
  }
  qs() {
    this.Ls = null;
  }
  Ws() {
    this.As && (this.Ys(), this.As = false), this.Is && (this.Hs(), this.Is = false), this.Bs && (this.Zs(), this.Bs = false);
  }
  Zs() {
    const t2 = this.Es.Dt(), e2 = this.Ns.St();
    if (this.qs(), e2.Ni() || t2.Ni()) return;
    const i2 = e2.Xs();
    if (null === i2) return;
    if (0 === this.Es.In().Ks()) return;
    const s2 = this.Es.Ct();
    null !== s2 && (this.Ls = o$(this.zs, i2, this.Fs), this.Gs(t2, e2, s2.Vt), this.Js());
  }
}
class Nt extends Et {
  constructor(t2, e2) {
    super(t2, e2, true);
  }
  Gs(t2, e2, i2) {
    e2.Qs(this.zs, Ez(this.Ls)), t2.te(this.zs, i2, Ez(this.Ls));
  }
  ie(t2, e2) {
    return { ot: t2, _t: e2, nt: NaN, st: NaN };
  }
  Ys() {
    const t2 = this.Es.Us();
    this.zs = this.Es.In().ne().map((e2) => {
      const i2 = e2.Vt[3];
      return this.se(e2.ee, i2, t2);
    });
  }
}
class Ft extends Nt {
  constructor(t2, e2) {
    super(t2, e2), this.js = new j(), this.re = new Pt(), this.he = new Vt(), this.js.Z([this.re, this.he]);
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W();
    this.re.J({ fs: t2.lineType, it: this.zs, Nt: t2.lineStyle, et: t2.lineWidth, vs: null, ps: t2.invertFilledArea, tt: this.Ls, ds: this.Ns.St().le() }), this.he.J({ fs: t2.lineVisible ? t2.lineType : void 0, it: this.zs, Nt: t2.lineStyle, et: t2.lineWidth, tt: this.Ls, ds: this.Ns.St().le(), Ds: t2.pointMarkersVisible ? t2.pointMarkersRadius || t2.lineWidth / 2 + 2 : void 0 });
  }
}
class Wt extends H {
  constructor() {
    super(...arguments), this.zt = null, this.ae = 0, this.oe = 0;
  }
  J(t2) {
    this.zt = t2;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    if (null === this.zt || 0 === this.zt.In.length || null === this.zt.tt) return;
    this.ae = this._e(e2), this.ae >= 2 && Math.max(1, Math.floor(e2)) % 2 != this.ae % 2 && this.ae--, this.oe = this.zt.ue ? Math.min(this.ae, Math.floor(e2)) : this.ae;
    let s2 = null;
    const n2 = this.oe <= this.ae && this.zt.le >= Math.floor(1.5 * e2);
    for (let r2 = this.zt.tt.from; r2 < this.zt.tt.to; ++r2) {
      const o2 = this.zt.In[r2];
      s2 !== o2.ce && (t2.fillStyle = o2.ce, s2 = o2.ce);
      const a2 = Math.floor(0.5 * this.oe), l2 = Math.round(o2.nt * e2), h2 = l2 - a2, c2 = this.oe, u2 = h2 + c2 - 1, d2 = Math.min(o2.de, o2.fe), f2 = Math.max(o2.de, o2.fe), p2 = Math.round(d2 * i2) - a2, m2 = Math.round(f2 * i2) + a2, g2 = Math.max(m2 - p2, this.oe);
      t2.fillRect(h2, p2, c2, g2);
      const v2 = Math.ceil(1.5 * this.ae);
      if (n2) {
        if (this.zt.ve) {
          const e4 = l2 - v2;
          let s4 = Math.max(p2, Math.round(o2.pe * i2) - a2), n4 = s4 + c2 - 1;
          n4 > p2 + g2 - 1 && (n4 = p2 + g2 - 1, s4 = n4 - c2 + 1), t2.fillRect(e4, s4, h2 - e4, n4 - s4 + 1);
        }
        const e3 = l2 + v2;
        let s3 = Math.max(p2, Math.round(o2.me * i2) - a2), n3 = s3 + c2 - 1;
        n3 > p2 + g2 - 1 && (n3 = p2 + g2 - 1, s3 = n3 - c2 + 1), t2.fillRect(u2 + 1, s3, e3 - u2, n3 - s3 + 1);
      }
    }
  }
  _e(t2) {
    const e2 = Math.floor(t2);
    return Math.max(e2, Math.floor(function(t3, e3) {
      return Math.floor(0.3 * t3 * e3);
    }(dz(this.zt).le, t2)));
  }
}
class jt extends Et {
  constructor(t2, e2) {
    super(t2, e2, false);
  }
  Gs(t2, e2, i2) {
    e2.Qs(this.zs, Ez(this.Ls)), t2.be(this.zs, i2, Ez(this.Ls));
  }
  we(t2, e2, i2) {
    return { ot: t2, ge: e2.Vt[0], Me: e2.Vt[1], xe: e2.Vt[2], Se: e2.Vt[3], nt: NaN, pe: NaN, de: NaN, fe: NaN, me: NaN };
  }
  Ys() {
    const t2 = this.Es.Us();
    this.zs = this.Es.In().ne().map((e2) => this.se(e2.ee, e2, t2));
  }
}
class Ht extends jt {
  constructor() {
    super(...arguments), this.js = new Wt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.we(t2, e2, i2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W();
    this.js.J({ In: this.zs, le: this.Ns.St().le(), ve: t2.openVisible, ue: t2.thinBars, tt: this.Ls });
  }
}
class $t extends St {
  constructor() {
    super(...arguments), this.Ts = new Tt();
  }
  bs(t2, e2) {
    const i2 = this.G;
    return this.Ts.ws(t2, { Ms: e2.ke, xs: e2.ye, Ss: e2.Ce, ks: e2.Te, ys: t2.bitmapSize.height, vs: i2.vs });
  }
}
class Ut extends Dt {
  constructor() {
    super(...arguments), this.Pe = new Tt();
  }
  Vs(t2, e2) {
    const i2 = this.G;
    return this.Pe.ws(t2, { Ms: e2.Re, xs: e2.Re, Ss: e2.De, ks: e2.De, ys: t2.bitmapSize.height, vs: i2.vs });
  }
}
class qt extends Nt {
  constructor(t2, e2) {
    super(t2, e2), this.js = new j(), this.Ve = new $t(), this.Oe = new Ut(), this.js.Z([this.Ve, this.Oe]);
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.Ct();
    if (null === t2) return;
    const e2 = this.Es.W(), i2 = this.Es.Dt().Rt(e2.baseValue.price, t2.Vt), s2 = this.Ns.St().le();
    this.Ve.J({ it: this.zs, et: e2.lineWidth, Nt: e2.lineStyle, fs: e2.lineType, vs: i2, ps: false, tt: this.Ls, ds: s2 }), this.Oe.J({ it: this.zs, et: e2.lineWidth, Nt: e2.lineStyle, fs: e2.lineVisible ? e2.lineType : void 0, Ds: e2.pointMarkersVisible ? e2.pointMarkersRadius || e2.lineWidth / 2 + 2 : void 0, vs: i2, tt: this.Ls, ds: s2 });
  }
}
class Yt extends H {
  constructor() {
    super(...arguments), this.zt = null, this.ae = 0;
  }
  J(t2) {
    this.zt = t2;
  }
  K(t2) {
    if (null === this.zt || 0 === this.zt.In.length || null === this.zt.tt) return;
    const { horizontalPixelRatio: e2 } = t2;
    this.ae = function(t3, e3) {
      if (t3 >= 2.5 && t3 <= 4) return Math.floor(3 * e3);
      const i3 = 1 - 0.2 * Math.atan(Math.max(4, t3) - 4) / (0.5 * Math.PI), s3 = Math.floor(t3 * i3 * e3), n2 = Math.floor(t3 * e3), r2 = Math.min(s3, n2);
      return Math.max(Math.floor(e3), r2);
    }(this.zt.le, e2), this.ae >= 2 && Math.floor(e2) % 2 != this.ae % 2 && this.ae--;
    const i2 = this.zt.In;
    this.zt.Be && this.Ae(t2, i2, this.zt.tt), this.zt._i && this.Ie(t2, i2, this.zt.tt);
    const s2 = this.ze(e2);
    (!this.zt._i || this.ae > 2 * s2) && this.Le(t2, i2, this.zt.tt);
  }
  Ae(t2, e2, i2) {
    if (null === this.zt) return;
    const { context: s2, horizontalPixelRatio: n2, verticalPixelRatio: r2 } = t2;
    let o2 = "", a2 = Math.min(Math.floor(n2), Math.floor(this.zt.le * n2));
    a2 = Math.max(Math.floor(n2), Math.min(a2, this.ae));
    const l2 = Math.floor(0.5 * a2);
    let h2 = null;
    for (let t3 = i2.from; t3 < i2.to; t3++) {
      const i3 = e2[t3];
      i3.Ee !== o2 && (s2.fillStyle = i3.Ee, o2 = i3.Ee);
      const c2 = Math.round(Math.min(i3.pe, i3.me) * r2), u2 = Math.round(Math.max(i3.pe, i3.me) * r2), d2 = Math.round(i3.de * r2), f2 = Math.round(i3.fe * r2);
      let p2 = Math.round(n2 * i3.nt) - l2;
      const m2 = p2 + a2 - 1;
      null !== h2 && (p2 = Math.max(h2 + 1, p2), p2 = Math.min(p2, m2));
      const g2 = m2 - p2 + 1;
      s2.fillRect(p2, d2, g2, c2 - d2), s2.fillRect(p2, u2 + 1, g2, f2 - u2), h2 = m2;
    }
  }
  ze(t2) {
    let e2 = Math.floor(1 * t2);
    this.ae <= 2 * e2 && (e2 = Math.floor(0.5 * (this.ae - 1)));
    const i2 = Math.max(Math.floor(t2), e2);
    return this.ae <= 2 * i2 ? Math.max(Math.floor(t2), Math.floor(1 * t2)) : i2;
  }
  Ie(t2, e2, i2) {
    if (null === this.zt) return;
    const { context: s2, horizontalPixelRatio: n2, verticalPixelRatio: r2 } = t2;
    let o2 = "";
    const a2 = this.ze(n2);
    let l2 = null;
    for (let t3 = i2.from; t3 < i2.to; t3++) {
      const i3 = e2[t3];
      i3.Ne !== o2 && (s2.fillStyle = i3.Ne, o2 = i3.Ne);
      let h2 = Math.round(i3.nt * n2) - Math.floor(0.5 * this.ae);
      const c2 = h2 + this.ae - 1, u2 = Math.round(Math.min(i3.pe, i3.me) * r2), d2 = Math.round(Math.max(i3.pe, i3.me) * r2);
      if (null !== l2 && (h2 = Math.max(l2 + 1, h2), h2 = Math.min(h2, c2)), this.zt.le * n2 > 2 * a2) Oz(s2, h2, u2, c2 - h2 + 1, d2 - u2 + 1, a2);
      else {
        const t4 = c2 - h2 + 1;
        s2.fillRect(h2, u2, t4, d2 - u2 + 1);
      }
      l2 = c2;
    }
  }
  Le(t2, e2, i2) {
    if (null === this.zt) return;
    const { context: s2, horizontalPixelRatio: n2, verticalPixelRatio: r2 } = t2;
    let o2 = "";
    const a2 = this.ze(n2);
    for (let t3 = i2.from; t3 < i2.to; t3++) {
      const i3 = e2[t3];
      let l2 = Math.round(Math.min(i3.pe, i3.me) * r2), h2 = Math.round(Math.max(i3.pe, i3.me) * r2), c2 = Math.round(i3.nt * n2) - Math.floor(0.5 * this.ae), u2 = c2 + this.ae - 1;
      if (i3.ce !== o2) {
        const t4 = i3.ce;
        s2.fillStyle = t4, o2 = t4;
      }
      this.zt._i && (c2 += a2, l2 += a2, u2 -= a2, h2 -= a2), l2 > h2 || s2.fillRect(c2, l2, u2 - c2 + 1, h2 - l2 + 1);
    }
  }
}
class Zt extends jt {
  constructor() {
    super(...arguments), this.js = new Yt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.we(t2, e2, i2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W();
    this.js.J({ In: this.zs, le: this.Ns.St().le(), Be: t2.wickVisible, _i: t2.borderVisible, tt: this.Ls });
  }
}
class Xt {
  constructor(t2, e2) {
    this.Fe = t2, this.Li = e2;
  }
  X(t2, e2, i2) {
    this.Fe.draw(t2, this.Li, e2, i2);
  }
}
class Kt extends Et {
  constructor(t2, e2, i2) {
    super(t2, e2, false), this.wn = i2, this.js = new Xt(this.wn.renderer(), (e3) => {
      const i3 = t2.Ct();
      return null === i3 ? null : t2.Dt().Rt(e3, i3.Vt);
    });
  }
  We(t2) {
    return this.wn.priceValueBuilder(t2);
  }
  je(t2) {
    return this.wn.isWhitespace(t2);
  }
  Ys() {
    const t2 = this.Es.Us();
    this.zs = this.Es.In().ne().map((e2) => Object.assign(Object.assign({ ot: e2.ee, nt: NaN }, t2.$s(e2.ee)), { He: e2.$e }));
  }
  Gs(t2, e2) {
    e2.Qs(this.zs, Ez(this.Ls));
  }
  Js() {
    this.wn.update({ bars: this.zs.map(a$), barSpacing: this.Ns.St().le(), visibleRange: this.Ls }, this.Es.W());
  }
}
function a$(t2) {
  return { x: t2.nt, time: t2.ot, originalData: t2.He, barColor: t2.ce };
}
class Jt extends H {
  constructor() {
    super(...arguments), this.zt = null, this.Ue = [];
  }
  J(t2) {
    this.zt = t2, this.Ue = [];
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    if (null === this.zt || 0 === this.zt.it.length || null === this.zt.tt) return;
    this.Ue.length || this.qe(e2);
    const s2 = Math.max(1, Math.floor(i2)), n2 = Math.round(this.zt.Ye * i2) - Math.floor(s2 / 2), r2 = n2 + s2;
    for (let e3 = this.zt.tt.from; e3 < this.zt.tt.to; e3++) {
      const o2 = this.zt.it[e3], a2 = this.Ue[e3 - this.zt.tt.from], l2 = Math.round(o2.st * i2);
      let h2, c2;
      t2.fillStyle = o2.ce, l2 <= n2 ? (h2 = l2, c2 = r2) : (h2 = n2, c2 = l2 - Math.floor(s2 / 2) + s2), t2.fillRect(a2.Os, h2, a2.ui - a2.Os + 1, c2 - h2);
    }
  }
  qe(t2) {
    if (null === this.zt || 0 === this.zt.it.length || null === this.zt.tt) return void (this.Ue = []);
    const e2 = Math.ceil(this.zt.le * t2) <= 1 ? 0 : Math.max(1, Math.floor(t2)), i2 = Math.round(this.zt.le * t2) - e2;
    this.Ue = new Array(this.zt.tt.to - this.zt.tt.from);
    for (let e3 = this.zt.tt.from; e3 < this.zt.tt.to; e3++) {
      const s3 = this.zt.it[e3], n2 = Math.round(s3.nt * t2);
      let r2, o2;
      if (i2 % 2) {
        const t3 = (i2 - 1) / 2;
        r2 = n2 - t3, o2 = n2 + t3;
      } else {
        const t3 = i2 / 2;
        r2 = n2 - t3, o2 = n2 + t3 - 1;
      }
      this.Ue[e3 - this.zt.tt.from] = { Os: r2, ui: o2, Ze: n2, Xe: s3.nt * t2, ot: s3.ot };
    }
    for (let t3 = this.zt.tt.from + 1; t3 < this.zt.tt.to; t3++) {
      const i3 = this.Ue[t3 - this.zt.tt.from], s3 = this.Ue[t3 - this.zt.tt.from - 1];
      i3.ot === s3.ot + 1 && i3.Os - s3.ui !== e2 + 1 && (s3.Ze > s3.Xe ? s3.ui = i3.Os - e2 - 1 : i3.Os = s3.ui + e2 + 1);
    }
    let s2 = Math.ceil(this.zt.le * t2);
    for (let t3 = this.zt.tt.from; t3 < this.zt.tt.to; t3++) {
      const e3 = this.Ue[t3 - this.zt.tt.from];
      e3.ui < e3.Os && (e3.ui = e3.Os);
      const i3 = e3.ui - e3.Os + 1;
      s2 = Math.min(i3, s2);
    }
    if (e2 > 0 && s2 < 4) for (let t3 = this.zt.tt.from; t3 < this.zt.tt.to; t3++) {
      const e3 = this.Ue[t3 - this.zt.tt.from];
      e3.ui - e3.Os + 1 > s2 && (e3.Ze > e3.Xe ? e3.ui -= 1 : e3.Os += 1);
    }
  }
}
class Qt extends Nt {
  constructor() {
    super(...arguments), this.js = new Jt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = { it: this.zs, le: this.Ns.St().le(), tt: this.Ls, Ye: this.Es.Dt().Rt(this.Es.W().base, dz(this.Es.Ct()).Vt) };
    this.js.J(t2);
  }
}
class ti extends Nt {
  constructor() {
    super(...arguments), this.js = new Vt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W(), e2 = { it: this.zs, Nt: t2.lineStyle, fs: t2.lineVisible ? t2.lineType : void 0, et: t2.lineWidth, Ds: t2.pointMarkersVisible ? t2.pointMarkersRadius || t2.lineWidth / 2 + 2 : void 0, tt: this.Ls, ds: this.Ns.St().le() };
    this.js.J(e2);
  }
}
const l$ = /[2-9]/g;
class ni {
  constructor(t2 = 50) {
    this.Ke = 0, this.Ge = 1, this.Je = 1, this.Qe = {}, this.tr = /* @__PURE__ */ new Map(), this.ir = t2;
  }
  nr() {
    this.Ke = 0, this.tr.clear(), this.Ge = 1, this.Je = 1, this.Qe = {};
  }
  xi(t2, e2, i2) {
    return this.sr(t2, e2, i2).width;
  }
  Mi(t2, e2, i2) {
    const s2 = this.sr(t2, e2, i2);
    return ((s2.actualBoundingBoxAscent || 0) - (s2.actualBoundingBoxDescent || 0)) / 2;
  }
  sr(t2, e2, i2) {
    const s2 = i2 || l$, n2 = String(e2).replace(s2, "0");
    if (this.tr.has(n2)) return uz(this.tr.get(n2)).er;
    if (this.Ke === this.ir) {
      const t3 = this.Qe[this.Je];
      delete this.Qe[this.Je], this.tr.delete(t3), this.Je++, this.Ke--;
    }
    t2.save(), t2.textBaseline = "middle";
    const r2 = t2.measureText(n2);
    return t2.restore(), 0 === r2.width && e2.length || (this.tr.set(n2, { er: r2, rr: this.Ge }), this.Qe[this.Ge] = n2, this.Ke++, this.Ge++), r2;
  }
}
class si {
  constructor(t2) {
    this.hr = null, this.k = null, this.lr = "right", this.ar = t2;
  }
  _r(t2, e2, i2) {
    this.hr = t2, this.k = e2, this.lr = i2;
  }
  X(t2) {
    null !== this.k && null !== this.hr && this.hr.X(t2, this.k, this.ar, this.lr);
  }
}
class ei {
  constructor(t2, e2, i2) {
    this.ur = t2, this.ar = new ni(50), this.cr = e2, this.F = i2, this.j = -1, this.Wt = new si(this.ar);
  }
  gt() {
    const t2 = this.F.dr(this.cr);
    if (null === t2) return null;
    const e2 = t2.vr(this.cr) ? t2.pr() : this.cr.Dt();
    if (null === e2) return null;
    const i2 = t2.mr(e2);
    if ("overlay" === i2) return null;
    const s2 = this.F.br();
    return s2.P !== this.j && (this.j = s2.P, this.ar.nr()), this.Wt._r(this.ur.Ii(), s2, i2), this.Wt;
  }
}
class ri extends H {
  constructor() {
    super(...arguments), this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  wr(t2, e2) {
    var i2;
    if (!(null === (i2 = this.zt) || void 0 === i2 ? void 0 : i2.yt)) return null;
    const { st: s2, et: n2, gr: r2 } = this.zt;
    return e2 >= s2 - n2 - 7 && e2 <= s2 + n2 + 7 ? { Mr: this.zt, gr: r2 } : null;
  }
  K({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (null === this.zt) return;
    if (false === this.zt.yt) return;
    const n2 = Math.round(this.zt.st * s2);
    n2 < 0 || n2 > e2.height || (t2.lineCap = "butt", t2.strokeStyle = this.zt.V, t2.lineWidth = Math.floor(this.zt.et * i2), lz(t2, this.zt.Nt), hz(t2, n2, 0, e2.width));
  }
}
class hi {
  constructor(t2) {
    this.Sr = { st: 0, V: "rgba(0, 0, 0, 0)", et: 1, Nt: 0, yt: false }, this.kr = new ri(), this.ft = true, this.Es = t2, this.Ns = t2.$t(), this.kr.J(this.Sr);
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.Es.yt() ? (this.ft && (this.yr(), this.ft = false), this.kr) : null;
  }
}
class li extends hi {
  constructor(t2) {
    super(t2);
  }
  yr() {
    this.Sr.yt = false;
    const t2 = this.Es.Dt(), e2 = t2.Cr().Cr;
    if (2 !== e2 && 3 !== e2) return;
    const i2 = this.Es.W();
    if (!i2.baseLineVisible || !this.Es.yt()) return;
    const s2 = this.Es.Ct();
    null !== s2 && (this.Sr.yt = true, this.Sr.st = t2.Rt(s2.Vt, s2.Vt), this.Sr.V = i2.baseLineColor, this.Sr.et = i2.baseLineWidth, this.Sr.Nt = i2.baseLineStyle);
  }
}
class ai extends H {
  constructor() {
    super(...arguments), this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  $e() {
    return this.zt;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    const s2 = this.zt;
    if (null === s2) return;
    const n2 = Math.max(1, Math.floor(e2)), r2 = n2 % 2 / 2, o2 = Math.round(s2.Xe.x * e2) + r2, a2 = s2.Xe.y * i2;
    t2.fillStyle = s2.Tr, t2.beginPath();
    const l2 = Math.max(2, 1.5 * s2.Pr) * e2;
    t2.arc(o2, a2, l2, 0, 2 * Math.PI, false), t2.fill(), t2.fillStyle = s2.Rr, t2.beginPath(), t2.arc(o2, a2, s2.ht * e2, 0, 2 * Math.PI, false), t2.fill(), t2.lineWidth = n2, t2.strokeStyle = s2.Dr, t2.beginPath(), t2.arc(o2, a2, s2.ht * e2 + n2 / 2, 0, 2 * Math.PI, false), t2.stroke();
  }
}
const h$ = [{ Vr: 0, Or: 0.25, Br: 4, Ar: 10, Ir: 0.25, zr: 0, Lr: 0.4, Er: 0.8 }, { Vr: 0.25, Or: 0.525, Br: 10, Ar: 14, Ir: 0, zr: 0, Lr: 0.8, Er: 0 }, { Vr: 0.525, Or: 1, Br: 14, Ar: 14, Ir: 0, zr: 0, Lr: 0, Er: 0 }];
function c$(t2, e2, i2, s2) {
  return function(t3, e3) {
    if ("transparent" === t3) return t3;
    const i3 = xz(t3), s3 = i3[3];
    return `rgba(${i3[0]}, ${i3[1]}, ${i3[2]}, ${e3 * s3})`;
  }(t2, i2 + (s2 - i2) * e2);
}
function u$(t2, e2) {
  const i2 = t2 % 2600 / 2600;
  let s2;
  for (const t3 of h$) if (i2 >= t3.Vr && i2 <= t3.Or) {
    s2 = t3;
    break;
  }
  cz(void 0 !== s2, "Last price animation internal logic error");
  const n2 = (i2 - s2.Vr) / (s2.Or - s2.Vr);
  return { Rr: c$(e2, n2, s2.Ir, s2.zr), Dr: c$(e2, n2, s2.Lr, s2.Er), ht: (r2 = n2, o2 = s2.Br, a2 = s2.Ar, o2 + (a2 - o2) * r2) };
  var r2, o2, a2;
}
class ci {
  constructor(t2) {
    this.Wt = new ai(), this.ft = true, this.Nr = true, this.Fr = performance.now(), this.Wr = this.Fr - 1, this.jr = t2;
  }
  Hr() {
    this.Wr = this.Fr - 1, this.bt();
  }
  $r() {
    if (this.bt(), 2 === this.jr.W().lastPriceAnimation) {
      const t2 = performance.now(), e2 = this.Wr - t2;
      if (e2 > 0) return void (e2 < 650 && (this.Wr += 2600));
      this.Fr = t2, this.Wr = t2 + 2600;
    }
  }
  bt() {
    this.ft = true;
  }
  Ur() {
    this.Nr = true;
  }
  yt() {
    return 0 !== this.jr.W().lastPriceAnimation;
  }
  qr() {
    switch (this.jr.W().lastPriceAnimation) {
      case 0:
        return false;
      case 1:
        return true;
      case 2:
        return performance.now() <= this.Wr;
    }
  }
  gt() {
    return this.ft ? (this.Mt(), this.ft = false, this.Nr = false) : this.Nr && (this.Yr(), this.Nr = false), this.Wt;
  }
  Mt() {
    this.Wt.J(null);
    const t2 = this.jr.$t().St(), e2 = t2.Xs(), i2 = this.jr.Ct();
    if (null === e2 || null === i2) return;
    const s2 = this.jr.Zr(true);
    if (s2.Xr || !e2.Kr(s2.ee)) return;
    const n2 = { x: t2.It(s2.ee), y: this.jr.Dt().Rt(s2._t, i2.Vt) }, r2 = s2.V, o2 = this.jr.W().lineWidth, a2 = u$(this.Gr(), r2);
    this.Wt.J({ Tr: r2, Pr: o2, Rr: a2.Rr, Dr: a2.Dr, ht: a2.ht, Xe: n2 });
  }
  Yr() {
    const t2 = this.Wt.$e();
    if (null !== t2) {
      const e2 = u$(this.Gr(), t2.Tr);
      t2.Rr = e2.Rr, t2.Dr = e2.Dr, t2.ht = e2.ht;
    }
  }
  Gr() {
    return this.qr() ? performance.now() - this.Fr : 2599;
  }
}
function d$(t2, e2) {
  return Zz(Math.min(Math.max(t2, 12), 30) * e2);
}
function f$(t2, e2) {
  switch (t2) {
    case "arrowDown":
    case "arrowUp":
      return d$(e2, 1);
    case "circle":
      return d$(e2, 0.8);
    case "square":
      return d$(e2, 0.7);
  }
}
function p$(t2) {
  return function(t3) {
    const e2 = Math.ceil(t3);
    return e2 % 2 != 0 ? e2 - 1 : e2;
  }(d$(t2, 1));
}
function m$(t2) {
  return Math.max(d$(t2, 0.1), 3);
}
function g$(t2, e2, i2) {
  return e2 ? t2 : i2 ? Math.ceil(t2 / 2) : 0;
}
function v$(t2, e2, i2, s2, n2) {
  const r2 = f$("square", i2), o2 = (r2 - 1) / 2, a2 = t2 - o2, l2 = e2 - o2;
  return s2 >= a2 && s2 <= a2 + r2 && n2 >= l2 && n2 <= l2 + r2;
}
function b$(t2, e2, i2, s2) {
  const n2 = (f$("arrowUp", s2) - 1) / 2 * i2.Jr, r2 = (Zz(s2 / 2) - 1) / 2 * i2.Jr;
  e2.beginPath(), t2 ? (e2.moveTo(i2.nt - n2, i2.st), e2.lineTo(i2.nt, i2.st - n2), e2.lineTo(i2.nt + n2, i2.st), e2.lineTo(i2.nt + r2, i2.st), e2.lineTo(i2.nt + r2, i2.st + n2), e2.lineTo(i2.nt - r2, i2.st + n2), e2.lineTo(i2.nt - r2, i2.st)) : (e2.moveTo(i2.nt - n2, i2.st), e2.lineTo(i2.nt, i2.st + n2), e2.lineTo(i2.nt + n2, i2.st), e2.lineTo(i2.nt + r2, i2.st), e2.lineTo(i2.nt + r2, i2.st - n2), e2.lineTo(i2.nt - r2, i2.st - n2), e2.lineTo(i2.nt - r2, i2.st)), e2.fill();
}
class Mi extends H {
  constructor() {
    super(...arguments), this.zt = null, this.ar = new ni(), this.j = -1, this.H = "", this.Qr = "";
  }
  J(t2) {
    this.zt = t2;
  }
  _r(t2, e2) {
    this.j === t2 && this.H === e2 || (this.j = t2, this.H = e2, this.Qr = Tz(t2, e2), this.ar.nr());
  }
  wr(t2, e2) {
    if (null === this.zt || null === this.zt.tt) return null;
    for (let i2 = this.zt.tt.from; i2 < this.zt.tt.to; i2++) {
      const s2 = this.zt.it[i2];
      if (y$(s2, t2, e2)) return { Mr: s2.th, gr: s2.gr };
    }
    return null;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }, s2, n2) {
    if (null !== this.zt && null !== this.zt.tt) {
      t2.textBaseline = "middle", t2.font = this.Qr;
      for (let s3 = this.zt.tt.from; s3 < this.zt.tt.to; s3++) {
        const n3 = this.zt.it[s3];
        void 0 !== n3.Kt && (n3.Kt.Hi = this.ar.xi(t2, n3.Kt.ih), n3.Kt.At = this.j, n3.Kt.nt = n3.nt - n3.Kt.Hi / 2), _$(n3, t2, e2, i2);
      }
    }
  }
}
function _$(t2, e2, i2, s2) {
  e2.fillStyle = t2.V, void 0 !== t2.Kt && function(t3, e3, i3, s3, n2, r2) {
    t3.save(), t3.scale(n2, r2), t3.fillText(e3, i3, s3), t3.restore();
  }(e2, t2.Kt.ih, t2.Kt.nt, t2.Kt.st, i2, s2), function(t3, e3, i3) {
    if (0 !== t3.Ks) {
      switch (t3.nh) {
        case "arrowDown":
          return void b$(false, e3, i3, t3.Ks);
        case "arrowUp":
          return void b$(true, e3, i3, t3.Ks);
        case "circle":
          return void function(t4, e4, i4) {
            const s3 = (f$("circle", i4) - 1) / 2;
            t4.beginPath(), t4.arc(e4.nt, e4.st, s3 * e4.Jr, 0, 2 * Math.PI, false), t4.fill();
          }(e3, i3, t3.Ks);
        case "square":
          return void function(t4, e4, i4) {
            const s3 = f$("square", i4), n2 = (s3 - 1) * e4.Jr / 2, r2 = e4.nt - n2, o2 = e4.st - n2;
            t4.fillRect(r2, o2, s3 * e4.Jr, s3 * e4.Jr);
          }(e3, i3, t3.Ks);
      }
      t3.nh;
    }
  }(t2, e2, function(t3, e3, i3) {
    const s3 = Math.max(1, Math.floor(e3)) % 2 / 2;
    return { nt: Math.round(t3.nt * e3) + s3, st: t3.st * i3, Jr: e3 };
  }(t2, i2, s2));
}
function y$(t2, e2, i2) {
  return !(void 0 === t2.Kt || !function(t3, e3, i3, s2, n2, r2) {
    const o2 = s2 / 2;
    return n2 >= t3 && n2 <= t3 + i3 && r2 >= e3 - o2 && r2 <= e3 + o2;
  }(t2.Kt.nt, t2.Kt.st, t2.Kt.Hi, t2.Kt.At, e2, i2)) || function(t3, e3, i3) {
    if (0 === t3.Ks) return false;
    switch (t3.nh) {
      case "arrowDown":
      case "arrowUp":
        return function(t4, e4, i4, s2, n2, r2) {
          return v$(e4, i4, s2, n2, r2);
        }(0, t3.nt, t3.st, t3.Ks, e3, i3);
      case "circle":
        return function(t4, e4, i4, s2, n2) {
          const r2 = 2 + f$("circle", i4) / 2, o2 = t4 - s2, a2 = e4 - n2;
          return Math.sqrt(o2 * o2 + a2 * a2) <= r2;
        }(t3.nt, t3.st, t3.Ks, e3, i3);
      case "square":
        return v$(t3.nt, t3.st, t3.Ks, e3, i3);
    }
  }(t2, e2, i2);
}
function x$(t2, e2, i2, s2, n2, r2, o2, a2, l2) {
  const h2 = Sz(i2) ? i2 : i2.Se, c2 = Sz(i2) ? i2 : i2.Me, u2 = Sz(i2) ? i2 : i2.xe, d2 = Sz(e2.size) ? Math.max(e2.size, 0) : 1, f2 = p$(a2.le()) * d2, p2 = f2 / 2;
  switch (t2.Ks = f2, e2.position) {
    case "inBar":
      return t2.st = o2.Rt(h2, l2), void (void 0 !== t2.Kt && (t2.Kt.st = t2.st + p2 + r2 + 0.6 * n2));
    case "aboveBar":
      return t2.st = o2.Rt(c2, l2) - p2 - s2.sh, void 0 !== t2.Kt && (t2.Kt.st = t2.st - p2 - 0.6 * n2, s2.sh += 1.2 * n2), void (s2.sh += f2 + r2);
    case "belowBar":
      return t2.st = o2.Rt(u2, l2) + p2 + s2.eh, void 0 !== t2.Kt && (t2.Kt.st = t2.st + p2 + r2 + 0.6 * n2, s2.eh += 1.2 * n2), void (s2.eh += f2 + r2);
  }
  e2.position;
}
class yi {
  constructor(t2, e2) {
    this.ft = true, this.rh = true, this.hh = true, this.ah = null, this.oh = null, this.Wt = new Mi(), this.jr = t2, this.$i = e2, this.zt = { it: [], tt: null };
  }
  bt(t2) {
    this.ft = true, this.hh = true, "data" === t2 && (this.rh = true, this.oh = null);
  }
  gt(t2) {
    if (!this.jr.yt()) return null;
    this.ft && this._h();
    const e2 = this.$i.W().layout;
    return this.Wt._r(e2.fontSize, e2.fontFamily), this.Wt.J(this.zt), this.Wt;
  }
  uh() {
    if (this.hh) {
      if (this.jr.dh().length > 0) {
        const t2 = this.$i.St().le(), e2 = m$(t2), i2 = 1.5 * p$(t2) + 2 * e2, s2 = this.fh();
        this.ah = { above: g$(i2, s2.aboveBar, s2.inBar), below: g$(i2, s2.belowBar, s2.inBar) };
      } else this.ah = null;
      this.hh = false;
    }
    return this.ah;
  }
  fh() {
    return null === this.oh && (this.oh = this.jr.dh().reduce((t2, e2) => (t2[e2.position] || (t2[e2.position] = true), t2), { inBar: false, aboveBar: false, belowBar: false })), this.oh;
  }
  _h() {
    const t2 = this.jr.Dt(), e2 = this.$i.St(), i2 = this.jr.dh();
    this.rh && (this.zt.it = i2.map((t3) => ({ ot: t3.time, nt: 0, st: 0, Ks: 0, nh: t3.shape, V: t3.color, th: t3.th, gr: t3.id, Kt: void 0 })), this.rh = false);
    const s2 = this.$i.W().layout;
    this.zt.tt = null;
    const n2 = e2.Xs();
    if (null === n2) return;
    const r2 = this.jr.Ct();
    if (null === r2) return;
    if (0 === this.zt.it.length) return;
    let o2 = NaN;
    const a2 = m$(e2.le()), l2 = { sh: a2, eh: a2 };
    this.zt.tt = o$(this.zt.it, n2, true);
    for (let n3 = this.zt.tt.from; n3 < this.zt.tt.to; n3++) {
      const h2 = i2[n3];
      h2.time !== o2 && (l2.sh = a2, l2.eh = a2, o2 = h2.time);
      const c2 = this.zt.it[n3];
      c2.nt = e2.It(h2.time), void 0 !== h2.text && h2.text.length > 0 && (c2.Kt = { ih: h2.text, nt: 0, st: 0, Hi: 0, At: 0 });
      const u2 = this.jr.ph(h2.time);
      null !== u2 && x$(c2, h2, u2, l2, s2.fontSize, a2, t2, e2, r2.Vt);
    }
    this.ft = false;
  }
}
class Ci extends hi {
  constructor(t2) {
    super(t2);
  }
  yr() {
    const t2 = this.Sr;
    t2.yt = false;
    const e2 = this.Es.W();
    if (!e2.priceLineVisible || !this.Es.yt()) return;
    const i2 = this.Es.Zr(0 === e2.priceLineSource);
    i2.Xr || (t2.yt = true, t2.st = i2.ki, t2.V = this.Es.mh(i2.V), t2.et = e2.priceLineWidth, t2.Nt = e2.priceLineStyle);
  }
}
class Ti extends nt {
  constructor(t2) {
    super(), this.jt = t2;
  }
  zi(t2, e2, i2) {
    t2.yt = false, e2.yt = false;
    const s2 = this.jt;
    if (!s2.yt()) return;
    const n2 = s2.W(), r2 = n2.lastValueVisible, o2 = "" !== s2.bh(), a2 = 0 === n2.seriesLastValueMode, l2 = s2.Zr(false);
    if (l2.Xr) return;
    r2 && (t2.Kt = this.wh(l2, r2, a2), t2.yt = 0 !== t2.Kt.length), (o2 || a2) && (e2.Kt = this.gh(l2, r2, o2, a2), e2.yt = e2.Kt.length > 0);
    const h2 = s2.mh(l2.V), c2 = kz(h2);
    i2.t = c2.t, i2.ki = l2.ki, e2.Ot = s2.$t().Bt(l2.ki / s2.Dt().At()), t2.Ot = h2, t2.V = c2.i, e2.V = c2.i;
  }
  gh(t2, e2, i2, s2) {
    let n2 = "";
    const r2 = this.jt.bh();
    return i2 && 0 !== r2.length && (n2 += `${r2} `), e2 && s2 && (n2 += this.jt.Dt().Mh() ? t2.xh : t2.Sh), n2.trim();
  }
  wh(t2, e2, i2) {
    return e2 ? i2 ? this.jt.Dt().Mh() ? t2.Sh : t2.xh : t2.Kt : "";
  }
}
function w$(t2, e2, i2, s2) {
  const n2 = Number.isFinite(e2), r2 = Number.isFinite(i2);
  return n2 && r2 ? t2(e2, i2) : n2 || r2 ? n2 ? e2 : i2 : s2;
}
class Ri {
  constructor(t2, e2) {
    this.kh = t2, this.yh = e2;
  }
  Ch(t2) {
    return null !== t2 && this.kh === t2.kh && this.yh === t2.yh;
  }
  Th() {
    return new Ri(this.kh, this.yh);
  }
  Ph() {
    return this.kh;
  }
  Rh() {
    return this.yh;
  }
  Dh() {
    return this.yh - this.kh;
  }
  Ni() {
    return this.yh === this.kh || Number.isNaN(this.yh) || Number.isNaN(this.kh);
  }
  ts(t2) {
    return null === t2 ? this : new Ri(w$(Math.min, this.Ph(), t2.Ph(), -1 / 0), w$(Math.max, this.Rh(), t2.Rh(), 1 / 0));
  }
  Vh(t2) {
    if (!Sz(t2)) return;
    if (0 === this.yh - this.kh) return;
    const e2 = 0.5 * (this.yh + this.kh);
    let i2 = this.yh - e2, s2 = this.kh - e2;
    i2 *= t2, s2 *= t2, this.yh = e2 + i2, this.kh = e2 + s2;
  }
  Oh(t2) {
    Sz(t2) && (this.yh += t2, this.kh += t2);
  }
  Bh() {
    return { minValue: this.kh, maxValue: this.yh };
  }
  static Ah(t2) {
    return null === t2 ? null : new Ri(t2.minValue, t2.maxValue);
  }
}
class Di {
  constructor(t2, e2) {
    this.Ih = t2, this.zh = e2 || null;
  }
  Lh() {
    return this.Ih;
  }
  Eh() {
    return this.zh;
  }
  Bh() {
    return null === this.Ih ? null : { priceRange: this.Ih.Bh(), margins: this.zh || void 0 };
  }
  static Ah(t2) {
    return null === t2 ? null : new Di(Ri.Ah(t2.priceRange), t2.margins);
  }
}
class Vi extends hi {
  constructor(t2, e2) {
    super(t2), this.Nh = e2;
  }
  yr() {
    const t2 = this.Sr;
    t2.yt = false;
    const e2 = this.Nh.W();
    if (!this.Es.yt() || !e2.lineVisible) return;
    const i2 = this.Nh.Fh();
    null !== i2 && (t2.yt = true, t2.st = i2, t2.V = e2.color, t2.et = e2.lineWidth, t2.Nt = e2.lineStyle, t2.gr = this.Nh.W().id);
  }
}
class Oi extends nt {
  constructor(t2, e2) {
    super(), this.jr = t2, this.Nh = e2;
  }
  zi(t2, e2, i2) {
    t2.yt = false, e2.yt = false;
    const s2 = this.Nh.W(), n2 = s2.axisLabelVisible, r2 = "" !== s2.title, o2 = this.jr;
    if (!n2 || !o2.yt()) return;
    const a2 = this.Nh.Fh();
    if (null === a2) return;
    r2 && (e2.Kt = s2.title, e2.yt = true), e2.Ot = o2.$t().Bt(a2 / o2.Dt().At()), t2.Kt = this.Wh(s2.price), t2.yt = true;
    const l2 = kz(s2.axisLabelColor || s2.color);
    i2.t = l2.t;
    const h2 = s2.axisLabelTextColor || l2.i;
    t2.V = h2, e2.V = h2, i2.ki = a2;
  }
  Wh(t2) {
    const e2 = this.jr.Ct();
    return null === e2 ? "" : this.jr.Dt().Fi(t2, e2.Vt);
  }
}
class Bi {
  constructor(t2, e2) {
    this.jr = t2, this.cn = e2, this.jh = new Vi(t2, this), this.ur = new Oi(t2, this), this.Hh = new ei(this.ur, t2, t2.$t());
  }
  $h(t2) {
    Mz(this.cn, t2), this.bt(), this.jr.$t().Uh();
  }
  W() {
    return this.cn;
  }
  qh() {
    return this.jh;
  }
  Yh() {
    return this.Hh;
  }
  Zh() {
    return this.ur;
  }
  bt() {
    this.jh.bt(), this.ur.bt();
  }
  Fh() {
    const t2 = this.jr, e2 = t2.Dt();
    if (t2.$t().St().Ni() || e2.Ni()) return null;
    const i2 = t2.Ct();
    return null === i2 ? null : e2.Rt(this.cn.price, i2.Vt);
  }
}
class Ai extends lt {
  constructor(t2) {
    super(), this.$i = t2;
  }
  $t() {
    return this.$i;
  }
}
const k$ = { Bar: (t2, e2, i2, s2) => {
  var n2;
  const r2 = e2.upColor, o2 = e2.downColor, a2 = dz(t2(i2, s2)), l2 = fz(a2.Vt[0]) <= fz(a2.Vt[3]);
  return { ce: null !== (n2 = a2.V) && void 0 !== n2 ? n2 : l2 ? r2 : o2 };
}, Candlestick: (t2, e2, i2, s2) => {
  var n2, r2, o2;
  const a2 = e2.upColor, l2 = e2.downColor, h2 = e2.borderUpColor, c2 = e2.borderDownColor, u2 = e2.wickUpColor, d2 = e2.wickDownColor, f2 = dz(t2(i2, s2)), p2 = fz(f2.Vt[0]) <= fz(f2.Vt[3]);
  return { ce: null !== (n2 = f2.V) && void 0 !== n2 ? n2 : p2 ? a2 : l2, Ne: null !== (r2 = f2.Ot) && void 0 !== r2 ? r2 : p2 ? h2 : c2, Ee: null !== (o2 = f2.Xh) && void 0 !== o2 ? o2 : p2 ? u2 : d2 };
}, Custom: (t2, e2, i2, s2) => {
  var n2;
  return { ce: null !== (n2 = dz(t2(i2, s2)).V) && void 0 !== n2 ? n2 : e2.color };
}, Area: (t2, e2, i2, s2) => {
  var n2, r2, o2, a2;
  const l2 = dz(t2(i2, s2));
  return { ce: null !== (n2 = l2.lt) && void 0 !== n2 ? n2 : e2.lineColor, lt: null !== (r2 = l2.lt) && void 0 !== r2 ? r2 : e2.lineColor, Ps: null !== (o2 = l2.Ps) && void 0 !== o2 ? o2 : e2.topColor, Rs: null !== (a2 = l2.Rs) && void 0 !== a2 ? a2 : e2.bottomColor };
}, Baseline: (t2, e2, i2, s2) => {
  var n2, r2, o2, a2, l2, h2;
  const c2 = dz(t2(i2, s2));
  return { ce: c2.Vt[3] >= e2.baseValue.price ? e2.topLineColor : e2.bottomLineColor, Re: null !== (n2 = c2.Re) && void 0 !== n2 ? n2 : e2.topLineColor, De: null !== (r2 = c2.De) && void 0 !== r2 ? r2 : e2.bottomLineColor, ke: null !== (o2 = c2.ke) && void 0 !== o2 ? o2 : e2.topFillColor1, ye: null !== (a2 = c2.ye) && void 0 !== a2 ? a2 : e2.topFillColor2, Ce: null !== (l2 = c2.Ce) && void 0 !== l2 ? l2 : e2.bottomFillColor1, Te: null !== (h2 = c2.Te) && void 0 !== h2 ? h2 : e2.bottomFillColor2 };
}, Line: (t2, e2, i2, s2) => {
  var n2, r2;
  const o2 = dz(t2(i2, s2));
  return { ce: null !== (n2 = o2.V) && void 0 !== n2 ? n2 : e2.color, lt: null !== (r2 = o2.V) && void 0 !== r2 ? r2 : e2.color };
}, Histogram: (t2, e2, i2, s2) => {
  var n2;
  return { ce: null !== (n2 = dz(t2(i2, s2)).V) && void 0 !== n2 ? n2 : e2.color };
} };
class zi {
  constructor(t2) {
    this.Kh = (t3, e2) => void 0 !== e2 ? e2.Vt : this.jr.In().Gh(t3), this.jr = t2, this.Jh = k$[t2.Qh()];
  }
  $s(t2, e2) {
    return this.Jh(this.Kh, this.jr.W(), t2, e2);
  }
}
var M$;
!function(t2) {
  t2[t2.NearestLeft = -1] = "NearestLeft", t2[t2.None = 0] = "None", t2[t2.NearestRight = 1] = "NearestRight";
}(M$ || (M$ = {}));
const S$ = 30;
class Ni {
  constructor() {
    this.tl = [], this.il = /* @__PURE__ */ new Map(), this.nl = /* @__PURE__ */ new Map();
  }
  sl() {
    return this.Ks() > 0 ? this.tl[this.tl.length - 1] : null;
  }
  el() {
    return this.Ks() > 0 ? this.rl(0) : null;
  }
  An() {
    return this.Ks() > 0 ? this.rl(this.tl.length - 1) : null;
  }
  Ks() {
    return this.tl.length;
  }
  Ni() {
    return 0 === this.Ks();
  }
  Kr(t2) {
    return null !== this.hl(t2, 0);
  }
  Gh(t2) {
    return this.ll(t2);
  }
  ll(t2, e2 = 0) {
    const i2 = this.hl(t2, e2);
    return null === i2 ? null : Object.assign(Object.assign({}, this.al(i2)), { ee: this.rl(i2) });
  }
  ne() {
    return this.tl;
  }
  ol(t2, e2, i2) {
    if (this.Ni()) return null;
    let s2 = null;
    for (const n2 of i2) s2 = C$(s2, this._l(t2, e2, n2));
    return s2;
  }
  J(t2) {
    this.nl.clear(), this.il.clear(), this.tl = t2;
  }
  rl(t2) {
    return this.tl[t2].ee;
  }
  al(t2) {
    return this.tl[t2];
  }
  hl(t2, e2) {
    const i2 = this.ul(t2);
    if (null === i2 && 0 !== e2) switch (e2) {
      case -1:
        return this.cl(t2);
      case 1:
        return this.dl(t2);
      default:
        throw new TypeError("Unknown search mode");
    }
    return i2;
  }
  cl(t2) {
    let e2 = this.fl(t2);
    return e2 > 0 && (e2 -= 1), e2 !== this.tl.length && this.rl(e2) < t2 ? e2 : null;
  }
  dl(t2) {
    const e2 = this.vl(t2);
    return e2 !== this.tl.length && t2 < this.rl(e2) ? e2 : null;
  }
  ul(t2) {
    const e2 = this.fl(t2);
    return e2 === this.tl.length || t2 < this.tl[e2].ee ? null : e2;
  }
  fl(t2) {
    return i$(this.tl, t2, (t3, e2) => t3.ee < e2);
  }
  vl(t2) {
    return s$(this.tl, t2, (t3, e2) => t3.ee > e2);
  }
  pl(t2, e2, i2) {
    let s2 = null;
    for (let n2 = t2; n2 < e2; n2++) {
      const t3 = this.tl[n2].Vt[i2];
      Number.isNaN(t3) || (null === s2 ? s2 = { ml: t3, bl: t3 } : (t3 < s2.ml && (s2.ml = t3), t3 > s2.bl && (s2.bl = t3)));
    }
    return s2;
  }
  _l(t2, e2, i2) {
    if (this.Ni()) return null;
    let s2 = null;
    const n2 = dz(this.el()), r2 = dz(this.An()), o2 = Math.max(t2, n2), a2 = Math.min(e2, r2), l2 = Math.ceil(o2 / S$) * S$, h2 = Math.max(l2, Math.floor(a2 / S$) * S$);
    {
      const t3 = this.fl(o2), n3 = this.vl(Math.min(a2, l2, e2));
      s2 = C$(s2, this.pl(t3, n3, i2));
    }
    let c2 = this.il.get(i2);
    void 0 === c2 && (c2 = /* @__PURE__ */ new Map(), this.il.set(i2, c2));
    for (let t3 = Math.max(l2 + 1, o2); t3 < h2; t3 += S$) {
      const e3 = Math.floor(t3 / S$);
      let n3 = c2.get(e3);
      if (void 0 === n3) {
        const t4 = this.fl(e3 * S$), s3 = this.vl((e3 + 1) * S$ - 1);
        n3 = this.pl(t4, s3, i2), c2.set(e3, n3);
      }
      s2 = C$(s2, n3);
    }
    {
      const t3 = this.fl(h2), e3 = this.vl(a2);
      s2 = C$(s2, this.pl(t3, e3, i2));
    }
    return s2;
  }
}
function C$(t2, e2) {
  return null === t2 ? e2 : null === e2 ? t2 : { ml: Math.min(t2.ml, e2.ml), bl: Math.max(t2.bl, e2.bl) };
}
class Wi {
  constructor(t2) {
    this.wl = t2;
  }
  X(t2, e2, i2) {
    this.wl.draw(t2);
  }
  gl(t2, e2, i2) {
    var s2, n2;
    null === (n2 = (s2 = this.wl).drawBackground) || void 0 === n2 || n2.call(s2, t2);
  }
}
class ji {
  constructor(t2) {
    this.tr = null, this.wn = t2;
  }
  gt() {
    var t2;
    const e2 = this.wn.renderer();
    if (null === e2) return null;
    if ((null === (t2 = this.tr) || void 0 === t2 ? void 0 : t2.Ml) === e2) return this.tr.xl;
    const i2 = new Wi(e2);
    return this.tr = { Ml: e2, xl: i2 }, i2;
  }
  Sl() {
    var t2, e2, i2;
    return null !== (i2 = null === (e2 = (t2 = this.wn).zOrder) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : "normal";
  }
}
function z$(t2) {
  var e2, i2, s2, n2, r2;
  return { Kt: t2.text(), ki: t2.coordinate(), Si: null === (e2 = t2.fixedCoordinate) || void 0 === e2 ? void 0 : e2.call(t2), V: t2.textColor(), t: t2.backColor(), yt: null === (s2 = null === (i2 = t2.visible) || void 0 === i2 ? void 0 : i2.call(t2)) || void 0 === s2 || s2, hi: null === (r2 = null === (n2 = t2.tickVisible) || void 0 === n2 ? void 0 : n2.call(t2)) || void 0 === r2 || r2 };
}
class $i {
  constructor(t2, e2) {
    this.Wt = new rt(), this.kl = t2, this.yl = e2;
  }
  gt() {
    return this.Wt.J(Object.assign({ Hi: this.yl.Hi() }, z$(this.kl))), this.Wt;
  }
}
class Ui extends nt {
  constructor(t2, e2) {
    super(), this.kl = t2, this.Li = e2;
  }
  zi(t2, e2, i2) {
    const s2 = z$(this.kl);
    i2.t = s2.t, t2.V = s2.V;
    const n2 = 2 / 12 * this.Li.P();
    i2.wi = n2, i2.gi = n2, i2.ki = s2.ki, i2.Si = s2.Si, t2.Kt = s2.Kt, t2.yt = s2.yt, t2.hi = s2.hi;
  }
}
class qi {
  constructor(t2, e2) {
    this.Cl = null, this.Tl = null, this.Pl = null, this.Rl = null, this.Dl = null, this.Vl = t2, this.jr = e2;
  }
  Ol() {
    return this.Vl;
  }
  Vn() {
    var t2, e2;
    null === (e2 = (t2 = this.Vl).updateAllViews) || void 0 === e2 || e2.call(t2);
  }
  Pn() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).paneViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Cl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Cl.xl;
    const r2 = n2.map((t3) => new ji(t3));
    return this.Cl = { Ml: n2, xl: r2 }, r2;
  }
  Qi() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).timeAxisViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Tl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Tl.xl;
    const r2 = this.jr.$t().St(), o2 = n2.map((t3) => new $i(t3, r2));
    return this.Tl = { Ml: n2, xl: o2 }, o2;
  }
  Rn() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).priceAxisViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Pl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Pl.xl;
    const r2 = this.jr.Dt(), o2 = n2.map((t3) => new Ui(t3, r2));
    return this.Pl = { Ml: n2, xl: o2 }, o2;
  }
  Bl() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).priceAxisPaneViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Rl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Rl.xl;
    const r2 = n2.map((t3) => new ji(t3));
    return this.Rl = { Ml: n2, xl: r2 }, r2;
  }
  Al() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).timeAxisPaneViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Dl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Dl.xl;
    const r2 = n2.map((t3) => new ji(t3));
    return this.Dl = { Ml: n2, xl: r2 }, r2;
  }
  Il(t2, e2) {
    var i2, s2, n2;
    return null !== (n2 = null === (s2 = (i2 = this.Vl).autoscaleInfo) || void 0 === s2 ? void 0 : s2.call(i2, t2, e2)) && void 0 !== n2 ? n2 : null;
  }
  wr(t2, e2) {
    var i2, s2, n2;
    return null !== (n2 = null === (s2 = (i2 = this.Vl).hitTest) || void 0 === s2 ? void 0 : s2.call(i2, t2, e2)) && void 0 !== n2 ? n2 : null;
  }
}
function $$(t2, e2, i2, s2) {
  t2.forEach((t3) => {
    e2(t3).forEach((t4) => {
      t4.Sl() === i2 && s2.push(t4);
    });
  });
}
function D$(t2) {
  return t2.Pn();
}
function R$(t2) {
  return t2.Bl();
}
function E$(t2) {
  return t2.Al();
}
class Gi extends Ai {
  constructor(t2, e2, i2, s2, n2) {
    super(t2), this.zt = new Ni(), this.jh = new Ci(this), this.zl = [], this.Ll = new li(this), this.El = null, this.Nl = null, this.Fl = [], this.Wl = [], this.jl = null, this.Hl = [], this.cn = e2, this.$l = i2;
    const r2 = new Ti(this);
    this.rn = [r2], this.Hh = new ei(r2, this, t2), "Area" !== i2 && "Line" !== i2 && "Baseline" !== i2 || (this.El = new ci(this)), this.Ul(), this.ql(n2);
  }
  S() {
    null !== this.jl && clearTimeout(this.jl);
  }
  mh(t2) {
    return this.cn.priceLineColor || t2;
  }
  Zr(t2) {
    const e2 = { Xr: true }, i2 = this.Dt();
    if (this.$t().St().Ni() || i2.Ni() || this.zt.Ni()) return e2;
    const s2 = this.$t().St().Xs(), n2 = this.Ct();
    if (null === s2 || null === n2) return e2;
    let r2, o2;
    if (t2) {
      const t3 = this.zt.sl();
      if (null === t3) return e2;
      r2 = t3, o2 = t3.ee;
    } else {
      const t3 = this.zt.ll(s2.ui(), -1);
      if (null === t3) return e2;
      if (r2 = this.zt.Gh(t3.ee), null === r2) return e2;
      o2 = t3.ee;
    }
    const a2 = r2.Vt[3], l2 = this.Us().$s(o2, { Vt: r2 }), h2 = i2.Rt(a2, n2.Vt);
    return { Xr: false, _t: a2, Kt: i2.Fi(a2, n2.Vt), xh: i2.Yl(a2), Sh: i2.Zl(a2, n2.Vt), V: l2.ce, ki: h2, ee: o2 };
  }
  Us() {
    return null !== this.Nl || (this.Nl = new zi(this)), this.Nl;
  }
  W() {
    return this.cn;
  }
  $h(t2) {
    const e2 = t2.priceScaleId;
    void 0 !== e2 && e2 !== this.cn.priceScaleId && this.$t().Xl(this, e2), Mz(this.cn, t2), void 0 !== t2.priceFormat && (this.Ul(), this.$t().Kl()), this.$t().Gl(this), this.$t().Jl(), this.wn.bt("options");
  }
  J(t2, e2) {
    this.zt.J(t2), this.Ql(), this.wn.bt("data"), this.dn.bt("data"), null !== this.El && (e2 && e2.ta ? this.El.$r() : 0 === t2.length && this.El.Hr());
    const i2 = this.$t().dr(this);
    this.$t().ia(i2), this.$t().Gl(this), this.$t().Jl(), this.$t().Uh();
  }
  na(t2) {
    this.Fl = t2, this.Ql();
    const e2 = this.$t().dr(this);
    this.dn.bt("data"), this.$t().ia(e2), this.$t().Gl(this), this.$t().Jl(), this.$t().Uh();
  }
  sa() {
    return this.Fl;
  }
  dh() {
    return this.Wl;
  }
  ea(t2) {
    const e2 = new Bi(this, t2);
    return this.zl.push(e2), this.$t().Gl(this), e2;
  }
  ra(t2) {
    const e2 = this.zl.indexOf(t2);
    -1 !== e2 && this.zl.splice(e2, 1), this.$t().Gl(this);
  }
  Qh() {
    return this.$l;
  }
  Ct() {
    const t2 = this.ha();
    return null === t2 ? null : { Vt: t2.Vt[3], la: t2.ot };
  }
  ha() {
    const t2 = this.$t().St().Xs();
    if (null === t2) return null;
    const e2 = t2.Os();
    return this.zt.ll(e2, 1);
  }
  In() {
    return this.zt;
  }
  ph(t2) {
    const e2 = this.zt.Gh(t2);
    return null === e2 ? null : "Bar" === this.$l || "Candlestick" === this.$l || "Custom" === this.$l ? { ge: e2.Vt[0], Me: e2.Vt[1], xe: e2.Vt[2], Se: e2.Vt[3] } : e2.Vt[3];
  }
  aa(t2) {
    const e2 = [];
    $$(this.Hl, D$, "top", e2);
    const i2 = this.El;
    return null !== i2 && i2.yt() ? (null === this.jl && i2.qr() && (this.jl = setTimeout(() => {
      this.jl = null, this.$t().oa();
    }, 0)), i2.Ur(), e2.unshift(i2), e2) : e2;
  }
  Pn() {
    const t2 = [];
    this._a() || t2.push(this.Ll), t2.push(this.wn, this.jh, this.dn);
    const e2 = this.zl.map((t3) => t3.qh());
    return t2.push(...e2), $$(this.Hl, D$, "normal", t2), t2;
  }
  ua() {
    return this.ca(D$, "bottom");
  }
  da(t2) {
    return this.ca(R$, t2);
  }
  fa(t2) {
    return this.ca(E$, t2);
  }
  va(t2, e2) {
    return this.Hl.map((i2) => i2.wr(t2, e2)).filter((t3) => null !== t3);
  }
  Ji(t2) {
    return [this.Hh, ...this.zl.map((t3) => t3.Yh())];
  }
  Rn(t2, e2) {
    if (e2 !== this.Yi && !this._a()) return [];
    const i2 = [...this.rn];
    for (const t3 of this.zl) i2.push(t3.Zh());
    return this.Hl.forEach((t3) => {
      i2.push(...t3.Rn());
    }), i2;
  }
  Qi() {
    const t2 = [];
    return this.Hl.forEach((e2) => {
      t2.push(...e2.Qi());
    }), t2;
  }
  Il(t2, e2) {
    if (void 0 !== this.cn.autoscaleInfoProvider) {
      const i2 = this.cn.autoscaleInfoProvider(() => {
        const i3 = this.pa(t2, e2);
        return null === i3 ? null : i3.Bh();
      });
      return Di.Ah(i2);
    }
    return this.pa(t2, e2);
  }
  ma() {
    return this.cn.priceFormat.minMove;
  }
  ba() {
    return this.wa;
  }
  Vn() {
    var t2;
    this.wn.bt(), this.dn.bt();
    for (const t3 of this.rn) t3.bt();
    for (const t3 of this.zl) t3.bt();
    this.jh.bt(), this.Ll.bt(), null === (t2 = this.El) || void 0 === t2 || t2.bt(), this.Hl.forEach((t3) => t3.Vn());
  }
  Dt() {
    return dz(super.Dt());
  }
  kt(t2) {
    if ("Line" !== this.$l && "Area" !== this.$l && "Baseline" !== this.$l || !this.cn.crosshairMarkerVisible) return null;
    const e2 = this.zt.Gh(t2);
    return null === e2 ? null : { _t: e2.Vt[3], ht: this.ga(), Ot: this.Ma(), Pt: this.xa(), Tt: this.Sa(t2) };
  }
  bh() {
    return this.cn.title;
  }
  yt() {
    return this.cn.visible;
  }
  ka(t2) {
    this.Hl.push(new qi(t2, this));
  }
  ya(t2) {
    this.Hl = this.Hl.filter((e2) => e2.Ol() !== t2);
  }
  Ca() {
    if (this.wn instanceof Kt != 0) return (t2) => this.wn.We(t2);
  }
  Ta() {
    if (this.wn instanceof Kt != 0) return (t2) => this.wn.je(t2);
  }
  _a() {
    return !jz(this.Dt().Pa());
  }
  pa(t2, e2) {
    if (!Cz(t2) || !Cz(e2) || this.zt.Ni()) return null;
    const i2 = "Line" === this.$l || "Area" === this.$l || "Baseline" === this.$l || "Histogram" === this.$l ? [3] : [2, 1], s2 = this.zt.ol(t2, e2, i2);
    let n2 = null !== s2 ? new Ri(s2.ml, s2.bl) : null;
    if ("Histogram" === this.Qh()) {
      const t3 = this.cn.base, e3 = new Ri(t3, t3);
      n2 = null !== n2 ? n2.ts(e3) : e3;
    }
    let r2 = this.dn.uh();
    return this.Hl.forEach((i3) => {
      const s3 = i3.Il(t2, e2);
      if (null == s3 ? void 0 : s3.priceRange) {
        const t3 = new Ri(s3.priceRange.minValue, s3.priceRange.maxValue);
        n2 = null !== n2 ? n2.ts(t3) : t3;
      }
      var o2, a2, l2, h2;
      (null == s3 ? void 0 : s3.margins) && (o2 = r2, a2 = s3.margins, r2 = { above: Math.max(null !== (l2 = null == o2 ? void 0 : o2.above) && void 0 !== l2 ? l2 : 0, a2.above), below: Math.max(null !== (h2 = null == o2 ? void 0 : o2.below) && void 0 !== h2 ? h2 : 0, a2.below) });
    }), new Di(n2, r2);
  }
  ga() {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline":
        return this.cn.crosshairMarkerRadius;
    }
    return 0;
  }
  Ma() {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline": {
        const t2 = this.cn.crosshairMarkerBorderColor;
        if (0 !== t2.length) return t2;
      }
    }
    return null;
  }
  xa() {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline":
        return this.cn.crosshairMarkerBorderWidth;
    }
    return 0;
  }
  Sa(t2) {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline": {
        const t3 = this.cn.crosshairMarkerBackgroundColor;
        if (0 !== t3.length) return t3;
      }
    }
    return this.Us().$s(t2).ce;
  }
  Ul() {
    switch (this.cn.priceFormat.type) {
      case "custom":
        this.wa = { format: this.cn.priceFormat.formatter };
        break;
      case "volume":
        this.wa = new pt(this.cn.priceFormat.precision);
        break;
      case "percent":
        this.wa = new vt(this.cn.priceFormat.precision);
        break;
      default: {
        const t2 = Math.pow(10, this.cn.priceFormat.precision);
        this.wa = new ft(t2, this.cn.priceFormat.minMove * t2);
      }
    }
    null !== this.Yi && this.Yi.Ra();
  }
  Ql() {
    const t2 = this.$t().St();
    if (!t2.Da() || this.zt.Ni()) return void (this.Wl = []);
    const e2 = dz(this.zt.el());
    this.Wl = this.Fl.map((i2, s2) => {
      const n2 = dz(t2.Va(i2.time, true)), r2 = n2 < e2 ? 1 : -1;
      return { time: dz(this.zt.ll(n2, r2)).ee, position: i2.position, shape: i2.shape, color: i2.color, id: i2.id, th: s2, text: i2.text, size: i2.size, originalTime: i2.originalTime };
    });
  }
  ql(t2) {
    switch (this.dn = new yi(this, this.$t()), this.$l) {
      case "Bar":
        this.wn = new Ht(this, this.$t());
        break;
      case "Candlestick":
        this.wn = new Zt(this, this.$t());
        break;
      case "Line":
        this.wn = new ti(this, this.$t());
        break;
      case "Custom":
        this.wn = new Kt(this, this.$t(), uz(t2));
        break;
      case "Area":
        this.wn = new Ft(this, this.$t());
        break;
      case "Baseline":
        this.wn = new qt(this, this.$t());
        break;
      case "Histogram":
        this.wn = new Qt(this, this.$t());
        break;
      default:
        throw Error("Unknown chart style assigned: " + this.$l);
    }
  }
  ca(t2, e2) {
    const i2 = [];
    return $$(this.Hl, t2, e2, i2), i2;
  }
}
class Ji {
  constructor(t2) {
    this.cn = t2;
  }
  Oa(t2, e2, i2) {
    let s2 = t2;
    if (0 === this.cn.mode) return s2;
    const n2 = i2.vn(), r2 = n2.Ct();
    if (null === r2) return s2;
    const o2 = n2.Rt(t2, r2), a2 = i2.Ba().filter((t3) => t3 instanceof Gi).reduce((t3, s3) => {
      if (i2.vr(s3) || !s3.yt()) return t3;
      const n3 = s3.Dt(), r3 = s3.In();
      if (n3.Ni() || !r3.Kr(e2)) return t3;
      const o3 = r3.Gh(e2);
      if (null === o3) return t3;
      const a3 = fz(s3.Ct());
      return t3.concat([n3.Rt(o3.Vt[3], a3.Vt)]);
    }, []);
    if (0 === a2.length) return s2;
    a2.sort((t3, e3) => Math.abs(t3 - o2) - Math.abs(e3 - o2));
    const l2 = a2[0];
    return s2 = n2.pn(l2, r2), s2;
  }
}
class Qi extends H {
  constructor() {
    super(...arguments), this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  K({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (null === this.zt) return;
    const n2 = Math.max(1, Math.floor(i2));
    t2.lineWidth = n2, function(t3, e3) {
      t3.save(), t3.lineWidth % 2 && t3.translate(0.5, 0.5), e3(), t3.restore();
    }(t2, () => {
      const r2 = dz(this.zt);
      if (r2.Aa) {
        t2.strokeStyle = r2.Ia, lz(t2, r2.za), t2.beginPath();
        for (const s3 of r2.La) {
          const r3 = Math.round(s3.Ea * i2);
          t2.moveTo(r3, -n2), t2.lineTo(r3, e2.height + n2);
        }
        t2.stroke();
      }
      if (r2.Na) {
        t2.strokeStyle = r2.Fa, lz(t2, r2.Wa), t2.beginPath();
        for (const i3 of r2.ja) {
          const r3 = Math.round(i3.Ea * s2);
          t2.moveTo(-n2, r3), t2.lineTo(e2.width + n2, r3);
        }
        t2.stroke();
      }
    });
  }
}
class tn {
  constructor(t2) {
    this.Wt = new Qi(), this.ft = true, this.tn = t2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    if (this.ft) {
      const t2 = this.tn.$t().W().grid, e2 = { Na: t2.horzLines.visible, Aa: t2.vertLines.visible, Fa: t2.horzLines.color, Ia: t2.vertLines.color, Wa: t2.horzLines.style, za: t2.vertLines.style, ja: this.tn.vn().Ha(), La: (this.tn.$t().St().Ha() || []).map((t3) => ({ Ea: t3.coord })) };
      this.Wt.J(e2), this.ft = false;
    }
    return this.Wt;
  }
}
class nn {
  constructor(t2) {
    this.wn = new tn(t2);
  }
  qh() {
    return this.wn;
  }
}
const P$ = { $a: 4, Ua: 1e-4 };
function T$(t2, e2) {
  const i2 = 100 * (t2 - e2) / e2;
  return e2 < 0 ? -i2 : i2;
}
function L$(t2, e2) {
  const i2 = T$(t2.Ph(), e2), s2 = T$(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function V$(t2, e2) {
  const i2 = 100 * (t2 - e2) / e2 + 100;
  return e2 < 0 ? -i2 : i2;
}
function O$(t2, e2) {
  const i2 = V$(t2.Ph(), e2), s2 = V$(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function A$(t2, e2) {
  const i2 = Math.abs(t2);
  if (i2 < 1e-15) return 0;
  const s2 = Math.log10(i2 + e2.Ua) + e2.$a;
  return t2 < 0 ? -s2 : s2;
}
function F$(t2, e2) {
  const i2 = Math.abs(t2);
  if (i2 < 1e-15) return 0;
  const s2 = Math.pow(10, i2 - e2.$a) - e2.Ua;
  return t2 < 0 ? -s2 : s2;
}
function N$(t2, e2) {
  if (null === t2) return null;
  const i2 = A$(t2.Ph(), e2), s2 = A$(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function W$(t2, e2) {
  if (null === t2) return null;
  const i2 = F$(t2.Ph(), e2), s2 = F$(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function I$(t2) {
  if (null === t2) return P$;
  const e2 = Math.abs(t2.Rh() - t2.Ph());
  if (e2 >= 1 || e2 < 1e-15) return P$;
  const i2 = Math.ceil(Math.abs(Math.log10(e2))), s2 = P$.$a + i2;
  return { $a: s2, Ua: 1 / Math.pow(10, s2) };
}
class dn {
  constructor(t2, e2) {
    if (this.qa = t2, this.Ya = e2, function(t3) {
      if (t3 < 0) return false;
      for (let e3 = t3; e3 > 1; e3 /= 10) if (e3 % 10 != 0) return false;
      return true;
    }(this.qa)) this.Za = [2, 2.5, 2];
    else {
      this.Za = [];
      for (let t3 = this.qa; 1 !== t3; ) {
        if (t3 % 2 == 0) this.Za.push(2), t3 /= 2;
        else {
          if (t3 % 5 != 0) throw new Error("unexpected base");
          this.Za.push(2, 2.5), t3 /= 5;
        }
        if (this.Za.length > 100) throw new Error("something wrong with base");
      }
    }
  }
  Xa(t2, e2, i2) {
    const s2 = 0 === this.qa ? 0 : 1 / this.qa;
    let n2 = Math.pow(10, Math.max(0, Math.ceil(Math.log10(t2 - e2)))), r2 = 0, o2 = this.Ya[0];
    for (; ; ) {
      const t3 = Qz(n2, s2, 1e-14) && n2 > s2 + 1e-14, e3 = Qz(n2, i2 * o2, 1e-14), a3 = Qz(n2, 1, 1e-14);
      if (!(t3 && e3 && a3)) break;
      n2 /= o2, o2 = this.Ya[++r2 % this.Ya.length];
    }
    if (n2 <= s2 + 1e-14 && (n2 = s2), n2 = Math.max(1, n2), this.Za.length > 0 && (a2 = n2, Math.abs(a2 - 1) < 1e-14)) for (r2 = 0, o2 = this.Za[0]; Qz(n2, i2 * o2, 1e-14) && n2 > s2 + 1e-14; ) n2 /= o2, o2 = this.Za[++r2 % this.Za.length];
    var a2;
    return n2;
  }
}
class fn {
  constructor(t2, e2, i2, s2) {
    this.Ka = [], this.Li = t2, this.qa = e2, this.Ga = i2, this.Ja = s2;
  }
  Xa(t2, e2) {
    if (t2 < e2) throw new Error("high < low");
    const i2 = this.Li.At(), s2 = (t2 - e2) * this.Qa() / i2, n2 = new dn(this.qa, [2, 2.5, 2]), r2 = new dn(this.qa, [2, 2, 2.5]), o2 = new dn(this.qa, [2.5, 2, 2]), a2 = [];
    return a2.push(n2.Xa(t2, e2, s2), r2.Xa(t2, e2, s2), o2.Xa(t2, e2, s2)), function(t3) {
      if (t3.length < 1) throw Error("array is empty");
      let e3 = t3[0];
      for (let i3 = 1; i3 < t3.length; ++i3) t3[i3] < e3 && (e3 = t3[i3]);
      return e3;
    }(a2);
  }
  io() {
    const t2 = this.Li, e2 = t2.Ct();
    if (null === e2) return void (this.Ka = []);
    const i2 = t2.At(), s2 = this.Ga(i2 - 1, e2), n2 = this.Ga(0, e2), r2 = this.Li.W().entireTextOnly ? this.no() / 2 : 0, o2 = r2, a2 = i2 - 1 - r2, l2 = Math.max(s2, n2), h2 = Math.min(s2, n2);
    if (l2 === h2) return void (this.Ka = []);
    let c2 = this.Xa(l2, h2), u2 = l2 % c2;
    u2 += u2 < 0 ? c2 : 0;
    const d2 = l2 >= h2 ? 1 : -1;
    let f2 = null, p2 = 0;
    for (let i3 = l2 - u2; i3 > h2; i3 -= c2) {
      const s3 = this.Ja(i3, e2, true);
      null !== f2 && Math.abs(s3 - f2) < this.Qa() || s3 < o2 || s3 > a2 || (p2 < this.Ka.length ? (this.Ka[p2].Ea = s3, this.Ka[p2].so = t2.eo(i3)) : this.Ka.push({ Ea: s3, so: t2.eo(i3) }), p2++, f2 = s3, t2.ro() && (c2 = this.Xa(i3 * d2, h2)));
    }
    this.Ka.length = p2;
  }
  Ha() {
    return this.Ka;
  }
  no() {
    return this.Li.P();
  }
  Qa() {
    return Math.ceil(2.5 * this.no());
  }
}
function B$(t2) {
  return t2.slice().sort((t3, e2) => dz(t3.Xi()) - dz(e2.Xi()));
}
var j$;
!function(t2) {
  t2[t2.Normal = 0] = "Normal", t2[t2.Logarithmic = 1] = "Logarithmic", t2[t2.Percentage = 2] = "Percentage", t2[t2.IndexedTo100 = 3] = "IndexedTo100";
}(j$ || (j$ = {}));
const H$ = new vt(), q$ = new ft(100, 1);
class wn {
  constructor(t2, e2, i2, s2) {
    this.ho = 0, this.lo = null, this.Ih = null, this.ao = null, this.oo = { _o: false, uo: null }, this.co = 0, this.do = 0, this.fo = new D(), this.vo = new D(), this.po = [], this.mo = null, this.bo = null, this.wo = null, this.Mo = null, this.wa = q$, this.xo = I$(null), this.So = t2, this.cn = e2, this.ko = i2, this.yo = s2, this.Co = new fn(this, 100, this.To.bind(this), this.Po.bind(this));
  }
  Pa() {
    return this.So;
  }
  W() {
    return this.cn;
  }
  $h(t2) {
    if (Mz(this.cn, t2), this.Ra(), void 0 !== t2.mode && this.Ro({ Cr: t2.mode }), void 0 !== t2.scaleMargins) {
      const e2 = uz(t2.scaleMargins.top), i2 = uz(t2.scaleMargins.bottom);
      if (e2 < 0 || e2 > 1) throw new Error(`Invalid top margin - expect value between 0 and 1, given=${e2}`);
      if (i2 < 0 || i2 > 1) throw new Error(`Invalid bottom margin - expect value between 0 and 1, given=${i2}`);
      if (e2 + i2 > 1) throw new Error(`Invalid margins - sum of margins must be less than 1, given=${e2 + i2}`);
      this.Do(), this.bo = null;
    }
  }
  Vo() {
    return this.cn.autoScale;
  }
  ro() {
    return 1 === this.cn.mode;
  }
  Mh() {
    return 2 === this.cn.mode;
  }
  Oo() {
    return 3 === this.cn.mode;
  }
  Cr() {
    return { Wn: this.cn.autoScale, Bo: this.cn.invertScale, Cr: this.cn.mode };
  }
  Ro(t2) {
    const e2 = this.Cr();
    let i2 = null;
    void 0 !== t2.Wn && (this.cn.autoScale = t2.Wn), void 0 !== t2.Cr && (this.cn.mode = t2.Cr, 2 !== t2.Cr && 3 !== t2.Cr || (this.cn.autoScale = true), this.oo._o = false), 1 === e2.Cr && t2.Cr !== e2.Cr && (function(t3, e3) {
      if (null === t3) return false;
      const i3 = F$(t3.Ph(), e3), s3 = F$(t3.Rh(), e3);
      return isFinite(i3) && isFinite(s3);
    }(this.Ih, this.xo) ? (i2 = W$(this.Ih, this.xo), null !== i2 && this.Ao(i2)) : this.cn.autoScale = true), 1 === t2.Cr && t2.Cr !== e2.Cr && (i2 = N$(this.Ih, this.xo), null !== i2 && this.Ao(i2));
    const s2 = e2.Cr !== this.cn.mode;
    s2 && (2 === e2.Cr || this.Mh()) && this.Ra(), s2 && (3 === e2.Cr || this.Oo()) && this.Ra(), void 0 !== t2.Bo && e2.Bo !== t2.Bo && (this.cn.invertScale = t2.Bo, this.Io()), this.vo.m(e2, this.Cr());
  }
  zo() {
    return this.vo;
  }
  P() {
    return this.ko.fontSize;
  }
  At() {
    return this.ho;
  }
  Lo(t2) {
    this.ho !== t2 && (this.ho = t2, this.Do(), this.bo = null);
  }
  Eo() {
    if (this.lo) return this.lo;
    const t2 = this.At() - this.No() - this.Fo();
    return this.lo = t2, t2;
  }
  Lh() {
    return this.Wo(), this.Ih;
  }
  Ao(t2, e2) {
    const i2 = this.Ih;
    (e2 || null === i2 && null !== t2 || null !== i2 && !i2.Ch(t2)) && (this.bo = null, this.Ih = t2);
  }
  Ni() {
    return this.Wo(), 0 === this.ho || !this.Ih || this.Ih.Ni();
  }
  jo(t2) {
    return this.Bo() ? t2 : this.At() - 1 - t2;
  }
  Rt(t2, e2) {
    return this.Mh() ? t2 = T$(t2, e2) : this.Oo() && (t2 = V$(t2, e2)), this.Po(t2, e2);
  }
  te(t2, e2, i2) {
    this.Wo();
    const s2 = this.Fo(), n2 = dz(this.Lh()), r2 = n2.Ph(), o2 = n2.Rh(), a2 = this.Eo() - 1, l2 = this.Bo(), h2 = a2 / (o2 - r2), c2 = void 0 === i2 ? 0 : i2.from, u2 = void 0 === i2 ? t2.length : i2.to, d2 = this.Ho();
    for (let i3 = c2; i3 < u2; i3++) {
      const n3 = t2[i3], o3 = n3._t;
      if (isNaN(o3)) continue;
      let a3 = o3;
      null !== d2 && (a3 = d2(n3._t, e2));
      const c3 = s2 + h2 * (a3 - r2), u3 = l2 ? c3 : this.ho - 1 - c3;
      n3.st = u3;
    }
  }
  be(t2, e2, i2) {
    this.Wo();
    const s2 = this.Fo(), n2 = dz(this.Lh()), r2 = n2.Ph(), o2 = n2.Rh(), a2 = this.Eo() - 1, l2 = this.Bo(), h2 = a2 / (o2 - r2), c2 = void 0 === i2 ? 0 : i2.from, u2 = void 0 === i2 ? t2.length : i2.to, d2 = this.Ho();
    for (let i3 = c2; i3 < u2; i3++) {
      const n3 = t2[i3];
      let o3 = n3.ge, a3 = n3.Me, c3 = n3.xe, u3 = n3.Se;
      null !== d2 && (o3 = d2(n3.ge, e2), a3 = d2(n3.Me, e2), c3 = d2(n3.xe, e2), u3 = d2(n3.Se, e2));
      let f2 = s2 + h2 * (o3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2;
      n3.pe = p2, f2 = s2 + h2 * (a3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2, n3.de = p2, f2 = s2 + h2 * (c3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2, n3.fe = p2, f2 = s2 + h2 * (u3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2, n3.me = p2;
    }
  }
  pn(t2, e2) {
    const i2 = this.To(t2, e2);
    return this.$o(i2, e2);
  }
  $o(t2, e2) {
    let i2 = t2;
    return this.Mh() ? i2 = function(t3, e3) {
      return e3 < 0 && (t3 = -t3), t3 / 100 * e3 + e3;
    }(i2, e2) : this.Oo() && (i2 = function(t3, e3) {
      return t3 -= 100, e3 < 0 && (t3 = -t3), t3 / 100 * e3 + e3;
    }(i2, e2)), i2;
  }
  Ba() {
    return this.po;
  }
  Uo() {
    if (this.mo) return this.mo;
    let t2 = [];
    for (let e2 = 0; e2 < this.po.length; e2++) {
      const i2 = this.po[e2];
      null === i2.Xi() && i2.Ki(e2 + 1), t2.push(i2);
    }
    return t2 = B$(t2), this.mo = t2, this.mo;
  }
  qo(t2) {
    -1 === this.po.indexOf(t2) && (this.po.push(t2), this.Ra(), this.Yo());
  }
  Zo(t2) {
    const e2 = this.po.indexOf(t2);
    if (-1 === e2) throw new Error("source is not attached to scale");
    this.po.splice(e2, 1), 0 === this.po.length && (this.Ro({ Wn: true }), this.Ao(null)), this.Ra(), this.Yo();
  }
  Ct() {
    let t2 = null;
    for (const e2 of this.po) {
      const i2 = e2.Ct();
      null !== i2 && (null === t2 || i2.la < t2.la) && (t2 = i2);
    }
    return null === t2 ? null : t2.Vt;
  }
  Bo() {
    return this.cn.invertScale;
  }
  Ha() {
    const t2 = null === this.Ct();
    if (null !== this.bo && (t2 || this.bo.Xo === t2)) return this.bo.Ha;
    this.Co.io();
    const e2 = this.Co.Ha();
    return this.bo = { Ha: e2, Xo: t2 }, this.fo.m(), e2;
  }
  Ko() {
    return this.fo;
  }
  Go(t2) {
    this.Mh() || this.Oo() || null === this.wo && null === this.ao && (this.Ni() || (this.wo = this.ho - t2, this.ao = dz(this.Lh()).Th()));
  }
  Jo(t2) {
    if (this.Mh() || this.Oo()) return;
    if (null === this.wo) return;
    this.Ro({ Wn: false }), (t2 = this.ho - t2) < 0 && (t2 = 0);
    let e2 = (this.wo + 0.2 * (this.ho - 1)) / (t2 + 0.2 * (this.ho - 1));
    const i2 = dz(this.ao).Th();
    e2 = Math.max(e2, 0.1), i2.Vh(e2), this.Ao(i2);
  }
  Qo() {
    this.Mh() || this.Oo() || (this.wo = null, this.ao = null);
  }
  t_(t2) {
    this.Vo() || null === this.Mo && null === this.ao && (this.Ni() || (this.Mo = t2, this.ao = dz(this.Lh()).Th()));
  }
  i_(t2) {
    if (this.Vo()) return;
    if (null === this.Mo) return;
    const e2 = dz(this.Lh()).Dh() / (this.Eo() - 1);
    let i2 = t2 - this.Mo;
    this.Bo() && (i2 *= -1);
    const s2 = i2 * e2, n2 = dz(this.ao).Th();
    n2.Oh(s2), this.Ao(n2, true), this.bo = null;
  }
  n_() {
    this.Vo() || null !== this.Mo && (this.Mo = null, this.ao = null);
  }
  ba() {
    return this.wa || this.Ra(), this.wa;
  }
  Fi(t2, e2) {
    switch (this.cn.mode) {
      case 2:
        return this.s_(T$(t2, e2));
      case 3:
        return this.ba().format(V$(t2, e2));
      default:
        return this.Wh(t2);
    }
  }
  eo(t2) {
    switch (this.cn.mode) {
      case 2:
        return this.s_(t2);
      case 3:
        return this.ba().format(t2);
      default:
        return this.Wh(t2);
    }
  }
  Yl(t2) {
    return this.Wh(t2, dz(this.e_()).ba());
  }
  Zl(t2, e2) {
    return t2 = T$(t2, e2), this.s_(t2, H$);
  }
  r_() {
    return this.po;
  }
  h_(t2) {
    this.oo = { uo: t2, _o: false };
  }
  Vn() {
    this.po.forEach((t2) => t2.Vn());
  }
  Ra() {
    this.bo = null;
    const t2 = this.e_();
    let e2 = 100;
    null !== t2 && (e2 = Math.round(1 / t2.ma())), this.wa = q$, this.Mh() ? (this.wa = H$, e2 = 100) : this.Oo() ? (this.wa = new ft(100, 1), e2 = 100) : null !== t2 && (this.wa = t2.ba()), this.Co = new fn(this, e2, this.To.bind(this), this.Po.bind(this)), this.Co.io();
  }
  Yo() {
    this.mo = null;
  }
  e_() {
    return this.po[0] || null;
  }
  No() {
    return this.Bo() ? this.cn.scaleMargins.bottom * this.At() + this.do : this.cn.scaleMargins.top * this.At() + this.co;
  }
  Fo() {
    return this.Bo() ? this.cn.scaleMargins.top * this.At() + this.co : this.cn.scaleMargins.bottom * this.At() + this.do;
  }
  Wo() {
    this.oo._o || (this.oo._o = true, this.l_());
  }
  Do() {
    this.lo = null;
  }
  Po(t2, e2) {
    if (this.Wo(), this.Ni()) return 0;
    t2 = this.ro() && t2 ? A$(t2, this.xo) : t2;
    const i2 = dz(this.Lh()), s2 = this.Fo() + (this.Eo() - 1) * (t2 - i2.Ph()) / i2.Dh();
    return this.jo(s2);
  }
  To(t2, e2) {
    if (this.Wo(), this.Ni()) return 0;
    const i2 = this.jo(t2), s2 = dz(this.Lh()), n2 = s2.Ph() + s2.Dh() * ((i2 - this.Fo()) / (this.Eo() - 1));
    return this.ro() ? F$(n2, this.xo) : n2;
  }
  Io() {
    this.bo = null, this.Co.io();
  }
  l_() {
    const t2 = this.oo.uo;
    if (null === t2) return;
    let e2 = null;
    const i2 = this.r_();
    let s2 = 0, n2 = 0;
    for (const r3 of i2) {
      if (!r3.yt()) continue;
      const i3 = r3.Ct();
      if (null === i3) continue;
      const o3 = r3.Il(t2.Os(), t2.ui());
      let a2 = o3 && o3.Lh();
      if (null !== a2) {
        switch (this.cn.mode) {
          case 1:
            a2 = N$(a2, this.xo);
            break;
          case 2:
            a2 = L$(a2, i3.Vt);
            break;
          case 3:
            a2 = O$(a2, i3.Vt);
        }
        if (e2 = null === e2 ? a2 : e2.ts(dz(a2)), null !== o3) {
          const t3 = o3.Eh();
          null !== t3 && (s2 = Math.max(s2, t3.above), n2 = Math.max(n2, t3.below));
        }
      }
    }
    if (s2 === this.co && n2 === this.do || (this.co = s2, this.do = n2, this.bo = null, this.Do()), null !== e2) {
      if (e2.Ph() === e2.Rh()) {
        const t3 = this.e_(), i3 = 5 * (null === t3 || this.Mh() || this.Oo() ? 1 : t3.ma());
        this.ro() && (e2 = W$(e2, this.xo)), e2 = new Ri(e2.Ph() - i3, e2.Rh() + i3), this.ro() && (e2 = N$(e2, this.xo));
      }
      if (this.ro()) {
        const t3 = W$(e2, this.xo), i3 = I$(t3);
        if (r2 = i3, o2 = this.xo, r2.$a !== o2.$a || r2.Ua !== o2.Ua) {
          const s3 = null !== this.ao ? W$(this.ao, this.xo) : null;
          this.xo = i3, e2 = N$(t3, i3), null !== s3 && (this.ao = N$(s3, i3));
        }
      }
      this.Ao(e2);
    } else null === this.Ih && (this.Ao(new Ri(-0.5, 0.5)), this.xo = I$(null));
    var r2, o2;
    this.oo._o = true;
  }
  Ho() {
    return this.Mh() ? T$ : this.Oo() ? V$ : this.ro() ? (t2) => A$(t2, this.xo) : null;
  }
  a_(t2, e2, i2) {
    return void 0 === e2 ? (void 0 === i2 && (i2 = this.ba()), i2.format(t2)) : e2(t2);
  }
  Wh(t2, e2) {
    return this.a_(t2, this.yo.priceFormatter, e2);
  }
  s_(t2, e2) {
    return this.a_(t2, this.yo.percentageFormatter, e2);
  }
}
class gn {
  constructor(t2, e2) {
    this.po = [], this.o_ = /* @__PURE__ */ new Map(), this.ho = 0, this.__ = 0, this.u_ = 1e3, this.mo = null, this.c_ = new D(), this.yl = t2, this.$i = e2, this.d_ = new nn(this);
    const i2 = e2.W();
    this.f_ = this.v_("left", i2.leftPriceScale), this.p_ = this.v_("right", i2.rightPriceScale), this.f_.zo().l(this.m_.bind(this, this.f_), this), this.p_.zo().l(this.m_.bind(this, this.p_), this), this.b_(i2);
  }
  b_(t2) {
    if (t2.leftPriceScale && this.f_.$h(t2.leftPriceScale), t2.rightPriceScale && this.p_.$h(t2.rightPriceScale), t2.localization && (this.f_.Ra(), this.p_.Ra()), t2.overlayPriceScales) {
      const e2 = Array.from(this.o_.values());
      for (const i2 of e2) {
        const e3 = dz(i2[0].Dt());
        e3.$h(t2.overlayPriceScales), t2.localization && e3.Ra();
      }
    }
  }
  w_(t2) {
    switch (t2) {
      case "left":
        return this.f_;
      case "right":
        return this.p_;
    }
    return this.o_.has(t2) ? uz(this.o_.get(t2))[0].Dt() : null;
  }
  S() {
    this.$t().g_().p(this), this.f_.zo().p(this), this.p_.zo().p(this), this.po.forEach((t2) => {
      t2.S && t2.S();
    }), this.c_.m();
  }
  M_() {
    return this.u_;
  }
  x_(t2) {
    this.u_ = t2;
  }
  $t() {
    return this.$i;
  }
  Hi() {
    return this.__;
  }
  At() {
    return this.ho;
  }
  S_(t2) {
    this.__ = t2, this.k_();
  }
  Lo(t2) {
    this.ho = t2, this.f_.Lo(t2), this.p_.Lo(t2), this.po.forEach((e2) => {
      if (this.vr(e2)) {
        const i2 = e2.Dt();
        null !== i2 && i2.Lo(t2);
      }
    }), this.k_();
  }
  Ba() {
    return this.po;
  }
  vr(t2) {
    const e2 = t2.Dt();
    return null === e2 || this.f_ !== e2 && this.p_ !== e2;
  }
  qo(t2, e2, i2) {
    const s2 = void 0 !== i2 ? i2 : this.C_().y_ + 1;
    this.T_(t2, e2, s2);
  }
  Zo(t2) {
    const e2 = this.po.indexOf(t2);
    cz(-1 !== e2, "removeDataSource: invalid data source"), this.po.splice(e2, 1);
    const i2 = dz(t2.Dt()).Pa();
    if (this.o_.has(i2)) {
      const e3 = uz(this.o_.get(i2)), s3 = e3.indexOf(t2);
      -1 !== s3 && (e3.splice(s3, 1), 0 === e3.length && this.o_.delete(i2));
    }
    const s2 = t2.Dt();
    s2 && s2.Ba().indexOf(t2) >= 0 && s2.Zo(t2), null !== s2 && (s2.Yo(), this.P_(s2)), this.mo = null;
  }
  mr(t2) {
    return t2 === this.f_ ? "left" : t2 === this.p_ ? "right" : "overlay";
  }
  R_() {
    return this.f_;
  }
  D_() {
    return this.p_;
  }
  V_(t2, e2) {
    t2.Go(e2);
  }
  O_(t2, e2) {
    t2.Jo(e2), this.k_();
  }
  B_(t2) {
    t2.Qo();
  }
  A_(t2, e2) {
    t2.t_(e2);
  }
  I_(t2, e2) {
    t2.i_(e2), this.k_();
  }
  z_(t2) {
    t2.n_();
  }
  k_() {
    this.po.forEach((t2) => {
      t2.Vn();
    });
  }
  vn() {
    let t2 = null;
    return this.$i.W().rightPriceScale.visible && 0 !== this.p_.Ba().length ? t2 = this.p_ : this.$i.W().leftPriceScale.visible && 0 !== this.f_.Ba().length ? t2 = this.f_ : 0 !== this.po.length && (t2 = this.po[0].Dt()), null === t2 && (t2 = this.p_), t2;
  }
  pr() {
    let t2 = null;
    return this.$i.W().rightPriceScale.visible ? t2 = this.p_ : this.$i.W().leftPriceScale.visible && (t2 = this.f_), t2;
  }
  P_(t2) {
    null !== t2 && t2.Vo() && this.L_(t2);
  }
  E_(t2) {
    const e2 = this.yl.Xs();
    t2.Ro({ Wn: true }), null !== e2 && t2.h_(e2), this.k_();
  }
  N_() {
    this.L_(this.f_), this.L_(this.p_);
  }
  F_() {
    this.P_(this.f_), this.P_(this.p_), this.po.forEach((t2) => {
      this.vr(t2) && this.P_(t2.Dt());
    }), this.k_(), this.$i.Uh();
  }
  Uo() {
    return null === this.mo && (this.mo = B$(this.po)), this.mo;
  }
  W_() {
    return this.c_;
  }
  j_() {
    return this.d_;
  }
  L_(t2) {
    const e2 = t2.r_();
    if (e2 && e2.length > 0 && !this.yl.Ni()) {
      const e3 = this.yl.Xs();
      null !== e3 && t2.h_(e3);
    }
    t2.Vn();
  }
  C_() {
    const t2 = this.Uo();
    if (0 === t2.length) return { H_: 0, y_: 0 };
    let e2 = 0, i2 = 0;
    for (let s2 = 0; s2 < t2.length; s2++) {
      const n2 = t2[s2].Xi();
      null !== n2 && (n2 < e2 && (e2 = n2), n2 > i2 && (i2 = n2));
    }
    return { H_: e2, y_: i2 };
  }
  T_(t2, e2, i2) {
    let s2 = this.w_(e2);
    if (null === s2 && (s2 = this.v_(e2, this.$i.W().overlayPriceScales)), this.po.push(t2), !jz(e2)) {
      const i3 = this.o_.get(e2) || [];
      i3.push(t2), this.o_.set(e2, i3);
    }
    s2.qo(t2), t2.Gi(s2), t2.Ki(i2), this.P_(s2), this.mo = null;
  }
  m_(t2, e2, i2) {
    e2.Cr !== i2.Cr && this.L_(t2);
  }
  v_(t2, e2) {
    const i2 = Object.assign({ visible: true, autoScale: true }, Dz(e2)), s2 = new wn(t2, i2, this.$i.W().layout, this.$i.W().localization);
    return s2.Lo(this.At()), s2;
  }
}
class Mn {
  constructor(t2, e2, i2 = 50) {
    this.Ke = 0, this.Ge = 1, this.Je = 1, this.tr = /* @__PURE__ */ new Map(), this.Qe = /* @__PURE__ */ new Map(), this.U_ = t2, this.q_ = e2, this.ir = i2;
  }
  Y_(t2) {
    const e2 = t2.time, i2 = this.q_.cacheKey(e2), s2 = this.tr.get(i2);
    if (void 0 !== s2) return s2.Z_;
    if (this.Ke === this.ir) {
      const t3 = this.Qe.get(this.Je);
      this.Qe.delete(this.Je), this.tr.delete(uz(t3)), this.Je++, this.Ke--;
    }
    const n2 = this.U_(t2);
    return this.tr.set(i2, { Z_: n2, rr: this.Ge }), this.Qe.set(this.Ge, i2), this.Ke++, this.Ge++, n2;
  }
}
class xn {
  constructor(t2, e2) {
    cz(t2 <= e2, "right should be >= left"), this.X_ = t2, this.K_ = e2;
  }
  Os() {
    return this.X_;
  }
  ui() {
    return this.K_;
  }
  G_() {
    return this.K_ - this.X_ + 1;
  }
  Kr(t2) {
    return this.X_ <= t2 && t2 <= this.K_;
  }
  Ch(t2) {
    return this.X_ === t2.Os() && this.K_ === t2.ui();
  }
}
function X$(t2, e2) {
  return null === t2 || null === e2 ? t2 === e2 : t2.Ch(e2);
}
class kn {
  constructor() {
    this.J_ = /* @__PURE__ */ new Map(), this.tr = null, this.Q_ = false;
  }
  tu(t2) {
    this.Q_ = t2, this.tr = null;
  }
  iu(t2, e2) {
    this.nu(e2), this.tr = null;
    for (let i2 = e2; i2 < t2.length; ++i2) {
      const e3 = t2[i2];
      let s2 = this.J_.get(e3.timeWeight);
      void 0 === s2 && (s2 = [], this.J_.set(e3.timeWeight, s2)), s2.push({ index: i2, time: e3.time, weight: e3.timeWeight, originalTime: e3.originalTime });
    }
  }
  su(t2, e2) {
    const i2 = Math.ceil(e2 / t2);
    return null !== this.tr && this.tr.eu === i2 || (this.tr = { Ha: this.ru(i2), eu: i2 }), this.tr.Ha;
  }
  nu(t2) {
    if (0 === t2) return void this.J_.clear();
    const e2 = [];
    this.J_.forEach((i2, s2) => {
      t2 <= i2[0].index ? e2.push(s2) : i2.splice(i$(i2, t2, (e3) => e3.index < t2), 1 / 0);
    });
    for (const t3 of e2) this.J_.delete(t3);
  }
  ru(t2) {
    let e2 = [];
    for (const i2 of Array.from(this.J_.keys()).sort((t3, e3) => e3 - t3)) {
      if (!this.J_.get(i2)) continue;
      const s2 = e2;
      e2 = [];
      const n2 = s2.length;
      let r2 = 0;
      const o2 = uz(this.J_.get(i2)), a2 = o2.length;
      let l2 = 1 / 0, h2 = -1 / 0;
      for (let i3 = 0; i3 < a2; i3++) {
        const a3 = o2[i3], c2 = a3.index;
        for (; r2 < n2; ) {
          const t3 = s2[r2], i4 = t3.index;
          if (!(i4 < c2)) {
            l2 = i4;
            break;
          }
          r2++, e2.push(t3), h2 = i4, l2 = 1 / 0;
        }
        if (l2 - c2 >= t2 && c2 - h2 >= t2) e2.push(a3), h2 = c2;
        else if (this.Q_) return s2;
      }
      for (; r2 < n2; r2++) e2.push(s2[r2]);
    }
    return e2;
  }
}
class yn {
  constructor(t2) {
    this.hu = t2;
  }
  lu() {
    return null === this.hu ? null : new xn(Math.floor(this.hu.Os()), Math.ceil(this.hu.ui()));
  }
  au() {
    return this.hu;
  }
  static ou() {
    return new yn(null);
  }
}
function K$(t2, e2) {
  return t2.weight > e2.weight ? t2 : e2;
}
class Tn {
  constructor(t2, e2, i2, s2) {
    this.__ = 0, this._u = null, this.uu = [], this.Mo = null, this.wo = null, this.cu = new kn(), this.du = /* @__PURE__ */ new Map(), this.fu = yn.ou(), this.vu = true, this.pu = new D(), this.mu = new D(), this.bu = new D(), this.wu = null, this.gu = null, this.Mu = [], this.cn = e2, this.yo = i2, this.xu = e2.rightOffset, this.Su = e2.barSpacing, this.$i = t2, this.q_ = s2, this.ku(), this.cu.tu(e2.uniformDistribution);
  }
  W() {
    return this.cn;
  }
  yu(t2) {
    Mz(this.yo, t2), this.Cu(), this.ku();
  }
  $h(t2, e2) {
    var i2;
    Mz(this.cn, t2), this.cn.fixLeftEdge && this.Tu(), this.cn.fixRightEdge && this.Pu(), void 0 !== t2.barSpacing && this.$i.Gn(t2.barSpacing), void 0 !== t2.rightOffset && this.$i.Jn(t2.rightOffset), void 0 !== t2.minBarSpacing && this.$i.Gn(null !== (i2 = t2.barSpacing) && void 0 !== i2 ? i2 : this.Su), this.Cu(), this.ku(), this.bu.m();
  }
  mn(t2) {
    var e2, i2;
    return null !== (i2 = null === (e2 = this.uu[t2]) || void 0 === e2 ? void 0 : e2.time) && void 0 !== i2 ? i2 : null;
  }
  Ui(t2) {
    var e2;
    return null !== (e2 = this.uu[t2]) && void 0 !== e2 ? e2 : null;
  }
  Va(t2, e2) {
    if (this.uu.length < 1) return null;
    if (this.q_.key(t2) > this.q_.key(this.uu[this.uu.length - 1].time)) return e2 ? this.uu.length - 1 : null;
    const i2 = i$(this.uu, this.q_.key(t2), (t3, e3) => this.q_.key(t3.time) < e3);
    return this.q_.key(t2) < this.q_.key(this.uu[i2].time) ? e2 ? i2 : null : i2;
  }
  Ni() {
    return 0 === this.__ || 0 === this.uu.length || null === this._u;
  }
  Da() {
    return this.uu.length > 0;
  }
  Xs() {
    return this.Ru(), this.fu.lu();
  }
  Du() {
    return this.Ru(), this.fu.au();
  }
  Vu() {
    const t2 = this.Xs();
    if (null === t2) return null;
    const e2 = { from: t2.Os(), to: t2.ui() };
    return this.Ou(e2);
  }
  Ou(t2) {
    const e2 = Math.round(t2.from), i2 = Math.round(t2.to), s2 = dz(this.Bu()), n2 = dz(this.Au());
    return { from: dz(this.Ui(Math.max(s2, e2))), to: dz(this.Ui(Math.min(n2, i2))) };
  }
  Iu(t2) {
    return { from: dz(this.Va(t2.from, true)), to: dz(this.Va(t2.to, true)) };
  }
  Hi() {
    return this.__;
  }
  S_(t2) {
    if (!isFinite(t2) || t2 <= 0) return;
    if (this.__ === t2) return;
    const e2 = this.Du(), i2 = this.__;
    if (this.__ = t2, this.vu = true, this.cn.lockVisibleTimeRangeOnResize && 0 !== i2) {
      const e3 = this.Su * t2 / i2;
      this.Su = e3;
    }
    if (this.cn.fixLeftEdge && null !== e2 && e2.Os() <= 0) {
      const e3 = i2 - t2;
      this.xu -= Math.round(e3 / this.Su) + 1, this.vu = true;
    }
    this.zu(), this.Lu();
  }
  It(t2) {
    if (this.Ni() || !Cz(t2)) return 0;
    const e2 = this.Eu() + this.xu - t2;
    return this.__ - (e2 + 0.5) * this.Su - 1;
  }
  Qs(t2, e2) {
    const i2 = this.Eu(), s2 = void 0 === e2 ? 0 : e2.from, n2 = void 0 === e2 ? t2.length : e2.to;
    for (let e3 = s2; e3 < n2; e3++) {
      const s3 = t2[e3].ot, n3 = i2 + this.xu - s3, r2 = this.__ - (n3 + 0.5) * this.Su - 1;
      t2[e3].nt = r2;
    }
  }
  Nu(t2) {
    return Math.ceil(this.Fu(t2));
  }
  Jn(t2) {
    this.vu = true, this.xu = t2, this.Lu(), this.$i.Wu(), this.$i.Uh();
  }
  le() {
    return this.Su;
  }
  Gn(t2) {
    this.ju(t2), this.Lu(), this.$i.Wu(), this.$i.Uh();
  }
  Hu() {
    return this.xu;
  }
  Ha() {
    if (this.Ni()) return null;
    if (null !== this.gu) return this.gu;
    const t2 = this.Su, e2 = 5 * (this.$i.W().layout.fontSize + 4) / 8 * (this.cn.tickMarkMaxCharacterLength || 8), i2 = Math.round(e2 / t2), s2 = dz(this.Xs()), n2 = Math.max(s2.Os(), s2.Os() - i2), r2 = Math.max(s2.ui(), s2.ui() - i2), o2 = this.cu.su(t2, e2), a2 = this.Bu() + i2, l2 = this.Au() - i2, h2 = this.$u(), c2 = this.cn.fixLeftEdge || h2, u2 = this.cn.fixRightEdge || h2;
    let d2 = 0;
    for (const t3 of o2) {
      if (!(n2 <= t3.index && t3.index <= r2)) continue;
      let i3;
      d2 < this.Mu.length ? (i3 = this.Mu[d2], i3.coord = this.It(t3.index), i3.label = this.Uu(t3), i3.weight = t3.weight) : (i3 = { needAlignCoordinate: false, coord: this.It(t3.index), label: this.Uu(t3), weight: t3.weight }, this.Mu.push(i3)), this.Su > e2 / 2 && !h2 ? i3.needAlignCoordinate = false : i3.needAlignCoordinate = c2 && t3.index <= a2 || u2 && t3.index >= l2, d2++;
    }
    return this.Mu.length = d2, this.gu = this.Mu, this.Mu;
  }
  qu() {
    this.vu = true, this.Gn(this.cn.barSpacing), this.Jn(this.cn.rightOffset);
  }
  Yu(t2) {
    this.vu = true, this._u = t2, this.Lu(), this.Tu();
  }
  Zu(t2, e2) {
    const i2 = this.Fu(t2), s2 = this.le(), n2 = s2 + e2 * (s2 / 10);
    this.Gn(n2), this.cn.rightBarStaysOnScroll || this.Jn(this.Hu() + (i2 - this.Fu(t2)));
  }
  Go(t2) {
    this.Mo && this.n_(), null === this.wo && null === this.wu && (this.Ni() || (this.wo = t2, this.Xu()));
  }
  Jo(t2) {
    if (null === this.wu) return;
    const e2 = Jz(this.__ - t2, 0, this.__), i2 = Jz(this.__ - dz(this.wo), 0, this.__);
    0 !== e2 && 0 !== i2 && this.Gn(this.wu.le * e2 / i2);
  }
  Qo() {
    null !== this.wo && (this.wo = null, this.Ku());
  }
  t_(t2) {
    null === this.Mo && null === this.wu && (this.Ni() || (this.Mo = t2, this.Xu()));
  }
  i_(t2) {
    if (null === this.Mo) return;
    const e2 = (this.Mo - t2) / this.le();
    this.xu = dz(this.wu).Hu + e2, this.vu = true, this.Lu();
  }
  n_() {
    null !== this.Mo && (this.Mo = null, this.Ku());
  }
  Gu() {
    this.Ju(this.cn.rightOffset);
  }
  Ju(t2, e2 = 400) {
    if (!isFinite(t2)) throw new RangeError("offset is required and must be finite number");
    if (!isFinite(e2) || e2 <= 0) throw new RangeError("animationDuration (optional) must be finite positive number");
    const i2 = this.xu, s2 = performance.now();
    this.$i.Zn({ Qu: (t3) => (t3 - s2) / e2 >= 1, tc: (n2) => {
      const r2 = (n2 - s2) / e2;
      return r2 >= 1 ? t2 : i2 + (t2 - i2) * r2;
    } });
  }
  bt(t2, e2) {
    this.vu = true, this.uu = t2, this.cu.iu(t2, e2), this.Lu();
  }
  nc() {
    return this.pu;
  }
  sc() {
    return this.mu;
  }
  ec() {
    return this.bu;
  }
  Eu() {
    return this._u || 0;
  }
  rc(t2) {
    const e2 = t2.G_();
    this.ju(this.__ / e2), this.xu = t2.ui() - this.Eu(), this.Lu(), this.vu = true, this.$i.Wu(), this.$i.Uh();
  }
  hc() {
    const t2 = this.Bu(), e2 = this.Au();
    null !== t2 && null !== e2 && this.rc(new xn(t2, e2 + this.cn.rightOffset));
  }
  lc(t2) {
    const e2 = new xn(t2.from, t2.to);
    this.rc(e2);
  }
  qi(t2) {
    return void 0 !== this.yo.timeFormatter ? this.yo.timeFormatter(t2.originalTime) : this.q_.formatHorzItem(t2.time);
  }
  $u() {
    const { handleScroll: t2, handleScale: e2 } = this.$i.W();
    return !(t2.horzTouchDrag || t2.mouseWheel || t2.pressedMouseMove || t2.vertTouchDrag || e2.axisDoubleClickReset.time || e2.axisPressedMouseMove.time || e2.mouseWheel || e2.pinch);
  }
  Bu() {
    return 0 === this.uu.length ? null : 0;
  }
  Au() {
    return 0 === this.uu.length ? null : this.uu.length - 1;
  }
  ac(t2) {
    return (this.__ - 1 - t2) / this.Su;
  }
  Fu(t2) {
    const e2 = this.ac(t2), i2 = this.Eu() + this.xu - e2;
    return Math.round(1e6 * i2) / 1e6;
  }
  ju(t2) {
    const e2 = this.Su;
    this.Su = t2, this.zu(), e2 !== this.Su && (this.vu = true, this.oc());
  }
  Ru() {
    if (!this.vu) return;
    if (this.vu = false, this.Ni()) return void this._c(yn.ou());
    const t2 = this.Eu(), e2 = this.__ / this.Su, i2 = this.xu + t2, s2 = new xn(i2 - e2 + 1, i2);
    this._c(new yn(s2));
  }
  zu() {
    const t2 = this.uc();
    if (this.Su < t2 && (this.Su = t2, this.vu = true), 0 !== this.__) {
      const t3 = 0.5 * this.__;
      this.Su > t3 && (this.Su = t3, this.vu = true);
    }
  }
  uc() {
    return this.cn.fixLeftEdge && this.cn.fixRightEdge && 0 !== this.uu.length ? this.__ / this.uu.length : this.cn.minBarSpacing;
  }
  Lu() {
    const t2 = this.cc();
    null !== t2 && this.xu < t2 && (this.xu = t2, this.vu = true);
    const e2 = this.dc();
    this.xu > e2 && (this.xu = e2, this.vu = true);
  }
  cc() {
    const t2 = this.Bu(), e2 = this._u;
    return null === t2 || null === e2 ? null : t2 - e2 - 1 + (this.cn.fixLeftEdge ? this.__ / this.Su : Math.min(2, this.uu.length));
  }
  dc() {
    return this.cn.fixRightEdge ? 0 : this.__ / this.Su - Math.min(2, this.uu.length);
  }
  Xu() {
    this.wu = { le: this.le(), Hu: this.Hu() };
  }
  Ku() {
    this.wu = null;
  }
  Uu(t2) {
    let e2 = this.du.get(t2.weight);
    return void 0 === e2 && (e2 = new Mn((t3) => this.fc(t3), this.q_), this.du.set(t2.weight, e2)), e2.Y_(t2);
  }
  fc(t2) {
    return this.q_.formatTickmark(t2, this.yo);
  }
  _c(t2) {
    const e2 = this.fu;
    this.fu = t2, X$(e2.lu(), this.fu.lu()) || this.pu.m(), X$(e2.au(), this.fu.au()) || this.mu.m(), this.oc();
  }
  oc() {
    this.gu = null;
  }
  Cu() {
    this.oc(), this.du.clear();
  }
  ku() {
    this.q_.updateFormatter(this.yo);
  }
  Tu() {
    if (!this.cn.fixLeftEdge) return;
    const t2 = this.Bu();
    if (null === t2) return;
    const e2 = this.Xs();
    if (null === e2) return;
    const i2 = e2.Os() - t2;
    if (i2 < 0) {
      const t3 = this.xu - i2 - 1;
      this.Jn(t3);
    }
    this.zu();
  }
  Pu() {
    this.Lu(), this.zu();
  }
}
class Pn {
  X(t2, e2, i2) {
    t2.useMediaCoordinateSpace((t3) => this.K(t3, e2, i2));
  }
  gl(t2, e2, i2) {
    t2.useMediaCoordinateSpace((t3) => this.vc(t3, e2, i2));
  }
  vc(t2, e2, i2) {
  }
}
class Rn extends Pn {
  constructor(t2) {
    super(), this.mc = /* @__PURE__ */ new Map(), this.zt = t2;
  }
  K(t2) {
  }
  vc(t2) {
    if (!this.zt.yt) return;
    const { context: e2, mediaSize: i2 } = t2;
    let s2 = 0;
    for (const t3 of this.zt.bc) {
      if (0 === t3.Kt.length) continue;
      e2.font = t3.R;
      const n3 = this.wc(e2, t3.Kt);
      n3 > i2.width ? t3.Zu = i2.width / n3 : t3.Zu = 1, s2 += t3.gc * t3.Zu;
    }
    let n2 = 0;
    switch (this.zt.Mc) {
      case "top":
        n2 = 0;
        break;
      case "center":
        n2 = Math.max((i2.height - s2) / 2, 0);
        break;
      case "bottom":
        n2 = Math.max(i2.height - s2, 0);
    }
    e2.fillStyle = this.zt.V;
    for (const t3 of this.zt.bc) {
      e2.save();
      let s3 = 0;
      switch (this.zt.xc) {
        case "left":
          e2.textAlign = "left", s3 = t3.gc / 2;
          break;
        case "center":
          e2.textAlign = "center", s3 = i2.width / 2;
          break;
        case "right":
          e2.textAlign = "right", s3 = i2.width - 1 - t3.gc / 2;
      }
      e2.translate(s3, n2), e2.textBaseline = "top", e2.font = t3.R, e2.scale(t3.Zu, t3.Zu), e2.fillText(t3.Kt, 0, t3.Sc), e2.restore(), n2 += t3.gc * t3.Zu;
    }
  }
  wc(t2, e2) {
    const i2 = this.kc(t2.font);
    let s2 = i2.get(e2);
    return void 0 === s2 && (s2 = t2.measureText(e2).width, i2.set(e2, s2)), s2;
  }
  kc(t2) {
    let e2 = this.mc.get(t2);
    return void 0 === e2 && (e2 = /* @__PURE__ */ new Map(), this.mc.set(t2, e2)), e2;
  }
}
class Dn {
  constructor(t2) {
    this.ft = true, this.Ft = { yt: false, V: "", bc: [], Mc: "center", xc: "center" }, this.Wt = new Rn(this.Ft), this.jt = t2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.Wt;
  }
  Mt() {
    const t2 = this.jt.W(), e2 = this.Ft;
    e2.yt = t2.visible, e2.yt && (e2.V = t2.color, e2.xc = t2.horzAlign, e2.Mc = t2.vertAlign, e2.bc = [{ Kt: t2.text, R: Tz(t2.fontSize, t2.fontFamily, t2.fontStyle), gc: 1.2 * t2.fontSize, Sc: 0, Zu: 0 }]);
  }
}
class Vn extends lt {
  constructor(t2, e2) {
    super(), this.cn = e2, this.wn = new Dn(this);
  }
  Rn() {
    return [];
  }
  Pn() {
    return [this.wn];
  }
  W() {
    return this.cn;
  }
  Vn() {
    this.wn.bt();
  }
}
var U$, Y$, G$, J$, Q$;
!function(t2) {
  t2[t2.OnTouchEnd = 0] = "OnTouchEnd", t2[t2.OnNextTap = 1] = "OnNextTap";
}(U$ || (U$ = {}));
class Ln {
  constructor(t2, e2, i2) {
    this.yc = [], this.Cc = [], this.__ = 0, this.Tc = null, this.Pc = new D(), this.Rc = new D(), this.Dc = null, this.Vc = t2, this.cn = e2, this.q_ = i2, this.Oc = new W(this), this.yl = new Tn(this, e2.timeScale, this.cn.localization, i2), this.vt = new ot(this, e2.crosshair), this.Bc = new Ji(e2.crosshair), this.Ac = new Vn(this, e2.watermark), this.Ic(), this.yc[0].x_(2e3), this.zc = this.Lc(0), this.Ec = this.Lc(1);
  }
  Kl() {
    this.Nc(ut.es());
  }
  Uh() {
    this.Nc(ut.ss());
  }
  oa() {
    this.Nc(new ut(1));
  }
  Gl(t2) {
    const e2 = this.Fc(t2);
    this.Nc(e2);
  }
  Wc() {
    return this.Tc;
  }
  jc(t2) {
    const e2 = this.Tc;
    this.Tc = t2, null !== e2 && this.Gl(e2.Hc), null !== t2 && this.Gl(t2.Hc);
  }
  W() {
    return this.cn;
  }
  $h(t2) {
    Mz(this.cn, t2), this.yc.forEach((e2) => e2.b_(t2)), void 0 !== t2.timeScale && this.yl.$h(t2.timeScale), void 0 !== t2.localization && this.yl.yu(t2.localization), (t2.leftPriceScale || t2.rightPriceScale) && this.Pc.m(), this.zc = this.Lc(0), this.Ec = this.Lc(1), this.Kl();
  }
  $c(t2, e2) {
    if ("left" === t2) return void this.$h({ leftPriceScale: e2 });
    if ("right" === t2) return void this.$h({ rightPriceScale: e2 });
    const i2 = this.Uc(t2);
    null !== i2 && (i2.Dt.$h(e2), this.Pc.m());
  }
  Uc(t2) {
    for (const e2 of this.yc) {
      const i2 = e2.w_(t2);
      if (null !== i2) return { Ht: e2, Dt: i2 };
    }
    return null;
  }
  St() {
    return this.yl;
  }
  qc() {
    return this.yc;
  }
  Yc() {
    return this.Ac;
  }
  Zc() {
    return this.vt;
  }
  Xc() {
    return this.Rc;
  }
  Kc(t2, e2) {
    t2.Lo(e2), this.Wu();
  }
  S_(t2) {
    this.__ = t2, this.yl.S_(this.__), this.yc.forEach((e2) => e2.S_(t2)), this.Wu();
  }
  Ic(t2) {
    const e2 = new gn(this.yl, this);
    void 0 !== t2 ? this.yc.splice(t2, 0, e2) : this.yc.push(e2);
    const i2 = void 0 === t2 ? this.yc.length - 1 : t2, s2 = ut.es();
    return s2.Nn(i2, { Fn: 0, Wn: true }), this.Nc(s2), e2;
  }
  V_(t2, e2, i2) {
    t2.V_(e2, i2);
  }
  O_(t2, e2, i2) {
    t2.O_(e2, i2), this.Jl(), this.Nc(this.Gc(t2, 2));
  }
  B_(t2, e2) {
    t2.B_(e2), this.Nc(this.Gc(t2, 2));
  }
  A_(t2, e2, i2) {
    e2.Vo() || t2.A_(e2, i2);
  }
  I_(t2, e2, i2) {
    e2.Vo() || (t2.I_(e2, i2), this.Jl(), this.Nc(this.Gc(t2, 2)));
  }
  z_(t2, e2) {
    e2.Vo() || (t2.z_(e2), this.Nc(this.Gc(t2, 2)));
  }
  E_(t2, e2) {
    t2.E_(e2), this.Nc(this.Gc(t2, 2));
  }
  Jc(t2) {
    this.yl.Go(t2);
  }
  Qc(t2, e2) {
    const i2 = this.St();
    if (i2.Ni() || 0 === e2) return;
    const s2 = i2.Hi();
    t2 = Math.max(1, Math.min(t2, s2)), i2.Zu(t2, e2), this.Wu();
  }
  td(t2) {
    this.nd(0), this.sd(t2), this.ed();
  }
  rd(t2) {
    this.yl.Jo(t2), this.Wu();
  }
  hd() {
    this.yl.Qo(), this.Uh();
  }
  nd(t2) {
    this.yl.t_(t2);
  }
  sd(t2) {
    this.yl.i_(t2), this.Wu();
  }
  ed() {
    this.yl.n_(), this.Uh();
  }
  wt() {
    return this.Cc;
  }
  ld(t2, e2, i2, s2, n2) {
    this.vt.gn(t2, e2);
    let r2 = NaN, o2 = this.yl.Nu(t2);
    const a2 = this.yl.Xs();
    null !== a2 && (o2 = Math.min(Math.max(a2.Os(), o2), a2.ui()));
    const l2 = s2.vn(), h2 = l2.Ct();
    null !== h2 && (r2 = l2.pn(e2, h2)), r2 = this.Bc.Oa(r2, o2, s2), this.vt.kn(o2, r2, s2), this.oa(), n2 || this.Rc.m(this.vt.xt(), { x: t2, y: e2 }, i2);
  }
  ad(t2, e2, i2) {
    const s2 = i2.vn(), n2 = s2.Ct(), r2 = s2.Rt(t2, dz(n2)), o2 = this.yl.Va(e2, true), a2 = this.yl.It(dz(o2));
    this.ld(a2, r2, null, i2, true);
  }
  od(t2) {
    this.Zc().Cn(), this.oa(), t2 || this.Rc.m(null, null, null);
  }
  Jl() {
    const t2 = this.vt.Ht();
    if (null !== t2) {
      const e2 = this.vt.xn(), i2 = this.vt.Sn();
      this.ld(e2, i2, null, t2);
    }
    this.vt.Vn();
  }
  _d(t2, e2, i2) {
    const s2 = this.yl.mn(0);
    void 0 !== e2 && void 0 !== i2 && this.yl.bt(e2, i2);
    const n2 = this.yl.mn(0), r2 = this.yl.Eu(), o2 = this.yl.Xs();
    if (null !== o2 && null !== s2 && null !== n2) {
      const e3 = o2.Kr(r2), a2 = this.q_.key(s2) > this.q_.key(n2), l2 = null !== t2 && t2 > r2 && !a2, h2 = this.yl.W().allowShiftVisibleRangeOnWhitespaceReplacement, c2 = e3 && (!(void 0 === i2) || h2) && this.yl.W().shiftVisibleRangeOnNewBar;
      if (l2 && !c2) {
        const e4 = t2 - r2;
        this.yl.Jn(this.yl.Hu() - e4);
      }
    }
    this.yl.Yu(t2);
  }
  ia(t2) {
    null !== t2 && t2.F_();
  }
  dr(t2) {
    const e2 = this.yc.find((e3) => e3.Uo().includes(t2));
    return void 0 === e2 ? null : e2;
  }
  Wu() {
    this.Ac.Vn(), this.yc.forEach((t2) => t2.F_()), this.Jl();
  }
  S() {
    this.yc.forEach((t2) => t2.S()), this.yc.length = 0, this.cn.localization.priceFormatter = void 0, this.cn.localization.percentageFormatter = void 0, this.cn.localization.timeFormatter = void 0;
  }
  ud() {
    return this.Oc;
  }
  br() {
    return this.Oc.W();
  }
  g_() {
    return this.Pc;
  }
  dd(t2, e2, i2) {
    const s2 = this.yc[0], n2 = this.fd(e2, t2, s2, i2);
    return this.Cc.push(n2), 1 === this.Cc.length ? this.Kl() : this.Uh(), n2;
  }
  vd(t2) {
    const e2 = this.dr(t2), i2 = this.Cc.indexOf(t2);
    cz(-1 !== i2, "Series not found"), this.Cc.splice(i2, 1), dz(e2).Zo(t2), t2.S && t2.S();
  }
  Xl(t2, e2) {
    const i2 = dz(this.dr(t2));
    i2.Zo(t2);
    const s2 = this.Uc(e2);
    if (null === s2) {
      const s3 = t2.Xi();
      i2.qo(t2, e2, s3);
    } else {
      const n2 = s2.Ht === i2 ? t2.Xi() : void 0;
      s2.Ht.qo(t2, e2, n2);
    }
  }
  hc() {
    const t2 = ut.ss();
    t2.$n(), this.Nc(t2);
  }
  pd(t2) {
    const e2 = ut.ss();
    e2.Yn(t2), this.Nc(e2);
  }
  Kn() {
    const t2 = ut.ss();
    t2.Kn(), this.Nc(t2);
  }
  Gn(t2) {
    const e2 = ut.ss();
    e2.Gn(t2), this.Nc(e2);
  }
  Jn(t2) {
    const e2 = ut.ss();
    e2.Jn(t2), this.Nc(e2);
  }
  Zn(t2) {
    const e2 = ut.ss();
    e2.Zn(t2), this.Nc(e2);
  }
  Un() {
    const t2 = ut.ss();
    t2.Un(), this.Nc(t2);
  }
  md() {
    return this.cn.rightPriceScale.visible ? "right" : "left";
  }
  bd() {
    return this.Ec;
  }
  q() {
    return this.zc;
  }
  Bt(t2) {
    const e2 = this.Ec, i2 = this.zc;
    if (e2 === i2) return e2;
    if (t2 = Math.max(0, Math.min(100, Math.round(100 * t2))), null === this.Dc || this.Dc.Ps !== i2 || this.Dc.Rs !== e2) this.Dc = { Ps: i2, Rs: e2, wd: /* @__PURE__ */ new Map() };
    else {
      const e3 = this.Dc.wd.get(t2);
      if (void 0 !== e3) return e3;
    }
    const s2 = function(t3, e3, i3) {
      const [s3, n2, r2, o2] = xz(t3), [a2, l2, h2, c2] = xz(e3), u2 = [mz(s3 + i3 * (a2 - s3)), mz(n2 + i3 * (l2 - n2)), mz(r2 + i3 * (h2 - r2)), gz(o2 + i3 * (c2 - o2))];
      return `rgba(${u2[0]}, ${u2[1]}, ${u2[2]}, ${u2[3]})`;
    }(i2, e2, t2 / 100);
    return this.Dc.wd.set(t2, s2), s2;
  }
  Gc(t2, e2) {
    const i2 = new ut(e2);
    if (null !== t2) {
      const s2 = this.yc.indexOf(t2);
      i2.Nn(s2, { Fn: e2 });
    }
    return i2;
  }
  Fc(t2, e2) {
    return void 0 === e2 && (e2 = 2), this.Gc(this.dr(t2), e2);
  }
  Nc(t2) {
    this.Vc && this.Vc(t2), this.yc.forEach((t3) => t3.j_().qh().bt());
  }
  fd(t2, e2, i2, s2) {
    const n2 = new Gi(this, t2, e2, i2, s2), r2 = void 0 !== t2.priceScaleId ? t2.priceScaleId : this.md();
    return i2.qo(n2, r2), jz(r2) || n2.$h(t2), n2;
  }
  Lc(t2) {
    const e2 = this.cn.layout;
    return "gradient" === e2.background.type ? 0 === t2 ? e2.background.topColor : e2.background.bottomColor : e2.background.color;
  }
}
function Z$(t2) {
  return !Sz(t2) && !zz(t2);
}
function tD(t2) {
  return Sz(t2);
}
!function(t2) {
  t2[t2.Disabled = 0] = "Disabled", t2[t2.Continuous = 1] = "Continuous", t2[t2.OnDataUpdate = 2] = "OnDataUpdate";
}(Y$ || (Y$ = {})), function(t2) {
  t2[t2.LastBar = 0] = "LastBar", t2[t2.LastVisible = 1] = "LastVisible";
}(G$ || (G$ = {})), function(t2) {
  t2.Solid = "solid", t2.VerticalGradient = "gradient";
}(J$ || (J$ = {})), function(t2) {
  t2[t2.Year = 0] = "Year", t2[t2.Month = 1] = "Month", t2[t2.DayOfMonth = 2] = "DayOfMonth", t2[t2.Time = 3] = "Time", t2[t2.TimeWithSeconds = 4] = "TimeWithSeconds";
}(Q$ || (Q$ = {}));
const eD = (t2) => t2.getUTCFullYear();
class jn {
  constructor(t2 = "yyyy-MM-dd", e2 = "default") {
    this.gd = t2, this.Md = e2;
  }
  Y_(t2) {
    return function(t3, e2, i2) {
      return e2.replace(/yyyy/g, ((t4) => Hz(eD(t4), 4))(t3)).replace(/yy/g, ((t4) => Hz(eD(t4) % 100, 2))(t3)).replace(/MMMM/g, ((t4, e3) => new Date(t4.getUTCFullYear(), t4.getUTCMonth(), 1).toLocaleString(e3, { month: "long" }))(t3, i2)).replace(/MMM/g, ((t4, e3) => new Date(t4.getUTCFullYear(), t4.getUTCMonth(), 1).toLocaleString(e3, { month: "short" }))(t3, i2)).replace(/MM/g, ((t4) => Hz(((t5) => t5.getUTCMonth() + 1)(t4), 2))(t3)).replace(/dd/g, ((t4) => Hz(((t5) => t5.getUTCDate())(t4), 2))(t3));
    }(t2, this.gd, this.Md);
  }
}
class Hn {
  constructor(t2) {
    this.xd = t2 || "%h:%m:%s";
  }
  Y_(t2) {
    return this.xd.replace("%h", Hz(t2.getUTCHours(), 2)).replace("%m", Hz(t2.getUTCMinutes(), 2)).replace("%s", Hz(t2.getUTCSeconds(), 2));
  }
}
const iD = { Sd: "yyyy-MM-dd", kd: "%h:%m:%s", yd: " ", Cd: "default" };
class Un {
  constructor(t2 = {}) {
    const e2 = Object.assign(Object.assign({}, iD), t2);
    this.Td = new jn(e2.Sd, e2.Cd), this.Pd = new Hn(e2.kd), this.Rd = e2.yd;
  }
  Y_(t2) {
    return `${this.Td.Y_(t2)}${this.Rd}${this.Pd.Y_(t2)}`;
  }
}
function sD(t2) {
  return 60 * t2 * 60 * 1e3;
}
function nD(t2) {
  return 60 * t2 * 1e3;
}
const rD = [{ Dd: 1e3, Vd: 10 }, { Dd: nD(1), Vd: 20 }, { Dd: nD(5), Vd: 21 }, { Dd: nD(30), Vd: 22 }, { Dd: sD(1), Vd: 30 }, { Dd: sD(3), Vd: 31 }, { Dd: sD(6), Vd: 32 }, { Dd: sD(12), Vd: 33 }];
function oD(t2, e2) {
  if (t2.getUTCFullYear() !== e2.getUTCFullYear()) return 70;
  if (t2.getUTCMonth() !== e2.getUTCMonth()) return 60;
  if (t2.getUTCDate() !== e2.getUTCDate()) return 50;
  for (let i2 = rD.length - 1; i2 >= 0; --i2) if (Math.floor(e2.getTime() / rD[i2].Dd) !== Math.floor(t2.getTime() / rD[i2].Dd)) return rD[i2].Vd;
  return 0;
}
function aD(t2) {
  let e2 = t2;
  if (zz(t2) && (e2 = hD(t2)), !Z$(e2)) throw new Error("time must be of type BusinessDay");
  const i2 = new Date(Date.UTC(e2.year, e2.month - 1, e2.day, 0, 0, 0, 0));
  return { Od: Math.round(i2.getTime() / 1e3), Bd: e2 };
}
function lD(t2) {
  if (!tD(t2)) throw new Error("time must be of type isUTCTimestamp");
  return { Od: t2 };
}
function hD(t2) {
  const e2 = new Date(t2);
  if (isNaN(e2.getTime())) throw new Error(`Invalid date string=${t2}, expected format=yyyy-mm-dd`);
  return { day: e2.getUTCDate(), month: e2.getUTCMonth() + 1, year: e2.getUTCFullYear() };
}
function cD(t2) {
  zz(t2.time) && (t2.time = hD(t2.time));
}
class is {
  options() {
    return this.cn;
  }
  setOptions(t2) {
    this.cn = t2, this.updateFormatter(t2.localization);
  }
  preprocessData(t2) {
    Array.isArray(t2) ? function(t3) {
      t3.forEach(cD);
    }(t2) : cD(t2);
  }
  createConverterToInternalObj(t2) {
    return dz(function(t3) {
      return 0 === t3.length ? null : Z$(t3[0].time) || zz(t3[0].time) ? aD : lD;
    }(t2));
  }
  key(t2) {
    return "object" == typeof t2 && "Od" in t2 ? t2.Od : this.key(this.convertHorzItemToInternal(t2));
  }
  cacheKey(t2) {
    const e2 = t2;
    return void 0 === e2.Bd ? new Date(1e3 * e2.Od).getTime() : new Date(Date.UTC(e2.Bd.year, e2.Bd.month - 1, e2.Bd.day)).getTime();
  }
  convertHorzItemToInternal(t2) {
    return tD(e2 = t2) ? lD(e2) : Z$(e2) ? aD(e2) : aD(hD(e2));
    var e2;
  }
  updateFormatter(t2) {
    if (!this.cn) return;
    const e2 = t2.dateFormat;
    this.cn.timeScale.timeVisible ? this.Ad = new Un({ Sd: e2, kd: this.cn.timeScale.secondsVisible ? "%h:%m:%s" : "%h:%m", yd: "   ", Cd: t2.locale }) : this.Ad = new jn(e2, t2.locale);
  }
  formatHorzItem(t2) {
    const e2 = t2;
    return this.Ad.Y_(new Date(1e3 * e2.Od));
  }
  formatTickmark(t2, e2) {
    const i2 = function(t3, e3, i3) {
      switch (t3) {
        case 0:
        case 10:
          return e3 ? i3 ? 4 : 3 : 2;
        case 20:
        case 21:
        case 22:
        case 30:
        case 31:
        case 32:
        case 33:
          return e3 ? 3 : 2;
        case 50:
          return 2;
        case 60:
          return 1;
        case 70:
          return 0;
      }
    }(t2.weight, this.cn.timeScale.timeVisible, this.cn.timeScale.secondsVisible), s2 = this.cn.timeScale;
    if (void 0 !== s2.tickMarkFormatter) {
      const n2 = s2.tickMarkFormatter(t2.originalTime, i2, e2.locale);
      if (null !== n2) return n2;
    }
    return function(t3, e3, i3) {
      const s3 = {};
      switch (e3) {
        case 0:
          s3.year = "numeric";
          break;
        case 1:
          s3.month = "short";
          break;
        case 2:
          s3.day = "numeric";
          break;
        case 3:
          s3.hour12 = false, s3.hour = "2-digit", s3.minute = "2-digit";
          break;
        case 4:
          s3.hour12 = false, s3.hour = "2-digit", s3.minute = "2-digit", s3.second = "2-digit";
      }
      const n2 = void 0 === t3.Bd ? new Date(1e3 * t3.Od) : new Date(Date.UTC(t3.Bd.year, t3.Bd.month - 1, t3.Bd.day));
      return new Date(n2.getUTCFullYear(), n2.getUTCMonth(), n2.getUTCDate(), n2.getUTCHours(), n2.getUTCMinutes(), n2.getUTCSeconds(), n2.getUTCMilliseconds()).toLocaleString(i3, s3);
    }(t2.time, i2, e2.locale);
  }
  maxTickMarkWeight(t2) {
    let e2 = t2.reduce(K$, t2[0]).weight;
    return e2 > 30 && e2 < 50 && (e2 = 30), e2;
  }
  fillWeightsForPoints(t2, e2) {
    !function(t3, e3 = 0) {
      if (0 === t3.length) return;
      let i2 = 0 === e3 ? null : t3[e3 - 1].time.Od, s2 = null !== i2 ? new Date(1e3 * i2) : null, n2 = 0;
      for (let r2 = e3; r2 < t3.length; ++r2) {
        const e4 = t3[r2], o2 = new Date(1e3 * e4.time.Od);
        null !== s2 && (e4.timeWeight = oD(o2, s2)), n2 += e4.time.Od - (i2 || e4.time.Od), i2 = e4.time.Od, s2 = o2;
      }
      if (0 === e3 && t3.length > 1) {
        const e4 = Math.ceil(n2 / (t3.length - 1)), i3 = new Date(1e3 * (t3[0].time.Od - e4));
        t3[0].timeWeight = oD(new Date(1e3 * t3[0].time.Od), i3);
      }
    }(t2, e2);
  }
  static Id(t2) {
    return Mz({ localization: { dateFormat: "dd MMM 'yy" } }, null != t2 ? t2 : {});
  }
}
const uD = "undefined" != typeof window;
function dD() {
  return !!uD && window.navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
}
function fD() {
  return !!uD && /iPhone|iPad|iPod/.test(window.navigator.platform);
}
function pD(t2) {
  return t2 + t2 % 2;
}
function mD(t2, e2) {
  return t2.zd - e2.zd;
}
function gD(t2, e2, i2) {
  const s2 = (t2.zd - e2.zd) / (t2.ot - e2.ot);
  return Math.sign(s2) * Math.min(Math.abs(s2), i2);
}
class as {
  constructor(t2, e2, i2, s2) {
    this.Ld = null, this.Ed = null, this.Nd = null, this.Fd = null, this.Wd = null, this.jd = 0, this.Hd = 0, this.$d = t2, this.Ud = e2, this.qd = i2, this.rs = s2;
  }
  Yd(t2, e2) {
    if (null !== this.Ld) {
      if (this.Ld.ot === e2) return void (this.Ld.zd = t2);
      if (Math.abs(this.Ld.zd - t2) < this.rs) return;
    }
    this.Fd = this.Nd, this.Nd = this.Ed, this.Ed = this.Ld, this.Ld = { ot: e2, zd: t2 };
  }
  Vr(t2, e2) {
    if (null === this.Ld || null === this.Ed) return;
    if (e2 - this.Ld.ot > 50) return;
    let i2 = 0;
    const s2 = gD(this.Ld, this.Ed, this.Ud), n2 = mD(this.Ld, this.Ed), r2 = [s2], o2 = [n2];
    if (i2 += n2, null !== this.Nd) {
      const t3 = gD(this.Ed, this.Nd, this.Ud);
      if (Math.sign(t3) === Math.sign(s2)) {
        const e3 = mD(this.Ed, this.Nd);
        if (r2.push(t3), o2.push(e3), i2 += e3, null !== this.Fd) {
          const t4 = gD(this.Nd, this.Fd, this.Ud);
          if (Math.sign(t4) === Math.sign(s2)) {
            const e4 = mD(this.Nd, this.Fd);
            r2.push(t4), o2.push(e4), i2 += e4;
          }
        }
      }
    }
    let a2 = 0;
    for (let t3 = 0; t3 < r2.length; ++t3) a2 += o2[t3] / i2 * r2[t3];
    Math.abs(a2) < this.$d || (this.Wd = { zd: t2, ot: e2 }, this.Hd = a2, this.jd = function(t3, e3) {
      const i3 = Math.log(e3);
      return Math.log(1 * i3 / -t3) / i3;
    }(Math.abs(a2), this.qd));
  }
  tc(t2) {
    const e2 = dz(this.Wd), i2 = t2 - e2.ot;
    return e2.zd + this.Hd * (Math.pow(this.qd, i2) - 1) / Math.log(this.qd);
  }
  Qu(t2) {
    return null === this.Wd || this.Zd(t2) === this.jd;
  }
  Zd(t2) {
    const e2 = t2 - dz(this.Wd).ot;
    return Math.min(e2, this.jd);
  }
}
class os {
  constructor(t2, e2) {
    this.Xd = void 0, this.Kd = void 0, this.Gd = void 0, this.en = false, this.Jd = t2, this.Qd = e2, this.tf();
  }
  bt() {
    this.tf();
  }
  if() {
    this.Xd && this.Jd.removeChild(this.Xd), this.Kd && this.Jd.removeChild(this.Kd), this.Xd = void 0, this.Kd = void 0;
  }
  nf() {
    return this.en !== this.sf() || this.Gd !== this.ef();
  }
  ef() {
    return wz(xz(this.Qd.W().layout.textColor)) > 160 ? "dark" : "light";
  }
  sf() {
    return this.Qd.W().layout.attributionLogo;
  }
  rf() {
    const t2 = new URL(location.href);
    return t2.hostname ? "&utm_source=" + t2.hostname + t2.pathname : "";
  }
  tf() {
    this.nf() && (this.if(), this.en = this.sf(), this.en && (this.Gd = this.ef(), this.Kd = document.createElement("style"), this.Kd.innerText = "a#tv-attr-logo{--fill:#131722;--stroke:#fff;position:absolute;left:10px;bottom:10px;height:19px;width:35px;margin:0;padding:0;border:0;z-index:3;}a#tv-attr-logo[data-dark]{--fill:#D1D4DC;--stroke:#131722;}", this.Xd = document.createElement("a"), this.Xd.href = `https://www.tradingview.com/?utm_medium=lwc-link&utm_campaign=lwc-chart${this.rf()}`, this.Xd.title = "Charting by TradingView", this.Xd.id = "tv-attr-logo", this.Xd.target = "_blank", this.Xd.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 19" width="35" height="19" fill="none"><g fill-rule="evenodd" clip-path="url(#a)" clip-rule="evenodd"><path fill="var(--stroke)" d="M2 0H0v10h6v9h21.4l.5-1.3 6-15 1-2.7H23.7l-.5 1.3-.2.6a5 5 0 0 0-7-.9V0H2Zm20 17h4l5.2-13 .8-2h-7l-1 2.5-.2.5-1.5 3.8-.3.7V17Zm-.8-10a3 3 0 0 0 .7-2.7A3 3 0 1 0 16.8 7h4.4ZM14 7V2H2v6h6v9h4V7h2Z"/><path fill="var(--fill)" d="M14 2H2v6h6v9h6V2Zm12 15h-7l6-15h7l-6 15Zm-7-9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></g><defs><clipPath id="a"><path fill="var(--stroke)" d="M0 0h35v19H0z"/></clipPath></defs></svg>', this.Xd.toggleAttribute("data-dark", "dark" === this.Gd), this.Jd.appendChild(this.Kd), this.Jd.appendChild(this.Xd)));
  }
}
function vD(t2, e2) {
  const i2 = dz(t2.ownerDocument).createElement("canvas");
  t2.appendChild(i2);
  const s2 = (n2 = { options: { allowResizeObserver: false }, transform: (t3, e3) => ({ width: Math.max(t3.width, e3.width), height: Math.max(t3.height, e3.height) }) }, new KC(i2, n2.transform, n2.options));
  var n2;
  return s2.resizeCanvasElement(e2), s2;
}
function bD(t2) {
  var e2;
  t2.width = 1, t2.height = 1, null === (e2 = t2.getContext("2d")) || void 0 === e2 || e2.clearRect(0, 0, 1, 1);
}
function _D(t2, e2, i2, s2) {
  t2.gl && t2.gl(e2, i2, s2);
}
function yD(t2, e2, i2, s2) {
  t2.X(e2, i2, s2);
}
function xD(t2, e2, i2, s2) {
  const n2 = t2(i2, s2);
  for (const t3 of n2) {
    const i3 = t3.gt();
    null !== i3 && e2(i3);
  }
}
class ps {
  constructor(t2, e2, i2) {
    this.hf = 0, this.lf = null, this.af = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY }, this._f = 0, this.uf = null, this.cf = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY }, this.df = null, this.ff = false, this.vf = null, this.pf = null, this.mf = false, this.bf = false, this.wf = false, this.gf = null, this.Mf = null, this.xf = null, this.Sf = null, this.kf = null, this.yf = null, this.Cf = null, this.Tf = 0, this.Pf = false, this.Rf = false, this.Df = false, this.Vf = 0, this.Of = null, this.Bf = !fD(), this.Af = (t3) => {
      this.If(t3);
    }, this.zf = (t3) => {
      if (this.Lf(t3)) {
        const e3 = this.Ef(t3);
        if (++this._f, this.uf && this._f > 1) {
          const { Nf: i3 } = this.Ff(MD(t3), this.cf);
          i3 < 30 && !this.wf && this.Wf(e3, this.Hf.jf), this.$f();
        }
      } else {
        const e3 = this.Ef(t3);
        if (++this.hf, this.lf && this.hf > 1) {
          const { Nf: i3 } = this.Ff(MD(t3), this.af);
          i3 < 5 && !this.bf && this.Uf(e3, this.Hf.qf), this.Yf();
        }
      }
    }, this.Zf = t2, this.Hf = e2, this.cn = i2, this.Xf();
  }
  S() {
    null !== this.gf && (this.gf(), this.gf = null), null !== this.Mf && (this.Mf(), this.Mf = null), null !== this.Sf && (this.Sf(), this.Sf = null), null !== this.kf && (this.kf(), this.kf = null), null !== this.yf && (this.yf(), this.yf = null), null !== this.xf && (this.xf(), this.xf = null), this.Kf(), this.Yf();
  }
  Gf(t2) {
    this.Sf && this.Sf();
    const e2 = this.Jf.bind(this);
    if (this.Sf = () => {
      this.Zf.removeEventListener("mousemove", e2);
    }, this.Zf.addEventListener("mousemove", e2), this.Lf(t2)) return;
    const i2 = this.Ef(t2);
    this.Uf(i2, this.Hf.Qf), this.Bf = true;
  }
  Yf() {
    null !== this.lf && clearTimeout(this.lf), this.hf = 0, this.lf = null, this.af = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY };
  }
  $f() {
    null !== this.uf && clearTimeout(this.uf), this._f = 0, this.uf = null, this.cf = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY };
  }
  Jf(t2) {
    if (this.Df || null !== this.pf) return;
    if (this.Lf(t2)) return;
    const e2 = this.Ef(t2);
    this.Uf(e2, this.Hf.tv), this.Bf = true;
  }
  iv(t2) {
    const e2 = CD(t2.changedTouches, dz(this.Of));
    if (null === e2) return;
    if (this.Vf = SD(t2), null !== this.Cf) return;
    if (this.Rf) return;
    this.Pf = true;
    const i2 = this.Ff(MD(e2), dz(this.pf)), { nv: s2, sv: n2, Nf: r2 } = i2;
    if (this.mf || !(r2 < 5)) {
      if (!this.mf) {
        const t3 = 0.5 * s2, e3 = n2 >= t3 && !this.cn.ev(), i3 = t3 > n2 && !this.cn.rv();
        e3 || i3 || (this.Rf = true), this.mf = true, this.wf = true, this.Kf(), this.$f();
      }
      if (!this.Rf) {
        const i3 = this.Ef(t2, e2);
        this.Wf(i3, this.Hf.hv), kD(t2);
      }
    }
  }
  lv(t2) {
    if (0 !== t2.button) return;
    const e2 = this.Ff(MD(t2), dz(this.vf)), { Nf: i2 } = e2;
    if (i2 >= 5 && (this.bf = true, this.Yf()), this.bf) {
      const e3 = this.Ef(t2);
      this.Uf(e3, this.Hf.av);
    }
  }
  Ff(t2, e2) {
    const i2 = Math.abs(e2.nt - t2.nt), s2 = Math.abs(e2.st - t2.st);
    return { nv: i2, sv: s2, Nf: i2 + s2 };
  }
  ov(t2) {
    let e2 = CD(t2.changedTouches, dz(this.Of));
    if (null === e2 && 0 === t2.touches.length && (e2 = t2.changedTouches[0]), null === e2) return;
    this.Of = null, this.Vf = SD(t2), this.Kf(), this.pf = null, this.yf && (this.yf(), this.yf = null);
    const i2 = this.Ef(t2, e2);
    if (this.Wf(i2, this.Hf._v), ++this._f, this.uf && this._f > 1) {
      const { Nf: t3 } = this.Ff(MD(e2), this.cf);
      t3 < 30 && !this.wf && this.Wf(i2, this.Hf.jf), this.$f();
    } else this.wf || (this.Wf(i2, this.Hf.uv), this.Hf.uv && kD(t2));
    0 === this._f && kD(t2), 0 === t2.touches.length && this.ff && (this.ff = false, kD(t2));
  }
  If(t2) {
    if (0 !== t2.button) return;
    const e2 = this.Ef(t2);
    if (this.vf = null, this.Df = false, this.kf && (this.kf(), this.kf = null), dD() && this.Zf.ownerDocument.documentElement.removeEventListener("mouseleave", this.Af), !this.Lf(t2)) if (this.Uf(e2, this.Hf.cv), ++this.hf, this.lf && this.hf > 1) {
      const { Nf: i2 } = this.Ff(MD(t2), this.af);
      i2 < 5 && !this.bf && this.Uf(e2, this.Hf.qf), this.Yf();
    } else this.bf || this.Uf(e2, this.Hf.dv);
  }
  Kf() {
    null !== this.df && (clearTimeout(this.df), this.df = null);
  }
  fv(t2) {
    if (null !== this.Of) return;
    const e2 = t2.changedTouches[0];
    this.Of = e2.identifier, this.Vf = SD(t2);
    const i2 = this.Zf.ownerDocument.documentElement;
    this.wf = false, this.mf = false, this.Rf = false, this.pf = MD(e2), this.yf && (this.yf(), this.yf = null);
    {
      const e3 = this.iv.bind(this), s3 = this.ov.bind(this);
      this.yf = () => {
        i2.removeEventListener("touchmove", e3), i2.removeEventListener("touchend", s3);
      }, i2.addEventListener("touchmove", e3, { passive: false }), i2.addEventListener("touchend", s3, { passive: false }), this.Kf(), this.df = setTimeout(this.vv.bind(this, t2), 240);
    }
    const s2 = this.Ef(t2, e2);
    this.Wf(s2, this.Hf.pv), this.uf || (this._f = 0, this.uf = setTimeout(this.$f.bind(this), 500), this.cf = MD(e2));
  }
  mv(t2) {
    if (0 !== t2.button) return;
    const e2 = this.Zf.ownerDocument.documentElement;
    dD() && e2.addEventListener("mouseleave", this.Af), this.bf = false, this.vf = MD(t2), this.kf && (this.kf(), this.kf = null);
    {
      const t3 = this.lv.bind(this), i3 = this.If.bind(this);
      this.kf = () => {
        e2.removeEventListener("mousemove", t3), e2.removeEventListener("mouseup", i3);
      }, e2.addEventListener("mousemove", t3), e2.addEventListener("mouseup", i3);
    }
    if (this.Df = true, this.Lf(t2)) return;
    const i2 = this.Ef(t2);
    this.Uf(i2, this.Hf.bv), this.lf || (this.hf = 0, this.lf = setTimeout(this.Yf.bind(this), 500), this.af = MD(t2));
  }
  Xf() {
    this.Zf.addEventListener("mouseenter", this.Gf.bind(this)), this.Zf.addEventListener("touchcancel", this.Kf.bind(this));
    {
      const t2 = this.Zf.ownerDocument, e2 = (t3) => {
        this.Hf.wv && (t3.composed && this.Zf.contains(t3.composedPath()[0]) || t3.target && this.Zf.contains(t3.target) || this.Hf.wv());
      };
      this.Mf = () => {
        t2.removeEventListener("touchstart", e2);
      }, this.gf = () => {
        t2.removeEventListener("mousedown", e2);
      }, t2.addEventListener("mousedown", e2), t2.addEventListener("touchstart", e2, { passive: true });
    }
    fD() && (this.xf = () => {
      this.Zf.removeEventListener("dblclick", this.zf);
    }, this.Zf.addEventListener("dblclick", this.zf)), this.Zf.addEventListener("mouseleave", this.gv.bind(this)), this.Zf.addEventListener("touchstart", this.fv.bind(this), { passive: true }), function(t2) {
      uD && void 0 !== window.chrome && t2.addEventListener("mousedown", (t3) => {
        if (1 === t3.button) return t3.preventDefault(), false;
      });
    }(this.Zf), this.Zf.addEventListener("mousedown", this.mv.bind(this)), this.Mv(), this.Zf.addEventListener("touchmove", () => {
    }, { passive: false });
  }
  Mv() {
    void 0 === this.Hf.xv && void 0 === this.Hf.Sv && void 0 === this.Hf.kv || (this.Zf.addEventListener("touchstart", (t2) => this.yv(t2.touches), { passive: true }), this.Zf.addEventListener("touchmove", (t2) => {
      if (2 === t2.touches.length && null !== this.Cf && void 0 !== this.Hf.Sv) {
        const e2 = wD(t2.touches[0], t2.touches[1]) / this.Tf;
        this.Hf.Sv(this.Cf, e2), kD(t2);
      }
    }, { passive: false }), this.Zf.addEventListener("touchend", (t2) => {
      this.yv(t2.touches);
    }));
  }
  yv(t2) {
    1 === t2.length && (this.Pf = false), 2 !== t2.length || this.Pf || this.ff ? this.Cv() : this.Tv(t2);
  }
  Tv(t2) {
    const e2 = this.Zf.getBoundingClientRect() || { left: 0, top: 0 };
    this.Cf = { nt: (t2[0].clientX - e2.left + (t2[1].clientX - e2.left)) / 2, st: (t2[0].clientY - e2.top + (t2[1].clientY - e2.top)) / 2 }, this.Tf = wD(t2[0], t2[1]), void 0 !== this.Hf.xv && this.Hf.xv(), this.Kf();
  }
  Cv() {
    null !== this.Cf && (this.Cf = null, void 0 !== this.Hf.kv && this.Hf.kv());
  }
  gv(t2) {
    if (this.Sf && this.Sf(), this.Lf(t2)) return;
    if (!this.Bf) return;
    const e2 = this.Ef(t2);
    this.Uf(e2, this.Hf.Pv), this.Bf = !fD();
  }
  vv(t2) {
    const e2 = CD(t2.touches, dz(this.Of));
    if (null === e2) return;
    const i2 = this.Ef(t2, e2);
    this.Wf(i2, this.Hf.Rv), this.wf = true, this.ff = true;
  }
  Lf(t2) {
    return t2.sourceCapabilities && void 0 !== t2.sourceCapabilities.firesTouchEvents ? t2.sourceCapabilities.firesTouchEvents : SD(t2) < this.Vf + 500;
  }
  Wf(t2, e2) {
    e2 && e2.call(this.Hf, t2);
  }
  Uf(t2, e2) {
    e2 && e2.call(this.Hf, t2);
  }
  Ef(t2, e2) {
    const i2 = e2 || t2, s2 = this.Zf.getBoundingClientRect() || { left: 0, top: 0 };
    return { clientX: i2.clientX, clientY: i2.clientY, pageX: i2.pageX, pageY: i2.pageY, screenX: i2.screenX, screenY: i2.screenY, localX: i2.clientX - s2.left, localY: i2.clientY - s2.top, ctrlKey: t2.ctrlKey, altKey: t2.altKey, shiftKey: t2.shiftKey, metaKey: t2.metaKey, Dv: !t2.type.startsWith("mouse") && "contextmenu" !== t2.type && "click" !== t2.type, Vv: t2.type, Ov: i2.target, Bv: t2.view, Av: () => {
      "touchstart" !== t2.type && kD(t2);
    } };
  }
}
function wD(t2, e2) {
  const i2 = t2.clientX - e2.clientX, s2 = t2.clientY - e2.clientY;
  return Math.sqrt(i2 * i2 + s2 * s2);
}
function kD(t2) {
  t2.cancelable && t2.preventDefault();
}
function MD(t2) {
  return { nt: t2.pageX, st: t2.pageY };
}
function SD(t2) {
  return t2.timeStamp || performance.now();
}
function CD(t2, e2) {
  for (let i2 = 0; i2 < t2.length; ++i2) if (t2[i2].identifier === e2) return t2[i2];
  return null;
}
function zD(t2) {
  return { Hc: t2.Hc, Iv: { gr: t2.zv.externalId }, Lv: t2.zv.cursorStyle };
}
function $D(t2, e2, i2) {
  for (const s2 of t2) {
    const t3 = s2.gt();
    if (null !== t3 && t3.wr) {
      const n2 = t3.wr(e2, i2);
      if (null !== n2) return { Bv: s2, Iv: n2 };
    }
  }
  return null;
}
function DD(t2, e2) {
  return (i2) => {
    var s2, n2, r2, o2;
    return (null !== (n2 = null === (s2 = i2.Dt()) || void 0 === s2 ? void 0 : s2.Pa()) && void 0 !== n2 ? n2 : "") !== e2 ? [] : null !== (o2 = null === (r2 = i2.da) || void 0 === r2 ? void 0 : r2.call(i2, t2)) && void 0 !== o2 ? o2 : [];
  };
}
function RD(t2, e2, i2, s2) {
  if (!t2.length) return;
  let n2 = 0;
  const r2 = i2 / 2, o2 = t2[0].At(s2, true);
  let a2 = 1 === e2 ? r2 - (t2[0].Vi() - o2 / 2) : t2[0].Vi() - o2 / 2 - r2;
  a2 = Math.max(0, a2);
  for (let r3 = 1; r3 < t2.length; r3++) {
    const o3 = t2[r3], l2 = t2[r3 - 1], h2 = l2.At(s2, false), c2 = o3.Vi(), u2 = l2.Vi();
    if (1 === e2 ? c2 > u2 - h2 : c2 < u2 + h2) {
      const s3 = u2 - h2 * e2;
      o3.Oi(s3);
      const r4 = s3 - e2 * h2 / 2;
      if ((1 === e2 ? r4 < 0 : r4 > i2) && a2 > 0) {
        const s4 = 1 === e2 ? -1 - r4 : r4 - i2, o4 = Math.min(s4, a2);
        for (let i3 = n2; i3 < t2.length; i3++) t2[i3].Oi(t2[i3].Vi() + e2 * o4);
        a2 -= o4;
      }
    } else n2 = r3, a2 = 1 === e2 ? u2 - h2 - c2 : c2 - (u2 + h2);
  }
}
class Cs {
  constructor(t2, e2, i2, s2) {
    this.Li = null, this.Ev = null, this.Nv = false, this.Fv = new ni(200), this.Qr = null, this.Wv = 0, this.jv = false, this.Hv = () => {
      this.jv || this.tn.$v().$t().Uh();
    }, this.Uv = () => {
      this.jv || this.tn.$v().$t().Uh();
    }, this.tn = t2, this.cn = e2, this.ko = e2.layout, this.Oc = i2, this.qv = "left" === s2, this.Yv = DD("normal", s2), this.Zv = DD("top", s2), this.Xv = DD("bottom", s2), this.Kv = document.createElement("div"), this.Kv.style.height = "100%", this.Kv.style.overflow = "hidden", this.Kv.style.width = "25px", this.Kv.style.left = "0", this.Kv.style.position = "relative", this.Gv = vD(this.Kv, HC({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
    const n2 = this.Gv.canvasElement;
    n2.style.position = "absolute", n2.style.zIndex = "1", n2.style.left = "0", n2.style.top = "0", this.Jv = vD(this.Kv, HC({ width: 16, height: 16 })), this.Jv.subscribeSuggestedBitmapSizeChanged(this.Uv);
    const r2 = this.Jv.canvasElement;
    r2.style.position = "absolute", r2.style.zIndex = "2", r2.style.left = "0", r2.style.top = "0";
    const o2 = { bv: this.Qv.bind(this), pv: this.Qv.bind(this), av: this.tp.bind(this), hv: this.tp.bind(this), wv: this.ip.bind(this), cv: this.np.bind(this), _v: this.np.bind(this), qf: this.sp.bind(this), jf: this.sp.bind(this), Qf: this.ep.bind(this), Pv: this.rp.bind(this) };
    this.hp = new ps(this.Jv.canvasElement, o2, { ev: () => !this.cn.handleScroll.vertTouchDrag, rv: () => true });
  }
  S() {
    this.hp.S(), this.Jv.unsubscribeSuggestedBitmapSizeChanged(this.Uv), bD(this.Jv.canvasElement), this.Jv.dispose(), this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), bD(this.Gv.canvasElement), this.Gv.dispose(), null !== this.Li && this.Li.Ko().p(this), this.Li = null;
  }
  lp() {
    return this.Kv;
  }
  P() {
    return this.ko.fontSize;
  }
  ap() {
    const t2 = this.Oc.W();
    return this.Qr !== t2.R && (this.Fv.nr(), this.Qr = t2.R), t2;
  }
  op() {
    if (null === this.Li) return 0;
    let t2 = 0;
    const e2 = this.ap(), i2 = dz(this.Gv.canvasElement.getContext("2d"));
    i2.save();
    const s2 = this.Li.Ha();
    i2.font = this._p(), s2.length > 0 && (t2 = Math.max(this.Fv.xi(i2, s2[0].so), this.Fv.xi(i2, s2[s2.length - 1].so)));
    const n2 = this.up();
    for (let e3 = n2.length; e3--; ) {
      const s3 = this.Fv.xi(i2, n2[e3].Kt());
      s3 > t2 && (t2 = s3);
    }
    const r2 = this.Li.Ct();
    if (null !== r2 && null !== this.Ev && 2 !== (o2 = this.cn.crosshair).mode && o2.horzLine.visible && o2.horzLine.labelVisible) {
      const e3 = this.Li.pn(1, r2), s3 = this.Li.pn(this.Ev.height - 2, r2);
      t2 = Math.max(t2, this.Fv.xi(i2, this.Li.Fi(Math.floor(Math.min(e3, s3)) + 0.11111111111111, r2)), this.Fv.xi(i2, this.Li.Fi(Math.ceil(Math.max(e3, s3)) - 0.11111111111111, r2)));
    }
    var o2;
    i2.restore();
    const a2 = t2 || 34;
    return pD(Math.ceil(e2.C + e2.T + e2.A + e2.I + 5 + a2));
  }
  cp(t2) {
    null !== this.Ev && qC(this.Ev, t2) || (this.Ev = t2, this.jv = true, this.Gv.resizeCanvasElement(t2), this.Jv.resizeCanvasElement(t2), this.jv = false, this.Kv.style.width = `${t2.width}px`, this.Kv.style.height = `${t2.height}px`);
  }
  dp() {
    return dz(this.Ev).width;
  }
  Gi(t2) {
    this.Li !== t2 && (null !== this.Li && this.Li.Ko().p(this), this.Li = t2, t2.Ko().l(this.fo.bind(this), this));
  }
  Dt() {
    return this.Li;
  }
  nr() {
    const t2 = this.tn.fp();
    this.tn.$v().$t().E_(t2, dz(this.Dt()));
  }
  vp(t2) {
    if (null === this.Ev) return;
    if (1 !== t2) {
      this.pp(), this.Gv.applySuggestedBitmapSize();
      const t3 = GC(this.Gv);
      null !== t3 && (t3.useBitmapCoordinateSpace((t4) => {
        this.mp(t4), this.Ie(t4);
      }), this.tn.bp(t3, this.Xv), this.wp(t3), this.tn.bp(t3, this.Yv), this.gp(t3));
    }
    this.Jv.applySuggestedBitmapSize();
    const e2 = GC(this.Jv);
    null !== e2 && (e2.useBitmapCoordinateSpace(({ context: t3, bitmapSize: e3 }) => {
      t3.clearRect(0, 0, e3.width, e3.height);
    }), this.Mp(e2), this.tn.bp(e2, this.Zv));
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  bt() {
    var t2;
    null === (t2 = this.Li) || void 0 === t2 || t2.Ha();
  }
  Qv(t2) {
    if (null === this.Li || this.Li.Ni() || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const e2 = this.tn.$v().$t(), i2 = this.tn.fp();
    this.Nv = true, e2.V_(i2, this.Li, t2.localY);
  }
  tp(t2) {
    if (null === this.Li || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const e2 = this.tn.$v().$t(), i2 = this.tn.fp(), s2 = this.Li;
    e2.O_(i2, s2, t2.localY);
  }
  ip() {
    if (null === this.Li || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const t2 = this.tn.$v().$t(), e2 = this.tn.fp(), i2 = this.Li;
    this.Nv && (this.Nv = false, t2.B_(e2, i2));
  }
  np(t2) {
    if (null === this.Li || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const e2 = this.tn.$v().$t(), i2 = this.tn.fp();
    this.Nv = false, e2.B_(i2, this.Li);
  }
  sp(t2) {
    this.cn.handleScale.axisDoubleClickReset.price && this.nr();
  }
  ep(t2) {
    null !== this.Li && (!this.tn.$v().$t().W().handleScale.axisPressedMouseMove.price || this.Li.Mh() || this.Li.Oo() || this.kp(1));
  }
  rp(t2) {
    this.kp(0);
  }
  up() {
    const t2 = [], e2 = null === this.Li ? void 0 : this.Li;
    return ((i2) => {
      for (let s2 = 0; s2 < i2.length; ++s2) {
        const n2 = i2[s2].Rn(this.tn.fp(), e2);
        for (let e3 = 0; e3 < n2.length; e3++) t2.push(n2[e3]);
      }
    })(this.tn.fp().Uo()), t2;
  }
  mp({ context: t2, bitmapSize: e2 }) {
    const { width: i2, height: s2 } = e2, n2 = this.tn.fp().$t(), r2 = n2.q(), o2 = n2.bd();
    r2 === o2 ? Az(t2, 0, 0, i2, s2, r2) : Wz(t2, 0, 0, i2, s2, r2, o2);
  }
  Ie({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2 }) {
    if (null === this.Ev || null === this.Li || !this.Li.W().borderVisible) return;
    t2.fillStyle = this.Li.W().borderColor;
    const s2 = Math.max(1, Math.floor(this.ap().C * i2));
    let n2;
    n2 = this.qv ? e2.width - s2 : 0, t2.fillRect(n2, 0, s2, e2.height);
  }
  wp(t2) {
    if (null === this.Ev || null === this.Li) return;
    const e2 = this.Li.Ha(), i2 = this.Li.W(), s2 = this.ap(), n2 = this.qv ? this.Ev.width - s2.T : 0;
    i2.borderVisible && i2.ticksVisible && t2.useBitmapCoordinateSpace(({ context: t3, horizontalPixelRatio: r2, verticalPixelRatio: o2 }) => {
      t3.fillStyle = i2.borderColor;
      const a2 = Math.max(1, Math.floor(o2)), l2 = Math.floor(0.5 * o2), h2 = Math.round(s2.T * r2);
      t3.beginPath();
      for (const i3 of e2) t3.rect(Math.floor(n2 * r2), Math.round(i3.Ea * o2) - l2, h2, a2);
      t3.fill();
    }), t2.useMediaCoordinateSpace(({ context: t3 }) => {
      var r2;
      t3.font = this._p(), t3.fillStyle = null !== (r2 = i2.textColor) && void 0 !== r2 ? r2 : this.ko.textColor, t3.textAlign = this.qv ? "right" : "left", t3.textBaseline = "middle";
      const o2 = this.qv ? Math.round(n2 - s2.A) : Math.round(n2 + s2.T + s2.A), a2 = e2.map((e3) => this.Fv.Mi(t3, e3.so));
      for (let i3 = e2.length; i3--; ) {
        const s3 = e2[i3];
        t3.fillText(s3.so, o2, s3.Ea + a2[i3]);
      }
    });
  }
  pp() {
    if (null === this.Ev || null === this.Li) return;
    const t2 = [], e2 = this.Li.Uo().slice(), i2 = this.tn.fp(), s2 = this.ap();
    this.Li === i2.pr() && this.tn.fp().Uo().forEach((t3) => {
      i2.vr(t3) && e2.push(t3);
    });
    const n2 = this.Li;
    e2.forEach((e3) => {
      e3.Rn(i2, n2).forEach((e4) => {
        e4.Oi(null), e4.Bi() && t2.push(e4);
      });
    }), t2.forEach((t3) => t3.Oi(t3.ki())), this.Li.W().alignLabels && this.yp(t2, s2);
  }
  yp(t2, e2) {
    if (null === this.Ev) return;
    const i2 = this.Ev.height / 2, s2 = t2.filter((t3) => t3.ki() <= i2), n2 = t2.filter((t3) => t3.ki() > i2);
    s2.sort((t3, e3) => e3.ki() - t3.ki()), n2.sort((t3, e3) => t3.ki() - e3.ki());
    for (const i3 of t2) {
      const t3 = Math.floor(i3.At(e2) / 2), s3 = i3.ki();
      s3 > -t3 && s3 < t3 && i3.Oi(t3), s3 > this.Ev.height - t3 && s3 < this.Ev.height + t3 && i3.Oi(this.Ev.height - t3);
    }
    RD(s2, 1, this.Ev.height, e2), RD(n2, -1, this.Ev.height, e2);
  }
  gp(t2) {
    if (null === this.Ev) return;
    const e2 = this.up(), i2 = this.ap(), s2 = this.qv ? "right" : "left";
    e2.forEach((e3) => {
      e3.Ai() && e3.gt(dz(this.Li)).X(t2, i2, this.Fv, s2);
    });
  }
  Mp(t2) {
    if (null === this.Ev || null === this.Li) return;
    const e2 = this.tn.$v().$t(), i2 = [], s2 = this.tn.fp(), n2 = e2.Zc().Rn(s2, this.Li);
    n2.length && i2.push(n2);
    const r2 = this.ap(), o2 = this.qv ? "right" : "left";
    i2.forEach((e3) => {
      e3.forEach((e4) => {
        e4.gt(dz(this.Li)).X(t2, r2, this.Fv, o2);
      });
    });
  }
  kp(t2) {
    this.Kv.style.cursor = 1 === t2 ? "ns-resize" : "default";
  }
  fo() {
    const t2 = this.op();
    this.Wv < t2 && this.tn.$v().$t().Kl(), this.Wv = t2;
  }
  _p() {
    return Tz(this.ko.fontSize, this.ko.fontFamily);
  }
}
function ED(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.ua) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
function PD(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.Pn) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
function TD(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.Ji) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
function LD(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.aa) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
class Vs {
  constructor(t2, e2) {
    this.Ev = HC({ width: 0, height: 0 }), this.Cp = null, this.Tp = null, this.Pp = null, this.Rp = null, this.Dp = false, this.Vp = new D(), this.Op = new D(), this.Bp = 0, this.Ap = false, this.Ip = null, this.zp = false, this.Lp = null, this.Ep = null, this.jv = false, this.Hv = () => {
      this.jv || null === this.Np || this.$i().Uh();
    }, this.Uv = () => {
      this.jv || null === this.Np || this.$i().Uh();
    }, this.Qd = t2, this.Np = e2, this.Np.W_().l(this.Fp.bind(this), this, true), this.Wp = document.createElement("td"), this.Wp.style.padding = "0", this.Wp.style.position = "relative";
    const i2 = document.createElement("div");
    i2.style.width = "100%", i2.style.height = "100%", i2.style.position = "relative", i2.style.overflow = "hidden", this.jp = document.createElement("td"), this.jp.style.padding = "0", this.Hp = document.createElement("td"), this.Hp.style.padding = "0", this.Wp.appendChild(i2), this.Gv = vD(i2, HC({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
    const s2 = this.Gv.canvasElement;
    s2.style.position = "absolute", s2.style.zIndex = "1", s2.style.left = "0", s2.style.top = "0", this.Jv = vD(i2, HC({ width: 16, height: 16 })), this.Jv.subscribeSuggestedBitmapSizeChanged(this.Uv);
    const n2 = this.Jv.canvasElement;
    n2.style.position = "absolute", n2.style.zIndex = "2", n2.style.left = "0", n2.style.top = "0", this.$p = document.createElement("tr"), this.$p.appendChild(this.jp), this.$p.appendChild(this.Wp), this.$p.appendChild(this.Hp), this.Up(), this.hp = new ps(this.Jv.canvasElement, this, { ev: () => null === this.Ip && !this.Qd.W().handleScroll.vertTouchDrag, rv: () => null === this.Ip && !this.Qd.W().handleScroll.horzTouchDrag });
  }
  S() {
    null !== this.Cp && this.Cp.S(), null !== this.Tp && this.Tp.S(), this.Pp = null, this.Jv.unsubscribeSuggestedBitmapSizeChanged(this.Uv), bD(this.Jv.canvasElement), this.Jv.dispose(), this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), bD(this.Gv.canvasElement), this.Gv.dispose(), null !== this.Np && this.Np.W_().p(this), this.hp.S();
  }
  fp() {
    return dz(this.Np);
  }
  qp(t2) {
    var e2, i2;
    null !== this.Np && this.Np.W_().p(this), this.Np = t2, null !== this.Np && this.Np.W_().l(Vs.prototype.Fp.bind(this), this, true), this.Up(), this.Qd.Yp().indexOf(this) === this.Qd.Yp().length - 1 ? (this.Pp = null !== (e2 = this.Pp) && void 0 !== e2 ? e2 : new os(this.Wp, this.Qd), this.Pp.bt()) : (null === (i2 = this.Pp) || void 0 === i2 || i2.if(), this.Pp = null);
  }
  $v() {
    return this.Qd;
  }
  lp() {
    return this.$p;
  }
  Up() {
    if (null !== this.Np && (this.Zp(), 0 !== this.$i().wt().length)) {
      if (null !== this.Cp) {
        const t2 = this.Np.R_();
        this.Cp.Gi(dz(t2));
      }
      if (null !== this.Tp) {
        const t2 = this.Np.D_();
        this.Tp.Gi(dz(t2));
      }
    }
  }
  Xp() {
    null !== this.Cp && this.Cp.bt(), null !== this.Tp && this.Tp.bt();
  }
  M_() {
    return null !== this.Np ? this.Np.M_() : 0;
  }
  x_(t2) {
    this.Np && this.Np.x_(t2);
  }
  Qf(t2) {
    if (!this.Np) return;
    this.Kp();
    const e2 = t2.localX, i2 = t2.localY;
    this.Gp(e2, i2, t2);
  }
  bv(t2) {
    this.Kp(), this.Jp(), this.Gp(t2.localX, t2.localY, t2);
  }
  tv(t2) {
    var e2;
    if (!this.Np) return;
    this.Kp();
    const i2 = t2.localX, s2 = t2.localY;
    this.Gp(i2, s2, t2);
    const n2 = this.wr(i2, s2);
    this.Qd.Qp(null !== (e2 = null == n2 ? void 0 : n2.Lv) && void 0 !== e2 ? e2 : null), this.$i().jc(n2 && { Hc: n2.Hc, Iv: n2.Iv });
  }
  dv(t2) {
    null !== this.Np && (this.Kp(), this.tm(t2));
  }
  qf(t2) {
    null !== this.Np && this.im(this.Op, t2);
  }
  jf(t2) {
    this.qf(t2);
  }
  av(t2) {
    this.Kp(), this.nm(t2), this.Gp(t2.localX, t2.localY, t2);
  }
  cv(t2) {
    null !== this.Np && (this.Kp(), this.Ap = false, this.sm(t2));
  }
  uv(t2) {
    null !== this.Np && this.tm(t2);
  }
  Rv(t2) {
    if (this.Ap = true, null === this.Ip) {
      const e2 = { x: t2.localX, y: t2.localY };
      this.rm(e2, e2, t2);
    }
  }
  Pv(t2) {
    null !== this.Np && (this.Kp(), this.Np.$t().jc(null), this.hm());
  }
  lm() {
    return this.Vp;
  }
  am() {
    return this.Op;
  }
  xv() {
    this.Bp = 1, this.$i().Un();
  }
  Sv(t2, e2) {
    if (!this.Qd.W().handleScale.pinch) return;
    const i2 = 5 * (e2 - this.Bp);
    this.Bp = e2, this.$i().Qc(t2.nt, i2);
  }
  pv(t2) {
    this.Ap = false, this.zp = null !== this.Ip, this.Jp();
    const e2 = this.$i().Zc();
    null !== this.Ip && e2.yt() && (this.Lp = { x: e2.Yt(), y: e2.Zt() }, this.Ip = { x: t2.localX, y: t2.localY });
  }
  hv(t2) {
    if (null === this.Np) return;
    const e2 = t2.localX, i2 = t2.localY;
    if (null === this.Ip) this.nm(t2);
    else {
      this.zp = false;
      const s2 = dz(this.Lp), n2 = s2.x + (e2 - this.Ip.x), r2 = s2.y + (i2 - this.Ip.y);
      this.Gp(n2, r2, t2);
    }
  }
  _v(t2) {
    0 === this.$v().W().trackingMode.exitMode && (this.zp = true), this.om(), this.sm(t2);
  }
  wr(t2, e2) {
    const i2 = this.Np;
    return null === i2 ? null : function(t3, e3, i3) {
      const s2 = t3.Uo(), n2 = function(t4, e4, i4) {
        var s3, n3;
        let r2, o2;
        for (const h2 of t4) {
          const t5 = null !== (n3 = null === (s3 = h2.va) || void 0 === s3 ? void 0 : s3.call(h2, e4, i4)) && void 0 !== n3 ? n3 : [];
          for (const e5 of t5) a2 = e5.zOrder, (!(l2 = null == r2 ? void 0 : r2.zOrder) || "top" === a2 && "top" !== l2 || "normal" === a2 && "bottom" === l2) && (r2 = e5, o2 = h2);
        }
        var a2, l2;
        return r2 && o2 ? { zv: r2, Hc: o2 } : null;
      }(s2, e3, i3);
      if ("top" === (null == n2 ? void 0 : n2.zv.zOrder)) return zD(n2);
      for (const r2 of s2) {
        if (n2 && n2.Hc === r2 && "bottom" !== n2.zv.zOrder && !n2.zv.isBackground) return zD(n2);
        const s3 = $D(r2.Pn(t3), e3, i3);
        if (null !== s3) return { Hc: r2, Bv: s3.Bv, Iv: s3.Iv };
        if (n2 && n2.Hc === r2 && "bottom" !== n2.zv.zOrder && n2.zv.isBackground) return zD(n2);
      }
      return (null == n2 ? void 0 : n2.zv) ? zD(n2) : null;
    }(i2, t2, e2);
  }
  _m(t2, e2) {
    dz("left" === e2 ? this.Cp : this.Tp).cp(HC({ width: t2, height: this.Ev.height }));
  }
  um() {
    return this.Ev;
  }
  cp(t2) {
    qC(this.Ev, t2) || (this.Ev = t2, this.jv = true, this.Gv.resizeCanvasElement(t2), this.Jv.resizeCanvasElement(t2), this.jv = false, this.Wp.style.width = t2.width + "px", this.Wp.style.height = t2.height + "px");
  }
  dm() {
    const t2 = dz(this.Np);
    t2.P_(t2.R_()), t2.P_(t2.D_());
    for (const e2 of t2.Ba()) if (t2.vr(e2)) {
      const i2 = e2.Dt();
      null !== i2 && t2.P_(i2), e2.Vn();
    }
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  vp(t2) {
    if (0 === t2) return;
    if (null === this.Np) return;
    if (t2 > 1 && this.dm(), null !== this.Cp && this.Cp.vp(t2), null !== this.Tp && this.Tp.vp(t2), 1 !== t2) {
      this.Gv.applySuggestedBitmapSize();
      const t3 = GC(this.Gv);
      null !== t3 && (t3.useBitmapCoordinateSpace((t4) => {
        this.mp(t4);
      }), this.Np && (this.fm(t3, ED), this.vm(t3), this.pm(t3), this.fm(t3, PD), this.fm(t3, TD)));
    }
    this.Jv.applySuggestedBitmapSize();
    const e2 = GC(this.Jv);
    null !== e2 && (e2.useBitmapCoordinateSpace(({ context: t3, bitmapSize: e3 }) => {
      t3.clearRect(0, 0, e3.width, e3.height);
    }), this.bm(e2), this.fm(e2, LD));
  }
  wm() {
    return this.Cp;
  }
  gm() {
    return this.Tp;
  }
  bp(t2, e2) {
    this.fm(t2, e2);
  }
  Fp() {
    null !== this.Np && this.Np.W_().p(this), this.Np = null;
  }
  tm(t2) {
    this.im(this.Vp, t2);
  }
  im(t2, e2) {
    const i2 = e2.localX, s2 = e2.localY;
    t2.M() && t2.m(this.$i().St().Nu(i2), { x: i2, y: s2 }, e2);
  }
  mp({ context: t2, bitmapSize: e2 }) {
    const { width: i2, height: s2 } = e2, n2 = this.$i(), r2 = n2.q(), o2 = n2.bd();
    r2 === o2 ? Az(t2, 0, 0, i2, s2, o2) : Wz(t2, 0, 0, i2, s2, r2, o2);
  }
  vm(t2) {
    const e2 = dz(this.Np).j_().qh().gt();
    null !== e2 && e2.X(t2, false);
  }
  pm(t2) {
    const e2 = this.$i().Yc();
    this.Mm(t2, PD, _D, e2), this.Mm(t2, PD, yD, e2);
  }
  bm(t2) {
    this.Mm(t2, PD, yD, this.$i().Zc());
  }
  fm(t2, e2) {
    const i2 = dz(this.Np).Uo();
    for (const s2 of i2) this.Mm(t2, e2, _D, s2);
    for (const s2 of i2) this.Mm(t2, e2, yD, s2);
  }
  Mm(t2, e2, i2, s2) {
    const n2 = dz(this.Np), r2 = n2.$t().Wc(), o2 = null !== r2 && r2.Hc === s2, a2 = null !== r2 && o2 && void 0 !== r2.Iv ? r2.Iv.Mr : void 0;
    xD(e2, (e3) => i2(e3, t2, o2, a2), s2, n2);
  }
  Zp() {
    if (null === this.Np) return;
    const t2 = this.Qd, e2 = this.Np.R_().W().visible, i2 = this.Np.D_().W().visible;
    e2 || null === this.Cp || (this.jp.removeChild(this.Cp.lp()), this.Cp.S(), this.Cp = null), i2 || null === this.Tp || (this.Hp.removeChild(this.Tp.lp()), this.Tp.S(), this.Tp = null);
    const s2 = t2.$t().ud();
    e2 && null === this.Cp && (this.Cp = new Cs(this, t2.W(), s2, "left"), this.jp.appendChild(this.Cp.lp())), i2 && null === this.Tp && (this.Tp = new Cs(this, t2.W(), s2, "right"), this.Hp.appendChild(this.Tp.lp()));
  }
  xm(t2) {
    return t2.Dv && this.Ap || null !== this.Ip;
  }
  Sm(t2) {
    return Math.max(0, Math.min(t2, this.Ev.width - 1));
  }
  km(t2) {
    return Math.max(0, Math.min(t2, this.Ev.height - 1));
  }
  Gp(t2, e2, i2) {
    this.$i().ld(this.Sm(t2), this.km(e2), i2, dz(this.Np));
  }
  hm() {
    this.$i().od();
  }
  om() {
    this.zp && (this.Ip = null, this.hm());
  }
  rm(t2, e2, i2) {
    this.Ip = t2, this.zp = false, this.Gp(e2.x, e2.y, i2);
    const s2 = this.$i().Zc();
    this.Lp = { x: s2.Yt(), y: s2.Zt() };
  }
  $i() {
    return this.Qd.$t();
  }
  sm(t2) {
    if (!this.Dp) return;
    const e2 = this.$i(), i2 = this.fp();
    if (e2.z_(i2, i2.vn()), this.Rp = null, this.Dp = false, e2.ed(), null !== this.Ep) {
      const t3 = performance.now(), i3 = e2.St();
      this.Ep.Vr(i3.Hu(), t3), this.Ep.Qu(t3) || e2.Zn(this.Ep);
    }
  }
  Kp() {
    this.Ip = null;
  }
  Jp() {
    if (this.Np) {
      if (this.$i().Un(), document.activeElement !== document.body && document.activeElement !== document.documentElement) dz(document.activeElement).blur();
      else {
        const t2 = document.getSelection();
        null !== t2 && t2.removeAllRanges();
      }
      !this.Np.vn().Ni() && this.$i().St().Ni();
    }
  }
  nm(t2) {
    if (null === this.Np) return;
    const e2 = this.$i(), i2 = e2.St();
    if (i2.Ni()) return;
    const s2 = this.Qd.W(), n2 = s2.handleScroll, r2 = s2.kineticScroll;
    if ((!n2.pressedMouseMove || t2.Dv) && (!n2.horzTouchDrag && !n2.vertTouchDrag || !t2.Dv)) return;
    const o2 = this.Np.vn(), a2 = performance.now();
    if (null !== this.Rp || this.xm(t2) || (this.Rp = { x: t2.clientX, y: t2.clientY, Od: a2, ym: t2.localX, Cm: t2.localY }), null !== this.Rp && !this.Dp && (this.Rp.x !== t2.clientX || this.Rp.y !== t2.clientY)) {
      if (t2.Dv && r2.touch || !t2.Dv && r2.mouse) {
        const t3 = i2.le();
        this.Ep = new as(0.2 / t3, 7 / t3, 0.997, 15 / t3), this.Ep.Yd(i2.Hu(), this.Rp.Od);
      } else this.Ep = null;
      o2.Ni() || e2.A_(this.Np, o2, t2.localY), e2.nd(t2.localX), this.Dp = true;
    }
    this.Dp && (o2.Ni() || e2.I_(this.Np, o2, t2.localY), e2.sd(t2.localX), null !== this.Ep && this.Ep.Yd(i2.Hu(), a2));
  }
}
class Os {
  constructor(t2, e2, i2, s2, n2) {
    this.ft = true, this.Ev = HC({ width: 0, height: 0 }), this.Hv = () => this.vp(3), this.qv = "left" === t2, this.Oc = i2.ud, this.cn = e2, this.Tm = s2, this.Pm = n2, this.Kv = document.createElement("div"), this.Kv.style.width = "25px", this.Kv.style.height = "100%", this.Kv.style.overflow = "hidden", this.Gv = vD(this.Kv, HC({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
  }
  S() {
    this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), bD(this.Gv.canvasElement), this.Gv.dispose();
  }
  lp() {
    return this.Kv;
  }
  um() {
    return this.Ev;
  }
  cp(t2) {
    qC(this.Ev, t2) || (this.Ev = t2, this.Gv.resizeCanvasElement(t2), this.Kv.style.width = `${t2.width}px`, this.Kv.style.height = `${t2.height}px`, this.ft = true);
  }
  vp(t2) {
    if (t2 < 3 && !this.ft) return;
    if (0 === this.Ev.width || 0 === this.Ev.height) return;
    this.ft = false, this.Gv.applySuggestedBitmapSize();
    const e2 = GC(this.Gv);
    null !== e2 && e2.useBitmapCoordinateSpace((t3) => {
      this.mp(t3), this.Ie(t3);
    });
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  Ie({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (!this.Tm()) return;
    t2.fillStyle = this.cn.timeScale.borderColor;
    const n2 = Math.floor(this.Oc.W().C * i2), r2 = Math.floor(this.Oc.W().C * s2), o2 = this.qv ? e2.width - n2 : 0;
    t2.fillRect(o2, 0, n2, r2);
  }
  mp({ context: t2, bitmapSize: e2 }) {
    Az(t2, 0, 0, e2.width, e2.height, this.Pm());
  }
}
function VD(t2) {
  return (e2) => {
    var i2, s2;
    return null !== (s2 = null === (i2 = e2.fa) || void 0 === i2 ? void 0 : i2.call(e2, t2)) && void 0 !== s2 ? s2 : [];
  };
}
const OD = VD("normal"), AD = VD("top"), FD = VD("bottom");
class Ls {
  constructor(t2, e2) {
    this.Rm = null, this.Dm = null, this.k = null, this.Vm = false, this.Ev = HC({ width: 0, height: 0 }), this.Om = new D(), this.Fv = new ni(5), this.jv = false, this.Hv = () => {
      this.jv || this.Qd.$t().Uh();
    }, this.Uv = () => {
      this.jv || this.Qd.$t().Uh();
    }, this.Qd = t2, this.q_ = e2, this.cn = t2.W().layout, this.Xd = document.createElement("tr"), this.Bm = document.createElement("td"), this.Bm.style.padding = "0", this.Am = document.createElement("td"), this.Am.style.padding = "0", this.Kv = document.createElement("td"), this.Kv.style.height = "25px", this.Kv.style.padding = "0", this.Im = document.createElement("div"), this.Im.style.width = "100%", this.Im.style.height = "100%", this.Im.style.position = "relative", this.Im.style.overflow = "hidden", this.Kv.appendChild(this.Im), this.Gv = vD(this.Im, HC({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
    const i2 = this.Gv.canvasElement;
    i2.style.position = "absolute", i2.style.zIndex = "1", i2.style.left = "0", i2.style.top = "0", this.Jv = vD(this.Im, HC({ width: 16, height: 16 })), this.Jv.subscribeSuggestedBitmapSizeChanged(this.Uv);
    const s2 = this.Jv.canvasElement;
    s2.style.position = "absolute", s2.style.zIndex = "2", s2.style.left = "0", s2.style.top = "0", this.Xd.appendChild(this.Bm), this.Xd.appendChild(this.Kv), this.Xd.appendChild(this.Am), this.zm(), this.Qd.$t().g_().l(this.zm.bind(this), this), this.hp = new ps(this.Jv.canvasElement, this, { ev: () => true, rv: () => !this.Qd.W().handleScroll.horzTouchDrag });
  }
  S() {
    this.hp.S(), null !== this.Rm && this.Rm.S(), null !== this.Dm && this.Dm.S(), this.Jv.unsubscribeSuggestedBitmapSizeChanged(this.Uv), bD(this.Jv.canvasElement), this.Jv.dispose(), this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), bD(this.Gv.canvasElement), this.Gv.dispose();
  }
  lp() {
    return this.Xd;
  }
  Lm() {
    return this.Rm;
  }
  Em() {
    return this.Dm;
  }
  bv(t2) {
    if (this.Vm) return;
    this.Vm = true;
    const e2 = this.Qd.$t();
    !e2.St().Ni() && this.Qd.W().handleScale.axisPressedMouseMove.time && e2.Jc(t2.localX);
  }
  pv(t2) {
    this.bv(t2);
  }
  wv() {
    const t2 = this.Qd.$t();
    !t2.St().Ni() && this.Vm && (this.Vm = false, this.Qd.W().handleScale.axisPressedMouseMove.time && t2.hd());
  }
  av(t2) {
    const e2 = this.Qd.$t();
    !e2.St().Ni() && this.Qd.W().handleScale.axisPressedMouseMove.time && e2.rd(t2.localX);
  }
  hv(t2) {
    this.av(t2);
  }
  cv() {
    this.Vm = false;
    const t2 = this.Qd.$t();
    t2.St().Ni() && !this.Qd.W().handleScale.axisPressedMouseMove.time || t2.hd();
  }
  _v() {
    this.cv();
  }
  qf() {
    this.Qd.W().handleScale.axisDoubleClickReset.time && this.Qd.$t().Kn();
  }
  jf() {
    this.qf();
  }
  Qf() {
    this.Qd.$t().W().handleScale.axisPressedMouseMove.time && this.kp(1);
  }
  Pv() {
    this.kp(0);
  }
  um() {
    return this.Ev;
  }
  Nm() {
    return this.Om;
  }
  Fm(t2, e2, i2) {
    qC(this.Ev, t2) || (this.Ev = t2, this.jv = true, this.Gv.resizeCanvasElement(t2), this.Jv.resizeCanvasElement(t2), this.jv = false, this.Kv.style.width = `${t2.width}px`, this.Kv.style.height = `${t2.height}px`, this.Om.m(t2)), null !== this.Rm && this.Rm.cp(HC({ width: e2, height: t2.height })), null !== this.Dm && this.Dm.cp(HC({ width: i2, height: t2.height }));
  }
  Wm() {
    const t2 = this.jm();
    return Math.ceil(t2.C + t2.T + t2.P + t2.L + t2.B + t2.Hm);
  }
  bt() {
    this.Qd.$t().St().Ha();
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  vp(t2) {
    if (0 === t2) return;
    if (1 !== t2) {
      this.Gv.applySuggestedBitmapSize();
      const e3 = GC(this.Gv);
      null !== e3 && (e3.useBitmapCoordinateSpace((t3) => {
        this.mp(t3), this.Ie(t3), this.$m(e3, FD);
      }), this.wp(e3), this.$m(e3, OD)), null !== this.Rm && this.Rm.vp(t2), null !== this.Dm && this.Dm.vp(t2);
    }
    this.Jv.applySuggestedBitmapSize();
    const e2 = GC(this.Jv);
    null !== e2 && (e2.useBitmapCoordinateSpace(({ context: t3, bitmapSize: e3 }) => {
      t3.clearRect(0, 0, e3.width, e3.height);
    }), this.Um([...this.Qd.$t().wt(), this.Qd.$t().Zc()], e2), this.$m(e2, AD));
  }
  $m(t2, e2) {
    const i2 = this.Qd.$t().wt();
    for (const s2 of i2) xD(e2, (e3) => _D(e3, t2, false, void 0), s2, void 0);
    for (const s2 of i2) xD(e2, (e3) => yD(e3, t2, false, void 0), s2, void 0);
  }
  mp({ context: t2, bitmapSize: e2 }) {
    Az(t2, 0, 0, e2.width, e2.height, this.Qd.$t().bd());
  }
  Ie({ context: t2, bitmapSize: e2, verticalPixelRatio: i2 }) {
    if (this.Qd.W().timeScale.borderVisible) {
      t2.fillStyle = this.qm();
      const s2 = Math.max(1, Math.floor(this.jm().C * i2));
      t2.fillRect(0, 0, e2.width, s2);
    }
  }
  wp(t2) {
    const e2 = this.Qd.$t().St(), i2 = e2.Ha();
    if (!i2 || 0 === i2.length) return;
    const s2 = this.q_.maxTickMarkWeight(i2), n2 = this.jm(), r2 = e2.W();
    r2.borderVisible && r2.ticksVisible && t2.useBitmapCoordinateSpace(({ context: t3, horizontalPixelRatio: e3, verticalPixelRatio: s3 }) => {
      t3.strokeStyle = this.qm(), t3.fillStyle = this.qm();
      const r3 = Math.max(1, Math.floor(e3)), o2 = Math.floor(0.5 * e3);
      t3.beginPath();
      const a2 = Math.round(n2.T * s3);
      for (let s4 = i2.length; s4--; ) {
        const n3 = Math.round(i2[s4].coord * e3);
        t3.rect(n3 - o2, 0, r3, a2);
      }
      t3.fill();
    }), t2.useMediaCoordinateSpace(({ context: t3 }) => {
      const e3 = n2.C + n2.T + n2.L + n2.P / 2;
      t3.textAlign = "center", t3.textBaseline = "middle", t3.fillStyle = this.$(), t3.font = this._p();
      for (const n3 of i2) if (n3.weight < s2) {
        const i3 = n3.needAlignCoordinate ? this.Ym(t3, n3.coord, n3.label) : n3.coord;
        t3.fillText(n3.label, i3, e3);
      }
      this.Qd.W().timeScale.allowBoldLabels && (t3.font = this.Zm());
      for (const n3 of i2) if (n3.weight >= s2) {
        const i3 = n3.needAlignCoordinate ? this.Ym(t3, n3.coord, n3.label) : n3.coord;
        t3.fillText(n3.label, i3, e3);
      }
    });
  }
  Ym(t2, e2, i2) {
    const s2 = this.Fv.xi(t2, i2), n2 = s2 / 2, r2 = Math.floor(e2 - n2) + 0.5;
    return r2 < 0 ? e2 += Math.abs(0 - r2) : r2 + s2 > this.Ev.width && (e2 -= Math.abs(this.Ev.width - (r2 + s2))), e2;
  }
  Um(t2, e2) {
    const i2 = this.jm();
    for (const s2 of t2) for (const t3 of s2.Qi()) t3.gt().X(e2, i2);
  }
  qm() {
    return this.Qd.W().timeScale.borderColor;
  }
  $() {
    return this.cn.textColor;
  }
  j() {
    return this.cn.fontSize;
  }
  _p() {
    return Tz(this.j(), this.cn.fontFamily);
  }
  Zm() {
    return Tz(this.j(), this.cn.fontFamily, "bold");
  }
  jm() {
    null === this.k && (this.k = { C: 1, N: NaN, L: NaN, B: NaN, ji: NaN, T: 5, P: NaN, R: "", Wi: new ni(), Hm: 0 });
    const t2 = this.k, e2 = this._p();
    if (t2.R !== e2) {
      const i2 = this.j();
      t2.P = i2, t2.R = e2, t2.L = 3 * i2 / 12, t2.B = 3 * i2 / 12, t2.ji = 9 * i2 / 12, t2.N = 0, t2.Hm = 4 * i2 / 12, t2.Wi.nr();
    }
    return this.k;
  }
  kp(t2) {
    this.Kv.style.cursor = 1 === t2 ? "ew-resize" : "default";
  }
  zm() {
    const t2 = this.Qd.$t(), e2 = t2.W();
    e2.leftPriceScale.visible || null === this.Rm || (this.Bm.removeChild(this.Rm.lp()), this.Rm.S(), this.Rm = null), e2.rightPriceScale.visible || null === this.Dm || (this.Am.removeChild(this.Dm.lp()), this.Dm.S(), this.Dm = null);
    const i2 = { ud: this.Qd.$t().ud() }, s2 = () => e2.leftPriceScale.borderVisible && t2.St().W().borderVisible, n2 = () => t2.bd();
    e2.leftPriceScale.visible && null === this.Rm && (this.Rm = new Os("left", e2, i2, s2, n2), this.Bm.appendChild(this.Rm.lp())), e2.rightPriceScale.visible && null === this.Dm && (this.Dm = new Os("right", e2, i2, s2, n2), this.Am.appendChild(this.Dm.lp()));
  }
}
const ND = !!uD && !!navigator.userAgentData && navigator.userAgentData.brands.some((t2) => t2.brand.includes("Chromium")) && !!uD && ((null === (WD = null === navigator || void 0 === navigator ? void 0 : navigator.userAgentData) || void 0 === WD ? void 0 : WD.platform) ? "Windows" === navigator.userAgentData.platform : navigator.userAgent.toLowerCase().indexOf("win") >= 0);
var WD;
class Fs {
  constructor(t2, e2, i2) {
    var s2;
    this.Xm = [], this.Km = 0, this.ho = 0, this.__ = 0, this.Gm = 0, this.Jm = 0, this.Qm = null, this.tb = false, this.Vp = new D(), this.Op = new D(), this.Rc = new D(), this.ib = null, this.nb = null, this.Jd = t2, this.cn = e2, this.q_ = i2, this.Xd = document.createElement("div"), this.Xd.classList.add("tv-lightweight-charts"), this.Xd.style.overflow = "hidden", this.Xd.style.direction = "ltr", this.Xd.style.width = "100%", this.Xd.style.height = "100%", (s2 = this.Xd).style.userSelect = "none", s2.style.webkitUserSelect = "none", s2.style.msUserSelect = "none", s2.style.MozUserSelect = "none", s2.style.webkitTapHighlightColor = "transparent", this.sb = document.createElement("table"), this.sb.setAttribute("cellspacing", "0"), this.Xd.appendChild(this.sb), this.eb = this.rb.bind(this), ID(this.cn) && this.hb(true), this.$i = new Ln(this.Vc.bind(this), this.cn, i2), this.$t().Xc().l(this.lb.bind(this), this), this.ab = new Ls(this, this.q_), this.sb.appendChild(this.ab.lp());
    const n2 = e2.autoSize && this.ob();
    let r2 = this.cn.width, o2 = this.cn.height;
    if (n2 || 0 === r2 || 0 === o2) {
      const e3 = t2.getBoundingClientRect();
      r2 = r2 || e3.width, o2 = o2 || e3.height;
    }
    this._b(r2, o2), this.ub(), t2.appendChild(this.Xd), this.cb(), this.$i.St().ec().l(this.$i.Kl.bind(this.$i), this), this.$i.g_().l(this.$i.Kl.bind(this.$i), this);
  }
  $t() {
    return this.$i;
  }
  W() {
    return this.cn;
  }
  Yp() {
    return this.Xm;
  }
  fb() {
    return this.ab;
  }
  S() {
    this.hb(false), 0 !== this.Km && window.cancelAnimationFrame(this.Km), this.$i.Xc().p(this), this.$i.St().ec().p(this), this.$i.g_().p(this), this.$i.S();
    for (const t2 of this.Xm) this.sb.removeChild(t2.lp()), t2.lm().p(this), t2.am().p(this), t2.S();
    this.Xm = [], dz(this.ab).S(), null !== this.Xd.parentElement && this.Xd.parentElement.removeChild(this.Xd), this.Rc.S(), this.Vp.S(), this.Op.S(), this.pb();
  }
  _b(t2, e2, i2 = false) {
    if (this.ho === e2 && this.__ === t2) return;
    const s2 = function(t3) {
      const e3 = Math.floor(t3.width), i3 = Math.floor(t3.height);
      return HC({ width: e3 - e3 % 2, height: i3 - i3 % 2 });
    }(HC({ width: t2, height: e2 }));
    this.ho = s2.height, this.__ = s2.width;
    const n2 = this.ho + "px", r2 = this.__ + "px";
    dz(this.Xd).style.height = n2, dz(this.Xd).style.width = r2, this.sb.style.height = n2, this.sb.style.width = r2, i2 ? this.mb(ut.es(), performance.now()) : this.$i.Kl();
  }
  vp(t2) {
    void 0 === t2 && (t2 = ut.es());
    for (let e2 = 0; e2 < this.Xm.length; e2++) this.Xm[e2].vp(t2.Hn(e2).Fn);
    this.cn.timeScale.visible && this.ab.vp(t2.jn());
  }
  $h(t2) {
    const e2 = ID(this.cn);
    this.$i.$h(t2);
    const i2 = ID(this.cn);
    i2 !== e2 && this.hb(i2), this.cb(), this.bb(t2);
  }
  lm() {
    return this.Vp;
  }
  am() {
    return this.Op;
  }
  Xc() {
    return this.Rc;
  }
  wb() {
    null !== this.Qm && (this.mb(this.Qm, performance.now()), this.Qm = null);
    const t2 = this.gb(null), e2 = document.createElement("canvas");
    e2.width = t2.width, e2.height = t2.height;
    const i2 = dz(e2.getContext("2d"));
    return this.gb(i2), e2;
  }
  Mb(t2) {
    return ("left" !== t2 || this.xb()) && ("right" !== t2 || this.Sb()) ? 0 === this.Xm.length ? 0 : dz("left" === t2 ? this.Xm[0].wm() : this.Xm[0].gm()).dp() : 0;
  }
  kb() {
    return this.cn.autoSize && null !== this.ib;
  }
  yb() {
    return this.Xd;
  }
  Qp(t2) {
    this.nb = t2, this.nb ? this.yb().style.setProperty("cursor", t2) : this.yb().style.removeProperty("cursor");
  }
  Cb() {
    return this.nb;
  }
  Tb() {
    return uz(this.Xm[0]).um();
  }
  bb(t2) {
    (void 0 !== t2.autoSize || !this.ib || void 0 === t2.width && void 0 === t2.height) && (t2.autoSize && !this.ib && this.ob(), false === t2.autoSize && null !== this.ib && this.pb(), t2.autoSize || void 0 === t2.width && void 0 === t2.height || this._b(t2.width || this.__, t2.height || this.ho));
  }
  gb(t2) {
    let e2 = 0, i2 = 0;
    const s2 = this.Xm[0], n2 = (e3, i3) => {
      let s3 = 0;
      for (let n3 = 0; n3 < this.Xm.length; n3++) {
        const r3 = this.Xm[n3], o2 = dz("left" === e3 ? r3.wm() : r3.gm()), a2 = o2.xp();
        null !== t2 && o2.Sp(t2, i3, s3), s3 += a2.height;
      }
    };
    this.xb() && (n2("left", 0), e2 += dz(s2.wm()).xp().width);
    for (let s3 = 0; s3 < this.Xm.length; s3++) {
      const n3 = this.Xm[s3], r3 = n3.xp();
      null !== t2 && n3.Sp(t2, e2, i2), i2 += r3.height;
    }
    e2 += s2.xp().width, this.Sb() && (n2("right", e2), e2 += dz(s2.gm()).xp().width);
    const r2 = (e3, i3, s3) => {
      dz("left" === e3 ? this.ab.Lm() : this.ab.Em()).Sp(dz(t2), i3, s3);
    };
    if (this.cn.timeScale.visible) {
      const e3 = this.ab.xp();
      if (null !== t2) {
        let n3 = 0;
        this.xb() && (r2("left", n3, i2), n3 = dz(s2.wm()).xp().width), this.ab.Sp(t2, n3, i2), n3 += e3.width, this.Sb() && r2("right", n3, i2);
      }
      i2 += e3.height;
    }
    return HC({ width: e2, height: i2 });
  }
  Pb() {
    let t2 = 0, e2 = 0, i2 = 0;
    for (const s3 of this.Xm) this.xb() && (e2 = Math.max(e2, dz(s3.wm()).op(), this.cn.leftPriceScale.minimumWidth)), this.Sb() && (i2 = Math.max(i2, dz(s3.gm()).op(), this.cn.rightPriceScale.minimumWidth)), t2 += s3.M_();
    e2 = pD(e2), i2 = pD(i2);
    const s2 = this.__, n2 = this.ho, r2 = Math.max(s2 - e2 - i2, 0), o2 = this.cn.timeScale.visible;
    let a2 = o2 ? Math.max(this.ab.Wm(), this.cn.timeScale.minimumHeight) : 0;
    var l2;
    a2 = (l2 = a2) + l2 % 2;
    const h2 = 0 + a2, c2 = n2 < h2 ? 0 : n2 - h2, u2 = c2 / t2;
    let d2 = 0;
    for (let t3 = 0; t3 < this.Xm.length; ++t3) {
      const s3 = this.Xm[t3];
      s3.qp(this.$i.qc()[t3]);
      let n3 = 0, o3 = 0;
      o3 = t3 === this.Xm.length - 1 ? c2 - d2 : Math.round(s3.M_() * u2), n3 = Math.max(o3, 2), d2 += n3, s3.cp(HC({ width: r2, height: n3 })), this.xb() && s3._m(e2, "left"), this.Sb() && s3._m(i2, "right"), s3.fp() && this.$i.Kc(s3.fp(), n3);
    }
    this.ab.Fm(HC({ width: o2 ? r2 : 0, height: a2 }), o2 ? e2 : 0, o2 ? i2 : 0), this.$i.S_(r2), this.Gm !== e2 && (this.Gm = e2), this.Jm !== i2 && (this.Jm = i2);
  }
  hb(t2) {
    t2 ? this.Xd.addEventListener("wheel", this.eb, { passive: false }) : this.Xd.removeEventListener("wheel", this.eb);
  }
  Rb(t2) {
    switch (t2.deltaMode) {
      case t2.DOM_DELTA_PAGE:
        return 120;
      case t2.DOM_DELTA_LINE:
        return 32;
    }
    return ND ? 1 / window.devicePixelRatio : 1;
  }
  rb(t2) {
    if (!(0 !== t2.deltaX && this.cn.handleScroll.mouseWheel || 0 !== t2.deltaY && this.cn.handleScale.mouseWheel)) return;
    const e2 = this.Rb(t2), i2 = e2 * t2.deltaX / 100, s2 = -e2 * t2.deltaY / 100;
    if (t2.cancelable && t2.preventDefault(), 0 !== s2 && this.cn.handleScale.mouseWheel) {
      const e3 = Math.sign(s2) * Math.min(1, Math.abs(s2)), i3 = t2.clientX - this.Xd.getBoundingClientRect().left;
      this.$t().Qc(i3, e3);
    }
    0 !== i2 && this.cn.handleScroll.mouseWheel && this.$t().td(-80 * i2);
  }
  mb(t2, e2) {
    var i2;
    const s2 = t2.jn();
    3 === s2 && this.Db(), 3 !== s2 && 2 !== s2 || (this.Vb(t2), this.Ob(t2, e2), this.ab.bt(), this.Xm.forEach((t3) => {
      t3.Xp();
    }), 3 === (null === (i2 = this.Qm) || void 0 === i2 ? void 0 : i2.jn()) && (this.Qm.ts(t2), this.Db(), this.Vb(this.Qm), this.Ob(this.Qm, e2), t2 = this.Qm, this.Qm = null)), this.vp(t2);
  }
  Ob(t2, e2) {
    for (const i2 of t2.Qn()) this.ns(i2, e2);
  }
  Vb(t2) {
    const e2 = this.$i.qc();
    for (let i2 = 0; i2 < e2.length; i2++) t2.Hn(i2).Wn && e2[i2].N_();
  }
  ns(t2, e2) {
    const i2 = this.$i.St();
    switch (t2.qn) {
      case 0:
        i2.hc();
        break;
      case 1:
        i2.lc(t2.Vt);
        break;
      case 2:
        i2.Gn(t2.Vt);
        break;
      case 3:
        i2.Jn(t2.Vt);
        break;
      case 4:
        i2.qu();
        break;
      case 5:
        t2.Vt.Qu(e2) || i2.Jn(t2.Vt.tc(e2));
    }
  }
  Vc(t2) {
    null !== this.Qm ? this.Qm.ts(t2) : this.Qm = t2, this.tb || (this.tb = true, this.Km = window.requestAnimationFrame((t3) => {
      if (this.tb = false, this.Km = 0, null !== this.Qm) {
        const e2 = this.Qm;
        this.Qm = null, this.mb(e2, t3);
        for (const i2 of e2.Qn()) if (5 === i2.qn && !i2.Vt.Qu(t3)) {
          this.$t().Zn(i2.Vt);
          break;
        }
      }
    }));
  }
  Db() {
    this.ub();
  }
  ub() {
    const t2 = this.$i.qc(), e2 = t2.length, i2 = this.Xm.length;
    for (let t3 = e2; t3 < i2; t3++) {
      const t4 = uz(this.Xm.pop());
      this.sb.removeChild(t4.lp()), t4.lm().p(this), t4.am().p(this), t4.S();
    }
    for (let s2 = i2; s2 < e2; s2++) {
      const e3 = new Vs(this, t2[s2]);
      e3.lm().l(this.Bb.bind(this), this), e3.am().l(this.Ab.bind(this), this), this.Xm.push(e3), this.sb.insertBefore(e3.lp(), this.ab.lp());
    }
    for (let i3 = 0; i3 < e2; i3++) {
      const e3 = t2[i3], s2 = this.Xm[i3];
      s2.fp() !== e3 ? s2.qp(e3) : s2.Up();
    }
    this.cb(), this.Pb();
  }
  Ib(t2, e2, i2) {
    var s2;
    const n2 = /* @__PURE__ */ new Map();
    let r2;
    if (null !== t2 && this.$i.wt().forEach((e3) => {
      const i3 = e3.In().ll(t2);
      null !== i3 && n2.set(e3, i3);
    }), null !== t2) {
      const e3 = null === (s2 = this.$i.St().Ui(t2)) || void 0 === s2 ? void 0 : s2.originalTime;
      void 0 !== e3 && (r2 = e3);
    }
    const o2 = this.$t().Wc(), a2 = null !== o2 && o2.Hc instanceof Gi ? o2.Hc : void 0, l2 = null !== o2 && void 0 !== o2.Iv ? o2.Iv.gr : void 0;
    return { zb: r2, ee: null != t2 ? t2 : void 0, Lb: null != e2 ? e2 : void 0, Eb: a2, Nb: n2, Fb: l2, Wb: null != i2 ? i2 : void 0 };
  }
  Bb(t2, e2, i2) {
    this.Vp.m(() => this.Ib(t2, e2, i2));
  }
  Ab(t2, e2, i2) {
    this.Op.m(() => this.Ib(t2, e2, i2));
  }
  lb(t2, e2, i2) {
    this.Rc.m(() => this.Ib(t2, e2, i2));
  }
  cb() {
    const t2 = this.cn.timeScale.visible ? "" : "none";
    this.ab.lp().style.display = t2;
  }
  xb() {
    return this.Xm[0].fp().R_().W().visible;
  }
  Sb() {
    return this.Xm[0].fp().D_().W().visible;
  }
  ob() {
    return "ResizeObserver" in window && (this.ib = new ResizeObserver((t2) => {
      const e2 = t2.find((t3) => t3.target === this.Jd);
      e2 && this._b(e2.contentRect.width, e2.contentRect.height);
    }), this.ib.observe(this.Jd, { box: "border-box" }), true);
  }
  pb() {
    null !== this.ib && this.ib.disconnect(), this.ib = null;
  }
}
function ID(t2) {
  return Boolean(t2.handleScroll.mouseWheel || t2.handleScale.mouseWheel);
}
function BD(t2, e2) {
  var i2 = {};
  for (var s2 in t2) Object.prototype.hasOwnProperty.call(t2, s2) && e2.indexOf(s2) < 0 && (i2[s2] = t2[s2]);
  if (null != t2 && "function" == typeof Object.getOwnPropertySymbols) {
    var n2 = 0;
    for (s2 = Object.getOwnPropertySymbols(t2); n2 < s2.length; n2++) e2.indexOf(s2[n2]) < 0 && Object.prototype.propertyIsEnumerable.call(t2, s2[n2]) && (i2[s2[n2]] = t2[s2[n2]]);
  }
  return i2;
}
function jD(t2, e2, i2, s2) {
  const n2 = i2.value, r2 = { ee: e2, ot: t2, Vt: [n2, n2, n2, n2], zb: s2 };
  return void 0 !== i2.color && (r2.V = i2.color), r2;
}
function HD(t2, e2, i2, s2) {
  const n2 = i2.value, r2 = { ee: e2, ot: t2, Vt: [n2, n2, n2, n2], zb: s2 };
  return void 0 !== i2.lineColor && (r2.lt = i2.lineColor), void 0 !== i2.topColor && (r2.Ps = i2.topColor), void 0 !== i2.bottomColor && (r2.Rs = i2.bottomColor), r2;
}
function qD(t2, e2, i2, s2) {
  const n2 = i2.value, r2 = { ee: e2, ot: t2, Vt: [n2, n2, n2, n2], zb: s2 };
  return void 0 !== i2.topLineColor && (r2.Re = i2.topLineColor), void 0 !== i2.bottomLineColor && (r2.De = i2.bottomLineColor), void 0 !== i2.topFillColor1 && (r2.ke = i2.topFillColor1), void 0 !== i2.topFillColor2 && (r2.ye = i2.topFillColor2), void 0 !== i2.bottomFillColor1 && (r2.Ce = i2.bottomFillColor1), void 0 !== i2.bottomFillColor2 && (r2.Te = i2.bottomFillColor2), r2;
}
function XD(t2, e2, i2, s2) {
  const n2 = { ee: e2, ot: t2, Vt: [i2.open, i2.high, i2.low, i2.close], zb: s2 };
  return void 0 !== i2.color && (n2.V = i2.color), n2;
}
function KD(t2, e2, i2, s2) {
  const n2 = { ee: e2, ot: t2, Vt: [i2.open, i2.high, i2.low, i2.close], zb: s2 };
  return void 0 !== i2.color && (n2.V = i2.color), void 0 !== i2.borderColor && (n2.Ot = i2.borderColor), void 0 !== i2.wickColor && (n2.Xh = i2.wickColor), n2;
}
function UD(t2, e2, i2, s2, n2) {
  const r2 = uz(n2)(i2), o2 = Math.max(...r2), a2 = Math.min(...r2), l2 = r2[r2.length - 1], h2 = [l2, o2, a2, l2], c2 = i2, { time: u2, color: d2 } = c2;
  return { ee: e2, ot: t2, Vt: h2, zb: s2, $e: BD(c2, ["time", "color"]), V: d2 };
}
function YD(t2) {
  return void 0 !== t2.Vt;
}
function GD(t2, e2) {
  return void 0 !== e2.customValues && (t2.jb = e2.customValues), t2;
}
function JD(t2) {
  return (e2, i2, s2, n2, r2, o2) => function(t3, e3) {
    return e3 ? e3(t3) : void 0 === (i3 = t3).open && void 0 === i3.value;
    var i3;
  }(s2, o2) ? GD({ ot: e2, ee: i2, zb: n2 }, s2) : GD(t2(e2, i2, s2, n2, r2), s2);
}
function QD(t2) {
  return { Candlestick: JD(KD), Bar: JD(XD), Area: JD(HD), Baseline: JD(qD), Histogram: JD(jD), Line: JD(jD), Custom: JD(UD) }[t2];
}
function ZD(t2) {
  return { ee: 0, Hb: /* @__PURE__ */ new Map(), la: t2 };
}
function tR(t2, e2) {
  if (void 0 !== t2 && 0 !== t2.length) return { $b: e2.key(t2[0].ot), Ub: e2.key(t2[t2.length - 1].ot) };
}
function eR(t2) {
  let e2;
  return t2.forEach((t3) => {
    void 0 === e2 && (e2 = t3.zb);
  }), uz(e2);
}
class se {
  constructor(t2) {
    this.qb = /* @__PURE__ */ new Map(), this.Yb = /* @__PURE__ */ new Map(), this.Zb = /* @__PURE__ */ new Map(), this.Xb = [], this.q_ = t2;
  }
  S() {
    this.qb.clear(), this.Yb.clear(), this.Zb.clear(), this.Xb = [];
  }
  Kb(t2, e2) {
    let i2 = 0 !== this.qb.size, s2 = false;
    const n2 = this.Yb.get(t2);
    if (void 0 !== n2) if (1 === this.Yb.size) i2 = false, s2 = true, this.qb.clear();
    else for (const e3 of this.Xb) e3.pointData.Hb.delete(t2) && (s2 = true);
    let r2 = [];
    if (0 !== e2.length) {
      const i3 = e2.map((t3) => t3.time), n3 = this.q_.createConverterToInternalObj(e2), o3 = QD(t2.Qh()), a2 = t2.Ca(), l2 = t2.Ta();
      r2 = e2.map((e3, r3) => {
        const h2 = n3(e3.time), c2 = this.q_.key(h2);
        let u2 = this.qb.get(c2);
        void 0 === u2 && (u2 = ZD(h2), this.qb.set(c2, u2), s2 = true);
        const d2 = o3(h2, u2.ee, e3, i3[r3], a2, l2);
        return u2.Hb.set(t2, d2), d2;
      });
    }
    i2 && this.Gb(), this.Jb(t2, r2);
    let o2 = -1;
    if (s2) {
      const t3 = [];
      this.qb.forEach((e3) => {
        t3.push({ timeWeight: 0, time: e3.la, pointData: e3, originalTime: eR(e3.Hb) });
      }), t3.sort((t4, e3) => this.q_.key(t4.time) - this.q_.key(e3.time)), o2 = this.Qb(t3);
    }
    return this.tw(t2, o2, function(t3, e3, i3) {
      const s3 = tR(t3, i3), n3 = tR(e3, i3);
      if (void 0 !== s3 && void 0 !== n3) return { ta: s3.Ub >= n3.Ub && s3.$b >= n3.$b };
    }(this.Yb.get(t2), n2, this.q_));
  }
  vd(t2) {
    return this.Kb(t2, []);
  }
  iw(t2, e2) {
    const i2 = e2;
    !function(t3) {
      void 0 === t3.zb && (t3.zb = t3.time);
    }(i2), this.q_.preprocessData(e2);
    const s2 = this.q_.createConverterToInternalObj([e2])(e2.time), n2 = this.Zb.get(t2);
    if (void 0 !== n2 && this.q_.key(s2) < this.q_.key(n2)) throw new Error(`Cannot update oldest data, last time=${n2}, new time=${s2}`);
    let r2 = this.qb.get(this.q_.key(s2));
    const o2 = void 0 === r2;
    void 0 === r2 && (r2 = ZD(s2), this.qb.set(this.q_.key(s2), r2));
    const a2 = QD(t2.Qh()), l2 = t2.Ca(), h2 = t2.Ta(), c2 = a2(s2, r2.ee, e2, i2.zb, l2, h2);
    r2.Hb.set(t2, c2), this.nw(t2, c2);
    const u2 = { ta: YD(c2) };
    if (!o2) return this.tw(t2, -1, u2);
    const d2 = { timeWeight: 0, time: r2.la, pointData: r2, originalTime: eR(r2.Hb) }, f2 = i$(this.Xb, this.q_.key(d2.time), (t3, e3) => this.q_.key(t3.time) < e3);
    this.Xb.splice(f2, 0, d2);
    for (let t3 = f2; t3 < this.Xb.length; ++t3) iR(this.Xb[t3].pointData, t3);
    return this.q_.fillWeightsForPoints(this.Xb, f2), this.tw(t2, f2, u2);
  }
  nw(t2, e2) {
    let i2 = this.Yb.get(t2);
    void 0 === i2 && (i2 = [], this.Yb.set(t2, i2));
    const s2 = 0 !== i2.length ? i2[i2.length - 1] : null;
    null === s2 || this.q_.key(e2.ot) > this.q_.key(s2.ot) ? YD(e2) && i2.push(e2) : YD(e2) ? i2[i2.length - 1] = e2 : i2.splice(-1, 1), this.Zb.set(t2, e2.ot);
  }
  Jb(t2, e2) {
    0 !== e2.length ? (this.Yb.set(t2, e2.filter(YD)), this.Zb.set(t2, e2[e2.length - 1].ot)) : (this.Yb.delete(t2), this.Zb.delete(t2));
  }
  Gb() {
    for (const t2 of this.Xb) 0 === t2.pointData.Hb.size && this.qb.delete(this.q_.key(t2.time));
  }
  Qb(t2) {
    let e2 = -1;
    for (let i2 = 0; i2 < this.Xb.length && i2 < t2.length; ++i2) {
      const s2 = this.Xb[i2], n2 = t2[i2];
      if (this.q_.key(s2.time) !== this.q_.key(n2.time)) {
        e2 = i2;
        break;
      }
      n2.timeWeight = s2.timeWeight, iR(n2.pointData, i2);
    }
    if (-1 === e2 && this.Xb.length !== t2.length && (e2 = Math.min(this.Xb.length, t2.length)), -1 === e2) return -1;
    for (let i2 = e2; i2 < t2.length; ++i2) iR(t2[i2].pointData, i2);
    return this.q_.fillWeightsForPoints(t2, e2), this.Xb = t2, e2;
  }
  sw() {
    if (0 === this.Yb.size) return null;
    let t2 = 0;
    return this.Yb.forEach((e2) => {
      0 !== e2.length && (t2 = Math.max(t2, e2[e2.length - 1].ee));
    }), t2;
  }
  tw(t2, e2, i2) {
    const s2 = { ew: /* @__PURE__ */ new Map(), St: { Eu: this.sw() } };
    if (-1 !== e2) this.Yb.forEach((e3, n2) => {
      s2.ew.set(n2, { $e: e3, rw: n2 === t2 ? i2 : void 0 });
    }), this.Yb.has(t2) || s2.ew.set(t2, { $e: [], rw: i2 }), s2.St.hw = this.Xb, s2.St.lw = e2;
    else {
      const e3 = this.Yb.get(t2);
      s2.ew.set(t2, { $e: e3 || [], rw: i2 });
    }
    return s2;
  }
}
function iR(t2, e2) {
  t2.ee = e2, t2.Hb.forEach((t3) => {
    t3.ee = e2;
  });
}
function sR(t2) {
  const e2 = { value: t2.Vt[3], time: t2.zb };
  return void 0 !== t2.jb && (e2.customValues = t2.jb), e2;
}
function nR(t2) {
  const e2 = sR(t2);
  return void 0 !== t2.V && (e2.color = t2.V), e2;
}
function rR(t2) {
  const e2 = sR(t2);
  return void 0 !== t2.lt && (e2.lineColor = t2.lt), void 0 !== t2.Ps && (e2.topColor = t2.Ps), void 0 !== t2.Rs && (e2.bottomColor = t2.Rs), e2;
}
function oR(t2) {
  const e2 = sR(t2);
  return void 0 !== t2.Re && (e2.topLineColor = t2.Re), void 0 !== t2.De && (e2.bottomLineColor = t2.De), void 0 !== t2.ke && (e2.topFillColor1 = t2.ke), void 0 !== t2.ye && (e2.topFillColor2 = t2.ye), void 0 !== t2.Ce && (e2.bottomFillColor1 = t2.Ce), void 0 !== t2.Te && (e2.bottomFillColor2 = t2.Te), e2;
}
function aR(t2) {
  const e2 = { open: t2.Vt[0], high: t2.Vt[1], low: t2.Vt[2], close: t2.Vt[3], time: t2.zb };
  return void 0 !== t2.jb && (e2.customValues = t2.jb), e2;
}
function lR(t2) {
  const e2 = aR(t2);
  return void 0 !== t2.V && (e2.color = t2.V), e2;
}
function hR(t2) {
  const e2 = aR(t2), { V: i2, Ot: s2, Xh: n2 } = t2;
  return void 0 !== i2 && (e2.color = i2), void 0 !== s2 && (e2.borderColor = s2), void 0 !== n2 && (e2.wickColor = n2), e2;
}
function cR(t2) {
  return { Area: rR, Line: nR, Baseline: oR, Histogram: nR, Bar: lR, Candlestick: hR, Custom: uR }[t2];
}
function uR(t2) {
  const e2 = t2.zb;
  return Object.assign(Object.assign({}, t2.$e), { time: e2 });
}
const dR = { vertLine: { color: "#9598A1", width: 1, style: 3, visible: true, labelVisible: true, labelBackgroundColor: "#131722" }, horzLine: { color: "#9598A1", width: 1, style: 3, visible: true, labelVisible: true, labelBackgroundColor: "#131722" }, mode: 1 }, fR = { vertLines: { color: "#D6DCDE", style: 0, visible: true }, horzLines: { color: "#D6DCDE", style: 0, visible: true } }, pR = { background: { type: "solid", color: "#FFFFFF" }, textColor: "#191919", fontSize: 12, fontFamily: Pz, attributionLogo: true }, mR = { autoScale: true, mode: 0, invertScale: false, alignLabels: true, borderVisible: true, borderColor: "#2B2B43", entireTextOnly: false, visible: false, ticksVisible: false, scaleMargins: { bottom: 0.1, top: 0.2 }, minimumWidth: 0 }, gR = { rightOffset: 0, barSpacing: 6, minBarSpacing: 0.5, fixLeftEdge: false, fixRightEdge: false, lockVisibleTimeRangeOnResize: false, rightBarStaysOnScroll: false, borderVisible: true, borderColor: "#2B2B43", visible: true, timeVisible: false, secondsVisible: true, shiftVisibleRangeOnNewBar: true, allowShiftVisibleRangeOnWhitespaceReplacement: false, ticksVisible: false, uniformDistribution: false, minimumHeight: 0, allowBoldLabels: true }, vR = { color: "rgba(0, 0, 0, 0)", visible: false, fontSize: 48, fontFamily: Pz, fontStyle: "", text: "", horzAlign: "center", vertAlign: "center" };
function bR() {
  return { width: 0, height: 0, autoSize: false, layout: pR, crosshair: dR, grid: fR, overlayPriceScales: Object.assign({}, mR), leftPriceScale: Object.assign(Object.assign({}, mR), { visible: false }), rightPriceScale: Object.assign(Object.assign({}, mR), { visible: true }), timeScale: gR, watermark: vR, localization: { locale: uD ? navigator.language : "", dateFormat: "dd MMM 'yy" }, handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true }, handleScale: { axisPressedMouseMove: { time: true, price: true }, axisDoubleClickReset: { time: true, price: true }, mouseWheel: true, pinch: true }, kineticScroll: { mouse: false, touch: true }, trackingMode: { exitMode: 1 } };
}
class Me {
  constructor(t2, e2) {
    this.aw = t2, this.ow = e2;
  }
  applyOptions(t2) {
    this.aw.$t().$c(this.ow, t2);
  }
  options() {
    return this.Li().W();
  }
  width() {
    return jz(this.ow) ? this.aw.Mb(this.ow) : 0;
  }
  Li() {
    return dz(this.aw.$t().Uc(this.ow)).Dt;
  }
}
function _R(t2, e2, i2) {
  const s2 = BD(t2, ["time", "originalTime"]), n2 = Object.assign({ time: e2 }, s2);
  return void 0 !== i2 && (n2.originalTime = i2), n2;
}
const yR = { color: "#FF0000", price: 0, lineStyle: 2, lineWidth: 1, lineVisible: true, axisLabelVisible: true, title: "", axisLabelColor: "", axisLabelTextColor: "" };
class ke {
  constructor(t2) {
    this.Nh = t2;
  }
  applyOptions(t2) {
    this.Nh.$h(t2);
  }
  options() {
    return this.Nh.W();
  }
  _w() {
    return this.Nh;
  }
}
class ye {
  constructor(t2, e2, i2, s2, n2) {
    this.uw = new D(), this.Es = t2, this.cw = e2, this.dw = i2, this.q_ = n2, this.fw = s2;
  }
  S() {
    this.uw.S();
  }
  priceFormatter() {
    return this.Es.ba();
  }
  priceToCoordinate(t2) {
    const e2 = this.Es.Ct();
    return null === e2 ? null : this.Es.Dt().Rt(t2, e2.Vt);
  }
  coordinateToPrice(t2) {
    const e2 = this.Es.Ct();
    return null === e2 ? null : this.Es.Dt().pn(t2, e2.Vt);
  }
  barsInLogicalRange(t2) {
    if (null === t2) return null;
    const e2 = new yn(new xn(t2.from, t2.to)).lu(), i2 = this.Es.In();
    if (i2.Ni()) return null;
    const s2 = i2.ll(e2.Os(), 1), n2 = i2.ll(e2.ui(), -1), r2 = dz(i2.el()), o2 = dz(i2.An());
    if (null !== s2 && null !== n2 && s2.ee > n2.ee) return { barsBefore: t2.from - r2, barsAfter: o2 - t2.to };
    const a2 = { barsBefore: null === s2 || s2.ee === r2 ? t2.from - r2 : s2.ee - r2, barsAfter: null === n2 || n2.ee === o2 ? o2 - t2.to : o2 - n2.ee };
    return null !== s2 && null !== n2 && (a2.from = s2.zb, a2.to = n2.zb), a2;
  }
  setData(t2) {
    this.q_, this.Es.Qh(), this.cw.pw(this.Es, t2), this.mw("full");
  }
  update(t2) {
    this.Es.Qh(), this.cw.bw(this.Es, t2), this.mw("update");
  }
  dataByIndex(t2, e2) {
    const i2 = this.Es.In().ll(t2, e2);
    return null === i2 ? null : cR(this.seriesType())(i2);
  }
  data() {
    const t2 = cR(this.seriesType());
    return this.Es.In().ne().map((e2) => t2(e2));
  }
  subscribeDataChanged(t2) {
    this.uw.l(t2);
  }
  unsubscribeDataChanged(t2) {
    this.uw.v(t2);
  }
  setMarkers(t2) {
    this.q_;
    const e2 = t2.map((t3) => _R(t3, this.q_.convertHorzItemToInternal(t3.time), t3.time));
    this.Es.na(e2);
  }
  markers() {
    return this.Es.sa().map((t2) => _R(t2, t2.originalTime, void 0));
  }
  applyOptions(t2) {
    this.Es.$h(t2);
  }
  options() {
    return Dz(this.Es.W());
  }
  priceScale() {
    return this.dw.priceScale(this.Es.Dt().Pa());
  }
  createPriceLine(t2) {
    const e2 = Mz(Dz(yR), t2), i2 = this.Es.ea(e2);
    return new ke(i2);
  }
  removePriceLine(t2) {
    this.Es.ra(t2._w());
  }
  seriesType() {
    return this.Es.Qh();
  }
  attachPrimitive(t2) {
    this.Es.ka(t2), t2.attached && t2.attached({ chart: this.fw, series: this, requestUpdate: () => this.Es.$t().Kl() });
  }
  detachPrimitive(t2) {
    this.Es.ya(t2), t2.detached && t2.detached();
  }
  mw(t2) {
    this.uw.M() && this.uw.m(t2);
  }
}
class Ce {
  constructor(t2, e2, i2) {
    this.ww = new D(), this.mu = new D(), this.Om = new D(), this.$i = t2, this.yl = t2.St(), this.ab = e2, this.yl.nc().l(this.gw.bind(this)), this.yl.sc().l(this.Mw.bind(this)), this.ab.Nm().l(this.xw.bind(this)), this.q_ = i2;
  }
  S() {
    this.yl.nc().p(this), this.yl.sc().p(this), this.ab.Nm().p(this), this.ww.S(), this.mu.S(), this.Om.S();
  }
  scrollPosition() {
    return this.yl.Hu();
  }
  scrollToPosition(t2, e2) {
    e2 ? this.yl.Ju(t2, 1e3) : this.$i.Jn(t2);
  }
  scrollToRealTime() {
    this.yl.Gu();
  }
  getVisibleRange() {
    const t2 = this.yl.Vu();
    return null === t2 ? null : { from: t2.from.originalTime, to: t2.to.originalTime };
  }
  setVisibleRange(t2) {
    const e2 = { from: this.q_.convertHorzItemToInternal(t2.from), to: this.q_.convertHorzItemToInternal(t2.to) }, i2 = this.yl.Iu(e2);
    this.$i.pd(i2);
  }
  getVisibleLogicalRange() {
    const t2 = this.yl.Du();
    return null === t2 ? null : { from: t2.Os(), to: t2.ui() };
  }
  setVisibleLogicalRange(t2) {
    cz(t2.from <= t2.to, "The from index cannot be after the to index."), this.$i.pd(t2);
  }
  resetTimeScale() {
    this.$i.Kn();
  }
  fitContent() {
    this.$i.hc();
  }
  logicalToCoordinate(t2) {
    const e2 = this.$i.St();
    return e2.Ni() ? null : e2.It(t2);
  }
  coordinateToLogical(t2) {
    return this.yl.Ni() ? null : this.yl.Nu(t2);
  }
  timeToCoordinate(t2) {
    const e2 = this.q_.convertHorzItemToInternal(t2), i2 = this.yl.Va(e2, false);
    return null === i2 ? null : this.yl.It(i2);
  }
  coordinateToTime(t2) {
    const e2 = this.$i.St(), i2 = e2.Nu(t2), s2 = e2.Ui(i2);
    return null === s2 ? null : s2.originalTime;
  }
  width() {
    return this.ab.um().width;
  }
  height() {
    return this.ab.um().height;
  }
  subscribeVisibleTimeRangeChange(t2) {
    this.ww.l(t2);
  }
  unsubscribeVisibleTimeRangeChange(t2) {
    this.ww.v(t2);
  }
  subscribeVisibleLogicalRangeChange(t2) {
    this.mu.l(t2);
  }
  unsubscribeVisibleLogicalRangeChange(t2) {
    this.mu.v(t2);
  }
  subscribeSizeChange(t2) {
    this.Om.l(t2);
  }
  unsubscribeSizeChange(t2) {
    this.Om.v(t2);
  }
  applyOptions(t2) {
    this.yl.$h(t2);
  }
  options() {
    return Object.assign(Object.assign({}, Dz(this.yl.W())), { barSpacing: this.yl.le() });
  }
  gw() {
    this.ww.M() && this.ww.m(this.getVisibleRange());
  }
  Mw() {
    this.mu.M() && this.mu.m(this.getVisibleLogicalRange());
  }
  xw(t2) {
    this.Om.m(t2.width, t2.height);
  }
}
function xR(t2) {
  return function(t3) {
    if ($z(t3.handleScale)) {
      const e3 = t3.handleScale;
      t3.handleScale = { axisDoubleClickReset: { time: e3, price: e3 }, axisPressedMouseMove: { time: e3, price: e3 }, mouseWheel: e3, pinch: e3 };
    } else if (void 0 !== t3.handleScale) {
      const { axisPressedMouseMove: e3, axisDoubleClickReset: i2 } = t3.handleScale;
      $z(e3) && (t3.handleScale.axisPressedMouseMove = { time: e3, price: e3 }), $z(i2) && (t3.handleScale.axisDoubleClickReset = { time: i2, price: i2 });
    }
    const e2 = t3.handleScroll;
    $z(e2) && (t3.handleScroll = { horzTouchDrag: e2, vertTouchDrag: e2, mouseWheel: e2, pressedMouseMove: e2 });
  }(t2), t2;
}
class Re {
  constructor(t2, e2, i2) {
    this.Sw = /* @__PURE__ */ new Map(), this.kw = /* @__PURE__ */ new Map(), this.yw = new D(), this.Cw = new D(), this.Tw = new D(), this.Pw = new se(e2);
    const s2 = void 0 === i2 ? Dz(bR()) : Mz(Dz(bR()), xR(i2));
    this.q_ = e2, this.aw = new Fs(t2, s2, e2), this.aw.lm().l((t3) => {
      this.yw.M() && this.yw.m(this.Rw(t3()));
    }, this), this.aw.am().l((t3) => {
      this.Cw.M() && this.Cw.m(this.Rw(t3()));
    }, this), this.aw.Xc().l((t3) => {
      this.Tw.M() && this.Tw.m(this.Rw(t3()));
    }, this);
    const n2 = this.aw.$t();
    this.Dw = new Ce(n2, this.aw.fb(), this.q_);
  }
  remove() {
    this.aw.lm().p(this), this.aw.am().p(this), this.aw.Xc().p(this), this.Dw.S(), this.aw.S(), this.Sw.clear(), this.kw.clear(), this.yw.S(), this.Cw.S(), this.Tw.S(), this.Pw.S();
  }
  resize(t2, e2, i2) {
    this.autoSizeActive() || this.aw._b(t2, e2, i2);
  }
  addCustomSeries(t2, e2) {
    const i2 = fz(t2), s2 = Object.assign(Object.assign({}, sz), i2.defaultOptions());
    return this.Vw("Custom", s2, e2, i2);
  }
  addAreaSeries(t2) {
    return this.Vw("Area", tz, t2);
  }
  addBaselineSeries(t2) {
    return this.Vw("Baseline", ez, t2);
  }
  addBarSeries(t2) {
    return this.Vw("Bar", QC, t2);
  }
  addCandlestickSeries(t2 = {}) {
    return function(t3) {
      void 0 !== t3.borderColor && (t3.borderUpColor = t3.borderColor, t3.borderDownColor = t3.borderColor), void 0 !== t3.wickColor && (t3.wickUpColor = t3.wickColor, t3.wickDownColor = t3.wickColor);
    }(t2), this.Vw("Candlestick", JC, t2);
  }
  addHistogramSeries(t2) {
    return this.Vw("Histogram", iz, t2);
  }
  addLineSeries(t2) {
    return this.Vw("Line", ZC, t2);
  }
  removeSeries(t2) {
    const e2 = uz(this.Sw.get(t2)), i2 = this.Pw.vd(e2);
    this.aw.$t().vd(e2), this.Ow(i2), this.Sw.delete(t2), this.kw.delete(e2);
  }
  pw(t2, e2) {
    this.Ow(this.Pw.Kb(t2, e2));
  }
  bw(t2, e2) {
    this.Ow(this.Pw.iw(t2, e2));
  }
  subscribeClick(t2) {
    this.yw.l(t2);
  }
  unsubscribeClick(t2) {
    this.yw.v(t2);
  }
  subscribeCrosshairMove(t2) {
    this.Tw.l(t2);
  }
  unsubscribeCrosshairMove(t2) {
    this.Tw.v(t2);
  }
  subscribeDblClick(t2) {
    this.Cw.l(t2);
  }
  unsubscribeDblClick(t2) {
    this.Cw.v(t2);
  }
  priceScale(t2) {
    return new Me(this.aw, t2);
  }
  timeScale() {
    return this.Dw;
  }
  applyOptions(t2) {
    this.aw.$h(xR(t2));
  }
  options() {
    return this.aw.W();
  }
  takeScreenshot() {
    return this.aw.wb();
  }
  autoSizeActive() {
    return this.aw.kb();
  }
  chartElement() {
    return this.aw.yb();
  }
  paneSize() {
    const t2 = this.aw.Tb();
    return { height: t2.height, width: t2.width };
  }
  setCrosshairPosition(t2, e2, i2) {
    const s2 = this.Sw.get(i2);
    if (void 0 === s2) return;
    const n2 = this.aw.$t().dr(s2);
    null !== n2 && this.aw.$t().ad(t2, e2, n2);
  }
  clearCrosshairPosition() {
    this.aw.$t().od(true);
  }
  Vw(t2, e2, i2 = {}, s2) {
    !function(t3) {
      if (void 0 === t3 || "custom" === t3.type) return;
      const e3 = t3;
      void 0 !== e3.minMove && void 0 === e3.precision && (e3.precision = function(t4) {
        if (t4 >= 1) return 0;
        let e4 = 0;
        for (; e4 < 8; e4++) {
          const i3 = Math.round(t4);
          if (Math.abs(i3 - t4) < 1e-8) return e4;
          t4 *= 10;
        }
        return e4;
      }(e3.minMove));
    }(i2.priceFormat);
    const n2 = Mz(Dz(nz), Dz(e2), i2), r2 = this.aw.$t().dd(t2, n2, s2), o2 = new ye(r2, this, this, this, this.q_);
    return this.Sw.set(o2, r2), this.kw.set(r2, o2), o2;
  }
  Ow(t2) {
    const e2 = this.aw.$t();
    e2._d(t2.St.Eu, t2.St.hw, t2.St.lw), t2.ew.forEach((t3, e3) => e3.J(t3.$e, t3.rw)), e2.Wu();
  }
  Bw(t2) {
    return uz(this.kw.get(t2));
  }
  Rw(t2) {
    const e2 = /* @__PURE__ */ new Map();
    t2.Nb.forEach((t3, i3) => {
      const s2 = i3.Qh(), n2 = cR(s2)(t3);
      if ("Custom" !== s2) cz(function(t4) {
        return function(t5) {
          return void 0 !== t5.open;
        }(t4) || function(t5) {
          return void 0 !== t5.value;
        }(t4);
      }(n2));
      else {
        const t4 = i3.Ta();
        cz(!t4 || false === t4(n2));
      }
      e2.set(this.Bw(i3), n2);
    });
    const i2 = void 0 !== t2.Eb && this.kw.has(t2.Eb) ? this.Bw(t2.Eb) : void 0;
    return { time: t2.zb, logical: t2.ee, point: t2.Lb, hoveredSeries: i2, hoveredObjectId: t2.Fb, seriesData: e2, sourceEvent: t2.Wb };
  }
}
function wR(t2, e2) {
  return function(t3, e3, i2) {
    let s2;
    if (zz(t3)) {
      const e4 = document.getElementById(t3);
      cz(null !== e4, `Cannot find element in DOM with id=${t3}`), s2 = e4;
    } else s2 = t3;
    const n2 = new Re(s2, e3, i2);
    return e3.setOptions(n2.options()), n2;
  }(t2, new is(), is.Id(e2));
}
Object.assign(Object.assign({}, nz), sz);
class TwChart {
  constructor(t2, e2) {
    this.series = [], this.priceLines = [], this.colors = ["#725bf5", "#777777", "#1dcdbc", "#2b3440", "#ffffff", "#3abff8", "#36d399", "#fbbd23", "#f87272"], this.lightTheme = { layout: { textColor: "rgba(0, 0, 0, 0.7)" }, timeScale: { borderColor: "rgba(0, 0, 0, 0.1)", timeVisible: true, secondsVisible: false } }, this.darkTheme = { layout: { textColor: "rgba(255, 255, 255, 0.7)" }, timeScale: { borderColor: "rgba(255, 255, 255, 0.1)", timeVisible: true, secondsVisible: false } }, this.selectTheme = { light: this.lightTheme, dark: this.darkTheme }, this.candlestickSeries = null, this.htmlEle = t2, this.series = [];
    let i2 = { autoSize: true, localization: { locale: "zh-TW", dateFormat: "yyyy-MM-dd", priceFormatter: (t3) => t3.toFixed(2) }, rightPriceScale: { scaleMargins: { top: 0.1, bottom: 0.1 }, visible: true, mode: j$.Normal, borderVisible: false, ticksVisible: true, borderColor: "rgba(197, 203, 206, 0.4)" }, leftPriceScale: { scaleMargins: { top: 0.1, bottom: 0.1 }, visible: true, mode: j$.Normal, borderVisible: false, ticksVisible: true, borderColor: "red" }, timeScale: { borderColor: "red", borderVisible: false }, handleScroll: { pressedMouseMove: true, mouseWheel: false }, handleScale: { mouseWheel: false, pinch: true }, layout: { background: { type: J$.Solid, color: "transparent" } }, grid: { vertLines: { color: "rgba(197, 203, 206, 0.0)", style: oz.Dotted, visible: false }, horzLines: { color: "rgba(197, 203, 206, 0.0)", style: oz.Dotted, visible: false } }, crosshair: { horzLine: { visible: false, labelVisible: true }, vertLine: { visible: false, style: 0, width: 2, color: "rgba(32, 38, 46, 0.1)", labelVisible: true } } };
    i2.rightPriceScale.mode = e2 ? j$.Percentage : j$.Normal, i2.leftPriceScale.visible = false, this.chart = wR(this.htmlEle, i2);
  }
  setTheme(t2) {
    t2 && this.chart.applyOptions(this.selectTheme[t2]);
  }
  _updateLeftPriceScaleVisibility() {
    const t2 = this.series.some((t3) => {
      if (!t3) return false;
      try {
        return "left" === t3.options().priceScaleId;
      } catch (t4) {
        return false;
      }
    });
    this.chart.applyOptions({ leftPriceScale: { visible: t2 } });
  }
  resetAreaSeries(t2, e2 = "right") {
    if (this.series[t2]) try {
      this.chart.removeSeries(this.series[t2]);
    } catch (e3) {
      console.warn(`Could not remove series at index ${t2}:`, e3);
    }
    const i2 = this.colors[t2 % this.colors.length];
    this.series[t2] = this.chart.addAreaSeries({ lineColor: i2, topColor: i2 + "77", bottomColor: i2 + "00", priceLineVisible: false, priceScaleId: e2 }), this._updateLeftPriceScaleVisibility();
  }
  updatePriceLines(t2, e2) {
    this.series[t2] && this.priceLines.forEach((e3) => {
      try {
        this.series[t2].removePriceLine(e3);
      } catch (t3) {
        console.warn("Could not remove price line:", t3);
      }
    }), this.priceLines = [], this.series[t2] ? e2.forEach((e3) => {
      const i2 = this.series[t2].createPriceLine(e3);
      this.priceLines.push(i2);
    }) : console.warn(`Series at index ${t2} does not exist. Cannot add price lines.`);
  }
  setTimeScale(t2, e2) {
    this.chart.timeScale().setVisibleRange({ from: t2.getTime() / 1e3, to: e2.getTime() / 1e3 });
  }
  addCandlestickSeries() {
    this.candlestickSeries && this.chart.removeSeries(this.candlestickSeries), this.candlestickSeries = this.chart.addCandlestickSeries({ upColor: "#f43098", downColor: "#00d3bb", borderDownColor: "#00d3bb", borderUpColor: "#f43098", wickDownColor: "#00d3bb", wickUpColor: "#f43098" });
  }
  updateCandlestickSeriesData(t2) {
    if (this.candlestickSeries) {
      const e2 = t2.map((t3) => {
        let e3;
        return "string" != typeof t3.time ? null : (e3 = t3.time, { time: e3, open: t3.open, high: t3.high, low: t3.low, close: t3.close });
      }).filter((t3) => null !== t3);
      this.candlestickSeries.setData(e2), this.chart.timeScale().scrollToRealTime();
    }
  }
  addTradeMarkers(t2, e2, i2) {
    if (!this.chart || !this.candlestickSeries) return;
    let s2 = [];
    t2.forEach((t3) => {
      s2.push({ time: t3.time, position: "belowBar", color: i2, shape: "arrowUp", text: "進場" });
    }), 0 !== e2.length && e2.forEach((t3) => {
      s2.push({ time: t3.time, position: "aboveBar", color: i2, shape: "arrowDown", text: `Sell @ ${t3.price}` });
    }), this.candlestickSeries && this.candlestickSeries.setMarkers(s2);
  }
}
function kR(t2, e2) {
  if ("#" === t2[0]) {
    const i3 = Math.round(255 * e2).toString(16).padStart(2, "0");
    return `${t2.slice(0, 7)}${i3}`;
  }
  if (t2.startsWith("rgb")) {
    const i3 = t2.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!i3) throw new Error(`Invalid RGB color format: ${t2}`);
    return `rgba(${parseInt(i3[1])}, ${parseInt(i3[2])}, ${parseInt(i3[3])}, ${e2})`;
  }
  const i2 = t2.match(/^oklch\(([^)]+)\)/);
  if (!i2) return t2;
  const s2 = i2[1].split(/\s+/);
  if (s2.length < 3) throw new Error(`Incomplete OKLCH components in: ${t2}`);
  return `oklch(${s2[0]} ${s2[1]} ${s2[2]} / ${e2})`;
}
function MR() {
  return "undefined" == typeof document ? "" : (document.documentElement.getAttribute("data-theme"), getComputedStyle(document.documentElement).getPropertyValue("--color-error"));
}
function SR() {
  return "undefined" == typeof document ? "" : (document.documentElement.getAttribute("data-theme"), getComputedStyle(document.documentElement).getPropertyValue("--color-success"));
}
function CR(t2) {
  return 0 === t2 ? "undefined" == typeof document ? "#6b7280" : "dark" === document.documentElement.getAttribute("data-theme") ? "#d1d5db" : "#6b7280" : t2 > 0 ? MR() : SR();
}
function zR(t2) {
  return "undefined" == typeof document ? "" : getComputedStyle(document.documentElement).getPropertyValue("--color-" + t2);
}
function $R(t2) {
  return 0 === t2 ? "text-base-content-100" : t2 > 0 ? "text-error" : "text-success";
}
const DR = { light: "light", dark: "dark", cupcake: "light", bumblebee: "light", emerald: "light", corporate: "light", synthwave: "dark", retro: "light", cyberpunk: "dark", valentine: "light", halloween: "dark", garden: "light", forest: "dark", aqua: "light", lofi: "dark", pastel: "light", fantasy: "light", wireframe: "light", black: "dark", luxury: "dark", dracula: "dark", cmyk: "light", autumn: "dark", business: "dark", acid: "light", lemonade: "light", night: "dark", coffee: "dark", winter: "light", dim: "dark", nord: "light", sunset: "dark", caramellatte: "light", abyss: "dark", silk: "light" }, RR = Mr("dark");
function ER(t2) {
  if (!t2) return "dark";
  return "dark" === DR[t2] ? "dark" : "light";
}
const PR = { xmlns: "http://www.w3.org/2000/svg", width: 24, height: 24, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linecap": "round", "stroke-linejoin": "round" };
var TR = Es("<svg><!><!></svg>");
function LR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = Rr(i2, ["name", "color", "size", "strokeWidth", "absoluteStrokeWidth", "iconNode"]);
  G(e2, false);
  let n2 = Lr(e2, "name", 12, void 0), r2 = Lr(e2, "color", 12, "currentColor"), o2 = Lr(e2, "size", 12, 24), a2 = Lr(e2, "strokeWidth", 12, 2), l2 = Lr(e2, "absoluteStrokeWidth", 12, false), h2 = Lr(e2, "iconNode", 28, () => []);
  yr();
  var c2 = TR();
  ir(c2, (t3, e3) => ({ ...PR, ...s2, width: o2(), height: o2(), stroke: r2(), "stroke-width": t3, class: e3 }), [() => l2() ? 24 * Number(a2()) / Number(o2()) : a2(), () => ((...t3) => t3.filter((t4, e3, i3) => Boolean(t4) && i3.indexOf(t4) === e3).join(" "))("lucide-icon", "lucide", n2() ? `lucide-${n2()}` : "", i2.class)]);
  var u2 = me(c2);
  return hn(u2, 1, h2, ln, (t3, e3) => {
    var i3 = mt(() => _(hs(e3), 2));
    var s3 = Ts();
    Sn(ge(s3), () => hs(i3)[0], 0, (t4, e4) => {
      ir(t4, () => ({ ...hs(i3)[1] }));
    }), As(t3, s3);
  }), bn(ve(u2), e2, "default", {}, null), ie(c2), As(t2, c2), J({ get name() {
    return n2();
  }, set name(t3) {
    n2(t3), rs();
  }, get color() {
    return r2();
  }, set color(t3) {
    r2(t3), rs();
  }, get size() {
    return o2();
  }, set size(t3) {
    o2(t3), rs();
  }, get strokeWidth() {
    return a2();
  }, set strokeWidth(t3) {
    a2(t3), rs();
  }, get absoluteStrokeWidth() {
    return l2();
  }, set absoluteStrokeWidth(t3) {
    l2(t3), rs();
  }, get iconNode() {
    return h2();
  }, set iconNode(t3) {
    h2(t3), rs();
  } });
}
function VR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" }]];
  LR(t2, Pr({ name: "activity" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function OR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m7 7 10 10" }], ["path", { d: "M17 7v10H7" }]];
  LR(t2, Pr({ name: "arrow-down-right" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function AR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M12 5v14" }], ["path", { d: "m19 12-7 7-7-7" }]];
  LR(t2, Pr({ name: "arrow-down" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function FR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M7 7h10v10" }], ["path", { d: "M7 17 17 7" }]];
  LR(t2, Pr({ name: "arrow-up-right" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function NR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m5 12 7-7 7 7" }], ["path", { d: "M12 19V5" }]];
  LR(t2, Pr({ name: "arrow-up" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function WR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M8 2v4" }], ["path", { d: "M16 2v4" }], ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2" }], ["path", { d: "M3 10h18" }]];
  LR(t2, Pr({ name: "calendar" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function IR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M3 3v16a2 2 0 0 0 2 2h16" }], ["path", { d: "m19 9-5 5-4-4-3 3" }]];
  LR(t2, Pr({ name: "chart-line" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function BR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["line", { x1: "12", x2: "12", y1: "20", y2: "10" }], ["line", { x1: "18", x2: "18", y1: "20", y2: "4" }], ["line", { x1: "6", x2: "6", y1: "20", y2: "16" }]];
  LR(t2, Pr({ name: "chart-no-axes-column-increasing" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function jR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["line", { x1: "18", x2: "18", y1: "20", y2: "10" }], ["line", { x1: "12", x2: "12", y1: "20", y2: "4" }], ["line", { x1: "6", x2: "6", y1: "20", y2: "14" }]];
  LR(t2, Pr({ name: "chart-no-axes-column" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function HR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m6 9 6 6 6-6" }]];
  LR(t2, Pr({ name: "chevron-down" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function qR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m18 15-6-6-6 6" }]];
  LR(t2, Pr({ name: "chevron-up" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function XR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["line", { x1: "12", x2: "12", y1: "2", y2: "22" }], ["path", { d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" }]];
  LR(t2, Pr({ name: "dollar-sign" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function KR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m21 21-6-6m6 6v-4.8m0 4.8h-4.8" }], ["path", { d: "M3 16.2V21m0 0h4.8M3 21l6-6" }], ["path", { d: "M21 7.8V3m0 0h-4.8M21 3l-6 6" }], ["path", { d: "M3 7.8V3m0 0h4.8M3 3l6 6" }]];
  LR(t2, Pr({ name: "expand" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function UR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M8 3v3a2 2 0 0 1-2 2H3" }], ["path", { d: "M21 8h-3a2 2 0 0 1-2-2V3" }], ["path", { d: "M3 16h3a2 2 0 0 1 2 2v3" }], ["path", { d: "M16 21v-3a2 2 0 0 1 2-2h3" }]];
  LR(t2, Pr({ name: "minimize" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function YR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["line", { x1: "19", x2: "5", y1: "5", y2: "19" }], ["circle", { cx: "6.5", cy: "6.5", r: "2.5" }], ["circle", { cx: "17.5", cy: "17.5", r: "2.5" }]];
  LR(t2, Pr({ name: "percent" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function GR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["circle", { cx: "11", cy: "11", r: "8" }], ["path", { d: "m21 21-4.3-4.3" }]];
  LR(t2, Pr({ name: "search" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function JR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["polyline", { points: "22 17 13.5 8.5 8.5 13.5 2 7" }], ["polyline", { points: "16 17 22 17 22 11" }]];
  LR(t2, Pr({ name: "trending-down" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function QR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["polyline", { points: "22 7 13.5 15.5 8.5 10.5 2 17" }], ["polyline", { points: "16 7 22 7 22 13" }]];
  LR(t2, Pr({ name: "trending-up" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
function ZR(t2, e2) {
  const i2 = Rr(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" }], ["path", { d: "M12 9v4" }], ["path", { d: "M12 17h.01" }]];
  LR(t2, Pr({ name: "triangle-alert" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Ts();
    bn(ge(s3), e2, "default", {}, null), As(t3, s3);
  }, $$slots: { default: true } }));
}
Ar(LR, { name: {}, color: {}, size: {}, strokeWidth: {}, absoluteStrokeWidth: {}, iconNode: {} }, ["default"], [], true), Ar(VR, {}, ["default"], [], true), Ar(OR, {}, ["default"], [], true), Ar(AR, {}, ["default"], [], true), Ar(FR, {}, ["default"], [], true), Ar(NR, {}, ["default"], [], true), Ar(WR, {}, ["default"], [], true), Ar(IR, {}, ["default"], [], true), Ar(BR, {}, ["default"], [], true), Ar(jR, {}, ["default"], [], true), Ar(HR, {}, ["default"], [], true), Ar(qR, {}, ["default"], [], true), Ar(XR, {}, ["default"], [], true), Ar(KR, {}, ["default"], [], true), Ar(UR, {}, ["default"], [], true), Ar(YR, {}, ["default"], [], true), Ar(GR, {}, ["default"], [], true), Ar(JR, {}, ["default"], [], true), Ar(QR, {}, ["default"], [], true), Ar(ZR, {}, ["default"], [], true);
const tE = (t2) => t2;
function eE(t2) {
  const e2 = t2 - 1;
  return e2 * e2 * e2 + 1;
}
function iE(t2) {
  const e2 = "string" == typeof t2 && t2.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return e2 ? [parseFloat(e2[1]), e2[2] || "px"] : [t2, "px"];
}
function sE(t2, { delay: e2 = 0, duration: i2 = 400, easing: s2 = tE } = {}) {
  const n2 = +getComputedStyle(t2).opacity;
  return { delay: e2, duration: i2, easing: s2, css: (t3) => "opacity: " + t3 * n2 };
}
function nE(t2, { delay: e2 = 0, duration: i2 = 400, easing: s2 = eE, x: n2 = 0, y: r2 = 0, opacity: o2 = 0 } = {}) {
  const a2 = getComputedStyle(t2), l2 = +a2.opacity, h2 = "none" === a2.transform ? "" : a2.transform, c2 = l2 * (1 - o2), [u2, d2] = iE(n2), [f2, p2] = iE(r2);
  return { delay: e2, duration: i2, easing: s2, css: (t3, e3) => `
			transform: ${h2} translate(${(1 - t3) * u2}${d2}, ${(1 - t3) * f2}${p2});
			opacity: ${l2 - c2 * e3}` };
}
var rE = Rs("<div><!></div>"), oE = Rs("<div><!></div>"), aE = Rs("<div><!></div>"), lE = Rs("<div><!></div>"), hE = Rs("<div><!></div>"), cE = Rs('<div class="flex flex-col items-end"><div class="text-xs text-base-content/50">MAE</div> <div class="font-medium"> </div></div>'), uE = Rs('<div class="flex flex-col items-end"><div class="text-xs text-base-content/50">GMFE</div> <div class="font-medium"> </div></div>'), dE = Rs('<div class="grid grid-cols-12 p-4 gap-3 hover:bg-base-100 group relative transition-all cursor-pointer border-l-4 border-transparent hover:border-primary"><div class="col-span-2 flex items-center"><div class="font-medium text-base-content group-hover:text-primary transition-colors"> </div></div> <div class="col-span-2 flex items-center"><div class="flex items-center gap-2"><div class="w-8 h-8 rounded-lg flex items-center justify-center"><!></div> <div class="font-medium"> </div></div></div> <div class="col-span-2 flex items-center"><div class="flex flex-col"><div class="font-medium"> </div> <div class="text-xs text-base-content/50"> </div></div></div> <div class="col-span-2 flex items-center"><div class="flex flex-col"><div class="font-medium"> </div> <div class="text-xs text-base-content/50"> </div></div></div> <div class="col-span-2 flex items-center"><div class="font-medium"> </div></div> <div class="col-span-2 flex items-center justify-end gap-3"><!> <!></div></div>'), fE = Rs('<button class="join-item btn btn-sm btn-disabled">...</button>'), pE = Rs("<button> </button>"), mE = Rs('<div class="overflow-hidden rounded-xl border border-base-200 bg-base-100 shadow-sm"><div class="bg-base-200/50 grid grid-cols-12 p-4 gap-3 text-base-content/70 text-sm font-medium"><div class="col-span-2 flex items-center gap-1 cursor-pointer hover:text-primary transition-colors"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer hover:text-primary transition-colors"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer hover:text-primary transition-colors"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer hover:text-primary transition-colors"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer hover:text-primary transition-colors"> <!></div> <div class="col-span-2 text-center">指標</div></div> <div class="grid grid-cols-1 divide-y divide-base-200"><!> <div class="p-4 flex justify-center items-center border-t border-base-200"><div class="join"><button><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"></path></svg></button> <!> <button><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg></button></div> <div class="ml-4 text-sm text-base-content/70"> </div></div></div></div>'), gE = Rs('<div class="flex items-center gap-2 text-base-content/70 p-3 bg-base-200/50 rounded-lg"><!> <p> <code class="px-2 py-1 mx-1 bg-neutral rounded-md text-neutral-content font-mono">report.trades</code> </p></div>'), vE = Rs('<p class="text-base-content/70"></p>'), bE = Rs('<div class="flex flex-col items-center justify-center p-12 text-center bg-base-100 border border-base-200 rounded-xl shadow-sm"><div class="w-16 h-16 mb-6 rounded-full bg-base-200/80 flex items-center justify-center"><!></div> <h3 class="text-xl font-medium mb-3 text-base-content"></h3> <!></div>'), _E = Rs('<div class="mb-12"><!></div>');
function yE(t2, e2) {
  G(e2, false);
  const i2 = Mt(), s2 = Mt(), n2 = Mt(), r2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return WC[e3] ? WC[e3]() : e3;
  };
  let o2 = Lr(e2, "browser", 12), a2 = Lr(e2, "report", 12), l2 = Lr(e2, "theme", 12, "light"), h2 = Lr(e2, "candle", 12, "red"), c2 = Lr(e2, "tstart", 12, null), u2 = Lr(e2, "tend", 12, null);
  en(() => {
    o2();
  });
  const d2 = (t3) => t3 ? t3 == null ? void 0 : t3.toLocaleDateString() : "-";
  let f2 = Mt("entry"), p2 = Mt("dn"), m2 = Mt([]), g2 = Mt(1), v2 = Mt(1), b2 = Mt([]);
  function _2(t3) {
    t3 >= 1 && t3 <= hs(v2) && zt(g2, t3);
  }
  function y2() {
    const t3 = [], e3 = [];
    let i3;
    for (let e4 = 1; e4 <= hs(v2); e4++) (1 === e4 || e4 === hs(v2) || e4 >= hs(g2) - 2 && e4 <= hs(g2) + 2) && t3.push(e4);
    return t3.forEach((t4) => {
      i3 && (t4 - i3 === 2 ? e3.push(i3 + 1) : t4 - i3 !== 1 && e3.push("...")), e3.push(t4), i3 = t4;
    }), e3;
  }
  const x2 = (t3) => {
    if (null == t3) return "-";
    const e3 = Math.abs(100 * t3).toFixed(1);
    return e3.endsWith(".0") ? Math.abs(100 * t3).toFixed(0) + "%" : e3 + "%";
  };
  function w2(t3) {
    return null == t3 ? { color: "text-base-content/50", bgColor: "bg-base-300/20", icon: null } : t3 > 0.3 ? { color: `color: ${CR(1)}`, bgColor: `background-color: ${kR(CR(1), 0.1)}`, icon: FR } : t3 > 0 ? { color: `color: ${CR(1)}`, bgColor: `background-color: ${kR(CR(1), 0.05)}`, icon: QR } : t3 > -0.2 ? { color: `color: ${CR(-1)}`, bgColor: `background-color: ${kR(CR(-1), 0.05)}`, icon: OR } : { color: `color: ${CR(-1)}`, bgColor: `background-color: ${kR(CR(-1), 0.1)}`, icon: JR };
  }
  $e(() => (fs(a2()), fs(c2()), fs(u2()), hs(m2), hs(p2), hs(f2), hs(v2), hs(g2)), () => {
    if (a2() || c2() || u2()) {
      zt(m2, a2().trades), c2() && u2() && zt(m2, a2().trades.filter((t4) => {
        const e4 = t4.entry, i3 = t4.entry >= c2() & t4.entry <= u2(), s3 = t4.exit >= c2() & t4.exit <= u2();
        return e4 && i3 || s3;
      })), zt(m2, hs(m2).filter((t4) => Object.entries(t4).every(([t5, e4]) => "exit" === t5 || "exitSig" === t5 || null !== e4))), zt(m2, hs(m2).sort((t4, e4) => "up" === hs(p2) ? t4[hs(f2)] > e4[hs(f2)] ? 1 : -1 : t4[hs(f2)] < e4[hs(f2)] ? 1 : -1)), zt(v2, Math.ceil(hs(m2).length / 10)), hs(g2) > hs(v2) && zt(g2, 1);
      const t3 = 10 * (hs(g2) - 1), e3 = Math.min(t3 + 10, hs(m2).length);
      zt(b2, hs(m2).slice(t3, e3)), zt(n2, hs(m2).length > 10);
    }
  }), $e(() => hs(m2), () => {
    zt(i2, hs(m2).length > 0 ? hs(m2)[0].entry : null);
  }), $e(() => (fs(c2()), hs(i2)), () => {
    zt(s2, c2() > hs(i2));
  }), $e(() => {
  }, () => {
    zt(n2, true);
  }), De(), yr();
  var k2 = Ts(), M2 = ge(k2), S2 = (t3) => {
    var e3 = _E(), i3 = me(e3), n3 = (t4) => {
      var e4 = mE(), i4 = me(e4), s3 = me(i4), n4 = me(s3), o4 = ve(n4), a3 = (t5) => {
        var e5 = rE(), i5 = me(e5), s4 = (t6) => {
          HR(t6, { size: 14 });
        }, n5 = (t6) => {
          qR(t6, { size: 14 });
        };
        on(i5, (t6) => {
          "dn" === hs(p2) ? t6(s4) : t6(n5, false);
        }), ie(e5), dr(1, e5, () => sE, () => ({ duration: 150 })), As(t5, e5);
      };
      on(o4, (t5) => {
        "stockId" === hs(f2) && t5(a3);
      }), ie(s3);
      var l3 = ve(s3, 2), h3 = me(l3), c3 = ve(h3), u3 = (t5) => {
        var e5 = oE(), i5 = me(e5), s4 = (t6) => {
          HR(t6, { size: 14 });
        }, n5 = (t6) => {
          qR(t6, { size: 14 });
        };
        on(i5, (t6) => {
          "dn" === hs(p2) ? t6(s4) : t6(n5, false);
        }), ie(e5), dr(1, e5, () => sE, () => ({ duration: 150 })), As(t5, e5);
      };
      on(c3, (t5) => {
        "return" === hs(f2) && t5(u3);
      }), ie(l3);
      var k3 = ve(l3, 2), M3 = me(k3), S3 = ve(M3), C2 = (t5) => {
        var e5 = aE(), i5 = me(e5), s4 = (t6) => {
          HR(t6, { size: 14 });
        }, n5 = (t6) => {
          qR(t6, { size: 14 });
        };
        on(i5, (t6) => {
          "dn" === hs(p2) ? t6(s4) : t6(n5, false);
        }), ie(e5), dr(1, e5, () => sE, () => ({ duration: 150 })), As(t5, e5);
      };
      on(S3, (t5) => {
        "entry" === hs(f2) && t5(C2);
      }), ie(k3);
      var z2 = ve(k3, 2), R2 = me(z2), E2 = ve(R2), P2 = (t5) => {
        var e5 = lE(), i5 = me(e5), s4 = (t6) => {
          HR(t6, { size: 14 });
        }, n5 = (t6) => {
          qR(t6, { size: 14 });
        };
        on(i5, (t6) => {
          "dn" === hs(p2) ? t6(s4) : t6(n5, false);
        }), ie(e5), dr(1, e5, () => sE, () => ({ duration: 150 })), As(t5, e5);
      };
      on(E2, (t5) => {
        "exit" === hs(f2) && t5(P2);
      }), ie(z2);
      var T2 = ve(z2, 2), L2 = me(T2), V2 = ve(L2), O2 = (t5) => {
        var e5 = hE(), i5 = me(e5), s4 = (t6) => {
          HR(t6, { size: 14 });
        }, n5 = (t6) => {
          qR(t6, { size: 14 });
        };
        on(i5, (t6) => {
          "dn" === hs(p2) ? t6(s4) : t6(n5, false);
        }), ie(e5), dr(1, e5, () => sE, () => ({ duration: 150 })), As(t5, e5);
      };
      on(V2, (t5) => {
        "position" === hs(f2) && t5(O2);
      }), ie(T2), ne(2), ie(i4);
      var A2 = ve(i4, 2), F2 = me(A2);
      hn(F2, 1, () => hs(b2), ln, (t5, e5, i5) => {
        var s4 = dE();
        const n5 = gt(() => w2(hs(e5).return)), r3 = gt(() => w2(hs(e5).position));
        var o5 = me(s4), a4 = me(o5), l4 = me(a4, true);
        ie(a4), ie(o5);
        var h4 = ve(o5, 2), c4 = me(h4), u4 = me(c4), f3 = me(u4), p3 = (t6) => {
          var e6 = Ts();
          _n(ge(e6), () => hs(n5).icon, (t7, e7) => {
            e7(t7, { size: 14, get style() {
              return hs(n5).color;
            } });
          }), As(t6, e6);
        };
        on(f3, (t6) => {
          hs(n5).icon && t6(p3);
        }), ie(u4);
        var m3 = ve(u4, 2), g3 = me(m3, true);
        ie(m3), ie(c4), ie(h4);
        var v3 = ve(h4, 2), b3 = me(v3), _3 = me(b3), y3 = me(_3, true);
        ie(_3);
        var k4 = ve(_3, 2), M4 = me(k4, true);
        ie(k4), ie(b3), ie(v3);
        var S4 = ve(v3, 2), C3 = me(S4), z3 = me(C3), R3 = me(z3, true);
        ie(z3);
        var E3 = ve(z3, 2), P3 = me(E3, true);
        ie(E3), ie(C3), ie(S4);
        var T3 = ve(S4, 2), L3 = me(T3), V3 = me(L3, true);
        ie(L3), ie(T3);
        var O3 = ve(T3, 2), A3 = me(O3), F3 = (t6) => {
          var i6 = cE(), s5 = ve(me(i6), 2), n6 = me(s5, true);
          ie(s5), ie(i6), Pe((t7, e6) => {
            In(s5, t7), Us(n6, e6);
          }, [() => `color: ${CR(hs(e5).mae)}`, () => x2(hs(e5).mae)], gt), As(t6, i6);
        };
        on(A3, (t6) => {
          void 0 !== hs(e5).mae && null !== hs(e5).mae && t6(F3);
        });
        var N3 = ve(A3, 2), I3 = (t6) => {
          var i6 = uE(), s5 = ve(me(i6), 2), n6 = me(s5, true);
          ie(s5), ie(i6), Pe((t7, e6) => {
            In(s5, t7), Us(n6, e6);
          }, [() => `color: ${CR(hs(e5).gmfe)}`, () => x2(hs(e5).gmfe)], gt), As(t6, i6);
        };
        on(N3, (t6) => {
          void 0 !== hs(e5).gmfe && null !== hs(e5).gmfe && t6(I3);
        }), ie(O3), ie(s4), Pe((t6, i6, s5, o6) => {
          Us(l4, hs(e5).stockId || "-"), In(u4, hs(n5).bgColor), In(m3, hs(n5).color), Us(g3, t6), Us(y3, i6), Us(M4, hs(e5).entryPrice ? `$${hs(e5).entryPrice}` : ""), Us(R3, s5), Us(P3, hs(e5).exitPrice ? `$${hs(e5).exitPrice}` : ""), In(L3, hs(r3).color), Us(V3, o6);
        }, [() => x2(hs(e5).return), () => d2(hs(e5).entry), () => d2(hs(e5).exit), () => x2(hs(e5).position)], gt), dr(1, s4, () => nE, () => ({ y: 20, duration: 300, delay: 30 * i5 })), As(t5, s4);
      });
      var N2 = ve(F2, 2), I2 = me(N2), B2 = me(I2), q2 = ve(B2, 2);
      hn(q2, 1, y2, ln, (t5, e5) => {
        var i5 = Ts(), s4 = ge(i5), n5 = (t6) => {
          As(t6, fE());
        }, r3 = (t6) => {
          var i6 = pE(), s5 = me(i6, true);
          ie(i6), Pe(() => {
            Nn(i6, 1, "join-item btn btn-sm " + (hs(g2) === hs(e5) ? "btn-active" : "")), Us(s5, hs(e5));
          }), Ms("click", i6, () => _2(hs(e5))), As(t6, i6);
        };
        on(s4, (t6) => {
          "..." === hs(e5) ? t6(n5) : t6(r3, false);
        }), As(t5, i5);
      });
      var K2 = ve(q2, 2);
      ie(I2);
      var U2 = ve(I2, 2), G2 = me(U2, true);
      ie(U2), ie(N2), ie(A2), ie(e4), Pe((t5, e5, i5, s4, r3) => {
        Us(n4, `${t5 ?? ""} `), Us(h3, `${e5 ?? ""} `), Us(M3, `${i5 ?? ""} `), Us(R2, `${s4 ?? ""} `), Us(L2, `${r3 ?? ""} `), Nn(B2, 1, "join-item btn btn-sm " + (1 === hs(g2) ? "btn-disabled" : "")), B2.disabled = 1 === hs(g2), Nn(K2, 1, "join-item btn btn-sm " + (hs(g2) === hs(v2) ? "btn-disabled" : "")), K2.disabled = hs(g2) === hs(v2), Us(G2, `第 ${hs(g2)} 頁，共 ${hs(v2)} 頁 (${hs(m2).length} 筆交易)`);
      }, [() => r2("metrics.stocks.stockId"), () => r2("metrics.stocks.return"), () => r2("metrics.stocks.entry"), () => r2("metrics.stocks.exit"), () => r2("metrics.stocks.position")], gt), Ms("click", s3, () => {
        "stockId" !== hs(f2) ? zt(f2, "stockId") : zt(p2, "up" === hs(p2) ? "dn" : "up");
      }), Ms("click", l3, () => {
        "return" !== hs(f2) ? zt(f2, "return") : zt(p2, "up" === hs(p2) ? "dn" : "up");
      }), Ms("click", k3, () => {
        "entry" !== hs(f2) ? zt(f2, "entry") : zt(p2, "up" === hs(p2) ? "dn" : "up");
      }), Ms("click", z2, () => {
        "exit" !== hs(f2) ? zt(f2, "exit") : zt(p2, "up" === hs(p2) ? "dn" : "up");
      }), Ms("click", T2, () => {
        "position" !== hs(f2) ? zt(f2, "position") : zt(p2, "up" === hs(p2) ? "dn" : "up");
      }), Ms("click", B2, () => _2(hs(g2) - 1)), Ms("click", K2, () => _2(hs(g2) + 1)), As(t4, e4);
    }, o3 = (t4) => {
      var e4 = bE(), i4 = me(e4);
      GR(me(i4), { class: "w-8 h-8 text-base-content/50" }), ie(i4);
      var n4 = ve(i4, 2);
      n4.textContent = "沒有交易記錄";
      var r3 = ve(n4, 2), o4 = (t5) => {
        var e5 = gE(), i5 = me(e5);
        ZR(i5, { size: 16, class: "text-warning" });
        var s3 = ve(i5, 2), n5 = me(s3);
        n5.nodeValue = "網頁資料受限，請使用程式碼 ", ve(n5, 2).nodeValue = " 查看所有紀錄", ie(s3), ie(e5), As(t5, e5);
      }, a3 = (t5) => {
        var e5 = vE();
        e5.textContent = "這段時間沒有交易，請選擇其他時間範圍", As(t5, e5);
      };
      on(r3, (t5) => {
        hs(s2) ? t5(o4) : t5(a3, false);
      }), ie(e4), dr(1, e4, () => sE, () => ({ duration: 300 })), As(t4, e4);
    };
    on(i3, (t4) => {
      0 !== hs(m2).length ? t4(n3) : t4(o3, false);
    }), ie(e3), As(t3, e3);
  };
  return on(M2, (t3) => {
    a2() && 0 != a2().trades.length && t3(S2);
  }), As(t2, k2), J({ get browser() {
    return o2();
  }, set browser(t3) {
    o2(t3), rs();
  }, get report() {
    return a2();
  }, set report(t3) {
    a2(t3), rs();
  }, get theme() {
    return l2();
  }, set theme(t3) {
    l2(t3), rs();
  }, get candle() {
    return h2();
  }, set candle(t3) {
    h2(t3), rs();
  }, get tstart() {
    return c2();
  }, set tstart(t3) {
    c2(t3), rs();
  }, get tend() {
    return u2();
  }, set tend(t3) {
    u2(t3), rs();
  } });
}
Ar(yE, { browser: {}, report: {}, theme: {}, candle: {}, tstart: {}, tend: {} }, [], [], true);
var xE = Rs('<div class="absolute bg-primary/10 rounded-lg text-center whitespace-nowrap text-base-content text-sm flex justify-center items-start pt-2"> </div>'), wE = Rs('<button><div class="flex flex-col items-center"><span class="font-light"> </span> <span> </span></div></button>'), kE = Es('<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"></path></svg>'), ME = Es('<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"></path></svg>'), SE = Rs('<div class="flex justify-center items-center"> </div>'), CE = Rs("<div> </div>"), zE = Rs('<div class="h-12 flex justify-start items-center"> </div> <!> <div class="flex justify-center items-center border border-base-content/0"> </div>', 1), $E = Rs('<div class="col-span-14 text-center mt-3 text-xs text-base-content-200"> </div>'), DE = Rs('<div class="grid grid-cols-6 mx-6 md:mx-12 gap-6 md:12 lg:gap-24"><div class="col-span-6 md:col-span-6"><div class="mb-12"><div><div class="text-3xl font-light text-base-content/70"> </div></div> <div class="relative overflow-hidden -mt-6"><div class="text-primary h-64 z-0"></div> <!> <div class="mt-6 @md:text-right"><h3 class="text-lg font-light text-base-content/70 mb-3">年度表現</h3> <div class="carousel carousel-center max-w-full space-x-2 overflow-x-auto"><button class="carousel-item px-5 py-3 rounded-lg border border-base-content/20 hover:shadow-md transition-all duration-300 cursor-pointer"><div class="flex flex-col items-center"><span class="text-medium"> </span> <span class="text-sm"> </span></div></button> <!> <button class="carousel-item px-5 py-3 rounded-lg border border-base-content/20 hover:shadow-md transition-all duration-300 cursor-pointer"><div class="flex flex-col items-center"><span class="font-medium">全部</span> <span class="text-sm">重設時間</span></div></button></div></div></div></div></div> <div class="col-span-6 md:col-span-6"><div><div><div class="text-3xl font-light text-base-content/70 mb-3"> </div> <div class="card-content"><div class="stats"><div class="stat pl-0"><div class="stat-title"> </div> <div class="text-3xl font-light"><span> </span></div> <div class="stat-desc"> </div></div> <div class="stat"><div class="stat-title"> </div> <div class="text-3xl font-light"><span> </span></div> <div class="stat-desc"> </div></div></div> <div class="relative"><div class="flex justify-between items-center mb-2 -mt-12"><div class="text-base-content-200"></div> <button class="btn btn-sm btn-ghost"><!></button></div> <div><div class="grid grid-cols-14 mt-3 text-xs text-base-content-200 rounded-xl min-w-[640px] pb-4 overflow-y-hidden svelte-13tqbdu"><div class="h-5 md:h-10 flex justify-start items-center"> </div> <!> <div class="flex justify-center items-center"></div> <!> <!></div></div></div></div></div></div></div> <div class="col-span-6 md:col-span-6"><div><div><div class="text-3xl font-light text-base-content/70 mb-6"> </div> <div class="text-base-content/70 text-xl mb-3"><!></div> <div class="relative"><div><!></div></div></div></div></div> <div class="col-span-6 md:col-span-3"><div><div><div class="text-3xl font-light text-base-content/70 mb-6"> </div> <div><div class="stat-title"> </div> <div class="text-3xl font-light"> <span class="stat-desc"> </span></div></div> <div><div class="text-sm mt-3 flex"><div class="badge rounded bg-primary text-white mr-2"> </div> <div class="badge rounded bg-gray-500 text-white"> </div></div> <canvas class="h-48 mt-6" style="width:580px"></canvas></div></div></div></div> <div class="col-span-6 md:col-span-3"><div><div><div class="text-3xl font-light text-base-content/70 mb-6"> </div> <div class="text-base-content-100"><div class=" pl-0"><div class="stat-title"> </div> <div class="text-3xl font-light gap-2"> </div></div> <div class="text-sm mt-3 flex"><div class="badge rounded badge-primary text-white"> </div></div> <canvas class="h-48 mt-6" style="width:580px"></canvas></div></div></div></div></div>');
const RE = { hash: "svelte-13tqbdu", code: ".grid-cols-14.svelte-13tqbdu {grid-template-columns:repeat(14, minmax(0, 1fr));}" };
function EE(t2, e2) {
  G(e2, false), Cn(t2, RE);
  const i2 = Mt(), s2 = Mt(), n2 = Mt(), r2 = Mt(), o2 = Mt(), a2 = Mt(), l2 = Mt(), h2 = Mt(), c2 = Mt(), u2 = Mt(), d2 = Mt(), f2 = Mt(), p2 = Mt(), m2 = Mt(), g2 = Mt();
  Chart.register(LinearScale, BarController, CategoryScale, BarElement, ud);
  let v2 = Lr(e2, "browser", 12), b2 = Lr(e2, "report", 12), _2 = Lr(e2, "theme", 12, "light"), y2 = Lr(e2, "showAll", 12, true);
  const x2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return WC[e3] ? WC[e3]() : e3;
  };
  void 0 !== window && (window.report = b2());
  let w2 = Mt(), k2 = Mt(null);
  en(() => {
    T2("all"), et2();
  }), sn(() => {
    Q2 && Q2.destroy(), tt2 && tt2.destroy();
  });
  let M2 = Mt(null), S2 = Mt(null), C2 = Mt(null), z2 = Mt(y2() ? null : hs(s2)), R2 = Mt();
  function E2() {
    if (hs(C2) && hs(z2) && b2() && hs(k2) && hs(w2)) {
      const t3 = `${hs(z2)}-${hs(C2) < 10 ? `0${hs(C2)}` : String(hs(C2))}-01`, e3 = `${hs(z2)}-${hs(C2) + 1 < 10 ? `0${hs(C2) + 1}` : String(hs(C2) + 1)}-01`, i3 = b2().indexOfTimestamps(t3), s3 = b2().indexOfTimestamps(e3);
      if (!b2().timestamps[i3] | !b2().timestamps[s3]) return;
      const n3 = hs(k2).chart.timeScale().timeToCoordinate(b2().timestamps[i3]), r3 = hs(k2).chart.timeScale().timeToCoordinate(b2().timestamps[s3]);
      n3 && r3 && (Ct(R2, hs(R2).style.height = "80%"), Ct(R2, hs(R2).style.width = r3 - n3 + "px"), Ct(R2, hs(R2).style.left = n3 + "px"), Ct(R2, hs(R2).style.top = "0"));
    }
  }
  async function P2(t3, e3) {
    if (!hs(k2)) return;
    const i3 = b2().indexOfTimestamps(t3), s3 = b2().indexOfTimestamps(e3);
    hs(k2).setTimeScale(new Date(b2().timestamps[i3]), new Date(b2().timestamps[s3]));
  }
  function T2(t3) {
    hs(k2) || zt(k2, new TwChart(hs(w2), true)), hs(k2).setTheme(ER(_2()));
    const e3 = "all" === t3 ? b2().timestamps.length : 100, i3 = b2().timestamps.length / (e3 / 100), s3 = b2().createTradingviewSeries("strategy", 0, -1, i3), n3 = b2().createTradingviewSeries("benchmark", 0, -1, i3);
    hs(k2).resetAreaSeries(0), hs(k2).resetAreaSeries(1), hs(k2).series[0].setData(s3), hs(k2).series[1].setData(n3), hs(k2).chart.subscribeCrosshairMove((t4) => {
      const e4 = new Date(t4.time);
      zt(M2, e4.getMonth() + 1), zt(S2, e4.getFullYear() || hs(S2));
    }), hs(k2).chart.subscribeClick((t4) => {
      const e4 = new Date(t4.time);
      zt(C2, e4.getMonth() + 1), zt(z2, e4.getFullYear()), E2();
    }), hs(k2).chart.timeScale().subscribeVisibleTimeRangeChange((t4) => {
      E2();
    }), "all" === t3 ? hs(k2).setTimeScale(new Date(b2().timestamps[0]), new Date(b2().timestamps[b2().timestamps.length - 1])) : hs(k2);
  }
  function L2(t3) {
    return t3 > 0 ? "+" + String(t3) : t3;
  }
  function V2(t3) {
    return 0 === t3.length ? 0 : t3[0] + V2(t3.slice(1));
  }
  let O2 = Mt(null), A2 = Mt(null);
  function F2(t3) {
    if (!t3 || 0 == t3) return "rgba(0,0,0,0)";
    let e3 = t3 > 0 ? t3 / hs(l2) : t3 / hs(h2);
    e3 = Math.min(0.6, Math.abs(e3));
    return kR(t3 > 0 ? MR() : SR(), e3);
  }
  function N2(t3) {
    if (!t3 || 0 == t3) return "rgba(0,0,0,0)";
    let e3 = Math.abs(t3 > 0 ? t3 / hs(m2) : t3 / hs(p2)) / 2;
    return kR(t3 > 0 ? MR() : SR(), e3);
  }
  let I2 = Mt(null), B2 = Mt(null), q2 = Mt(null);
  let K2 = Mt(), U2 = Mt(), Q2 = null, tt2 = null;
  function et2() {
    if (!v2()) return;
    if (!hs(d2)) return;
    if (!hs(g2)) return;
    Q2 && Q2.destroy(), tt2 && tt2.destroy();
    const t3 = function(t4, e4) {
      const i4 = Object.keys(t4), s4 = {}, n3 = i4.reduce((i5, n4) => {
        const r3 = t4[n4] - e4[n4];
        return s4[n4] = r3, i5 + r3;
      }, 0) / i4.length;
      return { result: s4, mean: n3 };
    }(hs(d2), hs(g2));
    zt(I2, t3.mean), zt(B2, Object.values(t3.result).filter((t4) => t4 > 0).length), zt(q2, Object.values(t3.result).length - hs(B2));
    const e3 = Object.keys(hs(d2)), i3 = hs(K2).getContext("2d");
    Q2 = new Chart(i3, { type: "bar", data: { labels: e3, datasets: [{ label: x2("profitability.yearlyReturn"), data: Object.values(hs(d2)), backgroundColor: "light" === ER(_2()) ? "#725bf5" : "#7a64f5", borderWidth: 0, borderRadius: 200 }, { label: x2("profitability.benchmarkYearlyReturn"), data: Object.values(hs(g2)), backgroundColor: "#777777AA", borderWidth: 0, borderRadius: 200 }] }, options: { responsive: true, maintainAspectRatio: true, layout: { padding: 0 }, plugins: { legend: { display: false }, tooltip: {} }, scales: { y: { beginAtZero: true, ticks: { callback: (t4, e4, i4) => (100 * t4).toFixed() + "%", color: "light" === ER(_2()) ? "#000000aa" : "#FFFFFFaa", display: false }, grid: { color: "#77777755", display: false }, border: { display: false } }, x: { ticks: { color: "light" === ER(_2()) ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", display: false }, border: { display: false } } } } });
    const s3 = hs(U2).getContext("2d");
    tt2 = new Chart(s3, { type: "bar", data: { labels: e3, datasets: [{ label: x2("profitability.exceedReturn"), data: Object.values(t3.result), backgroundColor: "light" === ER(_2()) ? "#725bf5" : "#7a64f5", borderColor: "#725bf5", borderWidth: 0, borderRadius: 200 }] }, options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { callback: (t4, e4, i4) => (100 * t4).toFixed() + "%", color: "light" === ER(_2()) ? "#000000aa" : "#FFFFFFaa", display: false }, grid: { color: "#77777755", tickBorderDash: [2, 2], display: false }, border: { display: false } }, x: { ticks: { color: "light" === ER(_2()) ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2], display: false }, border: { display: false } } } } });
  }
  let at2 = Mt(false);
  $e(() => fs(_2()), () => {
    _2() && et2();
  }), $e(() => fs(b2()), () => {
    zt(i2, new Date(b2().timestamps[0]).getFullYear());
  }), $e(() => fs(b2()), () => {
    zt(s2, new Date(b2().timestamps[b2().timestamps.length - 1]).getFullYear());
  }), $e(() => (hs(z2), hs(C2)), () => {
    zt(n2, hs(z2) ? new Date(new Date(hs(z2), (hs(C2) || 1) - 1)) : null);
  }), $e(() => (hs(z2), hs(C2)), () => {
    zt(r2, hs(z2) ? new Date(new Date(hs(z2), hs(C2) || 12) - 864e5) : null);
  }), $e(() => (hs(k2), fs(_2())), () => {
    hs(k2) && hs(k2).setTheme(ER(_2()));
  }), $e(() => fs(b2()), () => {
    zt(o2, b2().calculateMonthlyReturn("strategy"));
  }), $e(() => hs(o2), () => {
    zt(a2, Object.values(hs(o2)).filter((t3) => t3 == t3));
  }), $e(() => hs(a2), () => {
    zt(l2, Math.max(...hs(a2)));
  }), $e(() => hs(a2), () => {
    zt(h2, Math.min(...hs(a2)));
  }), $e(() => hs(a2), () => {
    zt(c2, V2(hs(a2)) / hs(a2).length);
  }), $e(() => hs(a2), () => {
    zt(u2, hs(a2).filter((t3) => t3 > 0).length / hs(a2).length * 100);
  }), $e(() => fs(b2()), () => {
    zt(d2, b2().calculateAnnualReturn("strategy"));
  }), $e(() => hs(d2), () => {
    zt(f2, Object.values(hs(d2)).filter((t3) => t3 == t3));
  }), $e(() => hs(f2), () => {
    zt(p2, Math.min(...hs(f2)));
  }), $e(() => hs(f2), () => {
    zt(m2, Math.max(...hs(f2)));
  }), $e(() => fs(b2()), () => {
    zt(g2, b2().calculateAnnualReturn("benchmark"));
  }), $e(() => (hs(o2), fs(_2())), () => {
    (hs(o2) || _2()) && zt(O2, Object.fromEntries(Object.keys(hs(o2)).map((t3) => [t3, F2(hs(o2)[t3])])));
  }), $e(() => (hs(d2), fs(_2())), () => {
    (hs(d2) || _2()) && zt(A2, Object.fromEntries(Object.keys(hs(d2)).map((t3) => [t3, N2(hs(d2)[t3])])));
  }), De(), yr();
  var ct2 = DE(), dt2 = me(ct2), mt2 = me(dt2), bt2 = me(mt2), _t3 = me(bt2), yt2 = me(_t3, true);
  ie(_t3), ie(bt2);
  var xt2 = ve(bt2, 2), wt2 = me(xt2);
  _r(wt2, (t3) => zt(w2, t3), () => hs(w2));
  var kt2 = ve(wt2, 2), Rt2 = (t3) => {
    var e3 = xE(), i3 = me(e3);
    ie(e3), _r(e3, (t4) => zt(R2, t4), () => hs(R2)), Pe(() => Us(i3, `${hs(z2) ?? ""}-${(hs(C2) < 10 ? "0" + hs(C2) : hs(C2)) ?? ""}`)), As(t3, e3);
  };
  on(kt2, (t3) => {
    hs(C2) && hs(z2) && t3(Rt2);
  });
  var Lt2 = ve(kt2, 2), Ot2 = ve(me(Lt2), 2), At2 = me(Ot2), It2 = me(At2), Bt2 = me(It2), Gt2 = me(Bt2, true);
  ie(Bt2);
  var te2 = ve(Bt2, 2);
  me(te2, true).nodeValue = "年份", ie(te2), ie(It2), ie(At2);
  var ee2 = ve(At2, 2);
  hn(ee2, 1, () => Array.from(Array(hs(s2) + 1).keys()).slice(hs(i2)).filter((t3) => hs(at2) || t3 > hs(s2) - 5), ln, (t3, e3) => {
    var i3 = wE(), s3 = me(i3), n3 = me(s3), r3 = me(n3, true);
    ie(n3);
    var o3 = ve(n3, 2), a3 = me(o3);
    ie(o3), ie(s3), ie(i3), Pe((t4, s4) => {
      Nn(i3, 1, `cursor-pointer carousel-item px-5 py-3 rounded-lg border transition-all duration-300
									${hs(S2) === hs(e3) ? "border-primary shadow-sm" : "border-base-content/20"}
									hover:shadow-md`, "svelte-13tqbdu"), Us(r3, hs(e3)), Nn(o3, 1, t4, "svelte-13tqbdu"), Us(a3, `${s4 ?? ""}%`);
    }, [() => En($R(hs(d2)[hs(e3)])), () => (100 * hs(d2)[hs(e3)] || 0).toFixed(1)], gt), Ms("click", i3, () => {
      T2("year"), P2(hs(e3) - 1 + "-12-31", `${hs(e3)}-12-31`), zt(S2, hs(e3));
    }), As(t3, i3);
  });
  var ne2 = ve(ee2, 2);
  ie(Ot2), ie(Lt2), ie(xt2), ie(mt2), ie(dt2);
  var re2 = ve(dt2, 2), oe2 = me(re2), ae2 = me(oe2), le2 = me(ae2), he2 = me(le2, true);
  ie(le2);
  var ce2 = ve(le2, 2), ue2 = me(ce2), de2 = me(ue2), fe2 = me(de2), pe2 = me(fe2, true);
  ie(fe2);
  var be2 = ve(fe2, 2), _e4 = me(be2), xe2 = me(_e4);
  ie(_e4), ie(be2);
  var we2 = ve(be2, 2), Se2 = me(we2, true);
  ie(we2), ie(de2);
  var ze2 = ve(de2, 2), Ee2 = me(ze2), Te2 = me(Ee2, true);
  ie(Ee2);
  var Le2 = ve(Ee2, 2), Ve2 = me(Le2), Oe2 = me(Ve2);
  ie(Ve2), ie(Le2);
  var Ae2 = ve(Le2, 2), Fe2 = me(Ae2);
  ie(Ae2), ie(ze2), ie(ue2);
  var Ne2 = ve(ue2, 2), We2 = me(Ne2), Ie2 = ve(me(We2), 2), Be2 = me(Ie2), je2 = (t3) => {
    As(t3, kE());
  }, He2 = (t3) => {
    As(t3, ME());
  };
  on(Be2, (t3) => {
    hs(at2) ? t3(je2) : t3(He2, false);
  }), ie(Ie2), ie(We2);
  var qe2 = ve(We2, 2), Xe2 = me(qe2), Ke2 = me(Xe2), Ue2 = me(Ke2, true);
  ie(Ke2);
  var Ye2 = ve(Ke2, 2);
  hn(Ye2, 0, () => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], ln, (t3, e3, i3, s3) => {
    var n3 = SE(), r3 = me(n3);
    ie(n3), Pe(() => Us(r3, `${e3 ?? ""} 月`)), As(t3, n3);
  });
  var Ge2 = ve(Ye2, 4);
  hn(Ge2, 1, () => Array.from(Array(hs(s2) + 1).keys()).slice(hs(i2)).filter((t3) => hs(at2) || t3 > hs(s2) - 5), ln, (t3, e3) => {
    var i3 = zE(), s3 = ge(i3), n3 = me(s3, true);
    ie(s3);
    var r3 = ve(s3, 2);
    hn(r3, 0, () => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], ln, (t4, i4, s4, n4) => {
      var r4 = CE(), a4 = me(r4);
      ie(r4), Pe((t5) => {
        Nn(r4, 1, `cursor-pointer flex justify-center items-center hover:text-base-content-300 hover:z-20 hover:outline hover:shadow-primary hover:outline-2 hover:outline-primary hover:border-none hover:rounded-lg hover:font-bold hover:text-2xl hover:-m-3 hover:shadow-lg 
											${hs(e3) === hs(S2) ? "border-t-2 border-b-2 border-primary" : ""} 											${hs(e3) === hs(S2) && 1 == i4 ? "border-l-2 border-primary rounded-l-lg" : ""} 											${hs(e3) === hs(S2) && 12 == i4 ? "border-r-2 border-primary rounded-r-lg" : ""} 											${i4 === hs(M2) && hs(e3) === hs(S2) ? "text-base-content-300 text-2xl -m-6 font-bold outline shadow-primary outline-2 outline-primary border-none rounded-lg z-20 shadow-2xl" : ""}`, "svelte-13tqbdu"), In(r4, `background:${hs(O2)[`${hs(e3)}${i4}`]}`), Us(a4, `${t5 ?? ""}%`);
      }, [() => L2((100 * (hs(o2)[`${hs(e3)}${i4}`] || 0)).toFixed(1))], gt), Ms("click", r4, () => {
        T2("year"), P2(hs(e3) - 1 + "-12-31", `${hs(e3)}-12-31`), zt(S2, hs(e3)), zt(z2, hs(e3)), zt(C2, i4), E2();
      }), As(t4, r4);
    });
    var a3 = ve(r3, 2), l3 = me(a3, true);
    ie(a3), Pe(() => {
      Us(n3, hs(e3)), Us(l3, hs(e3));
    }), As(t3, i3);
  });
  var Je2 = ve(Ge2, 2), Qe2 = (t3) => {
    var e3 = $E(), n3 = me(e3);
    ie(e3), Pe((t4) => Us(n3, `只顯示 ${t4 ?? ""} 年，如希望看到完整報酬，請點選右上角展開`), [() => Math.min(5, hs(s2) - hs(i2) + 1)], gt), As(t3, e3);
  };
  on(Je2, (t3) => {
    !hs(at2) && hs(s2) - hs(i2) + 1 > 5 && t3(Qe2);
  }), ie(Xe2), ie(qe2), ie(Ne2), ie(ce2), ie(ae2), ie(oe2), ie(re2);
  var Ze2 = ve(re2, 2), ii2 = me(Ze2), oi2 = me(ii2), ui2 = me(oi2), di2 = me(ui2, true);
  ie(ui2);
  var fi2 = ve(ui2, 2), pi2 = me(fi2), mi2 = (t3) => {
    var e3 = Ps();
    Pe((t4, i3) => Us(e3, `${t4 ?? ""}~${i3 ?? ""}`), [() => {
      var _a3;
      return (_a3 = hs(n2)) == null ? void 0 : _a3.toLocaleDateString();
    }, () => {
      var _a3;
      return (_a3 = hs(r2)) == null ? void 0 : _a3.toLocaleDateString();
    }], gt), As(t3, e3);
  };
  on(pi2, (t3) => {
    hs(z2) && t3(mi2);
  }), ie(fi2);
  var gi2 = ve(fi2, 2), vi2 = me(gi2);
  yE(me(vi2), { get report() {
    return b2();
  }, get theme() {
    return _2();
  }, get browser() {
    return v2();
  }, get tstart() {
    return hs(n2);
  }, get tend() {
    return hs(r2);
  } }), ie(vi2), ie(gi2), ie(oi2), ie(ii2), ie(Ze2);
  var bi2 = ve(Ze2, 2), _i2 = me(bi2), xi2 = me(_i2), wi2 = me(xi2), ki2 = me(wi2, true);
  ie(wi2);
  var Si2 = ve(wi2, 2), Ei2 = me(Si2), Pi2 = me(Ei2, true);
  ie(Ei2);
  var Li2 = ve(Ei2, 2), Fi2 = me(Li2), Ii2 = ve(Fi2), Hi2 = me(Ii2, true);
  ie(Ii2), ie(Li2), ie(Si2);
  var Xi2 = ve(Si2, 2), Ki2 = me(Xi2), Yi2 = me(Ki2), Zi2 = me(Yi2, true);
  ie(Yi2);
  var ts2 = ve(Yi2, 2), es2 = me(ts2, true);
  ie(ts2), ie(Ki2), _r(ve(Ki2, 2), (t3) => zt(K2, t3), () => hs(K2)), ie(Xi2), ie(xi2), ie(_i2), ie(bi2);
  var ss2 = ve(bi2, 2), ns2 = me(ss2), ls2 = me(ns2), cs2 = me(ls2), us2 = me(cs2, true);
  ie(cs2);
  var ds2 = ve(cs2, 2), ms2 = me(ds2), gs2 = me(ms2), vs2 = me(gs2, true);
  ie(gs2);
  var bs2 = ve(gs2, 2), _s2 = me(bs2);
  ie(bs2), ie(ms2);
  var ys2 = ve(ms2, 2), xs2 = me(ys2), ws2 = me(xs2, true);
  return ie(xs2), ie(ys2), _r(ve(ys2, 2), (t3) => zt(U2, t3), () => hs(U2)), ie(ds2), ie(ls2), ie(ns2), ie(ss2), ie(ct2), Pe((t3, e3, i3, s3, n3, r3, o3, l3, h3, c3, u3, d3, f3, p3, m3, g3, v3, b3, _3, y3, x3, w3) => {
    Us(yt2, t3), Us(Gt2, hs(at2) ? "收起" : "更多"), Us(he2, e3), Us(pe2, i3), Nn(_e4, 1, s3, "svelte-13tqbdu"), Us(xe2, `${n3 ?? ""}%`), Us(Se2, r3), Us(Te2, o3), Nn(Ve2, 1, l3, "svelte-13tqbdu"), Us(Oe2, `${h3 ?? ""}%`), Us(Fe2, `${c3 ?? ""} / ${hs(a2).length ?? ""}`), er(Ie2, "aria-label", hs(at2) ? "Collapse" : "Expand"), Nn(qe2, 1, u3, "svelte-13tqbdu"), Us(Ue2, d3), Us(di2, f3), Us(ki2, p3), Us(Pi2, m3), Us(Fi2, `${hs(B2) ?? ""} / ${hs(B2) + hs(q2)} `), Us(Hi2, g3), Us(Zi2, v3), Us(es2, b3), Us(us2, _3), Us(vs2, y3), Us(_s2, `${x3 ?? ""}%`), Us(ws2, w3);
  }, [() => x2("profitability.historicalReturn"), () => x2("profitability.monthlyReturn"), () => x2("profitability.avgMonthlyReturn"), () => En($R(hs(c2))), () => L2((100 * hs(c2)).toFixed(2)), () => x2("average"), () => x2("profitability.monthlyWinRatio"), () => En($R(hs(u2) - 0.5)), () => hs(u2).toFixed(1), () => hs(a2).filter((t3) => t3 > 0).length, () => `overflow-x-auto
							${function() {
    const t3 = navigator.userAgent || navigator.vendor;
    return /iPad|iPhone|iPod|android/i.test(t3);
  }() ? "no-scrollbar" : "show-scrollbar"}
						`, () => x2("profitability.monthlyReturn"), () => x2("profitability.stockList"), () => x2("profitability.YearlyCompareWithBenchmark"), () => x2("profitability.yearlyWinRate"), () => x2("profitability.year"), () => x2("strategy"), () => x2("benchmark"), () => x2("profitability.exceedReturn"), () => x2("average"), () => L2((100 * hs(I2)).toFixed(2)), () => x2("strategy")], gt), Ms("click", At2, () => zt(at2, !hs(at2))), Ms("click", ne2, () => {
    T2("all"), P2(0, -1), zt(S2, null);
  }), Ms("click", Ie2, () => zt(at2, !hs(at2))), As(t2, ct2), J({ get browser() {
    return v2();
  }, set browser(t3) {
    v2(t3), rs();
  }, get report() {
    return b2();
  }, set report(t3) {
    b2(t3), rs();
  }, get theme() {
    return _2();
  }, set theme(t3) {
    _2(t3), rs();
  }, get showAll() {
    return y2();
  }, set showAll(t3) {
    y2(t3), rs();
  } });
}
Ar(EE, { browser: {}, report: {}, theme: {}, showAll: {} }, [], [], true);
var PE = Rs("<button>年</button> <button>季</button> <button>月</button>", 1), TE = Rs('<div class="grid grid-cols-6 mx-6 md:mx-12 gap-6 md:12 lg:gap-24 text-base-content-200"><div class="col-span-6 md:col-span-3"><div class="pb-0"><div class="flex items-center"><div class="test-base-content/70 font-light text-3xl mb-6"> <!></div></div> <div><div class="w-full mb-6"><div class="font-light"><div class="text-normal"> </div> <div class="text-3xl"> </div></div></div></div></div> <div class="pl-0 pt-0 pr-0 -mt-8"><div class="h-48"></div></div></div> <div class="col-span-6 md:col-span-3"><div><div class="test-base-content/70 font-light text-3xl mb-6"> </div> <div><span> </span> <div class="w-full overflow-x-auto relative"><div class="text-sm mt-2 flex gap-2"><div class="badge rounded bg-primary text-white"> </div> <div class="badge rounded bg-gray-500 text-white"> </div> <div class="badge rounded bg-[rgba(241,99,102,1)] text-white"> </div></div></div></div></div> <div class="pt-0 pr-0"><canvas class="h-48 mt-6"></canvas></div></div> <div class="col-span-6 md:col-span-3 hidden"><div class="h-48 hidden"></div></div> <div class="col-span-6 md:col-span-3"><div><div class="flex items-end mb-6"><div class="test-base-content/70 font-light text-3xl"> </div> <!></div> <div><div class="w-full mb-6"><div class="font-light"><div class="text-normal"> </div> <div class="text-3xl"> </div></div></div></div></div> <div class="pl-0 pt-0 pr-0 -mt-8"><div class="h-48"></div></div></div> <div class="col-span-6 md:col-span-3"><div><div class="test-base-content/70 font-light text-3xl mb-6"> </div> <div><span> </span> <div class="w-full overflow-x-auto relative"><div class="text-sm mt-3 flex gap-2"><div class="badge rounded badge-primary text-white"> </div> <div class="badge rounded bg-gray-500 text-white"> </div> <div class="badge rounded bg-[rgba(241,99,102,1)] text-white"> </div></div></div></div></div> <div class="pt-0 pr-0"><canvas class="h-48 mt-4" style="width:580px"></canvas></div></div> <div class="col-span-6"><div class="pb-0"><div class="flex items-end mb-6"><div class="test-base-content/70 font-light text-3xl"> </div> <!></div> <div><div class="w-full font-light"><div class="font-normal"> </div> <div class="text-3xl"> </div></div></div></div> <div class="pl-0 pt-0 pr-0"><div class="h-48"></div></div></div> <div class="col-span-6"><div class="pb-0"><div class="flex items-end mb-6"><div class="test-base-content/70 font-light text-3xl">策略與大盤相關性</div> <!></div></div> <div class="pl-0 pt-0 pr-0"><div class="h-48"></div></div></div></div>');
function LE(t2, e2) {
  G(e2, false);
  const i2 = Mt(), s2 = Mt(), n2 = Mt(), r2 = Mt(), o2 = Mt(), a2 = Mt(), l2 = Mt(), h2 = Mt(), c2 = Mt(), u2 = Mt(), d2 = Mt(), f2 = Mt(), p2 = Mt(), m2 = Mt(), g2 = Mt(), v2 = Mt(), b2 = Mt(), _2 = Mt(), y2 = (t3) => {
    var e3 = PE(), i3 = ge(e3);
    let s3;
    var n3 = ve(i3, 2);
    let r3;
    var o3 = ve(n3, 2);
    let a3;
    Pe((t4, e4, l3) => {
      s3 = Nn(i3, 1, "btn btn-xs ml-2", null, s3, t4), r3 = Nn(n3, 1, "btn btn-xs ml-2", null, r3, e4), a3 = Nn(o3, 1, "btn btn-primary btn-xs ml-2", null, a3, l3);
    }, [() => ({ "btn-primary": 252 == hs(C2) }), () => ({ "btn-primary": 60 == hs(C2) }), () => ({ "btn-primary": 20 == hs(C2) })], gt), Ms("click", i3, () => et2(252)), Ms("click", n3, () => et2(60)), Ms("click", o3, () => et2(20)), As(t3, e3);
  };
  Chart.register(LinearScale, BarController, CategoryScale, BarElement, ud);
  let x2 = Lr(e2, "browser", 12), w2 = Lr(e2, "report", 12), k2 = Lr(e2, "theme", 12), M2 = Lr(e2, "lang", 12, "en");
  function S2(t3, e3) {
    let i3 = 0;
    for (let s3 = 0; s3 < t3.length; s3++) t3[s3] > e3[s3] && i3++;
    return i3 / t3.length;
  }
  let C2 = Mt(252), z2 = Mt(), R2 = null, E2 = Mt(), P2 = null, T2 = Mt(), L2 = null, V2 = Mt(), O2 = null, A2 = Mt(), F2 = null, N2 = Mt(), I2 = null;
  function B2(t3, e3) {
    return hs(g2) ? hs(g2).map((i3) => {
      const s3 = t3[i3].value, n3 = e3[i3].value;
      return s3 > n3 ? 1 : s3 < n3 ? 0 : 0.5;
    }).reduce((t4, e4) => t4 + e4, 0) : 0;
  }
  let q2 = Mt(), K2 = null;
  function U2(t3, e3) {
    return t3.map((t4, i3) => t4 < e3[i3] ? "rgba(241, 99, 102, 1)" : "light" === ER(k2()) ? "#725bf5" : "#7a64f5");
  }
  function Q2() {
    var _a3, _b3;
    null === R2 && (R2 = new TwChart(hs(z2), false)), R2.setTheme(ER(k2())), R2.resetAreaSeries(0), R2.resetAreaSeries(1), hs(C2);
    let t3 = hs(i2)[0].time, e3 = hs(i2)[hs(i2).length - 1].time;
    R2.series[0].setData(hs(i2)), R2.series[1].setData(hs(s2)), R2.setTimeScale(new Date(t3), new Date(e3)), L2 || (L2 = new TwChart(hs(T2), false)), L2.setTheme(ER(k2())), L2.resetAreaSeries(0), L2.resetAreaSeries(1), t3 = hs(r2)[0].time, e3 = hs(r2)[hs(r2).length - 1].time, L2.series[0].setData(hs(r2)), L2.series[1].setData(hs(o2)), L2.setTimeScale(new Date(t3), new Date(e3)), O2 || (O2 = new TwChart(hs(V2), false)), O2.setTheme(ER(k2())), O2.resetAreaSeries(0), O2.resetAreaSeries(1), t3 = hs(a2)[0].time, e3 = (_a3 = hs(a2)[hs(a2).length - 1]) == null ? void 0 : _a3.time, O2.series[0].setData(hs(a2)), O2.series[1].setData(hs(l2)), O2.setTimeScale(new Date(t3), new Date(e3)), F2 || (F2 = new TwChart(hs(A2), false)), F2.setTheme(ER(k2())), F2.resetAreaSeries(0), F2.resetAreaSeries(1), t3 = hs(c2)[0].time, e3 = (_b3 = hs(c2)[hs(i2).length - 1]) == null ? void 0 : _b3.time, F2.series[0].setData(hs(c2)), F2.series[1].setData(hs(u2)), F2.setTimeScale(new Date(t3), new Date(e3)), K2 || (K2 = new TwChart(hs(q2), false)), K2.setTheme(ER(k2())), K2.resetAreaSeries(0), K2.series[0].setData(hs(_2));
  }
  function tt2() {
    if (void 0 !== hs(E2)) {
      P2 && P2.destroy();
      var t3 = hs(E2).getContext("2d");
      P2 = new Chart(t3, { type: "bar", data: { labels: hs(m2), datasets: [{ label: Fm(), data: hs(g2).map((t4) => hs(i2)[t4].value), backgroundColor: U2(hs(g2).map((t4) => hs(i2)[t4].value), hs(g2).map((t4) => hs(s2)[t4].value)), borderWidth: 0, barPercentage: 0.5 }, { label: uf(), data: hs(g2).map((t4) => hs(s2)[t4].value), backgroundColor: "#77777777", borderWidth: 0, barPercentage: 0.5 }] }, options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { color: "light" === ER(k2()) ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2], display: false } }, x: { ticks: { color: "light" === ER(k2()) ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2], display: false } } } } }), I2 && I2.destroy();
      var e3 = hs(N2).getContext("2d");
      I2 = new Chart(e3, { type: "bar", data: { labels: hs(m2), datasets: [{ label: Gm(), data: hs(g2).map((t4) => hs(c2)[t4].value), backgroundColor: U2(hs(g2).map((t4) => hs(c2)[t4].value), hs(g2).map((t4) => hs(u2)[t4].value)), borderWidth: 0, barPercentage: 0.5 }, { label: uf(), data: hs(g2).map((t4) => hs(u2)[t4].value), backgroundColor: "#77777777", borderWidth: 0, barPercentage: 0.5 }] }, options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { color: "light" === ER(k2()) ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2], display: false } }, x: { ticks: { color: "light" === ER(k2()) ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2], display: false } } } } });
    }
  }
  async function et2(t3) {
    zt(C2, t3), await ls(), Q2();
  }
  en(() => {
    x2() && (Q2(), tt2());
  }), sn(() => {
    P2 && P2.destroy(), I2 && I2.destroy();
  }), $e(() => (fs(w2()), hs(C2)), () => {
    zt(i2, w2().calculateSharpe("strategy", 0, hs(C2)));
  }), $e(() => (fs(w2()), hs(C2)), () => {
    zt(s2, w2().calculateSharpe("benchmark", 0, hs(C2)));
  }), $e(() => (hs(i2), hs(s2)), () => {
    zt(n2, S2(hs(i2).map((t3) => t3.value), hs(s2).map((t3) => t3.value)));
  }), $e(() => (fs(w2()), hs(C2)), () => {
    zt(r2, w2().calculateSortino("strategy", 0, hs(C2)));
  }), $e(() => (fs(w2()), hs(C2)), () => {
    zt(o2, w2().calculateSortino("benchmark", 0, hs(C2)));
  }), $e(() => (fs(w2()), hs(r2)), () => {
    zt(a2, w2().calculateVolitility("strategy", 0, 10).slice(-hs(r2).length));
  }), $e(() => (fs(w2()), hs(r2)), () => {
    zt(l2, w2().calculateVolitility("benchmark", 0, 10).slice(-hs(r2).length));
  }), $e(() => (hs(a2), hs(l2)), () => {
    zt(h2, S2(hs(a2).map((t3) => t3.value), hs(l2).map((t3) => t3.value)));
  }), $e(() => (fs(w2()), hs(C2)), () => {
    zt(c2, w2().calculateTailRatio("strategy", hs(C2)));
  }), $e(() => (fs(w2()), hs(C2)), () => {
    zt(u2, w2().calculateTailRatio("benchmark", hs(C2)));
  }), $e(() => (hs(c2), hs(u2)), () => {
    zt(d2, S2(hs(c2).map((t3) => t3.value), hs(u2).map((t3) => t3.value)));
  }), $e(() => hs(i2), () => {
    zt(f2, hs(i2) ? parseInt(hs(i2)[0].time.slice(0, 4)) : 0);
  }), $e(() => hs(i2), () => {
    zt(p2, hs(i2) ? parseInt(hs(i2)[hs(i2).length - 1].time.slice(0, 4)) : 0);
  }), $e(() => (hs(p2), hs(f2)), () => {
    zt(m2, Array.from(Array(hs(p2) + 1).keys()).slice(hs(f2)));
  }), $e(() => (hs(m2), fs(w2()), hs(i2)), () => {
    zt(g2, hs(m2) ? hs(m2).map((t3) => Math.max(Math.min(w2().indexOfTimestamps(t3 + "-12-31") - 249, hs(i2).length - 1), 0)) : []);
  }), $e(() => (hs(i2), hs(s2)), () => {
    zt(v2, B2(hs(i2), hs(s2)));
  }), $e(() => (hs(c2), hs(u2)), () => {
    zt(b2, B2(hs(c2), hs(u2)));
  }), $e(() => (fs(w2()), hs(C2)), () => {
    zt(_2, w2().calculateCorrelation(hs(C2)));
  }), $e(() => fs(k2()), () => {
    k2() && tt2();
  }), De(), yr();
  var at2 = TE(), ct2 = me(at2), dt2 = me(ct2), mt2 = me(dt2), bt2 = me(mt2), _t3 = me(bt2);
  y2(ve(_t3)), ie(bt2), ie(mt2);
  var yt2 = ve(mt2, 2), xt2 = me(yt2), wt2 = me(xt2), kt2 = me(wt2), Ct2 = me(kt2, true);
  ie(kt2);
  var Rt2 = ve(kt2, 2), Lt2 = me(Rt2);
  ie(Rt2), ie(wt2), ie(xt2), ie(yt2), ie(dt2);
  var Ot2 = ve(dt2, 2);
  _r(me(Ot2), (t3) => zt(z2, t3), () => hs(z2)), ie(Ot2), ie(ct2);
  var At2 = ve(ct2, 2), It2 = me(At2), Bt2 = me(It2), Gt2 = me(Bt2, true);
  ie(Bt2);
  var te2 = ve(Bt2, 2), ee2 = me(te2), ne2 = me(ee2);
  ie(ee2);
  var re2 = ve(ee2, 2), oe2 = me(re2), ae2 = me(oe2), le2 = me(ae2, true);
  ie(ae2);
  var he2 = ve(ae2, 2), ce2 = me(he2, true);
  ie(he2);
  var ue2 = ve(he2, 2), de2 = me(ue2, true);
  ie(ue2), ie(oe2), ie(re2), ie(te2), ie(It2);
  var fe2 = ve(It2, 2);
  _r(me(fe2), (t3) => zt(E2, t3), () => hs(E2)), ie(fe2), ie(At2);
  var pe2 = ve(At2, 2);
  _r(me(pe2), (t3) => zt(T2, t3), () => hs(T2)), ie(pe2);
  var be2 = ve(pe2, 2), _e4 = me(be2), xe2 = me(_e4), we2 = me(xe2), Se2 = me(we2, true);
  ie(we2), y2(ve(we2, 2)), ie(xe2);
  var ze2 = ve(xe2, 2), Ee2 = me(ze2), Te2 = me(Ee2), Le2 = me(Te2), Ve2 = me(Le2, true);
  ie(Le2);
  var Oe2 = ve(Le2, 2), Ae2 = me(Oe2);
  ie(Oe2), ie(Te2), ie(Ee2), ie(ze2), ie(_e4);
  var Fe2 = ve(_e4, 2);
  _r(me(Fe2), (t3) => zt(A2, t3), () => hs(A2)), ie(Fe2), ie(be2);
  var Ne2 = ve(be2, 2), We2 = me(Ne2), Ie2 = me(We2), Be2 = me(Ie2, true);
  ie(Ie2);
  var je2 = ve(Ie2, 2), He2 = me(je2), qe2 = me(He2);
  ie(He2);
  var Xe2 = ve(He2, 2), Ke2 = me(Xe2), Ue2 = me(Ke2), Ye2 = me(Ue2, true);
  ie(Ue2);
  var Ge2 = ve(Ue2, 2), Je2 = me(Ge2, true);
  ie(Ge2);
  var Qe2 = ve(Ge2, 2), Ze2 = me(Qe2, true);
  ie(Qe2), ie(Ke2), ie(Xe2), ie(je2), ie(We2);
  var ii2 = ve(We2, 2);
  _r(me(ii2), (t3) => zt(N2, t3), () => hs(N2)), ie(ii2), ie(Ne2);
  var oi2 = ve(Ne2, 2), ui2 = me(oi2), di2 = me(ui2), fi2 = me(di2), pi2 = me(fi2, true);
  ie(fi2), y2(ve(fi2, 2)), ie(di2);
  var mi2 = ve(di2, 2), gi2 = me(mi2), vi2 = me(gi2), bi2 = me(vi2, true);
  ie(vi2);
  var _i2 = ve(vi2, 2), xi2 = me(_i2);
  ie(_i2), ie(gi2), ie(mi2), ie(ui2);
  var wi2 = ve(ui2, 2);
  _r(me(wi2), (t3) => zt(V2, t3), () => hs(V2)), ie(wi2), ie(oi2);
  var ki2 = ve(oi2, 2), Si2 = me(ki2), Ei2 = me(Si2);
  y2(ve(me(Ei2), 2)), ie(Ei2), ie(Si2);
  var Pi2 = ve(Si2, 2);
  return _r(me(Pi2), (t3) => zt(q2, t3), () => hs(q2)), ie(Pi2), ie(ki2), ie(at2), Pe((t3, e3, i3, s3, n3, r3, o3, a3, l3, h3, c3, u3, d3, f3, p3, m3, _3, y3, x3, w3, k3) => {
    Us(_t3, `${t3 ?? ""} `), Us(Ct2, e3), Us(Lt2, `${i3 ?? ""}％`), Us(Gt2, s3), Us(ne2, `${n3 ?? ""}
					${hs(v2) ?? ""} / ${hs(g2).length ?? ""}
					${r3 ?? ""}`), Us(le2, o3), Us(ce2, a3), Us(de2, l3), Us(Se2, h3), Us(Ve2, c3), Us(Ae2, `${u3 ?? ""}％`), Us(Be2, d3), Us(qe2, `${f3 ?? ""}
					${hs(b2) ?? ""} / ${hs(g2).length ?? ""}
					${p3 ?? ""}`), Us(Ye2, m3), Us(Je2, _3), Us(Ze2, y3), Us(pi2, x3), Us(bi2, w3), Us(xi2, `${k3 ?? ""}％`);
  }, [() => Fm(), () => Zy(), () => (100 * hs(n2)).toFixed(2), () => Hy(), () => Zy(), () => Gy(), () => lf(), () => uf(), () => Zm(), () => Zw(), () => Zy(), () => (100 * hs(d2)).toFixed(2), () => ix(), () => Zy(), () => Gy(), () => lf(), () => uf(), () => Zm(), () => rx(), () => Zy(), () => (100 * hs(h2)).toFixed(2)], gt), As(t2, at2), J({ get browser() {
    return x2();
  }, set browser(t3) {
    x2(t3), rs();
  }, get report() {
    return w2();
  }, set report(t3) {
    w2(t3), rs();
  }, get theme() {
    return k2();
  }, set theme(t3) {
    k2(t3), rs();
  }, get lang() {
    return M2();
  }, set lang(t3) {
    M2(t3), rs();
  } });
}
Ar(LE, { browser: {}, report: {}, theme: {}, lang: {} }, [], [], true);
var VE = Rs('<div><div class="flex flex-col justify-center items-center"><div class="text-medium"> </div> <div> </div></div></div>'), OE = Rs('<div class="flex flex-col justify-center items-center text-sm rounded-full pb-4 hover:cursor-pointer hover:text-base hover:-mt-6 hover:shadow-2xl hover:shadow-primary"><div class="mt-3 border-b border-base-content/20 pb-4 px-2 text-center w-full"> <br/> </div> <div><div></div> <div></div></div> <div> <br/>% <br/></div></div>'), AE = Rs('<div class="flex flex-col justify-center items-center text-sm rounded-full pb-4 hover:cursor-pointer hover:text-base hover:-mt-6 hover:shadow-2xl hover:shadow-primary"><div class="mt-3 border-b border-base-content/20 pb-4 px-2 text-center w-full"> <br/> </div> <div><div></div></div> <div> <br/> </div></div>'), FE = Rs('<div class="grid grid-cols-6 mx-6 md:mx-12 gap-6 md:12 lg:gap-24"><div class="col-span-6 rounded-lg"><div class="pb-0"><div class="text-base-content/70 font-light text-3xl mb-6"> </div> <div><div><div class="carousel carousel-center max-w-full space-x-2 overflow-x-auto"></div></div></div></div> <div class="relative"><div class="text-primary h-64 z-0"></div> <div class="-mt-24 mb-12 mr-20 text-right"><div class="stat-title">再次創新高</div> <div class="stat-value"><span> </span> <span class="text-sm">天</span></div></div></div></div> <div class="col-span-6 md:col-span-6 rounded-lg"><div><div class="text-base-content/70 font-light text-3xl mb-6"> </div> <h4 class="text-base-content/70 text-xl font-light mb-3"> </h4> <!></div></div> <div class="text-center relative col-span-6 md:col-span-3 rounded-lg"><div><div class="text-base-content/70 font-light text-3xl"> </div> <div><div class="flex mt-6 justify-center gap-2"><button> </button> <button> </button></div> <div><div class="grid grid-cols-5 justify-start items-start mt-6"></div></div> <div class="absolute inset-x-0 bottom-0 flex justify-center my-3 text-sm gap-2" style="direction:rtl"><div class="badge rounded bg-gray-500 text-white"> </div> <div class="badge rounded bg-primary text-white"> </div></div></div></div></div> <div class="col-span-3 rounded-lg text-center"><div><div class="text-base-content/70 font-light text-3xl"> </div> <div><div class="flex mt-6 justify-center gap-2"><span> </span> <span> </span></div> <div><div class="flex justify-between items-start mt-6 text-sm"></div></div> <div class="absolute inset-x-0 bottom-0 flex justify-center my-3 text-sm" style="direction:rtl"><div class="badge rounded badge-primary text-white"> </div></div></div></div></div> <div class="col-span-6 rounded-lg"><div class="pb-0"><div class="text-base-content/70 font-light text-3xl mb-6"> </div></div> <div class="px-0 pt-0"></div> <div class="text-primary h-48 z-0"></div></div></div>');
function NE(t2, e2) {
  G(e2, false);
  const i2 = Mt(), s2 = Mt(), n2 = Mt(), r2 = Mt(), o2 = Mt(), a2 = Mt(), l2 = Mt(), h2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return WC[e3] ? WC[e3]() : e3;
  };
  let c2 = Lr(e2, "browser", 12), u2 = Lr(e2, "report", 12), d2 = Lr(e2, "theme", 12, "light"), f2 = Mt(), p2 = Mt(), m2 = Mt(null), g2 = null, v2 = Mt(null), b2 = Mt(null), y2 = Mt(null);
  function x2(t3, e3) {
    if (hs(m2)) if ("string" == typeof t3 && "string" == typeof e3) {
      const i3 = new Date(t3), s3 = new Date(e3);
      hs(m2).setTimeScale(i3, s3), zt(v2, M2({ start: t3, end: e3 })), zt(v2, ((i3 - s3) / 864e5).toFixed(0)), zt(b2, i3), zt(y2, s3);
    } else {
      const i3 = u2().indexOfTimestamps(t3), s3 = u2().indexOfTimestamps(e3), n3 = new Date(u2().timestamps[i3]), r3 = new Date(u2().timestamps[s3]);
      hs(m2).setTimeScale(n3, r3), zt(b2, n3), zt(y2, r3);
    }
  }
  function w2(t3) {
    hs(m2) || zt(m2, new TwChart(hs(f2), true)), hs(m2).setTheme(ER(d2()));
    const e3 = u2().timestamps.length / 1, i3 = u2().createTradingviewSeries("strategy", 0, -1, e3), s3 = u2().createTradingviewSeries("benchmark", 0, -1, e3);
    hs(m2).resetAreaSeries(0), hs(m2).resetAreaSeries(1), hs(m2).series[0].setData(i3), hs(m2).series[1].setData(s3), hs(m2).chart.subscribeCrosshairMove((t4) => {
    }), hs(m2).chart.subscribeClick((t4) => {
    }), hs(m2).chart.timeScale().subscribeVisibleTimeRangeChange((t4) => {
    }), hs(m2);
  }
  let k2 = Mt("strategy");
  const M2 = (t3) => ((new Date(u2().timestamps[t3.end]) - new Date(u2().timestamps[t3.start])) / 864e5).toFixed(0);
  en(() => {
    if (!c2()) return;
    const t3 = hs(n2)[0];
    w2(), x2(u2().timestamps[t3.start], u2().timestamps[t3.end]), g2 || (g2 = new TwChart(hs(p2), false)), g2.setTheme(ER(d2())), u2().timestamps.length, g2.resetAreaSeries(0), g2.resetAreaSeries(1), g2.series[0].setData(hs(i2)), g2.series[1].setData(hs(s2)), g2.setTimeScale(new Date(u2().timestamps[0]), new Date(u2().timestamps[u2().timestamps.length - 1]));
  }), $e(() => fs(u2()), () => {
    zt(i2, u2().createTradingViewDrawdown("strategy", u2().timestamps.length));
  }), $e(() => fs(u2()), () => {
    zt(s2, u2().createTradingViewDrawdown("benchmark", u2().timestamps.length));
  }), $e(() => (hs(m2), fs(d2())), () => {
    hs(m2) && hs(m2).setTheme(ER(d2()));
  }), $e(() => (hs(n2), hs(r2), fs(u2())), () => {
    var t3, e3;
    t3 = u2().calculateDrawdown("strategy"), e3 = _(t3, 2), zt(n2, e3[0]), zt(r2, e3[1]);
  }), $e(() => (hs(o2), hs(a2), fs(u2())), () => {
    var t3, e3;
    t3 = u2().calculateDrawdown("benchmark"), e3 = _(t3, 2), zt(o2, e3[0]), zt(a2, e3[1]);
  }), $e(() => hs(n2), () => {
    zt(l2, hs(n2)[0]);
  }), De(), yr();
  var S2 = FE(), C2 = me(S2), z2 = me(C2), R2 = me(z2), E2 = me(R2, true);
  ie(R2);
  var P2 = ve(R2, 2), T2 = me(P2), L2 = me(T2);
  hn(L2, 5, () => hs(n2), ln, (t3, e3) => {
    var i3 = VE(), s3 = me(i3), n3 = me(s3), r3 = me(n3, true);
    ie(n3);
    var o3 = ve(n3, 2), a3 = me(o3);
    ie(o3), ie(s3), ie(i3), Pe((t4, s4, n4) => {
      Nn(i3, 1, "cursor-pointer carousel-item px-5 py-3 rounded-lg border transition-all duration-300 " + (hs(l2) === hs(e3) ? "border-primary shadow-sm" : "border-base-content/20")), Us(r3, t4), Nn(o3, 1, `text-sm ${s4 ?? ""}`), Us(a3, `${n4 ?? ""}%`);
    }, [() => u2().timestamps[hs(e3).start].slice(0, 4), () => $R(-1), () => (100 * hs(e3).maxDrawdown).toFixed(1)], gt), Ms("click", i3, () => {
      w2(), x2(u2().timestamps[hs(e3).start], u2().timestamps[hs(e3).end]), zt(l2, hs(e3));
    }), As(t3, i3);
  }), ie(L2), ie(T2), ie(P2), ie(z2);
  var V2 = ve(z2, 2), O2 = me(V2);
  _r(O2, (t3) => zt(f2, t3), () => hs(f2));
  var A2 = ve(O2, 2), F2 = ve(me(A2), 2), N2 = me(F2), I2 = me(N2, true);
  ie(N2), ne(2), ie(F2), ie(A2), ie(V2), ie(C2);
  var B2 = ve(C2, 2), q2 = me(B2), K2 = me(q2), U2 = me(K2, true);
  ie(K2);
  var Q2 = ve(K2, 2), tt2 = me(Q2);
  ie(Q2), yE(ve(Q2, 2), { get report() {
    return u2();
  }, get theme() {
    return d2();
  }, get browser() {
    return c2();
  }, get tstart() {
    return hs(b2);
  }, get tend() {
    return hs(y2);
  } }), ie(q2), ie(B2);
  var et2 = ve(B2, 2), at2 = me(et2), ct2 = me(at2), dt2 = me(ct2, true);
  ie(ct2);
  var mt2 = ve(ct2, 2), bt2 = me(mt2), _t3 = me(bt2), yt2 = me(_t3, true);
  ie(_t3);
  var xt2 = ve(_t3, 2), wt2 = me(xt2, true);
  ie(xt2), ie(bt2);
  var kt2 = ve(bt2, 2), Ct2 = me(kt2);
  hn(Ct2, 5, () => "strategy" === hs(k2) ? hs(n2) : hs(o2), ln, (t3, e3) => {
    var r3 = OE(), a3 = me(r3), c3 = me(a3), d3 = ve(c3, 2);
    ie(a3);
    var f3 = ve(a3, 2), p3 = me(f3), m3 = ve(p3, 2);
    ie(f3);
    var g3 = ve(f3, 2), v3 = me(g3, true);
    ne(3), ie(g3), ie(r3), Pe((t4, e4, i3, s3, n3) => {
      Us(c3, `${t4 ?? ""} `), Us(d3, ` ${e4 ?? ""} 月`), Nn(f3, 1, "flex justify-center " + ("benchmark" === hs(k2) ? "flex-row-reverse" : "")), In(p3, i3), Nn(p3, 1, "w-3 rounded-b-full mx-1 " + ("strategy" === hs(k2) ? "bg-primary" : "bg-gray-400")), In(m3, s3), Nn(m3, 1, "w-3 rounded-b-full mx-1 " + ("strategy" === hs(k2) ? "bg-gray-400" : "bg-primary")), Nn(g3, 1, `w-20 pt-2 text-center text-primary ${0 === h2 ? "text-2xl font-bold" : ""} ${"strategy" === hs(k2) ? "text-primary" : "text-gray-400"}`), Us(v3, n3);
    }, [() => u2().timestamps[hs(e3).at].slice(0, 4), () => u2().timestamps[hs(e3).at].slice(5, 7), () => `height:${(hs(e3).maxDrawdown / hs(n2)[0].maxDrawdown * 160).toFixed(0)}px`, () => `height:${(("strategy" === hs(k2) ? hs(s2) : hs(i2))[hs(e3).at].value / 100 / Math.max(hs(n2)[0].maxDrawdown, hs(o2)[0].maxDrawdown) * 160).toFixed(0)}px`, () => (100 * hs(e3).maxDrawdown).toFixed(1)], gt), Ms("click", r3, () => {
      w2(), x2(u2().timestamps[hs(e3).start], u2().timestamps[hs(e3).end]), zt(l2, hs(e3));
    }), As(t3, r3);
  }), ie(Ct2), ie(kt2);
  var Rt2 = ve(kt2, 2), Lt2 = me(Rt2), Ot2 = me(Lt2, true);
  ie(Lt2);
  var At2 = ve(Lt2, 2), It2 = me(At2, true);
  ie(At2), ie(Rt2), ie(mt2), ie(at2), ie(et2);
  var Bt2 = ve(et2, 2), Gt2 = me(Bt2), te2 = me(Gt2), ee2 = me(te2, true);
  ie(te2);
  var re2 = ve(te2, 2), oe2 = me(re2), ae2 = me(oe2), le2 = me(ae2, true);
  ie(ae2);
  var he2 = ve(ae2, 2), ce2 = me(he2, true);
  ie(he2), ie(oe2);
  var ue2 = ve(oe2, 2), de2 = me(ue2);
  hn(de2, 5, () => "strategy" === hs(k2) ? hs(r2) : hs(a2), ln, (t3, e3) => {
    var i3 = AE(), s3 = me(i3), n3 = me(s3), o3 = ve(n3, 2);
    ie(s3);
    var c3 = ve(s3, 2), d3 = me(c3);
    ie(c3);
    var f3 = ve(c3, 2), p3 = me(f3), m3 = ve(p3, 2);
    ie(f3), ie(i3), Pe((t4, e4, i4, s4, r3) => {
      Us(n3, `${t4 ?? ""} `), Us(o3, ` ${e4 ?? ""} 月`), In(d3, i4), Nn(d3, 1, "w-3 rounded-b-full mx-1 " + ("strategy" === hs(k2) ? "bg-primary" : "bg-gray-400")), Nn(f3, 1, `w-14 pt-2 text-center ${0 === h2 ? "text-2xl font-bold" : ""} ${"strategy" === hs(k2) ? "text-primary" : "text-gray-400"}`), Us(p3, `${s4 ?? ""} `), Us(m3, ` ${r3 ?? ""}`);
    }, [() => u2().timestamps[hs(e3).at].slice(0, 4), () => u2().timestamps[hs(e3).at].slice(5, 7), () => `height:${(M2(hs(e3)) / Math.min(M2(hs(r2)[0]), M2(hs(a2)[0])) * 160).toFixed(0)}px`, () => M2(hs(e3)), () => h2("metrics.risk.days")], gt), Ms("click", i3, () => {
      w2(), x2(u2().timestamps[hs(e3).start], u2().timestamps[hs(e3).end]), zt(l2, hs(e3));
    }), As(t3, i3);
  }), ie(de2), ie(ue2);
  var fe2 = ve(ue2, 2), pe2 = me(fe2), ge2 = me(pe2, true);
  ie(pe2), ie(fe2), ie(re2), ie(Gt2), ie(Bt2);
  var be2 = ve(Bt2, 2), _e4 = me(be2), xe2 = me(_e4), we2 = me(xe2, true);
  return ie(xe2), ie(_e4), _r(ve(_e4, 4), (t3) => zt(p2, t3), () => hs(p2)), ie(be2), ie(S2), Pe((t3, e3, i3, s3, n3, r3, o3, a3, l3, h3, c3, u3, d3, f3, p3) => {
    Us(E2, t3), Us(I2, e3), Us(U2, i3), Us(tt2, `${s3 ?? ""}~${n3 ?? ""}`), Us(dt2, r3), Nn(_t3, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 rounded-xl " + ("strategy" === hs(k2) ? "outline outline-primary" : "")), Us(yt2, o3), Nn(xt2, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 rounded-xl " + ("benchmark" === hs(k2) ? "outline outline-primary" : "")), Us(wt2, a3), Us(Ot2, l3), Us(It2, h3), Us(ee2, c3), Nn(ae2, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 cursor-pointer rounded-xl " + ("strategy" === hs(k2) ? "outline outline-primary" : "")), Us(le2, u3), Nn(he2, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 cursor-pointer rounded-xl " + ("benchmark" === hs(k2) ? "outline outline-primary" : "")), Us(ce2, d3), Us(ge2, f3), Us(we2, p3);
  }, [() => h2("risk.drawdowPeriods"), () => Math.abs(hs(v2)), () => h2("profitability.stockList"), () => {
    var _a3;
    return (_a3 = hs(b2)) == null ? void 0 : _a3.toLocaleDateString();
  }, () => {
    var _a3;
    return (_a3 = hs(y2)) == null ? void 0 : _a3.toLocaleDateString();
  }, () => h2("metrics.risk.worstDrawdownPeriod"), () => h2("metrics.risk.worst10Strategy"), () => h2("metrics.risk.worst10Benchmark"), () => h2("benchmark"), () => h2("strategy"), () => h2("metrics.risk.newHighTimeRank"), () => h2("metrics.risk.worst10Strategy"), () => h2("metrics.risk.worst10Benchmark"), () => h2("strategy"), () => h2("risk.drawdownPercentage")], gt), Ms("click", _t3, () => {
    zt(k2, "strategy");
  }), Ms("click", xt2, () => {
    zt(k2, "benchmark");
  }), Ms("click", ae2, () => {
    zt(k2, "strategy");
  }), Ms("click", he2, () => {
    zt(k2, "benchmark");
  }), As(t2, S2), J({ get browser() {
    return c2();
  }, set browser(t3) {
    c2(t3), rs();
  }, get report() {
    return u2();
  }, set report(t3) {
    u2(t3), rs();
  }, get theme() {
    return d2();
  }, set theme(t3) {
    d2(t3), rs();
  } });
}
Ar(NE, { browser: {}, report: {}, theme: {} }, [], [], true);
var WE = Rs('<div class="text-base-content-200"><div class="grid grid-cols-6 mx-6 md:mx-12 gap-6 md:gap-12 lg:gap-24"><div class="col-span-6"><h3 class="text-base-content/70 font-light text-3xl mb-6"> </h3> <div class="card-content"><span> <span class="font-light"> </span> </span> <canvas class="mt-3 max-h-[400px]"></canvas> <div class="text-sm text-center pb-6 mt-3"> </div></div></div> <div class="col-span-6 md:col-span-3"><h3 class="text-base-content/70 font-light text-3xl mb-6"> </h3> <div class="card-content"><span> <span class="font-bold font-light"> </span></span> <br/> <span> <span class="font-bold font-light"> </span> %</span> <br/> <span> <span class="font-bold font-light"> </span></span> <input type="range" min="0" max="0.3" class="range range-secondary mt-6" step="0.05"/> <div class="w-full flex justify-between text-xs px-2"><span class="font-bold text-sm">0％</span> <span class="font-bold text-sm">5％</span> <span class="font-bold text-sm">10％</span> <span class="font-bold text-sm">15％</span> <span class="font-bold text-sm">20％</span> <span class="font-bold text-sm">25％</span> <span class="font-bold text-sm">30％</span></div> <h3 class="text-2xl font-bold mt-12 mb-6 text-center text-base-content-200"> </h3> <div class="text-base-content-100 text-sm font-bold mt-3"> </div> <canvas class="mt-3"></canvas> <div class="text-base-content-100 text-sm text-center font-bold"> </div></div></div> <div class="col-span-6 md:col-span-3"><h3 class="text-base-content/70 font-light text-3xl mb-6"> </h3> <div class="card-content"><span> <span class="font-bold font-light"> </span></span> <br/> <span> <span class="font-bold font-light"> </span>%</span> <br/> <span> <span class="font-bold font-light"> </span></span> <input type="range" min="0" max="0.3" class="range range-primary mt-6" step="0.05"/> <div class="w-full flex justify-between text-xs px-2"><span class="font-bold text-sm">0％</span> <span class="font-bold text-sm">5％</span> <span class="font-bold text-sm">10％</span> <span class="font-bold text-sm">15％</span> <span class="font-bold text-sm">20％</span> <span class="font-bold text-sm">25％</span> <span class="font-bold text-sm">30％</span></div> <h3 class="text-2xl font-bold mt-12 mb-6 text-center text-base-content-200"> </h3> <div class="text-base-content-100 text-sm font-bold mt-3"> </div> <canvas class="mt-3"></canvas> <div class="text-base-content-100 text-sm text-center font-bold"> </div></div></div> <div class="col-span-6"><h3 class="text-base-content/70 font-light text-3xl mb-6"> </h3> <div class="card-content"><div class="text-base-content-100 text-sm font-bold mt-3"> </div> <canvas class="mt-3"></canvas> <div class="text-base-content-100 text-sm text-center font-bold"> </div></div></div></div></div>');
function IE(t2, e2) {
  G(e2, false);
  const i2 = Mt(), s2 = Mt(), n2 = Mt(), r2 = Mt(), o2 = Mt(), a2 = Mt(), l2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return WC[e3] ? WC[e3]() : e3;
  };
  let h2 = Lr(e2, "lang", 12, "en");
  Chart.register(BubbleController, LinearScale, PointElement, ud, CategoryScale, BarController, BarElement, LineElement, LineController);
  let c2 = Lr(e2, "browser", 12), u2 = Lr(e2, "report", 12), d2 = Lr(e2, "theme", 12, "light"), f2 = Mt(0), p2 = Mt(0);
  const m2 = u2().trades.map((t3) => t3.return), g2 = m2.reduce((t3, e3) => t3 + e3, 0) / m2.length, v2 = m2.reduce((t3, e3) => t3 + Math.pow(e3 - g2, 2), 0) / m2.length, b2 = Math.sqrt(v2);
  function _2(t3, e3) {
    const i3 = -3 * b2, s3 = (3 * b2 - i3) / e3, n3 = new Array(e3).fill(0), r3 = [];
    t3.forEach((t4) => {
      const r4 = Math.min(Math.floor((t4 - i3) / s3), e3 - 1);
      n3[r4]++;
    });
    for (let t4 = 0; t4 < e3; t4++) r3.push([i3 + t4 * s3, i3 + (t4 + 1) * s3]);
    return { bins: n3, ranges: r3 };
  }
  [...m2].sort((t3, e3) => t3 - e3);
  let y2 = Mt(), x2 = null, w2 = Mt();
  const k2 = function(t3, e3 = 0.95) {
    const i3 = t3;
    return 0 === i3.length ? null : (i3.sort((t4, e4) => t4 - e4), i3[Math.floor((1 - e3) * i3.length)]);
  }(u2().trades.map((t3) => t3.return));
  function M2(t3) {
    const e3 = hs(y2), i3 = t3.ranges.map((t4) => t4[0]), s3 = i3.map((t4) => t4 >= 0 ? "light" === d2() ? "#725bf5" : "#7a64f5" : "rgba(241, 99, 102, 1)");
    null !== x2 && x2.destroy(), x2 = new Chart(e3, { type: "bar", data: { labels: i3, datasets: [{ data: t3.bins, backgroundColor: s3 }] }, options: { responsive: true, maintainAspectRatio: true, scales: { x: { type: "category", ticks: { callback: (t4, e4, s4) => (100 * i3[e4]).toFixed(1) + "%", color: "light" === d2() ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } }, y: { type: "linear", ticks: { callback: (t4, e4, i4) => t4 + " trades", color: "light" === d2() ? "#000000aa" : "#FFFFFFaa" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } } }, plugins: { legend: { display: false } } } });
  }
  const S2 = u2().trades.filter((t3) => t3.return > 0), C2 = u2().trades.filter((t3) => t3.return <= 0);
  function z2(t3, e3, i3, s3) {
    const n3 = Math.max(...u2().trades.map((t4) => Math.abs(t4[e3]))), r3 = Math.max(...u2().trades.map((t4) => Math.abs(t4[i3]))), o3 = u2().trades.map((t4) => Math.log(Math.abs(t4.return) + 1)), a3 = Math.max(...o3), l3 = Math.min(...o3);
    function h3(t4, e4, i4, s4, n4) {
      return (t4 - e4) / (i4 - e4) * (n4 - s4) + s4;
    }
    function c3(t4, i4) {
      const s4 = 0 !== hs(f2) ? hs(f2) : 1;
      return "mae" === e3 ? i4 < -s4 ? -s4 : t4 : "gmfe" === e3 && i4 > hs(p2) && 0 !== hs(p2) ? hs(p2) : t4;
    }
    const m3 = { type: "bubble", data: { datasets: [{ label: "Winning", data: S2.map((t4) => ({ x: Math.abs(t4[e3]), y: Math.abs(c3(t4[i3], t4[e3])), r: h3(Math.log(Math.abs(t4.return) + 1), l3, a3, 3, 20), t: t4 })), backgroundColor: "rgba(99, 102, 241, 0.5)" }, { label: "Losing", data: C2.map((t4) => ({ x: Math.abs(t4[e3]), y: Math.abs(c3(t4[i3], t4[e3])), r: h3(Math.log(Math.abs(t4.return) + 1), l3, a3, 3, 20), t: t4 })), backgroundColor: "rgba(241, 99, 102, 0.5)" }, { label: "45-degree Line", data: [{ x: 0, y: 0 }, { x: 0.5, y: 0.5 }], type: "line", fill: false, borderColor: "rgba(125, 125, 125, 0.8)", pointRadius: 0, borderWidth: 1, tension: 0 }] }, options: { responsive: true, maintainAspectRatio: true, animation: false, scales: { x: { type: "linear", beginAtZero: true, max: Math.min(0.5, n3, r3), ticks: { color: "light" === d2() ? "#000000aa" : "#FFFFFFaa", callback: (t4, e4, i4) => (100 * t4).toFixed(1) + "%" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } }, y: { type: "linear", beginAtZero: true, max: Math.min(0.5, r3, n3), ticks: { color: "light" === d2() ? "#000000aa" : "#FFFFFFaa", callback: (t4, e4, i4) => (100 * t4).toFixed(1) + "%" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } } }, plugins: { legend: { display: false }, zoom: { pan: { enabled: true, mode: "xy" }, zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: "xy" } }, tooltip: { callbacks: { title: (t4) => t4[0].raw.t.stockId + " " + t4[0].dataset.label, label(t4) {
      const s4 = t4.raw.x.toFixed(2), n4 = t4.raw.y.toFixed(2);
      return t4.raw.t.stock, `${e3}: ${s4}, ${i3}:${n4}`;
    } } } } } };
    return new Chart(t3, m3);
  }
  let R2 = Mt(), E2 = Mt();
  const P2 = Mt({});
  let T2 = Mt(false);
  en(() => {
    if (!c2()) return;
    M2(_2(m2, 50)), Ct(P2, hs(P2).maemfe = z2(hs(w2), "mae", "gmfe")), Ct(P2, hs(P2).mae = z2(hs(R2), "mae", "return")), Ct(P2, hs(P2).mfe = z2(hs(E2), "gmfe", "return")), zt(T2, true);
  }), sn(() => {
    var _a3, _b3, _c3;
    (_a3 = hs(P2).maemfe) == null ? void 0 : _a3.destroy(), (_b3 = hs(P2).mae) == null ? void 0 : _b3.destroy(), (_c3 = hs(P2).mfe) == null ? void 0 : _c3.destroy(), x2 == null ? void 0 : x2.destroy();
  }), $e(() => (fs(u2()), hs(f2)), () => {
    zt(i2, u2().trades.filter((t3) => t3.mae < -hs(f2)).map((t3) => t3.return));
  }), $e(() => (hs(f2), hs(i2)), () => {
    zt(s2, 0 === hs(f2) ? 0 : hs(i2).reduce((t3, e3) => t3 + e3, 0) / hs(i2).length + hs(f2) || 0);
  }), $e(() => (hs(f2), hs(i2), fs(u2())), () => {
    zt(n2, 0 === hs(f2) ? 0 : hs(i2).length / u2().trades.length);
  }), $e(() => (fs(u2()), hs(p2)), () => {
    zt(r2, u2().trades.filter((t3) => t3.gmfe > hs(p2)).map((t3) => t3.return));
  }), $e(() => (hs(p2), hs(r2)), () => {
    zt(o2, 0 === hs(p2) ? 0 : hs(r2).reduce((t3, e3) => t3 + e3, 0) / hs(r2).length - hs(p2) || 0);
  }), $e(() => (hs(p2), hs(r2), fs(u2())), () => {
    zt(a2, 0 === hs(p2) ? 0 : hs(r2).length / u2().trades.length);
  }), $e(() => (fs(d2()), hs(T2), hs(P2), hs(w2)), () => {
    if (d2() && hs(T2)) {
      hs(P2).maemfe && (hs(P2).maemfe.destroy(), Ct(P2, hs(P2).maemfe = z2(hs(w2), "mae", "gmfe")));
      M2(_2(m2, 50));
    }
  }), $e(() => (hs(f2), fs(d2()), hs(P2), hs(R2)), () => {
    (0 === hs(f2) || hs(f2) || d2()) && hs(P2).mae && (hs(P2).mae.destroy(), Ct(P2, hs(P2).mae = z2(hs(R2), "mae", "return")));
  }), $e(() => (hs(p2), fs(d2()), hs(P2), hs(E2)), () => {
    (0 === hs(p2) || hs(p2) || d2()) && hs(P2).mfe && (hs(P2).mfe.destroy(), Ct(P2, hs(P2).mfe = z2(hs(E2), "gmfe", "return")));
  }), De(), yr();
  var L2 = WE(), V2 = me(L2), O2 = me(V2), A2 = me(O2), F2 = me(A2, true);
  ie(A2);
  var N2 = ve(A2, 2), I2 = me(N2), B2 = me(I2), q2 = ve(B2), K2 = me(q2, true);
  ie(q2);
  var U2 = ve(q2);
  ie(I2);
  var Q2 = ve(I2, 2);
  _r(Q2, (t3) => zt(y2, t3), () => hs(y2));
  var tt2 = ve(Q2, 2), et2 = me(tt2, true);
  ie(tt2), ie(N2), ie(O2);
  var at2 = ve(O2, 2), ct2 = me(at2), dt2 = me(ct2, true);
  ie(ct2);
  var mt2 = ve(ct2, 2), bt2 = me(mt2), _t3 = me(bt2), yt2 = ve(_t3), xt2 = me(yt2, true);
  ie(yt2), ie(bt2);
  var wt2 = ve(bt2, 4), kt2 = me(wt2), Rt2 = ve(kt2), Lt2 = me(Rt2, true);
  ie(Rt2), ne(), ie(wt2);
  var Ot2 = ve(wt2, 4), At2 = me(Ot2), It2 = ve(At2), Bt2 = me(It2);
  ie(It2), ie(Ot2);
  var Gt2 = ve(Ot2, 2);
  Jn(Gt2);
  var te2 = ve(Gt2, 4), ee2 = me(te2, true);
  ie(te2);
  var re2 = ve(te2, 2), oe2 = me(re2, true);
  ie(re2);
  var ae2 = ve(re2, 2);
  _r(ae2, (t3) => zt(R2, t3), () => hs(R2));
  var le2 = ve(ae2, 2), he2 = me(le2, true);
  ie(le2), ie(mt2), ie(at2);
  var ce2 = ve(at2, 2), ue2 = me(ce2), de2 = me(ue2, true);
  ie(ue2);
  var fe2 = ve(ue2, 2), pe2 = me(fe2), ge2 = me(pe2, true), be2 = ve(ge2), _e4 = me(be2, true);
  ie(be2), ie(pe2);
  var xe2 = ve(pe2, 4), we2 = me(xe2), Se2 = ve(we2), ze2 = me(Se2, true);
  ie(Se2), ne(), ie(xe2);
  var Ee2 = ve(xe2, 4), Te2 = me(Ee2, true), Le2 = ve(Te2), Ve2 = me(Le2);
  ie(Le2), ie(Ee2);
  var Oe2 = ve(Ee2, 2);
  Jn(Oe2);
  var Ae2 = ve(Oe2, 4), Fe2 = me(Ae2, true);
  ie(Ae2);
  var Ne2 = ve(Ae2, 2), We2 = me(Ne2, true);
  ie(Ne2);
  var Ie2 = ve(Ne2, 2);
  _r(Ie2, (t3) => zt(E2, t3), () => hs(E2));
  var Be2 = ve(Ie2, 2), je2 = me(Be2, true);
  ie(Be2), ie(fe2), ie(ce2);
  var He2 = ve(ce2, 2), qe2 = me(He2), Xe2 = me(qe2, true);
  ie(qe2);
  var Ke2 = ve(qe2, 2), Ue2 = me(Ke2), Ye2 = me(Ue2, true);
  ie(Ue2);
  var Ge2 = ve(Ue2, 2);
  _r(Ge2, (t3) => zt(w2, t3), () => hs(w2));
  var Je2 = ve(Ge2, 2), Qe2 = me(Je2, true);
  return ie(Je2), ie(Ke2), ie(He2), ie(V2), ie(L2), Pe((t3, e3, i3, s3, n3, r3, o3, a3, l3, h3, c3, u3, d3, f3, p3, m3, g3, v3, b3, _3, y3, x3, w3, k3, M3, S3, C3, z3) => {
    Us(F2, t3), Us(B2, `${e3 ?? ""} `), Us(K2, i3), Us(U2, ` ${s3 ?? ""}`), Us(et2, n3), Us(dt2, r3), Us(_t3, `${o3 ?? ""} `), Us(xt2, a3), Us(kt2, `${l3 ?? ""} `), Us(Lt2, h3), Us(At2, `${c3 ?? ""} `), Us(Bt2, `${u3 ?? ""}%`), Us(ee2, d3), Us(oe2, f3), Us(he2, p3), Us(de2, m3), Us(ge2, g3), Us(_e4, v3), Us(we2, `${b3 ?? ""} `), Us(ze2, _3), Us(Te2, y3), Us(Ve2, `${x3 ?? ""}%`), Us(Fe2, w3), Us(We2, k3), Us(je2, M3), Us(Xe2, S3), Us(Ye2, C3), Us(Qe2, z3);
  }, [() => l2("metrics.winrate.returnDistribution"), () => l2("metrics.winrate.distributionInfo1"), () => (100 * k2).toFixed(1), () => l2("metrics.winrate.distributionInfo2"), () => l2("metrics.winrate.return"), () => l2("metrics.winrate.simulatedStopLoss"), () => l2("metrics.winrate.stoploss"), () => 0 !== hs(f2) ? 100 * hs(f2) + "%" : l2("metrics.winrate.none"), () => l2("metrics.winrate.extraProfitLoss"), () => (hs(s2) > 0 ? "+" : "") + (100 * hs(s2)).toFixed(1), () => l2("metrics.winrate.stoplossRatio"), () => (100 * hs(n2)).toFixed(1), () => l2("metrics.winrate.maeReturn"), () => l2("metrics.winrate.return"), () => l2("metrics.winrate.mae"), () => l2("metrics.winrate.simulatedTakeProfit"), () => l2("metrics.winrate.takeProfit"), () => 0 !== hs(p2) ? 100 * hs(p2) + "%" : l2("metrics.winrate.none"), () => l2("metrics.winrate.extraProfitLossTakingProfit"), () => (hs(o2) > 0 ? "+" : "") + (100 * hs(o2)).toFixed(1), () => l2("metrics.winrate.takeProfitRatio"), () => (100 * hs(a2)).toFixed(1), () => l2("metrics.winrate.mfeReturn"), () => l2("metrics.winrate.return"), () => l2("metrics.winrate.mfe"), () => l2("metrics.winrate.maemfe"), () => l2("metrics.winrate.mfe"), () => l2("metrics.winrate.mae")], gt), pr(Gt2, () => hs(f2), (t3) => zt(f2, t3)), pr(Oe2, () => hs(p2), (t3) => zt(p2, t3)), As(t2, L2), J({ get lang() {
    return h2();
  }, set lang(t3) {
    h2(t3), rs();
  }, get browser() {
    return c2();
  }, set browser(t3) {
    c2(t3), rs();
  }, get report() {
    return u2();
  }, set report(t3) {
    u2(t3), rs();
  }, get theme() {
    return d2();
  }, set theme(t3) {
    d2(t3), rs();
  } });
}
Ar(IE, { lang: {}, browser: {}, report: {}, theme: {} }, [], [], true);
const BE = Mr(null);
class Stock {
  constructor(t2) {
    this.timestamps = t2.date, this.open = t2.open, this.high = t2.high, this.close = t2.close, this.low = t2.low, this.volume = t2.volume;
  }
  createTradingviewSeries(t2, e2 = 0, i2 = -1, s2 = 500) {
    const n2 = this[t2], r2 = this.timestamps.map((t3, e3) => ({ time: t3.toDate(), value: n2[e3] })).slice(this.indexOfTimestamps(e2), this.indexOfTimestamps(i2) + 1), o2 = Math.round(r2.length / s2);
    return r2.filter((t3, e3) => e3 % o2 === 0 || e3 === r2.length - 1);
  }
  indexOfTimestamps(t2) {
    return "string" == typeof t2 ? this.timestamps.findIndex((e2) => e2 === t2) : t2 < 0 ? Math.max(this.timestamps.length + t2, 0) : Math.min(t2, this.timestamps.length - 1);
  }
  createCandlestickSeries(t2 = 0, e2 = -1) {
    const i2 = this.indexOfTimestamps(t2), s2 = this.indexOfTimestamps(e2) + 1;
    return this.timestamps.slice(i2, s2).map((t3, e3) => ({ time: t3, open: this.open[i2 + e3], high: this.high[i2 + e3], low: this.low[i2 + e3], close: this.close[i2 + e3] }));
  }
}
var jE = Rs('<div class="flex justify-center items-center h-64"><span class="loading loading-lg text-base-content/50"></span></div>'), HE = Rs("<div></div>"), qE = Rs('<div class="card bg-base-300"><div class="relative"><!> <!> <div class="absolute top-3 left-3 bg-base-300 flex gap-2 items-center"><div> </div> <div><span class="bg-primary/50 px-2 py-1 text-xs card"> </span></div></div> <div class="card-actions justify-end absolute top-2 right-2 z-[10]"><button class="btn btn-xs btn-circle btn-outline">✕</button></div></div></div>');
function XE(t2, e2) {
  G(e2, false);
  const [i2, s2] = $r(), n2 = () => zr(BE, "$stockStore", i2), r2 = "https://firestore.googleapis.com/v1/projects/fdata-299302/databases/(default)/documents";
  let o2 = Lr(e2, "width", 12, ""), a2 = Mt(), l2 = Mt();
  async function h2(t3) {
    await async function(t4) {
      zt(c2, true), await async function(t5) {
        const e3 = await async function(t6) {
          try {
            const e4 = await fetch(`${r2}/twStock/${t6}`);
            if (!e4.ok) throw new Error("Failed to fetch stock data");
            const i4 = await e4.json();
            console.log("Raw Firestore response:", i4);
            const s3 = i4.fields.price.mapValue.fields;
            console.log("Price data from Firestore:", s3);
            const n3 = { date: s3.date.arrayValue.values.map((t7) => t7.timestampValue), open: s3.open.arrayValue.values.map((t7) => parseFloat(t7.doubleValue || t7.integerValue || 0)), high: s3.high.arrayValue.values.map((t7) => parseFloat(t7.doubleValue || t7.integerValue || 0)), close: s3.close.arrayValue.values.map((t7) => parseFloat(t7.doubleValue || t7.integerValue || 0)), low: s3.low.arrayValue.values.map((t7) => parseFloat(t7.doubleValue || t7.integerValue || 0)), volume: s3.volume.arrayValue.values.map((t7) => parseFloat(t7.doubleValue || t7.integerValue || 0)) };
            console.log("Transformed stock data:", n3);
            const o3 = new Stock(n3);
            return console.log("Created Stock instance:", o3), o3;
          } catch (t7) {
            return console.error("Error fetching stock data:", t7), null;
          }
        }(t5), i3 = e3.createCandlestickSeries(0, -1);
        i3.forEach((t6) => {
          try {
            if ("string" != typeof t6.time) throw new Error("Invalid date format");
            t6.time = t6.time.split("T")[0];
          } catch (e4) {
            console.error("Error processing time:", t6.time, e4), t6.time = null;
          }
        }), u2 = i3;
      }(t4.assetId), zt(c2, false), p2();
    }(t3), await ls(), hs(a2);
  }
  let c2 = Mt(false);
  let u2, d2 = Mt(), f2 = null;
  function p2() {
    f2 || (f2 = new TwChart(hs(d2), false));
    const t3 = ER(zr(RR, "$theme", i2));
    f2.setTheme("dark" === t3 ? "dark" : "light"), f2.addCandlestickSeries(), f2.updateCandlestickSeriesData(u2);
    const e3 = "light" === t3 ? "rgb(107 114 128)" : "rgb(209 213 219)";
    f2.chart.applyOptions({ grid: { vertLines: { color: "#77777777", style: oz.Dotted, visible: true }, horzLines: { color: "#77777777", style: oz.Dotted, visible: true } }, crosshair: { horzLine: { visible: true, color: "#777777", style: oz.Dotted, labelVisible: true }, vertLine: { visible: true, color: "#777777", style: oz.Dotted, labelVisible: true } } });
    const s3 = new Date(hs(l2).exitDate), n3 = new Date(hs(l2).entryDate);
    function r3(t4) {
      const e4 = 6e4 * t4.getTimezoneOffset();
      return new Date(t4 - e4).toISOString().split("T")[0];
    }
    const o3 = [{ time: r3(n3), price: hs(l2).entryPrice }];
    let a3 = [];
    s3 > n3 && a3.push({ time: r3(s3), price: hs(l2).exitPrice }), f2.addTradeMarkers(o3, a3, e3);
  }
  const m2 = rn();
  function g2() {
    m2("close"), h2(hs(l2)), BE.set(null);
  }
  function v2(t3) {
    "Escape" === t3.key && g2();
  }
  en(() => {
    window.addEventListener("keydown", v2);
  }), sn(() => {
    window.removeEventListener("keydown", v2);
  }), $e(() => n2(), () => {
    zt(l2, n2());
  }), $e(() => hs(l2), () => {
    hs(l2) && h2(hs(l2));
  }), De(), yr();
  var b2 = qE(), _2 = me(b2), y2 = me(_2), x2 = (t3) => {
    As(t3, jE());
  };
  on(y2, (t3) => {
    hs(c2) && t3(x2);
  });
  var w2 = ve(y2, 2), k2 = (t3) => {
    var e3 = HE();
    _r(e3, (t4) => zt(d2, t4), () => hs(d2)), Pe(() => Nn(e3, 1, "mt-12 mb-4 h-64 w-full " + (hs(c2) ? "hidden" : "block"))), As(t3, e3);
  };
  on(w2, (t3) => {
    hs(l2) && t3(k2);
  });
  var M2 = ve(w2, 2), S2 = me(M2), C2 = me(S2, true);
  ie(S2);
  var z2 = ve(S2, 2), R2 = me(z2), E2 = me(R2, true);
  ie(R2), ie(z2), ie(M2);
  var P2 = ve(M2, 2), T2 = me(P2);
  ie(P2), ie(_2), ie(b2), _r(b2, (t3) => zt(a2, t3), () => hs(a2)), Pe(() => {
    In(b2, `width: ${o2() ?? ""}`), Us(C2, n2().assetName), Us(E2, n2().industry);
  }), Ms("click", T2, g2), As(t2, b2);
  var L2 = J({ get width() {
    return o2();
  }, set width(t3) {
    o2(t3), rs();
  } });
  return s2(), L2;
}
Ar(XE, { width: {} }, [], [], true);
var KE = Rs('<span class="pl-2"> </span>'), UE = Rs("<th> <!></th>"), YE = Rs("<td><!></td>"), GE = Rs('<tr class="relative"><!></tr>'), JE = Rs('<tr class="border-b border-primary/0 hover:border-base-content/20 bg-base-100 cursor-pointer rounded-lg"></tr> <!>', 1), QE = Rs('<div style="clip-path: inset(0 0 0 0);"><div class="relative w-full -mt-24"><div class="sticky top-0 z-20"><div class="overflow-x-auto scrollbar-hide pointer-events-none select-none" tabindex="-1" aria-hidden="true"><table class="table table-fixed m-0"><thead class="z-20 h-8 pb-4 bg-base-100"><tr></tr></thead></table></div></div> <div class="overflow-x-auto overflow-y-hidden"><table class="table table-fixed m-0"><tbody></tbody></table></div></div></div>');
function ZE(t2, e2) {
  G(e2, false);
  const [i2, s2] = $r(), n2 = () => zr(BE, "$stockStore", i2);
  let r2 = Lr(e2, "rows", 28, () => []), o2 = Lr(e2, "columns", 28, () => []), a2 = Lr(e2, "theme", 12, "light"), l2 = Mt([]), h2 = Mt(), c2 = Mt();
  let u2 = Mt(), d2 = Mt();
  let f2 = Mt(), p2 = Mt("100%");
  const m2 = rn();
  function g2() {
    m2("close");
  }
  function v2(t3) {
    t3.detail;
  }
  $e(() => fs(r2()), () => {
    zt(l2, r2()), zt(h2, null), zt(c2, true);
  }), $e(() => n2(), () => {
    zt(f2, n2());
  }), $e(() => (hs(f2), hs(d2)), () => {
    hs(f2) && hs(d2) && zt(p2, `${hs(d2).clientWidth}px`);
  }), De(), yr();
  var b2 = QE(), _2 = me(b2), y2 = me(_2), x2 = me(y2), w2 = me(x2), k2 = me(w2), M2 = me(k2);
  hn(M2, 5, o2, (t3) => t3.key, (t3, e3) => {
    var i3 = UE(), s3 = me(i3), n3 = ve(s3), o3 = (t4) => {
      var e4 = KE(), i4 = me(e4, true);
      ie(e4), Pe(() => Us(i4, hs(c2) ? "▲" : "▼")), As(t4, e4);
    };
    on(n3, (t4) => {
      hs(h2) === hs(e3).key && t4(o3);
    }), ie(i3), Pe(() => {
      In(i3, `width: ${hs(e3).width ?? ""};`), Nn(i3, 1, `tracking-wider pt-24 cursor-pointer font-bold whitespace-nowrap
									 ${"name" === hs(e3).key ? "pl-0 text-left sticky left-0 bg-base-100" : "text-right"} 
									  
									 ${hs(h2) === hs(e3).key ? "text-primary" : ""}
									 `), Us(s3, `${hs(e3).name ?? ""} `);
    }), Ms("click", i3, () => function(t4) {
      if (!t4.sort) return;
      const e4 = t4.key;
      hs(h2) === e4 ? zt(c2, !hs(c2)) : (zt(h2, e4), zt(c2, true)), zt(l2, [...r2()].sort((t5, i4) => {
        const s4 = t5[e4], n4 = i4[e4];
        if (s4 === n4) return 0;
        const r3 = s4 < n4 ? -1 : 1;
        return hs(c2) ? r3 : -r3;
      }));
    }(hs(e3))), As(t3, i3);
  }), ie(M2), ie(k2), ie(w2), ie(x2), _r(x2, (t3) => zt(u2, t3), () => hs(u2)), ie(y2);
  var S2 = ve(y2, 2), C2 = me(S2), z2 = me(C2);
  hn(z2, 5, () => hs(l2), (t3) => t3.assetId, (t3, i3) => {
    var s3 = JE(), n3 = ge(s3), r3 = mt(() => function(t4) {
      m2("click", t4);
    }(hs(i3)));
    hn(n3, 5, o2, (t4) => t4.name, (t4, s4) => {
      var n4 = YE(), r4 = me(n4), o3 = (t5) => {
        var s5 = Ts();
        bn(ge(s5), e2, "name", { get row() {
          return hs(i3);
        } }, (t6) => {
          var e3 = Ps();
          Pe(() => Us(e3, hs(i3).name)), As(t6, e3);
        }), As(t5, s5);
      }, a3 = (t5, n5) => {
        var r5 = (t6) => {
          var s5 = Ts();
          bn(ge(s5), e2, "action", { get row() {
            return hs(i3);
          } }, (t7) => {
            var e3 = Ps();
            Pe(() => Us(e3, hs(i3).action)), As(t7, e3);
          }), As(t6, s5);
        }, o4 = (t6, n6) => {
          var r6 = (t7) => {
            var s5 = Ts();
            bn(ge(s5), e2, "entryDate", { get row() {
              return hs(i3);
            } }, (t8) => {
              var e3 = Ps();
              Pe(() => Us(e3, hs(i3).entryDate)), As(t8, e3);
            }), As(t7, s5);
          }, o5 = (t7, n7) => {
            var r7 = (t8) => {
              var s5 = Ts();
              bn(ge(s5), e2, "profit", { get row() {
                return hs(i3);
              } }, (t9) => {
                var e3 = Ps();
                Pe(() => Us(e3, hs(i3).profit)), As(t9, e3);
              }), As(t8, s5);
            }, o6 = (t8, n8) => {
              var r8 = (t9) => {
                var s5 = Ts();
                bn(ge(s5), e2, "currentWeight", { get row() {
                  return hs(i3);
                } }, (t10) => {
                  var e3 = Ps();
                  Pe(() => Us(e3, hs(i3).currentWeight)), As(t10, e3);
                }), As(t9, s5);
              }, o7 = (t9, n9) => {
                var r9 = (t10) => {
                  var s5 = Ts();
                  bn(ge(s5), e2, "nextWeight", { get row() {
                    return hs(i3);
                  } }, (t11) => {
                    var e3 = Ps();
                    Pe(() => Us(e3, hs(i3).nextWeight)), As(t11, e3);
                  }), As(t10, s5);
                }, o8 = (t10, n10) => {
                  var r10 = (t11) => {
                    var s5 = Ts();
                    bn(ge(s5), e2, "RSV", { get row() {
                      return hs(i3);
                    } }, (t12) => {
                      var e3 = Ps();
                      Pe(() => Us(e3, hs(i3).RSV)), As(t12, e3);
                    }), As(t11, s5);
                  }, o9 = (t11) => {
                    var e3 = Ps();
                    Pe(() => Us(e3, hs(i3)[hs(s4).key] ? hs(i3)[hs(s4).key] : "-")), As(t11, e3);
                  };
                  on(t10, (t11) => {
                    "RSV" === hs(s4).key ? t11(r10) : t11(o9, false);
                  }, n10);
                };
                on(t9, (t10) => {
                  "nextWeight" === hs(s4).key ? t10(r9) : t10(o8, false);
                }, n9);
              };
              on(t8, (t9) => {
                "currentWeight" === hs(s4).key ? t9(r8) : t9(o7, false);
              }, n8);
            };
            on(t7, (t8) => {
              "profit" === hs(s4).key ? t8(r7) : t8(o6, false);
            }, n7);
          };
          on(t6, (t7) => {
            "entryDate" === hs(s4).key ? t7(r6) : t7(o5, false);
          }, n6);
        };
        on(t5, (t6) => {
          "action" === hs(s4).key ? t6(r5) : t6(o4, false);
        }, n5);
      };
      on(r4, (t5) => {
        "name" === hs(s4).key ? t5(o3) : t5(a3, false);
      }), ie(n4), Pe(() => {
        In(n4, `width: ${hs(s4).width ?? ""};`), Nn(n4, 1, `whitespace-nowrap
							  ${"name" === hs(s4).key ? "pl-0 text-left sticky bg-base-100 left-0 z-10" : "text-right"}
									`);
      }), As(t4, n4);
    }), ie(n3);
    var l3 = ve(n3, 2), h3 = (t4) => {
      var e3 = GE();
      XE(me(e3), { get width() {
        return hs(p2);
      }, get theme() {
        return a2();
      }, $$events: { close: g2, heightChange: v2 } }), ie(e3), As(t4, e3);
    };
    on(l3, (t4) => {
      hs(f2) && hs(i3).assetId === hs(f2).assetId && t4(h3);
    }), Ms("click", n3, function(...t4) {
      var _a3;
      (_a3 = hs(r3)) == null ? void 0 : _a3.apply(this, t4);
    }), As(t3, s3);
  }), ie(z2), ie(C2), ie(S2), _r(S2, (t3) => zt(d2, t3), () => hs(d2)), ie(_2), ie(b2), Ms("scroll", S2, () => function(t3, e3) {
    e3.scrollLeft = t3.scrollLeft;
  }(hs(d2), hs(u2))), As(t2, b2);
  var R2 = J({ get rows() {
    return r2();
  }, set rows(t3) {
    r2(t3), rs();
  }, get columns() {
    return o2();
  }, set columns(t3) {
    o2(t3), rs();
  }, get theme() {
    return a2();
  }, set theme(t3) {
    a2(t3), rs();
  } });
  return s2(), R2;
}
function tP(t2) {
  const e2 = function(t3) {
    if (!t3) return 0;
    const e3 = t3.codePointAt(0);
    if (void 0 === e3) throw new Error("Invalid character");
    return e3 % 360;
  }(t2), i2 = function(t3, e3, i3) {
    let s3, n2, r2;
    {
      const o2 = (t4, e4, i4) => (i4 < 0 && (i4 += 1), i4 > 1 && (i4 -= 1), i4 < 1 / 6 ? t4 + 6 * (e4 - t4) * i4 : i4 < 0.5 ? e4 : i4 < 2 / 3 ? t4 + (e4 - t4) * (2 / 3 - i4) * 6 : t4);
      let a2 = i3 + e3 - i3 * e3, l2 = 2 * i3 - a2;
      s3 = o2(l2, a2, t3 + 1 / 3), n2 = o2(l2, a2, t3), r2 = o2(l2, a2, t3 - 1 / 3);
    }
    return [Math.round(255 * s3), Math.round(255 * n2), Math.round(255 * r2)];
  }(e2 / 360, 0.5, 0.5), s2 = function(t3, e3, i3) {
    const s3 = (t4) => {
      const e4 = t4.toString(16);
      return 1 === e4.length ? "0" + e4 : e4;
    };
    return `#${s3(t3)}${s3(e3)}${s3(i3)}`;
  }(...i2);
  return s2 + "77";
}
function eP(t2) {
  const e2 = {};
  for (let [i2, s2] of t2.entries()) s2 instanceof Map ? e2[i2] = eP(s2) : e2[i2] = s2;
  return e2;
}
function iP(t2) {
  if ("object" != typeof t2 || null === t2) return console.log("Invalid: obj is not an object or is null"), false;
  t2 instanceof Map && (t2 = eP(t2));
  const e2 = ["assetName", "assetId"], i2 = ["entryDate", "exitDate"], s2 = ["entryPrice", "exitPrice", "currentPrice", "profit", "currentWeight", "nextWeight", "rsv20"];
  for (const i3 of e2) if ("string" != typeof t2[i3]) return console.log(`Invalid: ${i3} is not a string`), false;
  for (const e3 of i2) if (!(t2[e3] instanceof Date) && void 0 !== t2[e3]) return console.log(`Invalid: ${e3} is not a Date`), false;
  for (const e3 of s2) if ("number" != typeof t2[e3]) return console.log(`Invalid: ${e3} is not a number`), false;
  if (null !== t2.action) {
    if ("object" != typeof t2.action || null === t2.action) return console.log("Invalid: action is not an object or is null"), false;
    const e3 = ["type", "reason", "date", "profit"];
    for (const i4 of e3) if (!(i4 in t2.action)) return console.log(`Invalid: ${i4} is missing in action`), false;
    if (!["entry", "exit", "hold", "entry_f", "exit_p"].includes(t2.action.type)) return console.log("Invalid: action.type is not one of 'entry', 'exit', 'hold'"), false;
    const i3 = ["sl", "tp", "sl_", "tp_", "_", "enter", "exit", "sl_enter", "tp_enter"];
    if (!i3.includes(t2.action.reason)) return console.log(`Invalid: action.reason is not one of ${i3}`), false;
    if (!(t2.action.date instanceof Date) && void 0 !== t2.action.date) return console.log("Invalid: action.date is not a Date"), false;
    if ("number" != typeof t2.action.profit) return console.log("Invalid: action.profit is not a number"), false;
  }
  return true;
}
Ar(ZE, { rows: {}, columns: {}, theme: {} }, ["name", "action", "entryDate", "profit", "currentWeight", "nextWeight", "RSV"], [], true), Chart.register(...Nd);
var sP = Rs('<p class="text-sm"> </p>'), nP = Rs(" <br/> ", 1), rP = Rs('<div class="flex flex-col items-center gap-2"><h1 class="flex items-end font-bold text-4xl"><span class="text-sm"><!></span> <span style="position: relative; top: 3px;"> </span> <span class="text-sm"><!></span></h1> <!></div>'), oP = Rs('<div class="hidden md:flex gap-4"><div class="relative w-full" style="aspect-ratio: 1 / 1;"><canvas id="myPieChart"></canvas> <div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"><!></div></div></div> <div class="block md:hidden"><p> </p> <h1 class="flex items-end font-bold text-4xl mt-1.5 -ml-2 mb-3"><span class="text-sm"><!></span> <span style="position: relative; top: 3px;"> </span> <span class="text-sm"><!></span></h1></div>', 1);
const aP = { hash: "svelte-acpgfn", code: "" };
function lP(t2, e2) {
  G(e2, false), Cn(t2, aP);
  const i2 = Mt();
  let s2 = Lr(e2, "stockNames", 28, () => ["testStock", "testStock2"]), n2 = Lr(e2, "stockReturns", 28, () => [0.1, -0.1]), r2 = Lr(e2, "positionSizes", 28, () => [0.6, 0.4]), o2 = Lr(e2, "title", 12, "報酬"), a2 = Lr(e2, "theme", 12), l2 = Mt(null);
  let h2, c2 = Mt(0), u2 = Mt(null);
  const d2 = (t3, e3) => {
    const i3 = 0.95 * Math.abs(t3 / e3) + 0.05;
    return kR(t3 > 0 ? MR() : SR(), i3);
  }, f2 = CR, p2 = () => {
    (() => {
      let t4 = r2().reduce((t5, e4) => t5 + (0 !== e4 ? e4 : 0), 0);
      zt(c2, r2().reduce((t5, e4, i4) => 0 !== e4 ? t5 + e4 * n2()[i4] : t5, 0) / t4);
    })();
    const t3 = r2().map((t4, e4) => t4 * n2()[e4]);
    const e3 = [...Array(s2().length).keys()].sort(function(e4, i4) {
      const s3 = (t3[i4] > 0) - (t3[e4] > 0), n3 = (t3[e4], t3[i4] * r2()[i4] - t3[e4] * r2()[e4]);
      return 0 === s3 ? -n3 : -s3;
    }).filter((t4) => r2()[t4] > 0), i3 = e3.map((t4) => 100 * r2()[t4] + Math.abs(n2()[t4])), o3 = e3.map((t4) => s2()[t4]), a3 = e3.map((t4) => n2()[t4]), l3 = e3.map((t4) => r2()[t4]), p3 = e3.map((e4) => t3[e4]), m3 = Math.max(...p3.map(Math.abs));
    i3.map((t4) => t4).sort((t4, e4) => e4 - t4)[4];
    const g3 = { labels: o3, datasets: [{ data: l3, backgroundColor: p3.map((t4) => d2(t4, m3)), hoverBackgroundColor: p3.map((t4) => d2(t4, m3)) }] }, v3 = document.getElementById("myPieChart"), b3 = v3.getContext("2d"), _3 = { type: "doughnut", data: g3, options: { cutout: "75%", rotation: 0, responsive: true, animation: { duration: 0 }, elements: { arc: { borderWidth: 6, borderColor: "#00000000" } }, plugins: { legend: { display: false }, tooltip: { enabled: false } }, onHover(t4, e4) {
      if (e4.length > 0) {
        const t5 = e4[0].index;
        zt(u2, o3[t5]);
      } else zt(u2, null);
    } }, plugins: [{ id: "htmlLegend", afterDraw(t4) {
      const e4 = t4.canvas, i4 = t4.data.datasets[0], s3 = e4.parentNode;
      document.getElementsByClassName("chart-label").length > 0 || i4.data.forEach((i5, n3) => {
        const r3 = t4.getDatasetMeta(0).data[n3];
        r3.tooltipPosition();
        const o4 = (r3.endAngle - r3.startAngle) / 2 + r3.startAngle, h3 = r3.outerRadius + 40, c3 = t4.width / 2 + Math.cos(o4) * h3, u3 = t4.height / 2 + Math.sin(o4) * h3;
        let d3 = 1 - 1.5 * (t4.height - Math.abs(u3 - t4.height)) / t4.height;
        d3 < 0.7 && (d3 = 0.7), l3[n3] < 0.03 && (d3 = 0);
        const p4 = document.createElement("div");
        p4.style.lineHeight = "1", p4.style.opacity = d3;
        const m4 = document.createElement("span");
        var g4;
        m4.style.fontSize = "0.9rem", m4.innerHTML = (g4 = Math.round(1e4 * a3[n3]) / 100) > 0 ? `+${g4}` : g4;
        const v4 = document.createElement("span");
        v4.style.fontSize = "0.6rem", v4.innerHTML = "%", l3[n3] > 0.04 || d3 > 0.7 ? (m4.style.color = f2(a3[n3]), v4.style.color = f2(a3[n3])) : (m4.style.color = "#00000000", v4.style.color = "#00000000"), m4.style.fontWeight = "bold";
        const b4 = document.createElement("span");
        b4.innerHTML = t4.data.labels[n3], b4.style.fontSize = "0.8rem", p4.appendChild(b4), p4.appendChild(document.createElement("br")), p4.appendChild(m4), p4.appendChild(v4);
        const _4 = document.createElement("div");
        _4.className = "chart-label", _4.style.position = "absolute", _4.style.transform = "translate(-50%, -50%)", _4.style.pointerEvents = "none", _4.style.whiteSpace = "nowrap", _4.style.textAlign = "right", _4.appendChild(p4), s3.appendChild(_4), _4.style.left = e4.offsetLeft + c3 + "px", _4.style.top = e4.offsetTop + u3 + "px";
        const y3 = document.createElement("div");
        y3.style.lineHeight = "1.2", y3.style.color = "#FFFFFFaa", y3.style.opacity = d3;
        const x3 = document.createElement("span");
        x3.style.fontSize = "0.7rem", x3.innerHTML = Math.round(100 * l3[n3]) / 100, y3.appendChild(x3);
        const w3 = t4.width / 2 + Math.cos(o4) * h3 / 1.6, k3 = t4.height / 2 + Math.sin(o4) * h3 / 1.6, M3 = document.createElement("div");
        M3.style.position = "absolute", M3.className = "chart-label", M3.style.transform = "translate(-50%, -50%)", M3.style.pointerEvents = "none", M3.style.whiteSpace = "nowrap", M3.style.textAlign = "right", M3.style.marginTop = "-24px", M3.style.zIndex = 1e3, M3.style.left = e4.offsetLeft + w3 + "px", M3.style.top = e4.offsetTop + k3 + 20 + "px";
      });
    }, beforeDraw(t4) {
      const e4 = t4.canvas.parentNode;
      if (e4) {
        e4.querySelectorAll(".chart-label").forEach((t5) => t5.remove());
      }
    } }] };
    h2 && (h2.destroy(), h2 = null, b3.clearRect(0, 0, v3.width, v3.height)), h2 = new Chart(b3, _3);
  };
  en(() => {
    p2();
  });
  let m2 = Mt();
  $e(() => hs(u2), () => {
    hs(u2) && setTimeout(() => {
      zt(u2, null);
    }, 2e3);
  }), $e(() => (hs(u2), hs(c2), fs(n2()), fs(s2())), () => {
    zt(i2, null === hs(u2) ? Math.round(1e4 * hs(c2)) / 100 : Math.round(1e4 * n2()[s2().indexOf(hs(u2))]) / 100);
  }), De(), yr();
  var g2 = oP(), v2 = ge(g2), b2 = me(v2), _2 = ve(me(b2), 2);
  ((t3) => {
    var e3 = rP(), n3 = me(e3), a3 = me(n3), h3 = me(a3), c3 = (t4) => {
      NR(t4, { size: "1.5em" });
    }, d3 = (t4) => {
      AR(t4, { size: "1.5em" });
    };
    on(h3, (t4) => {
      hs(i2) > 0 ? t4(c3) : t4(d3, false);
    }), ie(a3);
    var p3 = ve(a3, 2), m3 = me(p3, true);
    ie(p3);
    var g3 = ve(p3, 2);
    YR(me(g3), { size: "1.2em" }), ie(g3), ie(n3);
    var v3 = ve(n3, 2), b3 = (t4) => {
      var e4 = sP(), i3 = me(e4, true);
      ie(e4), _r(e4, (t5) => zt(l2, t5), () => hs(l2)), Pe(() => Us(i3, o2())), As(t4, e4);
    }, _3 = (t4) => {
      var e4 = nP(), i3 = ge(e4), n4 = ve(i3, 2);
      Pe((t5) => {
        Us(i3, `${hs(u2) ?? ""} `), Us(n4, ` ${t5 ?? ""}`);
      }, [() => Math.round(100 * r2()[s2().indexOf(hs(u2))]) / 100], gt), As(t4, e4);
    };
    on(v3, (t4) => {
      null === hs(u2) ? t4(b3) : t4(_3, false);
    }), ie(e3), Pe((t4, e4) => {
      In(n3, `color: ${t4 ?? ""}`), Us(m3, e4);
    }, [() => f2(hs(i2)), () => Math.abs(hs(i2))], gt), As(t3, e3);
  })(me(_2)), ie(_2), ie(b2), ie(v2), _r(v2, (t3) => zt(m2, t3), () => hs(m2));
  var y2 = ve(v2, 2), x2 = me(y2), w2 = me(x2, true);
  ie(x2);
  var k2 = ve(x2, 2), M2 = me(k2), S2 = me(M2), C2 = (t3) => {
    NR(t3, { size: "2em" });
  }, z2 = (t3) => {
    AR(t3, { size: "2em" });
  };
  on(S2, (t3) => {
    hs(i2) > 0 ? t3(C2) : t3(z2, false);
  }), ie(M2);
  var R2 = ve(M2, 2), E2 = me(R2, true);
  ie(R2);
  var P2 = ve(R2, 2);
  return YR(me(P2), { size: "2em" }), ie(P2), ie(k2), ie(y2), Pe((t3, e3) => {
    Us(w2, o2()), In(k2, `color: ${t3 ?? ""}`), Us(E2, e3);
  }, [() => f2(hs(i2)), () => Math.abs(hs(i2))], gt), As(t2, g2), J({ get stockNames() {
    return s2();
  }, set stockNames(t3) {
    s2(t3), rs();
  }, get stockReturns() {
    return n2();
  }, set stockReturns(t3) {
    n2(t3), rs();
  }, get positionSizes() {
    return r2();
  }, set positionSizes(t3) {
    r2(t3), rs();
  }, get title() {
    return o2();
  }, set title(t3) {
    o2(t3), rs();
  }, get theme() {
    return a2();
  }, set theme(t3) {
    a2(t3), rs();
  } });
}
Ar(lP, { stockNames: {}, stockReturns: {}, positionSizes: {}, title: {}, theme: {} }, [], [], true);
const hP = (t2, e2, i2) => {
  zt(e2, !hs(e2)), i2();
};
var cP = Rs('<button class="btn btn-ghost btn-xs top-0 right-0 absolute"><!></button>'), uP = Rs("<div><canvas></canvas></div>"), dP = Rs('<div class="relative -ml-2"><!> <!></div>');
function fP(t2, e2) {
  G(e2, true);
  const [i2, s2] = $r();
  let n2 = Lr(e2, "stockNames", 7), r2 = Lr(e2, "stockReturns", 7), o2 = Lr(e2, "positionSizes", 7);
  const a2 = CR;
  let l2 = null, h2 = null, c2 = kt(240), u2 = kt(false), d2 = kt(false);
  const f2 = () => {
    if (!h2) return;
    const t3 = r2().map((t4, e4) => ({ returnVal: t4, index: e4 })).filter((t4) => !isNaN(t4.returnVal)).filter((t4) => o2()[t4.index] > 0).sort((t4, e4) => e4.returnVal - t4.returnVal).map((t4) => t4.index);
    let e3 = t3;
    if (t3.length > 15 && !hs(u2)) {
      const i4 = 7;
      e3 = [...t3.slice(0, i4), -1, ...t3.slice(-8)], zt(d2, true);
    } else t3.length > 15 && zt(d2, true);
    const i3 = e3.map((t4) => -1 === t4 ? "..." : n2()[t4]), s3 = e3.map((t4) => -1 === t4 ? 0 : r2()[t4]);
    e3.map((t4) => -1 === t4 ? 0 : Math.abs(r2()[t4]));
    const c3 = true, f3 = { labels: i3, datasets: [{ data: s3, backgroundColor: s3.map((t4) => ((t5, e4) => {
      const i4 = Math.max(...e4.filter((t6) => t6 == t6).map(Math.abs)), s4 = 0.7 * Math.abs(t5 / i4) + 0.3;
      return kR(t5 >= 0 ? MR() : SR(), s4);
    })(t4, s3)), borderRadius: 12, borderWidth: 0 }] }, p3 = h2.getContext("2d"), m3 = document.querySelector(".text-base-content");
    if (!p3 || !m3) return void console.error("Canvas context or theme element not found");
    const g3 = getComputedStyle(m3).color, v3 = { type: "bar", data: f3, options: { responsive: true, maintainAspectRatio: false, indexAxis: "x", layout: { padding: { top: 36, bottom: 0, left: 8, right: 0 } }, animation: { duration: 0 }, scales: { x: { display: c3, max: void 0, ticks: { color: g3, minRotation: 0, maxRotation: 90, beginAtZero: true, autoSkip: false, callback: (t4, e4) => i3[e4] }, grid: { display: false } }, y: { display: false, max: Math.max(0.01, ...s3.map((t4) => Math.abs(t4))), ticks: { beginAtZero: true, color: g3, format: { style: "percent" }, display: false, autoSkip: false, callback: (t4, e4) => t4 }, position: "left", grid: { display: false } } }, plugins: { legend: { enabled: false, display: false }, tooltip: { enabled: false } } }, plugins: [{ id: "barLabels", afterDatasetsDraw(t4) {
      t4.options.animation.duration = 0;
      const e4 = t4.ctx;
      t4.options.scales.x.ticks.color = g3, t4.options.scales.y.ticks.color = g3, t4.data.datasets.forEach(function(n3, r3) {
        t4.getDatasetMeta(r3).data.forEach(function(t5, n4) {
          const r4 = s3[n4];
          e4.fillStyle = a2(r4), e4.textAlign = "center";
          {
            const s4 = 15;
            e4.font = "12px sans-serif";
            i3.length > 12 ? (e4.save(), e4.translate(t5.x, r4 >= 0 ? t5.y - s4 - 5 : t5.y - t5.height - 20), e4.rotate(-Math.PI / 2), e4.textAlign = "center", e4.fillText(Math.abs(Math.round(1e3 * r4) / 10) + "%", 0, 0 + t5.width / 2 - 6), e4.restore()) : e4.fillText(Math.abs(Math.round(1e3 * r4) / 10) + "%", t5.x, r4 >= 0 ? t5.y - s4 : t5.y - t5.height - 14);
          }
        });
      });
    } }] };
    l2 && l2.destroy(), l2 = new Chart(p3, v3);
  };
  Se(() => (h2 && zr(RR, "$theme", i2) && f2(), () => {
    l2 && l2.destroy();
  })), en(() => f2());
  var p2 = dP(), m2 = me(p2), g2 = (t3) => {
    var e3 = cP();
    e3.__click = [hP, u2, f2];
    var i3 = me(e3), s3 = (t4) => {
      UR(t4, { size: 16 });
    }, n3 = (t4) => {
      KR(t4, { size: 16 });
    };
    on(i3, (t4) => {
      hs(u2) ? t4(s3) : t4(n3, false);
    }), ie(e3), As(t3, e3);
  };
  on(m2, (t3) => {
    hs(d2) && t3(g2);
  });
  var v2 = ve(m2, 2), b2 = (t3) => {
    var e3 = uP(), i3 = me(e3);
    _r(i3, (t4) => h2 = t4, () => h2), ie(e3), Pe(() => {
      In(e3, `height: ${hs(c2) ?? ""}px;width: 100%;`), er(i3, "height", hs(c2));
    }), As(t3, e3);
  };
  on(v2, (t3) => {
    0 != hs(c2) && t3(b2);
  }), ie(p2), As(t2, p2);
  var _2 = J({ get stockNames() {
    return n2();
  }, set stockNames(t3) {
    n2(t3), rs();
  }, get stockReturns() {
    return r2();
  }, set stockReturns(t3) {
    r2(t3), rs();
  }, get positionSizes() {
    return o2();
  }, set positionSizes(t3) {
    o2(t3), rs();
  } });
  return s2(), _2;
}
Ss(["click"]), Ar(fP, { stockNames: {}, stockReturns: {}, positionSizes: {} }, [], [], true);
function pP(t2) {
  var _a3, _b3;
  if ("stringValue" in t2) return t2.stringValue;
  if ("integerValue" in t2) return parseInt(t2.integerValue, 10);
  if ("doubleValue" in t2) return t2.doubleValue;
  if ("booleanValue" in t2) return t2.booleanValue;
  if ("nullValue" in t2) return null;
  if ("arrayValue" in t2 && ((_a3 = t2.arrayValue) == null ? void 0 : _a3.values)) return t2.arrayValue.values.map(pP);
  if ("mapValue" in t2 && ((_b3 = t2.mapValue) == null ? void 0 : _b3.fields)) {
    const e2 = {};
    for (const [i2, s2] of Object.entries(t2.mapValue.fields)) e2[i2] = pP(s2);
    return e2;
  }
  return null;
}
async function mP() {
  console.log("API call");
  try {
    const t2 = await fetch("https://firestore.googleapis.com/v1/projects/fdata-299302/databases/(default)/documents/twIntraday/realtime");
    if (!t2.ok) throw new Error(`HTTP error! status: ${t2.status}`);
    return function(t3) {
      var _a3;
      if (!t3 || !t3.fields) return {};
      const e2 = {};
      for (const [i2, s2] of Object.entries(t3.fields)) if ((_a3 = s2.mapValue) == null ? void 0 : _a3.fields) {
        e2[i2] = {};
        for (const [t4, n2] of Object.entries(s2.mapValue.fields)) e2[i2][t4] = pP(n2);
      }
      return e2;
    }(await t2.json());
  } catch (t2) {
    throw console.error("Error fetching realtime data:", t2), t2;
  }
}
const gP = 3e5;
const vP = function() {
  const t2 = Mr({});
  let e2 = null, i2 = false, s2 = 0;
  async function n2() {
    if (!i2) return;
    const e3 = Date.now();
    if (!(e3 - s2 < gP)) try {
      const i3 = await mP();
      t2.set(i3), s2 = e3;
    } catch (t3) {
      console.error("Error polling stock data:", t3);
    }
  }
  function r2() {
    e2 || document.hidden || (i2 = true, n2(), e2 = setInterval(n2, gP));
  }
  function o2() {
    i2 = false, e2 && (clearInterval(e2), e2 = null);
  }
  return document.addEventListener("visibilitychange", () => {
    document.hidden ? o2() : r2();
  }), { subscribe: t2.subscribe, start: r2, stop: o2 };
}(), bP = vP;
var _P = Rs('<div class="chart-label font-normal z-[99] hover:z-[100] hover:border rounded-box text-base-content/70 svelte-1v9yy1w"><span class="label-text svelte-1v9yy1w"> </span> <span class="label-value svelte-1v9yy1w"> </span></div>'), yP = Rs('<div class="svelte-1v9yy1w"><div class="w-full relative mb-16 svelte-1v9yy1w" style="height: 216px;"><div class="absolute inset-0 flex items-center justify-center z-10 pointer-events-none svelte-1v9yy1w"><div class="text-center svelte-1v9yy1w"><div class="text-lg font-extralight text-base-content svelte-1v9yy1w">產業比例</div></div></div> <canvas class="svelte-1v9yy1w"></canvas> <div class="z-[99] absolute top-0 left-0 w-full h-full pointer-events-none svelte-1v9yy1w"></div></div></div>'), xP = Rs('<div class="svelte-1v9yy1w"><!></div>');
const wP = { hash: "svelte-1v9yy1w", code: "\n	@keyframes svelte-1v9yy1w-fadeIn {\n		from {\n			opacity: 0;\n			transform: translateY(-5px);\n		}\n		to {\n			opacity: 1;\n			transform: translateY(0);\n		}\n	}.chart-label.svelte-1v9yy1w {position:absolute;transform:translate(-50%, -50%);padding:4px 8px;font-size:10px;z-index:10;display:flex;flex-direction:column;align-items:center;\n		animation: svelte-1v9yy1w-fadeInZoom 0.5s ease-out forwards;transition:all 0.3s ease;white-space:nowrap;min-width:60px;text-align:center;}.label-text.svelte-1v9yy1w {font-size:12px;overflow:hidden;text-overflow:ellipsis;max-width:90px;}.label-value.svelte-1v9yy1w {font-size:11px;font-weight:700;}\n\n	@keyframes svelte-1v9yy1w-fadeInZoom {\n		0% {\n			opacity: 0;\n			transform: translate(-50%, -50%) scale(0.8);\n		}\n		100% {\n			opacity: 1;\n			transform: translate(-50%, -50%) scale(1);\n		}\n	}" };
Ar(function(t2, e2) {
  G(e2, true), Cn(t2, wP);
  const [i2, s2] = $r();
  Chart.register(ArcElement, ud, Uu, Yu);
  let n2 = mt(() => ({ theme: zr(RR, "$theme", i2), industries: [zR("primary"), zR("secondary"), zR("accent"), zR("info"), zR("success"), zR("warning"), zR("error"), zR("neutral"), zR("base-300"), zR("base-200")], stocks: ["#FF8394", "#FFA3B4", "#FFC3D4", "#56B2FB", "#76C2FF", "#96D2FF", "#FFDE76", "#FFEE96", "#FFFEB6", "#6BD0D0", "#8BE0E0", "#ABF0F0", "#B986FF", "#D9A6FF", "#F9C6FF", "#FFAF60", "#FFBF80", "#FFCFA0", "#D9DBDF", "#E9EBEF", "#F9FBFF", "#9BD063", "#BBE083", "#DBF0A3"] })), r2 = Lr(e2, "portfolioData", 7), o2 = kt(tt({ industries: [] }));
  Se(() => {
    const t3 = r2().filter((t4) => t4.currentWeight > 0), e3 = /* @__PURE__ */ new Map();
    let i3 = 0;
    t3.forEach((t4) => {
      e3.has(t4.industry) || (e3.set(t4.industry, { name: t4.industry, weight: 0, color: hs(n2).industries[i3 % hs(n2).industries.length], stocks: [], colorIndex: i3 }), i3++);
      const s4 = e3.get(t4.industry);
      s4.weight += t4.currentWeight;
      const r3 = s4.colorIndex, o3 = s4.stocks.length, a3 = hs(n2).stocks[3 * r3 + o3 % 3];
      s4.stocks.push({ name: t4.assetName, weight: t4.currentWeight, profit: t4.profit, price: t4.currentPrice, color: a3 });
    });
    const s3 = Array.from(e3.values()).sort((t4, e4) => e4.weight - t4.weight);
    s3.forEach((t4, e4) => {
      t4.color = hs(n2).industries[e4 % hs(n2).industries.length], t4.colorIndex = e4, t4.stocks.forEach((t5, i4) => {
        t5.color = hs(n2).stocks[3 * e4 + i4 % 3];
      });
    }), zt(o2, { industries: s3 }, true);
  });
  let a2, l2 = mt(() => {
    var _a3;
    return ((_a3 = hs(o2).industries) == null ? void 0 : _a3.map((t3) => `${t3.name} (${(100 * t3.weight).toFixed(1)}%)`)) || [];
  }), h2 = mt(() => {
    var _a3;
    return ((_a3 = hs(o2).industries) == null ? void 0 : _a3.map((t3) => (100 * t3.weight).toFixed(1))) || [];
  }), c2 = mt(() => {
    var _a3;
    return ((_a3 = hs(o2).industries) == null ? void 0 : _a3.map((t3) => t3.name)) || [];
  }), u2 = mt(() => {
    var _a3;
    return ((_a3 = hs(o2).industries) == null ? void 0 : _a3.map((t3) => t3.weight)) || [];
  }), d2 = mt(() => {
    var _a3;
    return ((_a3 = hs(o2).industries) == null ? void 0 : _a3.map((t3) => t3.color)) || [];
  }), f2 = kt(null), p2 = kt(tt([]));
  function m2() {
    if (!a2) return;
    const t3 = a2.chartArea, e3 = (t3.left + t3.right) / 2, i3 = (t3.top + t3.bottom) / 2;
    let s3 = -0.5 * Math.PI;
    const n3 = Math.min(t3.right - t3.left, t3.bottom - t3.top) / 2, r3 = 1.2 * n3;
    zt(p2, hs(u2).map((t4, o3) => {
      const a3 = 2 * Math.PI * t4, u3 = s3 + a3 / 2, f3 = e3 + Math.cos(u3) * r3, p3 = i3 + Math.sin(u3) * r3, m3 = e3 + Math.cos(u3) * (0.85 * n3), g3 = i3 + Math.sin(u3) * (0.85 * n3);
      return s3 += a3, { x: f3, y: p3, lineStartX: m3, lineStartY: g3, visible: t4 > 0.03, label: hs(c2)[o3], fullLabel: hs(l2)[o3], weight: hs(h2)[o3], color: hs(d2)[o3], angle: u3 };
    }), true);
  }
  Se(() => {
    hs(f2) && hs(o2).industries && hs(o2).industries.length > 0 && (a2 && a2.destroy(), Chart.defaults.color = "#fff", Chart.defaults.borderColor = "#444", Chart.defaults.backgroundColor = "#1e1e2f", a2 = new Chart(hs(f2), { type: "doughnut", data: { datasets: [{ label: "Industries", data: hs(u2), backgroundColor: hs(d2).map((t3) => kR(t3, 0.7)), borderColor: "rgba(0,0,0,0)", borderWidth: 0, radius: "100%" }] }, options: { responsive: true, maintainAspectRatio: false, cutout: "80%", layout: { padding: 0 }, plugins: { tooltip: { enabled: true, backgroundColor: "rgba(30, 30, 47, 0.9)", titleColor: "#fff", bodyColor: "#fff", borderColor: "#555", borderWidth: 1, displayColors: true, callbacks: { title: (t3) => "", label(t3) {
      const e3 = t3.datasetIndex, i3 = t3.dataIndex;
      if (0 === e3) {
        const t4 = hs(o2).industries[i3];
        return [`${t4.name}`, `占比: ${(100 * t4.weight).toFixed(1)}%`, `股票數: ${t4.stocks.length} 檔`];
      }
      return "";
    } } } }, animation: { onComplete() {
      m2();
    } } } }), m2());
  }), sn(() => {
    a2 && a2.destroy();
  });
  var g2 = xP(), v2 = me(g2), b2 = (t3) => {
    var e3 = yP(), i3 = me(e3), s3 = ve(me(i3), 2);
    _r(s3, (t4) => zt(f2, t4), () => hs(f2));
    var n3 = ve(s3, 2);
    hn(n3, 21, () => hs(p2), ln, (t4, e4) => {
      var i4 = Ts(), s4 = ge(i4), n4 = (t5) => {
        var i5 = _P(), s5 = me(i5), n5 = me(s5, true);
        ie(s5);
        var r3 = ve(s5, 2), o3 = me(r3);
        ie(r3), ie(i5), Pe(() => {
          In(i5, `
								left: ${hs(e4).x ?? ""}px;
								top: ${hs(e4).y ?? ""}px;
								color: ;
							`), Us(n5, hs(e4).label), Us(o3, `${hs(e4).weight ?? ""}%`);
        }), As(t5, i5);
      };
      on(s4, (t5) => {
        hs(e4).visible && t5(n4);
      }), As(t4, i4);
    }), ie(n3), ie(i3), ie(e3), As(t3, e3);
  };
  on(v2, (t3) => {
    hs(o2).industries && hs(o2).industries.length > 0 && t3(b2);
  }), ie(g2), As(t2, g2);
  var _2 = J({ get portfolioData() {
    return r2();
  }, set portfolioData(t3) {
    r2(t3), rs();
  } });
  return s2(), _2;
}, { portfolioData: {} }, [], [], true);
var kP = Rs('<div class="w-[1.2em] h-[1.2em] flex items-center justify-center">—</div>'), MP = Rs('<div class="stat-desc flex gap-2 items-center"><!> <!></div>'), SP = Rs('<div class="flex flex-col gap-3"><div class="stat-title"> </div> <div class="stat-value text-5xl flex items-end font-extralight -ml-1.5"><!> <span class="text-sm"><!></span></div> <!></div>');
Ar(function(t2, e2) {
  G(e2, true);
  let i2 = Lr(e2, "stockNames", 23, () => []), s2 = Lr(e2, "stockReturns", 23, () => []), n2 = Lr(e2, "positionSizes", 23, () => []), r2 = Lr(e2, "purchaseDates", 23, () => []), o2 = Lr(e2, "title", 7, "總回報率"), a2 = mt(() => {
    let t3 = n2().reduce((t4, e4) => t4 + (0 !== e4 ? e4 : 0), 0), e3 = n2().reduce((t4, e4, i3) => 0 !== e4 ? t4 + e4 * s2()[i3] : t4, 0) / t3;
    return Math.round(1e4 * e3) / 100;
  }), l2 = mt(() => CR(hs(a2))), h2 = mt(() => r2().length ? r2().reduce((t3, e3) => t3 < e3 ? t3 : e3) : null);
  var c2 = SP(), u2 = me(c2), d2 = me(u2, true);
  ie(u2);
  var f2 = ve(u2, 2), p2 = me(f2), m2 = (t3) => {
    NR(t3, { size: "0.7em" });
  }, g2 = (t3, e3) => {
    var i3 = (t4) => {
      AR(t4, { size: "0.7em" });
    }, s3 = (t4) => {
      As(t4, kP());
    };
    on(t3, (t4) => {
      hs(a2) < 0 ? t4(i3) : t4(s3, false);
    }, e3);
  };
  on(p2, (t3) => {
    hs(a2) > 0 ? t3(m2) : t3(g2, false);
  });
  var v2 = ve(p2), b2 = ve(v2);
  YR(me(b2), { size: "2em" }), ie(b2), ie(f2);
  var _2 = ve(f2, 2), y2 = (t3) => {
    var e3 = MP(), i3 = me(e3);
    WR(i3, { size: "1em" });
    var s3 = ve(i3, 2), n3 = (t4) => {
      var e4 = Ps();
      Pe((t5) => Us(e4, `從 ${t5 ?? ""} 持有至今的報酬率`), [() => hs(h2).toLocaleDateString("zh-TW", { year: "numeric", month: "long", day: "numeric" })]), As(t4, e4);
    }, r3 = (t4) => {
      As(t4, Ps("最近日報酬率"));
    };
    on(s3, (t4) => {
      "累計報酬" === o2() ? t4(n3) : t4(r3, false);
    }), ie(e3), As(t3, e3);
  };
  return on(_2, (t3) => {
    hs(h2) && t3(y2);
  }), ie(c2), Pe((t3) => {
    Us(d2, o2()), In(f2, `color: ${hs(l2) ?? ""}`), Us(v2, ` ${t3 ?? ""} `);
  }, [() => Math.abs(hs(a2))]), As(t2, c2), J({ get stockNames() {
    return i2();
  }, set stockNames(t3 = []) {
    i2(t3), rs();
  }, get stockReturns() {
    return s2();
  }, set stockReturns(t3 = []) {
    s2(t3), rs();
  }, get positionSizes() {
    return n2();
  }, set positionSizes(t3 = []) {
    n2(t3), rs();
  }, get purchaseDates() {
    return r2();
  }, set purchaseDates(t3 = []) {
    r2(t3), rs();
  }, get title() {
    return o2();
  }, set title(t3 = "總回報率") {
    o2(t3), rs();
  } });
}, { stockNames: {}, stockReturns: {}, positionSizes: {}, purchaseDates: {}, title: {} }, [], [], true);
var CP = Rs('<div class="w-[240px] md:w-1/3 md:mx-auto"><!></div>'), zP = Rs('<div class="md:w-2/3 overflow-scroll"><!></div>'), $P = Rs('<div class="px-6 md:pl-12 md:pr-0 mb-6 md:mb-20 relative"><div><div class="flex md:items-center md:gap-24 flex-col md:flex-row"><!> <!></div></div></div> <div class="flex gap-6 justify-end mb-12 px-6 md:pr-3"><label class="label cursor-pointer"><input type="radio" name="stockReturnType" class="radio"/> <span class="text-sm font-light">累計報酬</span></label> <label class="label cursor-pointer"><input type="radio" name="stockReturnType" class="radio"/> <span class="text-sm font-light">即時行情</span></label> <label class="label cursor-pointer mb:ml-4"><input type="checkbox" class="toggle toggle-sm mr-2"/> <span class="text-sm font-light">隱藏名稱</span></label></div>', 1), DP = Rs('<a role="tab"> </a>'), RP = Rs('<div role="tablist" class="w-full flex gap-y-4 flex-wrap border border-base-300 p-2 tabs tabs-boxed bg-base-100 mb-8 rounded-2xl" tabindex="0"></div>'), EP = Rs('<span class="text-base font-normal text-base-content/80"> </span>'), PP = Rs('<div class="mt-3"><progress max="1"></progress></div>'), TP = Rs('<div class="stat-card bg-base-100 p-6 rounded-xl shadow-sm border border-base-200"><div class="stat-title text-sm text-base-content/60 mb-1"> </div> <div class="stat-value text-2xl font-light"> <!></div> <!></div>'), LP = Rs('<div class="mb-6 mx-6 md:mx-0"><div class="grid grid-cols-2 md:grid-cols-4 gap-6"></div></div>'), VP = Rs('<span class="whitespace-nowrap font-bold text-base-content-200"> </span> <br/>', 1), OP = Rs('<div class="flex-grow text-left"><span> </span></div>'), AP = Rs('<div class="text-base font-bold relative text-ellipsis overflow-hidden text-left"><div class="flex flex-nowrap items-center"><div class="mr-3 w-8 h-8 rounded-full text-white font-bold justify-center items-center flex"><!></div> <div><!> <span class="font-light text-base-content-300"> </span></div> <!></div></div>'), FP = Rs('<div class="text-2xl text-base-content-200 font-bold items-center flex mb-4"><h2> </h2> <input type="checkbox" class="ml-4 toggle toggle-sm"/> <span class="ml-2 text-sm font-normal">顯示買入部位</span></div> <div class="grid grid-cols-2 md:grid-cols-3 gap-4 pt-1 mt-4"></div>', 1), NP = Rs('<hr class="my-6 divide-x"/>'), WP = Rs('<span class="whitespace-nowrap font-bold text-base-content-300"> </span> <br/>', 1), IP = Rs('<div class="font-bold relative text-ellipsis overflow-hidden text-left"><div class="flex flex-nowrap items-center"><div class="mr-3 w-8 h-8 rounded-full text-white font-bold justify-center items-center flex"><!></div> <div><!> <span class="font-light text-base-content-200"> </span></div></div></div>'), BP = Rs('<h2 class="text-2xl font-bold flex items-center mb-4"> </h2> <div class="grid grid-cols-2 md:grid-cols-3 gap-4 pt-1 mb-4"></div>', 1), jP = Rs('<div class="md:rounded-2xl h-full border bg-base-100 p-4 sm:p-8 mb-4"><!> <!> <!></div>'), HP = Rs('<h2 class="text-2xl text-base-content-200 font-bold mb-2 text-left">當前部位</h2>'), qP = Rs('<span class="whitespace-nowrap font-bold text-base-content-300"> </span> <br/>', 1), XP = Rs('<div slot="name" class="text-base font-bold relative text-ellipsis overflow-hidden text-left cursor-pointer"><div class="flex flex-nowrap items-center"><div class="mr-3 w-8 h-8 rounded-full text-white font-bold justify-center items-center flex"> </div> <div><!> <span class="font-light text-base-content-200"> </span></div></div></div>'), KP = Rs('<div slot="profit"><span> </span><br/> <span class="text-sm text-base-content/80"> </span></div>'), UP = Rs('<div slot="entryDate"><span class="lining-nums svelte-1nx0ef2"> </span><br/> <!> <span class="text-sm text-base-content/80"> </span><br/></div>'), YP = Rs('<div slot="currentWeight" class="lining-nums svelte-1nx0ef2"><span> </span></div>'), GP = Rs('<div slot="nextWeight" class="lining-nums svelte-1nx0ef2"><span> </span></div>'), JP = Rs(' <br/> <progress class="progress progress-primary w-32" max="1"></progress>', 1), QP = Rs('<div slot="RSV" class="text-base-content-100"><!></div>'), ZP = Rs('<div class="card min-h-[320px] flex items-center justify-center"><p>目前沒有持股喔！</p></div>'), tT = Rs('<!> <div class="card bg-base-100 border border-base-300 h-full mb-4 p-4 sm:p-8 relative"><!> <!></div>', 1), eT = Rs('<div class="text-base-content w-full text-left relative"><!> <!> <!> <!></div>');
const iT = { hash: "svelte-1nx0ef2", code: ".lining-nums.svelte-1nx0ef2 {font-weight:600;font-size:18px;line-height:32px;}" };
function sT(t2, e2) {
  G(e2, true), Cn(t2, iT);
  const [i2, s2] = $r(), n2 = () => zr(BE, "$stockStore", i2), r2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return WC[e3] ? WC[e3]() : e3;
  };
  let o2 = Lr(e2, "reportPosition", 7), a2 = Lr(e2, "lang", 7);
  let l2 = kt(false), h2 = kt("");
  function c2(t3) {
    const e3 = {};
    for (const [i3, s3] of t3.entries()) e3[i3] = s3;
    return e3.action && (e3.action = c2(e3.action)), e3;
  }
  function u2(t3) {
    null !== t3 && (t3.created = new Date(t3.created), t3.scheduled = new Date(t3.scheduled));
  }
  function d2(t3) {
    t3.forEach((t4) => {
      t4 instanceof Map && (t4 = c2(t4)), t4.entryDate = new Date(t4.entryDate), t4.exitDate = new Date(t4.exitDate), t4.entrySigDate = new Date(t4.entrySigDate), t4.exitSigDate = new Date(t4.exitSigDate), t4.action && (t4.action.date = new Date(t4.action.date)), iP(t4) || console.log("Invalid position:", t4);
    });
  }
  function f2(t3) {
    const e3 = {};
    return t3.forEach((t4) => {
      const i3 = t4.assetId;
      (!e3[i3] || new Date(t4.entrySigDate) > new Date(e3[i3].entrySigDate)) && (e3[i3] = t4);
    }), Object.values(e3);
  }
  Se(() => {
    "" === hs(h2) && p2() && zt(h2, hs(b2)[0], true);
  });
  let p2 = () => {
    let t3 = false;
    return o2() && (t3 = !("positionConfig" in o2())), t3;
  }, m2 = mt(() => {
    let t3 = null;
    if (p2()) {
      let e3 = hs(h2);
      "" != e3 && e3 in o2() || (e3 = Object.keys(o2())[0]), t3 = o2()[e3];
    } else t3 = o2();
    return t3 && t3.positions ? (d2(t3.positions), t3 = f2(t3.positions), t3 = t3.sort((t4, e3) => {
      var _a3, _b3, _c3, _d3, _e4, _f3, _g2, _h2;
      return "entry" === ((_a3 = t4.action) == null ? void 0 : _a3.type) && "entry" !== ((_b3 = e3.action) == null ? void 0 : _b3.type) ? -1 : "entry" !== ((_c3 = t4.action) == null ? void 0 : _c3.type) && "entry" === ((_d3 = e3.action) == null ? void 0 : _d3.type) ? 1 : "exit" === ((_e4 = t4.action) == null ? void 0 : _e4.type) && "exit" !== ((_f3 = e3.action) == null ? void 0 : _f3.type) ? -1 : "exit" !== ((_g2 = t4.action) == null ? void 0 : _g2.type) && "exit" === ((_h2 = e3.action) == null ? void 0 : _h2.type) ? 1 : e3.entryDate.getTime() - t4.entryDate.getTime();
    }), t3) : [];
  }), g2 = mt(() => {
    let t3 = [];
    if (p2()) for (const [e3, i3] of Object.entries(o2())) {
      const e4 = f2(i3.positions);
      for (let s3 = 0; s3 < e4.length; s3++) {
        const n3 = t3.findIndex((t4) => t4.assetName === e4[s3].assetName), r3 = e4[s3].currentWeight * i3.positionConfig.weight;
        if (0 !== r3) if (-1 === n3) t3.push({ assetName: e4[s3].assetName, assetId: e4[s3].assetId, currentWeight: r3, profit: e4[s3].profit });
        else {
          const o3 = t3[n3].currentWeight;
          t3[n3].profit = (o3 * t3[n3].profit + r3 * e4[s3].profit) / (o3 + r3), t3[n3].currentWeight += e4[s3].currentWeight * i3.positionConfig.weight;
        }
      }
    }
    else t3 = hs(m2).filter((t4) => 0 !== t4.currentWeight);
    return t3;
  }), v2 = mt(() => {
    var _a3, _b3;
    if (p2()) {
      let t3 = hs(h2);
      return "" == t3 && (t3 = Object.keys(o2())[0]), o2()[t3] && u2(o2()[t3].positionConfig), ((_a3 = o2()[t3]) == null ? void 0 : _a3.positionConfig) || {};
    }
    return u2(o2().positionConfig), ((_b3 = o2()) == null ? void 0 : _b3.positionConfig) || {};
  });
  Se(() => {
    hs(m2) && L2();
  });
  let b2 = mt(() => {
    let t3 = null;
    return t3 = p2() ? Object.keys(o2()).sort((t4, e3) => t4.localeCompare(e3)) : [], t3;
  });
  function y2(t3) {
    try {
      return WC[t3]();
    } catch (e3) {
      return console.log("Error for translation", t3), console.log(e3), t3;
    }
  }
  en(() => bP.start()), sn(() => {
    I2(), bP.stop();
  });
  const x2 = { resample: { formatter: (t3) => {
    try {
      return WC["position_resampleValue_" + t3]();
    } catch (e3) {
      return console.log("Error in positionConfigInfo.resample.formatter"), console.log(e3), console.log("position.resampleValue." + t3), t3;
    }
  }, unit: "" }, scheduled: { formatter: (t3) => hs(v2).isDailyStrategy ? t3 == null ? void 0 : t3.toLocaleDateString() : t3 == null ? void 0 : t3.toLocaleString(), unit: "" }, entryTradePrice: { formatter: (t3) => y2(`position_${t3}`) || t3, unit: "進場" }, exitTradePrice: { formatter: (t3) => y2(`position_${t3}`) || t3, unit: "出場" }, sl: { shown: (t3) => 1 != t3, formatter: (t3) => 100 !== t3 ? -(100 * t3).toFixed() : "無", unit: "%" }, tp: { shown: (t3) => t3 < 1e5, formatter: (t3) => "+" + (100 * t3).toFixed(), unit: "%" }, ts: { shown: (t3) => t3 < 1e5, formatter: (t3) => "+" + (100 * t3).toFixed(), unit: "%" } };
  let w2 = mt(() => hs(m2).filter((t3) => "hold" == t3.action.type || "exit" == t3.action.type));
  const k2 = /* @__PURE__ */ new Date();
  function M2(t3 = null) {
    !t3 || t3 instanceof Date || (t3 = new Date(t3)), t3 || (t3 = /* @__PURE__ */ new Date());
    const e3 = t3.getTime() + 6e4 * t3.getTimezoneOffset(), i3 = new Date(e3 + 288e5);
    return i3.setHours(15, 0, 0, 0), i3;
  }
  let S2, C2 = mt(() => hs(m2).filter((t3) => {
    var _a3, _b3, _c3;
    return t3.exitSigDate >= new Date(hs(v2).lastTimestamp) && k2 > M2(t3.exitSigDate) && (0 === t3.nextWeight || "exit" === ((_a3 = t3.action) == null ? void 0 : _a3.type) && ("tp" === ((_b3 = t3.action) == null ? void 0 : _b3.reason) || "sl" === ((_c3 = t3.action) == null ? void 0 : _c3.reason))) || function(t4) {
      var _a4, _b4;
      return ("tp_enter" === ((_a4 = t4.action) == null ? void 0 : _a4.reason) || "sl_enter" === ((_b4 = t4.action) == null ? void 0 : _b4.reason)) && 0 !== t4.currentWeight && hs(v2).scheduled && k2 < M2(hs(v2).scheduled);
    }(t3);
  })), z2 = mt(() => hs(m2).filter((t3) => t3.entrySigDate >= new Date(hs(v2).lastTimestamp) && k2 > M2(t3.entrySigDate) && 0 !== t3.nextWeight || function(t4) {
    var _a3, _b3;
    return ("tp_enter" === ((_a3 = t4.action) == null ? void 0 : _a3.reason) || "sl_enter" === ((_b3 = t4.action) == null ? void 0 : _b3.reason)) && 0 === t4.currentWeight && hs(v2).scheduled && k2 >= M2(hs(v2).scheduled);
  }(t3))), R2 = kt(false), E2 = mt(() => 0 !== hs(z2).length || 0 !== hs(C2).length ? [{ key: "name", name: r2("position.assetName"), sort: false, width: "160px" }, { key: "profit", name: r2("position.profit"), sort: true, width: "160px" }, { key: "entryDate", name: r2("position.entryDate"), sort: true, width: "180px" }, { key: "currentWeight", name: r2("position.currentWeight"), sort: true, width: "160px" }, { key: "nextWeight", name: r2("position.nextWeight"), sort: true, width: "160px" }, { key: "RSV", name: r2("position.RSV"), sort: false, width: "240px" }] : [{ key: "name", name: r2("position.assetName"), sort: false, width: "160px" }, { key: "profit", name: r2("position.profit"), sort: true, width: "160px" }, { key: "entryDate", name: r2("position.entryDate"), sort: true, width: "180px" }, { key: "currentWeight", name: r2("position.currentWeight"), sort: true, width: "160px" }, { key: "RSV", name: r2("position.RSV"), sort: false, width: "240px" }]);
  function P2() {
    localStorage.setItem("strategyAnalyticTab", "position"), L2();
  }
  let T2 = "選股";
  async function L2(t3) {
    if (await ls(), !S2) return;
    let e3 = S2.scrollHeight + 120, i3 = t3 ? t3.assetId : "";
    window.parent.postMessage({ frameHeight: e3, tab: T2 + " " + i3 }, "*");
  }
  const V2 = (t3) => {
    t3 = t3.detail, localStorage.setItem("strategyAnalyticTab", "position"), L2(t3), null === n2() || n2().assetId !== t3.assetId ? BE.set(t3) : BE.set(null);
  };
  let O2 = kt("cumulative");
  function A2(t3) {
    zt(O2, t3, true), "cumulative" === t3 ? bP.stop() : bP.start();
  }
  let F2 = mt(() => "cumulative" === hs(O2) ? hs(g2).map((t3) => t3.profit == t3.profit ? t3.profit : 0) : hs(g2).map((t3) => function(t4) {
    if (hs(N2)[t4]) return hs(N2)[t4];
    return { c: 0, h: 0, l: 0, o: 0, p: 0, r: 0, v: 0 };
  }(t3.assetId).r / 100)), N2 = kt(tt({}));
  const I2 = bP.subscribe((t3) => zt(N2, t3, true));
  var B2 = eT(), q2 = me(B2), K2 = (t3) => {
    var e3 = $P(), i3 = ge(e3), s3 = me(i3), n3 = me(s3), r3 = me(n3);
    an(r3, () => [hs(g2), hs(O2), hs(l2)], (t4) => {
      var e4 = CP(), i4 = me(e4);
      const s4 = mt(() => hs(g2).map((t5) => hs(l2) ? "* * * * *" : t5.assetName)), n4 = mt(() => hs(g2).map((t5) => t5.currentWeight)), r4 = mt(() => "cumulative" === hs(O2) ? "累計報酬" : "即時行情");
      lP(i4, { get stockNames() {
        return hs(s4);
      }, get stockReturns() {
        return hs(F2);
      }, get positionSizes() {
        return hs(n4);
      }, get title() {
        return hs(r4);
      } }), ie(e4), As(t4, e4);
    }), an(ve(r3, 2), () => [hs(g2), hs(O2), hs(l2)], (t4) => {
      var e4 = zP(), i4 = me(e4);
      const s4 = mt(() => hs(g2).map((t5) => hs(l2) ? "* * * * *" : t5.assetName)), n4 = mt(() => hs(g2).map((t5) => t5.currentWeight));
      fP(i4, { get stockNames() {
        return hs(s4);
      }, get stockReturns() {
        return hs(F2);
      }, get positionSizes() {
        return hs(n4);
      } }), ie(e4), As(t4, e4);
    }), ie(n3), ie(s3), ie(i3);
    var o3 = ve(i3, 2), a3 = me(o3), h3 = me(a3);
    Jn(h3), ne(2), ie(a3);
    var c3 = ve(a3, 2), u3 = me(c3);
    Jn(u3), ne(2), ie(c3);
    var d3 = ve(c3, 2), f3 = me(d3);
    Jn(f3), ne(2), ie(d3), ie(o3), Pe(() => {
      Zn(h3, "cumulative" === hs(O2)), Zn(u3, "realtime" === hs(O2));
    }), Ms("click", h3, () => A2("cumulative")), Ms("click", u3, () => A2("realtime")), mr(f3, () => hs(l2), (t4) => zt(l2, t4)), As(t3, e3);
  };
  on(q2, (t3) => {
    hs(F2) && hs(F2).length > 0 && t3(K2);
  });
  var U2 = ve(q2, 2), Q2 = (t3) => {
    var e3 = RP();
    hn(e3, 21, () => hs(b2), ln, (t4, e4) => {
      var i3 = DP();
      let s3;
      var n3 = me(i3, true);
      ie(i3), Pe((t5) => {
        s3 = Nn(i3, 1, "tab", null, s3, t5), Us(n3, hs(e4));
      }, [() => ({ "tab-active": hs(e4) === hs(h2) })]), Ms("click", i3, () => {
        zt(h2, hs(e4), true);
      }), As(t4, i3);
    }), ie(e3), As(t3, e3);
  };
  on(U2, (t3) => {
    hs(b2).length > 1 && t3(Q2);
  });
  var et2 = ve(U2, 2), at2 = (t3) => {
    var e3 = LP(), i3 = me(e3);
    hn(i3, 21, () => Object.entries(x2), ln, (t4, e4) => {
      var i4 = mt(() => _(hs(e4), 2));
      let s3 = () => hs(i4)[0], n3 = () => hs(i4)[1];
      var r3 = Ts(), o3 = ge(r3), a3 = (t5) => {
        var e5 = TP(), i5 = me(e5), r4 = me(i5, true);
        ie(i5);
        var o4 = ve(i5, 2), a4 = me(o4), l3 = ve(a4), h3 = (t6) => {
          var e6 = EP(), i6 = me(e6, true);
          ie(e6), Pe(() => Us(i6, n3().unit)), As(t6, e6);
        };
        on(l3, (t6) => {
          n3().unit && t6(h3);
        }), ie(o4);
        var c3 = ve(o4, 2), u3 = (t6) => {
          var e6 = PP(), i6 = me(e6);
          ie(e6), Pe(() => {
            Nn(i6, 1, `progress ${"sl" === s3() ? "progress-error" : "progress-success"} w-full`), Qn(i6, "sl" === s3() ? 1 - hs(v2)[s3()] : hs(v2)[s3()]);
          }), As(t6, e6);
        };
        on(c3, (t6) => {
          "sl" !== s3() && "tp" !== s3() && "ts" !== s3() || t6(u3);
        }), ie(e5), Pe((t6, e6) => {
          Us(r4, t6), Us(a4, `${e6 ?? ""} `);
        }, [() => WC["position_" + s3()](), () => n3().formatter(hs(v2)[s3()])]), As(t5, e5);
      };
      on(o3, (t5) => {
        "shown" in n3() && !n3().shown(hs(v2)[s3()]) || t5(a3);
      }), As(t4, r3);
    }), ie(i3), ie(e3), As(t3, e3);
  };
  on(et2, (t3) => {
    hs(v2) && t3(at2);
  });
  var ct2 = ve(et2, 2), dt2 = (t3) => {
    var e3 = tT(), i3 = ge(e3), s3 = (t4) => {
      var e4 = jP(), i4 = me(e4), s4 = (t5) => {
        var e5 = FP(), i5 = ge(e5), s5 = me(i5), n5 = me(s5);
        ie(s5);
        var r5 = ve(s5, 2);
        Jn(r5), ne(2), ie(i5);
        var o5 = ve(i5, 2);
        hn(o5, 21, () => hs(z2), ln, (t6, e6) => {
          var i6 = AP(), s6 = me(i6), n6 = me(s6), r6 = me(n6), o6 = (t7) => {
            var i7 = Ps();
            Pe(() => Us(i7, hs(e6).assetName[0])), As(t7, i7);
          };
          on(r6, (t7) => {
            hs(e6).assetName && t7(o6);
          }), ie(n6);
          var a5 = ve(n6, 2), l4 = me(a5), h4 = (t7) => {
            var i7 = VP(), s7 = ge(i7), n7 = me(s7, true);
            ie(s7), ne(2), Pe(() => Us(n7, hs(e6).assetName)), As(t7, i7);
          };
          on(l4, (t7) => {
            hs(e6).assetName && t7(h4);
          });
          var c3 = ve(l4, 2), u3 = me(c3, true);
          ie(c3), ie(a5);
          var d3 = ve(a5, 2), f3 = (t7) => {
            var i7 = OP(), s7 = me(i7), n7 = me(s7);
            ie(s7), ie(i7), Pe((t8, e7) => {
              Nn(s7, 1, `font-light lining-nums ml-4 ${t8 ?? ""}`, "svelte-1nx0ef2"), Us(n7, `${e7 ?? ""}%`);
            }, [() => $R(hs(e6).profit), () => Math.abs(100 * hs(e6).nextWeight).toFixed(1)]), As(t7, i7);
          };
          on(d3, (t7) => {
            hs(R2) && t7(f3);
          }), ie(s6), ie(i6), Pe((t7) => {
            In(n6, `background: ${t7 ?? ""}`), Us(u3, hs(e6).assetId);
          }, [() => tP(hs(e6).assetName[0])]), As(t6, i6);
        }), ie(o5), Pe(() => Us(n5, `${{ close: "收盤", open: "開盤" }[hs(v2).entryTradePrice] || "盤中"}買入`)), mr(r5, () => hs(R2), (t6) => zt(R2, t6)), As(t5, e5);
      };
      on(i4, (t5) => {
        0 !== hs(z2).length && t5(s4);
      });
      var n4 = ve(i4, 2), r4 = (t5) => {
        As(t5, NP());
      };
      on(n4, (t5) => {
        0 !== hs(z2).length && 0 !== hs(C2).length && t5(r4);
      });
      var o4 = ve(n4, 2), a4 = (t5) => {
        var e5 = BP(), i5 = ge(e5), s5 = me(i5);
        ie(i5);
        var n5 = ve(i5, 2);
        hn(n5, 21, () => hs(C2), ln, (t6, e6) => {
          var i6 = IP(), s6 = me(i6), n6 = me(s6), r5 = me(n6), o5 = (t7) => {
            var i7 = Ps();
            Pe(() => Us(i7, hs(e6).assetName[0])), As(t7, i7);
          };
          on(r5, (t7) => {
            hs(e6).assetName && t7(o5);
          }), ie(n6);
          var a5 = ve(n6, 2), l4 = me(a5), h4 = (t7) => {
            var i7 = WP(), s7 = ge(i7), n7 = me(s7, true);
            ie(s7), ne(2), Pe(() => Us(n7, hs(e6).assetName)), As(t7, i7);
          };
          on(l4, (t7) => {
            hs(e6).assetName && t7(h4);
          });
          var c3 = ve(l4, 2), u3 = me(c3, true);
          ie(c3), ie(a5), ie(s6), ie(i6), Pe((t7) => {
            In(n6, `background: ${t7 ?? ""}`), Us(u3, hs(e6).assetId);
          }, [() => tP(hs(e6).assetName[0])]), As(t6, i6);
        }), ie(n5), Pe(() => Us(s5, `${{ close: "收盤", open: "開盤" }[hs(v2).entryTradePrice] || "盤中"}賣出`)), As(t5, e5);
      };
      on(o4, (t5) => {
        0 != hs(C2).length && t5(a4);
      }), ie(e4), As(t4, e4);
    };
    on(i3, (t4) => {
      0 === hs(C2).length && 0 === hs(z2).length || t4(s3);
    });
    var n3 = ve(i3, 2), r3 = me(n3), o3 = (t4) => {
      As(t4, HP());
    };
    on(r3, (t4) => {
      0 === hs(C2).length && 0 === hs(z2).length || t4(o3);
    });
    var a3 = ve(r3, 2), l3 = (t4) => {
      ZE(t4, { get rows() {
        return hs(w2);
      }, get columns() {
        return hs(E2);
      }, $$events: { close: P2, click: V2 }, $$slots: { name: (t5, e4) => {
        var i4 = XP();
        const s4 = mt(() => e4.row);
        var n4 = me(i4), r4 = me(n4), o4 = me(r4, true);
        ie(r4);
        var a4 = ve(r4, 2), l4 = me(a4), h4 = (t6) => {
          var e5 = qP(), i5 = ge(e5), n5 = me(i5, true);
          ie(i5), ne(2), Pe(() => Us(n5, hs(s4).assetName ? hs(s4).assetName : "")), As(t6, e5);
        };
        on(l4, (t6) => {
          hs(s4).assetName && t6(h4);
        });
        var c3 = ve(l4, 2), u3 = me(c3, true);
        ie(c3), ie(a4), ie(n4), ie(i4), Pe((t6) => {
          In(r4, `background: ${t6 ?? ""}`), Us(o4, hs(s4).assetName ? hs(s4).assetName[0] : ""), Us(u3, hs(s4).assetId);
        }, [() => tP(hs(s4).assetName[0])]), As(t5, i4);
      }, profit: (t5, e4) => {
        var i4 = KP();
        const s4 = mt(() => e4.row);
        var n4 = me(i4), r4 = me(n4);
        ie(n4);
        var o4 = ve(n4, 3), a4 = me(o4, true);
        ie(o4), ie(i4), Pe((t6, e5, i5, s5) => {
          Nn(n4, 1, `lining-nums ${t6 ?? ""}`, "svelte-1nx0ef2"), Us(r4, `${e5 ?? ""}${i5 ?? ""}%`), Us(a4, s5);
        }, [() => $R(hs(s4).profit), () => hs(s4).profit > 0 ? "▴ " : "▾ ", () => (100 * hs(s4).profit).toFixed(2), () => hs(s4).currentPrice ? hs(s4).currentPrice.toFixed(2) : "-"]), As(t5, i4);
      }, entryDate: (t5, e4) => {
        var i4 = UP();
        const s4 = mt(() => e4.row);
        var n4 = me(i4), r4 = me(n4, true);
        ie(n4);
        var o4 = ve(n4, 3), a4 = (t6) => {
          var e5 = Ps();
          Pe((t7) => Us(e5, t7), [() => hs(s4).entryDate.toLocaleTimeString()]), As(t6, e5);
        };
        on(o4, (t6) => {
          hs(v2).isDailyStrategy || t6(a4);
        });
        var l4 = ve(o4, 2), h4 = me(l4, true);
        ie(l4), ne(), ie(i4), Pe((t6, e5) => {
          Us(r4, t6), Us(h4, e5);
        }, [() => hs(s4).entryDate.toLocaleDateString(), () => hs(s4).entryPrice == hs(s4).entryPrice ? hs(s4).entryPrice.toFixed(2) : "-"]), As(t5, i4);
      }, currentWeight: (t5, e4) => {
        var i4 = YP();
        const s4 = mt(() => e4.row);
        var n4 = me(i4), r4 = me(n4);
        ie(n4), ie(i4), Pe((t6, e5) => {
          Nn(n4, 1, t6, "svelte-1nx0ef2"), Us(r4, `${e5 ?? ""}%`);
        }, [() => En($R(hs(s4).currentWeight)), () => (100 * hs(s4).currentWeight).toFixed(1)]), As(t5, i4);
      }, nextWeight: (t5, e4) => {
        var i4 = GP();
        const s4 = mt(() => e4.row);
        var n4 = me(i4), r4 = me(n4);
        ie(n4), ie(i4), Pe((t6, e5) => {
          Nn(n4, 1, t6, "svelte-1nx0ef2"), Us(r4, `${e5 ?? ""}%`);
        }, [() => En($R(hs(s4).nextWeight)), () => (100 * hs(s4).nextWeight).toFixed(1)]), As(t5, i4);
      }, RSV: (t5, e4) => {
        var i4 = QP();
        const s4 = mt(() => e4.row);
        var n4 = me(i4), r4 = (t6) => {
          var e5 = JP(), i5 = ge(e5), n5 = ve(i5, 3);
          Pe((t7) => {
            Us(i5, `${t7 ?? ""}%`), Qn(n5, hs(s4).rsv20);
          }, [() => (100 * hs(s4).rsv20).toFixed(2)]), As(t6, e5);
        }, o4 = (t6) => {
          As(t6, Ps("-"));
        };
        on(n4, (t6) => {
          isFinite(hs(s4).rsv20) ? t6(r4) : t6(o4, false);
        }), ie(i4), As(t5, i4);
      } } });
    }, h3 = (t4) => {
      As(t4, ZP());
    };
    on(a3, (t4) => {
      hs(w2) && hs(w2).length > 0 ? t4(l3) : t4(h3, false);
    }), ie(n3), As(t3, e3);
  };
  on(ct2, (t3) => {
    hs(v2) && t3(dt2);
  }), ie(B2), _r(B2, (t3) => S2 = t3, () => S2), As(t2, B2);
  var gt2 = J({ get reportPosition() {
    return o2();
  }, set reportPosition(t3) {
    o2(t3), rs();
  }, get lang() {
    return a2();
  }, set lang(t3) {
    a2(t3), rs();
  } });
  return s2(), gt2;
}
Ar(sT, { reportPosition: {}, lang: {} }, [], [], true);
!function(t2) {
  function e2() {
    var t3 = document.querySelector("[data-toggle-theme]"), e3 = t3 ? t3.getAttribute("data-key") : null;
    !function(i3 = localStorage.getItem(e3 || "theme")) {
      localStorage.getItem(e3 || "theme") && (document.documentElement.setAttribute("data-theme", i3), t3 && [...document.querySelectorAll("[data-toggle-theme]")].forEach((e4) => {
        e4.classList.add(t3.getAttribute("data-act-class"));
      }));
    }(), t3 && [...document.querySelectorAll("[data-toggle-theme]")].forEach((t4) => {
      t4.addEventListener("click", function() {
        var i3 = t4.getAttribute("data-toggle-theme");
        if (i3) {
          var s3 = i3.split(",");
          document.documentElement.getAttribute("data-theme") == s3[0] ? 1 == s3.length ? (document.documentElement.removeAttribute("data-theme"), localStorage.removeItem(e3 || "theme")) : (document.documentElement.setAttribute("data-theme", s3[1]), localStorage.setItem(e3 || "theme", s3[1])) : (document.documentElement.setAttribute("data-theme", s3[0]), localStorage.setItem(e3 || "theme", s3[0]));
        }
        [...document.querySelectorAll("[data-toggle-theme]")].forEach((t5) => {
          t5.classList.toggle(this.getAttribute("data-act-class"));
        });
      });
    });
  }
  function i2() {
    var t3 = document.querySelector("[data-set-theme='']"), e3 = t3 ? t3.getAttribute("data-key") : null;
    !function(t4 = localStorage.getItem(e3 || "theme")) {
      var i3;
      null != t4 && "" != t4 && (localStorage.getItem(e3 || "theme") && "" != localStorage.getItem(e3 || "theme") ? (document.documentElement.setAttribute("data-theme", t4), (i3 = document.querySelector("[data-set-theme='" + t4.toString() + "']")) && ([...document.querySelectorAll("[data-set-theme]")].forEach((t5) => {
        t5.classList.remove(t5.getAttribute("data-act-class"));
      }), i3.getAttribute("data-act-class") && i3.classList.add(i3.getAttribute("data-act-class")))) : (i3 = document.querySelector("[data-set-theme='']")).getAttribute("data-act-class") && i3.classList.add(i3.getAttribute("data-act-class")));
    }(), [...document.querySelectorAll("[data-set-theme]")].forEach((t4) => {
      t4.addEventListener("click", function() {
        document.documentElement.setAttribute("data-theme", this.getAttribute("data-set-theme")), localStorage.setItem(e3 || "theme", document.documentElement.getAttribute("data-theme")), [...document.querySelectorAll("[data-set-theme]")].forEach((t5) => {
          t5.classList.remove(t5.getAttribute("data-act-class"));
        }), t4.getAttribute("data-act-class") && t4.classList.add(t4.getAttribute("data-act-class"));
      });
    });
  }
  function s2() {
    var t3 = document.querySelector("select[data-choose-theme]"), e3 = t3 ? t3.getAttribute("data-key") : null;
    !function(t4 = localStorage.getItem(e3 || "theme")) {
      localStorage.getItem(e3 || "theme") && (document.documentElement.setAttribute("data-theme", t4), document.querySelector("select[data-choose-theme] [value='" + t4.toString() + "']") && [...document.querySelectorAll("select[data-choose-theme] [value='" + t4.toString() + "']")].forEach((t5) => {
        t5.selected = true;
      }));
    }(), t3 && [...document.querySelectorAll("select[data-choose-theme]")].forEach((t4) => {
      t4.addEventListener("change", function() {
        document.documentElement.setAttribute("data-theme", this.value), localStorage.setItem(e3 || "theme", document.documentElement.getAttribute("data-theme")), [...document.querySelectorAll("select[data-choose-theme] [value='" + localStorage.getItem(e3 || "theme") + "']")].forEach((t5) => {
          t5.selected = true;
        });
      });
    });
  }
  t2.exports = { themeChange: function(t3 = true) {
    true === t3 ? document.addEventListener("DOMContentLoaded", function(t4) {
      e2(), s2(), i2();
    }) : (e2(), s2(), i2());
  } };
}({ exports: {} }), new TextEncoder();
var nT = Rs('<div class="w-8 flex justify-center"><div class="w-6 h-9"><!></div></div> <div><span class="text-base-content-300 font-bold -mt-2">FinLab</span></div>', 1), rT = Rs('<a role="tab" tabindex="1"> </a>'), oT = Rs('<div class="sticky top-0 z-[21] backdrop-blur-lg text-left"><div class="flex gap-4 h-20 items-center"><div style="margin-left: -4px" class="flex items-end flex-1 -mt-2 text-base-content"><!></div> <div class="flex-1 w-full rounded-lg"><div role="tablist" class="tabs tabs-lg tabs-border w-full border border-primary rounded-xl overflow-hidden"></div></div> <div class="flex-1 text-right text-base-content-200 flex items-center justify-end"><label class="swap swap-rotate"><input type="checkbox"/> <svg class="swap-on h-6 w-6 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5.64,17l-.71.71a1,1,0,0,0,0,1.41,1,1,0,0,0,1.41,0l.71-.71A1,1,0,0,0,5.64,17ZM5,12a1,1,0,0,0-1-1H3a1,1,0,0,0,0,2H4A1,1,0,0,0,5,12Zm7-7a1,1,0,0,0,1-1V3a1,1,0,0,0-2,0V4A1,1,0,0,0,12,5ZM5.64,7.05a1,1,0,0,0,.7.29,1,1,0,0,0,.71-.29,1,1,0,0,0,0-1.41l-.71-.71A1,1,0,0,0,4.93,6.34Zm12,.29a1,1,0,0,0,.7-.29l.71-.71a1,1,0,1,0-1.41-1.41L17,5.64a1,1,0,0,0,0,1.41A1,1,0,0,0,17.66,7.34ZM21,11H20a1,1,0,0,0,0,2h1a1,1,0,0,0,0-2Zm-9,8a1,1,0,0,0-1,1v1a1,1,0,0,0,2,0V20A1,1,0,0,0,12,19ZM18.36,17A1,1,0,0,0,17,18.36l.71.71a1,1,0,0,0,1.41,0,1,1,0,0,0,0-1.41ZM12,6.5A5.5,5.5,0,1,0,17.5,12,5.51,5.51,0,0,0,12,6.5Zm0,9A3.5,3.5,0,1,1,15.5,12,3.5,3.5,0,0,1,12,15.5Z"></path></svg> <svg class="swap-off h-6 w-6 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21.64,13a1,1,0,0,0-1.05-.14,8.05,8.05,0,0,1-3.37.73A8.15,8.15,0,0,1,9.08,5.49a8.59,8.59,0,0,1,.25-2A1,1,0,0,0,8,2.36,10.14,10.14,0,1,0,22,14.05,1,1,0,0,0,21.64,13Zm-9.5,6.69A8.14,8.14,0,0,1,7.08,5.22v.27A10.15,10.15,0,0,0,17.22,15.63a9.79,9.79,0,0,0,2.1-.22A8.11,8.11,0,0,1,12.14,19.73Z"></path></svg></label></div></div></div>'), aT = Rs('<div class="mask mask-star-2 bg-primary"></div>'), lT = Rs('<div class="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-0 h-0\n										border-l-[12px] border-l-transparent\n										border-t-[12px] border-t-primary\n										border-r-[12px] border-r-transparent\n										hidden @md:block"></div>'), hT = Rs('<button><div class="flex flex-col items-center"><div class="mb-1"><!></div> <div class="mb-1.5 break-keep"><span class="font-light"> </span></div> <div><div class="rating rating-xs"></div></div></div> <!></button>'), cT = Rs('<div class="w-8 h-8 text-accent"><!></div>'), uT = Rs('<div class="w-8 h-8 text-secondary"><!></div>'), dT = Rs('<div><div class="mb-3 @md:md:break-all"><!></div> <div class="text-sm font-light"> </div> <div class="text-3xl font-extralight whitespace-nowrap"><span> </span> <span class="text-sm"> </span></div> <div class="stat-desc"></div></div>'), fT = Rs('<div class="card bg-base-100 text-base-content-300"><div class="card-body"><h3 class="font-bold text-lg"> </h3> <p> </p> <h3 class="font-bold text-lg mt-4"> </h3> <p> </p></div></div>'), pT = Rs('<div class="@container"><div class="my-3 grid grid-cols-2 @md:mx-12 @md:grid-cols-5 justify-center gap-2 @md:gap-1"></div> <div class="overflow-x-auto border-t border-primary/50 rounded-4xl"><div class="min-w-xl grid grid-cols-5 w-full rounded-lg pt-3 shadow shadow-2xl shadow-primary/5"></div> <!></div> <div class="pb-6 mt-24"><!></div></div>'), mT = Rs('<div class="pb-4 mt-12"><!></div>'), gT = Rs("<div><!> <div></div> <!></div>");
function vT(t2, e2) {
  G(e2, true);
  let i2 = Lr(e2, "report", 7), s2 = Lr(e2, "lang", 7), n2 = Lr(e2, "theme", 7), r2 = Lr(e2, "browser", 7), o2 = Lr(e2, "reportPosition", 7), a2 = Lr(e2, "webcomponent", 7);
  const l2 = new MetricDisplay();
  let h2, c2, u2 = kt(tt("position" === localStorage.getItem("strategyAnalyticTab") ? "profitability" : localStorage.getItem("strategyAnalyticTab") || "profitability")), d2 = mt(() => i2() ? Ir(i2().metrics) : {}), f2 = ["分析", "選股"], p2 = kt("分析");
  async function m2() {
    await ls(), await new Promise((t4) => setTimeout(t4, 500));
    let t3 = h2.scrollHeight;
    window.parent.postMessage({ frameHeight: t3, tab: hs(p2) + " " + hs(u2) }, "*");
  }
  en(async () => {
    a2() && await m2();
  });
  let g2 = kt(null);
  const v2 = { profitability: XR, risk: VR, ratio: YR, winrate: jR, liquidity: IR, all: BR };
  var b2 = gT(), y2 = me(b2), x2 = (t3) => {
    var e3 = oT(), i3 = me(e3), s3 = me(i3), r3 = me(s3), o3 = (t4) => {
      var e4 = nT(), i4 = ge(e4), s4 = me(i4);
      vn(me(s4), () => '<svg\n	xmlns="http://www.w3.org/2000/svg"\n	version="1.0"\n	viewBox="0 0 248.000000 348.000000"\n	preserveAspectRatio="xMidYMid meet"\n>\n	<g\n		transform="translate(0.000000,348.000000) scale(0.100000,-0.100000)"\n		stroke="none"\n		fill="currentColor"\n	>\n		<path\n			d="M1453 3192 c-74 -27 -119 -60 -157 -117 -62 -94 -71 -189 -26 -293 55 -128 216 -208 347 -172 184 51 286 262 203 423 -72 139 -230 208 -367 159z"\n		/>\n		<path\n			d="M1045 2575 c-47 -25 -64 -45 -76 -86 -17 -54 -4 -104 36 -144 87 -86 229 -35 242 88 5 49 -18 100 -58 130 -37 26 -106 32 -144 12z"\n		/>\n		<path\n			d="M1146 2123 l-29 -5 7 -146 c3 -81 11 -184 16 -230 l9 -82 -367 -553 c-420 -630 -467 -705 -457 -715 3 -4 454 -8 1001 -10 823 -2 994 0 994 11 0 22 -113 210 -454 757 l-327 525 5 75 c4 41 9 141 13 221 l6 146 -39 6 c-42 7 -330 7 -378 0z m327 -723 c268 -427 477 -771 477 -786 0 -16 -543 -27 -933 -18 l-316 7 16 31 c26 49 472 727 510 774 l35 43 91 -3 92 -3 28 -45z"\n		/>\n		<path\n			d="M1163 1058 c-54 -59 -213 -303 -213 -326 0 -9 91 -12 353 -12 347 0 397 3 397 22 0 24 -170 258 -188 258 -8 0 -37 -20 -64 -45 -28 -25 -56 -45 -64 -45 -8 0 -54 38 -103 85 -50 47 -92 85 -94 85 -2 0 -13 -10 -24 -22z"\n		/>\n	</g>\n</svg>'), ie(s4), ie(i4), ne(2), As(t4, e4);
    };
    on(r3, (t4) => {
      t4(o3);
    }), ie(s3);
    var a3 = ve(s3, 2), l3 = me(a3);
    hn(l3, 21, () => f2, ln, (t4, e4) => {
      var i4 = rT();
      let s4;
      var n3 = me(i4, true);
      ie(i4), Pe((t5) => {
        s4 = Nn(i4, 1, "rounded-none w-1/2 rounded-none flex items-center h-12 justify-center text-base-content cursor-pointer select-none", null, s4, t5), Us(n3, hs(e4));
      }, [() => ({ "bg-primary": hs(p2) === hs(e4), "opacity-70": hs(p2) === hs(e4), "text-primary-content": hs(p2) === hs(e4) })]), Ms("click", i4, () => {
        zt(p2, hs(e4), true), void 0 !== window && window.scrollY > c2.offsetTop && window.scrollTo(0, c2.offsetTop), m2();
      }), As(t4, i4);
    }), ie(l3), ie(a3);
    var h3 = ve(a3, 2), u3 = me(h3), d3 = me(u3);
    ne(4), ie(u3), ie(h3), ie(i3), ie(e3), Ms("click", d3, () => {
      const t4 = "dark" === document.documentElement.getAttribute("data-theme") ? "light" : "dark";
      localStorage.setItem("theme", t4), n2(t4), document.documentElement.setAttribute("data-theme", t4);
    }), As(t3, e3);
  };
  on(y2, (t3) => {
    a2() && t3(x2);
  });
  var w2 = ve(y2, 2);
  _r(w2, (t3) => c2 = t3, () => c2);
  var k2 = ve(w2, 2), M2 = (t3) => {
    var e3 = Ts(), o3 = ge(e3), a3 = (t4) => {
      var e4 = pT(), o4 = me(e4);
      hn(o4, 21, () => Object.entries(i2().metrics).filter((t5) => "backtest" !== t5[0]), ln, (t5, e5) => {
        var i3 = mt(() => _(hs(e5), 2));
        let s3 = () => hs(i3)[0];
        var n3 = hT(), r3 = me(n3), o5 = me(r3), a5 = me(o5), l3 = (t6) => {
          var e6 = Ts();
          _n(ge(e6), () => v2[s3()], (t7, e7) => {
            e7(t7, { size: 18 });
          }), As(t6, e6);
        };
        on(a5, (t6) => {
          v2[s3()] && t6(l3);
        }), ie(o5);
        var h4 = ve(o5, 2), c4 = me(h4), f4 = me(c4, true);
        ie(c4), ie(h4);
        var p4 = ve(h4, 2), b4 = me(p4);
        hn(b4, 20, () => Array.from({ length: 5 }), ln, (t6, e6, i4) => {
          var n4 = aT();
          er(n4, "aria-label", `${i4 + 1} star`), Pe(() => er(n4, "aria-current", 0.2 * i4 < hs(d2)[s3()] && 0.2 * i4 + 0.2 >= hs(d2)[s3()] ? "true" : void 0)), As(t6, n4);
        }), ie(b4), ie(p4), ie(r3);
        var y4 = ve(r3, 2), x4 = (t6) => {
          As(t6, lT());
        };
        on(y4, (t6) => {
          hs(u2) === s3() && t6(x4);
        }), ie(n3), Pe((t6) => {
          Nn(n3, 1, `cursor-pointer border border-base-content/5 @md:border-none py-1.5 md:py-1.5 @lg:py-3 @2xl:py-3 px-1.5 @lg:px-3 @2xl:px-8 rounded-lg transition-all duration-300 ${hs(u2) === s3() ? "bg-primary/30 outline outline-primary" : "hover:bg-base-100"} relative`), Us(f4, t6);
        }, [() => WC[`tabs_${s3()}`]()]), Ms("click", n3, () => {
          zt(g2, null), zt(u2, s3(), true), localStorage.setItem("strategyAnalyticTab", s3()), m2();
        }), As(t5, n3);
      }), ie(o4);
      var a4 = ve(o4, 2), h3 = me(a4);
      hn(h3, 21, () => Object.entries(i2().metrics[hs(u2)]).splice(0, 7), ln, (t5, e5, i3) => {
        var s3 = mt(() => _(hs(e5), 2));
        let n3 = () => hs(s3)[0], r3 = () => hs(s3)[1];
        var o5 = Ts(), a5 = ge(o5), h4 = (t6) => {
          var e6 = dT();
          let s4;
          var o6 = me(e6), a6 = me(o6), h5 = (t7) => {
            var e7 = cT();
            vn(me(e7), () => '<svg\n\n										viewBox="0 0 24 24"\n										fill="none"\n										stroke="currentColor"\n										xmlns="http://www.w3.org/2000/svg"\n										><g id="SVGRepo_bgCarrier" stroke-width="0" /><g\n											id="SVGRepo_tracerCarrier"\n											stroke-linecap="round"\n											stroke-linejoin="round"\n											\n											stroke-width="1"\n										/><g id="SVGRepo_iconCarrier">\n											<circle cx="12" cy="12" r="10"  stroke-width="1" />\n											<path\n												d="M8.5 12.5L10.5 14.5L15.5 9.5"\n												\n												stroke-width="1"\n												stroke-linecap="round"\n												stroke-linejoin="round"\n											/>\n										</g>\n									</svg>'), ie(e7), As(t7, e7);
          }, c4 = (t7) => {
            var e7 = uT();
            vn(me(e7), () => '<svg\n								\n										viewBox="0 0 24 24"\n										fill="none"\n										stroke="currentColor"\n										xmlns="http://www.w3.org/2000/svg"\n										\n										><g id="SVGRepo_bgCarrier" stroke-width="0" /><g\n											id="SVGRepo_tracerCarrier"\n											stroke-linecap="round"\n											stroke-linejoin="round"\n										/><g id="SVGRepo_iconCarrier">\n											<circle cx="12" cy="12" r="10" stroke-width="1" />\n											<path\n												d="M14.5 9.50002L9.5 14.5M9.49998 9.5L14.5 14.5"\n												\n												stroke-width="1"\n												stroke-linecap="round"\n											/>\n										</g>\n									</svg>'), ie(e7), As(t7, e7);
          };
          on(a6, (t7) => {
            Wr[hs(u2)][n3()](r3()) ? t7(h5) : t7(c4, false);
          }), ie(o6);
          var d3 = ve(o6, 2), f4 = me(d3, true);
          ie(d3);
          var p4 = ve(d3, 2), v3 = me(p4), b4 = me(v3, true);
          ie(v3);
          var _2 = ve(v3, 2), y4 = me(_2, true);
          ie(_2), ie(p4), ne(2), ie(e6), Pe((t7, i4, n4, r4, o7) => {
            s4 = Nn(e6, 1, "flex flex-col items-center border-base-content/5 cursor-pointer transition-all duration-200 p-2 rounded-md hover:bg-base-200", null, s4, t7), er(e6, "title", i4), Us(f4, n4), Us(b4, r4), Us(y4, o7);
          }, [() => ({ "border-r": 4 != i3, "bg-base-200": hs(g2) === n3() }), () => WC[`metrics_${hs(u2)}_${n3()}`](), () => WC[`metrics_${hs(u2)}_${n3()}`](), () => l2.format(n3(), r3()), () => l2.getUnit(n3())]), Ms("click", e6, () => {
            var t7;
            t7 = n3(), hs(g2) === t7 ? zt(g2, null) : zt(g2, t7, true), m2();
          }), As(t6, e6);
        };
        on(a5, (t6) => {
          var _a3;
          ((_a3 = Wr[hs(u2)]) == null ? void 0 : _a3[n3()]) && t6(h4);
        }), As(t5, o5);
      }), ie(h3);
      var c3 = ve(h3, 2), f3 = (t5) => {
        var e5 = fT(), i3 = me(e5), s3 = me(i3), n3 = me(s3, true);
        ie(s3);
        var r3 = ve(s3, 2), o5 = me(r3, true);
        ie(r3);
        var a5 = ve(r3, 2), l3 = me(a5, true);
        ie(a5);
        var h4 = ve(a5, 2), c4 = me(h4, true);
        ie(h4), ie(i3), ie(e5), Pe((t6, e6, i4, s4) => {
          Us(n3, t6), Us(o5, e6), Us(l3, i4), Us(c4, s4);
        }, [() => WC[`metrics_${hs(u2)}_${hs(g2)}`](), () => WC[`metric_description_${hs(u2)}_${hs(g2)}`](), () => DS(), () => Wr[hs(u2)][hs(g2)].toString().split("=>")[1]]), As(t5, e5);
      };
      on(c3, (t5) => {
        null !== hs(g2) && t5(f3);
      }), ie(a4);
      var p3 = ve(a4, 2), b3 = me(p3), y3 = (t5) => {
        EE(t5, { get report() {
          return i2();
        }, get browser() {
          return r2();
        }, get theme() {
          return n2();
        }, get lang() {
          return s2();
        } });
      }, x3 = (t5, e5) => {
        var o5 = (t6) => {
          NE(t6, { get report() {
            return i2();
          }, get browser() {
            return r2();
          }, get theme() {
            return n2();
          }, get lang() {
            return s2();
          } });
        }, a5 = (t6, e6) => {
          var o6 = (t7) => {
            LE(t7, { get report() {
              return i2();
            }, get browser() {
              return r2();
            }, get theme() {
              return n2();
            }, get lang() {
              return s2();
            } });
          }, a6 = (t7, e7) => {
            var o7 = (t8) => {
              IE(t8, { get report() {
                return i2();
              }, get browser() {
                return r2();
              }, get theme() {
                return n2();
              }, get lang() {
                return s2();
              } });
            }, a7 = (t8, e8) => {
              var o8 = (t9) => {
                jC(t9, { get report() {
                  return i2();
                }, get browser() {
                  return r2();
                }, get theme() {
                  return n2();
                }, get lang() {
                  return s2();
                } });
              };
              on(t8, (t9) => {
                "liquidity" === hs(u2) && t9(o8);
              }, e8);
            };
            on(t7, (t8) => {
              "winrate" === hs(u2) ? t8(o7) : t8(a7, false);
            }, e7);
          };
          on(t6, (t7) => {
            "ratio" === hs(u2) ? t7(o6) : t7(a6, false);
          }, e6);
        };
        on(t5, (t6) => {
          "risk" === hs(u2) ? t6(o5) : t6(a5, false);
        }, e5);
      };
      on(b3, (t5) => {
        "profitability" === hs(u2) ? t5(y3) : t5(x3, false);
      }), ie(p3), ie(e4), As(t4, e4);
    };
    on(o3, (t4) => {
      i2() && t4(a3);
    }), As(t3, e3);
  }, S2 = (t3) => {
    var e3 = mT();
    sT(me(e3), { get reportPosition() {
      return o2();
    }, get lang() {
      return s2();
    } }), ie(e3), As(t3, e3);
  };
  return on(k2, (t3) => {
    "分析" === hs(p2) ? t3(M2) : t3(S2, false);
  }), ie(b2), _r(b2, (t3) => h2 = t3, () => h2), As(t2, b2), J({ get report() {
    return i2();
  }, set report(t3) {
    i2(t3), rs();
  }, get lang() {
    return s2();
  }, set lang(t3) {
    s2(t3), rs();
  }, get theme() {
    return n2();
  }, set theme(t3) {
    n2(t3), rs();
  }, get browser() {
    return r2();
  }, set browser(t3) {
    r2(t3), rs();
  }, get reportPosition() {
    return o2();
  }, set reportPosition(t3) {
    o2(t3), rs();
  }, get webcomponent() {
    return a2();
  }, set webcomponent(t3) {
    a2(t3), rs();
  } });
}
customElements.define("strategy-analytic", Ar(vT, { report: { reflect: true, type: "Object" }, lang: { reflect: true, type: "String" }, theme: { reflect: true, type: "String" }, browser: { reflect: true, type: "Boolean" }, webcomponent: { reflect: true, type: "Boolean" }, reportPosition: { reflect: true, type: "Object" } }, [], [], false));
var bT = Es('<svg aria-hidden="true"><use></use></svg>');
function _T(t2, e2) {
  G(e2, false);
  const i2 = Mt();
  let s2 = Lr(e2, "prefix", 12, "icon"), n2 = Lr(e2, "name", 12, ""), r2 = Lr(e2, "color", 12, "#333"), o2 = Lr(e2, "strokeColor", 12, ""), a2 = Lr(e2, "className", 12, "");
  $e(() => (fs(s2()), fs(n2())), () => {
    zt(i2, `#${s2()}-${n2()}`);
  }), De();
  var l2 = bT(), h2 = me(l2);
  return ie(l2), Pe(() => {
    Nn(l2, 0, En(a2())), er(h2, "href", hs(i2)), er(h2, "fill", r2()), er(h2, "stroke", o2());
  }), As(t2, l2), J({ get prefix() {
    return s2();
  }, set prefix(t3) {
    s2(t3), rs();
  }, get name() {
    return n2();
  }, set name(t3) {
    n2(t3), rs();
  }, get color() {
    return r2();
  }, set color(t3) {
    r2(t3), rs();
  }, get strokeColor() {
    return o2();
  }, set strokeColor(t3) {
    o2(t3), rs();
  }, get className() {
    return a2();
  }, set className(t3) {
    a2(t3), rs();
  } });
}
Ar(_T, { prefix: {}, name: {}, color: {}, strokeColor: {}, className: {} }, [], [], true);
export {
  Fr as IMetricsKeysOrder,
  jC as L,
  MetricDisplay,
  EE as P,
  LE as R,
  Report,
  yE as S,
  IE as W,
  NE as a,
  vT as b,
  _T as c,
  Ir as calculateScores,
  Nr as orderMetricsByKeys,
  Wr as qualityMetrics
};
