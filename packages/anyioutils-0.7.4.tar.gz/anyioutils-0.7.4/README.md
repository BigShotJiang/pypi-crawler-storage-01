[![Build Status](https://github.com/davidbrochart/anyioutils/actions/workflows/test.yml/badge.svg?query=branch%3Amain++)](https://github.com/davidbrochart/anyioutils/actions/workflows/test.yml/badge.svg?query=branch%3Amain++)
[![Code Coverage](https://img.shields.io/badge/coverage-100%25-green)](https://img.shields.io/badge/coverage-100%25-green)

# anyioutils

Utility classes and functions for AnyIO.

See the [documentation](https://davidbrochart.github.io/anyioutils).
