# 0. Table of Contents

1. [Getting Started](1_getting_started.md)
2. [Defining Tables](2_defining_tables.md)
3. [Building Queries](3_building_queries.md)
4. [Relationships](4_relationships.md)
5. [py4web & web2py](./5_py4web.md)
6. [Migrations](./6_migrations.md)
7. [Mixins](./7_mixins.md)
