#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
    @Date   : 2025/3/7 20:39
    @Author : chairc
    @Site   : https://github.com/chairc
"""
from iddm.tools.generate import Generator
