class BsbTestError(Exception):
    pass


class FixtureError(BsbTestError):
    pass
