# THIS FILE WAS GENERATED AUTOMATICALLY
# BY: poem-plugins "git" plugin
# NEVER EDIT THIS FILE MANUALLY

version_info = (17, 9, 4)
__version__ = "17.9.4"
