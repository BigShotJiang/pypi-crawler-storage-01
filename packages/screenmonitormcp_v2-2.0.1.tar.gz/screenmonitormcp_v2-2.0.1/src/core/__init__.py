"""Core components for ScreenMonitorMCP v2."""
