"""View-related Widgets."""

from ._image_widget import ImagePreview

__all__ = ["ImagePreview"]
