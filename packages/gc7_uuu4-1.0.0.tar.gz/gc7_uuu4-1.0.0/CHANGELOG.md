# CHANGELOG

<!-- version list -->

## v1.0.2 (2025-08-03)

### Bug Fixes

- Reset dynamic version
  ([`d07896f`](https://github.com/PyMoX-fr/GC7/commit/d07896f1052d5b4f14d2e4924ba57e2f2ca22d97))


## v1.0.1 (2025-08-03)

### Bug Fixes

- For 4
  ([`31bcf6b`](https://github.com/PyMoX-fr/GC7/commit/31bcf6b49b8cf0d332282af209ba40847f4d0d49))


## v1.0.0 (2025-08-03)

### Bug Fixes

- Reset v0.0.2
  ([`93b91ea`](https://github.com/PyMoX-fr/GC7/commit/93b91ea5d002c5408d81a20f2a2192585e386422))

- Set v.0.2
  ([`32e8cf0`](https://github.com/PyMoX-fr/GC7/commit/32e8cf0c38b70126e5835e072e7b087713ad6799))


## v0.0.0 (2025-08-03)

- Initial Release
