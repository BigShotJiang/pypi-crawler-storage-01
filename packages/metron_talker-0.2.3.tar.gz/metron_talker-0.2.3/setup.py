# Setup file for comictagger Metron talker python source
from __future__ import annotations

from setuptools import setup

setup()
