"""
🐛 Genie Debug Agent - The Ruthless Debugging Meeseeks

Enhanced Agno agent for systematic bug extermination with persistent memory.
"""

from .agent import get_genie_debug

__all__ = ["get_genie_debug"]