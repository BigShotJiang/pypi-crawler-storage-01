"""Assonant Collimator component data class."""

from .component import Component


class Collimator(Component):
    """Data class to handle all data required to define a collimator."""
