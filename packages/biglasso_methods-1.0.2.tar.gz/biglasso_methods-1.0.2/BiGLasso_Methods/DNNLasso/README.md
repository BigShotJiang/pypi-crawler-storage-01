# DNNLasso

DNNLasso --  A MATALB software package for learning diagonally non-negative graphical lasso with Kronecker-sum precison matrix

Authors: Meixia Lin and Yangjing Zhang

Main solver: DNNLasso.m

For demonstration purposes, you may run 

test_synthetic.m

test_coil100.m

Citation:
Meixia Lin, and Yangjing Zhang. DNNLasso: Scalable graph learning for matrix-variate data.
27th International Conference on Artificial Intelligence and Statistics (AISTATS), 2024
