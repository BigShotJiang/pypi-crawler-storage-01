function [ y ] = add_one( x )
% Adds one to the input x
% This is a troubleshooting function; if it does not
% work as expected, the problem is likely with the package installation.

y = x + 1

end