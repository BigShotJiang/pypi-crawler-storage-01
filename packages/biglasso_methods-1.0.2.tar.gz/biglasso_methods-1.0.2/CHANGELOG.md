# Changelog

## Version 1.0.2
- Quick fix to prevent using a feature from a future version of Python

## Version 1.0.1
- Can provide one regularization argument per axis to TeraLasso (rather than one for all of them, as before)

## Version 1.0.0

- Initial version
- Includes DNNLasso and TeraLasso
- GmGM, a natively Python BiGLasso method (and a dependency), is also included as accessible in the namespace, in case one wants a consistent API between the methods.