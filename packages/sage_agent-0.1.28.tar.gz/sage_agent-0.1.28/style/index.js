import './fonts.css';
import './base.css';
import './modal.css';
// Import styles
import './inline-diff-approval.css';
import './diff-edit-mode.css';
import './codebase-manager.css';
import './chat-mention-dropdown.css';
import './left-side-banner.css';
import './mode-selector-dropdown.css';
import './new-chat-display.css';
import './llm-state-display.css';
import './plan-state-display.css';
import './more-options.css';
import './settings-widget.css';
import './update-banner.css';
import './code-mirror-merge.css';
