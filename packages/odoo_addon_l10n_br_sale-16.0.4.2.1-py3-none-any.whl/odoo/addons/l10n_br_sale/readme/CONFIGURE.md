Este módulo depende do módulo l10n_br_fiscal e l10n_br_account e para
funcionar corretamente deve ser previamente configurado parâmetros
fiscais e contábeis.
