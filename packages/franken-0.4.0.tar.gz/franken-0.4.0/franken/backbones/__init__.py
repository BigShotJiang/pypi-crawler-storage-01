from franken.backbones.utils import load_model_registry


REGISTRY = load_model_registry()
