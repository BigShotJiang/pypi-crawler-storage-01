from pathlib import Path

__version__ = "0.4.0"

# Get the absolute path of the directory where this file is located
FRANKEN_DIR = Path(__file__).resolve().parent
