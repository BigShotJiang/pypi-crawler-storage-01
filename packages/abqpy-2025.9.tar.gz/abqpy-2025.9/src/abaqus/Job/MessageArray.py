from __future__ import annotations

from typing import List

from .Message import Message

MessageArray = List[Message]
