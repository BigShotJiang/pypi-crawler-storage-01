from __future__ import annotations

from typing import List

from .PartInstance import PartInstance

PartInstanceArray = List[PartInstance]
