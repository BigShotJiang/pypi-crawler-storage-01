from __future__ import annotations

from ..Odb.OdbBase import OdbBase


class FieldOdb(OdbBase): ...
