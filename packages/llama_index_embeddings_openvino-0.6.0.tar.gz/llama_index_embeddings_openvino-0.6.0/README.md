# LlamaIndex Embeddings Integration: Huggingface OpenVINO
