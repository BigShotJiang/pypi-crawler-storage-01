# LlamaIndex Embeddings Integration: Text Embeddings Inference
