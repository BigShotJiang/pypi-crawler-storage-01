from llama_index.embeddings.text_embeddings_inference.base import (
    TextEmbeddingsInference,
)

__all__ = ["TextEmbeddingsInference"]
