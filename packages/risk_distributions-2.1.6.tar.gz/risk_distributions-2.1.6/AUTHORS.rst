Authors
=======

- James Collins <collijk@uw.edu>
- Michelle Park <hpark3@uw.edu>
- Kate Wilson <kwilson7@uw.edu>
- Cody Horst <chorst@uw.edu>

Current Maintainers
-------------------

- James Collins <collijk@uw.edu>
- Kjell Swedin <kjells@uw.edu>
- Rajan Mudambi <rmudambi@uw.edu>
- Matt Kappel <mkappel@uw.edu>
