This is a package I developed for handling an ML pipline for training and inference. 

This work builds upon the file_golem package which I developed, and it is a necessary dependency.

The goal is to simplify working with different ML models, where all custom parameters are stored on a single config file. 

For dev: python setup.py sdist bdist_wheel && pip install .