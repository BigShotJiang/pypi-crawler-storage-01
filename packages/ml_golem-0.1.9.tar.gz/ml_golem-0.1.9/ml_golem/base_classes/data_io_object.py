class DataIOObject:
    def __init__(self,args):
        self.data_io = args.data_io