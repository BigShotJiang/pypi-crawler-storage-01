from enum import Enum
class MainLoopMessages(Enum):
    BEGINNING_PROGRAM = 'Beginning program'
    COMPLETE_PROGRAM = 'Program complete'
