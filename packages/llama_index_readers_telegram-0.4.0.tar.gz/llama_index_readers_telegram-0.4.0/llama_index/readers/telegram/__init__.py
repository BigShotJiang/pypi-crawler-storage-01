from llama_index.readers.telegram.base import TelegramReader

__all__ = ["TelegramReader"]
