default_app_config = 'provider.oauth2.apps.Oauth2'
