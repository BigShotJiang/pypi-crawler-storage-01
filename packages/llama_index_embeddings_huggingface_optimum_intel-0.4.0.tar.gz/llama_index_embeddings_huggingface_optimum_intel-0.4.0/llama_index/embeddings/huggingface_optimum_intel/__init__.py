from llama_index.embeddings.huggingface_optimum_intel.base import IntelEmbedding

__all__ = ["IntelEmbedding"]
