# LlamaIndex Embeddings Integration: Huggingface Optimum Intel
