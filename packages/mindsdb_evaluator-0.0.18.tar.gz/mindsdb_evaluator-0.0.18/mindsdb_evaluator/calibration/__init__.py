from mindsdb_evaluator.calibration.ece import ece

__all__ = ['ece']
