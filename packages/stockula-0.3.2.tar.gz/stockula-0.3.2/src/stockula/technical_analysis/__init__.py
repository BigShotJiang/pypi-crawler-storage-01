"""Technical analysis module using finta library."""

from .indicators import TechnicalIndicators

__all__ = ["TechnicalIndicators"]
