"""Integration tests for Stockula - tests that require external systems or APIs."""
