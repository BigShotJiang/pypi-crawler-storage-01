# resources for browser injection/scraping
