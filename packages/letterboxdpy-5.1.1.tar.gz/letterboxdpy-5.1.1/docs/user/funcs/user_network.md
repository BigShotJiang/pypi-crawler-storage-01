<h2 id="user_network">user_network(user: letterboxdpy.user.User, section: str) -> dict</h2>

**Documentation:**

Fetches followers or following based on the section and returns them as a dictionary
- The section to scrape, must be either 'followers' or 'following'.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+user_network)
