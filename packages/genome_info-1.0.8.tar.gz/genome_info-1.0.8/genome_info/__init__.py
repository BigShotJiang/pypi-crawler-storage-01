"""Init for CBS."""

from __future__ import absolute_import
from .import kmers
from .core.info import *
#from .core.calculate_bias import calculate_bias, calculate_bin_bias

# This is extracted automatically by the top-level setup.py.
__version__ = '1.0.8'

# Check download was completed


        