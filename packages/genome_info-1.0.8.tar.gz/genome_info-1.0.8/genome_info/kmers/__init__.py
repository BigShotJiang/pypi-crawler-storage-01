"""Init for CallPeaks."""
from __future__ import absolute_import
from .kmer_reader import read_kmers, gc_percent
