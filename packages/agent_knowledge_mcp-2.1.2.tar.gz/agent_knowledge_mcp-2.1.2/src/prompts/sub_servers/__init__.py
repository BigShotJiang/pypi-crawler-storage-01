"""
Sub-servers for modular prompt server architecture
"""
