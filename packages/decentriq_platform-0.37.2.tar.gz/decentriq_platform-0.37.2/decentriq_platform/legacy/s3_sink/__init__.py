from .compute import S3SinkCompute

__pdoc__ = {
    "compute": False,
    "proto": False,
}

__all__ = [
    "S3SinkCompute",
]
