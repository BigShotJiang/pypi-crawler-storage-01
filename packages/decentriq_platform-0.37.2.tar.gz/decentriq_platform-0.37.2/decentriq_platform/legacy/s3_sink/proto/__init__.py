from .compute_s3_sink_pb2 import (
    FullContent,
    RawObject,
    S3Credentials,
    S3Object,
    S3SinkWorkerConfiguration,
    SingleFile,
    ZipObject,
    DqDspCredentials,
    UserDefinedCredentials,
    DspCredentialsType,
)
