"""ACE IoT Models CLI - Command line interface for ACE IoT API."""

from .cli import main

__version__ = "0.5.4"

__all__ = ["main"]
