from pathlib import Path

absolute_path = Path(__file__).parent
build_path = absolute_path / "frontend" / "build"
