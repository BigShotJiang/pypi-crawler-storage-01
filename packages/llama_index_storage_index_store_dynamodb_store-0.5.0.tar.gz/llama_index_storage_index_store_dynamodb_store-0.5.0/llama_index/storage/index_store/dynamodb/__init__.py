from llama_index.storage.index_store.dynamodb.base import DynamoDBIndexStore

__all__ = ["DynamoDBIndexStore"]
