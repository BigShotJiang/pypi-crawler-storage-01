# LlamaIndex Index_Store Integration: Dynamodb Index Store
