from .core import FileSenderBot
