from __future__ import annotations

import logging
from ._version import __title__


root_logger = logging.getLogger(__title__)