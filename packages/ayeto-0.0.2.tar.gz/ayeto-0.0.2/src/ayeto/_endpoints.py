from __future__ import annotations

VERSION = "/version"
AI_MODEL_LIST = "/ai_model/get_all"
CHAT = "/chat"
CHAT_SIMPLE = "/chat/simple"