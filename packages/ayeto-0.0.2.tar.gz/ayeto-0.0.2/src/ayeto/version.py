from ._version import __version__

VERSION = __version__