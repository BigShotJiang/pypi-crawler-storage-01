from __future__ import annotations

class AyetoException(Exception):
    """Base exception class for Ayeto client errors."""