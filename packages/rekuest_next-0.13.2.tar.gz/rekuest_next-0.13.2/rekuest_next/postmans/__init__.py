"""The postman module is used to create a communicationg assigner with the rekeust_server"""
