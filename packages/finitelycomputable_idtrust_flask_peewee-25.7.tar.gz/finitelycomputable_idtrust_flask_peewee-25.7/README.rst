======================================
Identification of Trust (Flask-Peewee)
======================================

This provides an the implementation of the Identification of Trust microsite using the
Flask framework

The implementation is by separately requiring the Flask-dependent code and the
Peewee-dependent code.

