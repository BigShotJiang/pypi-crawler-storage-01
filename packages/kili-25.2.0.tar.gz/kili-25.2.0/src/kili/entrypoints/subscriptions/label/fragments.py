"""Fragments of label subscription."""

LABEL_FRAGMENT = """
id
author {
  email
}
labelOf {
  id
}
labelType
jsonResponse
"""
