from typing import Literal

Stage = Literal["train", "val", "test"]
