from optuna.trial import FrozenTrial, Trial

HpTunerTrial = Trial | FrozenTrial
