This module is an extension of the module *l10n_fr_ecotax* for sale
orders. Please refer to the README of the module *account_ecotax* for
more info about ecotax management.
