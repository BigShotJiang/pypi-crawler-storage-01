# src/matplot_util/__init__.py
