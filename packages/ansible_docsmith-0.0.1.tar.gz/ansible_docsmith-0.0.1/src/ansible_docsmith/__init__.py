"""DocSmith for Ansible: automating role documentation (using argument_specs.yml). Placeholder - coming soon!"""
__version__ = "0.0.1"
