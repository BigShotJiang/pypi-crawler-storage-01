from enum import StrEnum


class Game(StrEnum):
    LOL = "lor"
    VALURANT = "val"
