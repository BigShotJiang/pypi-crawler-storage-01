# ChampionMastery-V4
get_all_champion_mastery = "https://{server_addr}/lol/champion-mastery/v4/champion-masteries/by-puuid/{puuid}"
get_champion_mastery = (
    "https://{server_addr}/lol/champion-mastery/v4/champion-masteries/by-puuid/{puuid}/by-champion/{champion_id}"
)
get_top_champion_mastery_by_count = (
    "https://{server_addr}/lol/champion-mastery/v4/champion-masteries/by-puuid/{puuid}/top"
)
get_total_champion_mastery_score = "https://{server_addr}/lol/champion-mastery/v4/scores/by-puuid/{puuid}"
