When user click to cancel purchase request, a confirmation wizard will
be show, with reason as optional.
