class ToolboxError(Exception):
    """Base Toolbox Exception"""
