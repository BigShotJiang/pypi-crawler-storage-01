
# Usage
- import frinZ 
- ifile = "test.cor"
- header = frinZ.cor.header(ifile)
- visibility = frinZ.cor.visibility(ifile, skip = 0, header = header)


# frinZ version history in PyPI  
- https://pypi.org/project/frinZ/1.3/
