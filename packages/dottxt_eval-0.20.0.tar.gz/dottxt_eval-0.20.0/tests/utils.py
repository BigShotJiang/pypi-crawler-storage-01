def sampler(samples: list):
    return ["b"] * len(samples)
