# structlogger
Cloud-native structured logging for Python: JSON logs, context support, AWS-ready, zero dependencies.
