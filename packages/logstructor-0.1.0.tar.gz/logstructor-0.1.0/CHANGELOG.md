# CHANGELOG


## v0.1.0 (2025-08-03)

### Continuous Integration

- Add github action workflow
  ([`f10f88f`](https://github.com/flitzpiepe93/logstructor/commit/f10f88fe1cce5abe6c67a59b968ecfc84e2e1fed))

### Features

- Add first basis version of framework
  ([`daf3b44`](https://github.com/flitzpiepe93/logstructor/commit/daf3b442835a210af4fad3d2b16260f39aa88475))
