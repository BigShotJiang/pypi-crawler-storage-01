#!/usr/bin/env python
# -*- coding:utf-8 -*-

from setuptools import setup  # 这个包没有的可以pip一下

setup()
