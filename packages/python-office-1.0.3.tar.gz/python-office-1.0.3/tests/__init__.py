# pip install python-office -i https://pypi.python.org/simple -U
# pip install PyOfficeRobot -i https://pypi.python.org/simple -U
# pip install poimage -i https://pypi.python.org/simple -U

# 1、pip freeze > allpackages.txt
# 2、pip uninstall -r allpackages.txt -y
# 3、pip install --upgrade python-office

# 下载次数：https://pypistats.org/packages/python-office