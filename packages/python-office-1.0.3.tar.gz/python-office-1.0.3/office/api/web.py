# -*- coding:utf-8 -*-

import pospider


def url2ebook(url, tile):
    pospider.url.url2ebook(url, tile)
