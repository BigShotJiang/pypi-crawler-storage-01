<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>CtrlBtn</name>
    <message>
        <location filename="../windows/CtrlBtn.qml" line="19"/>
        <source>Maximize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/CtrlBtn.qml" line="19"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/CtrlBtn.qml" line="19"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/CtrlBtn.qml" line="19"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DatePicker</name>
    <message>
        <location filename="../components/DateAndTime/DatePicker.qml" line="98"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/DateAndTime/DatePicker.qml" line="99"/>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/DateAndTime/DatePicker.qml" line="100"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorPage</name>
    <message>
        <location filename="../components/Navigation/ErrorPage.qml" line="21"/>
        <source>Sorry, something went wrong!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/Navigation/ErrorPage.qml" line="30"/>
        <source> load failed! 

 Because of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/Navigation/ErrorPage.qml" line="30"/>
        <source>
Please try again later.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/Navigation/ErrorPage.qml" line="41"/>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FluentWindow</name>
    <message>
        <location filename="../windows/FluentWindow.qml" line="11"/>
        <source>Fluent Window</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FluentWindowBase</name>
    <message>
        <location filename="../windows/FluentWindowBase.qml" line="11"/>
        <source>Fluent Window Base</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoBar</name>
    <message>
        <location filename="../components/StatusAndInfo/InfoBar.qml" line="171"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NavigationBar</name>
    <message>
        <location filename="../components/Navigation/NavigationBar.qml" line="98"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/Navigation/NavigationBar.qml" line="137"/>
        <source>Open Navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/Navigation/NavigationBar.qml" line="137"/>
        <source>Close Navigation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PickerView</name>
    <message>
        <location filename="../components/DateAndTime/PickerView.qml" line="26"/>
        <source>AM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/DateAndTime/PickerView.qml" line="26"/>
        <source>PM</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Switch</name>
    <message>
        <location filename="../components/BasicInput/Switch.qml" line="15"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/BasicInput/Switch.qml" line="16"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextInputMenu</name>
    <message>
        <location filename="../components/MenusAndToolbars/TextInputMenu.qml" line="13"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/MenusAndToolbars/TextInputMenu.qml" line="20"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/MenusAndToolbars/TextInputMenu.qml" line="27"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/MenusAndToolbars/TextInputMenu.qml" line="34"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimePicker</name>
    <message>
        <location filename="../components/DateAndTime/TimePicker.qml" line="10"/>
        <source>AM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/DateAndTime/TimePicker.qml" line="11"/>
        <source>PM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/DateAndTime/TimePicker.qml" line="12"/>
        <source>hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/DateAndTime/TimePicker.qml" line="13"/>
        <source>minute</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TitleBar</name>
    <message>
        <location filename="../windows/TitleBar.qml" line="133"/>
        <source>Fluent TitleBar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Toast</name>
    <message>
        <location filename="../components/StatusAndInfo/Toast.qml" line="156"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
