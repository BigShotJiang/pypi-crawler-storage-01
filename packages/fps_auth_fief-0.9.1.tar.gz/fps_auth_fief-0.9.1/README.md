# fps-auth-fief

An FPS plugin for the authentication API, using Fief.
