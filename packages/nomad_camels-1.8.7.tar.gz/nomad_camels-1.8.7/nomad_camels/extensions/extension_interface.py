EXTENSION_CONFIG = {
    "required_contexts": [],
    "name": "",
    "version": "0.0",
    "dependencies": {"nomad-camels": ">=0.2.4"},
}


class Extension:
    def stop_extension(self):
        pass
