:status: under-construction

Patterns
========

..  self-criticism::

    These docs are still under construction.

- what is a pattern

Background
----------

- legacy of sc's pattern library

Sequences
---------

Noise
-----

Math
----

Events
------

- event pattern
- mono event pattern

Control flow
------------

Structure
---------

- bus pattern
- fx pattern
- group pattern
- parallel

Players
-------

- realtime
- non-realtime
