Advanced tutorials overview
===========================

The following set of tutorials represent Supriya's *advanced* functionality:

- Orchestration of commands over time
- Affordances for building complex audio applications
- Integration with third-party tooling
