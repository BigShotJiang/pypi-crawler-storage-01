from ..truthful_qa.truthful_qa import TruthfulQAMode
from ..arc.arc import ARCMode
