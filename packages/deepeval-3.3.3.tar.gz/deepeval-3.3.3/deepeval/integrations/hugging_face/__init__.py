from deepeval.integrations.hugging_face.callback import (
    DeepEvalHuggingFaceCallback,
)
