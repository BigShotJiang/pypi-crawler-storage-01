from setuptools import setup, find_packages

setup(
    name='megarnucleusx',
    version='0.0.2.3',
    description='IA modular sin dependencias externas',
    author='TuNombre',
    author_email='tu@email.com',
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.6',
)
