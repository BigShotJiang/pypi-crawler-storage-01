# `timecopilot.gift_eval`

::: timecopilot.gift_eval.eval
    options:
        members:
            - GIFTEval

::: timecopilot.gift_eval.gluonts_predictor
    options:
        members:
            - GluonTSPredictor