
# `timecopilot.models.benchmarks.stats`

::: timecopilot.models.benchmarks.stats
    options:
        members:
            - ADIDA
            - AutoARIMA
            - AutoCES
            - AutoETS
            - CrostonClassic
            - DynamicOptimizedTheta
            - HistoricAverage
            - IMAPA
            - SeasonalNaive
            - Theta
            - ZeroModel