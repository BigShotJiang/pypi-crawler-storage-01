# `timecopilot.models.foundational`

::: timecopilot.models.foundational.chronos
    options:
        members:
            - Chronos

::: timecopilot.models.foundational.timegpt
    options:
        members:
            - TimeGPT

::: timecopilot.models.foundational.timesfm
    options:
        members:
            - TimesFM

::: timecopilot.models.foundational.toto
    options:
        members:
            - Toto

::: timecopilot.models.foundational.tirex
    options:
        members:
            - TiRex

::: timecopilot.models.foundational.tabpfn
    options:
        members:
            - TabPFN

::: timecopilot.models.foundational.moirai
    options:
        members:
            - Moirai