<style>
  .md-typeset h1,
  .md-content__button {
    display: none;
  }
</style>

--8<-- "README.md"
