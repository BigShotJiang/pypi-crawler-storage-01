from setuptools import setup, find_packages

setup(
    name="dziplib",
    version="1.0.0",
    packages=find_packages(),
    author="danilavkariev",
    description="Test librarry",
    python_requires=">=3.6",
)