# Copyright 2024 SAFRAN SA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

## This is the init file of pyHarm Package
"""
The pyHarm package is the core of pyHarm. It contains every modules and subpackages for pyHarm to be runnning an analysis. 
"""
from ._version import __version__, __package_name__
from .BaseUtilFuncs import *
from .Maestro import Maestro
import importlib.metadata

def _load_extensions(verbose: bool = True):
    group = "pyharm.extensions"
    for entry_point in importlib.metadata.entry_points().select(group=group):
        try:
            if verbose:
                print(f"[pyHarm] Loading extension: {entry_point.name} -> {entry_point.value}")
            plugin_func = entry_point.load()
            plugin_func()
        except Exception as e:
            print(f"[pyHarm] Failed to load extension '{entry_point.name}': {e}")

_load_extensions()