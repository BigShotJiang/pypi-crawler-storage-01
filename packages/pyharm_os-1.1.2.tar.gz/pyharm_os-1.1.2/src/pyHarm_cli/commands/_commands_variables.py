
LOCK_FILE_NAME = r"pyharm.lock"
RUN_FILE_NAME = r"pyHarm_run.py"
SYSTEM_FILE_NAME = r"system.json"
ANALYSIS_FILE_NAME = r"analysis.json"