"""
This package contains the main logic for every command of the CLI tool
"""