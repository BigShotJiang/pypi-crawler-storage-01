volatile unsigned long {{ trace_variable_task }};
volatile unsigned long {{ trace_variable_isr }};