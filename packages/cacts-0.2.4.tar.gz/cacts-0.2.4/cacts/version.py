"""
Define CACTS version
NOTE: we put it here, rather than in __init__.py, so we can
avoid pylint cyclic imports errors
"""

__version__ = "0.2.4"
