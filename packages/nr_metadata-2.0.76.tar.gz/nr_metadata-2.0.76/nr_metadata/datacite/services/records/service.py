from oarepo_runtime.services.service import SearchAllRecordsService


class DataciteService(SearchAllRecordsService):
    """DataciteRecord service."""
