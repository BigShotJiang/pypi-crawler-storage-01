import React from "react";

export const DoubleSeparator = () => {
  return <div className="double separator"></div>;
};
