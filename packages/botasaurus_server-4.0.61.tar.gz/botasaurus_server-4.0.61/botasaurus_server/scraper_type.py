class ScraperType:
    BROWSER = "browser"
    REQUEST = "request"
    TASK = "task"
