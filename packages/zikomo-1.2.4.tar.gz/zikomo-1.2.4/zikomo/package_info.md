# Zikomo CLI
#### Developed by Imran A. Shah

This CLI is designed to facilitate the deployment of projects to Staging, UAT and Production environments. It supports various commands for managing deployments, updating databases, and interacting with the system.