class EnvVarNotSet(Exception):
    pass
