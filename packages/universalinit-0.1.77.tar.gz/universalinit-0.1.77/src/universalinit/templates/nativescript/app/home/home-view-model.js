import { fromObject } from '@nativescript/core'

export function HomeViewModel() {
  const viewModel = fromObject({
    /* Add your view model properties here */
  })

  return viewModel
}
