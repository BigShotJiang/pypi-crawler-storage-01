from enum import Enum

class GraphColor(Enum):
    Red = "red"
    Blue = "blue"
    Green = "green"
    Yellow = "yellow"
    Black = "black"
    White = "white"
    Orange = "orange"
    Grey = "grey"