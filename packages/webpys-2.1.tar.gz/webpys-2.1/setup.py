from setuptools import setup, find_packages

setup(
    name="webpys",  # Your package name on PyPI
    version="2.1",
    author="Pugazh@TheHacker",
    description="A website analysis tool with security features",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/webpys",  # GitHub or docs link
    packages=find_packages(),
    install_requires=[
        "requests",
        "rich",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",  # Or your chosen license
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'webpys=yourtool.main:main',  # CLI entry point
        ],
    },
)
