# TA-X: X (Twitter) Agent Package

A Python package for interacting with X (Twitter) platform using AI agents. This package provides a simple and intuitive interface to perform various Twitter operations like posting, liking, retweeting, and retrieving data.

## Features

- 🤖 AI-powered X (Twitter) interactions
- 📝 Create and post content
- ❤️ Like and unlike posts
- 🔄 Retweet posts
- 📊 Get trending topics
- 👤 Get user details and tweet information
- 🔧 Easy configuration and setup
- 🚀 Ready for PyPI distribution

## Installation

### From PyPI (Recommended)

```bash
pip install ta-x
```

### From Source

```bash
git clone https://github.com/yourusername/ta-x.git
cd ta-x
pip install -e .
```

## Quick Start

### 1. Setup Configuration

First, you need to set up your authentication tokens and API keys:

```python
from ta_x import setup

# Setup with your credentials
setup(
    x_auth_token="your_x_auth_token",
    x_ct0="your_x_ct0_token",
    openai_api_key="your_openai_api_key",
    rapid_api_key="your_rapid_api_key"
)
```

### 2. Using Environment Variables (Alternative)

You can also set the credentials using environment variables:

```bash
export X_AUTH_TOKEN="your_x_auth_token"
export X_CT0="your_x_ct0_token"
export OPENAI_API_KEY="your_openai_api_key"
export RAPID_API_KEY="your_rapid_api_key"
```

Then import and use the package:

```python
from ta_x import XAgent

# The agent will automatically use environment variables
agent = XAgent()
```

### 3. Basic Usage

```python
import asyncio
from ta_x import XAgent

async def main():
    # Create an agent instance
    agent = XAgent()
    
    # Post content
    result = await agent.run("Post this: Hello X world!")
    print(result)
    
    # Like the latest post
    result = await agent.run("Like the latest post")
    print(result)
    
    # Get trending topics
    result = await agent.run("What's trending?")
    print(result)

# Run the async function
asyncio.run(main())
```

## Advanced Usage

### Working with Specific Users

```python
# Like a specific user's latest post
result = await agent.run("Like the latest post of elonmusk")

# Retweet a specific user's second latest post
result = await agent.run("Retweet the second latest post of elonmusk")

# Get user details
result = await agent.run("Get user details for elonmusk")
```

### Working with Specific Posts

```python
# Like a specific post by ID
result = await agent.run("Like post 123456789")

# Get tweet details
result = await agent.run("Get tweet details for 123456789")
```

### Using the Execute Function

```python
from ta_x import execute_x_task

async def main():
    # Execute tasks directly
    result = await execute_x_task("Post this: Another test post")
    print(result)

asyncio.run(main())
```

## Configuration Management

### Get Current Configuration

```python
from ta_x import get_config

config = get_config()
print(f"X Auth Token: {config.x_auth_token}")
print(f"X CT0: {config.x_ct0}")
print(f"OpenAI API Key: {config.openai_api_key}")
print(f"RapidAPI Key: {config.rapid_api_key}")
```

### Reset Configuration

```python
from ta_x import reset_config

# Reset to default values
reset_config()
```

## Available Operations

The agent supports the following operations:

1. **Create Posts**: `"Post this: [content]"` or `"Create a post with [content]"`
2. **Like Posts**: `"Like the latest post"` or `"Like the post of [username]"`
3. **Unlike Posts**: `"Unlike the post"` or `"Dislike the post of [username]"`
4. **Retweet Posts**: `"Retweet the post"` or `"Retweet the post of [username]"`
5. **Get Trends**: `"What's trending?"` or `"Show trends"`
6. **Get Tweet Details**: `"Get tweet details for [tweet_id]"`
7. **Get User Details**: `"Get user details for [username]"`

## Error Handling

The package includes comprehensive error handling:

- **Missing Configuration**: Clear error messages when required tokens are not set
- **Invalid Credentials**: Proper handling of authentication failures
- **Network Errors**: Graceful handling of connection issues
- **Rate Limiting**: Built-in support for X API rate limits

## Development

### Installing Development Dependencies

```bash
pip install -e ".[dev]"
```

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black ta_x/
```

### Type Checking

```bash
mypy ta_x/
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run the test suite
6. Submit a pull request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- 📧 Email: your.email@example.com
- 🐛 Issues: [GitHub Issues](https://github.com/yourusername/ta-x/issues)
- 📖 Documentation: [GitHub README](https://github.com/yourusername/ta-x#readme)

## Disclaimer

This package is for educational and development purposes. Please ensure you comply with X (Twitter)'s Terms of Service and API usage guidelines when using this package. 