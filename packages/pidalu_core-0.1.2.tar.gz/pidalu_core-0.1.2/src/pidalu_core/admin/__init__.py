from .mixins import ReadOnlyAdminFieldsMixin, AutoSlugAdminMixin

__all__ = [
    "ReadOnlyAdminFieldsMixin",
    "AutoSlugAdminMixin",
]
