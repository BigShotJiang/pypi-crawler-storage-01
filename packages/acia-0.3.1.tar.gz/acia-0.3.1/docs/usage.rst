=====
Usage
=====

To use AutomatedCellularImageAnalysis in a project::

    import acia
