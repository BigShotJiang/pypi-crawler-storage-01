def main():
    print("Hello from damb!")


if __name__ == "__main__":
    main()
