"""Compatibility layer for maintaining existing API."""
