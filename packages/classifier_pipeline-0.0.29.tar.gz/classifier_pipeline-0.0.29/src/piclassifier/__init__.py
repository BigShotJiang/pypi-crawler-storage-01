def pi_classify():
    from piclassifier.piclassify import main

    main()
