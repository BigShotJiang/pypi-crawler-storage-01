from ml_tools.thermaldataset import main

if __name__ == "__main__":
    main()
