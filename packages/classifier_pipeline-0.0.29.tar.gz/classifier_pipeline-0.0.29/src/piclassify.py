#!/usr/bin/env python

"""
Script to classify animals within a CPTV video file.
"""

from piclassifier.piclassify import main

if __name__ == "__main__":
    main()
