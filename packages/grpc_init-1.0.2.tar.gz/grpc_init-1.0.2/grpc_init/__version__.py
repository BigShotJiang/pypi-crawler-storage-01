"""
This package contains the grpc-init package.

Author: Achraf MATAICH <achraf.mataich@outlook.com>
"""

from importlib.metadata import version as get_version
__version__ = get_version("grpc-init")