# Maze Generator for Algorithms

A Python package to generate and visualize mazes for pathfinding and AI simulations.

## Installation
