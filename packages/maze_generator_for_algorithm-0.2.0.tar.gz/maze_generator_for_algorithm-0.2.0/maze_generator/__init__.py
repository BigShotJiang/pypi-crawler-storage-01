# maze_generator/__init__.py

from .core import generate_maze, print_maze, apply_wall_config, export_images
