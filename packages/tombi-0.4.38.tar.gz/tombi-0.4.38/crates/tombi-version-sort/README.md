# tombi-version-sort

This is a copy of the rustfmt's [version-sort implementation](https://github.com/rust-lang/rust/blob/14863ea0777c68348b3e6e7a8472423d273a52af/src/tools/rustfmt/src/sort.rs#L136).
For detailed specification, see https://doc.rust-lang.org/nightly/style-guide/index.html#sorting.
