#!!!!! do not change this file !!!!!
app_version="4.30"
app_bulld_anchor="Noh_2025-07-30 14:00:12.143574"
app_name="ryry-cli"
import sys, os
if getattr(sys, 'frozen', False):
    base_path = sys._MEIPASS
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

