To use this module, you need to:

1.  Go to the form view of any record that has a mail thread. It can be
    a partner, for example.
2.  Post a message.

The mail is now in the outgoing mail queue. It will be there for at
least 30 seconds. It will be really sent the next time the "Mail: Email
Queue Manager" cron job is executed.

While the message has not been yet sent:

1.  Click the little envelope. You will see a paper airplane icon,
    indicating it is still outgoing.
2.  Hover over the message and click on *⠇ \> 🗑️ Delete*. Mails will not be sent.
