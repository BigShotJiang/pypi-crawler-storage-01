{{ objname | escape | underline}}

.. currentmodule:: {{ module }}

.. autodata:: {{ objname }}