""" Expose version """

__version__ = "0.4.7"
VERSION = __version__.split(".")
