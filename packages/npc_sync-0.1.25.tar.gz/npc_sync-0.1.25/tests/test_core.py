import npc_sync


def test_import_package():
    pass