import pytest


@pytest.fixture
def sample_data():
    return {"foo": 1, "bar": 2}
