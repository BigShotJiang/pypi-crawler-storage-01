document.addEventListener('load', () => {
  console.log('Page has loaded');
  document.getElementById("table_pane").style.width = '1325px';
});
