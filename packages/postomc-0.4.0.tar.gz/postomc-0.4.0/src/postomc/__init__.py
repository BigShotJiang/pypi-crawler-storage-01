from .depletion_results import DepletionResults

__all__ = ["DepletionResults"]
__version__ = "0.4.0"