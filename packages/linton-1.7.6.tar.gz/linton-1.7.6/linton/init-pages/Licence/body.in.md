# Licence

Linton is copyright [Reuben Thomas](mailto:rrt@sc3d.org)

Linton is free software. It is distributed under the terms of the [GNU General Public License](https://www.gnu.org/copyleft/gpl.html); either version 3, or (at your option) any later version. This program is distributed in the hope that it will be useful, but without any warranty, even the implied warranty of merchantability or fitness for a particular purpose.
