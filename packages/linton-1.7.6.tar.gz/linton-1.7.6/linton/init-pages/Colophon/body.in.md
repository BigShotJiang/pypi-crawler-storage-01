# Colophon

This site is made with [Linton](https://rrthomas.github.io/linton/), the simple static web site builder, by Reuben Thomas. The site template is built with [Bootstrap](https://getbootstrap.com). The [mistletoe](https://github.com/miyuchina/mistletoe) Markdown processor is used to generate the page content.

Linton is based on [Nancy](https://github.com/rrthomas/nancy/), the simple macro processor, also by Reuben Thomas.
