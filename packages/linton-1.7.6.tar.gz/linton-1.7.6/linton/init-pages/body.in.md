# A Linton web site

Here’s your fresh Linton web site, ready to go.

See the [Linton documentation](https://rrthomas.github.io/linton) for more information on how to make your own site.

Here’s a [sample page](<Sample page/index.html>).
