# Assertive Mock API Client

    This is a mock API client that can be used to test your applications API calls.
    While also leveraging the Assertive library to provide declarative assertions to your tests.