## What's Changed

- fix(web): resolve Streamlit crashes and improve agent UI stability (e58b069)
- fix: improve agent instructions and response handling (873845b)
- feat: integrate Agent system with web interface (f91d770)

**Full Changelog**: https://github.com/djvolz/coda-code-assistant/compare/v2025.8.2.1052...v2025.8.3.1017
