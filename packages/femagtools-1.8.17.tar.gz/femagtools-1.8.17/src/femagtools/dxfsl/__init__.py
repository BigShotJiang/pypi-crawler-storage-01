"""
    femagtools.dxfsl
    ~~~~~~~~~~~~~~~~

    convert dxf to fsl


"""
