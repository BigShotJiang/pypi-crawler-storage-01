from .serializers import SettingSerializer  # noqa
