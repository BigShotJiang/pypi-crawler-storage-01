# from enum import Enum


# TODO Another option, which option we prefer? - Let's stick to one option
# class AuthenticationApiVersion(Enum):
# AUTHENTICATION_API_VERSION_DICT = {
# "play1": 1,
# "dvlp1": 2
# }
