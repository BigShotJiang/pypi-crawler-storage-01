from pathlib import Path

VECTOR_DB_DIR = Path("~/.cache/arjan/vector_db").expanduser()