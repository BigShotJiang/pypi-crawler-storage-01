def main() -> None:
    print("Hello from test-python-tag-wheel!")
