This module was written to manage audits and verifications lists of your
management system.
