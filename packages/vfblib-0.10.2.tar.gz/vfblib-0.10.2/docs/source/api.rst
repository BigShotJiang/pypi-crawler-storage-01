API
===

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   vfbLib.cmdline
   vfbLib.compilers
   vfbLib.parsers
   vfbLib.templates
   vfbLib.ufo
   vfbLib.vfb
   vfbLib.constants
   vfbLib.cu2qu
   vfbLib.diff
   vfbLib.helpers
   vfbLib.truetype
   vfbLib.tth
   vfbLib.typing
   vfbLib.value
