vfbLib.compilers.text.VendorIdCompiler
======================================

.. currentmodule:: vfbLib.compilers.text

.. autoclass:: VendorIdCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VendorIdCompiler.__init__
      ~VendorIdCompiler.compile
      ~VendorIdCompiler.compile_hex
      ~VendorIdCompiler.merge
      ~VendorIdCompiler.write_bytes
      ~VendorIdCompiler.write_double
      ~VendorIdCompiler.write_doubles
      ~VendorIdCompiler.write_int16
      ~VendorIdCompiler.write_int32
      ~VendorIdCompiler.write_str
      ~VendorIdCompiler.write_str_with_len
      ~VendorIdCompiler.write_uint16
      ~VendorIdCompiler.write_uint32
      ~VendorIdCompiler.write_uint8
      ~VendorIdCompiler.write_value
   
   

   
   
   