vfbLib.ufo.builder
==================

.. automodule:: vfbLib.ufo.builder
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      VfbToUfoBuilder
   
   

   
   
   



