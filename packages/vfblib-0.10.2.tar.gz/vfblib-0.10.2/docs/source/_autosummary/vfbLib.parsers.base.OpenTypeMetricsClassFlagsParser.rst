vfbLib.parsers.base.OpenTypeMetricsClassFlagsParser
===================================================

.. currentmodule:: vfbLib.parsers.base

.. autoclass:: OpenTypeMetricsClassFlagsParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OpenTypeMetricsClassFlagsParser.__init__
      ~OpenTypeMetricsClassFlagsParser.parse
      ~OpenTypeMetricsClassFlagsParser.parse_hex
      ~OpenTypeMetricsClassFlagsParser.read_double
      ~OpenTypeMetricsClassFlagsParser.read_doubles
      ~OpenTypeMetricsClassFlagsParser.read_int16
      ~OpenTypeMetricsClassFlagsParser.read_int32
      ~OpenTypeMetricsClassFlagsParser.read_int8
      ~OpenTypeMetricsClassFlagsParser.read_str
      ~OpenTypeMetricsClassFlagsParser.read_str_all
      ~OpenTypeMetricsClassFlagsParser.read_str_with_len
      ~OpenTypeMetricsClassFlagsParser.read_uint16
      ~OpenTypeMetricsClassFlagsParser.read_uint32
      ~OpenTypeMetricsClassFlagsParser.read_uint8
      ~OpenTypeMetricsClassFlagsParser.read_value
   
   

   
   
   