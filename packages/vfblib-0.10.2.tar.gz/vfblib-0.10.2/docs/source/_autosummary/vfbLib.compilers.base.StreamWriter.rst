vfbLib.compilers.base.StreamWriter
==================================

.. currentmodule:: vfbLib.compilers.base

.. autoclass:: StreamWriter
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~StreamWriter.__init__
      ~StreamWriter.write_bytes
      ~StreamWriter.write_double
      ~StreamWriter.write_doubles
      ~StreamWriter.write_int16
      ~StreamWriter.write_int32
      ~StreamWriter.write_str
      ~StreamWriter.write_str_with_len
      ~StreamWriter.write_uint16
      ~StreamWriter.write_uint32
      ~StreamWriter.write_uint8
      ~StreamWriter.write_value
   
   

   
   
   