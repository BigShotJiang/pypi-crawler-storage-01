vfbLib.compilers.bitmap.GlyphBitmapsCompiler
============================================

.. currentmodule:: vfbLib.compilers.bitmap

.. autoclass:: GlyphBitmapsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphBitmapsCompiler.__init__
      ~GlyphBitmapsCompiler.compile
      ~GlyphBitmapsCompiler.compile_hex
      ~GlyphBitmapsCompiler.merge
      ~GlyphBitmapsCompiler.write_bytes
      ~GlyphBitmapsCompiler.write_double
      ~GlyphBitmapsCompiler.write_doubles
      ~GlyphBitmapsCompiler.write_int16
      ~GlyphBitmapsCompiler.write_int32
      ~GlyphBitmapsCompiler.write_str
      ~GlyphBitmapsCompiler.write_str_with_len
      ~GlyphBitmapsCompiler.write_uint16
      ~GlyphBitmapsCompiler.write_uint32
      ~GlyphBitmapsCompiler.write_uint8
      ~GlyphBitmapsCompiler.write_value
   
   

   
   
   