vfbLib.typing.VfbDict
=====================

.. currentmodule:: vfbLib.typing

.. autoclass:: VfbDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbDict.__init__
      ~VfbDict.clear
      ~VfbDict.copy
      ~VfbDict.fromkeys
      ~VfbDict.get
      ~VfbDict.items
      ~VfbDict.keys
      ~VfbDict.pop
      ~VfbDict.popitem
      ~VfbDict.setdefault
      ~VfbDict.update
      ~VfbDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbDict.header
      ~VfbDict.entries
   
   