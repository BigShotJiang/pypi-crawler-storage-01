vfbLib.ufo.features.rename\_kern\_classes\_in\_feature\_code
============================================================

.. currentmodule:: vfbLib.ufo.features

.. autofunction:: rename_kern_classes_in_feature_code