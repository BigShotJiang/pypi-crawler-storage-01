vfbLib.parsers.bitmap.GlyphBitmapsParser
========================================

.. currentmodule:: vfbLib.parsers.bitmap

.. autoclass:: GlyphBitmapsParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphBitmapsParser.__init__
      ~GlyphBitmapsParser.parse
      ~GlyphBitmapsParser.parse_hex
      ~GlyphBitmapsParser.read_double
      ~GlyphBitmapsParser.read_doubles
      ~GlyphBitmapsParser.read_int16
      ~GlyphBitmapsParser.read_int32
      ~GlyphBitmapsParser.read_int8
      ~GlyphBitmapsParser.read_str
      ~GlyphBitmapsParser.read_str_all
      ~GlyphBitmapsParser.read_str_with_len
      ~GlyphBitmapsParser.read_uint16
      ~GlyphBitmapsParser.read_uint32
      ~GlyphBitmapsParser.read_uint8
      ~GlyphBitmapsParser.read_value
   
   

   
   
   