vfbLib.vfb.glyph.VfbGlyphMaster
===============================

.. currentmodule:: vfbLib.vfb.glyph

.. autoclass:: VfbGlyphMaster
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbGlyphMaster.__init__
      ~VfbGlyphMaster.clearContours
      ~VfbGlyphMaster.drawPoints
      ~VfbGlyphMaster.getPen
      ~VfbGlyphMaster.getPointPen
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbGlyphMaster.name
   
   