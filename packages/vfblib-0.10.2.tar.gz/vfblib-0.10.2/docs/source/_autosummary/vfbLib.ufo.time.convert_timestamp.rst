vfbLib.ufo.time.convert\_timestamp
==================================

.. currentmodule:: vfbLib.ufo.time

.. autofunction:: convert_timestamp