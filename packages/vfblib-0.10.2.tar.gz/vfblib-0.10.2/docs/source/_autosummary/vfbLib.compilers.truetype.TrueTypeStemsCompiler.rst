vfbLib.compilers.truetype.TrueTypeStemsCompiler
===============================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: TrueTypeStemsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeStemsCompiler.__init__
      ~TrueTypeStemsCompiler.compile
      ~TrueTypeStemsCompiler.compile_hex
      ~TrueTypeStemsCompiler.merge
      ~TrueTypeStemsCompiler.write_bytes
      ~TrueTypeStemsCompiler.write_double
      ~TrueTypeStemsCompiler.write_doubles
      ~TrueTypeStemsCompiler.write_int16
      ~TrueTypeStemsCompiler.write_int32
      ~TrueTypeStemsCompiler.write_str
      ~TrueTypeStemsCompiler.write_str_with_len
      ~TrueTypeStemsCompiler.write_uint16
      ~TrueTypeStemsCompiler.write_uint32
      ~TrueTypeStemsCompiler.write_uint8
      ~TrueTypeStemsCompiler.write_value
   
   

   
   
   