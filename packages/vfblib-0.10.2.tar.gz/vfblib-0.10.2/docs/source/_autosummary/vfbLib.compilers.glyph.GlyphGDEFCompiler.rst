vfbLib.compilers.glyph.GlyphGDEFCompiler
========================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlyphGDEFCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphGDEFCompiler.__init__
      ~GlyphGDEFCompiler.compile
      ~GlyphGDEFCompiler.compile_hex
      ~GlyphGDEFCompiler.merge
      ~GlyphGDEFCompiler.write_bytes
      ~GlyphGDEFCompiler.write_double
      ~GlyphGDEFCompiler.write_doubles
      ~GlyphGDEFCompiler.write_int16
      ~GlyphGDEFCompiler.write_int32
      ~GlyphGDEFCompiler.write_str
      ~GlyphGDEFCompiler.write_str_with_len
      ~GlyphGDEFCompiler.write_uint16
      ~GlyphGDEFCompiler.write_uint32
      ~GlyphGDEFCompiler.write_uint8
      ~GlyphGDEFCompiler.write_value
   
   

   
   
   