vfbLib.typing.GaspRangeDict
===========================

.. currentmodule:: vfbLib.typing

.. autoclass:: GaspRangeDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GaspRangeDict.__init__
      ~GaspRangeDict.clear
      ~GaspRangeDict.copy
      ~GaspRangeDict.fromkeys
      ~GaspRangeDict.get
      ~GaspRangeDict.items
      ~GaspRangeDict.keys
      ~GaspRangeDict.pop
      ~GaspRangeDict.popitem
      ~GaspRangeDict.setdefault
      ~GaspRangeDict.update
      ~GaspRangeDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GaspRangeDict.maxPpem
      ~GaspRangeDict.flags
   
   