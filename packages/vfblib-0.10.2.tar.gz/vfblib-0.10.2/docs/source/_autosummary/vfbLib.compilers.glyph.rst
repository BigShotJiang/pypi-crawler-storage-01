vfbLib.compilers.glyph
======================

.. automodule:: vfbLib.compilers.glyph
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      GlobalMaskCompiler
      GlyphAnchorsCompiler
      GlyphAnchorsSuppCompiler
      GlyphCompiler
      GlyphGDEFCompiler
      GlyphOriginCompiler
      GlyphSketchCompiler
      GlyphUnicodesCompiler
      GlyphUnicodesSuppCompiler
      InstructionsCompiler
      LinksCompiler
      MaskCompiler
      MaskMetricsCompiler
      MaskMetricsMMCompiler
      OutlinesCompiler
   
   

   
   
   



