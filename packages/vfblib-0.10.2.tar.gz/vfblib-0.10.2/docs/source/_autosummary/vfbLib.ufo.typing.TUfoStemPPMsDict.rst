vfbLib.ufo.typing.TUfoStemPPMsDict
==================================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoStemPPMsDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoStemPPMsDict.__init__
      ~TUfoStemPPMsDict.clear
      ~TUfoStemPPMsDict.copy
      ~TUfoStemPPMsDict.fromkeys
      ~TUfoStemPPMsDict.get
      ~TUfoStemPPMsDict.items
      ~TUfoStemPPMsDict.keys
      ~TUfoStemPPMsDict.pop
      ~TUfoStemPPMsDict.popitem
      ~TUfoStemPPMsDict.setdefault
      ~TUfoStemPPMsDict.update
      ~TUfoStemPPMsDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoStemPPMsDict.ttStemsH
      ~TUfoStemPPMsDict.ttStemsV
   
   