vfbLib.typing.FeaturesDict
==========================

.. currentmodule:: vfbLib.typing

.. autoclass:: FeaturesDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FeaturesDict.__init__
      ~FeaturesDict.clear
      ~FeaturesDict.copy
      ~FeaturesDict.fromkeys
      ~FeaturesDict.get
      ~FeaturesDict.items
      ~FeaturesDict.keys
      ~FeaturesDict.pop
      ~FeaturesDict.popitem
      ~FeaturesDict.setdefault
      ~FeaturesDict.update
      ~FeaturesDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~FeaturesDict.prefix
      ~FeaturesDict.features
   
   