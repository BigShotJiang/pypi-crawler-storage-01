vfbLib.ufo.typing.UfoHintSet
============================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: UfoHintSet
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UfoHintSet.__init__
      ~UfoHintSet.clear
      ~UfoHintSet.copy
      ~UfoHintSet.fromkeys
      ~UfoHintSet.get
      ~UfoHintSet.items
      ~UfoHintSet.keys
      ~UfoHintSet.pop
      ~UfoHintSet.popitem
      ~UfoHintSet.setdefault
      ~UfoHintSet.update
      ~UfoHintSet.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UfoHintSet.pointTag
      ~UfoHintSet.stems
   
   