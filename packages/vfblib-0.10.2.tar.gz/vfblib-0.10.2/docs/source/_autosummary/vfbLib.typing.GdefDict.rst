vfbLib.typing.GdefDict
======================

.. currentmodule:: vfbLib.typing

.. autoclass:: GdefDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GdefDict.__init__
      ~GdefDict.clear
      ~GdefDict.copy
      ~GdefDict.fromkeys
      ~GdefDict.get
      ~GdefDict.items
      ~GdefDict.keys
      ~GdefDict.pop
      ~GdefDict.popitem
      ~GdefDict.setdefault
      ~GdefDict.update
      ~GdefDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GdefDict.anchors
      ~GdefDict.carets
      ~GdefDict.glyph_class
      ~GdefDict.unknown
   
   