vfbLib.ufo.pshints.get\_master\_hints
=====================================

.. currentmodule:: vfbLib.ufo.pshints

.. autofunction:: get_master_hints