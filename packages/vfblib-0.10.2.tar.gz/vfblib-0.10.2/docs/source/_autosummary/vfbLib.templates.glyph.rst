vfbLib.templates.glyph
======================

.. automodule:: vfbLib.templates.glyph
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      get_empty_glyph
   
   

   
   
   

   
   
   



