vfbLib.parsers.bitmap.BackgroundBitmapParser
============================================

.. currentmodule:: vfbLib.parsers.bitmap

.. autoclass:: BackgroundBitmapParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BackgroundBitmapParser.__init__
      ~BackgroundBitmapParser.parse
      ~BackgroundBitmapParser.parse_hex
      ~BackgroundBitmapParser.read_double
      ~BackgroundBitmapParser.read_doubles
      ~BackgroundBitmapParser.read_int16
      ~BackgroundBitmapParser.read_int32
      ~BackgroundBitmapParser.read_int8
      ~BackgroundBitmapParser.read_str
      ~BackgroundBitmapParser.read_str_all
      ~BackgroundBitmapParser.read_str_with_len
      ~BackgroundBitmapParser.read_uint16
      ~BackgroundBitmapParser.read_uint32
      ~BackgroundBitmapParser.read_uint8
      ~BackgroundBitmapParser.read_value
   
   

   
   
   