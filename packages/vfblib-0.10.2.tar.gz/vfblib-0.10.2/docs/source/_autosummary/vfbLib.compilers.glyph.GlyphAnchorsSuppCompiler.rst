vfbLib.compilers.glyph.GlyphAnchorsSuppCompiler
===============================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlyphAnchorsSuppCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphAnchorsSuppCompiler.__init__
      ~GlyphAnchorsSuppCompiler.compile
      ~GlyphAnchorsSuppCompiler.compile_hex
      ~GlyphAnchorsSuppCompiler.merge
      ~GlyphAnchorsSuppCompiler.write_bytes
      ~GlyphAnchorsSuppCompiler.write_double
      ~GlyphAnchorsSuppCompiler.write_doubles
      ~GlyphAnchorsSuppCompiler.write_int16
      ~GlyphAnchorsSuppCompiler.write_int32
      ~GlyphAnchorsSuppCompiler.write_str
      ~GlyphAnchorsSuppCompiler.write_str_with_len
      ~GlyphAnchorsSuppCompiler.write_uint16
      ~GlyphAnchorsSuppCompiler.write_uint32
      ~GlyphAnchorsSuppCompiler.write_uint8
      ~GlyphAnchorsSuppCompiler.write_value
   
   

   
   
   