vfbLib.compilers.guides.GuidePropertiesCompiler
===============================================

.. currentmodule:: vfbLib.compilers.guides

.. autoclass:: GuidePropertiesCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GuidePropertiesCompiler.__init__
      ~GuidePropertiesCompiler.compile
      ~GuidePropertiesCompiler.compile_hex
      ~GuidePropertiesCompiler.merge
      ~GuidePropertiesCompiler.write_bytes
      ~GuidePropertiesCompiler.write_double
      ~GuidePropertiesCompiler.write_doubles
      ~GuidePropertiesCompiler.write_int16
      ~GuidePropertiesCompiler.write_int32
      ~GuidePropertiesCompiler.write_str
      ~GuidePropertiesCompiler.write_str_with_len
      ~GuidePropertiesCompiler.write_uint16
      ~GuidePropertiesCompiler.write_uint32
      ~GuidePropertiesCompiler.write_uint8
      ~GuidePropertiesCompiler.write_value
   
   

   
   
   