vfbLib.vfb.vfb.VfbMaster
========================

.. currentmodule:: vfbLib.vfb.vfb

.. autoclass:: VfbMaster
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbMaster.__init__
      ~VfbMaster.items
      ~VfbMaster.keys
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbMaster.glyph_order
      ~VfbMaster.info
      ~VfbMaster.num_masters
      ~VfbMaster.ps_hinting_options
   
   