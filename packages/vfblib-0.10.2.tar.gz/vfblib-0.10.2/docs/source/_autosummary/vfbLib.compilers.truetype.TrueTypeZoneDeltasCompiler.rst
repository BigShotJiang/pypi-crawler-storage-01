vfbLib.compilers.truetype.TrueTypeZoneDeltasCompiler
====================================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: TrueTypeZoneDeltasCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeZoneDeltasCompiler.__init__
      ~TrueTypeZoneDeltasCompiler.compile
      ~TrueTypeZoneDeltasCompiler.compile_hex
      ~TrueTypeZoneDeltasCompiler.merge
      ~TrueTypeZoneDeltasCompiler.write_bytes
      ~TrueTypeZoneDeltasCompiler.write_double
      ~TrueTypeZoneDeltasCompiler.write_doubles
      ~TrueTypeZoneDeltasCompiler.write_int16
      ~TrueTypeZoneDeltasCompiler.write_int32
      ~TrueTypeZoneDeltasCompiler.write_str
      ~TrueTypeZoneDeltasCompiler.write_str_with_len
      ~TrueTypeZoneDeltasCompiler.write_uint16
      ~TrueTypeZoneDeltasCompiler.write_uint32
      ~TrueTypeZoneDeltasCompiler.write_uint8
      ~TrueTypeZoneDeltasCompiler.write_value
   
   

   
   
   