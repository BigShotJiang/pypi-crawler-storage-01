vfbLib.compilers.cmap.CustomCmapCompiler
========================================

.. currentmodule:: vfbLib.compilers.cmap

.. autoclass:: CustomCmapCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CustomCmapCompiler.__init__
      ~CustomCmapCompiler.compile
      ~CustomCmapCompiler.compile_hex
      ~CustomCmapCompiler.merge
      ~CustomCmapCompiler.write_bytes
      ~CustomCmapCompiler.write_double
      ~CustomCmapCompiler.write_doubles
      ~CustomCmapCompiler.write_int16
      ~CustomCmapCompiler.write_int32
      ~CustomCmapCompiler.write_str
      ~CustomCmapCompiler.write_str_with_len
      ~CustomCmapCompiler.write_uint16
      ~CustomCmapCompiler.write_uint32
      ~CustomCmapCompiler.write_uint8
      ~CustomCmapCompiler.write_value
   
   

   
   
   