vfbLib.cmdline.vfb2json
=======================

.. currentmodule:: vfbLib.cmdline

.. autofunction:: vfb2json