vfbLib.compilers.value.write\_value\_long
=========================================

.. currentmodule:: vfbLib.compilers.value

.. autofunction:: write_value_long