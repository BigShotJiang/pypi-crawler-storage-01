vfbLib.typing.AnchorDict
========================

.. currentmodule:: vfbLib.typing

.. autoclass:: AnchorDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AnchorDict.__init__
      ~AnchorDict.clear
      ~AnchorDict.copy
      ~AnchorDict.fromkeys
      ~AnchorDict.get
      ~AnchorDict.items
      ~AnchorDict.keys
      ~AnchorDict.pop
      ~AnchorDict.popitem
      ~AnchorDict.setdefault
      ~AnchorDict.update
      ~AnchorDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AnchorDict.name
      ~AnchorDict.x
      ~AnchorDict.x1
      ~AnchorDict.y
      ~AnchorDict.y1
   
   