vfbLib.ufo.typing.TUfoStemDict
==============================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoStemDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoStemDict.__init__
      ~TUfoStemDict.clear
      ~TUfoStemDict.copy
      ~TUfoStemDict.fromkeys
      ~TUfoStemDict.get
      ~TUfoStemDict.items
      ~TUfoStemDict.keys
      ~TUfoStemDict.pop
      ~TUfoStemDict.popitem
      ~TUfoStemDict.setdefault
      ~TUfoStemDict.update
      ~TUfoStemDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoStemDict.horizontal
      ~TUfoStemDict.name
      ~TUfoStemDict.round
      ~TUfoStemDict.width
   
   