vfbLib.parsers.glyph.read\_absolute\_point
==========================================

.. currentmodule:: vfbLib.parsers.glyph

.. autofunction:: read_absolute_point