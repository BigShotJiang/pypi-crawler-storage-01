vfbLib.tth.extract\_tt\_stem\_ppems
===================================

.. currentmodule:: vfbLib.tth

.. autofunction:: extract_tt_stem_ppems