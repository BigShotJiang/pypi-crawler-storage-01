vfbLib.compilers.text.OpenTypeStringCompiler
============================================

.. currentmodule:: vfbLib.compilers.text

.. autoclass:: OpenTypeStringCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OpenTypeStringCompiler.__init__
      ~OpenTypeStringCompiler.compile
      ~OpenTypeStringCompiler.compile_hex
      ~OpenTypeStringCompiler.merge
      ~OpenTypeStringCompiler.write_bytes
      ~OpenTypeStringCompiler.write_double
      ~OpenTypeStringCompiler.write_doubles
      ~OpenTypeStringCompiler.write_int16
      ~OpenTypeStringCompiler.write_int32
      ~OpenTypeStringCompiler.write_str
      ~OpenTypeStringCompiler.write_str_with_len
      ~OpenTypeStringCompiler.write_uint16
      ~OpenTypeStringCompiler.write_uint32
      ~OpenTypeStringCompiler.write_uint8
      ~OpenTypeStringCompiler.write_value
   
   

   
   
   