vfbLib.vfb.info.VfbInfo
=======================

.. currentmodule:: vfbLib.vfb.info

.. autoclass:: VfbInfo
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbInfo.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbInfo.unitsPerEm
   
   