vfbLib.templates.glyph.get\_empty\_glyph
========================================

.. currentmodule:: vfbLib.templates.glyph

.. autofunction:: get_empty_glyph