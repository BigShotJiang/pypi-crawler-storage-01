vfbLib.tth.extract\_tt\_zones
=============================

.. currentmodule:: vfbLib.tth

.. autofunction:: extract_tt_zones