vfbLib.ufo.paths.UfoMasterGlyph
===============================

.. currentmodule:: vfbLib.ufo.paths

.. autoclass:: UfoMasterGlyph
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UfoMasterGlyph.__init__
      ~UfoMasterGlyph.build
      ~UfoMasterGlyph.drawPoints
      ~UfoMasterGlyph.drawPointsMask
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UfoMasterGlyph.name
   
   