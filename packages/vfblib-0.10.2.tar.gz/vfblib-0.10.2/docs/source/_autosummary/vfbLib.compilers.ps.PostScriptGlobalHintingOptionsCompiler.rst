vfbLib.compilers.ps.PostScriptGlobalHintingOptionsCompiler
==========================================================

.. currentmodule:: vfbLib.compilers.ps

.. autoclass:: PostScriptGlobalHintingOptionsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PostScriptGlobalHintingOptionsCompiler.__init__
      ~PostScriptGlobalHintingOptionsCompiler.compile
      ~PostScriptGlobalHintingOptionsCompiler.compile_hex
      ~PostScriptGlobalHintingOptionsCompiler.merge
      ~PostScriptGlobalHintingOptionsCompiler.write_bytes
      ~PostScriptGlobalHintingOptionsCompiler.write_double
      ~PostScriptGlobalHintingOptionsCompiler.write_doubles
      ~PostScriptGlobalHintingOptionsCompiler.write_int16
      ~PostScriptGlobalHintingOptionsCompiler.write_int32
      ~PostScriptGlobalHintingOptionsCompiler.write_str
      ~PostScriptGlobalHintingOptionsCompiler.write_str_with_len
      ~PostScriptGlobalHintingOptionsCompiler.write_uint16
      ~PostScriptGlobalHintingOptionsCompiler.write_uint32
      ~PostScriptGlobalHintingOptionsCompiler.write_uint8
      ~PostScriptGlobalHintingOptionsCompiler.write_value
   
   

   
   
   