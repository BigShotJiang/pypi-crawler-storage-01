vfbLib.helpers.hexStr
=====================

.. currentmodule:: vfbLib.helpers

.. autofunction:: hexStr