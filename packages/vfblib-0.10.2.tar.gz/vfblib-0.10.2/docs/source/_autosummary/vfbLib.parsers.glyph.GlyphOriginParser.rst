vfbLib.parsers.glyph.GlyphOriginParser
======================================

.. currentmodule:: vfbLib.parsers.glyph

.. autoclass:: GlyphOriginParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphOriginParser.__init__
      ~GlyphOriginParser.parse
      ~GlyphOriginParser.parse_hex
      ~GlyphOriginParser.read_double
      ~GlyphOriginParser.read_doubles
      ~GlyphOriginParser.read_int16
      ~GlyphOriginParser.read_int32
      ~GlyphOriginParser.read_int8
      ~GlyphOriginParser.read_str
      ~GlyphOriginParser.read_str_all
      ~GlyphOriginParser.read_str_with_len
      ~GlyphOriginParser.read_uint16
      ~GlyphOriginParser.read_uint32
      ~GlyphOriginParser.read_uint8
      ~GlyphOriginParser.read_value
   
   

   
   
   