vfbLib.compilers.numeric.DoubleCompiler
=======================================

.. currentmodule:: vfbLib.compilers.numeric

.. autoclass:: DoubleCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DoubleCompiler.__init__
      ~DoubleCompiler.compile
      ~DoubleCompiler.compile_hex
      ~DoubleCompiler.merge
      ~DoubleCompiler.write_bytes
      ~DoubleCompiler.write_double
      ~DoubleCompiler.write_doubles
      ~DoubleCompiler.write_int16
      ~DoubleCompiler.write_int32
      ~DoubleCompiler.write_str
      ~DoubleCompiler.write_str_with_len
      ~DoubleCompiler.write_uint16
      ~DoubleCompiler.write_uint32
      ~DoubleCompiler.write_uint8
      ~DoubleCompiler.write_value
   
   

   
   
   