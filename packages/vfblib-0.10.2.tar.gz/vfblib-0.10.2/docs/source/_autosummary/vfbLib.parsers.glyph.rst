vfbLib.parsers.glyph
====================

.. automodule:: vfbLib.parsers.glyph
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      read_absolute_point
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      GlobalMaskParser
      GlyphAnchorsParser
      GlyphAnchorsSuppParser
      GlyphGDEFParser
      GlyphOriginParser
      GlyphParser
      GlyphSketchParser
      GlyphUnicodeParser
      GlyphUnicodeSuppParser
      LinkParser
      MaskMetricsMMParser
      MaskMetricsParser
      MaskParser
      PathCommand
   
   

   
   
   



