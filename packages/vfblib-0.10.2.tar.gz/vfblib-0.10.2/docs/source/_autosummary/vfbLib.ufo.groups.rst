vfbLib.ufo.groups
=================

.. automodule:: vfbLib.ufo.groups
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      build_glyph_to_group_maps
      rebuild_kerning_groups
      transform_groups
   
   

   
   
   

   
   
   



