vfbLib.ufo.glyph
================

.. automodule:: vfbLib.ufo.glyph
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      IndexVfbToUfoGlyph
      VfbToUfoGlyph
   
   

   
   
   



