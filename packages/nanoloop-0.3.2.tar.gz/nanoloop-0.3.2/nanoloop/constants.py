ref_mutations = {
  'CtoA': 0,
  'CtoG': 0,
  'CtoT': 0,
  'CtoN': 0,
  'AtoC': 0,
  'AtoG': 0,
  'AtoT': 0,
  'AtoN': 0,
  'GtoC': 0,
  'GtoA': 0,
  'GtoT': 0,
  'GtoN': 0,
  'TtoC': 0,
  'TtoA': 0,
  'TtoG': 0,
  'TtoN': 0
}