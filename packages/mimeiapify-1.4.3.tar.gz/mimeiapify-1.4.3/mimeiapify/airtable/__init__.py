# airtable/__init__.py

from .airtable import Airtable
from .airtable_async import AirtableAsync

__all__ = ["Airtable", "AirtableAsync"] 