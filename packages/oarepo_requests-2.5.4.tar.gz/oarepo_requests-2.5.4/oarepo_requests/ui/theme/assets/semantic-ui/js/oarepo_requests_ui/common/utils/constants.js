export const MAX_COMMENT_LENGTH = 1000;
