"""
Test package for Firestore schema core functionality.
"""
