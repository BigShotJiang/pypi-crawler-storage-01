# Usage

To use EthoPy in a project:

```
import ethopy
```
