# Visualizations

## Basic Visualizations

### Session Performace

### Licks

## Across many sessions

### Performance per day

## Real time plots

