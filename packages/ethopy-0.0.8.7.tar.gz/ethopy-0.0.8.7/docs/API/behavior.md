# Core Behavior module

::: ethopy.core.behavior