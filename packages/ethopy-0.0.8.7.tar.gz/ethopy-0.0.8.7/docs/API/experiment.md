# Core Experiment module

::: ethopy.core.experiment