"""Init core for ethopy."""
