# -*- coding: utf-8 -*-
from .aws_secret_key import AwsSecretKey
