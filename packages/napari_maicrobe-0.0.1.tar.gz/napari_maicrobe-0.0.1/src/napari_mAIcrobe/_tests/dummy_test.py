def test():
    pass