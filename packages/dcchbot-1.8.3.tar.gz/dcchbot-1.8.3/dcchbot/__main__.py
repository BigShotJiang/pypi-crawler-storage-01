from .main import run

run()