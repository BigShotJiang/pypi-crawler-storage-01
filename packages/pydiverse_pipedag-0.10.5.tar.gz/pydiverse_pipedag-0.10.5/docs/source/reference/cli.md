# Command Line Utility

Pipedag comes with a command line utility called `pipedag-manage` to help with some common pipedag related management operations.
These are all the available commands:

```{eval-rst}
.. click:: pydiverse.pipedag.management.cli:cli
   :prog: pipedag-manage
   :nested: full
```
