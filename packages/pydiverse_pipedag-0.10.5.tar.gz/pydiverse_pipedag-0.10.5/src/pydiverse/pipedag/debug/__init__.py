# Copyright (c) QuantCo and pydiverse contributors 2025-2025
# SPDX-License-Identifier: BSD-3-Clause

from pydiverse.pipedag.materialize.debug import materialize_table

__all__ = ["materialize_table"]
