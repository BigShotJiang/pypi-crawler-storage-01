def testfunction():
    print("hello from src/aiway/test.py")