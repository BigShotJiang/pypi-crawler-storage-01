def function():
    print("hello from src/aiway/__init__.py")