# Changelog

All notable changes to this project will be documented in this file.

## [0.13.1](https://github.com/s0undt3ch/refine/releases/tag/0.13.1) - 2025-07-29

### 🐛 Bug Fixes

- *(cli)* Allow overriding ``process_pool_size`` from the CLI.

