class MyEnum(StrEnum):
    one = "one"
