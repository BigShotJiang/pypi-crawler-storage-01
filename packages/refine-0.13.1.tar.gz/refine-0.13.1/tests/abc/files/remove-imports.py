from strenum import StrEnum
import logging

class MyEnum(StrEnum):
    one = "one"
