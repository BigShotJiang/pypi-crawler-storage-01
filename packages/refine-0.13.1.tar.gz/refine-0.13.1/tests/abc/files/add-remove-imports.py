from datetime import datetime, timedelta
import enum
import logging


class MyEnum(StrEnum):
    one = "one"
