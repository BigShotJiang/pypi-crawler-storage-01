from enum import StrEnum

class MyEnum(StrEnum):
    one = "one"
