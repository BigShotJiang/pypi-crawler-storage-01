from strenum import StrEnum

class MyEnum(StrEnum):
    one = "one"
