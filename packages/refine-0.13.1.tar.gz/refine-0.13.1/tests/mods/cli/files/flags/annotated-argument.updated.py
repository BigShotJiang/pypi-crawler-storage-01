from argparse import ArgumentParser


def main() -> None:
    parser: ArgumentParser = ArgumentParser()
    parser.add_argument("--company-id", type=int, required=True)
    parser.add_argument(
        "--customer-ids",
        type=str,
        nargs="+",
        help="A space-separated list of customer IDs",
    )
    parser.add_argument(
        "--emails",
        type=str,
        nargs="+",
        help="A space-separated list of email addresses",
    )


if __name__ == "__main__":
    main()
