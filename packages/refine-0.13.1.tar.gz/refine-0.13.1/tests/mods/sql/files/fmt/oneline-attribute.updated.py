foo = "select foo from bar"
