foo = "SELECT foo FROM bar"
