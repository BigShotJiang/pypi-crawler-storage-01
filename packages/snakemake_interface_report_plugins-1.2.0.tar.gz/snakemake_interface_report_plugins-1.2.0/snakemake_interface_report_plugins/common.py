__author__ = "Johannes Köster"
__copyright__ = "Copyright 2024, Johannes Köster"
__email__ = "johannes.koester@uni-due.de"
__license__ = "MIT"


report_plugin_prefix = "snakemake-report-plugin-"
report_plugin_module_prefix = report_plugin_prefix.replace("-", "_")
