from .async_ import _FetchObjectsByIDsGenerateAsync
from .sync import _FetchObjectsByIDsGenerate

__all__ = [
    "_FetchObjectsByIDsGenerate",
    "_FetchObjectsByIDsGenerateAsync",
]
