.. include:: references.txt

.. _util:

*****************************
Misc. Utilities (`gala.util`)
*****************************

Introduction
============

This subpackage contains miscellaneous utilities.

.. _util-api:

API
===

.. automodapi:: gala.util
    :no-inheritance-diagram:
