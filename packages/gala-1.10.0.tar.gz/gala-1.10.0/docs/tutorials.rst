.. _gala-tutorials:

*********
Tutorials
*********

The tutorials listed below are meant to be step-by-step demonstrations of common
functionality in `gala`. If you are interested in contributing a tutorial, or
requesting a tutorial about material that is not covered here, please `open an
issue on GitHub <https://github.com/adrn/gala/issues>`_.

.. The _tutorials.rst file is auto-generated in conf.py. Add new tutorials to
.. the list of files in conf.py

.. include:: _tutorials.rst
