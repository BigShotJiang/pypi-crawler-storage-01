*********************
Major Release History
*********************

.. toctree::
   :maxdepth: 1

   1.0
