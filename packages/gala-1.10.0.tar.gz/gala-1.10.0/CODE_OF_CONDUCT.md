All `gala` community members are expected to abide by the
[Astropy Project Code of Conduct](http://www.astropy.org/code_of_conduct.html).
