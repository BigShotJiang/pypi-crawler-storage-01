"""
Gala.
"""

import sys

__author__ = "adrn <adrianmpw@gmail.com>"

from ._version import version as __version__
