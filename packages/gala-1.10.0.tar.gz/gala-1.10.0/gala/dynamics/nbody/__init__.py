from .core import DirectNBody
