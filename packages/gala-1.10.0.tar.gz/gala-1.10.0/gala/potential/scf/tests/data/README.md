Note: the data in here was generated using the scripts in
https://github.com/adrn/biff
