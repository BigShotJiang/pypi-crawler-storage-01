from .frames import ConstantRotatingFrame, StaticFrame
