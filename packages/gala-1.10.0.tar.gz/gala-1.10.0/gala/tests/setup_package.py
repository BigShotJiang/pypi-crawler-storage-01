def get_package_data():
    return {"gala.tests": ["coveragerc"]}
