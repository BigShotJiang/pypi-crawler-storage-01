from solaredge2mqtt.services.events import ComponentsEvent


class PowerflowGeneratedEvent(ComponentsEvent):
    pass
