from solaredge2mqtt.core.events.events import BaseEvent


class IntervalBaseTriggerEvent(BaseEvent):
    pass


class Interval1MinTriggerEvent(BaseEvent):
    pass


class Interval5MinTriggerEvent(BaseEvent):
    pass


class Interval10MinTriggerEvent(BaseEvent):
    pass


class Interval15MinTriggerEvent(BaseEvent):
    pass
