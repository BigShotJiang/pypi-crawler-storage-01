"""Folder containing i18n translations bundles.

This file exists to help pkgutil find the i18n data. There is no actual
python code in this package.
"""
#
# (C) Pywikibot team, 2011-2023
#
# Distributed under the terms of the MIT license.
#
# Translations by translators are licensed CC BY 3.0
#
