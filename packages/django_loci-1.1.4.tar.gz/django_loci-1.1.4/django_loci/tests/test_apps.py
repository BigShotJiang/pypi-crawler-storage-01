from django.test import TestCase

from .base.test_apps import BaseTestApps


class TestApps(BaseTestApps, TestCase):
    pass
