# LICENSE

    Copyright(C) Mad IT House (Pvt) Ltd.
    All rights reserved.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.

## Legal

This code is the property of Mad IT House (Pvt) Ltd.

- You are not allowed to use this code without prior written permissions from the owner.
- You may update this code at any time as per your requirements, but not without written permission from the owner.
- You must attribute the owner of this code even after you have written permission to use the code, unless you have written permission not to do so.
