# LlamaIndex Index_Store Integration: Azure CosmosDB NoSQL Index Store
