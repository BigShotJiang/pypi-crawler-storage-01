"""
IOWarp Agents CLI - Beautiful command-line interface for managing scientific AI agents
"""

__version__ = "0.1.0"
__author__ = "IOWarp Team"
__email__ = "team@iowarp.com"