#!/bin/bash

docker build $@ -t dtt-build:deb dttbuild_debian