You need to run onetime_auth.py to create user_external with token on the first time

https://developers.google.com/assistant/identity/google-sign-in-oauth

https://developers.google.com/identity/openid-connect/openid-connect#python
