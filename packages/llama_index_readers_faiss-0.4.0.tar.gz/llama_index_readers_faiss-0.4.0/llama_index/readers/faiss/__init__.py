from llama_index.readers.faiss.base import FaissReader

__all__ = ["FaissReader"]
