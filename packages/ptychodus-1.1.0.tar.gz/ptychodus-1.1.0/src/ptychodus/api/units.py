from typing import Final

BYTES_PER_MEGABYTE: Final[int] = 1000 * 1000
