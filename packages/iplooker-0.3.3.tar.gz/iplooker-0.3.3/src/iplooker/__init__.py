from __future__ import annotations

from .ip_looker import IPLooker
from .ip_looker import IPLooker as IPLookup
