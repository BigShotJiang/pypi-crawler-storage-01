"""
Main entry point for browser_copilot module
"""

from .cli import main

if __name__ == "__main__":
    main()
