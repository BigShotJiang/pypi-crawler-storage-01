from llama_index.embeddings.openvino_genai.base import (
    OpenVINOGENAIEmbedding,
)

__all__ = ["OpenVINOGENAIEmbedding"]
