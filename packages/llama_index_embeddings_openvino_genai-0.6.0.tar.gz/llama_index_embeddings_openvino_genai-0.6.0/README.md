# LlamaIndex Embeddings Integration: OpenVINO GenAI
