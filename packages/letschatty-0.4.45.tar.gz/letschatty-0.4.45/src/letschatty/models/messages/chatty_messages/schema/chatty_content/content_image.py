from .content_media import ChattyContentMedia

class ChattyContentImage(ChattyContentMedia):
    pass
