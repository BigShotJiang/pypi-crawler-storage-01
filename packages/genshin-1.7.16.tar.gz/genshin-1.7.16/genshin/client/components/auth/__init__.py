"""Auth-related utility.

Credits to:
- JokelBaf - https://github.com/jokelbaf
- Seria - https://github.com/seriaati
- M-307 - https://github.com/mrwan200
- gsuid_core - https://github.com/Genshin-bots/gsuid_core
"""

from .client import *
