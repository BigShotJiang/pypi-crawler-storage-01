"""Components of a client organized by endpoint.

Abuses inheritance because it can.
"""
