"""API models."""

from .auth import *
from .genshin import *
from .honkai import *
from .hoyolab import *
from .model import *
from .starrail import *
from .zzz import *
