"""Fancy paginators with a large amount of useful methods."""

from .api import *
from .base import *
