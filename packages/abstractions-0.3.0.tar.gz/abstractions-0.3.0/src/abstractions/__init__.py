def main() -> None:
    print("Hello from abstractions!")
