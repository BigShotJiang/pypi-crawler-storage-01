name = "cdoctest"

from .c_doctest import CDocTest
from .cmake_api import CMakeApi
