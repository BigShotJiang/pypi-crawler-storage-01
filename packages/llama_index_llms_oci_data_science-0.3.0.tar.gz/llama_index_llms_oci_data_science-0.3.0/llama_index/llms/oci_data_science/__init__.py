from llama_index.llms.oci_data_science.base import OCIDataScience


__all__ = ["OCIDataScience"]
