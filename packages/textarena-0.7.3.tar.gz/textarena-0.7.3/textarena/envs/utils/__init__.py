import textarena.envs.utils.jury 
import textarena.envs.utils.word_lists