# NL-to-SQL-Evaluator

👷🏼‍♂️ Work in progress 