import { s as J, b as pe } from "./index-CpVxDhhD.js";
import { m as he, c as m, p as Z } from "./index-CqUzoIk5.js";
import { c as fe, E as de, S as ge } from "./index-DPVDNjDQ.js";
import { p as me } from "./index-dR6aK-GC.js";
import { w as ye } from "./index-qIqGBAea.js";
import { v as C } from "./index-MxBukWlM.js";
import { t as be } from "./index-Dzq2w4iB.js";
function we(e) {
  return function(t) {
    he(t, e);
  };
}
function xe(e, t) {
  const n = t.properties || {}, r = (
    /** @type {Array<PhrasingContent>} */
    e.all(t)
  ), l = {
    type: "link",
    url: e.resolve(String(n.href || "") || null),
    title: n.title ? String(n.title) : null,
    children: r
  };
  return e.patch(t, l), l;
}
function ve(e, t) {
  e.baseFound || (e.frozenBaseUrl = String(t.properties && t.properties.href || "") || void 0, e.baseFound = !0);
}
function Se(e, t) {
  const n = { type: "blockquote", children: e.toFlow(e.all(t)) };
  return e.patch(t, n), n;
}
function ke(e, t) {
  const n = { type: "break" };
  return e.patch(t, n), n;
}
const $ = (
  // Note: overloads like this are needed to support optional generics.
  /**
   * @type {(
   *   (<Kind extends UnistParent, Check extends Test>(parent: Kind, index: Child<Kind> | number, test: Check) => Matches<Child<Kind>, Check> | undefined) &
   *   (<Kind extends UnistParent>(parent: Kind, index: Child<Kind> | number, test?: null | undefined) => Child<Kind> | undefined)
   * )}
   */
  /**
   * @param {UnistParent} parent
   * @param {UnistNode | number} index
   * @param {Test} [test]
   * @returns {UnistNode | undefined}
   */
  function(e, t, n) {
    const r = fe(n);
    if (!e || !e.type || !e.children)
      throw new Error("Expected parent node");
    if (typeof t == "number") {
      if (t < 0 || t === Number.POSITIVE_INFINITY)
        throw new Error("Expected positive finite number as index");
    } else if (t = e.children.indexOf(t), t < 0)
      throw new Error("Expected child node or index");
    for (; ++t < e.children.length; )
      if (r(e.children[t], t, e))
        return e.children[t];
  }
), P = /\n/g, j = /[\t ]+/g, U = m("br"), H = m(qe), Ne = m("p"), W = m("tr"), Ce = m([
  // List from: <https://html.spec.whatwg.org/multipage/rendering.html#hidden-elements>
  "datalist",
  "head",
  "noembed",
  "noframes",
  "noscript",
  // Act as if we support scripting.
  "rp",
  "script",
  "style",
  "template",
  "title",
  // Hidden attribute.
  Be,
  // From: <https://html.spec.whatwg.org/multipage/rendering.html#flow-content-3>
  Me
]), ee = m([
  "address",
  // Flow content
  "article",
  // Sections and headings
  "aside",
  // Sections and headings
  "blockquote",
  // Flow content
  "body",
  // Page
  "caption",
  // `table-caption`
  "center",
  // Flow content (legacy)
  "dd",
  // Lists
  "dialog",
  // Flow content
  "dir",
  // Lists (legacy)
  "dl",
  // Lists
  "dt",
  // Lists
  "div",
  // Flow content
  "figure",
  // Flow content
  "figcaption",
  // Flow content
  "footer",
  // Flow content
  "form,",
  // Flow content
  "h1",
  // Sections and headings
  "h2",
  // Sections and headings
  "h3",
  // Sections and headings
  "h4",
  // Sections and headings
  "h5",
  // Sections and headings
  "h6",
  // Sections and headings
  "header",
  // Flow content
  "hgroup",
  // Sections and headings
  "hr",
  // Flow content
  "html",
  // Page
  "legend",
  // Flow content
  "li",
  // Lists (as `display: list-item`)
  "listing",
  // Flow content (legacy)
  "main",
  // Flow content
  "menu",
  // Lists
  "nav",
  // Sections and headings
  "ol",
  // Lists
  "p",
  // Flow content
  "plaintext",
  // Flow content (legacy)
  "pre",
  // Flow content
  "section",
  // Sections and headings
  "ul",
  // Lists
  "xmp"
  // Flow content (legacy)
]);
function v(e, t) {
  const n = {}, r = "children" in e ? e.children : [], l = ee(e), i = re(e, {
    whitespace: n.whitespace || "normal"
  }), c = [];
  (e.type === "text" || e.type === "comment") && c.push(
    ...ne(e, {
      breakBefore: !0,
      breakAfter: !0
    })
  );
  let s = -1;
  for (; ++s < r.length; )
    c.push(
      ...te(
        r[s],
        // @ts-expect-error: `tree` is a parent if we’re here.
        e,
        {
          whitespace: i,
          breakBefore: s ? void 0 : l,
          breakAfter: s < r.length - 1 ? U(r[s + 1]) : l
        }
      )
    );
  const o = [];
  let a;
  for (s = -1; ++s < c.length; ) {
    const u = c[s];
    typeof u == "number" ? a !== void 0 && u > a && (a = u) : u && (a !== void 0 && a > -1 && o.push(`
`.repeat(a) || " "), a = -1, o.push(u));
  }
  return o.join("");
}
function te(e, t, n) {
  return e.type === "element" ? Ie(e, t, n) : e.type === "text" ? n.whitespace === "normal" ? ne(e, n) : Te(e) : [];
}
function Ie(e, t, n) {
  const r = re(e, n), l = e.children || [];
  let i = -1, c = [];
  if (Ce(e))
    return c;
  let s, o;
  for (U(e) || W(e) && // @ts-expect-error: something up with types of parents.
  $(t, e, W) ? o = `
` : Ne(e) ? (s = 2, o = 2) : ee(e) && (s = 1, o = 1); ++i < l.length; )
    c = c.concat(
      te(l[i], e, {
        whitespace: r,
        breakBefore: i ? void 0 : s,
        breakAfter: i < l.length - 1 ? U(l[i + 1]) : o
      })
    );
  return H(e) && // @ts-expect-error: something up with types of parents.
  $(t, e, H) && c.push("	"), s && c.unshift(s), o && c.push(o), c;
}
function ne(e, t) {
  const n = String(e.value), r = [], l = [];
  let i = 0;
  for (; i <= n.length; ) {
    P.lastIndex = i;
    const o = P.exec(n), a = o && "index" in o ? o.index : n.length;
    r.push(
      // Any sequence of collapsible spaces and tabs immediately preceding or
      // following a segment break is removed.
      Ae(
        // […] ignoring bidi formatting characters (characters with the
        // Bidi_Control property [UAX9]: ALM, LTR, RTL, LRE-RLO, LRI-PDI) as if
        // they were not there.
        n.slice(i, a).replace(/[\u061C\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, ""),
        i === 0 ? t.breakBefore : !0,
        a === n.length ? t.breakAfter : !0
      )
    ), i = a + 1;
  }
  let c = -1, s;
  for (; ++c < r.length; )
    r[c].charCodeAt(r[c].length - 1) === 8203 || c < r.length - 1 && r[c + 1].charCodeAt(0) === 8203 ? (l.push(r[c]), s = void 0) : r[c] ? (typeof s == "number" && l.push(s), l.push(r[c]), s = 0) : (c === 0 || c === r.length - 1) && l.push(0);
  return l;
}
function Te(e) {
  return [String(e.value)];
}
function Ae(e, t, n) {
  const r = [];
  let l = 0, i;
  for (; l < e.length; ) {
    j.lastIndex = l;
    const c = j.exec(e);
    i = c ? c.index : e.length, !l && !i && c && !t && r.push(""), l !== i && r.push(e.slice(l, i)), l = c ? i + c[0].length : i;
  }
  return l !== i && !n && r.push(""), r.join(" ");
}
function re(e, t) {
  if (e.type === "element") {
    const n = e.properties || {};
    switch (e.tagName) {
      case "listing":
      case "plaintext":
      case "xmp":
        return "pre";
      case "nobr":
        return "nowrap";
      case "pre":
        return n.wrap ? "pre-wrap" : "pre";
      case "td":
      case "th":
        return n.noWrap ? "nowrap" : t.whitespace;
      case "textarea":
        return "pre-wrap";
    }
  }
  return t.whitespace;
}
function Be(e) {
  return !!(e.properties || {}).hidden;
}
function qe(e) {
  return e.tagName === "td" || e.tagName === "th";
}
function Me(e) {
  return e.tagName === "dialog" && !(e.properties || {}).open;
}
function Ee(e) {
  const t = String(e);
  let n = t.length;
  for (; n > 0; ) {
    const r = t.codePointAt(n - 1);
    if (r !== void 0 && (r === 10 || r === 13))
      n--;
    else
      break;
  }
  return t.slice(0, n);
}
const A = "language-";
function k(e, t) {
  const n = t.children;
  let r = -1, l, i;
  if (t.tagName === "pre")
    for (; ++r < n.length; ) {
      const s = n[r];
      if (s.type === "element" && s.tagName === "code" && s.properties && s.properties.className && Array.isArray(s.properties.className)) {
        l = s.properties.className;
        break;
      }
    }
  if (l) {
    for (r = -1; ++r < l.length; )
      if (String(l[r]).slice(0, A.length) === A) {
        i = String(l[r]).slice(A.length);
        break;
      }
  }
  const c = {
    type: "code",
    lang: i || null,
    meta: null,
    value: Ee(v(t))
  };
  return e.patch(t, c), c;
}
function Ue(e, t) {
  const n = {
    type: "html",
    value: "<!--" + t.value + "-->"
  };
  return e.patch(t, n), n;
}
function B(e, t) {
  const r = { type: "delete", children: (
    /** @type {Array<PhrasingContent>} */
    e.all(t)
  ) };
  return e.patch(t, r), r;
}
function F(e) {
  let t = -1;
  if (e.length > 1) {
    for (; ++t < e.length; )
      if (e[t].spread)
        return !0;
  }
  return !1;
}
function Fe(e, t) {
  const n = [], r = [];
  let l = -1;
  for (; ++l < t.children.length; ) {
    const s = t.children[l];
    s.type === "element" && s.tagName === "div" ? n.push(...s.children) : n.push(s);
  }
  let i = { definitions: [], titles: [] };
  for (l = -1; ++l < n.length; ) {
    const s = n[l];
    if (s.type === "element" && s.tagName === "dt") {
      const o = n[l - 1];
      o && o.type === "element" && o.tagName === "dd" && (r.push(i), i = { definitions: [], titles: [] }), i.titles.push(s);
    } else
      i.definitions.push(s);
  }
  r.push(i), l = -1;
  const c = [];
  for (; ++l < r.length; ) {
    const s = [
      ...z(e, r[l].titles),
      ...z(e, r[l].definitions)
    ];
    s.length > 0 && c.push({
      type: "listItem",
      spread: s.length > 1,
      checked: null,
      children: s
    });
  }
  if (c.length > 0) {
    const s = {
      type: "list",
      ordered: !1,
      start: null,
      spread: F(c),
      children: c
    };
    return e.patch(t, s), s;
  }
}
function z(e, t) {
  const n = e.all({ type: "root", children: t }), r = e.toSpecificContent(n, Re);
  return r.length === 0 ? [] : r.length === 1 ? r[0].children : [
    {
      type: "list",
      ordered: !1,
      start: null,
      spread: F(r),
      children: r
    }
  ];
}
function Re() {
  return { type: "listItem", spread: !1, checked: null, children: [] };
}
function N(e, t) {
  const r = { type: "emphasis", children: (
    /** @type {Array<PhrasingContent>} */
    e.all(t)
  ) };
  return e.patch(t, r), r;
}
function R(e) {
  let t = 0, n = e.length;
  for (; t < n && e[t].type === "break"; ) t++;
  for (; n > t && e[n - 1].type === "break"; ) n--;
  return t === 0 && n === e.length ? e : e.slice(t, n);
}
function g(e, t) {
  const n = (
    /** @type {Heading['depth']} */
    /* c8 ignore next */
    Number(t.tagName.charAt(1)) || 1
  ), r = R(
    /** @type {Array<PhrasingContent>} */
    e.all(t)
  ), l = { type: "heading", depth: n, children: r };
  return e.patch(t, l), l;
}
function Oe(e, t) {
  const n = { type: "thematicBreak" };
  return e.patch(t, n), n;
}
function $e(e, t) {
  const n = t.properties || {}, r = String(n.src || ""), l = String(n.title || "");
  if (r && l) {
    const i = {
      type: "link",
      title: null,
      url: e.resolve(r),
      children: [{ type: "text", value: l }]
    };
    return e.patch(t, i), i;
  }
}
function L(e, t) {
  const n = t.properties || {}, r = {
    type: "image",
    url: e.resolve(String(n.src || "") || null),
    title: n.title ? String(n.title) : null,
    alt: n.alt ? String(n.alt) : ""
  };
  return e.patch(t, r), r;
}
function x(e, t) {
  const n = { type: "inlineCode", value: v(t) };
  return e.patch(t, n), n;
}
function le(e, t) {
  const n = [], r = [], l = t || e.properties || {}, i = ie(e), c = Math.min(Number.parseInt(String(l.size), 10), 0) || (l.multiple ? 4 : 1);
  let s = -1;
  for (; ++s < i.length; ) {
    const u = i[s];
    u && u.properties && u.properties.selected && n.push(u);
  }
  const o = n.length > 0 ? n : i, a = Math.min(o.length, c);
  for (s = -1; ++s < a; ) {
    const u = o[s], f = u.properties || {}, y = v(u), b = y || String(f.label || ""), w = String(f.value || "") || y;
    r.push([w, b === w ? void 0 : b]);
  }
  return r;
}
function ie(e) {
  const t = [];
  let n = -1;
  for (; ++n < e.children.length; ) {
    const r = e.children[n];
    "children" in r && Array.isArray(r.children) && t.push(...ie(r)), r.type === "element" && r.tagName === "option" && (!r.properties || !r.properties.disabled) && t.push(r);
  }
  return t;
}
const Pe = "[x]", je = "[ ]";
function He(e, t) {
  const n = t.properties || {}, r = String(n.value || n.placeholder || "");
  if (n.disabled || n.type === "hidden" || n.type === "file")
    return;
  if (n.type === "checkbox" || n.type === "radio") {
    const o = {
      type: "text",
      value: n.checked ? e.options.checked || Pe : e.options.unchecked || je
    };
    return e.patch(t, o), o;
  }
  if (n.type === "image") {
    const o = n.alt || r;
    if (o) {
      const a = {
        type: "image",
        url: e.resolve(String(n.src || "") || null),
        title: String(n.title || "") || null,
        alt: String(o)
      };
      return e.patch(t, a), a;
    }
    return;
  }
  let l = [];
  if (r)
    l = [[r, void 0]];
  else if (
    // `list` is not supported on these types:
    n.type !== "button" && n.type !== "file" && n.type !== "password" && n.type !== "reset" && n.type !== "submit" && n.list
  ) {
    const o = String(n.list), a = e.elementById.get(o);
    a && a.tagName === "datalist" && (l = le(a, n));
  }
  if (l.length === 0)
    return;
  if (n.type === "password" && (l[0] = ["•".repeat(l[0][0].length), void 0]), n.type === "email" || n.type === "url") {
    const o = [];
    let a = -1;
    for (; ++a < l.length; ) {
      const u = e.resolve(l[a][0]), f = {
        type: "link",
        title: null,
        url: n.type === "email" ? "mailto:" + u : u,
        children: [{ type: "text", value: l[a][1] || u }]
      };
      o.push(f), a !== l.length - 1 && o.push({ type: "text", value: ", " });
    }
    return o;
  }
  const i = [];
  let c = -1;
  for (; ++c < l.length; )
    i.push(
      l[c][1] ? l[c][1] + " (" + l[c][0] + ")" : l[c][0]
    );
  const s = { type: "text", value: i.join(", ") };
  return e.patch(t, s), s;
}
function q(e, t) {
  const { rest: n, checkbox: r } = ce(t), l = r ? !!r.properties.checked : null, i = se(n), c = e.toFlow(e.all(n)), s = { type: "listItem", spread: i, checked: l, children: c };
  return e.patch(t, s), s;
}
function se(e) {
  let t = -1, n = !1;
  for (; ++t < e.children.length; ) {
    const r = e.children[t];
    if (r.type === "element") {
      if (Z(r)) continue;
      if (r.tagName === "p" || n || se(r))
        return !0;
      n = !0;
    }
  }
  return !1;
}
function ce(e) {
  const t = e.children[0];
  if (t && t.type === "element" && t.tagName === "input" && t.properties && (t.properties.type === "checkbox" || t.properties.type === "radio")) {
    const n = { ...e, children: e.children.slice(1) };
    return { checkbox: t, rest: n };
  }
  if (t && t.type === "element" && t.tagName === "p") {
    const { checkbox: n, rest: r } = ce(t);
    if (n) {
      const l = { ...e, children: [r, ...e.children.slice(1)] };
      return { checkbox: n, rest: l };
    }
  }
  return { checkbox: void 0, rest: e };
}
function M(e, t) {
  const n = t.tagName === "ol", r = e.toSpecificContent(e.all(t), We);
  let l = null;
  n && (l = t.properties && t.properties.start ? Number.parseInt(String(t.properties.start), 10) : 1);
  const i = {
    type: "list",
    ordered: n,
    start: l,
    spread: F(r),
    children: r
  };
  return e.patch(t, i), i;
}
function We() {
  return { type: "listItem", spread: !1, checked: null, children: [] };
}
function I(e) {
  let t = -1;
  for (; ++t < e.length; ) {
    const n = e[t];
    if (!ue(n) || "children" in n && I(n.children))
      return !0;
  }
  return !1;
}
function oe(e) {
  return ae(e, t, function(n) {
    return n;
  });
  function t(n) {
    return n.every(function(r) {
      return r.type === "text" ? ye(r.value) : !1;
    }) ? [] : [{ type: "paragraph", children: R(n) }];
  }
}
function ze(e) {
  return ae(e.children, t, n);
  function t(r) {
    const l = E(e);
    return l.children = r, [l];
  }
  function n(r) {
    if ("children" in r && "children" in e) {
      const l = E(e), i = E(r);
      return l.children = r.children, i.children.push(l), i;
    }
    return { ...r };
  }
}
function ae(e, t, n) {
  const r = Le(e), l = [];
  let i = [], c = -1;
  for (; ++c < r.length; ) {
    const s = r[c];
    ue(s) ? i.push(s) : (i.length > 0 && (l.push(...t(i)), i = []), l.push(n(s)));
  }
  return i.length > 0 && (l.push(...t(i)), i = []), l;
}
function Le(e) {
  const t = [];
  let n = -1;
  for (; ++n < e.length; ) {
    const r = e[n];
    (r.type === "delete" || r.type === "link") && I(r.children) ? t.push(...ze(r)) : t.push(r);
  }
  return t;
}
function ue(e) {
  const t = e.data && e.data.hName;
  return t ? Z({ type: "element", tagName: t, properties: {}, children: [] }) : me(e);
}
function E(e) {
  return J({ ...e, children: [] });
}
function _(e, t) {
  const n = t.properties || {}, r = t.tagName === "video" ? String(n.poster || "") : "";
  let l = String(n.src || ""), i = -1, c = !1, s = e.all(t);
  if (C({ type: "root", children: s }, function(f) {
    if (f.type === "link")
      return c = !0, de;
  }), c || I(s))
    return s;
  for (; !l && ++i < t.children.length; ) {
    const f = t.children[i];
    f.type === "element" && f.tagName === "source" && f.properties && (l = String(f.properties.src || ""));
  }
  if (r) {
    const f = {
      type: "image",
      title: null,
      url: e.resolve(r),
      alt: be(s)
    };
    e.patch(t, f), s = [f];
  }
  const a = (
    /** @type {Array<PhrasingContent>} */
    s
  ), u = {
    type: "link",
    title: n.title ? String(n.title) : null,
    url: e.resolve(l),
    children: a
  };
  return e.patch(t, u), u;
}
function D(e, t) {
  const n = R(
    // Allow potentially “invalid” nodes, they might be unknown.
    // We also support straddling later.
    /** @type {Array<PhrasingContent>} */
    e.all(t)
  );
  if (n.length > 0) {
    const r = { type: "paragraph", children: n };
    return e.patch(t, r), r;
  }
}
const _e = ['"'];
function De(e, t) {
  const n = e.options.quotes || _e;
  e.qNesting++;
  const r = e.all(t);
  e.qNesting--;
  const l = n[e.qNesting % n.length], i = r[0], c = r[r.length - 1], s = l.charAt(0), o = l.length > 1 ? l.charAt(1) : l;
  return i && i.type === "text" ? i.value = s + i.value : r.unshift({ type: "text", value: s }), c && c.type === "text" ? c.value += o : r.push({ type: "text", value: o }), r;
}
function Ke(e, t) {
  let n = e.all(t);
  (e.options.document || I(n)) && (n = oe(n));
  const r = { type: "root", children: n };
  return e.patch(t, r), r;
}
function Qe(e, t) {
  const n = le(t);
  let r = -1;
  const l = [];
  for (; ++r < n.length; ) {
    const i = n[r];
    l.push(i[1] ? i[1] + " (" + i[0] + ")" : i[0]);
  }
  if (l.length > 0) {
    const i = { type: "text", value: l.join(", ") };
    return e.patch(t, i), i;
  }
}
function K(e, t) {
  const r = { type: "strong", children: (
    /** @type {Array<PhrasingContent>} */
    e.all(t)
  ) };
  return e.patch(t, r), r;
}
function Q(e, t) {
  const r = { type: "tableCell", children: (
    /** @type {Array<PhrasingContent>} */
    e.all(t)
  ) };
  if (e.patch(t, r), t.properties) {
    const l = t.properties.rowSpan, i = t.properties.colSpan;
    if (l || i) {
      const c = (
        /** @type {Record<string, unknown>} */
        r.data || (r.data = {})
      );
      l && (c.hastUtilToMdastTemporaryRowSpan = l), i && (c.hastUtilToMdastTemporaryColSpan = i);
    }
  }
  return r;
}
function Ve(e, t) {
  const r = { type: "tableRow", children: e.toSpecificContent(e.all(t), Xe) };
  return e.patch(t, r), r;
}
function Xe() {
  return { type: "tableCell", children: [] };
}
function Ye(e, t) {
  if (e.inTable) {
    const a = { type: "text", value: v(t) };
    return e.patch(t, a), a;
  }
  e.inTable = !0;
  const { align: n, headless: r } = Ge(t), l = e.toSpecificContent(e.all(t), V);
  r && l.unshift(V());
  let i = -1;
  for (; ++i < l.length; ) {
    const a = l[i], u = e.toSpecificContent(a.children, Je);
    a.children = u;
  }
  let c = 1;
  for (i = -1; ++i < l.length; ) {
    const a = l[i].children;
    let u = -1;
    for (; ++u < a.length; ) {
      const f = a[u];
      if (f.data) {
        const y = (
          /** @type {Record<string, unknown>} */
          f.data
        ), b = Number.parseInt(String(y.hastUtilToMdastTemporaryColSpan), 10) || 1, w = Number.parseInt(String(y.hastUtilToMdastTemporaryRowSpan), 10) || 1;
        if (b > 1 || w > 1) {
          let S = i - 1;
          for (; ++S < i + w; ) {
            let T = u - 1;
            for (; ++T < u + b && l[S]; ) {
              const O = [];
              (S !== i || T !== u) && O.push({ type: "tableCell", children: [] }), l[S].children.splice(T, 0, ...O);
            }
          }
        }
        "hastUtilToMdastTemporaryColSpan" in f.data && delete f.data.hastUtilToMdastTemporaryColSpan, "hastUtilToMdastTemporaryRowSpan" in f.data && delete f.data.hastUtilToMdastTemporaryRowSpan, Object.keys(f.data).length === 0 && delete f.data;
      }
    }
    a.length > c && (c = a.length);
  }
  for (i = -1; ++i < l.length; ) {
    const a = l[i].children;
    let u = a.length - 1;
    for (; ++u < c; )
      a.push({ type: "tableCell", children: [] });
  }
  let s = n.length - 1;
  for (; ++s < c; )
    n.push(null);
  e.inTable = !1;
  const o = { type: "table", align: n, children: l };
  return e.patch(t, o), o;
}
function Ge(e) {
  const t = { align: [null], headless: !0 };
  let n = 0, r = 0;
  return C(e, function(l) {
    if (l.type === "element") {
      if (l.tagName === "table" && e !== l)
        return ge;
      if ((l.tagName === "th" || l.tagName === "td") && l.properties) {
        if (!t.align[r]) {
          const i = String(l.properties.align || "") || null;
          (i === "center" || i === "left" || i === "right" || i === null) && (t.align[r] = i);
        }
        t.headless && n < 2 && l.tagName === "th" && (t.headless = !1), r++;
      } else l.tagName === "thead" ? t.headless = !1 : l.tagName === "tr" && (n++, r = 0);
    }
  }), t;
}
function Je() {
  return { type: "tableCell", children: [] };
}
function V() {
  return { type: "tableRow", children: [] };
}
function Ze(e, t) {
  const n = { type: "text", value: t.value };
  return e.patch(t, n), n;
}
function et(e, t) {
  const n = { type: "text", value: v(t) };
  return e.patch(t, n), n;
}
function tt(e, t) {
  const n = { type: "text", value: "​" };
  return e.patch(t, n), n;
}
const nt = {
  comment: Ue,
  doctype: h,
  root: Ke,
  text: Ze
}, rt = {
  // Ignore:
  applet: h,
  area: h,
  basefont: h,
  bgsound: h,
  caption: h,
  col: h,
  colgroup: h,
  command: h,
  content: h,
  datalist: h,
  dialog: h,
  element: h,
  embed: h,
  frame: h,
  frameset: h,
  isindex: h,
  keygen: h,
  link: h,
  math: h,
  menu: h,
  menuitem: h,
  meta: h,
  nextid: h,
  noembed: h,
  noframes: h,
  optgroup: h,
  option: h,
  param: h,
  script: h,
  shadow: h,
  source: h,
  spacer: h,
  style: h,
  svg: h,
  template: h,
  title: h,
  track: h,
  // Use children:
  abbr: p,
  acronym: p,
  bdi: p,
  bdo: p,
  big: p,
  blink: p,
  button: p,
  canvas: p,
  cite: p,
  data: p,
  details: p,
  dfn: p,
  font: p,
  ins: p,
  label: p,
  map: p,
  marquee: p,
  meter: p,
  nobr: p,
  noscript: p,
  object: p,
  output: p,
  progress: p,
  rb: p,
  rbc: p,
  rp: p,
  rt: p,
  rtc: p,
  ruby: p,
  slot: p,
  small: p,
  span: p,
  sup: p,
  sub: p,
  tbody: p,
  tfoot: p,
  thead: p,
  time: p,
  // Use children as flow.
  address: d,
  article: d,
  aside: d,
  body: d,
  center: d,
  div: d,
  fieldset: d,
  figcaption: d,
  figure: d,
  form: d,
  footer: d,
  header: d,
  hgroup: d,
  html: d,
  legend: d,
  main: d,
  multicol: d,
  nav: d,
  picture: d,
  section: d,
  // Handle.
  a: xe,
  audio: _,
  b: K,
  base: ve,
  blockquote: Se,
  br: ke,
  code: x,
  dir: M,
  dl: Fe,
  dt: q,
  dd: q,
  del: B,
  em: N,
  h1: g,
  h2: g,
  h3: g,
  h4: g,
  h5: g,
  h6: g,
  hr: Oe,
  i: N,
  iframe: $e,
  img: L,
  image: L,
  input: He,
  kbd: x,
  li: q,
  listing: k,
  mark: N,
  ol: M,
  p: D,
  plaintext: k,
  pre: k,
  q: De,
  s: B,
  samp: x,
  select: Qe,
  strike: B,
  strong: K,
  summary: D,
  table: Ye,
  td: Q,
  textarea: et,
  th: Q,
  tr: Ve,
  tt: x,
  u: N,
  ul: M,
  var: x,
  video: _,
  wbr: tt,
  xmp: k
};
function p(e, t) {
  return e.all(t);
}
function d(e, t) {
  return e.toFlow(e.all(t));
}
function h() {
}
const X = {}.hasOwnProperty;
function lt(e) {
  return {
    all: it,
    baseFound: !1,
    elementById: /* @__PURE__ */ new Map(),
    frozenBaseUrl: void 0,
    handlers: { ...rt, ...e.handlers },
    inTable: !1,
    nodeHandlers: { ...nt, ...e.nodeHandlers },
    one: st,
    options: e,
    patch: ct,
    qNesting: 0,
    resolve: ot,
    toFlow: at,
    toSpecificContent: ut
  };
}
function it(e) {
  const t = e.children || [], n = [];
  let r = -1;
  for (; ++r < t.length; ) {
    const l = t[r], i = (
      /** @type {Array<MdastRootContent> | MdastRootContent | undefined} */
      this.one(l, e)
    );
    Array.isArray(i) ? n.push(...i) : i && n.push(i);
  }
  return n;
}
function st(e, t) {
  if (e.type === "element") {
    if (e.properties && e.properties.dataMdast === "ignore")
      return;
    if (X.call(this.handlers, e.tagName))
      return this.handlers[e.tagName](this, e, t) || void 0;
  } else if (X.call(this.nodeHandlers, e.type))
    return this.nodeHandlers[e.type](this, e, t) || void 0;
  if ("value" in e && typeof e.value == "string") {
    const n = { type: "text", value: e.value };
    return this.patch(e, n), n;
  }
  if ("children" in e)
    return this.all(e);
}
function ct(e, t) {
  e.position && (t.position = pe(e));
}
function ot(e) {
  const t = this.frozenBaseUrl;
  return e == null ? "" : t ? String(new URL(e, t)) : e;
}
function at(e) {
  return oe(e);
}
function ut(e, t) {
  const n = t(), r = [];
  let l = [], i = -1;
  for (; ++i < e.length; ) {
    const s = e[i];
    if (c(s))
      l.length > 0 && (s.children.unshift(...l), l = []), r.push(s);
    else {
      const o = (
        /** @type {ChildType} */
        s
      );
      l.push(o);
    }
  }
  if (l.length > 0) {
    let s = r[r.length - 1];
    s || (s = t(), r.push(s)), s.children.push(...l), l = [];
  }
  return r;
  function c(s) {
    return s.type === n.type;
  }
}
const pt = {};
function Y(e, t) {
  const n = J(e), r = t || pt, l = we({
    newlines: r.newlines === !0
  }), i = lt(r);
  let c;
  l(n), C(n, function(o) {
    if (o && o.type === "element" && o.properties) {
      const a = String(o.properties.id || "") || void 0;
      a && !i.elementById.has(a) && i.elementById.set(a, o);
    }
  });
  const s = i.one(n, void 0);
  return s ? Array.isArray(s) ? c = { type: "root", children: (
    /** @type {Array<MdastRootContent>} */
    s
  ) } : c = s : c = { type: "root", children: [] }, C(c, function(o, a, u) {
    if (o.type === "text" && a !== void 0 && u) {
      const f = u.children[a - 1];
      if (f && f.type === o.type)
        return f.value += o.value, u.children.splice(a, 1), f.position && o.position && (f.position.end = o.position.end), a - 1;
      if (o.value = o.value.replace(/[\t ]*(\r?\n|\r)[\t ]*/, "$1"), u && (u.type === "heading" || u.type === "paragraph" || u.type === "root") && (a || (o.value = o.value.replace(/^[\t ]+/, "")), a === u.children.length - 1 && (o.value = o.value.replace(/[\t ]+$/, ""))), !o.value)
        return u.children.splice(a, 1), a;
    }
  }), c;
}
const G = { document: !0 };
function wt(e, t) {
  return e && "run" in e ? async function(n, r) {
    const l = Y(n, { ...G, ...t });
    await e.run(l, r);
  } : function(n) {
    return (
      /** @type {MdastRoot} */
      Y(n, { ...G, ...e })
    );
  };
}
export {
  wt as default
};
