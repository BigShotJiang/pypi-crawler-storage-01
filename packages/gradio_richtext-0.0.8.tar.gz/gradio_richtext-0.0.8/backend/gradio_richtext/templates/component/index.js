import { I as f } from "./Index-C6h55__v.js";
export {
  f as default
};
