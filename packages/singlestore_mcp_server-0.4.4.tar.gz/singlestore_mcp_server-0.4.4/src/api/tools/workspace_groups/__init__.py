"""Workspace Groups tools for SingleStore MCP server."""

from .workspace_groups import workspace_groups_info

__all__ = ["workspace_groups_info"]
