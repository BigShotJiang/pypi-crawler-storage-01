"""Authentication unit tests package."""
