version_tuple = __version_info__ = (0, 0, 12)
version = version_string = __version__ = ".".join(map(str, __version_info__))
