# snakemake-executor-plugin-cluster-sync

A Snakemake executor plugin for generic cluster jobs that are executed synchronously. 