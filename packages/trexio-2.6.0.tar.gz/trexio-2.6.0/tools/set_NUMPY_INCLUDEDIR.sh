
INCLUDEDIR=`python -c 'import numpy; print(numpy.get_include())'`
export NUMPY_INCLUDEDIR=${INCLUDEDIR}

