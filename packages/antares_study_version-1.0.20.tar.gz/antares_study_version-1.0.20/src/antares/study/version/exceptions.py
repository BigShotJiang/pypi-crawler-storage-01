class ApplicationError(Exception):
    """
    Base class for all exceptions raised by the application.
    """
