"""
Antares Study (and Solver) version models.
"""

# Standard project metadata

__version__ = "1.0.20"
__author__ = "RTE, Antares Web Team"
__date__ = "2025-07-31"
__credits__ = "© Réseau de Transport de l’Électricité (RTE)"
