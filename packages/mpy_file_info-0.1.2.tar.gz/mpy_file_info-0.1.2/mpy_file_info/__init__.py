from mpy_file_info.mpy_tool import main
