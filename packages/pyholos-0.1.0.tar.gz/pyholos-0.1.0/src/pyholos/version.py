major = 0
minor = 1
post = 0

__version__ = ".".join([str(s) for s in (major, minor, post)])