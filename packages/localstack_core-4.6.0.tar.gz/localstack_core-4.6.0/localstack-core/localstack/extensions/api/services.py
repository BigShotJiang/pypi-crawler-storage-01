from localstack.utils.common import external_service_ports

__all__ = [
    "external_service_ports",
]
