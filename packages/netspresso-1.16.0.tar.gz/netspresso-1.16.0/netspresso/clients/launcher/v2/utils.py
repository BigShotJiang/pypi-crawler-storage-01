def make_file_form_data_object(file_name, file_content):
    return [("file", (file_name, file_content))]
