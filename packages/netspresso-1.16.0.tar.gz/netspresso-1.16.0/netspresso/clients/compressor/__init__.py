from netspresso.clients.compressor.v2.main import compressor_client_v2

__all__ = ["compressor_client_v2"]
