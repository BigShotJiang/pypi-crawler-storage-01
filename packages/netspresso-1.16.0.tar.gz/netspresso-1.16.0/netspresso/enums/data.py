from netspresso.enums.base import StrEnum


class Format(StrEnum):
    Local = "local"
    Hugging_Face = "huggingface"
