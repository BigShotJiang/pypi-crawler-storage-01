from netspresso.enums.base import StrEnum


class SimulateTaskType(StrEnum):
    OUTPUT = "OUTPUT"
