from netspresso.compressor.v2.compressor import CompressorV2

__all__ = ["CompressorV2"]
