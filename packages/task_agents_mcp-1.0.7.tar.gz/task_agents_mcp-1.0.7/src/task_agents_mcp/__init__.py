"""Task-Agents MCP Server - Delegate tasks to specialized AI agents."""

__version__ = "1.0.0"

from .server import mcp

__all__ = ["mcp"]