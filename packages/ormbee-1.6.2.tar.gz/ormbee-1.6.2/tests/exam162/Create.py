from bee.api import SuidRich

import MyConfig
from entity.Test import Test
from exam162.Orders import Orders


# from bee.util import HoneyUtil
if __name__ == '__main__':

    # create_sql=HoneyUtil.get_create_sql(Entity)
    
    MyConfig.init()
    suidRich = SuidRich()
    
    #有声明类型和无声明类型都有
    # suidRich.create_table(Entity,True)
    
    #无声明类型
    suidRich.create_table(Orders,True)
    suidRich.create_table(Test,True)
    
    ######1. just print create table sql
    # honeyConfig = HoneyConfig()
    # # honeyConfig.set_dbname("MySQL")
    # # # honeyConfig.set_dbname("Oracle")
    # # # honeyConfig.set_dbname("sqlite")
    # honeyConfig.set_dbname("H2")
    # sql = ObjToSQL().toCreateSQL(Orders)
    # print(sql)
    
    # suidRich.create_table(Orders3,True)
    
    # suidRich.create_table(Student2,True)
    # suidRich.create_table(Student3,True)
