"""  
bee core implementation.
"""
