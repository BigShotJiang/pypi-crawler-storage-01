"""Module for Danfoss quirks implementations."""
