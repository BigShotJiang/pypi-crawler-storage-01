CHANGES
=======

0.2.0 (2025-08-02)
------------------

- Add stub files according to PEP 561
- Support Python 3.9, 3.10, 3.11, 3.12, 3.13

0.1.2 (2019-12-31)
------------------

- Support Python 3.8

0.1.1 (2019-1-28)
------------------

- Support Python 2.7

0.1 (2019-1-27)
------------------

- First release
