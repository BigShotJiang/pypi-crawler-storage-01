# CLOSED MODULE

from .types import GenericHttpRequest as GenericHttpRequest
from .types import GenericHttpResponse as GenericHttpResponse
from .types import HttpException as HttpException
