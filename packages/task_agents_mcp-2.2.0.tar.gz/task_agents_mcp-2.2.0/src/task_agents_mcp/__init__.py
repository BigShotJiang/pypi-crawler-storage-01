"""Task-Agents Multi-Tool MCP Server - Each specialized AI agent as an individual MCP tool."""

__version__ = "2.2.0"

from .server import mcp

__all__ = ["mcp"]