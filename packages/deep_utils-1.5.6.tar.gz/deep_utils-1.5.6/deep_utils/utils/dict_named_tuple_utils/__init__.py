import sys

if sys.version_info.major >= 3 and sys.version_info.minor >= 8:
    from deep_utils.utils.dict_named_tuple_utils.dictnamedtuple_38 import dictnamedtuple
else:
    from deep_utils.utils.dict_named_tuple_utils.dictnamedtuple_37 import dictnamedtuple
