# from .main import get_func_time, get_method_time
