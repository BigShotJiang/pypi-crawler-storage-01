# try:
#     from deep_utils.dummy_objects.vision.face_recognition import VggFace2TorchFaceRecognition
#     from deep_utils.vision.face_recognition.vggface2.torch.vggface2_torch import VggFace2TorchFaceRecognition
# except ModuleNotFoundError:
#     pass
