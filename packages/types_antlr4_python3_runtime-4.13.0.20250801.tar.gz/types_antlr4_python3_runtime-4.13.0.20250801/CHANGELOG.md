## 4.13.0.20250801 (2025-08-01)

Split `tool.stubtest.platforms` metadata key (#13746)

Co-authored-by: Avasam <samuel.06@hotmail.com>
Co-authored-by: pre-commit-ci[bot] <66853113+pre-commit-ci[bot]@users.noreply.github.com>

## 4.13.0.20250613 (2025-06-13)

[antlr4-python3-runtime] Remove `ignore_missing_stub` flag (#14270)

## 4.13.0.20250516 (2025-05-16)

Replace `Incomplete | None = None` in third party stubs (#14063)

## 4.13.0.20240519 (2024-05-19)

Use assignment instead of annotation in third party enums (#11957)

## 4.13.0.20240331 (2024-03-31)

Remove bare Incomplete annotations in third-party stubs (#11671)

## 4.13.0.20240116 (2024-01-16)

Add stubs for antlr4 (#11192)

