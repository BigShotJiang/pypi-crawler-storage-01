## Typing stubs for antlr4-python3-runtime

This is a [PEP 561](https://peps.python.org/pep-0561/) type stub package for
the [`antlr4-python3-runtime`](https://github.com/antlr/antlr4) package. It can be used by type checkers
to check code that uses `antlr4-python3-runtime`. This version of
`types-antlr4-python3-runtime` aims to provide accurate annotations for
`antlr4-python3-runtime==4.13.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/antlr4-python3-runtime`](https://github.com/python/typeshed/tree/main/stubs/antlr4-python3-runtime)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.16.1
* [pyright](https://github.com/microsoft/pyright) 1.1.403
It was generated from typeshed commit
[`8edafa8029b48c2bb877dde68a572dc4a4349557`](https://github.com/python/typeshed/commit/8edafa8029b48c2bb877dde68a572dc4a4349557).