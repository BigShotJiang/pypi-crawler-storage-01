"""Entry point for python -m apple_notes_parser."""

from .cli import main

if __name__ == "__main__":
    main()
