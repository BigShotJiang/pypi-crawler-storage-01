# LlamaIndex Vector_Stores Integration: Vearch
