# How to update to the latest template structure

To track changes to the upstream template, run

```
copier update
```

This will fetch the latest tagged release of the template, and apply any changes to your working copy. It will prompt for answers again, giving your previous answers as the defaults.
