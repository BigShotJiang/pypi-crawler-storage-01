# Nintendo Switch Tools

Tools for  XCI, XCZ, NSP and NSZ

Based on nut, NSC_B and nsz

# pypi.org

for using nstools.Fs, nstools.lib and nstools.nut:
https://pypi.org/project/nstools/
