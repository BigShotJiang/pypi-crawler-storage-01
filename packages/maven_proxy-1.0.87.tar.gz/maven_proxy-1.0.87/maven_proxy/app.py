#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
from maven_proxy import proxy


def main():
    proxy.startup()


if __name__ == "__main__":
    main()
