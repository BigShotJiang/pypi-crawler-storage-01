class Configuration:
    """
    全局配置信息
    """
    file: str | None = None  # 元数据的保存路径
