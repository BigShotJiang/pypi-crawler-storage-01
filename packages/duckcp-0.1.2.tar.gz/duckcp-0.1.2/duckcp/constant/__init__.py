APP = 'duckcp'
IDENTIFIER = f'com.yinfn.{APP}'
