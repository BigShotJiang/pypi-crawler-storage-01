# shopify-data-platform-spark

python utils for shop spark