"""shopify-data-platform-spark: python utils for shop spark"""

__version__ = "1.99.100"
