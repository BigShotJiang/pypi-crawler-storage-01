# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import contract_recurring_mixin
from . import contract_template
from . import contract
from . import contract_template_line
from . import contract_line
from . import contract_modification
from . import account_move
from . import account_move_line
from . import res_partner
from . import contract_tag
