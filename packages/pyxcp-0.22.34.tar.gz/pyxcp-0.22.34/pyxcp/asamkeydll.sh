#!/bin/sh
gcc -O3 -Wall asamkeydll.c -ldl  -o asamkeydll
