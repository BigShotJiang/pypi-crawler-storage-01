# Where from the nanonis file reader
This reader is the copy of a open-source repository called [nanonispy](https://github.com/ramav87/nanonispy.git)
