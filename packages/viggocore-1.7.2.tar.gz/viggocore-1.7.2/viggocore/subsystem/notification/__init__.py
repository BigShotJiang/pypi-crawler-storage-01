from viggocore.common import subsystem
from viggocore.subsystem.notification import resource

subsystem = subsystem.Subsystem(resource=resource.Notification)
