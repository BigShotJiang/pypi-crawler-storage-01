from .codesnap import CodeSnap

__author__ = 'Shayan Heidari'
__version__ = '0.2'