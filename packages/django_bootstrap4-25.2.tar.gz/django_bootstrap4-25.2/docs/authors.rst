.. include:: ../AUTHORS
   :parser: myst_parser.sphinx_
