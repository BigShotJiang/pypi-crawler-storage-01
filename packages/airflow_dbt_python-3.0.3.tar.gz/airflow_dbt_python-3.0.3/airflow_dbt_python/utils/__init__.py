"""Utils for project operators and hooks."""
