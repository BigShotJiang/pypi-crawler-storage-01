"""Provides an Airflow operator and hooks to run all or most dbtcommands."""

from .__version__ import __author__, __copyright__, __title__, __version__
