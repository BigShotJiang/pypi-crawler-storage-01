@filter.md:- content
title: Create a Web Form
form: subscribe
menu.parent: /demos
menu.name: Form demo
===
This page demonstrates how to display a form using the `Form` plugins provided by pyonir.