@filter.md:- content
title: Error pages
menu.parent: /demos
===

- [demo 404 Error Page](/some-page)
- [demo 401 Error Page](/sample/foo)
