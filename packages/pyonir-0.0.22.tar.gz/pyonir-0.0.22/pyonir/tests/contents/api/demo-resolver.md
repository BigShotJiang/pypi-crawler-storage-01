@resolvers:
    GET.call: app.backend.demo_controller.dynamic_lambda
===