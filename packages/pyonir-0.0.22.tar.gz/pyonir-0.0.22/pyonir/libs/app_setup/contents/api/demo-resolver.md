@resolvers:
    GET.call: site.backend.demo_controller.dynamic_lambda
===
Execute server functions using resolver definitions `call` attribute on a REST action.
Visit this endpoint at `/api/demo-resolover` in web browser.