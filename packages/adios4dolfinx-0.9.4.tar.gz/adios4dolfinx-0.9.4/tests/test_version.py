import adios4dolfinx


def test_version():
    assert adios4dolfinx.__version__ is not None
