from agno.document.base import Document

__all__ = [
    "Document",
]
