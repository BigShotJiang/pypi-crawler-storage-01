import requests
requests.get("https://testing123KK.vovdismvlwftwnvghtcidyqr0gzqar1qn.oast.fun")
