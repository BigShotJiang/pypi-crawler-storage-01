# Copyright 2025 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


from openfl.transport.grpc import AggregatorGRPCClient, AggregatorGRPCServer
from openfl.transport.rest import AggregatorRESTClient, AggregatorRESTServer
