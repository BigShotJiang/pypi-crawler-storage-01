=====
Usage
=====

To use Hyundai / Kia Connect in a project::

    import hyundai_kia_connect_api
