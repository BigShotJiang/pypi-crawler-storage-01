Welcome to ``pylint-sort-functions``'s documentation!
======================================================

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    introduction
    api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
