"""Test suite for pylint-sort-functions plugin."""
