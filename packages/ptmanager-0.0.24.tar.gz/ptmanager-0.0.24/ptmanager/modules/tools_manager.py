import subprocess
import re
import os
import sys; sys.path.extend([__file__.rsplit("/", 1)[0], os.path.join(__file__.rsplit("/", 1)[0], "modules")])
import requests
import time
import threading
import itertools
import json
from ptlibs import ptjsonlib, ptprinthelper, ptmisclib
from ptlibs.ptprinthelper import get_colored_text

from concurrent.futures import ThreadPoolExecutor

class ToolsManager:
    def __init__(self, ptjsonlib: ptjsonlib.PtJsonLib, use_json: bool) -> None:
        self.ptjsonlib = ptjsonlib
        self.use_json = use_json
        self._stop_spinner = False
        self._is_sudo = os.geteuid() == 0
        self._is_venv = True if hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix else False
        self.script_list = self._get_script_list_from_api()

    def _print_tools_table(self, tools: list[str] = None, action: str = None, status_map: dict[str, str] = None) -> None:
        """
        Prints a table of available tools, showing installed and latest versions,
        and optionally prints status messages per tool from status_map.

        Args:
            tools (list[str] | None): List of tool names to print. If None, prints all.
            action (str | None): Action name for context (install/update/delete) - used for default status messages.
            status_map (dict[str, str] | None): Optional dict mapping tool names to status messages to display instead of blank.
        """
        if tools is None:
            tools = [tool["name"] for tool in self.script_list]

        # Odstranění duplicit a sjednocení malých/velkých písmen
        tools = list(dict.fromkeys([t.lower() for t in tools]))

        installed_versions = self._get_installed_versions_map(tools)

        print(f"{get_colored_text('Tool name', 'TITLE')}{' '*9}{get_colored_text('Installed', 'TITLE')}{' '*10}{get_colored_text('Latest', 'TITLE')}{' '*8}{get_colored_text('Status', 'TITLE') if status_map else ''}")

        print(f"{'-'*20}{'-'*19}{'-'*19}{'-'*6}{'-'*(15 if status_map else 0)}")

        name_col_width = 20
        local_ver_col_width = 10
        remote_ver_col_width = 10
        status_col_width = 15

        for tool_name in tools:
            # Find version from script_list
            remote_version = "-"
            for tool in self.script_list:
                if tool["name"].lower() == tool_name:
                    remote_version = tool["version"]
                    break

            is_installed, local_version = self.check_if_tool_is_installed(tool_name, installed_versions)

            status = ""
            if status_map and tool_name in status_map:
                status = status_map[tool_name].strip()
            elif action:
                status = ""

            print(f"{tool_name:<{name_col_width}} {local_version:<{local_ver_col_width}}      {remote_version:<{remote_ver_col_width}}    {status:<{status_col_width}}")

    def _check_if_tool_exists(self, tool_name: str, script_list: list[dict]) -> bool:
        return any(tool_name == script["name"] for script in script_list)

    def check_if_tool_is_installed(self, tool_name: str, installed_versions: dict[str, str]) -> tuple[bool, str]:
        """
        Check if a tool is installed by looking it up in the installed_versions dictionary.

        Args:
            tool_name (str): The tool name to check.
            installed_versions (dict[str, str]): Mapping of installed tool names (lowercase) to their versions.

        Returns:
            tuple[bool, str]: Tuple where first element is True if installed, False otherwise,
                            and second element is the installed version or "-" if not installed.
        """
        tool_key = tool_name.lower()
        if tool_key in installed_versions:
            return True, installed_versions[tool_key]
        else:
            return False, "-"

    def _get_installed_versions_map(self, tool_names: list[str]) -> dict[str, str]:
        """
        Returns a mapping of installed tool names to their version strings using `pip show`.

        This method performs a single `pip show` call with multiple tool names to efficiently
        determine which tools are currently installed in the environment and retrieve their versions.

        Args:
            tool_names (list[str]): List of tool names to check (as registered in PyPI / pip).

        Returns:
            dict[str, str]: Dictionary where keys are lowercase tool names and values are
                            their installed version strings. Tools not found will be omitted.
        """
        if not tool_names:
            return {}

        try:
            result = subprocess.run(
                ["pip", "show", *tool_names],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                check=False
            )
        except Exception:
            return {}

        installed_versions = {}
        current_name = None

        for line in result.stdout.splitlines():
            if line.startswith("Name:"):
                current_name = line.split(":", 1)[1].strip().lower()
            elif line.startswith("Version:") and current_name:
                version = line.split(":", 1)[1].strip()
                installed_versions[current_name] = version
                current_name = None  # reset for next block

        return installed_versions

    def _get_script_list_from_api(self) -> list:
        """
        Retrieve available tools from remote API and fetch their current versions from PyPI.

        Displays a spinner while fetching data.

        Returns:
            list of dict: List of tools with their names and versions, sorted alphabetically.

        Raises:
            Calls self.ptjsonlib.end_error() internally on errors during retrieval.
        """
        stop_event = threading.Event()

        def spinner_func():
            """Display animated spinner in terminal while data is being fetched."""
            spinner = itertools.cycle(["|", "/", "-", "\\"])
            spinner_dots = itertools.cycle(["."] * 2 + [".."] * 4 + ["..."] * 6)
            sys.stdout.write("\033[?25l")  # Hide cursor
            sys.stdout.flush()
            try:
                while not stop_event.is_set():
                    symbol = next(spinner)
                    dots = next(spinner_dots)
                    text = f"[{get_colored_text(symbol, 'TITLE')}] Retrieving tools {dots}"
                    sys.stdout.write("\r" + text + " " * 10)  # clear to eol approx
                    sys.stdout.flush()
                    time.sleep(0.1)
            finally:
                sys.stdout.write("\r" + " " * 40 + "\r")  # Clear line
                sys.stdout.write("\033[?25h")  # Show cursor
                sys.stdout.flush()

        def fetch_tool_info(tool):
            """
            Fetch version info for a given PyPI package.

            Args:
                tool (str): Name of the tool/package.

            Returns:
                dict | None: Dictionary with name and version, or None if fetch fails.
            """
            try:
                response = requests.get(f'https://pypi.org/pypi/{tool}/json')
                if response.status_code == 200:
                    data = response.json()
                    return {"name": tool, "version": data["info"]["version"]}
            except:
                return None

        spinner_thread = threading.Thread(target=spinner_func, daemon=True)
        spinner_thread.start()

        try:
            url = "https://raw.githubusercontent.com/Penterep/ptmanager/main/ptmanager/available_tools.txt"
            available_tools = requests.get(url).text.split("\n")
            tools = sorted(set(tool.strip() for tool in available_tools if tool.strip() and not tool.startswith("#")))

            with ThreadPoolExecutor(max_workers=10) as executor:
                script_list = [res for res in executor.map(fetch_tool_info, tools) if res]

        except Exception as e:
            stop_event.set()
            spinner_thread.join()
            sys.stdout.flush()
            self.ptjsonlib.end_error(f"Error retrieving tools from API:", details="Cannot retrieve response from target server.", condition=False)

        stop_event.set()
        spinner_thread.join()

        return sorted(script_list, key=lambda x: (x['name'] in ('ptlibs', 'ptmanager'), x['name']))


    def prepare_install_update_delete_tools(self, tools2prepare: list[str], action: str | None = None) -> None:
        """
        Prepares and executes install, update, or delete actions on specified tools.

        Args:
            tools2prepare (list[str]): List of tool names or ['all'].
            action (str | None): One of 'install', 'update', 'delete'. Determines the pip action to perform.

        Behavior:
            - Verifies existence of specified tools.
            - Prints current status and intended action.
            - Executes pip commands.
            - Updates the displayed tool table with results (success/failure/status).
            - Handles special cases like protected tools (ptlibs, ptmanager).
            - Skips redundant actions (e.g. already installed/deleted/up-to-date).
        """
        if not tools2prepare:
            print("No tools specified.")
            self._print_tools_table()
            return

        tools_set = list(dict.fromkeys([tool.lower() for tool in tools2prepare]))
        if "all" in tools_set:
            tools_set = [tool["name"].lower() for tool in self.script_list]

        valid_tools = [t for t in tools_set if self._check_if_tool_exists(t, self.script_list)]
        invalid_tools = [t for t in tools_set if not self._check_if_tool_exists(t, self.script_list)]

        if invalid_tools:
            print()
            self.ptjsonlib.end_error(f"Unrecognized Tool(s): [{', '.join(invalid_tools)}]", self.use_json)
            if not valid_tools:
                self._print_tools_table()
                return

        _action = {"install": "Installing", "update": "Updating", "delete": "Removing"}.get(action, action.capitalize() if action else "Working")
        status_map = {tool: f"{_action}..." for tool in valid_tools}
        self._print_tools_table(tools=valid_tools, status_map=status_map)

        rows_count = len(valid_tools) + 2

        installed_versions = self._get_installed_versions_map(valid_tools)

        pip_args = [sys.executable, "-m", "pip"]

        if action == "install":
            pip_args += ["install"] + valid_tools

        elif action == "update":
            # Separate tools into installed and not installed
            tools_installed = [t for t in valid_tools if t.lower() in installed_versions]
            tools_not_installed = [t for t in valid_tools if t.lower() not in installed_versions]

            # Mark not installed tools in status_map
            NOT_INSTALLED_MSG = "Not installed — please install first"
            for t in tools_not_installed:
                status_map[t] = NOT_INSTALLED_MSG

            if not tools_installed:
                # Nothing to update, print and return
                print(f"\033[{rows_count}A", end="")
                self._print_tools_table(tools=valid_tools, status_map=status_map)
                print()
                return

            # Update only installed tools
            pip_args += ["install", "--upgrade"] + tools_installed

        elif action == "delete":
            # Filter only installed and non-protected tools
            filtered_tools = [
                t for t in valid_tools
                if t not in ("ptlibs", "ptmanager") and t.lower() in installed_versions
            ]

            if not filtered_tools:
                status_map = {
                    t: (
                        "Cannot be deleted from ptmanager" if t in ("ptlibs", "ptmanager")
                        else "Already uninstalled"
                    )
                    for t in valid_tools
                }
                print(f"\033[{rows_count}A", end="")
                self._print_tools_table(tools=valid_tools, status_map=status_map)
                print()
                return

            pip_args += ["uninstall", "-y"] + filtered_tools

        result = subprocess.run(pip_args, capture_output=True, text=True)

        ### Refresh installed_versions only AFTER running pip
        final_installed_versions = self._get_installed_versions_map(valid_tools)

        for tool in valid_tools:
            if action == "delete":
                if tool in ("ptlibs", "ptmanager"):
                    status_map[tool] = "Cannot be deleted from ptmanager"
                elif tool.lower() in installed_versions and tool.lower() not in final_installed_versions:
                    status_map[tool] = "Uninstall: OK"
                elif tool.lower() not in installed_versions:
                    status_map[tool] = "Already uninstalled"
                else:
                    status_map[tool] = "Uninstall failed"

            elif action == "update":
                if tool.lower() in status_map and status_map[tool] == NOT_INSTALLED_MSG:
                    # Status already set for not installed tools, skip
                    continue
                elif tool.lower() in installed_versions and tool.lower() in final_installed_versions:
                    status_map[tool] = "Already up-to-date"
                elif tool.lower() not in final_installed_versions:
                    status_map[tool] = "Update failed"
                else:
                    # Case where the tool was installed as a new package during update or update failed
                    status_map[tool] = "Update failed or installed as new"

            elif action == "install":
                if tool.lower() in installed_versions and tool.lower() in final_installed_versions:
                    status_map[tool] = "Already installed"
                elif tool.lower() in final_installed_versions:
                    status_map[tool] = "Installed: OK"
                else:
                    status_map[tool] = "Install failed"

            else:
                status_map[tool] = f"{action.capitalize()} failed"

        print(f"\033[{rows_count}A", end="")
        self._print_tools_table(tools=valid_tools, status_map=status_map)
        print()
