def make_dict(**kwargs):
    return kwargs