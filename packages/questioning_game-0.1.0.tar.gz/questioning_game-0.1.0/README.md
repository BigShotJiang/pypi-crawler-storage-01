# Questioning_game
A game that asks question and award you prize on every correct answer just a question game to practice my coding skills and its does not really award you money for real. its a fake game made for fun and learning..
