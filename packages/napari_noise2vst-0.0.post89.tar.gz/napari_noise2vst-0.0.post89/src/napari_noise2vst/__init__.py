__version__ = "0.1.0"

from ._widget import Noise2VSTWidget

__all__ = ("Noise2VSTWidget",)
