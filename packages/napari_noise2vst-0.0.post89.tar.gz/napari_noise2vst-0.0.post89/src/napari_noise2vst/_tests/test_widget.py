import numpy as np


def test_nothing():
    pass