"""Tests for managers module."""
