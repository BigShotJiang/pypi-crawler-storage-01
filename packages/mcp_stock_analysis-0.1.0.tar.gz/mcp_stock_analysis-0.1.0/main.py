def main():
    print("Hello from mcp-stock-analysis!")


if __name__ == "__main__":
    main()
