from llama_index.llms.alephalpha.base import AlephAlpha

__all__ = ["AlephAlpha"]
