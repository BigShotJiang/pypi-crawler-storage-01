from .pornfans_exam import _PornfansExamAnswerMonitor

__ignore__ = True


class TestPornfansExamMonitor(_PornfansExamAnswerMonitor):
    name = "PornFans 科举回答测试"
    chat_name = "api_group"
    chat_user = ["embykeeper_test_bot"]
