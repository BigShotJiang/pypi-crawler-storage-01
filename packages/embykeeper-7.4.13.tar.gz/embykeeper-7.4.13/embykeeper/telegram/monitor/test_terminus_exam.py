from .terminus_exam import TerminusExamMonitor

__ignore__ = True


class TestTerminusExamMonitor(TerminusExamMonitor):
    name = "终点站考试辅助 测试"
    chat_name = "embykeeper_test_bot"
