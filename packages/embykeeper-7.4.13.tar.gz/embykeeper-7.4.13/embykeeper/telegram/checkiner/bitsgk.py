from . import BotCheckin

__ignore__ = True


class BitSGKCheckin(BotCheckin):
    name = "Bit 社工库"
    bot_username = "BitSGKBot"
    bot_checkin_cmd = "签到"
