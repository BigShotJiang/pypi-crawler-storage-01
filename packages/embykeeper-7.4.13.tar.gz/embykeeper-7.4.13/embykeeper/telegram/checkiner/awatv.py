from ._templ_a import TemplateACheckin


class AWATVCheckin(TemplateACheckin):
    name = "AWA 影视服"
    bot_username = "awatv3_bot"
    bot_use_captcha = False
