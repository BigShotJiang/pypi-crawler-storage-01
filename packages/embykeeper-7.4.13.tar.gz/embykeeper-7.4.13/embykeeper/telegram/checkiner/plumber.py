from ._templ_a import TemplateACheckin


class PlumberCheckin(TemplateACheckin):
    name = "Plumber"
    bot_username = "Luuuigi_bot"
