from . import BotCheckin

__ignore__ = True


class SSSQCheckin(BotCheckin):
    name = "搜书神器"
    bot_username = "sosdbot"
