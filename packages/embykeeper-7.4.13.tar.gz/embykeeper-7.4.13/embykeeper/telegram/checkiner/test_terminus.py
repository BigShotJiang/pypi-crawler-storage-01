from .terminus import TerminusCheckin

__ignore__ = True


class TestTerminusCheckin(TerminusCheckin):
    name = "终点站签到测试"
    bot_username = "embykeeper_test_bot"
