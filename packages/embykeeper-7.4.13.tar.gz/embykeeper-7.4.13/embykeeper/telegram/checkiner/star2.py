from ._templ_a import TemplateACheckin

__ignore__ = True


class Star2Checkin(TemplateACheckin):
    name = "Star 2"
    bot_username = "star_emby2_bot"
    templ_panel_keywords = ["星灵感应到了熟悉的气息"]
