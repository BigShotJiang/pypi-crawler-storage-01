from ._templ_a import TemplateACheckin

__ignore__ = True


class AivbiCheckin(TemplateACheckin):
    name = "AIVBI"
    bot_username = "AIVBIbot"
