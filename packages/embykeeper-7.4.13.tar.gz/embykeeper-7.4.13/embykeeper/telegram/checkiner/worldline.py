from ._templ_a import TemplateACheckin


class WorldLineCheckin(TemplateACheckin):
    name = "WorldLine"
    bot_username = "WorldLineEmby_bot"
