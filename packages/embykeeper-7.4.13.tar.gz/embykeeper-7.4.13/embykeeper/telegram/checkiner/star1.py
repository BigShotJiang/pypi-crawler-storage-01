from ._templ_a import TemplateACheckin

__ignore__ = True


class Star1Checkin(TemplateACheckin):
    name = "Star 1"
    bot_username = "star_emby_bot"
    templ_panel_keywords = ["星灵感应到了熟悉的气息"]
