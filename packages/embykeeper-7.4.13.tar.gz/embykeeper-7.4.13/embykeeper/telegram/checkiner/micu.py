from ._templ_a import TemplateACheckin


class MICUCheckin(TemplateACheckin):
    name = "MICU 股东会"
    bot_username = "micu_user_bot"
