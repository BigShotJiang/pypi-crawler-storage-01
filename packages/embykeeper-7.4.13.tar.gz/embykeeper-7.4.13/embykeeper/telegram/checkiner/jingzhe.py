from ._templ_a import TemplateACheckin


class JingzheCheckin(TemplateACheckin):
    name = "惊蛰"
    bot_username = "JingzheProbot"
