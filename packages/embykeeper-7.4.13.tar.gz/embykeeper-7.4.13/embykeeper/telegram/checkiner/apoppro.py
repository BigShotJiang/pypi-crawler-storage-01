from ._templ_a import TemplateACheckin

__ignore__ = True


class ApopProCheckin(TemplateACheckin):
    name = "Apop Pro"
    bot_username = "apopembypro_bot"
