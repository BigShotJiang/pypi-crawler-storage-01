from ._templ_a import TemplateACheckin


class YeziGMCheckin(TemplateACheckin):
    name = "叶子高码"
    bot_username = "yezigm_bot"
