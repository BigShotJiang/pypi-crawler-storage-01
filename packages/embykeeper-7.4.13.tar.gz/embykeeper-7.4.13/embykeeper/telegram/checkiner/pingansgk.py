from . import BotCheckin

__ignore__ = True


class PinganSGKCheckin(BotCheckin):
    name = "平安社工库"
    bot_username = "pingansgk_bot"
    bot_checkin_cmd = "/qd"
