from ._templ_a import TemplateACheckin


class MooncakeCheckin(TemplateACheckin):
    name = "月饼"
    bot_username = "Moonkkbot"
