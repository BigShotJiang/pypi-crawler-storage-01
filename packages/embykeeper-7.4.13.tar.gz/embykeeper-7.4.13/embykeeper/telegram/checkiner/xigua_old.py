from ._templ_a import TemplateACheckin


class XiguaCheckin(TemplateACheckin):
    name = "冰镇西瓜"
    bot_username = "XiguaEmbyBot"
    bot_use_captcha = False
