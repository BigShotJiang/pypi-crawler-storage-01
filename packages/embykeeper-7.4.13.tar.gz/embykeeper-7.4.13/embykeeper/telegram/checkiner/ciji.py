from ._templ_a import TemplateACheckin

__ignore__ = True


class CijiCheckin(TemplateACheckin):
    name = "Ciji"
    bot_username = "MM_nastool_bot"
