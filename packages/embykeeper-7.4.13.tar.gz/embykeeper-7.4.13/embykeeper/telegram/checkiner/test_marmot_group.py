from .marmot_group_old import MarmotGroupCheckin

__ignore__ = True


class TestMarmotGroupCheckin(MarmotGroupCheckin):
    name = "Marmot 群组发言测试"
    chat_name = "api_group"
