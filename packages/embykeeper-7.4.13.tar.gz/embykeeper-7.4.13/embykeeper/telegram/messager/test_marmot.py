from .marmot import MarmotMessager

__ignore__ = True


class TestMarmotMessager(MarmotMessager):
    name = "Marmot 水群测试"
    chat_name = "api_group"
