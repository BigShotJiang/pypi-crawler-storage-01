from .app import cli

cli()
