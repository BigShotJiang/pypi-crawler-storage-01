# Dataiku ML Scoring Python library

This repository contains the Python library to run exported Dataiku models outside of Dataiku.

To use this library, you need to first export your model to Python from Dataiku.
