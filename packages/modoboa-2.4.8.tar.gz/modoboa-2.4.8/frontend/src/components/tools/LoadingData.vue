<template>
  <v-container class="fill-height" fuild>
    <v-row align="center" justify="center" dense>
      <v-col cols="12" sm="12" md="12" lg="12" class="text-center">
        <v-progress-circular
          color="primary"
          indeterminate
          :size="108"
        ></v-progress-circular>
      </v-col>
    </v-row>
  </v-container>
</template>
