<template>
  <ComposeEmailForm />
</template>

<script setup>
import ComposeEmailForm from '@/components/webmail/ComposeEmailForm'
</script>
