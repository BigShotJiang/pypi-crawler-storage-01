from autoblocks._impl.configs.config import AutoblocksConfig

__all__ = [
    "AutoblocksConfig",
]
