class IncompatiblePromptRevisionError(Exception):
    pass
