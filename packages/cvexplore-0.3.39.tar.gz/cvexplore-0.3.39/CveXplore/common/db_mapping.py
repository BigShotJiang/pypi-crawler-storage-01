database_mapping = ["capec", "cpe", "cwe", "via4", "cves"]
