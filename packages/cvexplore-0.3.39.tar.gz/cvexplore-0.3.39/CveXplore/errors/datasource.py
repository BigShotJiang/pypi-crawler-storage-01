class DatasourceException(Exception):
    pass


class UnsupportedDatasourceException(DatasourceException):
    pass
