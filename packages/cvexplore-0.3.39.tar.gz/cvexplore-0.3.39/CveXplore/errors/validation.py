class InputValidationException(Exception):
    pass


class CveNumberValidationError(InputValidationException):
    pass
