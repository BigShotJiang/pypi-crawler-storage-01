﻿eprllib.Agents.Triggers.WindowsShadingTriggers
==============================================

.. automodule:: eprllib.Agents.Triggers.WindowsShadingTriggers

   
   .. rubric:: Classes

   .. autosummary::
   
      WindowsShadingTrigger
   