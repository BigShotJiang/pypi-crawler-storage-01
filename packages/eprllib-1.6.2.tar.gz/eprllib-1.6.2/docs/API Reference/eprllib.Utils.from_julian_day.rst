eprllib.Utils.from\_julian\_day
===============================

.. automodule:: eprllib.Utils.from_julian_day

   
   .. rubric:: Functions

   .. autosummary::
   
      from_julian_day
   