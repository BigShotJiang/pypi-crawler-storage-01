﻿eprllib.Agents.Triggers.WindowsOpeningTriggers
==============================================

.. automodule:: eprllib.Agents.Triggers.WindowsOpeningTriggers

   
   .. rubric:: Classes

   .. autosummary::
   
      WindowsOpeningTrigger
   