"""Version information."""

__version__ = "1.6.2"
EP_VERSION = "24-2-0"
