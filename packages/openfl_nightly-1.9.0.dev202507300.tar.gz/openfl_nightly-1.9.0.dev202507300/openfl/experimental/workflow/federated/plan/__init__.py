# Copyright 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


"""Experimental Plan package."""

# FIXME: Too much recursion in namespace
from openfl.experimental.workflow.federated.plan.plan import Plan
