# **Link Digital Product - Digital Product**
>	Link digital product dependency between two digital products.

## **DigitalProduct1**
>	**Input Required**: True

>	**Description**: The  first product to link.

>	**Alternative Labels**: Product 1


## **DigitalProduct2**
>	**Input Required**: True

>	**Description**: The  second product to link.

>	**Alternative Labels**: Product 2


## **Label**
>	**Input Required**: False

>	**Description**: Labels the link between two digital products.


## **Description**
>	**Input Required**: False

>	**Description**: A description of the link.

