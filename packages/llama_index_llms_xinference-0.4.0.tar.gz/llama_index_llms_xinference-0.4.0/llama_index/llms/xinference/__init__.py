from llama_index.llms.xinference.base import Xinference

__all__ = ["Xinference"]
