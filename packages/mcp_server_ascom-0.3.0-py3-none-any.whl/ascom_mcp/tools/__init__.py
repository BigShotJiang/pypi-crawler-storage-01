"""Tool implementations for ASCOM MCP server."""
