"""Utilities copied from aurelian for scientific literature processing."""
