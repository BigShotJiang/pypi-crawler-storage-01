# AIND Behavior Launcher Example

## Example Code

The following example shows how to instantiate a behavior launcher that interfaces with AIND infrastructure.

```python
--8<-- "examples/behavior_launcher.py"
```