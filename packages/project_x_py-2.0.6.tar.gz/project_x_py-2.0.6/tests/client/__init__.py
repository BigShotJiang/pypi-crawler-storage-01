"""Client module tests package."""
