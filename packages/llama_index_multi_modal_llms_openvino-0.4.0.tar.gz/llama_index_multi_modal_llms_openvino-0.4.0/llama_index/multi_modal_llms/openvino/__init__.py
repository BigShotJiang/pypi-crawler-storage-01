from llama_index.multi_modal_llms.openvino.base import OpenVINOMultiModal

__all__ = ["OpenVINOMultiModal"]
