# LlamaIndex Multi_Modal_Llms Integration: OpenVINO
