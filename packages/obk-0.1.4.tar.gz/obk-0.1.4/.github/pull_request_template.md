### PR Deployment Checklist

- [ ] Deployment PR (will trigger PyPI release)
- [ ] Non-deployment PR (documentation, chores, automation)
- [ ] Changelog updated (Codex automation task run after GitHub Release)