This addon limit payment mode selection is sale order to the brand
allowed payment mode.
