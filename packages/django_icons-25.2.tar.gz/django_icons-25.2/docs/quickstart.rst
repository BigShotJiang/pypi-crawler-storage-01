Quickstart
==========

- Install ``django-icons`` using ``pip`` or by adding it to your ``requirements.txt``.
- Load the ``{% icons %}`` library in your templates.
- Make sure your template loads the CSS for the icon libraries (e.g. `Font Awesome`).
- Use ``{% icon ... %}`` to display an icon.


