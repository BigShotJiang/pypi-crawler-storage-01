django-icons
============

Icons for Django

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   quickstart
   renderers
   example
   demo
   api
   templatetags
   settings
   changelog
   
