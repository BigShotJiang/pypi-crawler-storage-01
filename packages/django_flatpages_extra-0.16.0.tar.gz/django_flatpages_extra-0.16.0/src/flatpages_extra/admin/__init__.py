from .models import (
    FlatPageAdmin,
    RevisionAdmin,
)

__all__ = [
    "FlatPageAdmin",
    "RevisionAdmin",
]
