"""API package for the Automagik Agents service.

This package contains the API models, routes, and documentation endpoints.
"""

# Empty init file to mark the directory as a Python package 