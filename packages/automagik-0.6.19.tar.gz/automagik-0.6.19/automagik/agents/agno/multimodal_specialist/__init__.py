"""Multimodal Specialist Agent - Agno Framework Showcase"""

from .agent import MultimodalSpecialistAgent, create_multimodal_specialist_agent

__all__ = ["MultimodalSpecialistAgent", "create_multimodal_specialist_agent"]