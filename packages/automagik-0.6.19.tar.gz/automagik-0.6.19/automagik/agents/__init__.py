"""Agents package.

This package contains all agent implementations.
"""
