"""Discord agent prompts module."""

# Export the main prompt
from .prompt import AGENT_PROMPT

__all__ = ["AGENT_PROMPT"]