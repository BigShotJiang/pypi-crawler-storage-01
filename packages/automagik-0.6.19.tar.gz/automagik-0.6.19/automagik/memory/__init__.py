"""Memory management module for Sofia."""
