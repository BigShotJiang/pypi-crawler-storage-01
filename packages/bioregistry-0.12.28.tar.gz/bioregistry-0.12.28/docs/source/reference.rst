Reference
=========

This page includes the reference documentation for all user-facing code from the
Bioregistry Python package.

.. automodapi:: bioregistry
    :no-heading:
    :no-main-docstr:
