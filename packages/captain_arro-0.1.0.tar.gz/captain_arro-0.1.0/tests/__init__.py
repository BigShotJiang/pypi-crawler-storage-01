"""
Test suite for captain_arro package.
"""