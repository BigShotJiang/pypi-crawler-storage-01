Adds information about employee's medical examinations
