
from setuptools import setup

setup(
    name="thisisthedaventest",
    version="99.99.99",
    packages=["thisisthedaventest"],
    install_requires=[],
)
