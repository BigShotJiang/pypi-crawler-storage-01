from haupt.db.abstracts.runs import BaseRun


class Run(BaseRun):
    pass
