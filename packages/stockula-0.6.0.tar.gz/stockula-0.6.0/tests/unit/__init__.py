"""Unit tests for Stockula - isolated tests without external dependencies."""
