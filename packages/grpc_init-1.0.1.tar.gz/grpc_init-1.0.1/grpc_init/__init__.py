"""
This package contains the grpc-init package.

Author: Achraf MATAICH <achraf.mataich@outlook.com>
"""

from .cli import app