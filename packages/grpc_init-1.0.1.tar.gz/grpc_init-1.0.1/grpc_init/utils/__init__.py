"""
This module contains the utils functions for the grpc-init package.

Author: Achraf MATAICH <achraf.mataich@outlook.com>
"""

from .operations import generate_crud_proto