"""Utility functions for google-workspace-mcp."""
