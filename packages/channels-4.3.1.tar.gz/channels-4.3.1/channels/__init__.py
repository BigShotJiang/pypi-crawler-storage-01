__version__ = "4.3.1"


DEFAULT_CHANNEL_LAYER = "default"
