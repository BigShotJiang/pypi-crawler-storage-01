This module adds a button to the navbar to navigate to the initial action if the 
user has one defined.