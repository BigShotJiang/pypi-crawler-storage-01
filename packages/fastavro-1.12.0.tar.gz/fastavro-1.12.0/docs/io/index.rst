###########
fastavro.io
###########

.. toctree::
   :maxdepth: 1

   json_decoder
   json_encoder
