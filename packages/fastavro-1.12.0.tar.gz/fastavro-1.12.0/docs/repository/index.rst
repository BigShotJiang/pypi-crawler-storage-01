###################
fastavro.repository
###################

.. toctree::
   :maxdepth: 1

   base
