fastavro.repository.base
========================

.. autoclass:: fastavro.repository.base.AbstractSchemaRepository
