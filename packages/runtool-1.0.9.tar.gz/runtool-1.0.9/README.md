# runtool

[![PyPI - Version](https://img.shields.io/pypi/v/runtool.svg)](https://pypi.org/project/runtool)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/runtool.svg)](https://pypi.org/project/runtool)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/FlavioAmurrioCS/runtool/main.svg)](https://results.pre-commit.ci/latest/github/FlavioAmurrioCS/runtool/main)

-----

**Table of Contents**

- [runtool](#runtool)
  - [Installation](#installation)
  - [License](#license)

## Installation

```console
pip install runtool
```

## License

`runtool` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
