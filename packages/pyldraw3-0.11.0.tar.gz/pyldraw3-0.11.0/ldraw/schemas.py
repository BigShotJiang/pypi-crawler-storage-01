"""Schema definitions for validation."""
