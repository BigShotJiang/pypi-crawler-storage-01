def main():
    print("Hello from deep-breath-cli!")


if __name__ == "__main__":
    main()
