# LlamaIndex Index_Store Integration: Elasticsearch Index Store
