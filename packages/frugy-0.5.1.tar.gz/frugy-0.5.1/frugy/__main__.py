from frugy.cli import main

main()
