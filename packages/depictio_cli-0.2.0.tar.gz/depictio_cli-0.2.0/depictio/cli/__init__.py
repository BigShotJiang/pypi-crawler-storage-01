from pathlib import Path

# Set BASE_path to the parent directory where depictio package is located

BASE_PATH = Path(__file__).parent
