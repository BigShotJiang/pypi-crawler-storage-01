RICH_HTML_TEMPLATE = """\
<style>
{stylesheet}
rich-text {{
  color: {foreground};
  background-color: {background};
  padding: 0;
  margin: 0;
}}
</style>
<pre class="rich-text">{code}</pre>
"""
