
# Additional snippets not already in tldr_standard_commands.sh

# Show all current processes running `python`
procs python

# Show all current processes running `python` in a tree view
procs --tree python


