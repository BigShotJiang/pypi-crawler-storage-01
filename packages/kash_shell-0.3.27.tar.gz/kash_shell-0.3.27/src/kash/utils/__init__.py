"""
Common utilities for kash not available elsewhere. Everything here should
have few or no dependencies.
"""
