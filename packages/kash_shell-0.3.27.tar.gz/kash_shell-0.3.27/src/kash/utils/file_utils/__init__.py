"""
Minimal tools for file operations.
"""
