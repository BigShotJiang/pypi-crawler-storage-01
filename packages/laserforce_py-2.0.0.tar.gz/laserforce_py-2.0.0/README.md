# laserforce.py
[![Documentation Status](https://readthedocs.org/projects/laserforcepy/badge/?version=latest)](https://laserforcepy.readthedocs.io/en/latest/?badge=latest)
[![MIT](https://img.shields.io/pypi/l/gd.py.svg)](https://opensource.org/licenses/MIT)

A python package for Laserforce!
