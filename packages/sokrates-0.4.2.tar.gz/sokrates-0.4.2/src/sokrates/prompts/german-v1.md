# General Instruction for text output
__WRITE ALL RESPONSES IN GERMAN__