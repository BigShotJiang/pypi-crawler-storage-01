default_app_config = 'django_lms_geotool.apps.GeotoolConfig'
