def test_sample_fixture(sample_data):
    assert sample_data["foo"] == 1
