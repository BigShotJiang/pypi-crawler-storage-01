import os
import json
import argparse
from package_runner import run_app

# Bu dosya artık sadece run_app fonksiyonunu sağlar
# Diğer fonksiyonlar ayrı modüllere taşındı 