from ._proxy import TrioProxy as Proxy

__all__ = ('Proxy',)
