from ._proxy import SyncProxy as Proxy
from ._chain import ProxyChain

__all__ = (
    'Proxy',
    'ProxyChain',
)
