"""
Module to handle the numpy arrays
related to image files, maybe with
libraries like:

- `pillow`
- `opencv`
- ...
"""