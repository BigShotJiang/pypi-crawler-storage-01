"""
Module to handle the numpy arrays
related to audio files, maybe with
libraries like:

- `moviepy`
"""