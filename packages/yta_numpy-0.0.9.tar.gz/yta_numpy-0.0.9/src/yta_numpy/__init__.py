"""
Welcome to Youtube Autonomous Numpy
Helper Module.

This library is to simplify the way
we handle numpy arrays and we 
validate them for the different
purposes we have in our libraries.
"""