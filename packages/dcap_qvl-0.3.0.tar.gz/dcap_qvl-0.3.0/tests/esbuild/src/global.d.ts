declare module "@phala/dcap-qvl-web";
declare module "@phala/dcap-qvl-web/dcap-qvl-web_bg.wasm"; 