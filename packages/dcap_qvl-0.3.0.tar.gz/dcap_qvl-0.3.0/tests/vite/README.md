# vite + @phala/dcap-qvl-web

## Usage

```
pnpm install
pnpm dev
```

And then open http://localhost:5173/ in your browser and check the console for the verification result.