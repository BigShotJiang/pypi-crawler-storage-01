from .oauth2 import SpotifyAnon

__version__ = "1.2"
