# hanifx/__init__.py
__version__ = "14.0.0"

from .core import encrypt_file
from .utils import show_warning
