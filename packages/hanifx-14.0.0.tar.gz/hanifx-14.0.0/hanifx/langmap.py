# hanifx/langmap.py

EXTENSION_MAP = {
    ".py": "python",
    ".java": "java",
    ".php": "php",
    ".c": "c"
}
