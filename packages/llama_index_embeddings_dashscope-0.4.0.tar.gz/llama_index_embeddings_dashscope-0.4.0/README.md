# LlamaIndex Embeddings Integration: Dashscope
