# _src

All objects within this module are implemented in pure JAX and are designed to
work with JAX's grad and hessian functions.