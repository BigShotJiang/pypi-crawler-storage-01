r"""Special functions implemented by copulAX.

Currently the following are implemented:
- kv
"""

from copulax._src.special import kv_asymptotic as kv
from copulax._src.special import stdtr
