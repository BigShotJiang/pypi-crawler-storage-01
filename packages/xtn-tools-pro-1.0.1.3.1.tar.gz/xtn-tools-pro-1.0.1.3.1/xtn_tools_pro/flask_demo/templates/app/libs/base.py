#!/usr/bin/env python
# -*- coding: utf-8 -*-

# from flask_mail import Mail

# mail = Mail()  # 邮箱

