"""Base classes and utilities for the Gateway Development Kit (GDK)."""
