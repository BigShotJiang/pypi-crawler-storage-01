"""Core A2A Service Layer for decoupling gateway logic."""
