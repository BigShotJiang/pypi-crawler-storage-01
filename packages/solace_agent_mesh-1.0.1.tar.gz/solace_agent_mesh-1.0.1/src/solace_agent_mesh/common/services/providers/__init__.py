"""
This package contains concrete implementations (providers) for the services
defined in the parent 'services' package.
"""
