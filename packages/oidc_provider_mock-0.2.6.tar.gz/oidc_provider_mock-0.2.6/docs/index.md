```{toctree}
:maxdepth: 1
:hidden:

Readme <./README.md>
usage
api.rst
http.rst
Contributing <./CONTRIBUTING.md>
Changelog <./CHANGELOG.md>
```

```{include} README.md

```
