class Lambda_From_S3:

    def __init__(self):
        pass

