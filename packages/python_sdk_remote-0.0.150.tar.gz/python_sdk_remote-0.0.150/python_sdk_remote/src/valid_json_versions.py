# Later we'll generate this file using Sql2Code (from json_version database schema)
valid_json_versions = {
    "240109": "Description"
}
