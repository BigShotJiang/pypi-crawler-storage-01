class ValidationError(Exception):
    """Raised when a validation error occurs."""

    pass
