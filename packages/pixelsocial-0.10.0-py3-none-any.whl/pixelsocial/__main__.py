"""Support module execution"""

from . import main

main()
