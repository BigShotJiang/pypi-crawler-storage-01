__all__ = ["LangCodes", "LanguageCodeError", "Sanakirja"]
__version__ = "sanakirja-org 1.1.2"

from .api import LangCodes, LanguageCodeError, Sanakirja
