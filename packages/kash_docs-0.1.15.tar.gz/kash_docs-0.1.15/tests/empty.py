def test_empty():
    pass
