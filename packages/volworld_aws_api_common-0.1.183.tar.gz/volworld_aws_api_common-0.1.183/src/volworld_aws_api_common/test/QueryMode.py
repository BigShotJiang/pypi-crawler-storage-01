from volworld_aws_api_common.api.enum.QueryModeType import QueryModeType


class QueryMode:
    type = QueryModeType.ServerTest
    testUrlPrefix = ''