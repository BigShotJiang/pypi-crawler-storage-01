ebilab.analysis package
=======================

.. warning::

    :py:mod:`ebilab.analysis` モジュールは完成していません。
    今後のバージョンでは後方互換性がない場合があります。

.. automodule:: ebilab.analysis
   :members:
   :undoc-members:
   :imported-members:
   :show-inheritance:

Classes returned by preceding functions
-----------------------------------------

.. autoclass:: ebilab.analysis._preprocess.PreprocessFileData
.. autoclass:: ebilab.analysis._preprocess.PreprocessDfData
.. autoclass:: ebilab.analysis._process.ProcessingData
.. autoclass:: ebilab.analysis._process.AggregatedProcessingData

