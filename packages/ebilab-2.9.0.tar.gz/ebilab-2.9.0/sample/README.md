# sample scripts

- `multimeter.py`: simple measurement example w/o `launch_experiment()` class
- `voltage.py`: simple measurement and real-time plot example w/o `launch_experiment()`
- `random-walk.py`: real-time plot example using `launch_experiment()`
- `cont_r.py`: simple experiment example using `launch_experiment()`
