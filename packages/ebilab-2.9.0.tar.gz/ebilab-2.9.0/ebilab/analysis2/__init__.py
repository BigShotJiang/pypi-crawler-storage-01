import warnings

warnings.warn(
    "ebilab.analysis2 package is no longer maintained and will be removed in the future."
    "You are recommended to lock the version if you are using it.",
    UserWarning,
)
