Adds support for managing bonuses in employee contracts. Allows setting fixed or variable bonuses.

