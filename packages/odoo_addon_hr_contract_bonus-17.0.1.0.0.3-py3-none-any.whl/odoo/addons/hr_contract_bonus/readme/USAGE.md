1. Go to Employees > Configuration > Contracts > Employee Bonuses.
2. Create a bonus with the desired information.
3. Go to Employees > Contracts, select a contract, and assign the bonus to it.
You will see the annual wage updated to include the bonus.