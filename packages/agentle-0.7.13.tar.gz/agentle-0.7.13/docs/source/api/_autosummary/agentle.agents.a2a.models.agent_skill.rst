agentle.agents.a2a.models.agent\_skill
======================================

.. automodule:: agentle.agents.a2a.models.agent_skill

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      AgentSkill
      BaseModel
      Sequence
   