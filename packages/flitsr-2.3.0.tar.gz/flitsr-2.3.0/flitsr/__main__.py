from flitsr import main

main.main()
