#####################
Carrier Weight Module
#####################

The *Carrier Weight Module* adds a cost method based on the weight.

.. toctree::
   :maxdepth: 2

   design
   releases
