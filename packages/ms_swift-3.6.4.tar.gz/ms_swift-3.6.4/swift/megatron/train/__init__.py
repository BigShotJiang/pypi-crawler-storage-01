# Copyright (c) Alibaba, Inc. and its affiliates.
from .pt import megatron_pt_main
from .rlhf import megatron_rlhf_main
from .sft import megatron_sft_main
