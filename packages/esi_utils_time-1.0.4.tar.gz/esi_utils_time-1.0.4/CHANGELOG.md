## main

## 1.0.4 / 2025-08-01

- numpy>=1.26


## 1.0.3

- Removed deprecated use of pkg_resources
- Cleaned up deployment infrastructure
