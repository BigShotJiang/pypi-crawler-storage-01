# sage_setup: distribution = sagemath-combinat
"""
Hecke Algebras
"""
