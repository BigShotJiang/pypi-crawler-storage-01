# sage_setup: distribution = sagemath-combinat
"""
Abstract ANF to CNF Converter

All ANF to CNF converters must inherit from this class.

AUTHORS:

- Martin Albrecht (2012): first version
"""


class ANF2CNFConverter:
    pass
