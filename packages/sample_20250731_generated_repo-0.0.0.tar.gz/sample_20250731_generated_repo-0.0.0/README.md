# sample_20250731_generated_repo

## Install as package

```bash
pip install sample_20250731_generated_repo
```

```python
from sample_20250731_generated_package import ...
```

## Contributing

```bash
# clone the repo
git clone https://github.com/momomozhang/sample_20250731_generated_repo.git

# install the dev dependencies
make install

# run the tests
make test
```
