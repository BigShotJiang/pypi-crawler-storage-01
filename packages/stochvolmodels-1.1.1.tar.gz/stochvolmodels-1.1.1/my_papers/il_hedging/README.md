This module contains analysis for paper
[Unified Approach for Hedging Impermanent Loss of Liquidity Provision](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4887298) 
by Artur Sepp, Alexander Lipton, and Vladimir Lucic

All figures in the paper are produced by unittests in
https://github.com/ArturSepp/StochVolModels/blob/main/my_papers/il_hedging/run_logsv_for_il_payoff.py

See the description of data and analysis in the paper.