__version__ = "0.51.10"


if __name__ == "__main__":
    print(__version__)
