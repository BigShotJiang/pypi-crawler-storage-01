from inference.models.yolo_world.yolo_world import YOLOWorld
