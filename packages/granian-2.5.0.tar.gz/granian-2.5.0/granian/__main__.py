from granian.cli import entrypoint


entrypoint()
