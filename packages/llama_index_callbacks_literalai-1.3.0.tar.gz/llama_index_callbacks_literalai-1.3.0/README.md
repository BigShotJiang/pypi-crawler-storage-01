# LlamaIndex Callbacks Integration: Literal AI

This integration allows you to get one-click observability of your LlamaIndex RAG pipelines on [Literal AI](https://literalai.com/).

The simplest way to get started and try out Literal AI is to signup on our [cloud instance](https://cloud.getliteral.ai/).
You can then navigate to **Settings**, grab your API key, and start logging !
