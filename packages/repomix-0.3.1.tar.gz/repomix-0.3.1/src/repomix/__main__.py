"""
Repomix module entry point
"""

from repomix.cli import run

if __name__ == "__main__":
    run()
