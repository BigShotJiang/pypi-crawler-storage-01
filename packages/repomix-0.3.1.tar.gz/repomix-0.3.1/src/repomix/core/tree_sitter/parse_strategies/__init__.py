"""Parse strategies for different programming languages."""
