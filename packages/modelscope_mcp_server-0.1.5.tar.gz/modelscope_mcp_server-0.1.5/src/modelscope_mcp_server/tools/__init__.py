"""ModelScope MCP Server tools package."""
