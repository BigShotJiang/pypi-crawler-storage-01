# snz-movie-recsys
SNZ 팀의 챗봇 기반 영화 추천 라이브러리
