

class CounterSettings:
    def __init__(self, pattern: str = ''):
        self.pattern: str = pattern

