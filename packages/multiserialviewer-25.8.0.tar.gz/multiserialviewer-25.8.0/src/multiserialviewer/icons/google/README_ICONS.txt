https://fonts.google.com/icons?selected=Material+Symbols+Outlined:add:FILL@1;wght@400;GRAD@0;opsz@48&icon.size=48&icon.color=%23CCCCCC
https://github.com/google/material-design-icons