# Module Utils

Additional helper functions for creating Clarifai Modules should be placed here so that they can be reused across modules.

This should still not import streamlit as we want to keep clarifai-python-utils lightweight. If you find we need utilities for streamlit itself we should start a new repo for that. Please contact support@clarifai.com to do so.
