from clarifai.cli.base import main

if __name__ == "__main__":
    main()
