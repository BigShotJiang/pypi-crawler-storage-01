# tests/test_smoke.py
"""Smoke tests to verify basic functionality."""

import tempfile
import zipfile
from pathlib import Path

def test_import():
    """Test that the package can be imported."""
    import unzipall
    assert hasattr(unzipall, 'extract')
    assert hasattr(unzipall, 'ArchiveExtractor')

def test_basic_zip_extraction():
    """Test basic ZIP extraction functionality."""
    import unzipall

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create a simple ZIP file
        zip_path = tmpdir / "test.zip"
        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr("hello.txt", "Hello, World!")

        # Extract it
        output_dir = tmpdir / "output"
        result = unzipall.extract(zip_path, output_dir)

        assert result is True
        assert (output_dir / "hello.txt").exists()
        assert (output_dir / "hello.txt").read_text() == "Hello, World!"

def test_list_formats():
    """Test listing supported formats."""
    import unzipall

    formats = unzipall.list_supported_formats()
    assert isinstance(formats, list)
    assert len(formats) > 0
    assert '.zip' in formats

def test_is_supported():
    """Test format support checking."""
    import unzipall

    assert unzipall.is_supported('test.zip')
    assert not unzipall.is_supported('test.unknown')

if __name__ == "__main__":
    test_import()
    test_basic_zip_extraction()
    test_list_formats()
    test_is_supported()
    print("All smoke tests passed! ✅")