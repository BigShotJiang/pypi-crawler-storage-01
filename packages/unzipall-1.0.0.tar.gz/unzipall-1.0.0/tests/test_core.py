# tests/test_core.py
"""Test core functionality of ArchiveExtractor."""

import pytest
from pathlib import Path
import sys

project_root = Path(__file__).parent.parent
src_path = project_root / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

# Import only when needed to avoid dependency issues
def test_import():
    """Test that the package can be imported."""
    from unzipall import ArchiveExtractor
    assert ArchiveExtractor is not None

def test_archiveextractor_init():
    """Test ArchiveExtractor initialization."""
    from unzipall import ArchiveExtractor

    # Test default initialization
    extractor = ArchiveExtractor()
    assert not extractor.verbose
    assert hasattr(extractor, 'format_handlers')
    assert hasattr(extractor, 'logger')

    # Test verbose initialization
    extractor_verbose = ArchiveExtractor(verbose=True)
    assert extractor_verbose.verbose

def test_list_supported_formats():
    """Test listing supported formats."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()
    formats = extractor.list_supported_formats()

    assert isinstance(formats, list)
    assert len(formats) > 0
    assert '.zip' in formats
    assert '.tar' in formats
    assert '.tar.gz' in formats

    # Check that formats are sorted
    assert formats == sorted(formats)

def test_is_supported():
    """Test is_supported for various formats."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()

    # Should support basic formats
    assert extractor.is_supported('test.zip')
    assert extractor.is_supported('test.tar.gz')
    assert extractor.is_supported(Path('test.tar'))

    # Should not support unknown formats
    assert not extractor.is_supported('test.unknown')
    assert not extractor.is_supported('test.xyz')

def test_detect_format():
    """Test format detection."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()

    # Test compound extensions
    assert extractor._detect_format(Path('test.tar.gz')) == '.tar.gz'
    assert extractor._detect_format(Path('test.tar.bz2')) == '.tar.bz2'
    assert extractor._detect_format(Path('test.tar.xz')) == '.tar.xz'

    # Test simple extensions
    assert extractor._detect_format(Path('test.zip')) == '.zip'
    assert extractor._detect_format(Path('test.tar')) == '.tar'

def test_get_available_features():
    """Test getting available features."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()
    features = extractor.get_available_features()

    assert isinstance(features, dict)
    assert 'rarfile' in features
    assert 'py7zr' in features
    assert 'patool' in features
    assert 'libarchive' in features
    assert 'pycdlib' in features
    assert 'python-magic' in features

    # All values should be boolean
    for feature, available in features.items():
        assert isinstance(available, bool)

def test_extract_nonexistent_file(temp_dir):
    """Test extraction of non-existent file."""
    from unzipall import ArchiveExtractor
    from unzipall.exceptions import ArchiveExtractionError

    extractor = ArchiveExtractor()

    with pytest.raises(ArchiveExtractionError, match="Archive file not found"):
        extractor.extract('nonexistent.zip', temp_dir)

def test_extract_unsupported_format(temp_dir):
    """Test extraction of unsupported format."""
    from unzipall import ArchiveExtractor
    from unzipall.exceptions import UnsupportedFormatError

    extractor = ArchiveExtractor()

    # Create a file with unsupported extension
    unsupported_file = temp_dir / "test.unknown"
    unsupported_file.write_text("fake content")

    with pytest.raises(UnsupportedFormatError):
        extractor.extract(unsupported_file, temp_dir / "output")

def test_extract_valid_zip(sample_zip, temp_dir):
    """Test extracting a valid ZIP file."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()
    output_dir = temp_dir / "output"

    result = extractor.extract(sample_zip, output_dir)

    assert result is True
    assert output_dir.exists()
    assert (output_dir / "file_0.txt").exists()
    assert (output_dir / "file_1.txt").exists()
    assert (output_dir / "subdir" / "sub_file.txt").exists()

    # Check content
    content = (output_dir / "file_0.txt").read_text()
    assert "This is content of file 0" in content

def test_extract_tar_gz(sample_tar_gz, temp_dir):
    """Test extracting TAR.GZ file."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()
    output_dir = temp_dir / "output"

    result = extractor.extract(sample_tar_gz, output_dir)

    assert result is True
    assert output_dir.exists()
    assert (output_dir / "file_0.txt").exists()
    assert (output_dir / "subdir" / "sub_file.txt").exists()

def test_extract_gzip(sample_gzip, temp_dir):
    """Test extracting GZIP file."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()
    output_dir = temp_dir / "output"

    result = extractor.extract(sample_gzip, output_dir)

    assert result is True
    assert output_dir.exists()
    # Should create sample.txt (without .gz)
    output_file = output_dir / "sample.txt"
    assert output_file.exists()

    content = output_file.read_text()
    assert "This is a test file for GZIP compression" in content

def test_extract_corrupted_zip(corrupted_zip, temp_dir):
    """Test extracting a corrupted ZIP file."""
    from unzipall import ArchiveExtractor
    from unzipall.exceptions import CorruptedArchiveError

    extractor = ArchiveExtractor()
    output_dir = temp_dir / "output"

    with pytest.raises(CorruptedArchiveError):
        extractor.extract(corrupted_zip, output_dir)

def test_path_traversal_protection(malicious_zip, temp_dir):
    """Test protection against path traversal attacks."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()
    output_dir = temp_dir / "output"

    # Should extract safely without raising an exception
    result = extractor.extract(malicious_zip, output_dir)

    assert result is True
    # Safe file should exist
    assert (output_dir / "safe_file.txt").exists()
    # Dangerous file should not exist outside output dir
    assert not (temp_dir / "etc" / "passwd").exists()

def test_safe_path_method():
    """Test the _is_safe_path method."""
    from unzipall import ArchiveExtractor

    extractor = ArchiveExtractor()
    extract_to = Path("/safe/path")

    # Safe paths
    assert extractor._is_safe_path("file.txt", extract_to)
    assert extractor._is_safe_path("subdir/file.txt", extract_to)
    assert extractor._is_safe_path("./file.txt", extract_to)

    # Unsafe paths
    assert not extractor._is_safe_path("../file.txt", extract_to)
    assert not extractor._is_safe_path("../../etc/passwd", extract_to)
    assert not extractor._is_safe_path("/etc/passwd", extract_to)
    assert not extractor._is_safe_path("C:\\Windows\\System32\\config\\sam", extract_to)