"""Test command-line interface."""

import pytest
import sys
from unittest.mock import patch, MagicMock
from pathlib import Path

from unzipall.cli import main


class TestCLI:
    """Test command-line interface."""

    def test_cli_help(self):
        """Test CLI help output."""
        with patch.object(sys, 'argv', ['unzipall', '--help']):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

    def test_cli_version(self):
        """Test CLI version output."""
        with patch.object(sys, 'argv', ['unzipall', '--version']):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

    def test_cli_list_formats(self):
        """Test listing supported formats."""
        with patch.object(sys, 'argv', ['unzipall', '--list-formats']):
            with patch('builtins.print') as mock_print:
                result = main()
                assert result == 0
                mock_print.assert_called()

    def test_cli_extract_basic(self, sample_zip, temp_dir):
        """Test basic extraction via CLI."""
        output_dir = temp_dir / "cli_output"

        with patch.object(sys, 'argv', ['unzipall', str(sample_zip), str(output_dir)]):
            with patch('builtins.print') as mock_print:
                result = main()
                assert result == 0
                mock_print.assert_called()

    def test_cli_extract_with_password(self, temp_dir):
        """Test extraction with password via CLI."""
        fake_archive = temp_dir / "fake.zip"
        fake_archive.write_bytes(b"fake zip content")

        with patch.object(sys, 'argv', ['unzipall', str(fake_archive), '-p', 'testpass']):
            with patch('unzipall.cli.ArchiveExtractor') as mock_extractor:
                mock_instance = MagicMock()
                mock_extractor.return_value = mock_instance
                mock_instance.extract.return_value = True

                result = main()
                assert result == 0
                mock_instance.extract.assert_called_once()

    def test_cli_verbose_mode(self, sample_zip, temp_dir):
        """Test verbose mode."""
        output_dir = temp_dir / "cli_output"

        with patch.object(sys, 'argv', ['unzipall', str(sample_zip), str(output_dir), '-v']):
            with patch('unzipall.cli.ArchiveExtractor') as mock_extractor:
                mock_instance = MagicMock()
                mock_extractor.return_value = mock_instance
                mock_instance.extract.return_value = True

                result = main()
                assert result == 0
                # Check that verbose=True was passed
                mock_extractor.assert_called_with(verbose=True)

    def test_cli_no_arguments(self):
        """Test CLI with no arguments."""
        with patch.object(sys, 'argv', ['unzipall']):
            result = main()
            assert result == 1  # Should return error code