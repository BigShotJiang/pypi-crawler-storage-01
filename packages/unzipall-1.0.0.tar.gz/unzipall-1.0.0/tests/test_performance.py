"""Performance tests."""

import time
import zipfile

import pytest

from unzipall import ArchiveExtractor


class TestPerformance:
    """Performance tests."""

    @pytest.mark.slow
    def test_large_zip_extraction(self, temp_dir):
        """Test extraction of a large ZIP file."""
        # Create a ZIP with many files
        large_zip = temp_dir / "large.zip"
        with zipfile.ZipFile(large_zip, 'w') as zf:
            for i in range(1000):
                content = f"File {i} content\n" * 100
                zf.writestr(f"file_{i:04d}.txt", content)

        extractor = ArchiveExtractor()
        output_dir = temp_dir / "large_output"

        start_time = time.time()
        result = extractor.extract(large_zip, output_dir)
        extraction_time = time.time() - start_time

        assert result is True
        assert len(list(output_dir.glob("*.txt"))) == 1000

        # Should complete in reasonable time (adjust threshold as needed)
        assert extraction_time < 30  # 30 seconds max

    @pytest.mark.benchmark(group="extraction")
    def test_benchmark_zip_extraction(self, benchmark, sample_zip, temp_dir):
        """Benchmark ZIP extraction speed."""
        def extract_zip():
            output_dir = temp_dir / f"bench_output_{time.time()}"
            extractor = ArchiveExtractor()
            return extractor.extract(sample_zip, output_dir)

        result = benchmark(extract_zip)
        assert result is True