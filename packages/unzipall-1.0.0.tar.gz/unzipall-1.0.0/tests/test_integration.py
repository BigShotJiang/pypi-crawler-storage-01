"""Integration tests for unzipall."""

import zipfile
from pathlib import Path

import unzipall


class TestIntegration:
    """Integration tests using the public API."""

    def test_simple_extract_function(self, sample_zip, temp_dir):
        """Test the simple extract function."""
        output_dir = temp_dir / "integration_output"

        result = unzipall.extract(sample_zip, output_dir)

        assert result is True
        assert output_dir.exists()
        assert (output_dir / "file_0.txt").exists()

    def test_extract_with_default_output(self, temp_dir):
        """Test extraction with default output directory."""
        # Create a ZIP file
        zip_path = temp_dir / "test_archive.zip"
        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr("test_file.txt", "test content")

        # Extract without specifying output (should extract to same dir)
        result = unzipall.extract(zip_path)

        assert result is True
        # Should create test_archive/ directory next to the ZIP
        expected_dir = temp_dir / "test_archive"
        assert expected_dir.exists()
        assert (expected_dir / "test_file.txt").exists()

    def test_is_supported_function(self):
        """Test the is_supported function."""
        assert unzipall.is_supported('test.zip')
        assert unzipall.is_supported(Path('test.tar.gz'))
        assert not unzipall.is_supported('test.unknown')

    def test_list_supported_formats_function(self):
        """Test the list_supported_formats function."""
        formats = unzipall.list_supported_formats()

        assert isinstance(formats, list)
        assert len(formats) > 0
        assert '.zip' in formats

    def test_verbose_extraction(self, sample_zip, temp_dir):
        """Test extraction with verbose output."""
        output_dir = temp_dir / "verbose_output"

        # This should not raise any errors
        result = unzipall.extract(sample_zip, output_dir, verbose=True)

        assert result is True
        assert output_dir.exists()
