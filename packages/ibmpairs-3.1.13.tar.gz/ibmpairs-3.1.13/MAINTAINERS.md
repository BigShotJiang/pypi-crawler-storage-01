# MAINTAINERS

This project relates to [IBM Environmental Intelligence: Geospatial APIs](https://www.ibm.com/products/environmental-intelligence) which is maintained
by the groups [*Sustainability Software* at IBM Software, IBM Corp.](https://www.ibm.com/sustainability) & [*Physical Analytics* at IBM Research, IBM Corp.](https://researcher.watson.ibm.com/researcher/view_group.php?id=6566),
particularly:
- Steffan J. Taylor
- Johannes Schmude
- Marcus Freitag
