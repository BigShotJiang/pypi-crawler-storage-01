# `RealtimeSession`

::: agents.realtime.session.RealtimeSession