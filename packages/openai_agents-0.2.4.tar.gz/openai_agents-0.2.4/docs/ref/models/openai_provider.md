# `OpenAI Provider`

::: agents.models.openai_provider
