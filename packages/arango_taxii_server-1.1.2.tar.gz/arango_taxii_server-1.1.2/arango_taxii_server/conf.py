media_type = "application/stix+json;version=2.1"
taxii_type = "application/taxii+json;version=2.1"

