def dummy_pre_processor(x):
    x = x[:]  # convert to numpy array
    return {"y": x}
