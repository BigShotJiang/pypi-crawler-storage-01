# elasticsearch-interface
Interface to interact with elasticsearch's python client for the use case of EPFL Graph
