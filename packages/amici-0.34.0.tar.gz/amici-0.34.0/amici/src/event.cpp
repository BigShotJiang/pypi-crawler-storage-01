#include "amici/event.h"

namespace amici {} // namespace amici
