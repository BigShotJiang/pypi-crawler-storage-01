# sage_setup: distribution = sagemath-kenzo

from sage.all__sagemath_graphs import *
from sage.all__sagemath_modules import *
