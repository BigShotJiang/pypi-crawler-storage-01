from .html import guess_html  # noqa: F401
from .pdf import guess_pdf  # noqa: F401
from .raw import guess_raw  # noqa: F401
from .rss import guess_rss  # noqa: F401
