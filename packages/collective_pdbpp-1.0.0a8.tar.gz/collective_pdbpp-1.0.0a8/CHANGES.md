# Changelog

## 1.0.0a8 (2025-07-30)

- Fix another error on Startup when the DefaultConfig is not yet initialized

## 1.0.0a7 (2025-07-29)

- Fix error on Startup when the DefaultConfig is not yet initialized

## 1.0.0a6 (2025-05-21)

- Add an `ii` command

## 1.0.0a5 (2025-03-28)

- Do not limit rich output

## 1.0.0a4 (2024-12-18)

- Nothing changed yet.

## 1.0.0a3 (2024-11-29)

- Add features from rich to make debugging easier.

## 1.0.0a2 (2023-11-27)

- Initial release. [ale-rt]
