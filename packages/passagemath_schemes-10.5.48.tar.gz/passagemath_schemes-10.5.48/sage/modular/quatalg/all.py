# sage_setup: distribution = sagemath-schemes

from sage.modular.quatalg.brandt import BrandtModule
