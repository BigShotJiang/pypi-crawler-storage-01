# Django Admin Logs Hub
# A reusable Django app for managing and viewing application logs

__version__ = "1.0.2"
__author__ = "Enes HAZIR"
__email__ = "iletisim@eneshazir.com"
