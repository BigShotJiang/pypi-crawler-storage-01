def hello(name="World"):
    """A real greeting function for the browsergym utils."""
    message = f"A real greeting function for the browsergym utils."
    print(message)
    return message