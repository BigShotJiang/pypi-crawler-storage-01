"""Fantasy Premier League Model Context Protocol (MCP) Server."""

__version__ = "0.1.5"

# Import main components for easy access
from fpl_mcp.__main__ import main