from llama_index.multi_modal_llms.replicate.base import ReplicateMultiModal

__all__ = ["ReplicateMultiModal"]
