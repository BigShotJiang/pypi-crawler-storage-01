"""Tests for the Adversary MCP Server."""
