"""
Ripple1D Package.

This package provides tools and utilities for managing 1-dimensional HEC-RAS simulations.
"""

from .version import __version__
