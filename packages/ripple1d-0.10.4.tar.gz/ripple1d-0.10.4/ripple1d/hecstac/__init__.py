"""Stable port of hecstac (https://github.com/fema-ffrd/hecstac/)."""
