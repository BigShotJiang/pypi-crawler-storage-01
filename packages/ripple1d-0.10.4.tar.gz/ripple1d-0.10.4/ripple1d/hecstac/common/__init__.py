"""Common scripts."""
