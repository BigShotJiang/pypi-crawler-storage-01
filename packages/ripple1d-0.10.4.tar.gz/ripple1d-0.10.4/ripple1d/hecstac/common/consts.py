"""Common constants for HECSTAC."""

S3_PREFIX = "s3://"
HTTPS_PREFIX = "https://"
DEFAULT_CRS = "EPSG:4326"
