"""Initialize conflate."""
