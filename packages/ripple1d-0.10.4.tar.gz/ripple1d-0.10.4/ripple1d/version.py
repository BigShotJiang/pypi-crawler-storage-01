"""ripple1d version."""

__version__ = "0.10.4"
