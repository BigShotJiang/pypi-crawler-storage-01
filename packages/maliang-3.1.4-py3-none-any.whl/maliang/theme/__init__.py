"""A subpackage that provides theme-related features.

Listen to the system's theme and respond accordingly, modify the style of the
window, and more.
"""

from .manager import *
