# LlamaIndex Embeddings Integration: Gaudi
