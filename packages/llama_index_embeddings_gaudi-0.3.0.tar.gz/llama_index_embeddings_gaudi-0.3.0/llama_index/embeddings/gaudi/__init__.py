from llama_index.embeddings.gaudi.base import GaudiEmbedding

__all__ = ["GaudiEmbedding"]
