#  SPDX-FileCopyrightText: 2024-present Hinrich Mahler <chango@mahlerhome.de>
#
#  SPDX-License-Identifier: MIT


# INFO:
# Best reference for how use sphinx testing so far is
# https://github.com/sphinx-doc/sphinx/issues/7008

pytest_plugins = ["sphinx.testing.fixtures"]
