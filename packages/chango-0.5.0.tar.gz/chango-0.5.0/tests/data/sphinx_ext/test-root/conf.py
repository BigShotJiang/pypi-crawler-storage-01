from pathlib import Path

extensions = ["chango.sphinx_ext"]


# Configuration for the chango sphinx directive
chango_pyproject_toml_path = Path(__file__).parent.parent.parent
