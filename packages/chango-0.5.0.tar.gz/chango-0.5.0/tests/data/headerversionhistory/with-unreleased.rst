Unreleased
==========
*unknown*

- comment 1
- a

  multi-line

  comment 2
- comment 3

1.0.2
=====
*2024-01-03*

- comment 1
- a

  multi-line

  comment 2
- comment 3

1.0.1
=====
*2024-01-02*

- comment 1
- a

  multi-line

  comment 2
- comment 3

1.0.0
=====
*2024-01-01*

- comment 1
- a

  multi-line

  comment 2
- comment 3