#  SPDX-FileCopyrightText: 2024-present Hinrich Mahler <chango@mahlerhome.de>
#
#  SPDX-License-Identifier: MIT

from ._cli import app  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    app()
