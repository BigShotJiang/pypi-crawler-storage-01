BackwardCompatibleVersionScanner
================================

.. autoclass:: chango.concrete.BackwardCompatibleVersionScanner
    :members:
    :show-inheritance: