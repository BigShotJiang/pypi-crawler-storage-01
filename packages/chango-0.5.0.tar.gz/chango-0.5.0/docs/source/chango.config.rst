config
======

.. automodule:: chango.config
   :members:
   :inherited-members: TomlSettings, FrozenModel
