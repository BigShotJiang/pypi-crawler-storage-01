ChangeNoteInfo
==============

.. autoclass:: chango.ChangeNoteInfo
    :members:
    :show-inheritance: