HeaderVersionHistory
====================

.. autoclass:: chango.concrete.HeaderVersionHistory
    :members:
    :show-inheritance: