VersionScanner
==============

.. autoclass:: chango.abc.VersionScanner
    :members:
    :show-inheritance: