Version
=======

.. autoclass:: chango.Version
    :members:
    :show-inheritance: