BackwardCompatibleChanGo
=========================

.. autoclass:: chango.concrete.BackwardCompatibleChanGo
    :members:
    :show-inheritance: