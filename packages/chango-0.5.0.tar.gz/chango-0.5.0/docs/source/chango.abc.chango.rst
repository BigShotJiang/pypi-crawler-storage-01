ChanGo
======

.. autoclass:: chango.abc.ChanGo
    :members:
    :show-inheritance: