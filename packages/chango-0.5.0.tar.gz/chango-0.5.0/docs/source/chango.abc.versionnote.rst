VersionNote
===========

.. autoclass:: chango.abc.VersionNote
    :members:
    :show-inheritance: