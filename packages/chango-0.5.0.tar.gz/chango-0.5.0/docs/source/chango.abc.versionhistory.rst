VersionHistory
==============

.. autoclass:: chango.abc.VersionHistory
    :members:
    :show-inheritance: