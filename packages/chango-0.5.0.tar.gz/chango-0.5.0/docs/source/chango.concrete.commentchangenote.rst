CommentChangeNote
=================

.. autoclass:: chango.concrete.CommentChangeNote
    :members:
    :show-inheritance: