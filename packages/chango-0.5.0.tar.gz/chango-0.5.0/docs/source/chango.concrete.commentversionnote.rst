CommentVersionNote
==================

.. autoclass:: chango.concrete.CommentVersionNote
    :members:
    :show-inheritance: