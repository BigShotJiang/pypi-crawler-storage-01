error
=====

.. automodule:: chango.error
    :members:
