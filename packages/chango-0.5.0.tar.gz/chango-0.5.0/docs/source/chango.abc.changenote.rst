ChangeNote
==========

.. autoclass:: chango.abc.ChangeNote
    :members:
    :show-inheritance: