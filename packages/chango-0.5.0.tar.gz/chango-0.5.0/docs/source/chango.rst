chango
======

.. automodule:: chango
    :members: __version__

.. toctree::
    :titlesonly:

    chango.changenoteinfo
    chango.version
    chango.abc
    chango.concrete
    