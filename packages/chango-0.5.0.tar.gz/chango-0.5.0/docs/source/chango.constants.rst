constants
=========

.. automodule:: chango.constants
   :members:
