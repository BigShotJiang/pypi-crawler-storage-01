DirectoryChanGo
===============

.. autoclass:: chango.concrete.DirectoryChanGo
    :members:
    :show-inheritance: