DirectoryVersionScanner
=======================

.. autoclass:: chango.concrete.DirectoryVersionScanner
    :members:
    :show-inheritance: