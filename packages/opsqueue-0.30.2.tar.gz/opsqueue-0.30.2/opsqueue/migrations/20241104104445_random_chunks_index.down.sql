DROP INDEX random_chunks_order;

ALTER TABLE chunks DROP COLUMN random_order;
