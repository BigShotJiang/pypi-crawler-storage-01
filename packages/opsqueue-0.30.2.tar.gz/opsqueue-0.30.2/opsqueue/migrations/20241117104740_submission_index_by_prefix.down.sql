DROP INDEX submissions_prefix;
DROP INDEX submissions_completed_prefix;
DROP INDEX submissions_failed_prefix;
