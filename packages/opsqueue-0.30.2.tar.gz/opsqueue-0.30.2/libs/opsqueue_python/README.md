The Python client library for the Opsqueue lightweight batch processing queue system.

## Installation instructions

1. Install the Python client using `pip`, `uv` or similar.
2. Install the Opsqueue binary, using `cargo install opsqueue` (if you do not have Cargo/Rust installed yet, follow the instructions at https://rustup.rs/ first)
3. Enjoy!

## More Info

Find the full README with examples at https://github.com/channable/opsqueue
