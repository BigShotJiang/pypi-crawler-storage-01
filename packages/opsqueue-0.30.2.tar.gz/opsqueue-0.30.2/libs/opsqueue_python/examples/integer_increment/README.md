In this very basic example,
the producer creates a submission containing the numbers 0..N for some N,
and then the consumer will walk over all these numbers and increment them by 1.
