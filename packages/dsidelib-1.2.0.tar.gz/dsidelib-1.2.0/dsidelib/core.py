import disco
import telega

async def run():
    await disco.main()
    await telega.main()
