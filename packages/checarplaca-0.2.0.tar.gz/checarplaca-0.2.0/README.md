# checarplaca

Um pacote Python para consultar dados da placa do veículo.

## Instalação

```bash
pip install checarplaca
```

## Como usar

```bash
checar_placa("{Placa}")
```
