# Changelog

## 0.1.0 (2025-07-31)

Full Changelog: [v0.0.1-alpha.0...v0.1.0](https://github.com/spatiali-se/spatialise-python/compare/v0.0.1-alpha.0...v0.1.0)

### Features

* **client:** support file upload requests ([49c90b0](https://github.com/spatiali-se/spatialise-python/commit/49c90b05fbb2e5ad9b613a51c0ab14971edc66b7))


### Chores

* update SDK settings ([3e73e00](https://github.com/spatiali-se/spatialise-python/commit/3e73e00b3cae0cfc789d5f2596c9915092dcd418))
* update SDK settings ([a76165b](https://github.com/spatiali-se/spatialise-python/commit/a76165b7f411c3c9eb3205910fd2d1d13ccbc38b))
