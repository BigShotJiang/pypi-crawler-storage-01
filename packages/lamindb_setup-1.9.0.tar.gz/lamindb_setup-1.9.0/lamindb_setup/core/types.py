from lamindb_setup.types import UPathStr  # backward compatibility
