from llama_index.callbacks.opik.base import opik_callback_handler

__all__ = ["opik_callback_handler"]
