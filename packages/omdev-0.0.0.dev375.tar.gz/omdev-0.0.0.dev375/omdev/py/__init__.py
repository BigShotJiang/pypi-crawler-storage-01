"""
Python source-related utilities.
"""
