"""Depless, self-contained scripts with no reason to be imported from any other module."""
