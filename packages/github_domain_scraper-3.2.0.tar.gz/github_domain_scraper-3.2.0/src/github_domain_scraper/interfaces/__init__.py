from github_domain_scraper.interfaces.stargazer_profile import StargazerProfile
from github_domain_scraper.interfaces.user_profile import UserProfile

__all__ = ["StargazerProfile", "UserProfile"]
