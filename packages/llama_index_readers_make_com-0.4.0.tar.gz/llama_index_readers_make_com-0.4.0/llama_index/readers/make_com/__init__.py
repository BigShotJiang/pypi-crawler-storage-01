from llama_index.readers.make_com.base import MakeWrapper

__all__ = ["MakeWrapper"]
