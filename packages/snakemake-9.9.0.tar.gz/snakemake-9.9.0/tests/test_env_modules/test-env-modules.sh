echo test > $1
