import json
import os
from agoraiot import logger
import traceback
import requests

# ESP STABILIZATION API
URLPREFIX = "http://"
STABILIZATION = os.getenv('STABILIZATION_URI')
if STABILIZATION != None:
    STABILIZATION_URL = URLPREFIX + STABILIZATION
else:
    STABILIZATION_URL = URLPREFIX + "esp-stabilization-model:8080"

STABILIZATION_API = "/predict"
HTTP_HEADER_STABILIZATION = {
    'Content-type': 'application/json',
    'Accept': 'text/plain'
}

class StabilizationApi:    

    def workflow_stabilization(self, data_payload):
        try:
            self.predicted_label = 0
            self.predicted_probability = 0
            api_url=STABILIZATION_URL + STABILIZATION_API
            logger.debug("************api url - " + str(api_url))  
            response = requests.post(url=api_url, data=json.dumps(data_payload), headers=HTTP_HEADER_STABILIZATION)
            
            logger.debug(response.text)
            if response.status_code == 200:
                self.api_response = json.loads(response.text)
                self.predicted_label = self.api_response["predicted_label"]
                self.predicted_probability = self.api_response["predicted_probability"]

                logger.debug("Stabilization ML model api call successful")
                return True
            else:
                logger.debug("Stabilization ML model api call failed")
                return False

        except requests.exceptions.RequestException as e:
            logger.debug("Error in api call - "+str(e))
            logger.debug(traceback.format_exc())
            return False