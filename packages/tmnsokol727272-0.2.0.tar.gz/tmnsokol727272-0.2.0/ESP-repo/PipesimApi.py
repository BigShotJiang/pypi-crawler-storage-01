import json
import os
import traceback
import requests
import base64
import re
from datetime import datetime
from scipy.stats import linregress
from agoraiot import logger,bus_client,AgoraTimeStamp,config,IoPoint,IoDataReportMsg,IoDeviceData
from _utilities import show_publish_table

if "APP_TAGS" in os.environ:
    tags_version = os.getenv("APP_TAGS")
    if tags_version =="old":
        import tag_names_old as tag_names
    else:
        import tag_names as tag_names
else:
    import tag_names as tag_names


#URLs for API calls
PIPESIM_URI = config['Api:PIPESIM_URI']
VFM_URI = config['Api:VFM_URI']
GLK_URI = config['Api:GLK_URI']

#APIs for PIPESIM
SIM_HEAD = config['Api:SIM_HEAD']
SIM_PI = config['Api:SIM_PI']
CAL_HEAD =config['Api:CAL_HEAD']
CAL_PI = config['Api:CAL_PI']
LIC_UPDATE =config['Api:LIC_UPDATE']
LIC_VALIDITY = config['Api:LIC_VALIDITY']

#APIs for Smart Alarms 
VFM_DEP = config['Api:VFM_DEP']

GLK_API = config['Api:GLK_API']
VFM_RESET = config['Api:VFM_RESET']
MWT_RESET = config['Api:MWT_RESET']
MWT_RESET_ALL = config['Api:MWT_RESET_ALL']
VFM_RESET_ALL = config['Api:VFM_RESET_ALL']
FLOWRATE_RESET = config['Api:FLOWRATE_RESET']
FLOWRATE_RESET_ALL = config['Api:FLOWRATE_RESET_ALL']

calibration_file = config["Path:Calibration_FileName"]
model_text_file = config["Path:Model_Text_FileName"] 
license_filename = config["Path:License_FileName"]


if "PIPE_SIM_AUTH" in os.environ:
    PIPESIM_AUTH = os.getenv('PIPE_SIM_AUTH')
else:
    PIPESIM_AUTH = 'asdf'

HTTP_HEADER = {
    "Content-type": f"{config['Api:Content-Type-Json']}",
    "Authorization": f"Bearer {PIPESIM_AUTH}"
}

HTTP_HEADER_LICENSE = {
    "Content-type": f"{config['Api:Content-Type-Stream']}",
    "Authorization": f"Bearer {PIPESIM_AUTH}"
}

HTTP_HEADER_SMART_ALARM = {
    'Content-type': f"{config['Api:Content-Type-Json']}",
    'Accept': 'text/plain'
}

class PipeSimApi:

    def __init__(self, model_text_filename, calibration_filename, license_filename,slave_id,virtual_id):

        self.model_text_filename = model_text_filename        
        self.calibration_filename = calibration_filename
        self.license_filename = license_filename
        self.slave_id = slave_id
        self.virtual_id = str(virtual_id)
        self.model_initialized=False     
        self.model_text_pi = ""
        self.model_text_head = ""
        self.head_calibration_threshold = 5.0
        self.pi_calibartion_threshold = 5.0
        self.well_test_water_cut = self.well_test_api = self.well_test_gor = 0
        self.well_test_liquid_flowrate = 0
        self.well_test_intake_pressure = 0
        self.well_test_discharge_pressure =  0
        self.well_test_drive_frequecny = 0
        self.well_test_motor_temperature =0
        self.well_test_reservoir_pressure = 0
        self.well_test_reservoir_temperature = 0
        self.well_test_date = 0
        self.motor_temperature_key = \
        self.well_test_key = self.drive_frequency_key = \
        self.discharge_pressure_key = self.intake_pressure_key = False
        self.model_created_date  = 0
        self.flow_rate_pi = 0
        self.flow_rate_head = 0
        self.virtual_liquid_rate = 0
        self.calibration_flag = 0
        self.pred_label_gas_interference = 0
        self.pred_label_gas_lock = 0
        self.bubble_point_pressure = self.drive_frequency_tolerance = self.flowrate_selection_interval = self.slope_calculation_interval = 0
        self.reset_flowrate = self.reset_flowrate_all = 0
        self.reset_mwt_alarm = self.reset_pumpwear_alarm = self.reset_mwt_alarm_all = self.reset_pumpwear_alarm_all = 0
        self.head_values = []
        self.pi_values = []
        self.flow_indicator_values = []
        self.data_count = []
        self.stabilization_threshold = 60
        self.stabilization_points_delay = 60
        self.stabilization_probability_threshold = 75
        self.bubble_point_pressure = float(self.load_default_data(tag_names.bubble_point_pressure_tag,self.bubble_point_pressure))
        self.drive_frequency_tolerance = float(self.load_default_data(tag_names.drive_frequency_tolerance_tag,self.drive_frequency_tolerance))
        self.flowrate_selection_interval = float(self.load_default_data(tag_names.flowrate_selection_interval_tag,self.flowrate_selection_interval))
        self.slope_calculation_interval = float(self.load_default_data(tag_names.slope_calculation_interval_tag,self.slope_calculation_interval))
        self.stabilization_threshold = float(self.load_default_data(tag_names.stabilization_threshold_tag,self.stabilization_threshold))
        self.stabilization_probability_threshold = float(self.load_default_data(tag_names.stabilization_probability_threshold_tag,self.stabilization_probability_threshold))
        self.stabilization_points_delay = float(self.load_default_data(tag_names.stabilization_points_delay_tag,self.stabilization_points_delay))
        
        self.load_model_text()
        self.load_welltest_data()
        self.drive_freq = 0
        self.well_start = 0
        self.operational_drive_frequency = 0
        self.step_interval = float((config["RampTimer:Step_Interval"]))
        self.step_size = float((config["RampTimer:Step_Size"]))
    def load_default_data(self,tag_name,default_value):
        appconfig_device_mapping = 'AppConfig:DeviceMapping:' + self.slave_id
        if tag_name in config[appconfig_device_mapping]:
            value = float(config[appconfig_device_mapping +':'+tag_name])
        else:
            self.save_alternate_config(tag_name, default_value)
            value = default_value
        return value
    
    
        """
        This function loads a model text file and initializes certain variables with its contents.
        @returns The method is returning a tuple containing two values: the boolean value of
        `model_initialized` and a string message.
    """
    def load_model_text(self):
        try:
            if os.path.exists(self.model_text_filename):
                with open(self.model_text_filename, 'r') as pi_file:
                    file_content_dict = json.loads(pi_file.read())
                    self.model_text_pi = file_content_dict[tag_names.pi_model_text_tag]
                    self.model_text_head = file_content_dict[tag_names.head_model_text_tag]
                    self.well_test_water_cut = file_content_dict[tag_names.well_test_water_cut_tag]
                    self.well_test_gor = file_content_dict[tag_names.well_test_gor_tag]
                    self.well_test_api = file_content_dict[tag_names.well_test_api_tag]
                    self.head_calibration_threshold = file_content_dict[tag_names.head_calibration_threshold_tag]
                    self.pi_calibartion_threshold = file_content_dict[tag_names.pi_calibartion_threshold_tag]
                    if self. model_text_pi != " " and self.model_text_head != " ":             
                        self.model_initialized = True
                    message = "Read files"
                    self.model_created_date = self.model_date_extract()          
            else:
                self.model_initialized = False
                message = "Model text not available"
                logger.error(message)
        except Exception as error:
            self.model_initialized = False
            logger.error(traceback.format_exc())
            logger.exception(error,"Exception occurred in load model text.")  
            
    
    def load_welltest_data(self):
        try:
            if os.path.exists(self.calibration_filename):
                with open(self.calibration_filename, 'r') as data:
                    calibration_dict = json.loads(data.read())
                    self.well_test_liquid_flowrate = calibration_dict[tag_names.well_test_liquid_flowrate_tag]
                    self.well_test_motor_temperature = calibration_dict[tag_names.well_test_motor_temperature_tag]
                    self.well_test_discharge_pressure = calibration_dict[tag_names.well_test_discharge_pressure_tag]
                    self.well_test_intake_pressure = calibration_dict[tag_names.well_test_intake_pressure_tag]
                    self.well_test_drive_frequecny = calibration_dict[tag_names.well_test_drive_frequency_tag]
                    self.well_test_reservoir_pressure = calibration_dict[tag_names.well_test_reservoir_pressure_tag]
                    self.well_test_reservoir_temperature = calibration_dict[tag_names.well_test_reservoir_temperature_tag]
                    message = "Read files"
            else:
                message = "Calibration file not avaiable"
                logger.error(message)
        except Exception as error:
            self.model_initialized = False
            logger.error(traceback.format_exc())
            logger.exception(error,"Exception occurred in load model text.")  
            
    def model_date_extract(self):
        try:
            model_text = base64.b64decode(self.model_text_head).decode('utf-8')
            model_text_line = model_text.split('\n')[0]
            date_regex = r"\b\w+, (\w+ \d+, \d{4}) \d{2}:\d{2}:\d{2} \w+\b"
            match = re.search(date_regex, model_text_line)
            if match:
                date = match.group(1)
                date_format = "%B %d, %Y"
                datetime_obj = datetime.strptime(date, date_format)
                formatted_date = int(datetime_obj.strftime("%d%m%Y"))
                logger.info("..........................")
                logger.info("PIPESIM Model is created on: {}".format(formatted_date)) # type: ignore
                logger.info("..........................")
                return formatted_date
            else:
                return 0
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return 0 
        
    def esp_real_tags_with_units(self,real_tags,timestamp):
        
        try:
            tags = {}        
            tags[tag_names.average_amps_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = real_tags[tag_names.average_amps_tag].value) 
            tags[tag_names.drive_frequency_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = real_tags[tag_names.drive_frequency_tag].value)
            tags[tag_names.discharge_pressure_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = real_tags[tag_names.discharge_pressure_tag].value)
            tags[tag_names.intake_pressure_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = real_tags[tag_names.intake_pressure_tag].value) 
            tags[tag_names.motor_temperature_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = real_tags[tag_names.motor_temperature_tag].value)
            tags[tag_names.intake_temperature_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = real_tags[tag_names.intake_temperature_tag].value)     
            return tags
        
        except Exception as error:
            logger.exception(error,"Exception occurred in hbm flow resposne.")  
            logger.error(traceback.format_exc())
            return {}

    def hbm_flow_response(self,timestamp):
        try:
            tags = {}        
            tags[tag_names.flow_rate_head_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.flow_rate_head) 
            tags[tag_names.flow_rate_pi_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.flow_rate_pi)
            tags[tag_names.calibration_flag_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.calibration_flag)
            tags[tag_names.model_created_date_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.model_created_date)      
            tags = self.setpoint_tags(tags,timestamp)
            logger.info("*" * 17 + "  Virtual Tags(Edge) "+"*" * 17)
            show_publish_table(tags)
            return tags
        
        except Exception as error:
            logger.exception(error,"Exception occurred in hbm flow resposne.")  
            logger.error(traceback.format_exc())
            return {}


    def setpoint_tags(self, tags,timestamp):
        try:      
            tags[tag_names.head_calibration_threshold_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.head_calibration_threshold) 
            tags[tag_names.pi_calibartion_threshold_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.pi_calibartion_threshold)
            tags[tag_names.bubble_point_pressure_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.bubble_point_pressure)
            tags[tag_names.flowrate_selection_interval_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.flowrate_selection_interval) # type: ignore
            tags[tag_names.slope_calculation_interval_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.slope_calculation_interval)  # type: ignore
            tags[tag_names.drive_frequency_tolerance_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.drive_frequency_tolerance)  # type: ignore
            tags[tag_names.reset_mwt_alarm_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.reset_mwt_alarm)  # type: ignore
            tags[tag_names.reset_mwt_alarm_all_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.reset_mwt_alarm_all)  # type: ignore
            tags[tag_names.reset_pumpwear_alarm_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.reset_pumpwear_alarm)  # type: ignore
            tags[tag_names.reset_pumpwear_alarm_all_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.reset_pumpwear_alarm_all)  # type: ignore
            tags[tag_names.well_test_water_cut_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_water_cut)
            tags[tag_names.well_test_date_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_date)
            tags[tag_names.well_test_liquid_flowrate_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_liquid_flowrate)
            tags[tag_names.well_test_intake_pressure_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_intake_pressure) 
            tags[tag_names.well_test_discharge_pressure_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_discharge_pressure)
            tags[tag_names.well_test_drive_frequency_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_drive_frequecny)
            tags[tag_names.well_test_motor_temperature_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_motor_temperature)      
            tags[tag_names.well_test_api_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_api) 
            tags[tag_names.well_test_gor_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_gor)
            tags[tag_names.well_test_reservoir_pressure_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_reservoir_pressure)
            tags[tag_names.well_test_reservoir_temperature_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_test_reservoir_temperature)
            tags[tag_names.operational_drive_frequency_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.operational_drive_frequency)
            tags[tag_names.well_start_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.well_start)
            tags[tag_names.step_interval_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.step_interval)
            tags[tag_names.step_size_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.step_size)
            tags[tag_names.head_model_text_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = 0, value_str = self.model_text_head)
            tags[tag_names.pi_model_text_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = 0, value_str = self.model_text_pi)
            tags[tag_names.reset_flowrate_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.reset_flowrate)
            tags[tag_names.reset_flowrate_all_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.reset_flowrate_all)
            tags[tag_names.stabilization_threshold_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.stabilization_threshold) # type: ignore
            tags[tag_names.stabilization_probability_threshold_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.stabilization_probability_threshold)  # type: ignore
            tags[tag_names.stabilization_points_delay_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.stabilization_points_delay)  # type: ignore
            return tags
        
        except Exception as error:
            logger.exception(error,"Exception occurred in setpoint tags.") 
            logger.error(traceback.format_exc()) 
            return {}

    def vfm_virtual_tags(self,data,timestamp):
        try:
            if self.flow_rate_head > 0 and self.flow_rate_pi > 0:
                self.virtual_liquid_rate = self.flow_rate_selections(data)

            elif self.flow_rate_head > 0 and self.flow_rate_pi < 0:
                self.virtual_liquid_rate = self.flow_rate_head
            else:
                self.virtual_liquid_rate = 0
            virtual_water_rate = round(self.virtual_liquid_rate*(self.well_test_water_cut/100))
            virtual_oil_rate = self.virtual_liquid_rate - virtual_water_rate

            tags = {}        
            tags[tag_names.virtual_liquid_rate_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.virtual_liquid_rate) 
            tags[tag_names.virtual_water_rate_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = virtual_water_rate)
            tags[tag_names.virtual_oil_rate_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = virtual_oil_rate) 
            logger.info("*" * 17 + " VIRTUAL FLOWRATES  DATA  "+"*" * 17)
            show_publish_table(tags)  
            return tags
        
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return {}


    def vfm_alarms_response(self,timestamp):
        try: 
            tags = {}        
            tags[tag_names.operational_condition_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.operational_condition_alarm) 
            tags[tag_names.operational_condition_flag_raw_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.operational_condition_flag)
            tags[tag_names.pi_drop_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.pi_drop_alarm)
            tags[tag_names.pump_low_eff_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.pump_low_eff_alarm) 
            tags[tag_names.pump_wear_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.pump_wear_alarm)
            tags[tag_names.tubing_leak_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.tub_leak_alarm) 
            logger.info("*" * 17 + " VFM BASED SMART ALARMS  "+"*" * 17)
            show_publish_table(tags)  
            return tags
        
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return {}

    def glk_alarms_response(self,timestamp):
        try: 
            tags = {}        
            tags[tag_names.gas_interference_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.pred_label_gas_interference) 
            tags[tag_names.gas_lock_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.pred_label_gas_lock)
            tags[tag_names.emulsion_solid_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.pred_label_emulsion_solid)
            tags[tag_names.motor_temperauture_indicator_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.motor_temperauture_indicator)
            tags[tag_names.motor_temperature_defaut_mean_tag] = IoPoint(quality_code=0, timestamp=int(timestamp), value = self.motor_temperature_defaut_mean)
            logger.info("*" * 17 + " NON-VFM BASED SMART ALARM  "+"*" * 17)
            show_publish_table(tags)
            return tags
        
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return {}
        
    def slope_calculation(self,data):
        try:
            x_values = list(range(1, len(data) + 1))
            slope, _, _, _, _ = linregress(x_values, data)
            return slope
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return 0
        
        
    def flow_rate_selections(self,tags):
        try:
            logger.debug("...................flow rate selection workflow...............")
            # logging.debug(data)
            flow_indicator = count_of_pi = 0
            amp = tags[tag_names.average_amps_tag].value
            pip = tags[tag_names.intake_pressure_tag].value
            pdp = tags[tag_names.discharge_pressure_tag].value
            logger.debug("Average Amps: {}, Intake Pressure: {}. Discharge pressure: {}".format(str(amp),str(pip),str(pdp)))
            flow_indicator = (1000*amp)/(pdp - pip) #flow indicator using amp,pdp,pip
            self.head_values.append(self.flow_rate_head) #appending data of flowrate head
            self.pi_values.append(self.flow_rate_pi)   #appending data of flowrate pi
            self.flow_indicator_values.append(flow_indicator)   #appending data of flow indicator
            logger.debug("head values: {}".format(str(self.head_values)))
            logger.debug("pi values: {}".format(str(self.pi_values)))
            logger.debug("indicator values: {}".format(str(self.flow_indicator_values)))
            logger.debug("FlowIndicator: {}".format(str(flow_indicator)))
            
            flowrate = self.flow_rate_selection_data()   
            
            count_of_pi = self.data_count.count("pi")
            logger.debug("pi count: %d" %count_of_pi)
            flowrate = self.flow_rate_pi if count_of_pi >= self.flowrate_selection_interval else self.flow_rate_head # type: ignore
            if len(self.data_count) == self.flowrate_selection_interval: 
                logger.debug("data count:{}".format(str(self.data_count)))
                self.data_count.pop(0)
            else:
                if len(self.data_count) > self.flowrate_selection_interval: # type: ignore
                    del self.data_count[0:int(len(self.data_count)-self.flowrate_selection_interval+1)] # type: ignore
                    
            logger.debug("flow rate head: {}".format(str(self.flow_rate_head)))
            logger.debug("flow rate pi: {}".format(str(self.flow_rate_pi)))
            logger.debug("flowrate: {}".format(str(flowrate)))
            logger.debug("............................................................................")
            return flowrate
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return 0

    def flow_rate_selection_data(self):
        try:
            head_slope = pi_slope = flow_indicator_slope = head_or_pi = head_or_flow_indicator = head_pi_differnece = 0
            if len(self.head_values) == self.slope_calculation_interval or len(self.pi_values) == self.slope_calculation_interval or len(self.flow_indicator_values) == self.slope_calculation_interval: #slope calculation of 20 data points
                    head_slope =self.slope_calculation(self.head_values)
                    pi_slope =self.slope_calculation(self.pi_values)
                    flow_indicator_slope = self.slope_calculation(self.flow_indicator_values)
                    logger.debug("head slope: {}, pi slope: {}, flow indicato slope: {}".format(str(head_slope),str(pi_slope),str(flow_indicator_slope)))
                    head_or_pi = (head_slope >= 0) == (pi_slope >= 0)
                    head_or_flow_indicator = (head_slope >= 0) == (flow_indicator_slope >= 0)
                    head_pi_differnece = (100*(self.flow_rate_head-self.flow_rate_pi))/self.flow_rate_head
                    logger.debug("head or pi: {}, head or flow indicator: {}".format(str(head_or_pi),str(head_or_flow_indicator)))
                    logger.debug("head pip difference:{}".format(str(head_pi_differnece))) 
                    if head_pi_differnece <= 5 or head_or_flow_indicator == True or (head_or_flow_indicator == False and head_or_pi == True):
                        self.data_count.append("head")
                        logger.debug(".........FLOW RATE HEAD is selected.........")
                    else:
                        self.data_count.append("pi")
                        logger.debug(".........FLOW RATE PI is selected...........")
                    self.pi_values.pop(0)
                    self.head_values.pop(0)
                    self.flow_indicator_values.pop(0)
            else:
                flowrate = self.flow_rate_head
                if len(self.head_values) > self.slope_calculation_interval: # type: ignore
                    end_index = int(len(self.head_values)-self.slope_calculation_interval+1) # type: ignore
                    del self.head_values[0:end_index]
                    del self.pi_values[0:end_index]
                    del self.flow_indicator_values[0:end_index]
                return flowrate
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return self.flow_rate_head


    """
        This function updates the configuration settings of a system based on input tags and returns a
        boolean value indicating whether any updates were made.
        @param tags - A dictionary containing the updated values for various parameters.
        @returns a boolean value indicating whether any of the configuration parameters have been
        updated or not.
        Update the value of all required tags
    """
    def update_config(self, tags, drive_freq): 
        ret = False 
        self.drive_freq = drive_freq
        try:  
            ret1 = self.update_well_test_tag(tags) 
            ret2 = self.save_head_calibration_threshold(tags)
            ret3 = self.save_pi_calibartion_threshold(tags)  
            ret4 = self.save_bubble_point_pressure(tags)  
            ret5 = self.save_drive_frequency_tolerance(tags)
            ret6 = self.save_flowrate_selection_interval(tags) 
            ret7 = self.save_slope_calculation_interval(tags)
            ret8 = self.make_workflow_mwt_alarm_reset(tags)
            ret9 = self.make_workflow_vfm_dependent_alarm_reset(tags)
            ret10 = self.do_esp_startup(tags)
            ret11 = self.make_workflow_mwt_alarm_reset_all(tags)
            ret12 = self.make_workflow_vfm_dependent_alarm_reset_all(tags)
            ret13 = self.make_workflow_flowrate_reset(tags)
            ret14 = self.make_workflow_flowrate_reset_all(tags)
            ret15 = self.save_head_model(tags) 
            ret16 = self.save_pi_model(tags) 
            ret17 = self.save_stabilization_threshold(tags)
            ret18 = self.save_stabilization_probability_threshold(tags)
            ret19 = self.save_stabilization_points_delay(tags)
            
            ret = ret1 or ret2 or ret3 or ret4 or ret5 or ret6 or ret7 or ret8 or ret9 or ret10 or ret11 or ret12 or ret13 or ret14 or ret15 or ret16 or ret17 or ret18 or ret19
            
            if self.check_prepare_data_caliberation():
                data = self.prepare_data_caliberation()
                logger.debug(str(data))
                logger.debug("......Calling Calibration API........")
                _, message = self.calibrate(data)
                logger.debug("response from calibration: {}".format(message))
                self.reset_calibration_flags()
            else:
                self.calibration_flag = -1
                logger.debug("......Calibration data for some tags are missing........")

        except Exception as error:
            logger.exception(error,"Exception occurred in update_config.") 
            logger.error(traceback.format_exc())  
            ret = False       
        return ret
    def reset_calibration_flags(self):
        try:
            self.motor_temperature_key = \
            self.well_test_key = self.drive_frequency_key = \
            self.discharge_pressure_key = self.intake_pressure_key = False
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())

    def check_prepare_data_caliberation(self):
        return self.well_test_key == True and \
                self.drive_frequency_key == True and \
                self.discharge_pressure_key == True and \
                self.intake_pressure_key == True and \
                self.motor_temperature_key == True

    def do_esp_startup(self, tags):
        ret = False
        try:
            if (self.drive_freq > 0):
                self.well_start = 0
                self.operational_drive_frequency = 0
                ret = False
            else:
                if tags.get(tag_names.well_start_tag) is not None:
                    self.well_start = tags[tag_names.well_start_tag].value
                    self.process_setpoint_io_data(tag_names.well_start_tag,self.well_start)
                if tags.get(tag_names.operational_drive_frequency_tag) is not None:
                    self.operational_drive_frequency = tags[tag_names.operational_drive_frequency_tag].value
                    self.process_setpoint_io_data(tag_names.operational_drive_frequency_tag,self.operational_drive_frequency)
                if tags.get(tag_names.step_interval_tag) is not None:
                    self.step_interval = tags[tag_names.step_interval_tag].value
                    self.process_setpoint_io_data(tag_names.step_interval_tag,self.step_interval)
                if tags.get(tag_names.step_size_tag) is not None:
                    self.step_size = tags[tag_names.step_size_tag].value
                    self.process_setpoint_io_data(tag_names.step_size_tag,self.step_size)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in esp_startup.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret
    
    def make_workflow_vfm_dependent_alarm_reset(self, tags):
        ret = False
        try:
            if tags.get(tag_names.reset_pumpwear_alarm_tag) is not None:
                self.reset_pumpwear_alarm = tags[tag_names.reset_pumpwear_alarm_tag].value
                self.process_setpoint_io_data(tag_names.reset_pumpwear_alarm_tag,self.reset_pumpwear_alarm)
                if self.reset_pumpwear_alarm == 1:
                    self.workflow_vfm_dependent_alarm_reset()
                    ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in make_workflow_vfm_dependent_alarm_reset.") 
            logger.error(traceback.format_exc())  
            ret = False 
        return ret
    def make_workflow_vfm_dependent_alarm_reset_all(self, tags):
        ret = False
        try:
            if tags.get(tag_names.reset_pumpwear_alarm_all_tag) is not None:
                self.reset_pumpwear_alarm_all = tags[tag_names.reset_pumpwear_alarm_all_tag].value
                self.process_setpoint_io_data(tag_names.reset_pumpwear_alarm_all_tag,self.reset_pumpwear_alarm_all)
                if self.reset_pumpwear_alarm_all == 1:
                    self.workflow_vfm_dependent_alarm_reset_all()
                    ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in make_workflow_vfm_dependent_alarm_reset_all.") 
            logger.error(traceback.format_exc())  
            ret = False 
        return ret

    def make_workflow_mwt_alarm_reset(self, tags):
        ret = False
        try:
            if tags.get(tag_names.reset_mwt_alarm_tag) is not None:
                self.reset_mwt_alarm = tags[tag_names.reset_mwt_alarm_tag].value
                self.process_setpoint_io_data(tag_names.reset_mwt_alarm_tag,self.reset_mwt_alarm)
                if self.reset_mwt_alarm == 1:
                    self.workflow_mwt_alarm_reset()
                    ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in make_workflow_mwt_alarm_reset.") 
            logger.error(traceback.format_exc())  
            ret = False 
        return ret     
    def make_workflow_mwt_alarm_reset_all(self, tags):
        ret = False
        try:
            if tags.get(tag_names.reset_mwt_alarm_all_tag) is not None:
                self.reset_mwt_alarm_all = tags[tag_names.reset_mwt_alarm_all_tag].value
                self.process_setpoint_io_data(tag_names.reset_mwt_alarm_all_tag,self.reset_mwt_alarm_all)
                if self.reset_mwt_alarm_all == 1:
                    self.workflow_mwt_alarm_reset_all()
                    ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in make_workflow_mwt_alarm_reset_All.") 
            logger.error(traceback.format_exc())  
            ret = False 
        return ret   

    def make_workflow_flowrate_reset(self, tags):
        ret = False
        try:
            if tags.get(tag_names.reset_flowrate_tag) is not None:
                self.reset_flowrate = tags[tag_names.reset_flowrate_tag].value
                self.process_setpoint_io_data(tag_names.reset_flowrate_tag,self.reset_flowrate)
                if self.reset_flowrate == 1:
                    self.workflow_flowrate_reset()
                    ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in make_workflow_flowrate_reset.") 
            logger.error(traceback.format_exc())  
            ret = False 
        return ret     
    def make_workflow_flowrate_reset_all(self, tags):
        ret = False
        try:
            if tags.get(tag_names.reset_flowrate_all_tag) is not None:
                self.reset_flowrate_all = tags[tag_names.reset_flowrate_all_tag].value
                self.process_setpoint_io_data(tag_names.reset_flowrate_all_tag,self.reset_flowrate_all)
                if self.reset_flowrate_all == 1:
                    self.workflow_flowrate_reset_all()
                    ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in make_workflow_flowrate_reset_all.") 
            logger.error(traceback.format_exc())  
            ret = False 
        return ret         

    def save_slope_calculation_interval(self, tags):
        ret = False
        try:
            if tags.get(tag_names.slope_calculation_interval_tag) is not None:
                self.slope_calculation_interval = tags[tag_names.slope_calculation_interval_tag].value
                self.save_alternate_config(tag_names.slope_calculation_interval_tag,self.slope_calculation_interval)
                self.process_setpoint_io_data(tag_names.slope_calculation_interval_tag,self.slope_calculation_interval)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_slope_calculation_interval.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret                
    
    def save_flowrate_selection_interval(self, tags):
        ret = False
        try:
            if tags.get(tag_names.flowrate_selection_interval_tag) is not None:
                self.flowrate_selection_interval = tags[tag_names.flowrate_selection_interval_tag].value
                self.save_alternate_config(tag_names.flowrate_selection_interval_tag,self.flowrate_selection_interval)
                self.process_setpoint_io_data(tag_names.flowrate_selection_interval_tag,self.flowrate_selection_interval)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_flowrate_selection_interval.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret                
    
    def save_drive_frequency_tolerance(self, tags):
        ret = False
        try:
            if tags.get(tag_names.drive_frequency_tolerance_tag) is not None:
                self.drive_frequency_tolerance = tags[tag_names.drive_frequency_tolerance_tag].value
                self.save_alternate_config(tag_names.drive_frequency_tolerance_tag, self.drive_frequency_tolerance)
                self.process_setpoint_io_data(tag_names.drive_frequency_tolerance_tag,self.drive_frequency_tolerance)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_drive_frequency_tolerance.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret
    def save_stabilization_threshold(self, tags):
        ret = False
        try:
            if tags.get(tag_names.stabilization_threshold_tag) is not None:
                self.stabilization_threshold = tags[tag_names.stabilization_threshold_tag].value
                self.save_alternate_config(tag_names.stabilization_threshold_tag, self.stabilization_threshold)
                self.process_setpoint_io_data(tag_names.stabilization_threshold_tag,self.stabilization_threshold)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_drive_frequency_tolerance.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret
    def save_stabilization_probability_threshold(self, tags):
        ret = False
        try:
            if tags.get(tag_names.stabilization_probability_threshold_tag) is not None:
                self.stabilization_probability_threshold = tags[tag_names.stabilization_probability_threshold_tag].value
                self.save_alternate_config(tag_names.stabilization_probability_threshold_tag, self.stabilization_probability_threshold)
                self.process_setpoint_io_data(tag_names.stabilization_probability_threshold_tag,self.stabilization_probability_threshold)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_drive_frequency_tolerance.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret 
    def save_stabilization_points_delay(self, tags):
        ret = False
        try:
            if tags.get(tag_names.stabilization_points_delay_tag) is not None:
                self.stabilization_points_delay = tags[tag_names.stabilization_points_delay_tag].value
                self.save_alternate_config(tag_names.stabilization_points_delay_tag, self.stabilization_points_delay)
                self.process_setpoint_io_data(tag_names.stabilization_points_delay_tag,self.stabilization_points_delay)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_drive_frequency_tolerance.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret
    
    def save_bubble_point_pressure(self, tags):
        ret = False
        try:
            if tags.get(tag_names.bubble_point_pressure_tag) is not None:
                self.bubble_point_pressure = tags[tag_names.bubble_point_pressure_tag].value
                self.save_alternate_config(tag_names.bubble_point_pressure_tag, self.bubble_point_pressure)
                self.process_setpoint_io_data(tag_names.bubble_point_pressure_tag,self.bubble_point_pressure)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_bubble_point_pressure.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret                
    
    def save_pi_calibartion_threshold(self, tags):
        ret = False
        try:
            if tags.get(tag_names.pi_calibartion_threshold_tag) is not None:
                self.pi_calibartion_threshold = tags[tag_names.pi_calibartion_threshold_tag].value
                self.save_model_config(tag_names.pi_calibartion_threshold_tag, self.pi_calibartion_threshold)
                self.process_setpoint_io_data(tag_names.pi_calibartion_threshold_tag,self.pi_calibartion_threshold)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_pi_calibartion_threshold.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret                
    
    def save_head_calibration_threshold(self, tags):
        ret = False
        try:
            if tags.get(tag_names.head_calibration_threshold_tag) is not None:
                self.head_calibration_threshold=tags[tag_names.head_calibration_threshold_tag].value
                self.save_model_config(tag_names.head_calibration_threshold_tag, self.head_calibration_threshold)
                self.process_setpoint_io_data(tag_names.head_calibration_threshold_tag,self.head_calibration_threshold)
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_head_calibration_threshold.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret
    def save_head_model(self, tags):
        ret = False
        try:
            if tags.get(tag_names.head_model_text_tag) is not None and tags[tag_names.head_model_text_tag].value_str != None:
                
                self.model_text_head=base64.b64decode(tags[tag_names.head_model_text_tag].value_str).decode('utf-8')
                self.save_model_config(tag_names.head_model_text_tag, self.model_text_head)
                self.process_setpoint_io_data(tag_names.head_model_text_tag,self.model_text_head)
                self.load_model_text()
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_head_model.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret  
    def save_pi_model(self, tags):
        ret = False
        try:
            if tags.get(tag_names.pi_model_text_tag) is not None and tags[tag_names.pi_model_text_tag].value_str != None:
                self.model_text_pi=base64.b64decode(tags[tag_names.pi_model_text_tag].value_str).decode('utf-8')
                self.save_model_config(tag_names.pi_model_text_tag,self.model_text_pi)
                self.process_setpoint_io_data(tag_names.pi_model_text_tag,self.model_text_pi)
                self.load_model_text()
                ret = True
        except Exception as error:
            logger.exception(error,"Exception occurred in save_pi_model.") 
            logger.error(traceback.format_exc())  
            ret = False
        return ret                
        
    def update_well_test_tag(self,tags):
        ret = False
        try:
            if tags.get(tag_names.well_test_date_tag) is not None:
                self.well_test_date = tags[tag_names.well_test_date_tag].value
                self.process_setpoint_io_data(tag_names.well_test_date_tag,self.well_test_date)
                ret = True
            if tags.get(tag_names.well_test_liquid_flowrate_tag) is not None:
                self.well_test_liquid_flowrate = tags[tag_names.well_test_liquid_flowrate_tag].value
                self.save_calibration_config(tag_names.well_test_liquid_flowrate_tag, self.well_test_liquid_flowrate)
                self.process_setpoint_io_data(tag_names.well_test_liquid_flowrate_tag,self.well_test_liquid_flowrate)
                self.well_test_key = True
                ret = True
            if tags.get(tag_names.well_test_intake_pressure_tag) is not None:
                self.well_test_intake_pressure = tags[tag_names.well_test_intake_pressure_tag].value
                self.save_calibration_config(tag_names.well_test_intake_pressure_tag, self.well_test_intake_pressure)
                self.process_setpoint_io_data(tag_names.well_test_intake_pressure_tag,self.well_test_intake_pressure)
                self.intake_pressure_key = True
                ret = True
            if tags.get(tag_names.well_test_discharge_pressure_tag) is not None:
                self.well_test_discharge_pressure = tags[tag_names.well_test_discharge_pressure_tag].value
                self.save_calibration_config(tag_names.well_test_discharge_pressure_tag, self.well_test_discharge_pressure)
                self.process_setpoint_io_data(tag_names.well_test_discharge_pressure_tag,self.well_test_discharge_pressure)
                self.discharge_pressure_key = True
                ret = True
            if tags.get(tag_names.well_test_drive_frequency_tag) is not None:
                self.well_test_drive_frequecny = tags[tag_names.well_test_drive_frequency_tag].value
                self.save_calibration_config(tag_names.well_test_drive_frequency_tag, self.well_test_drive_frequecny)
                self.process_setpoint_io_data(tag_names.well_test_drive_frequency_tag,self.well_test_drive_frequecny)
                self.drive_frequency_key = True
                ret = True
            if tags.get(tag_names.well_test_motor_temperature_tag) is not None:
                self.well_test_motor_temperature = tags[tag_names.well_test_motor_temperature_tag].value
                self.save_calibration_config(tag_names.well_test_motor_temperature_tag, self.well_test_motor_temperature)
                self.process_setpoint_io_data(tag_names.well_test_motor_temperature_tag,self.well_test_motor_temperature)
                self.motor_temperature_key = True
                ret = True
            if tags.get(tag_names.well_test_reservoir_pressure_tag) is not None:
                self.well_test_reservoir_pressure = tags[tag_names.well_test_reservoir_pressure_tag].value
                self.save_calibration_config(tag_names.well_test_reservoir_pressure_tag, self.well_test_reservoir_pressure)
                self.process_setpoint_io_data(tag_names.well_test_reservoir_pressure_tag,self.well_test_reservoir_pressure)
                ret = True
            if tags.get(tag_names.well_test_reservoir_temperature_tag) is not None:
                self.well_test_reservoir_temperature = tags[tag_names.well_test_reservoir_temperature_tag].value
                self.save_calibration_config(tag_names.well_test_reservoir_temperature_tag, self.well_test_reservoir_temperature)
                self.process_setpoint_io_data(tag_names.well_test_reservoir_temperature_tag,self.well_test_reservoir_temperature)
                ret = True
            if tags.get(tag_names.well_test_water_cut_tag) is not None:
                self.well_test_water_cut = tags[tag_names.well_test_water_cut_tag].value
                self.save_model_config(tag_names.well_test_water_cut_tag, self.well_test_water_cut)
                self.save_calibration_config(tag_names.well_test_water_cut_tag, self.well_test_water_cut)
                self.process_setpoint_io_data(tag_names.well_test_water_cut_tag,self.well_test_water_cut)
                ret = True
            if tags.get(tag_names.well_test_api_tag) is not None:
                self.well_test_api = tags[tag_names.well_test_api_tag].value
                self.save_model_config(tag_names.well_test_api_tag, self.well_test_api)
                self.save_calibration_config(tag_names.well_test_api_tag, self.well_test_api)
                self.process_setpoint_io_data(tag_names.well_test_api_tag,self.well_test_api)
                ret = True
            if tags.get(tag_names.well_test_gor_tag) is not None:
                self.well_test_gor = tags[tag_names.well_test_gor_tag].value
                self.save_model_config(tag_names.well_test_gor_tag, self.well_test_gor)
                self.save_calibration_config(tag_names.well_test_gor_tag, self.well_test_gor)
                self.process_setpoint_io_data(tag_names.well_test_gor_tag,self.well_test_gor)
                ret = True
                
        except Exception as error:
            logger.exception(error,"Exception occurred in file update.") 
            logger.error(traceback.format_exc())         
        return ret
    
    def report_data(self,tag_name,tag_value):
        updated_tag = {}
        updated_tag[tag_name] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = tag_value )
        logger.info("Sent the IoDataReport for setpoint tag: %s" % tag_name)
        return updated_tag
        
    def process_setpoint_io_data(self, tag, value):
        try:
            msg = IoDataReportMsg()
            msg.device = []
            device_data = IoDeviceData(id = self.virtual_id)
            device_data.tags.update(self.report_data(tag,value))
            msg.device.append(device_data)  
            bus_client.send_data(msg)
        except Exception as error:
            logger.exception(error,"Exception occurred in io data sent")
            
    def update_file(self, payload):
        ret = False
        logger.info("config  file received ----------------------------------------------------")
        try:
            if payload.header.MessageType == 'Request_FileDownload' or payload.header.MessageType == "RequestFileDownload":
                file_name = payload.payload["FilePath"].split('/')
                file_device_id = payload.payload['DeviceID']
                filepath = "/Files/"+file_name[2]+"/FileIn/"+file_name[3]
                # validate if filename is from the predefined list
                logger.debug(os.path.basename(filepath))
                logger.debug(file_device_id)
                logger.debug(self.virtual_id)
                check_device_id = str(file_device_id) == str(self.virtual_id)
                if os.path.basename(filepath) == calibration_file and check_device_id:
                    ret = self.update_calibration_file(filepath)
                elif os.path.basename(filepath) == model_text_file and check_device_id:
                    ret = self.update_model_text_file(filepath)
                elif os.path.basename(filepath) == license_filename and check_device_id:
                    ret = self.update_license_file(filepath)
                else:
                    # do not send a response
                    logger.error(
                        "Found " + filepath + " and this is not calibration.json, model_text.json, license, app_config.json or it is not intended for this deivce")
                    # only for purpsose of testing and debugging
                    ret = True
            return ret             
        except Exception:
            logger.error(traceback.format_exc())
            return False

    def update_license_file(self, filepath):
        try:
            result = False
            with open(filepath, 'rb') as file_config:
                config = file_config.read()
                with open(self.license_filename, 'wb') as write_file_licence:
                    write_file_licence.write(config)
                    result = True
            if result == True:
                result, _ = self.workflow_license()
                if result == True:
                    os.remove(filepath)
            return True
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return False

    def update_model_text_file(self, filepath):
        try:
            with open(filepath, 'r') as file_config:
                config = file_config.read()
                logger.debug(config)
                            # when a override of model text is received and if it passes validation, it should be overriden as
                            # calibration filename. This is becuase when the next time model is restarted, the latest calibration file
                            # is reffering to the last model text update
                result, _ = self.write_config(self.model_text_filename, config)
                self.load_model_text()
            return True
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return False

    def update_calibration_file(self, filepath):
        try:
            with open(filepath, 'r') as file_config:
                config = file_config.read()
                logger.debug(config)
                result, _ = self.write_config(self.calibration_filename, config)
                            # self.file_download_response(message_id, result, message)
                config_data_calib = json.loads(config)
                self.save_model_config(tag_names.well_test_water_cut_tag, config_data_calib[tag_names.well_test_water_cut_tag])
                self.save_model_config(tag_names.well_test_api_tag, config_data_calib[tag_names.well_test_api_tag])
                self.save_model_config(tag_names.well_test_gor_tag, config_data_calib[tag_names.well_test_gor_tag])
                self.load_welltest_data()
                result, _ = self.calibrate(json.loads(config))
            return True
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return False
    
    """
        This function saves configuration data to two JSON files.
        Save updated value of tags in model & calibration json files
    
    """
    def write_config(self, path, config):

        try:
            with open(path, 'w') as config_file:
                config_file.write(config)
            return True, "SUCCESS"
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return False, str(error)

    def save_calibration_config(self, update_tag, update_value):

        try:
            with open(self.calibration_filename, 'r') as file_config:
                config = file_config.read()
                config = json.loads(config)
                # logging.debug(config)
                config[update_tag] = update_value
                config = json.dumps(config)
                logger.info(f"config updated for tag {update_tag} with value {update_value}")
                _, _= self.write_config(
                    self.calibration_filename , config)
        except Exception:
            logger.error("exception occcured while writing calibration config")
            logger.error(traceback.format_exc()) 

    def save_model_config(self, update_tag, update_value):

        try:
            with open(self.model_text_filename, 'r') as file_config:
                config = file_config.read()
                config = json.loads(config)
                # logging.debug(config)
                config[update_tag] = update_value
                config = json.dumps(config)
                logger.info(f"config updated for tag {update_tag} with value {update_value}")
                _, _= self.write_config(
                    self.model_text_filename , config)
        except Exception:
            logger.error("exception occcured while writing model config")
            logger.error(traceback.format_exc())    
    
    def save_alternate_config(self, update_tag, update_value):

        try:
            logger.info("alternate config Updation ........................")
            with open("/config/AEA.json", 'r') as file_config:
                config = file_config.read()
                config = json.loads(config)
                logger.debug(config)
                config['AppConfig']['DeviceMapping'][str(self.slave_id)][update_tag] = update_value
                config = json.dumps(config)
                logger.info(f"config updated for tag {update_tag} with value {update_value}")
                _, _= self.write_config(
                    "/config/AEA.json" , config)
        except Exception:
            logger.error("exception occcured while writing alternate config")
            logger.error(traceback.format_exc()) 
    """
        This function prepares calibration data by creating a dictionary of IoPoints with specific
        values and timestamps.
        @returns a dictionary object named "data" which contains the following key-value pairs:
        - 'well_test': an IoPoint object with quality_code, timestamp, and value attributes
        - 'outlet_pressure': an IoPoint object with quality_code, timestamp, and value attributes
        - 'inlet_pressure': an IoPoint object with quality_code, timestamp, and value attributes
        - ' Get updated values of all calibration tags
    """ 
    def prepare_data_caliberation(self):
        
        try:
            data = {}           
            data[tag_names.well_test_liquid_flowrate_tag] = self.well_test_liquid_flowrate
            data[tag_names.well_test_discharge_pressure_tag] = self.well_test_discharge_pressure
            data[tag_names.well_test_intake_pressure_tag] = self.well_test_intake_pressure
            data[tag_names.well_test_drive_frequency_tag] = self.well_test_drive_frequecny
            data[tag_names.well_test_motor_temperature_tag] = self.well_test_motor_temperature
            data[tag_names.well_test_water_cut_tag] = self.well_test_water_cut
            data[tag_names.well_test_api_tag] = self.well_test_api
            data[tag_names.well_test_gor_tag] = self.well_test_gor
            data[tag_names.well_test_reservoir_pressure_tag] = None
            data[tag_names.well_test_reservoir_temperature_tag] = None
            
            return data
        except Exception as error:
            logger.error(error)
            logger.error(traceback.format_exc())
    
    """
        This function calibrates the flow rate head based on well test flow rate and returns a status
        message.
        @param tags - A dictionary containing various parameters and their values used in the
        calibration process. It is passed as an argument to the `calibrate` method.
        @returns A tuple is being returned with two values: a boolean value indicating whether the
        calibration was successful or not, and a string message explaining the result of the
        calibration. Check calibration workflow logic
    """
    def calibrate(self,calibration_dict): 
        """
        {
            "well_test-water_cut": 1200,
            "well_test-liquid_flowrate": 3434,
            "well_test-intake_pressure": 1432,
            "well_test-discharge_pressure": 1432,
            "well_test-drive_frequency": 52,
            "well_test-motor_temperature": 253.6,
            "well_test-API": 100,
            "well_test-gor": 63,
            "well_test-reservoir_pressure": 2311,
            "well_test-reservoir_temperature": 215
        }
        """
        # Example calibration file
        try:
            if calibration_dict != None:
                well_test_flow_rate = calibration_dict[tag_names.well_test_liquid_flowrate_tag]
                self.well_test_liquid_flowrate = calibration_dict[tag_names.well_test_liquid_flowrate_tag]
                self.well_test_motor_temperature = calibration_dict[tag_names.well_test_motor_temperature_tag]
                self.well_test_discharge_pressure = calibration_dict[tag_names.well_test_discharge_pressure_tag]
                self.well_test_intake_pressure = calibration_dict[tag_names.well_test_intake_pressure_tag]
                self.well_test_drive_frequecny = calibration_dict[tag_names.well_test_drive_frequency_tag]
                self.well_test_water_cut = calibration_dict[tag_names.well_test_water_cut_tag]
                self.well_test_api = calibration_dict[tag_names.well_test_api_tag]
                self.well_test_gor = calibration_dict[tag_names.well_test_gor_tag]
                self.well_test_reservoir_pressure = calibration_dict[tag_names.well_test_reservoir_pressure_tag]
                self.well_test_reservoir_temperature = calibration_dict[tag_names.well_test_reservoir_temperature_tag]
                latest_head_flow_rate = self.virtual_liquid_rate

                # check calibration logic
                if (abs(latest_head_flow_rate - well_test_flow_rate) / well_test_flow_rate * 100) > self.head_calibration_threshold or self.model_initialized == False:
                    # calibration required
                    result_pi = self.workflow_calibraion_pi()
                    result_head = self.workflow_calibraion_head()
                    
                    if  result_head == True or result_pi == True:
                        self.write_calibration()
                        self.calibration_flag = 1
                        logger.info("Calibration accepted")
                        return True, "Calibration accepted"
                    else:
                        self.calibration_flag = -1
                        logger.info("Calibration failed as pi and head are not true")
                        return True, "Calibration failed as pi and head are not true"

                else:
                    logger.info("calibration not required.......")
                    # no calibration required
                    self.calibration_flag = 2
                    return True, "Calibration not required"
            else:
                # no calibration required
                logger.info("calibration file is not supported.......")
                self.calibration_flag = 2
                return True, "Calibration failed as file not supportd"
                    
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return True, "Calibration failed as exception"

    def workflow_calibraion_pi(self):
        """
        {
            "well_test": 0,
            "inlet_pressure": 0,
            "reservoir_pressure": 0,
            "reservoir_temperature": 0,
            "water_cut": 0
        }
        """
        # ssokol
        try:
            req_body = {
                "model_text": self.model_text_pi,
                "well_test": self.well_test_liquid_flowrate,
                "reservoir_pressure": self.well_test_reservoir_pressure,
                "inlet_pressure": self.well_test_intake_pressure,
                "reservoir_temperature": self.well_test_reservoir_temperature,
                "water_cut": self.well_test_water_cut,
                "gor":self.well_test_gor,
                "api":self.well_test_api
            }
            # logging.debug(str(req_body))
            logger.debug("......calling PI Calibration API......")
            logger.debug(str(PIPESIM_URI + CAL_PI))
            logger.debug(str(json.dumps(req_body)))
            response = requests.post(
                url=PIPESIM_URI + CAL_PI, data=json.dumps(req_body), headers=HTTP_HEADER)
            if response.status_code == 200:
                logger.debug(f"Api response status in workflow_calibraion_pi : {response.status_code}")
                logger.debug(str(response.json()))
                self.model_text_pi = response.json()['model_text']
                return True
            else:
                logger.debug(f"Api response status in workflow_calibraion_pi : {response.status_code}")
                return False

        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return False
    """
        This function sends a request to an API endpoint with specific data and updates a model text
        based on the response.
        @param tags - The "tags" parameter is a dictionary containing various process parameters
        required for the calibration of a pipeline head. These parameters include well test, outlet
        pressure, inlet pressure, operating frequency, motor temperature, and water cut.
        @returns a boolean value.
        Call Api to request Model-Text head. Model text head is encoded commands.
    """
    def workflow_calibraion_head(self):             
        try:
            req_body = {
                "model_text": self.model_text_head,
                "well_test": self.well_test_liquid_flowrate,
                "outlet_pressure":self.well_test_discharge_pressure,
                "inlet_pressure": self.well_test_intake_pressure,
                "operating_frequency":  self.well_test_drive_frequecny,
                "motor_temperature": self.well_test_motor_temperature,
                "water_cut": self.well_test_water_cut,
                "gor":self.well_test_gor,
                "api":self.well_test_api
            }
            logger.debug("......calling HEAD Calibration API......")
            url=PIPESIM_URI + CAL_HEAD
            data=json.dumps(req_body)
            logger.debug(url)
            logger.debug(data)
            response = requests.post(
                url=url, data=data, headers=HTTP_HEADER)
            if response.status_code == 200:
                logger.debug(f"Api response status in workflow_calibraion_head : {response.status_code}")
                logger.debug(str(response.json()))
                self.model_text_head = response.json()['model_text']
                return True   
            else:
                logger.debug(f"Api response status in workflow_calibraion_head : {response.status_code}")
                return False   
        except Exception as error:
            logger.exception(error,"calibration head is not received a response")
            logger.error(traceback.format_exc())
            return False   
        
    def write_calibration(self):
        try:
            with open(self.model_text_filename, 'r') as cal_file:
                config = cal_file.read()
                config = json.loads(config)
                config[tag_names.head_model_text_tag] = self.model_text_head
                config[tag_names.pi_model_text_tag] = self.model_text_pi
                config = json.dumps(config)
                self.save_calibration(config)
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            
    def save_calibration(self,config):
        try:
            with open(self.model_text_filename, 'w') as cal_file:
                cal_file.write(config)
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
        
    """
        This function simulates a workflow using a model and returns a boolean value indicating success
        or failure.
        @param tags - The "tags" parameter is a dictionary that contains the values of various process
        variables that are required for the simulation. In this specific code snippet, it contains the
        value of "Intake Pressure".
        @returns a boolean value indicating whether the workflow simulation for Pi was successful or not.
        Call Api to get flowrate
    """
    def workflow_simulation_pi(self,tags):       
        
        if self.model_initialized:
            try:
                req_body = {
                    "model_text": self.model_text_pi,
                    "inlet_pressure": tags[tag_names.intake_pressure_tag].value,
                    "water_cut": self.well_test_water_cut,
                    "gor":self.well_test_gor,
                    "api":self.well_test_api
                }
                url = PIPESIM_URI + SIM_PI
                data=json.dumps(req_body)
                logger.debug("......calling PI Simulation API......:")
                response = requests.post(
                    url=url, data=data, headers=HTTP_HEADER)
                if response.status_code == 200:
                    self.flow_rate_pi = round(response.json()['flowrate'])
                    flowrate_status = True
                else:
                    self.flow_rate_pi = -1
                    flowrate_status = False
                logger.debug(f"Api response status in workflow_simulation_pi: {response.status_code}")
                logger.debug("Flow Rate Pi value:" +str(self.flow_rate_pi))         
                return  flowrate_status
            
            except Exception as error:
                self.flow_rate_pi = -1
                logger.exception(error,"Exception occurred in Simulation Pi") 
                logger.error(traceback.format_exc())            
                return  False  
        else:
            logger.warn("Pi model not initialized.............")
            self.flow_rate_pi = -2
            return False

    """
        This is a Python function that simulates a workflow for a head model using input tags and sends a
        request to a PIPESIM API to get the flow rate.
        @param tags - The "tags" parameter is a dictionary containing the values of various process
        variables such as "Intake Pressure", "Discharge Pressure", "Drive Frequency", and "Motor
        Temperature". These values are used as inputs to the workflow simulation model.
        @returns a boolean value indicating whether the workflow simulation for the head model was
        successful or not.
    """
    
    # ssokol
    def workflow_simulation_head(self,tags):  
        if self.model_initialized:
            try:
                req_body = {
                    "model_text": self.model_text_head,
                    "inlet_pressure":tags[tag_names.intake_pressure_tag].value,
                    "water_cut": self.well_test_water_cut,
                    "outlet_pressure": tags[tag_names.discharge_pressure_tag].value,
                    "operating_frequency": tags[tag_names.drive_frequency_tag].value,
                    "motor_temperature": tags[tag_names.motor_temperature_tag].value,
                    "gor":self.well_test_gor,
                    "api":self.well_test_api
                }
                url = PIPESIM_URI + SIM_HEAD
                data=json.dumps(req_body)   
                logger.debug("......calling HEAD Simulation API......:")                           
                response = requests.post(
                    url=url, data=data, headers=HTTP_HEADER)
                if response.status_code == 200:
                    self.flow_rate_head = round(response.json()['flowrate'])
                    flowrate_status=  True
                else:                        
                    self.flow_rate_head = -1
                    flowrate_status = False
                logger.debug(f"Api response status in workflow_simulation_head : {response.status_code}")
                logger.debug("Flow Rate Head value:" + str(self.flow_rate_head))
                return flowrate_status

            except Exception as error:
                self.flow_rate_head = -1
                logger.exception(error, "An error occurred")
                logger.error(traceback.format_exc())            
                return False             
        else:
            self.flow_rate_head = -2
            logger.warn("Head model not initialized.........")
            return False
        
    def workflow_license(self):
        try:
            with open(self.license_filename, 'rb') as f:
                data = f.read()
            res = requests.post(url=PIPESIM_URI + LIC_UPDATE,
                                data=data,
                                headers=HTTP_HEADER_LICENSE)
            if res.status_code == 200:
                return True, "license updated"
            else:
                return False, str(res.status_code) + res.text
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return False, str(error)        
    """
        This function sends a GET request to a specified URL to check the validity of a license and
        returns the expiration date and a boolean indicating if the license is valid or not.
        @returns a tuple containing the license expiration date and a boolean value indicating whether the
        license is valid or not. If there is an exception, it returns None and False.
        Validate license
    """
    def workflow_license_validity(self):
        
        response = None
        url = PIPESIM_URI + LIC_VALIDITY  
        try:
            response = requests.get(
                url=url, headers=HTTP_HEADER)
            if(response.status_code==200):
                logger.debug(f"Api response status in workflow_license_validity is: {response.status_code}")
                return response.json()["license_expiration_date"], True
            else:
                logger.debug(f"Api response status in workflow_license_validity is: {response.status_code}")
                return response.status_code, False

        except Exception as error:           
            logger.exception(error,"Please find a exception for and license validity")   
            logger.error(traceback.format_exc())         
            return None, False

    """
        This is a Python function that sends a POST request to a VFM URI and retrieves alarm data based on
        the provided payload.
        @param data_paylaod - This is a dictionary or JSON object containing the data that will be sent in
        the API request to the VFM URI. It is passed as an argument to the `workflow_vfm_dependent_alarm`
        method.
        @returns a boolean value. It returns True if the API call is successful and False if there is an
        error in the API call.
    """
    def workflow_vfm_dependent_alarm(self, data_paylaod):
        url=VFM_URI + VFM_DEP
        logger.debug(url)
        try:
            data=json.dumps(data_paylaod)
            response = requests.post(url=url, data=data, headers=HTTP_HEADER_SMART_ALARM)
            if response.status_code == 200:
                self.api_response = response.json()
                self.operational_condition_alarm = self.api_response[tag_names.operational_condition_alarm_tag]
                self.operational_condition_flag = self.api_response[tag_names.operational_condition_flag_tag]
                self.pi_drop_alarm = self.api_response[tag_names.pi_drop_alarm_tag]
                self.pump_low_eff_alarm = self.api_response[tag_names.pump_low_eff_alarm_tag]
                self.pump_wear_alarm = self.api_response[tag_names.pump_wear_alarm_tag]
                self.tub_leak_alarm = self.api_response[tag_names.tub_leak_alarm_tag]
                logger.debug(f"Api response status in  workflow_vfm_dependent_alarm is: {response.status_code}")
                logger.debug(f"VFM based Alarm ={self.api_response}")
                return True
            else:
                logger.debug(f"Api response status in  workflow_vfm_dependent_alarm is: {response.status_code}")
                return False

        except requests.exceptions.RequestException as e:
            logger.exception(e, "Error in api call")
            logger.error(traceback.format_exc())
            return False

    """
        This function resets VFM dependent alarms for pump wear and returns True if successful, False
        otherwise.
        @returns a boolean value - True if the API response status code is 200, and False otherwise.
        Call Api to check dependent alarm reset
    """
    def workflow_vfm_dependent_alarm_reset(self):
        try:
            data = json.dumps({"device_id":str(self.slave_id)})
            response = requests.post(
                url=VFM_URI + VFM_RESET,data=data, headers=HTTP_HEADER_SMART_ALARM)
            if response.status_code == 200:
                logger.debug(f"Api response status in workflow_vfm_dependent_alarm_reset is: {response.status_code}")            
                logger.debug("Reset the VFM Dependent alarms(pump wear) every time for new well and well change")
                return True
            else:
                return False
        except requests.exceptions.RequestException as e:
            logger.exception(e, "Reset the VFM Dependent alarms(pump wear) every time for new well and well change")
            logger.error(traceback.format_exc())
            return False
    def workflow_vfm_dependent_alarm_reset_all(self):
        try:
            response = requests.post(
                url=VFM_URI + VFM_RESET_ALL, headers=HTTP_HEADER_SMART_ALARM)
            if response.status_code == 200:
                logger.debug(f"Api response status in workflow_vfm_dependent_alarm_reset All is: {response.status_code}")            
                logger.debug("Reset the VFM Dependent alarms(pump wear) All, every time for new well and well change")
                return True
            else:
                return False
        except requests.exceptions.RequestException as e:
            logger.exception(e, "Reset the VFM Dependent alarms(pump wear)All, every time for new well and well change")
            logger.error(traceback.format_exc())
            return False
    
    def workflow_mwt_alarm_reset(self):
        try:
            data = json.dumps({"device_id":str(self.slave_id)})
            response = requests.post(
                url=GLK_URI + MWT_RESET,data=data, headers=HTTP_HEADER_SMART_ALARM)
            if response.status_code == 200:
                logger.debug(f"Api response status in MWT alarm reset is: {response.status_code}")            
                logger.debug("Reset the  GLK alarms(MWT) every time for new well and well change")
                return True
            else:
                return False
        except requests.exceptions.RequestException as e:
            logger.exception(e, "Reset the GLK  alarms(GLK) every time for new well and well change")
            logger.error(traceback.format_exc())
            return False
    def workflow_mwt_alarm_reset_all(self):
        try:
            response = requests.post(
                url=GLK_URI + MWT_RESET_ALL, headers=HTTP_HEADER_SMART_ALARM)
            if response.status_code == 200:
                logger.debug(f"Api response status in MWT alarm reset All is: {response.status_code}")            
                logger.debug("Reset the  GLK alarms(MWT) All, every time for new well and well change")
                return True
            else:
                return False
        except requests.exceptions.RequestException as e:
            logger.exception(e, "Reset the GLK  alarms(GLK) All, every time for new well and well change")
            logger.error(traceback.format_exc())
            return False

    def workflow_flowrate_reset(self):
        try:
            data = json.dumps({"device_id":str(self.slave_id)})
            response = requests.post(
                url=GLK_URI + FLOWRATE_RESET,data=data, headers=HTTP_HEADER_SMART_ALARM)
            if response.status_code == 200:
                logger.debug(f"Api response status in Flowrate reset is: {response.status_code}")            
                logger.debug("Reset the  GLK alarms flowrate every time for new well and well change")
                return True
            else:
                return False
        except requests.exceptions.RequestException as e:
            logger.exception(e, "Reset the GLK  alarms(flowrate) every time for new well and well change")
            logger.error(traceback.format_exc())
            return False
    def workflow_flowrate_reset_all(self):
        try:
            response = requests.post(
                url=GLK_URI + FLOWRATE_RESET_ALL, headers=HTTP_HEADER_SMART_ALARM)
            if response.status_code == 200:
                logger.debug(f"Api response status in flowrate reset All is: {response.status_code}")            
                logger.debug("Reset the  GLK alarms(flowrate) All, every time for new well and well change")
                return True
            else:
                return False
        except requests.exceptions.RequestException as e:
            logger.exception(e, "Reset the GLK  alarms(flowrate) All, every time for new well and well change")
            logger.error(traceback.format_exc())
            return False

        
    def gasloack_and_emulsion_call(self, api_data):
            try:
                response = requests.post(url=GLK_URI+GLK_API, data=json.dumps(api_data), headers=HTTP_HEADER_SMART_ALARM)
                if response.status_code == 200: 
                    logger.debug("Non-VFM based Alarm: "+str(response.json()))
                    self.pred_label_gas_interference = response.json()[tag_names.pred_label_gas_interference_tag]
                    self.pred_label_gas_lock = response.json()[tag_names.pred_label_gas_lock_tag]
                    self.pred_label_emulsion_solid = response.json()[tag_names.pred_label_emulsion_solid_tag]
                    self.motor_temperauture_indicator = response.json()[tag_names.pred_proba_mwt_alarm_tag]
                    self.motor_temperature_defaut_mean = response.json()[tag_names.mean_default_mwt_tag]
                    logger.debug(f"API response status in gaslock_and_emulsion_call is: {response.status_code}")
                    return True
                else:
                    logger.debug(f"Api response status in gaslock_and_emulsion_call is: {response.status_code}")
                    return False
            except Exception as error:
                logger.exception(error,"Error while calling the api for 180 points")             
                logger.error(traceback.format_exc())
                return False