import json
from EspTagScaling import apply_reverse_scaling, apply_scaling, SCALING
import traceback
import os
from agoraiot import logger, config
if "APP_TAGS" in os.environ:
    tags_version = os.getenv("APP_TAGS")
    if tags_version =="old":
        import tag_names_old as tag_names
    else:
        import tag_names as tag_names
else:
    import tag_names as tag_names

class EspDataScaling:

    def __init__(self):

        if config["SCALING"]:
            logger.debug("Loading scaling from AEA.json")
            scaling_str = json.dumps(config["SCALING"])
            logger.debug(scaling_str)
            self.scaling = json.loads(scaling_str)
        else:
            self.scaling = SCALING

    def scale_data(self, hbm_device_tags, vfd):
        try:
            scaled_data,state = apply_scaling(hbm_device_tags, vfd, self.scaling) #after scaling and having all tags which comes from source
            self.scaled_data = scaled_data
            return state
        
        except Exception as e:
            logger.debug("All tags are not found")
            logger.debug(str(e))
            logger.error(traceback.format_exc())
            return False
        
    def reverse_scale_data(self, hbm_device_tags, vfd):
        try:
            hbm_device_tags = apply_reverse_scaling(hbm_device_tags, vfd, self.scaling)
            self.reverse_scaled_data = hbm_device_tags #after reverse scaling
            return True

        except Exception as e:
            logger.debug("All tags are not found")
            logger.debug(str(e))
            logger.error(traceback.format_exc())
            return False
        
    def esp_data_validation(self, hbm_device_tags):
        try:
            data_valid_1 = False
            data_valid_2 = False
            if hbm_device_tags[tag_names.drive_frequency_tag].quality_code == 0 and hbm_device_tags[tag_names.drive_frequency_tag].value > 0:
                data_valid_1 = True
            if hbm_device_tags[tag_names.discharge_pressure_tag].value - hbm_device_tags[tag_names.intake_pressure_tag].value > 0:
                data_valid_2 = True
            logger.info("Data Validity check for Drive Frequency > 0: %s" % data_valid_1)
            logger.info("Data Validity check for Discharge Pressure - Intake Pressure > 0: %s" % data_valid_2)
            return data_valid_1 and data_valid_2
        
        except Exception as e:
            logger.debug("ESP Data validation failed")
            logger.debug(str(e))
            logger.error(traceback.format_exc())
            return False