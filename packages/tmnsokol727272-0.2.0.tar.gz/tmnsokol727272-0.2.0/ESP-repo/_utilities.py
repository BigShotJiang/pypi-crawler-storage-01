import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from threading import Event
from typing import TYPE_CHECKING

from agoraiot import config, logger, redis

def show_publish_table(tags):
    try:
        # sorted_tags=sorted(tag_list, key=lambda x: x.name)
        ROW_HEADER_LENGTH = 58
        logger.info("+" + "=" * ROW_HEADER_LENGTH + "+")
        # logger.info("|{:<17} | {:<38}|".format("  Value", "  Tag"))
        logger.info("|{:<38} | {:<17}|".format("  Tag", "  Value"))
        logger.info("+" + "=" * ROW_HEADER_LENGTH + "+")
        for tag,io in tags.items():
            if (
                io.quality_code == 0
                and io.value is not None
            ):
                # logger.info(f"|  {io.value:<15.4f} |  {tag:<37.35s}|")
                logger.info(f"|  {tag:<37.35s} |  {io.value:<15.4f}|")
        logger.info("+" + "=" * ROW_HEADER_LENGTH + "+")
    except Exception as error:
        logger.error("Failed to parse the tags for publishing")
        logger.error(str(error))


def show_header():
    try:
        build_id = os.getenv("buildId")
        if not build_id:
            logger.warn("buildId is not found in env")
            return
        timestamp = datetime.strptime(build_id, "%Y%m%d%H%M")
        human_readable = timestamp.strftime("%Y-%m-%d %H:%M")
        content = f"buildId={build_id}, last updated on {human_readable}"
        logger.heading(content)
    except Exception as error:
        logger.error(f"failed to get the buildId : {error}")


def write_config(path, config):
    try:
        with open(path, "w") as config_file:
            config_file.write(config)
            logger.debug(config)
            logger.info("Config write successful.")
            return True, "SUCCESS"
    except Exception as error:
        logger.error(str(error))
        return False, str(error)


def read_file_if_exists(config_file):
    config_path = Path(config_file)
    if config_path.exists():
        try:
            with config_path.open("r") as f:
                config_json = json.load(f)
        except Exception as e:
            logger.error(f"Failed to read JSON file: {e}")
            return {}
        return config_json
    else:
        logger.error(f"Failed to read JSON file: {config_file} does not exist.")
        return {}


def is_valid_json(file_path):
    try:
        with open(file_path) as file:
            json.load(file)
        return True
    except (json.JSONDecodeError, FileNotFoundError):
        return False


def create_empty_json_if_not_exists(filename):
    if is_valid_json(filename):
        return
    with open(filename, "w") as file:
        json.dump({}, file)


def check_binds(binds: list[str]):
    for folder_name in binds:
        if os.path.exists(folder_name):
            if os.access(folder_name, os.W_OK):
                logger.info(f"{folder_name} exists and is writable")
            else:
                logger.error(f"{folder_name} exists but is not writable")
                sys.exit(1)
        else:
            logger.error(f"{folder_name} does not exist")
            sys.exit(1)

def wait_for_config():
    config_event = Event()
    config.observe_config(config_event.set)
    logger.heading("Waiting for valid configuration")
    config_event.wait()
    config.stop_observing_conf(config_event.set)


def wait_for_redis_connection():
    redis.connect()
    while not redis.is_connected():
        time.sleep(2)
        logger.error("Redis not connected")
        redis.connect()