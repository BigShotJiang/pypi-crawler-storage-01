import traceback
from agoraiot import logger
import os
if "APP_TAGS" in os.environ:
    tags_version = os.getenv("APP_TAGS")
    if tags_version =="old":
        import tag_names_old as tag_names
    else:
        import tag_names as tag_names
else:
    import tag_names as tag_names

#Default scaling settings
SCALING = {
    "SLB": {
        tag_names.average_amps_tag: tag_names.scaling_of_tens,
        tag_names.drive_frequency_tag: tag_names.scaling_of_hundreds,
        tag_names.intake_pressure_tag: tag_names.scaling_of_tens,
        tag_names.intake_temperature_tag: tag_names.scaling_of_tens,
        tag_names.motor_temperature_tag: tag_names.scaling_of_tens,
        tag_names.discharge_pressure_tag: tag_names.scaling_of_tens,

        },
    "UNSCALED": {
        tag_names.average_amps_tag: tag_names.scaling_of_ones,
        tag_names.drive_frequency_tag: tag_names.scaling_of_ones,
        tag_names.intake_pressure_tag: tag_names.scaling_of_ones,
        tag_names.intake_temperature_tag: tag_names.scaling_of_ones,
        tag_names.motor_temperature_tag: tag_names.scaling_of_ones,
        tag_names.discharge_pressure_tag: tag_names.scaling_of_ones,
        }
}

def apply_scaling(hbm_device_tags, vfd, scaling):
    """
    hbm_device : should be tag list
    """
    try: 
        keys= list(hbm_device_tags.keys())
        required_tags = [tag_names.drive_frequency_tag,tag_names.average_amps_tag, tag_names.discharge_pressure_tag,tag_names.intake_pressure_tag, tag_names.intake_temperature_tag, tag_names.motor_temperature_tag]
        missing_tags = [tag for tag in required_tags if tag not in keys]
        exists_common_tag = all(tag in keys for tag in required_tags)
        if exists_common_tag:
            logger.info("All required tags found in the message")
            for tag in hbm_device_tags:
                if scaling[vfd].get(tag) != None:
                    abcd_string = scaling[vfd][tag]
                    if hbm_device_tags[tag].value != None:                
                        new_value = scale_value(hbm_device_tags[tag].value, abcd_string)
                        new_value = round(float(new_value), 2)
                        logger.debug(tag + " : " + str(hbm_device_tags[tag].value) + ", SCALED value : " + str(new_value))
                        hbm_device_tags[tag].value = new_value
            state = True
        else:
            logger.info("Below Tags not preset in Message")
            logger.info(str(missing_tags))
            state = False
        return hbm_device_tags,state
    except Exception as e:
        logger.debug(str(e))
        logger.error(traceback.format_exc())
        return hbm_device_tags,False


def apply_reverse_scaling(hbm_device_tags, vfd, scaling):
    """
    hbm_device : should be tag list
    """
    try: 
        for tag in hbm_device_tags:
            if scaling[vfd].get(tag) != None:
                abcd_string = scaling[vfd][tag]
                if hbm_device_tags[tag].value != None:
                    new_value = reverse_scale_value(hbm_device_tags[tag].value, abcd_string)
                    new_value = round(float(new_value), 2)
                    logger.debug(tag + " : " + str(hbm_device_tags[tag].value) + ", REVERSE SCALED value : " + str(new_value))
                    hbm_device_tags[tag].value = new_value

        return hbm_device_tags

    except Exception as e:
        logger.debug(str(e))
        logger.error(traceback.format_exc())    


def scale_value(value, abcd_string):

    try:
        a, b, c, d = abcd_string.split(",")
        a, b, c, d = float(a), float(b), float(c), float(d)
        num = (a * value) + b
        den = (c * value) + d
        return num/den
    except Exception as e:
        logger.debug(str(e))
        logger.error(traceback.format_exc())
        return value


def reverse_scale_value(value, abcd_string):

    try:
        a, b, c, d = abcd_string.split(",")
        a, b, c, d = float(a), float(b), float(c), float(d)
        num = (b * value) + a
        den = (d * value) + c
        return den/num
    except Exception as e:
        logger.debug(str(e))
        logger.error(traceback.format_exc())
        return value