import threading
import traceback
import time
import os
import json
from queue import Queue
from agoraiot import logger,bus_client,config
from Vfm import Vfm
from data_handler import DataHandler
from request_handler import RequestHandler

CONFIG_FILE_PATH = 'config/AEA.json'
ENV_VAR_NAME = 'APP_CONFIG'
class App():

    """
        This function Initializes the queue and configuration and config updated accordingly
    """
    def __init__(self):   
        self.apps_by_virtual_id = {}
        self.apps_by_slave_id = {}
        self.message_queue = []
        self.request_queue = None
        self.config_read_env()
        self.get_config()
        bus_client.connect(30)
        config.observe_config(self.get_config)
    
    """
        This function retrieves configuration information and creates virtual devices based on the
        information provided.
        Checking configuration of virtual device mapping
    """
    def load_current_config(self,file_path):
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                return json.load(file)
        else:
            return {"AppConfig": {"DeviceMapping": {}}}
        
    def write_config(self,file_path, config):
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'w') as file:
            json.dump(config, file, indent=4)

    def update_config_from_env(self,config, env_var_name):
        env_var = os.getenv(env_var_name)
        if env_var:
            try:
                new_config = json.loads(env_var)
            except json.JSONDecodeError:
                print("Error: Invalid JSON format in environment variable")
                return False
            
            new_device_mapping = new_config.get("AppConfig", {}).get("DeviceMapping", {})
            current_device_mapping = config.get("AppConfig", {}).get("DeviceMapping", {})

            if not new_device_mapping:
                print("No DeviceMapping found in the environment variable")
                return False

            new_keys = set(new_device_mapping.keys()) - set(current_device_mapping.keys())

            if new_keys:
                for key in new_keys:
                    current_device_mapping[key] = new_device_mapping[key]
                print("Updating configuration with new keys from environment variable")
                config["AppConfig"]["DeviceMapping"] = current_device_mapping
                return True
            else:
                print("No new devcie mapping detected in the environment variable")
                return False
        else:
            print(f"Environment variable '{env_var_name}' not set")
            return False


    def config_read_env(self):
        # Load the existing configuration
        current_config = self.load_current_config(CONFIG_FILE_PATH)

        # Update the configuration from the environment variable
        if self.update_config_from_env(current_config, ENV_VAR_NAME):
            # Write the updated configuration back to AEA.json
            self.write_config(CONFIG_FILE_PATH, current_config)
            print("Configuration updated and written to AEA.json")
        else:
            print("No update required")

        # Print the updated configuration
        print(json.dumps(current_config, indent=4))

    def get_config(self):
        try:
            if config["AppConfig:DeviceMapping"] :
                appconfig=config["AppConfig:DeviceMapping"] 
                if isinstance(appconfig, dict): 
                    logger.info("Clearing Previous Instances....")
                    self.apps_by_slave_id.clear()
                    self.apps_by_virtual_id.clear()
                    for real_rtu_id,items in appconfig.items():
                        virtual_rtu_id = items["VIRTUAL_RTU_ID"]
                        vfd = items["VFD"]
                        logger.info(f"Creating instance with Virtual Device id = {virtual_rtu_id} for Slave id = {real_rtu_id} with VFD Type = {vfd}")
                        try:
                            self.apps_by_virtual_id[virtual_rtu_id] = self.apps_by_slave_id[real_rtu_id] = Vfm(virtual_rtu_id, real_rtu_id, vfd)  
                        except Exception as e:
                            logger.exception(e,f"Unable to create ESP App for virtual device {virtual_rtu_id}")
                            logger.info(f"Real RTU IDs: {self.apps_by_slave_id}, Virtual RTU IDs: {self.apps_by_virtual_id}")
                            logger.error(traceback.format_exc())
                else:
                    logger.info("Setting 'SlaveConfig:DeviceMapping' is not valid.")
            else:
                logger.info("Setting 'SlaveConfig:DeviceMapping' is missing or not configured correctly.")
        except Exception as error:
            logger.exception(error,"Exception occurred in configuration.")
            logger.error(traceback.format_exc())

    """
        This function runs a loop that checks for data and request messages in a bus client and calls
        corresponding functions to handle them.
        Connect to Busclient and get data and message from another devices
    """
    def run(self):
        logger.info("connected to BusClient..")
        try:           
            while bus_client.is_connected:
                if bus_client.messages.has_data_messages:
                    for msg in bus_client.messages.get_data_messages():
                        # for device in msg.device:
                        #     if (str(device.id) in self.apps_by_slave_id.keys()):
                                self.message_queue.append(msg)            
                time.sleep(0.1)
        except Exception as error:
            logger.exception(error,"Exception occurred in main run method")
            logger.error(traceback.format_exc())

    """
        This function runs a loop that checks for data in a bus client and calls
        corresponding functions to handle them.
    """
    def message_handler(self):
        try:
            logger.info("Message handler")
            self.data_handler = DataHandler(self.apps_by_slave_id)
            while bus_client.is_connected:
                if self.message_queue != []:
                    logger.debug(f"message queue size:{len(self.message_queue)} ")
                    message = self.message_queue.pop()
                    if message.header.MessageType == "IODataReport":
                        self.data_handler.io_data_report_call(message)
                time.sleep(0.1)
        except Exception as error:
            logger.exception(error,"Exception occurred in message handler")
            logger.error(traceback.format_exc())
    """
        This function runs a loop that checks for request in a bus client and calls
        corresponding functions to handle them.
    """        
    def setpoit_handler(self):
        try:
            self.request_handler = RequestHandler(self.apps_by_virtual_id)
            while bus_client.is_connected:
                if bus_client.messages.has_request_messages:
                    for msg in bus_client.messages.get_request_messages():
                        if msg.header.MessageType == 'RequestDataWrite':
                            self.request_handler.request_msgcall(msg)
                        if msg.header.MessageType == 'Request_FileDownload' or msg.header.MessageType == "RequestFileDownload":
                            self.request_handler.file_request_msgcall(msg)
                time.sleep(0.1)
        except Exception as error:
            logger.exception(error,"Exception occurred in setpoint handler(file or data write)")
            logger.error(traceback.format_exc())
"""
Main function to initiate the process and created multi threading for processing data/request from busclient and requests and data
"""
if __name__ == '__main__':
    try:
        logger.heading('::::::::::::::::::::::::::::::-- ESP Smart Alarms App is Starting --:::::::::::::::::::::::::::::::::')
        app = App()
        thread_data = threading.Thread(target=app.message_handler)
        thread_setpoint = threading.Thread(target=app.setpoit_handler)
        thread_data.start()
        thread_setpoint.start()
        app.run()
    except Exception as error:
            logger.exception(error,"Exception occurred in main")
            logger.error(traceback.format_exc())