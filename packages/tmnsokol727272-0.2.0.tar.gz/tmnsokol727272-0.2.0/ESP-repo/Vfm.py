import time
from datetime import timedelta, datetime, timezone
import traceback
import os
import json
from decimal import Decimal, InvalidOperation
from typing import Dict
from agoraiot import logger,bus_client,AgoraTimeStamp,config,IoDataReportMsg,IoPoint,IoDeviceData,RequestMsg
from PipeSimApi import PipeSimApi
from PipeSimData import EspDataScaling
from _utilities import show_publish_table
from StabilizationApi import StabilizationApi


if "ENABLE_STABILIZATION" in os.environ:
    enable_stabilzation = os.getenv("ENABLE_STABILIZATION")
else:
    enable_stabilzation = "False"

if "APP_TAGS" in os.environ:
    tags_version = os.getenv("APP_TAGS")
    if tags_version =="old":
        import tag_names_old as tag_names
    else:
        import tag_names as tag_names
else:
    import tag_names as tag_names

if "VFM_ALARMS_KEY" in os.environ:
    vfm_alarms_key = os.getenv('VFM_ALARMS_KEY')
else:
    vfm_alarms_key = "False"

if  "NON_VFM_ALARMS_KEY" in os.environ:
    non_vfm_alarms_key = os.getenv('NON_VFM_ALARMS_KEY')
else:
    non_vfm_alarms_key = "False"
    
if "VIRTUAL_TAGS" in os.environ:
    virtual_tags = os.getenv("VIRTUAL_TAGS")
    if virtual_tags:
        write_back_tags = [tag.strip() for tag in virtual_tags.split(',')]
else:
    write_back_tags = []
    
if "DATA_FORWARD" in os.environ:
    data_forward_key = os.getenv('DATA_FORWARD')
else:
    data_forward_key = "False"

TIME_FORMAT = '%Y-%m-%dT%H:%M:%SZ'
SET_FREQ_CONTROL_MODE = 0
SET_EXTENDED_RAMP_RATE_ON_OFF = 1
PREDICTED_PROBABILITY_CNSTNT = 1

class Vfm():

    def __init__(self,virtual_rtu_id, real_rtu_id, vfd):       
        self.virtual_id = str(virtual_rtu_id) 
        self.slave_id = str(real_rtu_id)
        self.vfd = str(vfd)
        self.calibration_path = config["Path:Calibration_Path"]+self.virtual_id
        self.calibration_file = config["Path:Calibration_FileName"]
        self.model_text_file = config["Path:Model_Text_FileName"]    
        self.license_filename = config["Path:License_FileName"]
        self.license_path = config["Path:License_Path"]
        appconfig_device_mapping = 'AppConfig:DeviceMapping:' + self.slave_id
        self.data_simulation = config[appconfig_device_mapping +':data_simulation']
        self.vfm_api_data_path = self.calibration_path+"/"+config["Path:Vfm_api_FileName"]
        self.glk_api_data_path = self.calibration_path+"/"+config["Path:glk_api_FileName"]
        self.stabilization_api_data_path =  self.calibration_path+"/"+config["Path:stabilization_api_FileName"]
        self.calibration_data_path = self.calibration_path+"/"+self.calibration_file
        self.model_text_file_path = self.calibration_path+"/"+self.model_text_file
        self.water_cut_flag = False
        self.well_test_flag = False
        self.license_key = True
        self.head_data_found = False
        self.pi_data_found = False
        self.vfm_data_found = False
        self.license_expiration_found = False   
        self.glk_data_found = False
        self.stage_1 = False
        self.well_stabilization_check = 0
        self.predicted_probability_pct = 0
        self.set_path = os.path.join(os.getcwd(), self.calibration_path)
        self.vfm_api_data = {"data": []}
        self.glk_api_data = {"data": []}
        self.stabilization_api_data = {"data": [], "threshold": 0}

        self.esp_scaled_data = EspDataScaling()
        self.pipe_sim_api = PipeSimApi(
            self.calibration_path + "/"+self.model_text_file,
            self.calibration_path + "/"+self.calibration_file,
            self.license_path + self.license_filename,
            self.slave_id,
            self.virtual_id
        )
        # create files if not present
        self.create_files()
        self.ready = True     
        self.stable_sim_api = StabilizationApi()
        
        try:
            # get license expiry date, at initialization time
            self.get_lic_expiry()
            #reset vfm dependent alarms
            # self.pipe_sim_api.workflow_vfm_dependent_alarm_reset()
            # self.pipe_sim_api.workflow_mwt_alarm_reset()
        except Exception as e:
            logger.debug("Exception occured as {}".format(e))
            logger.error(traceback.format_exc())

        self.start_vsd = 0
        self.drive_freq = 0
        self.target_drive_freq = 0
        self.step_size = 0
        self.step_interval = 0
        self.freq_control_mode = 0
        self.extended_ramp_rate_on_off = 0

    def create_files(self):
        try:
            if os.path.exists(self.calibration_path) != True:
                os.makedirs(self.calibration_path)
                        
            self.create_glk_api_files()                        
            self.create_vfm_api_files()
            self.create_stabilization_api_files()
            self.create_calibration_files()
            self.create_model_files()

        except Exception as e:
            logger.debug("Exception occured as {}".format(e))
            logger.error(traceback.format_exc()) 

    def create_vfm_api_files(self):
        if os.path.isfile(self.vfm_api_data_path):
            with open(self.vfm_api_data_path, 'r', encoding='utf-8') as payload:
                self.vfm_api_data = json.load(payload)
        else:
                    #Default configuration if nothing found in file
            with open(self.vfm_api_data_path, 'w', encoding='utf-8') as payload:
                json.dump({"data":[]}, payload, indent=4)
            with open(self.vfm_api_data_path, 'r', encoding='utf-8') as payload:
                self.vfm_api_data = json.load(payload)

    def create_glk_api_files(self):
        if os.path.isfile(self.glk_api_data_path):
            with open(self.glk_api_data_path, 'r', encoding='utf-8') as payload:
                self.glk_api_data = json.load(payload)
        else:
                    #Default configuration if nothing found in file
            with open(self.glk_api_data_path, 'w', encoding='utf-8') as payload:
                json.dump({"data":[]}, payload,indent=4)
            with open(self.glk_api_data_path, 'r', encoding='utf-8') as payload:
                self.glk_api_data = json.load(payload)     
    def create_stabilization_api_files(self):
            logger.info(f"Read api data json:- " + self.stabilization_api_data_path)
            if os.path.isfile(self.stabilization_api_data_path):
                with open(self.stabilization_api_data_path, 'r', encoding='utf-8') as payload:
                    self.stabilization_api_data = json.load(payload)
                    self.data_time_check()
                logger.info(f"Stabilization api data created successfully with existing file")
            else:
                #Default configuration if nothing found in file
                with open(self.stabilization_api_data_path, 'w', encoding='utf-8') as payload:
                    json.dump({"data": [], "threshold": 0.8}, payload)
                with open(self.stabilization_api_data_path, 'r', encoding='utf-8') as payload:
                    self.stabilization_api_data = json.load(payload)
                logger.info(f"Stabilization api data created successfully after creating file")
    def data_time_check(self):
        
        data_points = self.stabilization_api_data["data"]
        data_points.sort(key=lambda x: x["Time"])
        if len(data_points) != 0:
            latest_point = data_points[-1]
            current_time = datetime.now(timezone.utc)
            latest_time = datetime.strptime(latest_point["Time"], '%Y-%m-%dT%H:%M:%S%z')
            time_difference = current_time - latest_time
            if time_difference > timedelta(minutes=self.pipe_sim_api.stabilization_points_delay):
                print("The latest point is older than 60 minutes compared to the current time.")
                with open(self.stabilization_api_data_path, 'w', encoding='utf-8') as payload:json.dump({"data": [], "threshold": 0.8}, payload)
            else:
                print("The latest point is within the last 60 minutes compared to the current time.")

    def create_calibration_files(self):
        logger.debug(f"Read calibration json:- " + self.calibration_data_path)
        try:
            if not os.path.isfile(self.calibration_data_path):
                #   Default configuration if nothing found in file
                with open(self.calibration_data_path, 'w', encoding='utf-8') as payload:
                    json.dump({
                                    tag_names.well_test_water_cut_tag: 0,
                                    tag_names.well_test_liquid_flowrate_tag: 0,
                                    tag_names.well_test_intake_pressure_tag: 0,
                                    tag_names.well_test_discharge_pressure_tag: 0,
                                    tag_names.well_test_drive_frequency_tag: 0,
                                    tag_names.well_test_motor_temperature_tag: 0,
                                    tag_names.well_test_api_tag: 0,
                                    tag_names.well_test_gor_tag: 0,
                                    tag_names.well_test_reservoir_pressure_tag: 0,
                                    tag_names.well_test_reservoir_temperature_tag: 0
                                #add other tag from above list 
                            }, payload, indent=4)
                    logger.debug(f"Calibration payload created successfully after creating file")
        
        except Exception as e:
            logger.debug("exception occured as {}".format(e))
            logger.debug(traceback.format_exc())
    def create_model_files(self):
        logger.debug(f"Read Model Text json:- " + self.model_text_file_path)
        try:
            if not os.path.isfile(self.model_text_file_path):
                #   Default configuration if nothing found in file
                with open(self.model_text_file_path, 'w', encoding='utf-8') as payload:
                    json.dump({
                                    tag_names.well_test_water_cut_tag: 0,
                                    tag_names.well_test_api_tag: 0,
                                    tag_names.well_test_gor_tag: 0,
                                    tag_names.pi_model_text_tag :" ",
                                    tag_names.head_model_text_tag :" ",
                                    tag_names.head_calibration_threshold_tag : 5 ,
                                    tag_names. pi_calibartion_threshold_tag : 5
                            }, payload, indent=4)
                    logger.debug(f"Calibration payload created successfully after creating file")
        
        except Exception as e:
            logger.debug("exception occured as {}".format(e))
            logger.debug(traceback.format_exc())

    def data_write_handler(self,tags): 
        try:      
            return self.pipe_sim_api.update_config(tags, self.drive_freq)                 
            
        except Exception as error:
            logger.exception(error,"Exception occurred in data write handler")
            logger.error(traceback.format_exc())
            return False
            
    def file_download_handler(self,payload):
        try:      
            return self.pipe_sim_api.update_file(payload)                 

        except Exception as error:
            logger.exception(error,"Exception occurred in data write handler")
            logger.error(traceback.format_exc())
            return False
    """
        This function prepares data for VFM alarms by collecting various sensor readings and appending
        them to a JSON object, which is then added to a list until there are 60 points, at which point
        the list is assigned to the "model" key of another JSON object.
        @param tags - The `tags` parameter is a dictionary containing various sensor readings such as
        "Intake Pressure", "Discharge Pressure", "Drive Frequency", "Motor Temperature", etc. These
        readings are used to prepare data for VFM (Variable Frequency Drive) alarms.
        @returns a boolean value. If the length of the "data" list in the "api_data" dictionary is
        greater than or equal to 60, the function returns True. Otherwise, it returns False.
        Preapare vfm alarams data for 60 points
    """
    def prepare_vfm_alarms_data(self):
        try:
            if self.esp_scaled_data.scaled_data != None:
                current_json = {           
                    "DATE": time.strftime("%m/%d/%Y %H:%M", time.gmtime(AgoraTimeStamp() / 1000)),
                    "PIP": round(self.esp_scaled_data.scaled_data[tag_names.intake_pressure_tag].value,3),
                    "PDP": round(self.esp_scaled_data.scaled_data[tag_names.discharge_pressure_tag].value,3),
                    "FREQ": round(self.esp_scaled_data.scaled_data[tag_names.drive_frequency_tag].value,3),
                    "MT": round(self.esp_scaled_data.scaled_data[tag_names.motor_temperature_tag].value,3),
                    "Flowrate_head": round(self.pipe_sim_api.flow_rate_head,3),
                    "Flowrate_pi": round(self.pipe_sim_api.flow_rate_pi,3),
                }
                self.vfm_api_data["data"].append(current_json)
                self.write_config(self.vfm_api_data_path, json.dumps(self.vfm_api_data))
                if len(self.vfm_api_data["data"]) >=60:
                    self.vfm_api_data["device_id"] = self.slave_id # type: ignore
                    self.vfm_api_data["model"] = [self.pipe_sim_api.model_text_head]
                    logger.info("Data is prepared with 60 Points for vfm smart alarms")
                    return True
                else:
                    remaining_points = 60 - len(self.vfm_api_data["data"])
                    logger.info(f"Preparing data of 60 points for vfm smart alarms, remaining points: {remaining_points}")
                    return False
            else:
                return False
        except Exception as error:
            logger.exception(error,"Exception occurred in preparing alarm data")
            logger.error(traceback.format_exc())
            return False
    
    """
        This function handles data by checking for license expiry, checking for required tags, and
        calling other methods to simulate workflows and prepare data for VFM dependent alarms.
        @param tags - The input data that the function is handling. It is not specified what kind of
        data it is, but it is assumed to be related to some kind of simulation or workflow.
        @returns The function does not explicitly return anything, so it implicitly returns None.
        Call the logic of data handler
    """
    def data_handler(self,tags,print_lock):
        with print_lock:
            logger.info("<" * 30 + "  Process Start  "+">" * 30)
            logger.info("Data received from device: %s" % self.slave_id)
            self.lic_time=datetime.now().hour    
            if self.license_key == True:                         
                if self.lic_time == 1 or self.lic_time == 12:
                    self.get_lic_expiry()
                    self.license_key = False
                else:
                    self.license_key = True
            if  self.lic_time!= 1 and self.lic_time!= 12:
                self.license_key = True
            self.prepare_data(tags)
    
    def prepare_data(self, real_tags):
        data_check = False
        self.found_data = False
        self.well_stabilization_check = 0
        try:
            self.found_data = self.esp_scaled_data.scale_data(real_tags, self.vfd)
            logger.info("..............Data scaling done: "+str(self.found_data))
            self.read_real_tags_target_freq(real_tags)
            if self.is_scaled_tags_success():
                
                logger.debug("..............Tag data scaling success..... ")
                real_tags = self.esp_scaled_data.scaled_data
                data_check = self.esp_scaled_data.esp_data_validation(real_tags)

                if (self.drive_freq == 0 and self.pipe_sim_api.well_start == 1 and self.stage_1 == False):
                    self.do_esp_well_start_process()
                if self.stage_1 == True:
                    self.check_all_setpoints_valid_before_initial_rampup()
                #ESP Data Simulaton Process
                if self.data_simulation == "True":
                    logger.info("Data simulation for ESP is enabled....")
                    self.esp_start_stop_simulation(real_tags)
                else:
                    logger.info("Data simulation for ESP is disabled.....")
                # VFM head and Pi API call
                self.vfm_call(data_check,real_tags)
                if enable_stabilzation == "True":
                    logger.info("Stabilization is Enabled")
                    self.stabilization_ai_process()
                    if self.well_stabilization_check == 1:
                        # non-VFM Dependent Alarms 
                        self.non_vfm_alarm_call()
                        # VFM Dependent Alarms
                        self.vfm_alarm_call()
                    else:
                        logger.info("Stabilization is not True and not Calling Smart Alarms.....")
                else:
                    logger.info("Stabilization is Disabled and Normal processis used.")
                    # non-VFM Dependent Alarms 
                    self.non_vfm_alarm_call()
                    # VFM Dependent Alarms
                    self.vfm_alarm_call()
            self.send_virtual_data(real_tags)
        except Exception as err:
            logger.exception(err, "Exception occurred while IOData Report message")
            logger.error(traceback.format_exc())

    def stabilization_ai_process(self):
        try:        
            stabilization_data = self.prepare_stabilization_data()

            if stabilization_data == True:
                stabilization_api_mlmodel_check = self.stable_sim_api.workflow_stabilization(self.stabilization_api_data)
                logger.info("predicted label  : " + str(self.stable_sim_api.predicted_label))
                logger.info("predicted probability  : " + str(self.stable_sim_api.predicted_probability))

                if (self.well_stabilization_check == 0 and len(self.stabilization_api_data["data"]) > 0):
                    logger.info("data point to be deleted  : " + str(self.stabilization_api_data["data"][0]))
                    self.stabilization_api_data["data"].pop(0)

                if stabilization_api_mlmodel_check:                
                    self.stabilization_api_mlmodel_check_process()
                else:
                    logger.info("VFM based Stabilization FAILED : 1")                          

        except Exception as error:
            logger.error(str(error))
            logger.debug(traceback.format_exc()) 
        
    def stabilization_api_mlmodel_check_process(self):
        if self.is_decimal(self.stable_sim_api.predicted_label):
            if self.is_decimal(self.stable_sim_api.predicted_probability):
                self.predicted_probability_pct = float("{:.2}".format((self.stable_sim_api.predicted_probability)))
                logger.info("PREDICTED PROBABILITY PERCENT  : " + str(self.predicted_probability_pct))

            if (float(self.stable_sim_api.predicted_label) == PREDICTED_PROBABILITY_CNSTNT):
                    self.well_stabilization_check = 1
                    logger.info("...........STABILIZATION CHECK SUCCESSFUL")
            else:
                logger.debug("..........VFM based Stabilization FAILED : 3")
        else:
            logger.debug("..........VFM based Stabilization FAILED : 2") 
            
    def is_decimal(self, s):
        try:
            Decimal(s)
            return True
        except InvalidOperation:
            return False
    def prepare_stabilization_data(self):
        try:
            if self.esp_scaled_data.scaled_data != None:
                if (self.esp_scaled_data.scaled_data[tag_names.average_amps_tag].value > 0
                    and self.esp_scaled_data.scaled_data[tag_names.drive_frequency_tag].value > 0):
                        current_json = {
                            "Time": time.strftime(TIME_FORMAT, time.localtime(time.time())),
                            "Average_Amps": self.esp_scaled_data.scaled_data[tag_names.average_amps_tag].value,
                            "Drive_Frequency": self.esp_scaled_data.scaled_data[tag_names.drive_frequency_tag].value,
                        }
                        self.stabilization_api_data["data"].append(current_json)
                        self.write_config(self.stabilization_api_data_path, json.dumps(self.stabilization_api_data))

                self.stabilization_api_data["threshold"] = self.pipe_sim_api.stabilization_probability_threshold
                logger.debug("............ stabilization data points preparation {}".format(self.stabilization_api_data))
                if len(self.stabilization_api_data["data"]) >= self.pipe_sim_api.stabilization_threshold:
                    return True
                else:
                    logger.info("............ remaining data points " + str(self.pipe_sim_api.stabilization_threshold) + "  for stabilization : {}".format(self.pipe_sim_api.stabilization_threshold - len(self.stabilization_api_data["data"])))
                    return False
            else:
                return False
        except Exception as error:
            logger.error(str(error))
            logger.debug(traceback.format_exc())
            return False
    def  esp_start_stop_simulation(self,real_tags):
        
        if real_tags[tag_names.stop_vsd_tag].value == 1:
            logger.debug("Stop vsd is triggered, df = 0 .........................")
            self.process_real_io_data(self.setpoint_tags_stop_vsd_sim())
            
        elif real_tags[tag_names.start_vsd_tag].value == 1:
            logger.debug("start VSD triggered, DF = VSD DF..............................")
            target_freq = real_tags[tag_names.vsd_target_frequency_tag].value
            self.process_real_io_data(self.setpoint_tags_start_vsd_sim(target_freq))
        
        elif float((real_tags[tag_names.vsd_target_frequency_tag].value)/100) != float(real_tags[tag_names.drive_frequency_tag].value):
            logger.debug("Changing the Drive Frequency to VSD Target Frequency.........")
            target_freq = (real_tags[tag_names.vsd_target_frequency_tag].value)/100
            self.process_real_io_data(self.setpoint_tags_start_vsd_sim(target_freq))

    def vfm_call(self,data_check,real_tags):
        self.pipe_sim_api.flow_rate_head = 0
        self.pipe_sim_api.flow_rate_pi = 0
        self.pipe_sim_api.virtual_liquid_rate = 0
        if data_check:
            self.head_data_found = self.pipe_sim_api.workflow_simulation_head(real_tags)
            self.pi_data_found = self.pipe_sim_api.workflow_simulation_pi(real_tags)
            logger.info("VFM Simulation process is Completed")
        else:
            logger.info("ESP data is not valid for VFM calculation")
            
    def non_vfm_alarm_call(self):
        if non_vfm_alarms_key == "True":
            glk_data = self.prepare_glk_data()
            if glk_data:
                self.glk_data_found = self.pipe_sim_api.gasloack_and_emulsion_call(self.glk_api_data)
                self.glk_api_data["data"].pop(0)
            logger.info("Non-VFM Smart-Alarms process is Completed")
        else:
            logger.info("non-vfm data key is not set")
            
    def vfm_alarm_call(self):
        if self.head_data_found and self.pi_data_found and vfm_alarms_key == "True":
            vfm_data = self.prepare_vfm_alarms_data()
            if vfm_data:
                self.vfm_data_found = self.pipe_sim_api.workflow_vfm_dependent_alarm(self.vfm_api_data)
                self.vfm_api_data["data"].pop(0)
            logger.info("VFM Dependent Smart-Alarms process is Completed")
        else:
            logger.info("VFM dependent alarms require flow rate head and pi, and vfm alarm key should be True")        

    def is_scaled_tags_success(self):
        return self.found_data and self.esp_scaled_data.scaled_data != None
    
    def write_config(self, path, config):
        try:
            with open(path, 'w') as config_file:
                config_file.write(config)
            return True, "SUCCESS"
        except Exception as error:
            logger.error(str(error))
            logger.error(traceback.format_exc())
            return False, str(error)

    def prepare_glk_data(self):
        try:
            if self.esp_scaled_data.scaled_data != None:
                current_json = {
                    "Time": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.localtime(time.time())),
                    "Average_Amps": round(self.esp_scaled_data.scaled_data[tag_names.average_amps_tag].value,3),
                    "Intake_Pressure": round(self.esp_scaled_data.scaled_data[tag_names.intake_pressure_tag].value,3),
                    "Discharge_Pressure": round(self.esp_scaled_data.scaled_data[tag_names.discharge_pressure_tag].value,3),
                    "Drive_Frequency": round(self.esp_scaled_data.scaled_data[tag_names.drive_frequency_tag].value,3),
                    "Intake_Temperature": round(self.esp_scaled_data.scaled_data[tag_names.intake_temperature_tag].value,3),
                    "Motor_Temperature": round(self.esp_scaled_data.scaled_data[tag_names.motor_temperature_tag].value,3),
                    "Watercut": round(self.pipe_sim_api.well_test_water_cut,3),
                    "Pb":round(self.pipe_sim_api.bubble_point_pressure,3),
                    "API":round(self.pipe_sim_api.well_test_api,3),
                    "Drive_Frequency_Tolerance":round(self.pipe_sim_api.drive_frequency_tolerance,3)
                }
                self.glk_api_data["data"].append(current_json)
                self.write_config(self.glk_api_data_path, json.dumps(self.glk_api_data))
                if len(self.glk_api_data["data"]) >= 180:
                    self.glk_api_data["device_id"] = self.slave_id # type: ignore
                    logger.info("Data is prepared with 180 points for non-vfm alarms")
                    return True
                else:
                    logger.info("Preparing data of 180 points for non-vfm alarms Remaining points: {}".format(180-len(self.glk_api_data["data"])))
                    return False
            else:
                return False
        except Exception as error:
            logger.exception(error,"Exception in preparing data for glk")
            logger.error(traceback.format_exc())         
            return False 

    def update_timestamp(self, real_tags):
        for tag in real_tags:
            real_tags[tag].timestamp = self.timestamp
        return real_tags
            

    """
        This function sends data for an IODataReport message, including device data and various tags,
        and logs any exceptions that occur.
        @param tags - The `tags` parameter is a dictionary containing the data to be sent in the
        IoDataReportMsg message. It is used to update the `device_data.tags` dictionary with the data to
        be sent.
        @returns The function does not return anything explicitly, but it may return None if the
        condition "if not self.ready" is True.
        Update, append and send data to appropriate device
    """
    def send_virtual_data(self,real_tags):
        try:
            if not self.ready:
                return
            msg = IoDataReportMsg()
            msg.device = []
            device_data = IoDeviceData(id = self.virtual_id)  # type: ignore
            real_tags = self.update_timestamp(real_tags)
            if data_forward_key == "True":
                device_data.tags.update(real_tags)

            logger.info("*" * 20 + "  ESP DATA  "+"*" * 20)
            show_publish_table(self.pipe_sim_api.esp_real_tags_with_units(real_tags,self.timestamp))

            #commented this line for allowing data to write to virtual controller even data check has failed
            # if self.head_data_found or self.pi_data_found:
            device_data.tags.update(self.pipe_sim_api.hbm_flow_response(self.timestamp))

            if self.head_data_found:
                device_data.tags.update(self.pipe_sim_api.vfm_virtual_tags(real_tags,self.timestamp))    
            if self.vfm_data_found:
                device_data.tags.update(self.pipe_sim_api.vfm_alarms_response(self.timestamp))
            if self.glk_data_found:
                device_data.tags.update(self.pipe_sim_api.glk_alarms_response(self.timestamp)) 
            if self.license_expiration_found:
                lic = self.license_expiration
                device_data.tags.update({tag_names.license_expiration_tag: IoPoint(quality_code=0, timestamp=int(self.timestamp), value= lic)})
            #append stabiliztion data
            device_data.tags.update({tag_names.well_stabilization_check_tag: IoPoint(quality_code=0, timestamp=int(self.timestamp), value= self.well_stabilization_check)})
            device_data.tags.update({tag_names.stabilization_predicted_probability_tag: IoPoint(quality_code=0, timestamp=int(self.timestamp), value= self.predicted_probability_pct)})
            msg.device.append(device_data)
            bus_client.send_data(msg)
            self.send_to_real_id(msg)
            self.pipe_sim_api.calibration_flag = self.pipe_sim_api.flow_rate_head = self.pipe_sim_api.flow_rate_pi = 0 
            self.head_data_found = self.pi_data_found = self.vfm_data_found = self.glk_data_found = False
            logger.info("Data sent successfully to CLOUD with RTU id....: {}".format(self.virtual_id))
        except Exception as error:
            logger.exception(error,"Exception occurred in send flowrate")
            logger.error(traceback.format_exc())

    """
        This function creates a dictionary of IoPoint objects with specific values based on input tags.
        @param tagsvalue - The input parameter `tagsvalue` is a dictionary containing various key-value
        pairs, where each key represents a specific tag and its corresponding value represents the
        current value of that tag. The function extracts the values from this dictionary and creates a
        new dictionary `tags` with the same keys and values, but in
        @returns a dictionary object named "tags" which contains IoPoint objects with various properties
        such as quality_code, timestamp, and value. The IoPoint objects represent different measurements
        such as IntakePressure_Pa, DischargePressure_Pa, drive_frequency_hz, MotorTemperature_degC,
        operational_condition_indicator_percentage, operational_condition_flag,
        pi_drop_indicator_percentage, pump_low_eff_indicator_percentage, pump
        Get value of tags with Units
    """
    def send_to_real_id(self,data):
        try:
            if write_back_tags != []:
                # Header json data for real controller.
                msg = IoDataReportMsg()
                msg.device = []
                device_data = IoDeviceData(id = self.slave_id) # type: ignore
                # append VFM virtual tags to real controller
                if self.head_data_found or self.pi_data_found:
                    for tag in write_back_tags:
                        if tag in data.device[0].tags.keys():
                            device_data.tags.update({tag: IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value= data.device[0].tags[tag].value)})
                logger.info(".............Data Sending to Real Controller with RTU id: {}".format(self.slave_id))
                msg.device.append(device_data)
                bus_client.send_data(msg)
            else:
                logger.debug("Not writing VFM tags to real controller")
        except Exception as error:
            logger.exception(error,"Exception occurred in send flowrate to real controller")
            logger.error(traceback.format_exc())
    
    """
        This function retrieves the expiration date of a license and calculates the number of days until
        it expires.
        Calculate nomber of day to expired license
    """
    def get_lic_expiry(self):  
        self.license_expiration_found = False
        try:
            response = self.pipe_sim_api.workflow_license_validity()
            license_expiration_date = response[0]
            self.license_expiration_found = response[1]
            if license_expiration_date != None:
                license_expiration_date = datetime.strptime(license_expiration_date, "%d-%m-%Y") # type: ignore
                today_date = datetime.now()
                self.license_expiration = (
                    license_expiration_date - today_date).days
                logger.info(".........................................................")
                logger.info("pipesim license expire in days: {}".format(
                    self.license_expiration))
                logger.info("..........................................................")
        except Exception as e:
            logger.debug("error{}".format(e))
            logger.error(traceback.format_exc())

    def read_real_tags_target_freq(self, real_tags):

        try:
            for tag,io in real_tags.items():
                logger.debug(tag + " : " + str(io.value))
                io_value = round(float(io.value), 2)
                quality_code = io.quality_code
                if len(str(int(io.timestamp))) > 10:
                    self.timestamp = io.timestamp
                else:
                    self.timestamp = (io.timestamp*1000)+1 # Converting timestamp to millisenocds

                if quality_code == 0:
                    self.set_values_common_slb(tag, io_value,self.timestamp)

        except Exception as err:
            logger.exception(err, "Exception occurred in read_real_tags_target_freq")

    def set_values_common_slb(self, tag, io_value,timestamp):
        if tag == tag_names.drive_frequency_tag:
            self.drive_freq = io_value
            logger.info("Data source timestamp: "+str(timestamp))
            logger.debug("Drive Frequency : " + str(self.drive_freq))
        if tag == tag_names.vsd_target_frequency_tag:
            self.target_drive_freq = io_value
            logger.debug("VSD Target Frequency : " + str(self.target_drive_freq))
        if tag == tag_names.extended_ramp_rate_step_size_tag:
            self.step_size = io_value
            logger.debug("Step Size : " + str(self.step_size))
        if tag == tag_names.extended_ramp_rate_step_interval_tag:
            self.step_interval = io_value
            logger.debug("Step Interval : " + str(self.step_interval))
        if tag == tag_names.stop_vsd_tag:
            self.stop_vsd = io_value
            logger.debug("Stop VSD : " + str(self.stop_vsd))
        if tag == tag_names.start_vsd_tag:
            self.StartVSD_raw = io_value
            logger.debug("Start VSD : " + str(self.StartVSD_raw))
        if tag == tag_names.extended_ramp_rate_on_off_tag:
            self.extended_ramp_rate_on_off = io_value
        if tag == tag_names.frequency_control_mode_tag:
            self.freq_control_mode = io_value

    def do_esp_well_start_process(self):
        self.stage_1 = False
        try:
            if (self.pipe_sim_api.well_start == 1 and self.pipe_sim_api.operational_drive_frequency > 0):
                self.process_real_io_data(self.setpoint_tags_initial_stage())
                self.stage_1 = True
                logger.debug("Initial setpoints are sent to controller : " + str(self.pipe_sim_api.operational_drive_frequency))

        except Exception as error:
            logger.exception(error,"Exception occurred in do_esp_well_start_process")                

    def setpoint_tags_initial_stage(self) -> Dict[str, IoPoint]:
        
        try:
            tags: Dict[str, IoPoint] = {}     
            tags[tag_names.vsd_target_frequency_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = self.pipe_sim_api.operational_drive_frequency)
            tags[tag_names.frequency_control_mode_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = SET_FREQ_CONTROL_MODE)
            tags[tag_names.extended_ramp_rate_on_off_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = SET_EXTENDED_RAMP_RATE_ON_OFF)   
            tags[tag_names.extended_ramp_rate_step_size_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = self.pipe_sim_api.step_size) 
            # tags[tag_names.overload_amp_alarm_setpoint_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = self.overload_setpoint)
            
            tags[tag_names.min_frequency_setpoint_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 30)
            tags[tag_names.extended_ramp_rate_step_interval_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = self.pipe_sim_api.step_interval)
            tags[tag_names.clear_latched_motor_alarm_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 1) 
            tags[tag_names.clear_motor_lockouts_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 1)
            tags[tag_names.intake_pressure_high_trip_action_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 1) 
            tags[tag_names.discharge_pressure_low_trip_action_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 1)
            tags[tag_names.underload_trip_action_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 1)

            return tags
        
        except Exception as error:
            logger.exception(error,"Exception occurred in setpoint_tags_initial_stage")

    def check_all_setpoints_valid_before_initial_rampup(self):

        try:        
            logger.debug("Step size initial : " + str(self.step_size))
            logger.debug("Step interval initial : " + str(self.step_interval))
            logger.debug("SET Freq control mode initial : " + str(SET_FREQ_CONTROL_MODE))        
            logger.debug("Freq control mode initial : " + str(self.freq_control_mode))
            logger.debug("SET Extended ramp rate on/off initial : " + str(SET_EXTENDED_RAMP_RATE_ON_OFF))
            logger.debug("Extended ramp rate on/off initial : " + str(self.extended_ramp_rate_on_off))

            if (self.step_size == self.pipe_sim_api.step_size 
                    and self.step_interval == self.pipe_sim_api.step_interval
                    and self.freq_control_mode == SET_FREQ_CONTROL_MODE 
                    and self.extended_ramp_rate_on_off == SET_EXTENDED_RAMP_RATE_ON_OFF
                    and self.pipe_sim_api.well_start == 1 and self.target_drive_freq > 0
                    and self.pipe_sim_api.operational_drive_frequency == self.target_drive_freq):

                self.process_real_io_data(self.setpoint_tags_start_vsd())
                logger.debug("VSD is STARTED")
                self.stage_1 = False
                self.pipe_sim_api.well_start = 0
            else:
                self.do_esp_well_start_process()
                logger.debug("VSD is NOT STARTED as Initial setpoints are not Set ..........")

        except Exception as error:
            logger.exception(error,"Exception occurred in check_all_setpoints_valid_before_initial_rampup")

    def setpoint_tags_start_vsd(self) -> Dict[str, IoPoint]:

        try:
            tags: Dict[str, IoPoint] = {}      
            tags[tag_names.start_vsd_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 1)

            return tags
        
        except Exception as error:
            logger.exception(error,"Exception occurred in setpoint_tags_start_vsd")
    
    def setpoint_tags_stop_vsd_sim(self) -> Dict[str, IoPoint]:

        try:
            tags: Dict[str, IoPoint] = {}      
            tags[tag_names.drive_frequency_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 0)
            tags[tag_names.vsd_target_frequency_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 0)
            tags[tag_names.start_vsd_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 0)
            tags[tag_names.stop_vsd_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 0)

            return tags
        
        except Exception as error:
            logger.exception(error,"Exception occurred in setpoint_tags_start_vsd")
            
    def setpoint_tags_start_vsd_sim(self,target_freq) -> Dict[str, IoPoint]:

        try:
            tags: Dict[str, IoPoint] = {}      
            tags[tag_names.drive_frequency_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = target_freq)
            tags[tag_names.stop_vsd_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 0)
            tags[tag_names.start_vsd_tag] = IoPoint(quality_code=0, timestamp=int(AgoraTimeStamp()), value = 0)

            return tags
        
        except Exception as error:
            logger.exception(error,"Exception occurred in setpoint_tags_start_vsd")

    def process_real_io_data(self, update_function):

        try:
            msg = RequestMsg()
            msg.device = []
            device_data = IoDeviceData(id = self.slave_id)
            self.esp_scaled_data.reverse_scale_data(update_function, self.vfd)            
            reverse_scaled_tags = self.esp_scaled_data.reverse_scaled_data            
            device_data.tags.update(reverse_scaled_tags)
            msg.header.MessageType = "RequestDataWrite"
            msg.device.append(device_data)            
            bus_client.send_request(msg)
            logger.info("Request sent to real controller")

        except Exception as error:
            logger.exception(error,"Exception occurred in process_real_io_data")