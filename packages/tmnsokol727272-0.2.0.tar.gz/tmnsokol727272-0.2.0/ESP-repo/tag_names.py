#..................ESP Real Tags..........................
#ESP standard tags
average_amps_tag = "InputCurrent_A"
discharge_pressure_tag = "DischargePressure_psi"
drive_frequency_tag= "DriveFrequency_Hz"
intake_pressure_tag = "IntakePressure_psi"
intake_temperature_tag = "IntakeTemperature_degF"
motor_temperature_tag = "MotorTemperature_degF"

#ESP Startup Real Tags
clear_latched_motor_alarm_tag = "ClearLatchedMotorAlarm_raw"
clear_motor_lockouts_tag = "ClearMotorLockouts_raw"
discharge_pressure_low_trip_action_tag= "DischargePressureLowTripAction_raw"
extended_ramp_rate_step_interval_tag = "ExtendedRampRateStepInterval_sec"
extended_ramp_rate_step_size_tag= "ExtendedRampRateStepSize_Hz"
intake_pressure_high_trip_action_tag = "IntakePressureHighTripAction_raw"
min_frequency_setpoint_tag= "MinFrequencySetpoint_Hz"
start_vsd_tag = "StartVSD_raw"
stop_vsd_tag = "StopVSD_raw"
underload_trip_action_tag = "UnderLoadTripAction_raw"
vsd_target_frequency_tag = "VSDTargetFrequency_Hz"
frequency_control_mode_tag = "FrequencyControlMode_raw"
extended_ramp_rate_on_off_tag = "ExtendedRampRateOn/Off_raw"

#......................ESP Virtual tags...................

#ESP Startup Virtual Tags
operational_drive_frequency_tag = "OperationalDriveFrequency_Hz"
well_start_tag = "WellStart_raw"
step_interval_tag = "StepInterval_sec"
step_size_tag = "StepSize_Hz"


#threshold tags
head_calibration_threshold_tag = "HeadCalibrationThreshold_pct"
pi_calibartion_threshold_tag = "PICalibrationThreshold_pct"
bubble_point_pressure_tag = "BubblePointPressure_psi"
flowrate_selection_interval_tag = "FlowrateSelectionInterval_pct"
slope_calculation_interval_tag = "SlopeCalculationInterval_pct"
drive_frequency_tolerance_tag = "DriveFrequencyTolerance_Hz"
reset_mwt_alarm_tag = "ResetMWTAlarm_raw"
reset_pumpwear_alarm_tag = "ResetPumpwearAlarm_raw"
reset_mwt_alarm_all_tag = "ResetMWTAlarmAll_raw"
reset_pumpwear_alarm_all_tag = "ResetPumpwearAlarmAll_raw"
reset_flowrate_tag = "ResetFlowrate_raw"
reset_flowrate_all_tag = "ResetFlowrateAll_raw"

#ESP Well-test tags
well_test_water_cut_tag = "WellTestWaterCut_pct"
well_test_date_tag = "WellTestDate_date"
well_test_liquid_flowrate_tag = "WellTestLiquidFlowrate_blpd"
well_test_intake_pressure_tag = "WellTestIntakePressure_psi"
well_test_discharge_pressure_tag  = "WellTestDischargePressure_psi"
well_test_drive_frequency_tag= "WellTestDriveFrequency_Hz"
well_test_motor_temperature_tag = "WellTestMotorTemperature_degF"
well_test_api_tag = "WellTestAPI_dAPI"
well_test_gor_tag = "WellTestGOR_raw"
well_test_reservoir_pressure_tag = "WellTestReservoirPressure_psi"
well_test_reservoir_temperature_tag = "WellTestReservoirTemperature_degF"

#Model text tags (internal api response tags)
pi_model_text_tag = "pi_model_text"
head_model_text_tag = "head_model_text"
license_expiration_tag = "LicenseExpiration_days"

#flowrate tags
flow_rate_pi_tag = "FlowRatePI_blpd"
flow_rate_head_tag = "FlowRateHead_blpd"
calibration_flag_tag = "CalibrationFlag_raw"
model_created_date_tag = "ModelCreated_date"
virtual_liquid_rate_tag = "VirtualLiquidRate_blpd"
virtual_oil_rate_tag = "VirtualOilRate_bopd"
virtual_water_rate_tag = "VirtualWaterRate_bwpd"

#VFM Alarms tags
operational_condition_indicator_tag = "OperationalConditionIndicator_pct"
operational_condition_flag_raw_tag = "OperationalConditionFlag_raw"
pi_drop_indicator_tag = "PIDropIndicator_pct"
pump_low_eff_indicator_tag = "PumpLowEffIndicator_pct"
pump_wear_indicator_tag = "PumpWearIndicator_pct"
tubing_leak_indicator_tag = "TubingLeakIndicator_pct"

#Non-VFM Alarms(GLK and MWT) tags
gas_interference_indicator_tag = "GasInterferenceIndicator_pct"
gas_lock_indicator_tag = "GasLockIndicator_pct"
emulsion_solid_indicator_tag = "EmulsionSolidIndicator_pct"
motor_temperauture_indicator_tag = "MotorTemperatureIndicator_pct"
motor_temperature_defaut_mean_tag = "MotorTemperatureDefautMean_degF"

#VFM Dependent API tags (internal api response tags)
operational_condition_alarm_tag = "operational_condition_alarm"
operational_condition_flag_tag = "operational_condition_flag"
pi_drop_alarm_tag = "pi_drop_alarm"
pump_low_eff_alarm_tag = "pump_low_eff_alarm"
pump_wear_alarm_tag = "pump_wear_alarm"
tub_leak_alarm_tag = "tub_leak_alarm"

#Non-VFM Dependent(GLK and MWT) API tags (internal api response tags)
pred_label_gas_interference_tag = "pred_label_gas_interference"
pred_label_gas_lock_tag = "pred_label_gas_lock"
pred_label_emulsion_solid_tag = "pred_label_emulsion_solid"
pred_proba_mwt_alarm_tag = "pred_proba_mwt_alarm"
mean_default_mwt_tag = "mean_default_mwt"

#Stabilization ML model tags
well_stabilization_check_tag = "Smart_Alarms_well_stabilization_check"
stabilization_predicted_probability_tag = "Smart_Alarms_stabilization_predicted_probability"
stabilization_threshold_tag = "Smart_Alarms_stabilization_threshold"
stabilization_probability_threshold_tag = "Smart_Alarms_stabilization_probability_threshold"
stabilization_points_delay_tag = "Smart_Alarms_stabilization_points_delay"

#MISC tags
scaling_of_ones = "1,0,0,1"
scaling_of_tens = "1,0,0,10"
scaling_of_hundreds = "1,0,0,100"