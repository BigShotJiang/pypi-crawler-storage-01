"""Test package for mcp-scan."""
