"""
PeopleDataLabs Python Client.
"""

from .main import PDLPY


__version__ = "6.4.2"

__all__ = ["PDLPY"]
