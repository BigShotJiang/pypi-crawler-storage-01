"""Rich-PyFiglet
A fully featured wrapper around PyFiglet using the Rich library
for Python.
"""

from rich_pyfiglet.rich_figlet import RichFiglet

__all__ = ["RichFiglet"]
