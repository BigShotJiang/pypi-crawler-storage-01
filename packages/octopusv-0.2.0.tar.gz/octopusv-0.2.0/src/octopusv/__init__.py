"""Top-level package for OctopusV."""

__version__ = "0.1.0"
__PACKAGE_NAME__ = "octopusv"
