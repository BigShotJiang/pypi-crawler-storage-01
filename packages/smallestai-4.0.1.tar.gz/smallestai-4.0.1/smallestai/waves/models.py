TTSLanguages_lightning = ["en", "hi"]
TTSLanguages_lightning_large = ["en", "hi"]
TTSLanguages_lightning_v2 = ["en", "hi", "mr", "kn", "ta", "bn", "gu", "de", "fr", "es", "it", "pl", "nl", "ru", "ar", "he"]
TTSModels = [
    "lightning", 
    "lightning-large",
    "lightning-v2"
]
