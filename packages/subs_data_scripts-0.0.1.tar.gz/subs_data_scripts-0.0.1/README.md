# subs-data-scripts



*This is a placeholder package registered by the Schibsted Application Security Team (media-appsec@schibsted.com).**

This package exists **only** to prevent dependency confusion attacks and is not intended for public use.  
It contains no functional code and should not be used in production systems.
