# Placeholder package to prevent dependency confusion.
__version__ = "0.0.1"
