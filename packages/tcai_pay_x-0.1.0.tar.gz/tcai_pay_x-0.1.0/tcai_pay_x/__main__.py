# tcai_pay_x/__main__.py
from .webapp import run_app

if __name__ == "__main__":
    run_app()
