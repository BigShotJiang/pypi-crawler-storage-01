"""Metron Transform constants."""

from comicbox.enums.comicbox import IdSources

DEFAULT_ID_SOURCE = IdSources.METRON
