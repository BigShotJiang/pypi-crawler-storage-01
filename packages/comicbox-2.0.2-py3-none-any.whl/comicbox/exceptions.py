"""Exceptions for comicbox."""


class UnsupportedArchiveTypeError(Exception):
    """Unsupported Archive Type."""
