"""Comicbox metadata processing."""
