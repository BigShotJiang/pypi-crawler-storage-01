#__all__ = ['manman']
from .manman import __version__, Window

