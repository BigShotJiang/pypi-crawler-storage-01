"""Support for `python -m smpmgr`."""

from smpmgr.main import app

app(prog_name="smpmgr")
