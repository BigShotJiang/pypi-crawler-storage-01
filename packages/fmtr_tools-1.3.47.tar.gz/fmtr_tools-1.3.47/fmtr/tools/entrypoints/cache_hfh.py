def main():
    from fmtr import tools
    tools.hfh.main()
