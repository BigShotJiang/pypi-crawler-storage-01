class APIError(Exception):
    pass
