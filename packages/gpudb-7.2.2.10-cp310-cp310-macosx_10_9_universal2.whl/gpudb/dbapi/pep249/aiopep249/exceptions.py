"""Alias of ..exceptions."""
from gpudb.dbapi.pep249.exceptions import *  # pylint:disable=wildcard-import,unused-wildcard-import
