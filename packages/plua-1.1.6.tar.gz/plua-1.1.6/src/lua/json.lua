local json = {}
json.encode = _PY.json_encode
json.decode = _PY.json_decode
json.encodeFormated = _PY.json_encode_formated

return json