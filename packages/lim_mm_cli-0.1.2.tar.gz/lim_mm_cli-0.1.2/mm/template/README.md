## Structure
- mms: Micro Model Service, /meta.json must be specified to use the API, any framework to start from run/start.py
- models: trained AI models
- run: start.py run the mms 
