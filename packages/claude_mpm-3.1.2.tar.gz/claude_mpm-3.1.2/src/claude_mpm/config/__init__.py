"""Configuration module for claude-mpm."""

from .hook_config import HookConfig

__all__ = ['HookConfig']