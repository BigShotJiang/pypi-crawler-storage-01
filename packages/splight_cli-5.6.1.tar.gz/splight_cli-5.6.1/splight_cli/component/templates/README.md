# {{component_name}}

## Version: {{version}}

## Input

- **parameter**: Parameter description

## Use cases

-
