scityping.functions
===================

.. automodule:: scityping.functions
   :members:
   :undoc-members:
