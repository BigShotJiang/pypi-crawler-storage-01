scityping.json
==============

.. automodule:: scityping.json
   :members:
   :undoc-members: