scityping.utils
===============

.. automodule:: scityping.utils
   :members:
   :undoc-members: