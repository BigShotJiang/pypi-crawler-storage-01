scityping.numpy
===============

.. automodule:: scityping.numpy
   :members:
   :undoc-members:
