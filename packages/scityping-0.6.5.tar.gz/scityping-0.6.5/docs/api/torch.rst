scityping.torch
===============

.. automodule:: scityping.torch
   :members:
   :undoc-members: