scityping.base_types
====================

.. automodule:: scityping.base_types
   :members:
   :undoc-members:
