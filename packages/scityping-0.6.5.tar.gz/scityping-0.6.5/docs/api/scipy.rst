scityping.scipy
===============

.. automodule:: scityping.scipy
   :members:
   :undoc-members:
