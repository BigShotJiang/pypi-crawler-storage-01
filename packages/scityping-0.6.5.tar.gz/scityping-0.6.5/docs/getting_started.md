# Getting started

```{include} ../README.md
:start-after: "# Scityping: type hints and serializers for scientific types"
```
