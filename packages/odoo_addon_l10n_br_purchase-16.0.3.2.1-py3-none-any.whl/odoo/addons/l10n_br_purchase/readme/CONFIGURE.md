No configuration required.
