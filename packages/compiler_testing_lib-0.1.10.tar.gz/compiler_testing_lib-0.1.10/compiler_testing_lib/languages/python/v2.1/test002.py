# Python example: Always raise an exception
def is_prime(n):
    raise Exception("Exception raised")

# Function call for demonstration
is_prime(int(input()))