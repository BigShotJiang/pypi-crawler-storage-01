{
  // Missing OPEN_BRA
  z = 1;
  if (z == 1)
    z = 2;
  }
}