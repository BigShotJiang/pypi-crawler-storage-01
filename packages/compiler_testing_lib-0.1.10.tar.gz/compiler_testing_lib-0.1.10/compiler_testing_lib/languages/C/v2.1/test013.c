{
  // Unexpected token MULT
  r = *;
}