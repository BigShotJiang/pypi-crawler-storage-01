{
  // Unexpected token EOL
  m = 4/;
}