{
  {
    // Unexpected token OPEN_BRA
    f = 3;
  }
}