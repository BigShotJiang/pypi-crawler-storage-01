{
  // Unexpected token MULT
  a = *1;
}