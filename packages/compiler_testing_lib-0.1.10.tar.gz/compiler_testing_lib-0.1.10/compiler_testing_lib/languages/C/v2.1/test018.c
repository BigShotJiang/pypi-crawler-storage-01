{
  // Unexpected token CLOSE_BRA
  s = //6;
}