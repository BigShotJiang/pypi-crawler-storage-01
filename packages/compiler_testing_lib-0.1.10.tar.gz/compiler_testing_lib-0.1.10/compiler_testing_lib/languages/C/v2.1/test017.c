{
  // Unexpected token MULT
  o = 6**9;
}