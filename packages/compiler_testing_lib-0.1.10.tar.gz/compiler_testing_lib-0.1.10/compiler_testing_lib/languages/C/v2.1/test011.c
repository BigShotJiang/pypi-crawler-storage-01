{
  // Unexpected token EOL
  w = 4*;
}