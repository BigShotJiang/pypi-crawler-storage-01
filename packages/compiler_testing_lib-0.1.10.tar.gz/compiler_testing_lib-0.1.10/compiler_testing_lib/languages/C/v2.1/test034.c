{
  // Unexpected token CLOSE_BRA (expected EOF)
  t = 3;
}
}