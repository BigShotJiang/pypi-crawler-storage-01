{
  // Unexpected token DIV
  n = /2;
}