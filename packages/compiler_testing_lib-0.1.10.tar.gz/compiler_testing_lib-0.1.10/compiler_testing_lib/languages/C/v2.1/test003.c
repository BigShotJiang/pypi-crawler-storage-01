{
  // Unexpected token EOL
  b = 8-;
}