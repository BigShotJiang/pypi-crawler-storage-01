{
  // Missing OPEN_BRA
  m = 1;
  while (m == 1)
    m = 2;
  }
}