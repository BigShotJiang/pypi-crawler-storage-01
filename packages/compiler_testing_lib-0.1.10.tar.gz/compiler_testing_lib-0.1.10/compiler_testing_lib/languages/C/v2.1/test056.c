{
  // Missing OPEN_PAR
  while 1 == 1
    u = 7;
}