{
  // Unexpected EOF (Missing CLOSE_BRA)
  z = 1;
  while (z == 1) {
    z = 2;
}