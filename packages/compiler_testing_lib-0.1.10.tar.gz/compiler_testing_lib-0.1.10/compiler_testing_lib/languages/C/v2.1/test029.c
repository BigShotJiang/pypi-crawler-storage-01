{
  // Author: Rafael Dourado @rafaeldbo - Mar/2025
  // Unexpected token INT (expected OPEN_PAR)
  printf 6;
}