{
  // Unexpected token DIV
  r = 4*/4;
}