{
  // Unexpected EOF (Missing CLOSE_BRA)
  x = 1;
  if (x == 1) {
    x = 2;
  } else {
    x = 3;
}