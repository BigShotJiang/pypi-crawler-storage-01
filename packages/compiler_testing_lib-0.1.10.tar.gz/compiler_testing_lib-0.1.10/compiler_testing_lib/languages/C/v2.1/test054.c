{
  // Missing CLOSE_PAR
  n = scanf(;
}