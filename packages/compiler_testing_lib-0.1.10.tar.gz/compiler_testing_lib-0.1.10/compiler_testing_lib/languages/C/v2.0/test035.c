// Unexpected token IDEN (expected OPEN_BRA)
c = 7;