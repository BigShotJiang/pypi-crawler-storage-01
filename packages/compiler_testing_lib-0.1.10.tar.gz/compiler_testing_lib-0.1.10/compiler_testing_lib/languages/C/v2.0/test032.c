{
  // Unexpected token OPEN_BRA (expected EOF)
  h = 6;
}
{
}