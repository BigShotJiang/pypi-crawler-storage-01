{
  // Unexpected token EOL
  h = +;
}