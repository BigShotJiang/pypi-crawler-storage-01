{
  // Unexpected token CLOSE_BRA (expected EOF)
  w = 5;
}
}