{
  // Unexpected token DIV
  o = 5*/3;
}