{
  // Unexpected token CLOSE_PAR
  b = 4);
}