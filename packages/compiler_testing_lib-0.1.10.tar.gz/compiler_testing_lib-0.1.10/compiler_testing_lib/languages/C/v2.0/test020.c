{
  // Unexpected token MULT
  w = 2/*7;
}