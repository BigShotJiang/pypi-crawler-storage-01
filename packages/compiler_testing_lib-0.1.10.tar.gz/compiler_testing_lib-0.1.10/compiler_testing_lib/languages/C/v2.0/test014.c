{
  // Unexpected token DIV
  q = /;
}