{
  // Unexpected token EOL
  q = 2+;
}