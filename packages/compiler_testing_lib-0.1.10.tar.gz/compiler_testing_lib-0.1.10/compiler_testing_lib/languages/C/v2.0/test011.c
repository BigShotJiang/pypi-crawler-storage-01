{
  // Unexpected token EOL
  a = 2*;
}