{
  // Unexpected token MULT
  f = 3+*2;
}