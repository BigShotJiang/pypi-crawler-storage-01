{
  // Incompatible Types
  int d = 1*true;
}