{
  // Missing CLOSE_PAR
  int x = (2;
}