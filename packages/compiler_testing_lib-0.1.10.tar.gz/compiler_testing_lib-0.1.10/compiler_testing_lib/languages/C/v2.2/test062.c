{
  // Incompatible types
  bool g = 9;
}