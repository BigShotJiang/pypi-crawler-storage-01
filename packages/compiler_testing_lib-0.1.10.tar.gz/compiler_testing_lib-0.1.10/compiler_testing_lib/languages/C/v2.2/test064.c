{
  // Incompatible types
  str h = false;
}