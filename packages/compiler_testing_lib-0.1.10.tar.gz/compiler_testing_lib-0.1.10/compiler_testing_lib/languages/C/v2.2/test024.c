{
  // Unexpected token CLOSE_PAR
  int y = (9));
}