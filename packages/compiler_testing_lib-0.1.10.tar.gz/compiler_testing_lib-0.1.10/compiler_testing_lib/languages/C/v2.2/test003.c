{
  // Unexpected token EOL
  int x = 9-;
}