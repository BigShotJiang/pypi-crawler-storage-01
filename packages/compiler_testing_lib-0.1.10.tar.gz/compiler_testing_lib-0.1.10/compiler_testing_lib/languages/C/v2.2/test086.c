{
  // Incompatible Types
  int a = true*1;
}