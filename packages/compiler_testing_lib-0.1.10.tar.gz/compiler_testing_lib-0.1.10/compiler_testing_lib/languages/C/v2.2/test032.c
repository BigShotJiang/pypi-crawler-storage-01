{
  // Unexpected token OPEN_BRA (expected EOF)
  int x = 8;
}
{
}