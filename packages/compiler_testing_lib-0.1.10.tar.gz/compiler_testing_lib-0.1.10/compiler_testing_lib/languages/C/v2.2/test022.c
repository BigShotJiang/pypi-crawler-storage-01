{
  // Unexpected token CLOSE_PAR
  int n = 4);
}