{
  // Incompatible types
  int y = "a";
}