{
  // Unexpected token DIV
  int s = 1+/2;
}