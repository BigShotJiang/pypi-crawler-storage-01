{
  // Incompatible types
  str n = 6;
}