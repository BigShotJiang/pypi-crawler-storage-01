{
  // Incompatible Types
  bool u = 9<"a";
}