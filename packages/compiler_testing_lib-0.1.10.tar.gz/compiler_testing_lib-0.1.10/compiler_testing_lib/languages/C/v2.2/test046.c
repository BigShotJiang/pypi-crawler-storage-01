{
  // Missing OPEN_BRA
  int z = 1;
  while (z == 1)
    z = 2;
  }
}