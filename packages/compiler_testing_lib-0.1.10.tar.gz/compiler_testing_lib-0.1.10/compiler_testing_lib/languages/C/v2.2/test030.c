{
  // Identifier not found
  int x1 = 5;
  printf(X1);
}