{
  // Incompatible Types
  bool j = 4=="a";
}