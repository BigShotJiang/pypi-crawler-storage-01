{
  // Incompatible types
  bool t = 3;
}