{
  // Incompatible Types
  bool c = !7;
}