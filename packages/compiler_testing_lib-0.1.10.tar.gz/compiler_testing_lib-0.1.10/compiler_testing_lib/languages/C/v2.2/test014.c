{
  // Unexpected token DIV
  int n = /;
}