{
  // Incompatible types
  str x = scanf();
}