{
  // Unexpected token INT (expected EOL)
  int q = 5 2;
}