{
  // Incompatible Types
  int h = 1-true;
}