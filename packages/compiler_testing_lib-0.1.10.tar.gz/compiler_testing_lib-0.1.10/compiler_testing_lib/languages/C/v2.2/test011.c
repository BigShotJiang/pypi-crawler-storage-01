{
  // Unexpected token EOL
  int d = 2*;
}