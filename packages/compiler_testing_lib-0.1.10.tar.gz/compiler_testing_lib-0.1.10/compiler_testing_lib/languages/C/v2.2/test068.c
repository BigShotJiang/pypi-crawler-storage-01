{
  // Variable not found
  bool h = True;
}