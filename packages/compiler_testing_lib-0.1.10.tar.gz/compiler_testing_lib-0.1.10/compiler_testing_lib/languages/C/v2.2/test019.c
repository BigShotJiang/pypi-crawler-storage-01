{
  // Unexpected token DIV
  int x = 8*/2;
}