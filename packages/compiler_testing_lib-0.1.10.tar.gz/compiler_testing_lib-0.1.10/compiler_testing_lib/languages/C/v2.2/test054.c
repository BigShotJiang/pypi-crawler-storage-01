{
  // Missing CLOSE_PAR
  int y = scanf(;
}