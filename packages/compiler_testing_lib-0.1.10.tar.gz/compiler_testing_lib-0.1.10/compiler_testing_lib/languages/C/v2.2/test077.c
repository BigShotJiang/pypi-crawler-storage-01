{
  // Incompatible Types
  bool a = "a"<true;
}