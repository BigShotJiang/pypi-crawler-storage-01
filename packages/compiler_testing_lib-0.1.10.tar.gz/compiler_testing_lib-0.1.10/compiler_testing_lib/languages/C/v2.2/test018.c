{
  // Unexpected token CLOSE_BRA
  int z = //6;
}