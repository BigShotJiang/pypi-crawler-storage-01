// Unexpected token IDEN (expected OPEN_BRA)
int x = 3;