{
  // Incompatible Types
  str s = 7+5;
}