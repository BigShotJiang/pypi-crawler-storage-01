{
  // Missing OPEN_PAR
  while 1 == 1 {
    int m = 6;
  }
}