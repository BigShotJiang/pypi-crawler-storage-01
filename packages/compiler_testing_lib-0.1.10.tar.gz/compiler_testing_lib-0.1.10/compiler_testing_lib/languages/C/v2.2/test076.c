{
  // Incompatible Types
  bool o = true<5;
}