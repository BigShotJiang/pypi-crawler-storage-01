{
  // Incompatible Types
  bool o = "a"==true;
}