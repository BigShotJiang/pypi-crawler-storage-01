{
  // Unexpected token MULT
  int c = 6+*9;
}