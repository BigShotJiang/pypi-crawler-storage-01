{
  // Unexpected ELSE
  int z = 1;
  if (z == 1) {
    z = 2;
  } else {
    z = 3;
  } else {
    z = 4;
  }
}