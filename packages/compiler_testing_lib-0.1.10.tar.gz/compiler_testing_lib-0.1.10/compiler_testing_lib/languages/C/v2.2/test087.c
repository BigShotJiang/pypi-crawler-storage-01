{
  // Incompatible Types
  int u = 7/true;
}