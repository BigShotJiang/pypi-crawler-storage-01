{
  // Unexpected token MULT
  int j = *6;
}