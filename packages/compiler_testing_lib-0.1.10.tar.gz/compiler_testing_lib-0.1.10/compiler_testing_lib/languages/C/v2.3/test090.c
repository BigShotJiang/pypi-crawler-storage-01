void main() {
  // Incompatible Types
  str h = 3+4;
}