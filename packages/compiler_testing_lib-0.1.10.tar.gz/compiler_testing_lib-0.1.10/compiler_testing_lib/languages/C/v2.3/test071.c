void main() {
  // Incompatible Types
  bool f = "a"==true;
}