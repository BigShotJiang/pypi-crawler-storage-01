void main() {
  // Missing Right Expression
  int z = 1;
  if (!) {
    z = 2;
  }
}