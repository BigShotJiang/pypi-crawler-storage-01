void main() {
  // Unexpected token CLOSE_PAR
  int y = (2));
}