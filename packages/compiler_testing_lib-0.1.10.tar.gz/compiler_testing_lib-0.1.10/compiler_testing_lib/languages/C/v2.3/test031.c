void main() {
  // Unexpected token EOF (expected CLOSE_BRA)
  int s = 9;