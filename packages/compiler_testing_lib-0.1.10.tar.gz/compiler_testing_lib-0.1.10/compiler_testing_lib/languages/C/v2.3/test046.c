void main() {
  // Missing OPEN_BRA
  int t = 1;
  while (t == 1)
    t = 2;
  }
}