void main() {
  // Incompatible Types
  int j = true*1;
}