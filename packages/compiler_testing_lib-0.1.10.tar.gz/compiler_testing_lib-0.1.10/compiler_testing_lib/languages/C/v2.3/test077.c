void main() {
  // Incompatible Types
  bool u = "a"<true;
}