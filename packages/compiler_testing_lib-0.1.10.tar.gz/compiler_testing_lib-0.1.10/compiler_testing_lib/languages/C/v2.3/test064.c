void main() {
  // Incompatible types
  str n = false;
}