void main() {
  // Incompatible Types
  bool h = "a"<true;
}