int test(int x) {
  return x;
}
void main() {
  // Number of args wrong
  printf(test(4, 1));
}