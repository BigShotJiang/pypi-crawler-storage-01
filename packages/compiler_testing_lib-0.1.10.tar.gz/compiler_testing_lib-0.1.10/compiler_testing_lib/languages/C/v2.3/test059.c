void main() {
  // Incompatible types
  int o = "a";
}