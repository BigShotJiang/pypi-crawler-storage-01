void main() {
  // Unexpected token EOL
  int p = 6+;
}