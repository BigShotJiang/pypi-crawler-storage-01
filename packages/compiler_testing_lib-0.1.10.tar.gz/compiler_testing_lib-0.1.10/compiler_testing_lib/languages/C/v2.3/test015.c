void main() {
  // Unexpected token MULT
  int v = 5+*6;
}