void main() {
  // Incompatible Types
  bool g = true<1;
}