void main() {
  // Missing CLOSE_PAR
  int z = (1;
}