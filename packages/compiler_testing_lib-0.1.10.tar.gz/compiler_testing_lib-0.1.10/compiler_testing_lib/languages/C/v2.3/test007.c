void main() {
  // Unexpected token INT (expected EOL)
  int r = 2 9;
}