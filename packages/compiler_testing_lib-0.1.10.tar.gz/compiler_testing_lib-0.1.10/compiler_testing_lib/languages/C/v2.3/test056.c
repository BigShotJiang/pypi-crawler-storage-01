void main() {
  // Missing OPEN_PAR
  while 1 == 1 {
    int s = 7;
  }
}