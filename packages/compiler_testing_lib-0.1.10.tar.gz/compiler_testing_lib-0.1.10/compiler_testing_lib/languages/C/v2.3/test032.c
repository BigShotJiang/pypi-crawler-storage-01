void main() {
  // Unexpected token OPEN_BRA (expected EOF)
  int k = 7;
}
{
}