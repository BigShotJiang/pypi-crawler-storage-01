void main() {
  // Variable Already Declared
  int v;
  str v;
}