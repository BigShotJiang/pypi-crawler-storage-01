void main() {
  // Invalid token @
  int y = @;
}