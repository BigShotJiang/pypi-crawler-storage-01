void main() {
  // Incompatible Types
  bool u = "a"&&5;
}