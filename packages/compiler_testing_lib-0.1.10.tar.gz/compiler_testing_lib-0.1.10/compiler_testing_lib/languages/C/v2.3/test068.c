void main() {
  // Variable not found
  bool r = True;
}