void main() {
  // Unexpected EOF (Missing CLOSE_BRA)
  int z = 1;
  if (z == 1) {
}