void main() {
  // Missing OPEN_BRA
  int h = 1;
  if (h == 1) {
    h = 2;
  } else
    h = 3;
  }
}