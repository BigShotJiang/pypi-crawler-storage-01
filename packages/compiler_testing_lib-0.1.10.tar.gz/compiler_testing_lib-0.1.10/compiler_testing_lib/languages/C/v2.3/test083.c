void main() {
  // Incompatible Types
  int c = 1-true;
}