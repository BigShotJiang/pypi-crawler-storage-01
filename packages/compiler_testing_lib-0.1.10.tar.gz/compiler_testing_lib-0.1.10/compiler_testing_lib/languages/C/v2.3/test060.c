void main() {
  // Incompatible types
  bool x = 8;
}