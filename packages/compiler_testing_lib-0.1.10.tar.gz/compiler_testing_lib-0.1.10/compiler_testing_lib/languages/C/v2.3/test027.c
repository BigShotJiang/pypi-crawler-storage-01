void main() {
  // Unexpected token INT (expected OPEN_PAR)
  printf 4);
}