void main() {
  // Incompatible types
  str s = scanf();
}