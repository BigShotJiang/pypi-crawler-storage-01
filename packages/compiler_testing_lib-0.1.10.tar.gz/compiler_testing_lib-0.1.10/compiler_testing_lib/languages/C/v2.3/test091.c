void main() {
  // Incompatible Types
  bool p = "a"."b";
}