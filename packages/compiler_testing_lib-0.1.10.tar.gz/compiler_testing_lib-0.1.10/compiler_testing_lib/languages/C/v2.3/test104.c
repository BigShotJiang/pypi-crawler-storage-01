void main() {
  // Var out of scope
  {
    int w = 8;
  }
  w = 2;
}