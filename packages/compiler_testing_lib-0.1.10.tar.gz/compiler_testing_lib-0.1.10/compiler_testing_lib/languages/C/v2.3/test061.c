void main() {
  // Incompatible types
  bool m = "a";
}