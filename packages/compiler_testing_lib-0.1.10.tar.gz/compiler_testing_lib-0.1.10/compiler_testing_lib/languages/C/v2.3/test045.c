void main() {
  // Unexpected EOF (Missing CLOSE_BRA)
  int w = 1;
  while (w == 1) {
    w = 2;
}