void main() {
  // Unexpected token DIV
  int r = /;
}