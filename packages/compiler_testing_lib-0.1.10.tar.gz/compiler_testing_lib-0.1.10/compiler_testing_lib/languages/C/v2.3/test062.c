void main() {
  // Incompatible types
  bool m = 8;
}