void main() {
  // Unexpected token MULT
  int d = 9/*6;
}