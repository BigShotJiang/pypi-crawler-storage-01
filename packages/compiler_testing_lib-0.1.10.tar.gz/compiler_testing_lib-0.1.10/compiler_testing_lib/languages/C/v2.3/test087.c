void main() {
  // Incompatible Types
  int s = 8/true;
}