void main() {
  // Unexpected token EOL
  int g = ;
}