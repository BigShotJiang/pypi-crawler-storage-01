void main() {
  // Unexpected token OPEN_PAR (wrong print token)
  Printf(9);
}