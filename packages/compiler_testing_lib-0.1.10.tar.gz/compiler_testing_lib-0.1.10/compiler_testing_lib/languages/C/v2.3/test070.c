void main() {
  // Incompatible Types
  bool r = 1==true;
}