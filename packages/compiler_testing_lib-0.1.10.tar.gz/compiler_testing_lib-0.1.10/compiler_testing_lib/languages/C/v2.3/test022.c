void main() {
  // Unexpected token CLOSE_PAR
  int s = 9);
}