void main() {
  // Missing OPEN_PAR
  int m = scanf;
}