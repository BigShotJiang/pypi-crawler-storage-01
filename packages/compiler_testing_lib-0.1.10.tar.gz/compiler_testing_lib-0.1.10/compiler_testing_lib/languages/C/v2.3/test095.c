void Main() {
  // Missing function main
}