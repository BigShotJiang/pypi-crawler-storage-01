void main() {
  // Incompatible Types
  bool a = 1>true;
}