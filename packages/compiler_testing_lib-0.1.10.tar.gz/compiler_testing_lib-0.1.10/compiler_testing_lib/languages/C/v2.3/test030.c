void main() {
  // Identifier not found
  int x1 = 7;
  printf(X1);
}