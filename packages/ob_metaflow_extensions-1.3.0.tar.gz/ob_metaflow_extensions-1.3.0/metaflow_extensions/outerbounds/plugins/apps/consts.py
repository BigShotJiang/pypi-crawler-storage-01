DEFAULT_WAIT_TIME_SECONDS_FOR_PROCESS_TO_START = 10
BASE_DIR_FOR_APP_ASSETS = "/home/ob-workspace/.appdaemon/apps/"
APP_DAEMON_WORKSTAION_PATH = "/home/ob-workspace/.appdaemon"
