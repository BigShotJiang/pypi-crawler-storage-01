"""REST API service based on FastAPI."""
