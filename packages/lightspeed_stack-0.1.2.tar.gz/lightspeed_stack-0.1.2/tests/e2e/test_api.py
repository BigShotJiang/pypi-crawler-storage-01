"""Integration tests for basic REST API endpoints."""
