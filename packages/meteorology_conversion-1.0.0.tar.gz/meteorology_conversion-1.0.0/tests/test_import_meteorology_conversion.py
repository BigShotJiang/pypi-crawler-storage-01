def test_import_meteorology_conversion():
    import meteorology_conversion
