"""
This file is used to import all the functions from the modules and make them
available to the user.
Author: @julynx
"""

from __main__ import *
from .modules.convert import convert, live_convert, convert_text
