# sage_setup: distribution = sagemath-qepcad

from sage.all__sagemath_symbolics import *
