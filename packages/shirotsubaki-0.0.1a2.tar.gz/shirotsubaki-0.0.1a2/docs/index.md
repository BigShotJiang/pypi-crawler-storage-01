# Shirotsubaki

This package is being developed to help generate beautiful reports.  
You can install the release version from [PyPI](https://pypi.org/project/shirotsubaki/).
```
pip install shirotsubaki
```

See the function and class references below:  
[Reference](reference.md)
