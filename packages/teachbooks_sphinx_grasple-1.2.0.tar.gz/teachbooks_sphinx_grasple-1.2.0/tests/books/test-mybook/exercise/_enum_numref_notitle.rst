_enum_numref_notitle
====================

This is a reference :numref:`text-exc-notitle`.

This is a second reference :numref:`some text %s <text-exc-notitle>`.

This is a third reference :numref:`some text {number} <text-exc-notitle>`.

This is a fourth reference :numref:`some text {name} <text-exc-notitle>`.
