_enum_numref_placeholders
=========================


This reference does not include math :numref:`some {number} text %s test {name} <test-exc-label>`.

This reference does not include math :numref:`some {number} text %s test <test-exc-label>`.

This reference does not include math :numref:`some {name} text %s test <test-exc-label>`.

This reference does not include math :numref:`some {name} text {number} test <test-exc-label>`.

This reference does not include math :numref:`some %s text test <test-exc-label>`.



This reference includes math :numref:`some {number} text %s test {name} <test-exc-label-math>`.

This reference includes math :numref:`some {number} text %s test <test-exc-label-math>`.

This reference includes math :numref:`some {name} text %s test <test-exc-label-math>`.

This reference includes math :numref:`some {name} text {number} test <test-exc-label-math>`.

This reference includes math :numref:`some %s text test <test-exc-label-math>`.
