mth5.io package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mth5.io.lemi
   mth5.io.miniseed
   mth5.io.nims
   mth5.io.phoenix
   mth5.io.scripps
   mth5.io.usgs_ascii
   mth5.io.zen

Submodules
----------

mth5.io.collection module
-------------------------

.. automodule:: mth5.io.collection
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.reader module
---------------------

.. automodule:: mth5.io.reader
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.io
   :members:
   :undoc-members:
   :show-inheritance:
