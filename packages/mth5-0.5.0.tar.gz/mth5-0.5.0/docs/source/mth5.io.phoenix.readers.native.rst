mth5.io.phoenix.readers.native package
======================================

Submodules
----------

mth5.io.phoenix.readers.native.native\_reader module
----------------------------------------------------

.. automodule:: mth5.io.phoenix.readers.native.native_reader
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.io.phoenix.readers.native
   :members:
   :undoc-members:
   :show-inheritance:
