mth5.groups package
===================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mth5.groups.filter_groups

Submodules
----------

mth5.groups.base module
-----------------------

.. automodule:: mth5.groups.base
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.channel\_dataset module
-----------------------------------

.. automodule:: mth5.groups.channel_dataset
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.estimate\_dataset module
------------------------------------

.. automodule:: mth5.groups.estimate_dataset
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.experiment module
-----------------------------

.. automodule:: mth5.groups.experiment
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.fc\_dataset module
------------------------------

.. automodule:: mth5.groups.fc_dataset
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.filters module
--------------------------

.. automodule:: mth5.groups.filters
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.fourier\_coefficients module
----------------------------------------

.. automodule:: mth5.groups.fourier_coefficients
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.reports module
--------------------------

.. automodule:: mth5.groups.reports
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.run module
----------------------

.. automodule:: mth5.groups.run
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.standards module
----------------------------

.. automodule:: mth5.groups.standards
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.station module
--------------------------

.. automodule:: mth5.groups.station
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.survey module
-------------------------

.. automodule:: mth5.groups.survey
   :members:
   :undoc-members:
   :show-inheritance:

mth5.groups.transfer\_function module
-------------------------------------

.. automodule:: mth5.groups.transfer_function
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.groups
   :members:
   :undoc-members:
   :show-inheritance:
