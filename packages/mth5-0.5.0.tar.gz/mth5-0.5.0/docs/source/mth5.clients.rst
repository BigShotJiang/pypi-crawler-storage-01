mth5.clients package
====================

Submodules
----------

mth5.clients.base module
------------------------

.. automodule:: mth5.clients.base
   :members:
   :undoc-members:
   :show-inheritance:

mth5.clients.fdsn module
------------------------

.. automodule:: mth5.clients.fdsn
   :members:
   :undoc-members:
   :show-inheritance:

mth5.clients.geomag module
--------------------------

.. automodule:: mth5.clients.geomag
   :members:
   :undoc-members:
   :show-inheritance:

mth5.clients.lemi424 module
---------------------------

.. automodule:: mth5.clients.lemi424
   :members:
   :undoc-members:
   :show-inheritance:

mth5.clients.make\_mth5 module
------------------------------

.. automodule:: mth5.clients.make_mth5
   :members:
   :undoc-members:
   :show-inheritance:

mth5.clients.phoenix module
---------------------------

.. automodule:: mth5.clients.phoenix
   :members:
   :undoc-members:
   :show-inheritance:

mth5.clients.zen module
-----------------------

.. automodule:: mth5.clients.zen
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.clients
   :members:
   :undoc-members:
   :show-inheritance:
