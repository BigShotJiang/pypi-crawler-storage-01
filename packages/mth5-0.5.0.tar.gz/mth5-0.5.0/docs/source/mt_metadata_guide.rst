MT Metadata
===================

See `mt_metadata <https://mt-metadata.readthedocs.io/en/latest/>`_ documentation for more information on magnetotelluric time series and transfer function metadata standards.
