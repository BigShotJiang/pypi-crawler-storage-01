mth5.io.phoenix.readers.segmented package
=========================================

Submodules
----------

mth5.io.phoenix.readers.segmented.decimated\_segmented\_reader module
---------------------------------------------------------------------

.. automodule:: mth5.io.phoenix.readers.segmented.decimated_segmented_reader
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.io.phoenix.readers.segmented
   :members:
   :undoc-members:
   :show-inheritance:
