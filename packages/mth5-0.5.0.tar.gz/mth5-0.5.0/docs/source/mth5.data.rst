mth5.data package
=================

Submodules
----------

mth5.data.make\_mth5\_from\_asc module
--------------------------------------

.. automodule:: mth5.data.make_mth5_from_asc
   :members:
   :undoc-members:
   :show-inheritance:

mth5.data.paths module
----------------------

.. automodule:: mth5.data.paths
   :members:
   :undoc-members:
   :show-inheritance:

mth5.data.station\_config module
--------------------------------

.. automodule:: mth5.data.station_config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.data
   :members:
   :undoc-members:
   :show-inheritance:
