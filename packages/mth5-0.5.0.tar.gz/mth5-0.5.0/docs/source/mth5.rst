mth5 package
============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mth5.clients
   mth5.data
   mth5.groups
   mth5.io
   mth5.tables
   mth5.timeseries
   mth5.utils

Submodules
----------

mth5.helpers module
-------------------

.. automodule:: mth5.helpers
   :members:
   :undoc-members:
   :show-inheritance:

mth5.mth5 module
----------------

.. automodule:: mth5.mth5
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5
   :members:
   :undoc-members:
   :show-inheritance:
