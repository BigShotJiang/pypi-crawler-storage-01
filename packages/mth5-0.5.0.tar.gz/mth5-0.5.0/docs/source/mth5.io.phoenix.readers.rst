mth5.io.phoenix.readers package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mth5.io.phoenix.readers.contiguous
   mth5.io.phoenix.readers.native
   mth5.io.phoenix.readers.segmented

Submodules
----------

mth5.io.phoenix.readers.base module
-----------------------------------

.. automodule:: mth5.io.phoenix.readers.base
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.phoenix.readers.calibrations module
-------------------------------------------

.. automodule:: mth5.io.phoenix.readers.calibrations
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.phoenix.readers.config module
-------------------------------------

.. automodule:: mth5.io.phoenix.readers.config
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.phoenix.readers.header module
-------------------------------------

.. automodule:: mth5.io.phoenix.readers.header
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.phoenix.readers.helpers module
--------------------------------------

.. automodule:: mth5.io.phoenix.readers.helpers
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.phoenix.readers.receiver\_metadata module
-------------------------------------------------

.. automodule:: mth5.io.phoenix.readers.receiver_metadata
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.io.phoenix.readers
   :members:
   :undoc-members:
   :show-inheritance:
