mth5.io.usgs\_ascii package
===========================

Submodules
----------

mth5.io.usgs\_ascii.header module
---------------------------------

.. automodule:: mth5.io.usgs_ascii.header
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.usgs\_ascii.usgs\_ascii module
--------------------------------------

.. automodule:: mth5.io.usgs_ascii.usgs_ascii
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.usgs\_ascii.usgs\_ascii\_collection module
--------------------------------------------------

.. automodule:: mth5.io.usgs_ascii.usgs_ascii_collection
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.io.usgs_ascii
   :members:
   :undoc-members:
   :show-inheritance:
