mth5.io.phoenix package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mth5.io.phoenix.readers

Submodules
----------

mth5.io.phoenix.phoenix\_collection module
------------------------------------------

.. automodule:: mth5.io.phoenix.phoenix_collection
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.phoenix.read module
---------------------------

.. automodule:: mth5.io.phoenix.read
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.io.phoenix
   :members:
   :undoc-members:
   :show-inheritance:
