mth5.io.nims package
====================

Submodules
----------

mth5.io.nims.gps module
-----------------------

.. automodule:: mth5.io.nims.gps
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.nims.header module
--------------------------

.. automodule:: mth5.io.nims.header
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.nims.nims module
------------------------

.. automodule:: mth5.io.nims.nims
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.nims.nims\_collection module
------------------------------------

.. automodule:: mth5.io.nims.nims_collection
   :members:
   :undoc-members:
   :show-inheritance:

mth5.io.nims.response\_filters module
-------------------------------------

.. automodule:: mth5.io.nims.response_filters
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mth5.io.nims
   :members:
   :undoc-members:
   :show-inheritance:
