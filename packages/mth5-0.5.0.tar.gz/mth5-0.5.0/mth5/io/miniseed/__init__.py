# package file
from .miniseed import read_miniseed


__all__ = ["read_miniseed"]
