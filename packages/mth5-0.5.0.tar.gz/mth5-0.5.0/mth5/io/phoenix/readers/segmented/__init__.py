from .decimated_segmented_reader import DecimatedSegmentedReader

__all__ = ["DecimatedSegmentedReader"]
