__all__ = [
    "attr_c",
    "fn_c",
]

attr_c = 3.0


def fn_c() -> float:
    return 3.0
