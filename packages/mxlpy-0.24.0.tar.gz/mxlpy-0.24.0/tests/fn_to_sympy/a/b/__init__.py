from . import c

__all__ = [
    "attr_b",
    "c",
    "fn_b",
]

attr_b = 2.0


def fn_b() -> float:
    return 2.0
