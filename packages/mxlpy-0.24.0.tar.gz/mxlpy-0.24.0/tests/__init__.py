"""Test init file"""

from __future__ import annotations
