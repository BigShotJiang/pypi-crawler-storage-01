"""Test suite for the SBML module."""

from __future__ import annotations
