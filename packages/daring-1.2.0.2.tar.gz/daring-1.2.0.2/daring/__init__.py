#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @File     : setup
# @Author   : Raodi
# @Time     : 2024/7/24 14:19
from __future__ import absolute_import
from daring.GoogleBatchTranslator import *
from daring.RSql import *

name = "Raodi"
