# core/__init__.py
# Export main functions so they can be imported directly from core
from . import m2
from . import gc2
from . import process_ssr_results 