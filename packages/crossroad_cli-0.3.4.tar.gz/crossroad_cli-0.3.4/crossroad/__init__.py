"""CrossRoad: A tool for analyzing SSRs in genomic data"""

__version__ = "0.3.4" 