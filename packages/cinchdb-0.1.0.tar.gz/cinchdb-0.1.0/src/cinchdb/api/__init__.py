"""CinchDB API package."""

from cinchdb.api.app import app

__all__ = ["app"]
