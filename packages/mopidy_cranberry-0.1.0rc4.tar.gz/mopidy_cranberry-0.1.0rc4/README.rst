****************
Mopidy-Cranberry
****************

An opinionated `Mopidy <https://mopidy.com/>`_ frontend.


Installation
============

Install by running::

    sudo pip install Mopidy-Cranberry

.. Or, if available, install the Debian/Ubuntu package from `apt.mopidy.com
.. <https://apt.mopidy.com/>`_.


Configuration
=============

Nothing to configure yet


Project resources
=================

- `Source code <https://github.com/alkern/cranberry>`_
- `Issue tracker <https://github.com/alkern/cranberry/issues>`_


Changelog
=========

v0.1.0 (2025-??-??)
-------------------

- Initial release.