# json_equationer
A package for creating json equation records and evaluating them. 


## **0\. Creating a Record**
