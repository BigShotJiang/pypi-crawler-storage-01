# sage_setup: distribution = sagemath-ecl

from sage.all__sagemath_categories import *
