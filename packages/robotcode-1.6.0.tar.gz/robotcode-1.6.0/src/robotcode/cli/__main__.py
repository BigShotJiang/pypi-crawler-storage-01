def main() -> None:
    from . import robotcode

    robotcode(max_content_width=120, windows_expand_args=False)


if __name__ == "__main__":
    main()
