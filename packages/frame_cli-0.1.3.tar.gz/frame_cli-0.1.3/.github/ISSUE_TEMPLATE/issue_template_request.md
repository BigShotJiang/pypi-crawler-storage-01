---
name: Issue template request
about: Suggest an idea for a new issue template
title: ""
labels: enhancement
assignees: sphamba
---

**Bug and Feature issues are not enough ?**

Please ask for a new kind of template if you think it's necessary
