if (!localStorage.getItem("darkmode")) {
	localStorage.setItem("darkmode", "off");
}
