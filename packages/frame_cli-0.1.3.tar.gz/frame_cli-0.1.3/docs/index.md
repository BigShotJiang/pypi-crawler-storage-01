# FRAME CLI Documentation

Welcome to the [FRAME CLI](https://github.com/CHANGE-EPFL/frame-project-cli) documentation!

```{toctree}
:maxdepth: 2
:caption: Contents

src/user/user_guide
src/developer/developer_guide
```

## Indices and Tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
