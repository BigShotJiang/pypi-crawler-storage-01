def test_dummy():
    import frame_cli

    assert frame_cli is not None
