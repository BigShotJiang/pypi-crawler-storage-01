GCID
===

Global, Cryptographic, Identifiers
====


Global 
=====

Identifiers contain internal location tagging information that can
be used in a federated system to locate objects globally while
maintaining private internal number spaces.


Crytographic
=====

Identifiers can be reversed to provide metadata such as row number
and shard without exposing this information to external observers.


Identifiers
=====

Strings that can be used with APIs such as is seen in APIs from Stripe, et al.


