remote
======

.. automodule:: spicerack.remote
