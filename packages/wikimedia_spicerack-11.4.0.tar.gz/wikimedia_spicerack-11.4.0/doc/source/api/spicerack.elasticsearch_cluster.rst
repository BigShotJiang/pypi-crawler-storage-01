elasticsearch_cluster
=====================

.. automodule:: spicerack.elasticsearch_cluster
