debmonitor
==========

.. automodule:: spicerack.debmonitor
