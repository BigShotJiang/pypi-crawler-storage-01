administrative
==============

.. automodule:: spicerack.administrative
