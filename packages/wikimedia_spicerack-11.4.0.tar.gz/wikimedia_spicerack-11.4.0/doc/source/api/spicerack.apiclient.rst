apiclient
=========

.. automodule:: spicerack.apiclient
