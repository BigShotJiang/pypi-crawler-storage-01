"""Unit tests package for Spicerack."""
