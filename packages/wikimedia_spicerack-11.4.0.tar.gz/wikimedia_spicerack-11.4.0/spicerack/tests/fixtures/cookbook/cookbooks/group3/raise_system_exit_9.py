"""Group3 Raise SystemExit(9)."""

import sys


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    raise sys.exit(9)
