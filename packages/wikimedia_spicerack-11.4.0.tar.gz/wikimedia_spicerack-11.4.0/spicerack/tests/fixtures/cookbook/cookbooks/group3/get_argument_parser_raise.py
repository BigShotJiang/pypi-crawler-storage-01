"""Group3 get argument_parser() raise."""


def argument_parser():
    """As required by spicerack._cookbook."""
    raise RuntimeError("argument_parser() raise")


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
