"""Group3 Raise KeyboardInterrupt."""


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    raise KeyboardInterrupt
