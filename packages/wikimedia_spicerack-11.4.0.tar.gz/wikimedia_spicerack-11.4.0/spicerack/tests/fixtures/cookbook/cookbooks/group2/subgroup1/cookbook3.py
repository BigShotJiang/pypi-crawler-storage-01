"""Group2 Subgroup1 Cookbook3."""


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    return 0
