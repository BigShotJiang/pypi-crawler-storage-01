"""Group3 Subgroup3 Cookbook4."""

__owner_team__ = "team9"


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    return 0
