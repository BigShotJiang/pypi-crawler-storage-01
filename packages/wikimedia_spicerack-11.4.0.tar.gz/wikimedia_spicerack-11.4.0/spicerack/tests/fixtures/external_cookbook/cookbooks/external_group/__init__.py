"""External Group Test Cookbooks."""

__title__ = __doc__
