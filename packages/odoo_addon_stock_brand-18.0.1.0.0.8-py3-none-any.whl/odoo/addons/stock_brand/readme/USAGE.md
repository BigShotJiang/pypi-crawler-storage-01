To use this module, you need to:

1.  Go to Sales \> Sale Orders
2.  Select or create a sale order
3.  Enter the information and the brand
4.  Confirm Sale order to create pickings
5.  Print the delivery slip PDF report. It includes the information of
    the brand.

To do point 5, the [Brand External Report Layout](https://github.com/OCA/brand/tree/18.0/brand_external_report_layout/README.rst) OCA module must be installed.
