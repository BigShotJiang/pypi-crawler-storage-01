# Changelog

## [0.1.0] - 2025-08-03

- Add `cv2.error`
- Other fixes.

## [0.0.12] - 2025-06-08

- Add `cv2.pollKey`

## [0.0.11] - 2025-03-07

-Add missing inits for `VideoCapture` and `VideoWriter`.
