"""Provide generic and mocked python objects to call in tests."""

GENERIC_DICT = {"key": "value"}
