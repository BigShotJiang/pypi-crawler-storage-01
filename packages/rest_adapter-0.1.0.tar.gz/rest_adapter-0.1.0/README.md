# Rest Adapter

**Rest Adapter** is a Python wrapper for the Requests module. This is intended primarily for HBNet Networks internal use, but is free for any interested party to use.

## Please note
This project is a Work In Progress and is intended primarily for HBNet Networks internal use.

## Contributing

Contributions and suggestions are welcome! Please open issues or pull requests.

## License

This project is licensed under the GNU/GPL License. See the [LICENSE](LICENSE) file for details.

---

© 2025 HBNet Networks
