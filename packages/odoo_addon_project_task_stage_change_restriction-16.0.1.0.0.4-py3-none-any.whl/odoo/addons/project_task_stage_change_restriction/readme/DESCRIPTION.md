This module allows specifying which users or groups can move a task to a specific stage.
