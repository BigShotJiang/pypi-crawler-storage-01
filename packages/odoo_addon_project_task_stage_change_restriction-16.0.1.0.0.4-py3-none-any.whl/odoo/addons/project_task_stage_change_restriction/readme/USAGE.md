Try to move a task to a restricted stage. If your user doesn't satisfy the stage-allowance conditions, the following access error will be raised:  
"Sorry, you are not allowed to move the task '<task_name>' into the stage '<stage_name>'."
