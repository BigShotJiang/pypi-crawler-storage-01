"""
This module includes general utility classes and functions used extensively in diplomat.
"""
