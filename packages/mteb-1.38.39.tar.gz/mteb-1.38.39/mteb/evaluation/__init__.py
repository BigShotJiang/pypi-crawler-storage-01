from __future__ import annotations

from .MTEB import *
