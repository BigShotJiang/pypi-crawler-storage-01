# **Getting started**
To load QuanEstimation, start with the statement: 
=== "Python"
    ``` py
    from quanestimation import *
    ```
=== "Julia"
    ``` jl
    using quanestimation
    ```