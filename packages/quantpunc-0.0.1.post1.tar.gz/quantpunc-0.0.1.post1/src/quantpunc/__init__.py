__version__ = "0.0.1.post1"

from quantpunc.quantpunc_widget import QuantPunc

__all__ = ["QuantPunc"]
