from inference.models.trocr.trocr import TrOCR
