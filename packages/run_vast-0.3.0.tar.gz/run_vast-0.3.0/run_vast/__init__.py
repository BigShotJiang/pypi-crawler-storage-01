from .run_vast import main

__all__ = ['main']
