{% macro bigquery__intersect() %}

    intersect distinct

{% endmacro %}
