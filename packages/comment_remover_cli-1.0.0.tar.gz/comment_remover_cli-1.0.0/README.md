# 🗂️ Comment Remover CLI - Universal Comment Remover

A high-accuracy Python tool that removes comments from 20+ programming languages while preserving code functionality. Features automatic backup, undo capability, and configurable settings.

## ✨ Features

- **🌍 Universal Support**: 20+ programming languages
- **🔄 Safe Operation**: Automatic backup before processing
- **⏪ Undo Function**: Restore original files anytime
- **⚙️ Configurable**: JSON-based settings
- **🧪 Demo Mode**: Generate test files for validation
- **🚀 High Performance**: Processes entire directory trees
- **📁 Recursive Scanning**: All subdirectories included
- **🛡️ Error Handling**: Robust file processing

## 🚀 Quick Start

### Installation

```bash
# Install via pip (recommended)
pip install comment-remover-cli

# Or install from source
git clone https://github.com/guider23/Comms.git
cd Comms/comms_package
pip install .
```

### Basic Usage

```bash
# Remove comments from current directory
comment-remover

# Remove comments from specific directory
comment-remover /path/to/your/project

# Create demo files for testing
comment-remover --demo

# Undo last operation
comment-remover --undo

# Show help
comment-remover --help

# Alternative short command (alias)
comms
```

## 📖 Detailed Usage

### Command Line Options

```bash
comment-remover [directory] [options]

Options:
  -h, --help     Show help message
  --demo         Create demo files with comments for testing
  --undo         Restore files from last backup
  --config FILE  Use custom config file (default: config.json)
  --dry-run      Show what would be processed without making changes
  --verbose      Show detailed processing information
```

### Examples

```bash
# Process current directory with verbose output
comment-remover --verbose

# Use custom config
comment-remover /my/project --config my-config.json

# See what would be processed (dry run)
comment-remover --dry-run

# Create test files, then process them
comment-remover --demo
comment-remover demo_files/
```

## ⚙️ Configuration

Create a `config.json` file to customize behavior:

```json
{
  "languages": {
    "python": {
      "extensions": [".py"],
      "line_comment": "#",
      "block_comment_start": "\"\"\"",
      "block_comment_end": "\"\"\""
    },
    "javascript": {
      "extensions": [".js", ".jsx", ".ts", ".tsx"],
      "line_comment": "//",
      "block_comment_start": "/*",
      "block_comment_end": "*/"
    }
  },
  "backup_enabled": true,
  "backup_directory": ".backup",
  "skip_patterns": [
    "node_modules/",
    ".git/",
    "__pycache__/",
    "*.min.js",
    "*.min.css"
  ]
}
```

## 🗣️ Supported Languages

| Language | Extensions | Line Comments | Block Comments |
|----------|------------|---------------|----------------|
| Python | .py | # | """ """ or ''' ''' |
| JavaScript/TypeScript | .js, .jsx, .ts, .tsx | // | /* */ |
| Java | .java | // | /* */ |
| C/C++ | .c, .cpp, .h, .hpp | // | /* */ |
| C# | .cs | // | /* */ |
| Go | .go | // | /* */ |
| Rust | .rs | // | /* */ |
| PHP | .php | // | /* */ |
| Ruby | .rb | # | =begin =end |
| Shell/Bash | .sh, .bash | # | - |
| Perl | .pl, .pm | # | =pod =cut |
| R | .r, .R | # | - |
| MATLAB | .m | % | %{ %} |
| SQL | .sql | -- | /* */ |
| HTML | .html, .htm | - | <!-- --> |
| CSS | .css | - | /* */ |
| SCSS/Sass | .scss, .sass | // | /* */ |
| Lua | .lua | -- | --[[ ]] |
| Swift | .swift | // | /* */ |
| Kotlin | .kt, .kts | // | /* */ |

## 🔄 Backup & Undo

### Automatic Backup
- Every operation creates a timestamped backup in `.backup/`
- Original file structure is preserved
- Multiple backups are kept for safety

### Undo Operation
```bash
# Restore from most recent backup
comment-remover --undo

# List available backups (if implemented)
ls .backup/
```

### Manual Backup Management
```bash
# Backup location
.backup/
├── backup_20231120_143022/
│   ├── src/
│   │   └── main.py
│   └── index.js
└── backup_20231120_142015/
    └── ...
```

## 🧪 Testing & Demo

Generate test files to validate the tool:

```bash
# Create demo files with comments
comment-remover --demo

# Process the demo files
comment-remover demo_files/

# Check the results
cat demo_files/example.py
```

## 🛡️ Safety Features

1. **Automatic Backup**: Every file is backed up before processing
2. **String Literal Protection**: Comments inside strings are preserved
3. **Dry Run Mode**: Preview changes before execution
4. **Error Recovery**: Failed operations don't corrupt files
5. **Undo Capability**: Restore original files anytime

## 🔧 Advanced Usage

### Custom Config File
```bash
comment-remover --config custom-config.json /my/project
```

### Processing Specific File Types
Edit `config.json` to limit processing to specific languages or add new ones.

### Integration with Build Systems
```bash
# In your build script
comment-remover src/ --config production-config.json
```

## 📋 Requirements

- Python 3.6 or higher
- No external dependencies
- Cross-platform (Windows, macOS, Linux)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details.

## 🆘 Support

- **Issues**: Report bugs on [GitHub Issues](https://github.com/guider23/Comms/issues)
- **Discussions**: Community support on [GitHub Discussions](https://github.com/guider23/Comms/discussions)
- **Documentation**: Full docs at [GitHub Repository](https://github.com/guider23/Comms)

## 🏆 Why Comms?

- **Reliable**: Rule-based parsing, no AI uncertainty
- **Fast**: Processes large codebases quickly
- **Safe**: Comprehensive backup system
- **Flexible**: Highly configurable
- **Maintained**: Active development and support

---

**Made with ❤️ for developers who value clean, comment-free code in production.**
