"""
Subcommands package for vibectl.

This package contains organized subcommand implementations that have been
separated from the main cli.py module for better maintainability.
"""
