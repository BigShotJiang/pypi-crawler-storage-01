"""vibectl gRPC protocol definitions."""

from . import llm_proxy_pb2, llm_proxy_pb2_grpc

__all__ = ["llm_proxy_pb2", "llm_proxy_pb2_grpc"]
