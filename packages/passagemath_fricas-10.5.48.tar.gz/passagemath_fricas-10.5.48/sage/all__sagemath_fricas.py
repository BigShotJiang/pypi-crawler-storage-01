# sage_setup: distribution = sagemath-fricas

from sage.all__sagemath_symbolics import *
