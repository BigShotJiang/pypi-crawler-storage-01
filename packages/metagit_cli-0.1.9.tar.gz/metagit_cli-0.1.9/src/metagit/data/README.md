# Metagit Data

Much of this is unused currently. The only item that matters is the `metagit.config.yaml` file which represents the default configuration if none is passed in or found in the default or directory.