"""Environment Interface and Wrappers to abstract different simulation environments.
"""