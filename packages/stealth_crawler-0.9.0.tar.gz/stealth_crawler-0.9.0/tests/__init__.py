"""Tests for the stealth crawler."""
