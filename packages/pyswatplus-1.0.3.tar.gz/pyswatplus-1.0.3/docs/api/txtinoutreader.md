::: pySWATPlus.TxtinoutReader
