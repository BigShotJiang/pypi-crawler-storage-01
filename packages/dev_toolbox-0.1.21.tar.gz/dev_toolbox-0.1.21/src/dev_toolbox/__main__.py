from __future__ import annotations

import sys

if __name__ == "__main__":
    from dev_toolbox.cli import dev_toolbox

    sys.exit(dev_toolbox())
