from __future__ import annotations


def dev_toolbox() -> int:
    print("Hello world!")
    return 0
