# OneSecondTrader

[![Tests](https://github.com/nilskujath/onesecondtrader/actions/workflows/release.yml/badge.svg)](https://github.com/nilskujath/onesecondtrader/actions/workflows/release.yml)
[![Docs](https://img.shields.io/badge/docs-onesecondtrader.com-blue)](https://www.onesecondtrader.com)
[![PyPI](https://img.shields.io/pypi/v/onesecondtrader)](https://pypi.org/project/onesecondtrader/)
[![License](https://img.shields.io/github/license/nilskujath/onesecondtrader)](https://github.com/nilskujath/onesecondtrader/blob/master/LICENSE)


For documentation, please visit [onesecondtrader.com](https://www.onesecondtrader.com).
