class CertificateNotApprovedException(Exception):
    """The requested certificated was not approved"""

    pass
