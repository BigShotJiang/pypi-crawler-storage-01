# OpenID Federation Entity Collection Service

This project implements the [OpenID Federation Entity Collection specification](https://zachmann.github.io/openid-federation-entity-collection/main.html).

## Running the Service

## License

This project is licensed under the MIT License.

This project includes code from fedservice (https://github.com/SUNET/fedservice), licensed under the Apache License, Version 2.0.
Modifications were made to adapt it for this project.
