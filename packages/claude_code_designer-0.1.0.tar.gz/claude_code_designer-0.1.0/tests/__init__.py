"""Tests for Claude Code Designer."""
