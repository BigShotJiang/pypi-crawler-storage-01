"""Tests for the AI Tool Registry package."""
