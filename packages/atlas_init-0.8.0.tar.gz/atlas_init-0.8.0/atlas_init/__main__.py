from atlas_init.cli import typer_main

typer_main()
