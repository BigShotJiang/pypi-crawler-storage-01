DEFAULT_EXTERNAL_SUBSTRINGS = ["aws", "azure", "google", "gcp"]
DEFAULT_INTERNAL_SUBSTRINGS = ["atlas", "mongo", "aws_region", "gcp_region", "azure_region", "cidr"]
ATLAS_PROVIDER_NAME = "mongodbatlas"
