"""
Configuration for event sink clickhouse.
"""

WAFFLE_FLAG_NAMESPACE = "event_sink_clickhouse"
