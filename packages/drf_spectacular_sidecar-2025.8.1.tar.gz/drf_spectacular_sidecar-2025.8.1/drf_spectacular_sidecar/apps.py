from django.apps import AppConfig


class SpectacularSidecarConfig(AppConfig):
    name = 'drf_spectacular_sidecar'
    verbose_name = "drf-spectacular-sidecar"
