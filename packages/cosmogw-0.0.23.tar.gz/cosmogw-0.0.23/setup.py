from setuptools import setup, find_packages

setup(
    package_data={'cosmoGW' :['resources/*/*','resources/*/*/*','*']},
)
