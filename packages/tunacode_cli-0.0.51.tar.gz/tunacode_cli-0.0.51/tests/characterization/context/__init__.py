"""Characterization tests for context loading and injection."""
