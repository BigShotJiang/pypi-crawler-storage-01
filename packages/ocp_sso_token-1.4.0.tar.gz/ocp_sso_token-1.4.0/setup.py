#!/usr/bin/env python3
"""Setup package."""
from setuptools import setup

setup()
