from ratio1 import Logger

if __name__ == "__main__":
  log = Logger("TEST")
  log.P("This is a test message")