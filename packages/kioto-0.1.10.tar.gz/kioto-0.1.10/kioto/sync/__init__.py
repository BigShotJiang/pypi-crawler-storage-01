from kioto.sync.api import Mutex
