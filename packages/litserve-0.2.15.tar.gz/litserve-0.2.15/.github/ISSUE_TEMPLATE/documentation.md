---
name: Typos and doc fixes
about: Typos and doc fixes
title: ''
labels: documentation
assignees: ''
---

## 📚 Documentation

For typos and doc fixes, please go ahead and:

- For a simple typo or fix, please send directly a PR (no need to create an issue)
- If you are not sure about the proper solution, please describe here your finding...

Thanks!
