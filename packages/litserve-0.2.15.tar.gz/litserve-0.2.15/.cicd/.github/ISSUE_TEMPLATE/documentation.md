---
name: Typos and doc fixes
about: Typos and doc fixes
title: ''
labels: documentation
assignees: ''
---

## 📚 Documentation

For typos or docs fixes, please go ahead and submit a PR (no need to open an issue).
If you are not sure about the proper solution, please describe the issue here...

Thanks!
