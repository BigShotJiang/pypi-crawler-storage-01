make clean
make html --debug --jobs $(nproc)
