.. LightningAI-DevToolbox documentation master file, created by
   sphinx-quickstart on Wed Mar 25 21:34:07 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Lightning-DevToolbox documentation
==================================

.. figure:: https://pl-public-data.s3.amazonaws.com/assets_lightning/Lightning.gif
    :alt: What is Lightning gif.
    :width: 80 %

.. toctree::
   :maxdepth: 1
   :name: content
   :caption: Overview

   Utilities readme <readme>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
