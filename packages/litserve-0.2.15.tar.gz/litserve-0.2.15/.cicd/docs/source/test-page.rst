:orphan:

Testing page
============

This is some page serving exclusively for testing purposes.

Link to scikit-learn stable documentation: https://scikit-learn.org/stable/index.html
