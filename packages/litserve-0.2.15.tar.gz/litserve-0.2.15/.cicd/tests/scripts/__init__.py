import os

_PATH_HERE = os.path.dirname(__file__)
_PATH_ROOT = os.path.dirname(os.path.dirname(_PATH_HERE))
_PATH_SCRIPTS = os.path.join(_PATH_ROOT, "scripts")
