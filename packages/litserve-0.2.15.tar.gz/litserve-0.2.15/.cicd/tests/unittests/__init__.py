import os

_PATH_UNITTESTS = os.path.dirname(__file__)
_PATH_ROOT = os.path.dirname(os.path.dirname(_PATH_UNITTESTS))
