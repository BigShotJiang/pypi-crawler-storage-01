## Installation

```
pip install synmax-agent
```

## Usage

```
from synmax_agent.hyperion import ChatClient

client = ChatClient()

client.chat("show me a map of all haynesville DUCs")

```
