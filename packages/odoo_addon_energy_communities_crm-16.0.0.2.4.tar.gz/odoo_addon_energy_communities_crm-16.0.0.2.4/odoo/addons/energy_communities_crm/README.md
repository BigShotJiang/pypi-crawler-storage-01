# Energy Communities CRM

<add description>

## Changelog

### 2025-05-21

- Added Readme
