from pytessng.Tessng import MyPlugin as TessngObject
print("\033[94m欢迎使用 TessNG 路网编辑工具 (pytessng)！通过 “from pytessng import TessngObject” 和 “TessngObject()” 进行使用.\033[0m\n")
