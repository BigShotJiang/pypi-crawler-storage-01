from genie_flow.genie import GenieModel

ModelKeyRegistryType = dict[str, type[GenieModel]]
