# poetic_ontology_builder/__init__.py
from .builder import PoeticBuilder
