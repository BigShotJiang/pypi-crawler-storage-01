Technical addon to support multiproperty in property management system
(PMS).
