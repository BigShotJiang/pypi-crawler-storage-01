- Use the standard multicompany guidelines applied to pms.property:

  `_check_pms_properties_auto like model attribute to autocheck  on create/write`
  `check_pms_properties like field attribute to check relational record properties consistence`
  `This module not implement propety dependent fields`
