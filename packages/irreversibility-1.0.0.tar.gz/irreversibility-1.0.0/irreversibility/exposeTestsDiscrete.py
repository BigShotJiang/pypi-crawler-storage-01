

from irreversibility.DiscreteMetrics.Gaspard import GetPValue as GaspardTest


allTests = [
    [ 'Gaspard', GaspardTest ],
]
