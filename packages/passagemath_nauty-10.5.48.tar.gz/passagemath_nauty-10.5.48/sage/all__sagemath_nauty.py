# sage_setup: distribution = sagemath-nauty

from sage.all__sagemath_graphs import *
