from django.apps import AppConfig


class MultiTenancyConfig(AppConfig):
    name = 'app_kit.multi_tenancy'
