from django.apps import AppConfig


class MapsConfig(AppConfig):
    name = 'app_kit.features.maps'
