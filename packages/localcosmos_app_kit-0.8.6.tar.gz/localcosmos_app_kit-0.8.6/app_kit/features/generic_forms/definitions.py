TEXT_LENGTH_RESTRICTIONS = {
    'GenericField' : {
        'label' : 150,
        'help_text' : 255,
    },
    'GenericValues' : {
        'choice' : 100
    } 
}
