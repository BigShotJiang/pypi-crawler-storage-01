default_app_config = 'app_kit.app_kit_api.apps.AppKitApiConfig'
