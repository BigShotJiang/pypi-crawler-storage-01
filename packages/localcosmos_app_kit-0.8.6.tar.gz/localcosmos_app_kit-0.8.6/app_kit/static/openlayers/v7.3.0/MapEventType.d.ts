declare namespace _default {
    const POSTRENDER: string;
    const MOVESTART: string;
    const MOVEEND: string;
    const LOADSTART: string;
    const LOADEND: string;
}
export default _default;
/**
 * *
 */
export type Types = 'postrender' | 'movestart' | 'moveend' | 'loadstart' | 'loadend';
//# sourceMappingURL=MapEventType.d.ts.map