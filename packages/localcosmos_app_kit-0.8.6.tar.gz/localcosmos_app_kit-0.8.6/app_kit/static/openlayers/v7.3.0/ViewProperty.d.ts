declare namespace _default {
    const CENTER: string;
    const RESOLUTION: string;
    const ROTATION: string;
}
export default _default;
//# sourceMappingURL=ViewProperty.d.ts.map