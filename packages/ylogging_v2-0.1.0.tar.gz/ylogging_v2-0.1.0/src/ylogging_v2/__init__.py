"""ylogging-v2: A Python logging package."""

__version__ = "0.1.0"
__author__ = "Yacine Touati"
__email__ = "yactouat@yactouat.com"

from .lib import *