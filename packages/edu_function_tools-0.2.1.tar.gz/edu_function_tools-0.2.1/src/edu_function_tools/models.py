from function_tools.models import (
    Entity as EduEntity,
    EntityType as EduEntityType,
)
