from function_tools.storages import (
    EntityStorage as EduEntityStorage,
)
