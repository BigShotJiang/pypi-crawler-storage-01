def main():
    import main
    main.run()

