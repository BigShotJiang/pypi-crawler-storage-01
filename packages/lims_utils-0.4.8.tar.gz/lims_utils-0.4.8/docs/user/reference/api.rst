API
===

.. automodule:: lims_utils

    ``lims_utils``
    -----------------------------------

This is the internal API reference for lims-utils

.. data:: lims_utils.__version__
    :type: str

    Version number as calculated by https://github.com/pypa/setuptools_scm
