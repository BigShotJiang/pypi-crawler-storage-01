## How To generate python code   
https://github.com/antlr/antlr4/blob/master/doc/python-target.md
