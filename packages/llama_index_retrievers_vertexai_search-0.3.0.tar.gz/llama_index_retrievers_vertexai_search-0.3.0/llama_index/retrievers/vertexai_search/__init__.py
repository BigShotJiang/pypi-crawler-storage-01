from llama_index.retrievers.vertexai_search.base import VertexAISearchRetriever

__all__ = ["VertexAISearchRetriever"]
