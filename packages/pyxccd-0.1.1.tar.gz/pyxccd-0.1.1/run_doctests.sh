#!/usr/bin/env bash
xdoctest src/python/pyxccd --style=google all "$@"