def test_import():
    import pyxccd