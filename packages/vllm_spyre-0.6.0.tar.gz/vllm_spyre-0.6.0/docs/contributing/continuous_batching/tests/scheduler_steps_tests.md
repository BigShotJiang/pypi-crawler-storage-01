# Scheduler Steps Tests

!!! note
    Unless otherwise specified, all the continuous batching tests are running with `max_model_len=256`

!!! warning
    End output correctness is not verified in those tests (TODO should we? maybe for some of them?)

::: tests.e2e.test_spyre_cb_scheduler_steps
