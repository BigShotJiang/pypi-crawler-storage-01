#!/bin/bash

pymarkdownlnt scan docs -r
pymarkdownlnt fix docs -r
