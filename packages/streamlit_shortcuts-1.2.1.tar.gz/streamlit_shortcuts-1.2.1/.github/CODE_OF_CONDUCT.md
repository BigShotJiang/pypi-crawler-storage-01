# Code of Conduct

Just don't be a jerk. All constructive input is welcome.

(This file exists to make GitHub happy ¯\_(ツ)_/¯)