---
name: Bug report
about: Something broken
---

**What happened?**

**Code to reproduce:**
```python
import streamlit as st
from streamlit_shortcuts import shortcut_button, add_shortcuts

# Your code here
```