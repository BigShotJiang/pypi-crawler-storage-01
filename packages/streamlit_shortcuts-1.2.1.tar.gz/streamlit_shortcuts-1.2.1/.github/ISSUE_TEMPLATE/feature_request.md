---
name: Feature request
about: Want something new
---

**What do you want?**

**Why?**