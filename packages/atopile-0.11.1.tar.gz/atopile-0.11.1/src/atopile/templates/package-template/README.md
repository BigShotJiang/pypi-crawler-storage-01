# atopile package template

Run `ato create package` to instantiate a package using this template.
