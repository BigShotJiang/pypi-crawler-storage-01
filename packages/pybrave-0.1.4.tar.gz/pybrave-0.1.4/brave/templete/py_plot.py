import sys
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
common_dir = os.path.abspath(os.path.join(script_dir, "../../script/common"))
sys.path.insert(0, common_dir)

