export default {
  networkError: "CORE_101",
  networkErrorQuery: "CORE_102",
  networkErrorMutation: "CORE_103",
  graphQlErrorMutation: "CORE_201",
  graphQlErrorMutationValidation: "CORE_202",
  graphQlErrorQuery: "CORE_203",
  actionSelectIncompatibleSelection: "CORE_301",
};
