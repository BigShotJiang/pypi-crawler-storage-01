import * as Sentry from "@sentry/vue";
import { BrowserTracing } from "@sentry/tracing";

export default { Sentry, BrowserTracing };
