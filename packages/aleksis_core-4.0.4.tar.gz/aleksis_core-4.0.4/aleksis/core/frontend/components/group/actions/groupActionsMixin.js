export default {
  props: {
    group: {
      type: Object,
      required: true,
    },
  },
};
