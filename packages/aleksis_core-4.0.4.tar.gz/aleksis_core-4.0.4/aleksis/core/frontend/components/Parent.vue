<!-- Parent template for Vue router views -->

<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: "Parent",
};
</script>
