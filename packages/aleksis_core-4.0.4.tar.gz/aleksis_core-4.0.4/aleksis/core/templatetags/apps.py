from django.apps import AppConfig


class TemplatetagsConfig(AppConfig):
    name = "templatetags"
