# this makes "linter" a package so "linter.user" is a valid module for importlib.import_module() to load
