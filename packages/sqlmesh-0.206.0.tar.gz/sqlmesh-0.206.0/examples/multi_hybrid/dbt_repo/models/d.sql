SELECT
  rounded_col_a
FROM {{ ref("c") }}
