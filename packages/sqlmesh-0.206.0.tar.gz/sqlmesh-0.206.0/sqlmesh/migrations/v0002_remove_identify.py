"""Remove identify=True kwarg for rendering sql"""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
