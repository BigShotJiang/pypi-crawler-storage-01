from pathlib import Path

DEFAULT_ROOT = Path(__file__).resolve().parent
