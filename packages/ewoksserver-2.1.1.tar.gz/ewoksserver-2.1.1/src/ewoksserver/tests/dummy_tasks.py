from ewokscore import Task


class MyTask1(Task):
    pass


class MyTask2(Task):
    pass


def my_task3():
    pass
