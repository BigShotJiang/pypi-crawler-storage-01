"""
DaedalusPy - Data Engineering Library Code Generator
"""

__version__ = "1.0.0"
__author__ = "Golden Valley Consulting"
