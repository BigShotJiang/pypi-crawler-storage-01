from mpqp.local_storage.delete import *
from mpqp.local_storage.load import *
from mpqp.local_storage.queries import *
from mpqp.local_storage.save import *
from mpqp.local_storage.setup import *
