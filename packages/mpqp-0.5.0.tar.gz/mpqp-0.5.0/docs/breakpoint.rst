Breakpoint
==========

.. code-block:: python
    :class: import

    from mpqp import Breakpoint

.. automodule:: mpqp.core.instruction.breakpoint