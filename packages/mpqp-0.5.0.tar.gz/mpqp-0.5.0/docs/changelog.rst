Changelog
=========

.. changelog::
    :github: https://github.com/ColibrITD-SAS/mpqp/releases
    :pypi: https://pypi.org/project/mpqp