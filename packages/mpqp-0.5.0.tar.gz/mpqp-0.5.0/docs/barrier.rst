Barriers
========

.. code-block:: python
    :class: import

    from mpqp import Barrier

.. automodule:: mpqp.core.instruction.barrier