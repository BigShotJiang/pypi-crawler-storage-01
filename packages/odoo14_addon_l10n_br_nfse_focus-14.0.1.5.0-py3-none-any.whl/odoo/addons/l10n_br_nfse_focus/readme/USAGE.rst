Para usar este módulo:

#. Crie uma fatura com o tipo de documento fiscal 'SE'.
#. Preencha os detalhes necessários, como o código tributário da cidade, impostos e informações correlatas.
#. Valide o documento.
#. Envie o Documento Fiscal.
#. Acompanhe o status de processamento do documento.
