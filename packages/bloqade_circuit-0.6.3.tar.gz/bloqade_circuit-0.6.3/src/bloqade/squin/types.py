from kirin import types


class MeasurementResult:
    pass


MeasurementResultType = types.PyClass(MeasurementResult)
