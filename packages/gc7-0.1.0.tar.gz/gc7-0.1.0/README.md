# Tools

```bash
mon_module/
├── mon_module/
│   └── __init__.py
├── setup.py
├── README.md
├── LICENSE
├── pyproject.toml
└── .github/
    └── workflows/
        └── publish.yml   ← le workflow GitHub Actions
```
