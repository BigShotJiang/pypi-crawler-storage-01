# LlamaIndex Docstore Integration: Gel
