KungFuApi Web Framework
====================

`KungFuApi` 是一个自动化生成接口的Web框架。