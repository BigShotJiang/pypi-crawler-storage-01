MIB_SOURCE_URL = 'https://raw.githubusercontent.com:443/DataDog/mibs.snmplabs.com/master/asn1/@mib@'

MIB_COMPILED_URL = "https://raw.githubusercontent.com/DataDog/mibs.snmplabs.com/master/json/@mib@"

CLEAR_LINE_ESCAPE_CODE = '\33[2K\r'
