{license_header}
__version__ = '{starting_version}'
