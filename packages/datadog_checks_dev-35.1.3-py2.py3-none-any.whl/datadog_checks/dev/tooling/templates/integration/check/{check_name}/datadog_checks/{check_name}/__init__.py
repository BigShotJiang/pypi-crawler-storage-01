{license_header}
from .__about__ import __version__
from .check import {check_class}

__all__ = ['__version__', '{check_class}']
