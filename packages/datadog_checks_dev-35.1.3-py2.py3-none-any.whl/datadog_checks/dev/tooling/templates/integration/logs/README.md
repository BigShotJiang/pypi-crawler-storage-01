# Logs-only Integration

Choose this type of integration if you only need some pipelines and a configuration for collecting and processing logs through the Agent.

To help you get started with your config, this integration is turned into a Python package that can be installed in the Agent.
These integrations are released just like Agent Checks, and the changelog is managed with towncrier in integrations-core.
