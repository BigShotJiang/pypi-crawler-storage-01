# sage_setup: distribution = sagemath-planarity

from sage.all__sagemath_graphs import *
