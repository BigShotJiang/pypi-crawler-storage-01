## 0.2.4 (2025-06-12)

### Fix

- **tests/misc-functions**: add function walk_object and change build framework to use uv

## 0.2.3 (2025-05-06)

### Fix

- removed print

## 0.2.2 (2025-05-02)

### Fix

- add retry functions and typex module

## 0.2.1 (2025-04-12)

## 0.2.0 (2025-04-12)

### Feat

- added jsonx and config

### Fix

- update cz config
- added tests for autodiscovery
- added support for autodiscovery
- removed gyver, env-star and lazyfields references
- added support for context-handler
