# sage_setup: distribution = sagemath-gfan

from sage.all__sagemath_polyhedra import *
