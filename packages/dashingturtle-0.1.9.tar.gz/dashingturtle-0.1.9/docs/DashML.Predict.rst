DashML.Predict package
======================

.. automodule:: DashML.Predict
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

DashML.Predict.Gmm\_Analysis module
-----------------------------------

.. automodule:: DashML.Predict.Gmm_Analysis
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Gmm\_Analysis2 module
------------------------------------

.. automodule:: DashML.Predict.Gmm_Analysis2
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Load module
--------------------------

.. automodule:: DashML.Predict.Load
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Lof module
-------------------------

.. automodule:: DashML.Predict.Lof
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Metric\_Average module
-------------------------------------

.. automodule:: DashML.Predict.Metric_Average
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Metric\_Reads module
-----------------------------------

.. automodule:: DashML.Predict.Metric_Reads
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Peak\_Analysis module
------------------------------------

.. automodule:: DashML.Predict.Peak_Analysis
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Peak\_Analysis\_BC module
----------------------------------------

.. automodule:: DashML.Predict.Peak_Analysis_BC
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Predict\_BPP module
----------------------------------

.. automodule:: DashML.Predict.Predict_BPP
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Predict\_Fold module
-----------------------------------

.. automodule:: DashML.Predict.Predict_Fold
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.Predicts module
------------------------------

.. automodule:: DashML.Predict.Predicts
   :members:
   :undoc-members:
   :show-inheritance:

DashML.Predict.run\_predict module
----------------------------------

.. automodule:: DashML.Predict.run_predict
   :members:
   :undoc-members:
   :show-inheritance:
