"""Device management for ASCOM MCP server."""
