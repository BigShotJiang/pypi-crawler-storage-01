from pysqa.queueadapter import QueueAdapter

from . import _version

__all__ = ["QueueAdapter"]
__version__ = _version.__version__
