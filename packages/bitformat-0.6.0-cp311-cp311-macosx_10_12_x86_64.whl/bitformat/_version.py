# This should be the one source of truth for the version number.
VERSION = "0.6.0"