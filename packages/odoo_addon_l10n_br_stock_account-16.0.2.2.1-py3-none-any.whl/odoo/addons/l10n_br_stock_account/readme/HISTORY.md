## 14.0.3.2.1 (2023-09-07)

**Bugfixes**

> - Fixes picking creation with kits products.

## 13.0.1.0.0 (2022-01-19)

- Module migration.
