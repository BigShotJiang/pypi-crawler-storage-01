#include "test_framework.hpp"

// Global test framework instance
TestFramework g_test_framework;