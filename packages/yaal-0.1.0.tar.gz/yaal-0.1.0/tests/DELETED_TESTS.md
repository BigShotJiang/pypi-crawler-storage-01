
 delete mode 100644 tests/COMPREHENSIVE_TESTS_SUMMARY.md
 delete mode 100644 tests/python/PYTHON_TESTS_STATUS.md
 delete mode 100644 tests/python/main.py
 delete mode 100644 tests/python/pyproject.toml
 delete mode 100755 tests/python/run_tests.py
 delete mode 100644 tests/python/src/yaal_parser/__init__.py
 delete mode 100644 tests/python/src/yaal_parser/grammar.lark
 delete mode 100644 tests/python/src/yaal_parser/parser.py
 delete mode 100644 tests/python/tests/__init__.py
 delete mode 100644 tests/python/tests/test_ast_extraction.py
 delete mode 100644 tests/python/tests/test_edge_cases.py
 delete mode 100644 tests/python/tests/test_integration.py
 delete mode 100644 tests/python/tests/test_parser_advanced.py
 delete mode 100644 tests/python/tests/test_parser_basic.py
