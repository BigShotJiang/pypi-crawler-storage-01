
# Usage
- 

# frinZ version history in PyPI  
- https://pypi.org/project/frinZ/0.1/
- https://pypi.org/project/frinZ/1.0/
- https://pypi.org/project/frinZ/1.1/

