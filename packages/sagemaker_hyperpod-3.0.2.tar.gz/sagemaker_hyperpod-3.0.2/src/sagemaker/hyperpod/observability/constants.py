AMAZON_HYPERPOD_OBSERVABILITY = "amazon-sagemaker-hyperpod-observability"
GRAFANA_DASHBOARD_UID = "aws-sm-hp-observability-cluster-v1_0"