from flask import Blueprint

web_bp = Blueprint('web', __name__)
