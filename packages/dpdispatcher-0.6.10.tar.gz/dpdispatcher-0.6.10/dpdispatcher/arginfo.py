from dpdispatcher.machine import Machine
from dpdispatcher.submission import Resources, Task

resources_dargs = Resources.arginfo
machine_dargs = Machine.arginfo
task_dargs = Task.arginfo
