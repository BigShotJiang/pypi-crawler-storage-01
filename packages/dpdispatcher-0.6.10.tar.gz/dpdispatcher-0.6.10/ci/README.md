## Notes

Files about `slurm` and `pbs` in this directory is originally taken from [dask/dask-jobqueue](https://github.com/dask/dask-jobqueue) under [BSD 3-Clause "New" or "Revised" License](LICENSE).
They have been relicensed under [LPGL 3.0](../LICENSE) as [they are compatible](https://www.gnu.org/licenses/license-list.html#ModifiedBSD).
