# Changelog

## [0.3.0] - 2025-08-02

Improve type hints for the following functions:

- `matplotlib.pyplot.close()`
- `matplotlib.pyplot.figure()`
- `matplotlib.pyplot.legend()`
- `matplotlib.pyplot.plot()`
- `matplotlib.pyplot.savefig()`
- `matplotlib.pyplot.scatter()`
- `matplotlib.pyplot.title()`
- `matplotlib.pyplot.xlabel()`
- `matplotlib.pyplot.ylabel()`
