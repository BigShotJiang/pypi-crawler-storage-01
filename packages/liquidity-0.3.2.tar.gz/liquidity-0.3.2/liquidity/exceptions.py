class DataNotAvailable(Exception):
    pass
