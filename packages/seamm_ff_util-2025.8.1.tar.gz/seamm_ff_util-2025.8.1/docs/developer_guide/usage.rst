=====
Usage
=====

To use the SEAMM forcefield utilities in a project::

    import seamm_ff_util
