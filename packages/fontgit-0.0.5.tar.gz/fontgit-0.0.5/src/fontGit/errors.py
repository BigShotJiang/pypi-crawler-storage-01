
class Error(Exception):
    pass