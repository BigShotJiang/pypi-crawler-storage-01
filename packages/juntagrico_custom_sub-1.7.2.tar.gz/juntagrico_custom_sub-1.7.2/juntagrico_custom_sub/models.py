from juntagrico_custom_sub.entity.cs_depot import CsDepot  # noqa: F401 avoid makemigration to delete CsDepot TODO?
