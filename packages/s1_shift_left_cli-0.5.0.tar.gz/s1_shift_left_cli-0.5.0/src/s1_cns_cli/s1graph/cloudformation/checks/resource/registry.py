from s1_cns_cli.s1graph.cloudformation.checks.resource.base_registry import Registry

cfn_registry = Registry()
