# CloudFormation does not currently support.
#
# September 2021
#
#
# https://github.com/aws-cloudformation/cloudformation-coverage-roadmap/issues/158
#
# check_id: CKV_AWS_106
