#!/usr/bin/env python
# -*- coding: utf-8 -*-
# (c) Copyright IBM Corp. 2023. All Rights Reserved.

""" setup.py for resilient-app-config-plugins Python package """

from setuptools import setup

setup()
