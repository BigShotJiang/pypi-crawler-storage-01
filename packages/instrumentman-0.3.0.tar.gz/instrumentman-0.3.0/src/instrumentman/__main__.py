from . import cli

cli()
