:icon: material/angle-acute

Sets
====

The set measurement commands provide a simple way to conduct automated polar
measurements to predefined target points.

.. toctree::
    :maxdepth: 1

    measure
    validate
    merge
    calc
