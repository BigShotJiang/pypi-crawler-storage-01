:icon: material/cog

Settings
========

For different measurements, different instrument settings might be required.
The settings commands can be used to save the settings to the config file,
and later load them back as necessary.

.. toctree::
    :maxdepth: 1

    download
    validate
    upload
