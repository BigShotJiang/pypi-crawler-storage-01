:icon: material/swap-horizontal

Inclination
===========

The inclination measurement commands provid tools to determine the inclination
of an instrument from measurements in multiple horizontal positions.

.. toctree::
    :maxdepth: 1

    measure
    merge
    calc
