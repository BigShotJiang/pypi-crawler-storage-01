:icon: material/protocol

Protocol Test
=============

Just by looking at the instrument, or even checking its documentation, it
might not be obvious what command protocols it supports (or if it even
supports any). The protocol testing commands offer a simple way to test
which parts of which protocols the instrument responds to.

.. toctree::
    :maxdepth: 1

    geocom
    gsidna
