:icon: material/console

Interactive Terminal
====================

The interactive terminal is a TUI application for testing and experimentation
purposes. It allows to connect to an instrument, and issue any of the available
commands. The responses are displayed in a log format.

.. only:: html

    .. image:: terminal_screenshot.svg

Usage
-----

.. click:: instrumentman.terminal:cli
    :prog: iman terminal
