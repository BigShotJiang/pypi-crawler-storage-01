Creates a 3D Vector from the given magnitudes
* "x" - The magnitude in the X direction
* "y" - The magnitude in the Y direction
* "z" - The magnitude in the Z direction