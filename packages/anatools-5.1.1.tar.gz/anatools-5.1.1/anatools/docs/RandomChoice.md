Selects the specified number of choices from a list
* "List_of_Choices" - The list of choices to choose from
* "Number_of_Choices" - The number of choices make
* "Unique_Choices" - Determines if every choice needs to be unique