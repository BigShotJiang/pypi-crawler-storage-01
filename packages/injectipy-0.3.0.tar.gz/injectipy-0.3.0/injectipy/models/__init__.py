from .inject import Inject

__all__ = ["Inject"]
