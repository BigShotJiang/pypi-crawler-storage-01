"""Unit test package for dj_notify."""
