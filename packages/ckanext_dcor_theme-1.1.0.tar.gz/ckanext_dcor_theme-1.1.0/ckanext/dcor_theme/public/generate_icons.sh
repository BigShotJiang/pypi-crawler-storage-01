inkscape favicon.svg -e favicon.png -w 32
icotool -c -o favicon.ico favicon.png
mkdir -p images
inkscape favicon.svg -e images/dcor-076.png -w 76
inkscape favicon.svg -e images/dcor-096.png -w 96
inkscape favicon.svg -e images/dcor-152.png -w 152
inkscape favicon.svg -e images/dcor-180.png -w 152

