# AlertBound


## Enum

* `UPPER_BOUND` (value: `'upper_bound'`)

* `LOWER_BOUND` (value: `'lower_bound'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


