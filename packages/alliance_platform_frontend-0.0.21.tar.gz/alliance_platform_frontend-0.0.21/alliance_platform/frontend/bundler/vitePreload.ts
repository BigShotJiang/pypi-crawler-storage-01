// This file should be included on every page, and is the entry point for the frontend.
// eslint-disable-next-line import/no-unresolved
import "vite/modulepreload-polyfill";
