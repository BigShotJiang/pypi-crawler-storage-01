"""
threadman: A simple thread manager for Python
"""

from .main import ThreadManager

__all__ = ["ThreadManager"]
