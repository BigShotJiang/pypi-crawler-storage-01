source ${VENV_PATH}/bin/activate && uv pip install -e ".[dev]"
