from llama_index.extractors.relik.base import RelikPathExtractor

__all__ = ["RelikPathExtractor"]
