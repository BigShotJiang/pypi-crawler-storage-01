# coding=utf-8

class EndpointResolver(object):
    def resolve(self, request):
        """
        Endpoint resolver interface
        """
        pass
