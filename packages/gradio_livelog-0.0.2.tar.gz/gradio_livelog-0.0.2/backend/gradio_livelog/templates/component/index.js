var rr = Object.defineProperty;
var Ao = (o) => {
  throw TypeError(o);
};
var sr = (o, e, t) => e in o ? rr(o, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : o[e] = t;
var V = (o, e, t) => sr(o, typeof e != "symbol" ? e + "" : e, t), ur = (o, e, t) => e.has(o) || Ao("Cannot " + t);
var Co = (o, e, t) => e.has(o) ? Ao("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(o) : e.set(o, t);
var hn = (o, e, t) => (ur(o, e, "access private method"), t);
const {
  SvelteComponent: cr,
  append_hydration: Ni,
  assign: _r,
  attr: _e,
  binding_callbacks: dr,
  children: en,
  claim_element: na,
  claim_space: ia,
  claim_svg_element: ri,
  create_slot: fr,
  detach: We,
  element: oa,
  empty: So,
  get_all_dirty_from_scope: hr,
  get_slot_changes: pr,
  get_spread_update: mr,
  init: gr,
  insert_hydration: ln,
  listen: vr,
  noop: br,
  safe_not_equal: Dr,
  set_dynamic_element_data: To,
  set_style: z,
  space: la,
  svg_element: si,
  toggle_class: ae,
  transition_in: aa,
  transition_out: ra,
  update_slot_base: wr
} = window.__gradio__svelte__internal;
function xo(o) {
  let e, t, n, i, a;
  return {
    c() {
      e = si("svg"), t = si("line"), n = si("line"), this.h();
    },
    l(l) {
      e = ri(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = en(e);
      t = ri(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), en(t).forEach(We), n = ri(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), en(n).forEach(We), r.forEach(We), this.h();
    },
    h() {
      _e(t, "x1", "1"), _e(t, "y1", "9"), _e(t, "x2", "9"), _e(t, "y2", "1"), _e(t, "stroke", "gray"), _e(t, "stroke-width", "0.5"), _e(n, "x1", "5"), _e(n, "y1", "9"), _e(n, "x2", "9"), _e(n, "y2", "5"), _e(n, "stroke", "gray"), _e(n, "stroke-width", "0.5"), _e(e, "class", "resize-handle svelte-239wnu"), _e(e, "xmlns", "http://www.w3.org/2000/svg"), _e(e, "viewBox", "0 0 10 10");
    },
    m(l, r) {
      ln(l, e, r), Ni(e, t), Ni(e, n), i || (a = vr(
        e,
        "mousedown",
        /*resize*/
        o[27]
      ), i = !0);
    },
    p: br,
    d(l) {
      l && We(e), i = !1, a();
    }
  };
}
function yr(o) {
  var m;
  let e, t, n, i, a;
  const l = (
    /*#slots*/
    o[31].default
  ), r = fr(
    l,
    o,
    /*$$scope*/
    o[30],
    null
  );
  let s = (
    /*resizable*/
    o[19] && xo(o)
  ), u = [
    { "data-testid": (
      /*test_id*/
      o[11]
    ) },
    { id: (
      /*elem_id*/
      o[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((m = o[7]) == null ? void 0 : m.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      o[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = _r(c, u[d]);
  return {
    c() {
      e = oa(
        /*tag*/
        o[25]
      ), r && r.c(), t = la(), s && s.c(), this.h();
    },
    l(d) {
      e = na(
        d,
        /*tag*/
        (o[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var g = en(e);
      r && r.l(g), t = ia(g), s && s.l(g), g.forEach(We), this.h();
    },
    h() {
      To(
        /*tag*/
        o[25]
      )(e, c), ae(
        e,
        "hidden",
        /*visible*/
        o[14] === !1
      ), ae(
        e,
        "padded",
        /*padding*/
        o[10]
      ), ae(
        e,
        "flex",
        /*flex*/
        o[1]
      ), ae(
        e,
        "border_focus",
        /*border_mode*/
        o[9] === "focus"
      ), ae(
        e,
        "border_contrast",
        /*border_mode*/
        o[9] === "contrast"
      ), ae(e, "hide-container", !/*explicit_call*/
      o[12] && !/*container*/
      o[13]), ae(
        e,
        "fullscreen",
        /*fullscreen*/
        o[0]
      ), ae(
        e,
        "animating",
        /*fullscreen*/
        o[0] && /*preexpansionBoundingRect*/
        o[24] !== null
      ), ae(
        e,
        "auto-margin",
        /*scale*/
        o[17] === null
      ), z(
        e,
        "height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*height*/
            o[2]
          )
        )
      ), z(
        e,
        "min-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*min_height*/
            o[3]
          )
        )
      ), z(
        e,
        "max-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*max_height*/
            o[4]
          )
        )
      ), z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].top}px` : "0px"
      ), z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].left}px` : "0px"
      ), z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].width}px` : "0px"
      ), z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].height}px` : "0px"
      ), z(
        e,
        "width",
        /*fullscreen*/
        o[0] ? void 0 : typeof /*width*/
        o[5] == "number" ? `calc(min(${/*width*/
        o[5]}px, 100%))` : (
          /*get_dimension*/
          o[26](
            /*width*/
            o[5]
          )
        )
      ), z(
        e,
        "border-style",
        /*variant*/
        o[8]
      ), z(
        e,
        "overflow",
        /*allow_overflow*/
        o[15] ? (
          /*overflow_behavior*/
          o[16]
        ) : "hidden"
      ), z(
        e,
        "flex-grow",
        /*scale*/
        o[17]
      ), z(e, "min-width", `calc(min(${/*min_width*/
      o[18]}px, 100%))`), z(e, "border-width", "var(--block-border-width)");
    },
    m(d, g) {
      ln(d, e, g), r && r.m(e, null), Ni(e, t), s && s.m(e, null), o[32](e), a = !0;
    },
    p(d, g) {
      var b;
      r && r.p && (!a || g[0] & /*$$scope*/
      1073741824) && wr(
        r,
        l,
        d,
        /*$$scope*/
        d[30],
        a ? pr(
          l,
          /*$$scope*/
          d[30],
          g,
          null
        ) : hr(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, g) : (s = xo(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), To(
        /*tag*/
        d[25]
      )(e, c = mr(u, [
        (!a || g[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!a || g[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!a || g[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((b = d[7]) == null ? void 0 : b.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!a || g[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: i }
      ])), ae(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), ae(
        e,
        "padded",
        /*padding*/
        d[10]
      ), ae(
        e,
        "flex",
        /*flex*/
        d[1]
      ), ae(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), ae(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), ae(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), ae(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), ae(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), ae(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), g[0] & /*fullscreen, height*/
      5 && z(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), g[0] & /*fullscreen, min_height*/
      9 && z(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), g[0] & /*fullscreen, max_height*/
      17 && z(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), g[0] & /*fullscreen, width*/
      33 && z(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), g[0] & /*variant*/
      256 && z(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), g[0] & /*allow_overflow, overflow_behavior*/
      98304 && z(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), g[0] & /*scale*/
      131072 && z(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), g[0] & /*min_width*/
      262144 && z(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      a || (aa(r, d), a = !0);
    },
    o(d) {
      ra(r, d), a = !1;
    },
    d(d) {
      d && We(e), r && r.d(d), s && s.d(), o[32](null);
    }
  };
}
function Bo(o) {
  let e;
  return {
    c() {
      e = oa("div"), this.h();
    },
    l(t) {
      e = na(t, "DIV", { class: !0 }), en(e).forEach(We), this.h();
    },
    h() {
      _e(e, "class", "placeholder svelte-239wnu"), z(
        e,
        "height",
        /*placeholder_height*/
        o[22] + "px"
      ), z(
        e,
        "width",
        /*placeholder_width*/
        o[23] + "px"
      );
    },
    m(t, n) {
      ln(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && z(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && z(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && We(e);
    }
  };
}
function Fr(o) {
  let e, t, n, i = (
    /*tag*/
    o[25] && yr(o)
  ), a = (
    /*fullscreen*/
    o[0] && Bo(o)
  );
  return {
    c() {
      i && i.c(), e = la(), a && a.c(), t = So();
    },
    l(l) {
      i && i.l(l), e = ia(l), a && a.l(l), t = So();
    },
    m(l, r) {
      i && i.m(l, r), ln(l, e, r), a && a.m(l, r), ln(l, t, r), n = !0;
    },
    p(l, r) {
      /*tag*/
      l[25] && i.p(l, r), /*fullscreen*/
      l[0] ? a ? a.p(l, r) : (a = Bo(l), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(l) {
      n || (aa(i, l), n = !0);
    },
    o(l) {
      ra(i, l), n = !1;
    },
    d(l) {
      l && (We(e), We(t)), i && i.d(l), a && a.d(l);
    }
  };
}
function $r(o, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: a = void 0 } = e, { min_height: l = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: m = "solid" } = e, { border_mode: d = "base" } = e, { padding: g = !0 } = e, { type: b = "normal" } = e, { test_id: p = void 0 } = e, { explicit_call: D = !1 } = e, { container: $ = !0 } = e, { visible: h = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: v = "auto" } = e, { scale: y = null } = e, { min_width: w = 0 } = e, { flex: A = !1 } = e, { resizable: F = !1 } = e, { rtl: S = !1 } = e, { fullscreen: I = !1 } = e, T = I, L, Q = b === "fieldset" ? "fieldset" : "div", j = 0, oe = 0, J = null;
  function te(E) {
    I && E.key === "Escape" && t(0, I = !1);
  }
  const N = (E) => {
    if (E !== void 0) {
      if (typeof E == "number")
        return E + "px";
      if (typeof E == "string")
        return E;
    }
  }, G = (E) => {
    let ne = E.clientY;
    const W = (C) => {
      const ke = C.clientY - ne;
      ne = C.clientY, t(21, L.style.height = `${L.offsetHeight + ke}px`, L);
    }, re = () => {
      window.removeEventListener("mousemove", W), window.removeEventListener("mouseup", re);
    };
    window.addEventListener("mousemove", W), window.addEventListener("mouseup", re);
  };
  function ve(E) {
    dr[E ? "unshift" : "push"](() => {
      L = E, t(21, L);
    });
  }
  return o.$$set = (E) => {
    "height" in E && t(2, a = E.height), "min_height" in E && t(3, l = E.min_height), "max_height" in E && t(4, r = E.max_height), "width" in E && t(5, s = E.width), "elem_id" in E && t(6, u = E.elem_id), "elem_classes" in E && t(7, c = E.elem_classes), "variant" in E && t(8, m = E.variant), "border_mode" in E && t(9, d = E.border_mode), "padding" in E && t(10, g = E.padding), "type" in E && t(28, b = E.type), "test_id" in E && t(11, p = E.test_id), "explicit_call" in E && t(12, D = E.explicit_call), "container" in E && t(13, $ = E.container), "visible" in E && t(14, h = E.visible), "allow_overflow" in E && t(15, _ = E.allow_overflow), "overflow_behavior" in E && t(16, v = E.overflow_behavior), "scale" in E && t(17, y = E.scale), "min_width" in E && t(18, w = E.min_width), "flex" in E && t(1, A = E.flex), "resizable" in E && t(19, F = E.resizable), "rtl" in E && t(20, S = E.rtl), "fullscreen" in E && t(0, I = E.fullscreen), "$$scope" in E && t(30, i = E.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && I !== T && (t(29, T = I), I ? (t(24, J = L.getBoundingClientRect()), t(22, j = L.offsetHeight), t(23, oe = L.offsetWidth), window.addEventListener("keydown", te)) : (t(24, J = null), window.removeEventListener("keydown", te))), o.$$.dirty[0] & /*visible*/
    16384 && (h || t(1, A = !1));
  }, [
    I,
    A,
    a,
    l,
    r,
    s,
    u,
    c,
    m,
    d,
    g,
    p,
    D,
    $,
    h,
    _,
    v,
    y,
    w,
    F,
    S,
    L,
    j,
    oe,
    J,
    Q,
    N,
    G,
    b,
    T,
    i,
    n,
    ve
  ];
}
class kr extends cr {
  constructor(e) {
    super(), gr(
      this,
      e,
      $r,
      Fr,
      Dr,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Ki() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Et = Ki();
function sa(o) {
  Et = o;
}
const ua = /[&<>"']/, Er = new RegExp(ua.source, "g"), ca = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Ar = new RegExp(ca.source, "g"), Cr = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Ro = (o) => Cr[o];
function Fe(o, e) {
  if (e) {
    if (ua.test(o))
      return o.replace(Er, Ro);
  } else if (ca.test(o))
    return o.replace(Ar, Ro);
  return o;
}
const Sr = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Tr(o) {
  return o.replace(Sr, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const xr = /(^|[^\[])\^/g;
function H(o, e) {
  let t = typeof o == "string" ? o : o.source;
  e = e || "";
  const n = {
    replace: (i, a) => {
      let l = typeof a == "string" ? a : a.source;
      return l = l.replace(xr, "$1"), t = t.replace(i, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function Io(o) {
  try {
    o = encodeURI(o).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return o;
}
const tn = { exec: () => null };
function Lo(o, e) {
  const t = o.replace(/\|/g, (a, l, r) => {
    let s = !1, u = l;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function pn(o, e, t) {
  const n = o.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && o.charAt(n - i - 1) === e; )
    i++;
  return o.slice(0, n - i);
}
function Br(o, e) {
  if (o.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < o.length; n++)
    if (o[n] === "\\")
      n++;
    else if (o[n] === e[0])
      t++;
    else if (o[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function qo(o, e, t, n) {
  const i = e.href, a = e.title ? Fe(e.title) : null, l = o[1].replace(/\\([\[\]])/g, "$1");
  if (o[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: i,
      title: a,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: a,
    text: Fe(l)
  };
}
function Rr(o, e) {
  const t = o.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const a = i.match(/^\s+/);
    if (a === null)
      return i;
    const [l] = a;
    return l.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class xn {
  // set by the lexer
  constructor(e) {
    V(this, "options");
    V(this, "rules");
    // set by the lexer
    V(this, "lexer");
    this.options = e || Et;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : pn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = Rr(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = pn(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = pn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, a = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let m = t[2].split(`
`, 1)[0].replace(/^\t+/, ($) => " ".repeat(3 * $.length)), d = e.split(`
`, 1)[0], g = 0;
        this.options.pedantic ? (g = 2, s = m.trimStart()) : (g = t[2].search(/[^ ]/), g = g > 4 ? 1 : g, s = m.slice(g), g += t[1].length);
        let b = !1;
        if (!m && /^ *$/.test(d) && (r += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const $ = new RegExp(`^ {0,${Math.min(3, g - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), h = new RegExp(`^ {0,${Math.min(3, g - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, g - 1)}}(?:\`\`\`|~~~)`), v = new RegExp(`^ {0,${Math.min(3, g - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (d = y, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || v.test(d) || $.test(d) || h.test(e))
              break;
            if (d.search(/[^ ]/) >= g || !d.trim())
              s += `
` + d.slice(g);
            else {
              if (b || m.search(/[^ ]/) >= 4 || _.test(m) || v.test(m) || h.test(m))
                break;
              s += `
` + d;
            }
            !b && !d.trim() && (b = !0), r += y + `
`, e = e.substring(y.length + 1), m = d.slice(g);
          }
        }
        a.loose || (u ? a.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let p = null, D;
        this.options.gfm && (p = /^\[[ xX]\] /.exec(s), p && (D = p[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: r,
          task: !!p,
          checked: D,
          loose: !1,
          text: s,
          tokens: []
        }), a.raw += r;
      }
      a.items[a.items.length - 1].raw = r.trimEnd(), a.items[a.items.length - 1].text = s.trimEnd(), a.raw = a.raw.trimEnd();
      for (let c = 0; c < a.items.length; c++)
        if (this.lexer.state.top = !1, a.items[c].tokens = this.lexer.blockTokens(a.items[c].text, []), !a.loose) {
          const m = a.items[c].tokens.filter((g) => g.type === "space"), d = m.length > 0 && m.some((g) => /\n.*\n/.test(g.raw));
          a.loose = d;
        }
      if (a.loose)
        for (let c = 0; c < a.items.length; c++)
          a.items[c].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Lo(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const r of i)
        /^ *-+: *$/.test(r) ? l.align.push("right") : /^ *:-+: *$/.test(r) ? l.align.push("center") : /^ *:-+ *$/.test(r) ? l.align.push("left") : l.align.push(null);
      for (const r of n)
        l.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of a)
        l.rows.push(Lo(r, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Fe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = pn(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = Br(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], a = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        l && (i = l[1], a = l[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), qo(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), a = t[i.toLowerCase()];
      if (!a) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return qo(n, a, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...i[0]].length - 1;
      let r, s, u = l, c = 0;
      const m = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (m.lastIndex = 0, t = t.slice(-1 * e.length + l); (i = m.exec(t)) != null; ) {
        if (r = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !r)
          continue;
        if (s = [...r].length, i[3] || i[4]) {
          u += s;
          continue;
        } else if ((i[5] || i[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...i[0]][0].length, g = e.slice(0, l + i.index + d + s);
        if (Math.min(l, s) % 2) {
          const p = g.slice(1, -1);
          return {
            type: "em",
            raw: g,
            text: p,
            tokens: this.lexer.inlineTokens(p)
          };
        }
        const b = g.slice(2, -2);
        return {
          type: "strong",
          raw: g,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), a = /^ /.test(n) && / $/.test(n);
      return i && a && (n = n.substring(1, n.length - 1)), n = Fe(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = Fe(t[1]), i = "mailto:" + n) : (n = Fe(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, a;
      if (t[2] === "@")
        i = Fe(t[0]), a = "mailto:" + i;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        i = Fe(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: a,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Fe(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Ir = /^(?: *(?:\n|$))+/, Lr = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, qr = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, an = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Or = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, _a = /(?:[*+-]|\d{1,9}[.)])/, da = H(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, _a).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Qi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Nr = /^[^\n]+/, Ji = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Mr = H(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Ji).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Pr = H(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, _a).getRegex(), Gn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", eo = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, zr = H("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", eo).replace("tag", Gn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), fa = H(Qi).replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Gn).getRegex(), Ur = H(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", fa).getRegex(), to = {
  blockquote: Ur,
  code: Lr,
  def: Mr,
  fences: qr,
  heading: Or,
  hr: an,
  html: zr,
  lheading: da,
  list: Pr,
  newline: Ir,
  paragraph: fa,
  table: tn,
  text: Nr
}, Oo = H("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Gn).getRegex(), Hr = {
  ...to,
  table: Oo,
  paragraph: H(Qi).replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Oo).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Gn).getRegex()
}, Gr = {
  ...to,
  html: H(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", eo).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: tn,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: H(Qi).replace("hr", an).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", da).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, ha = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, jr = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, pa = /^( {2,}|\\)\n(?!\s*$)/, Vr = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, rn = "\\p{P}\\p{S}", Wr = H(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, rn).getRegex(), Zr = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Yr = H(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, rn).getRegex(), Xr = H("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, rn).getRegex(), Kr = H("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, rn).getRegex(), Qr = H(/\\([punct])/, "gu").replace(/punct/g, rn).getRegex(), Jr = H(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), es = H(eo).replace("(?:-->|$)", "-->").getRegex(), ts = H("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", es).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Bn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, ns = H(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Bn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ma = H(/^!?\[(label)\]\[(ref)\]/).replace("label", Bn).replace("ref", Ji).getRegex(), ga = H(/^!?\[(ref)\](?:\[\])?/).replace("ref", Ji).getRegex(), is = H("reflink|nolink(?!\\()", "g").replace("reflink", ma).replace("nolink", ga).getRegex(), no = {
  _backpedal: tn,
  // only used for GFM url
  anyPunctuation: Qr,
  autolink: Jr,
  blockSkip: Zr,
  br: pa,
  code: jr,
  del: tn,
  emStrongLDelim: Yr,
  emStrongRDelimAst: Xr,
  emStrongRDelimUnd: Kr,
  escape: ha,
  link: ns,
  nolink: ga,
  punctuation: Wr,
  reflink: ma,
  reflinkSearch: is,
  tag: ts,
  text: Vr,
  url: tn
}, os = {
  ...no,
  link: H(/^!?\[(label)\]\((.*?)\)/).replace("label", Bn).getRegex(),
  reflink: H(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Bn).getRegex()
}, Mi = {
  ...no,
  escape: H(ha).replace("])", "~|])").getRegex(),
  url: H(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, ls = {
  ...Mi,
  br: H(pa).replace("{2,}", "*").getRegex(),
  text: H(Mi.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, mn = {
  normal: to,
  gfm: Hr,
  pedantic: Gr
}, Wt = {
  normal: no,
  gfm: Mi,
  breaks: ls,
  pedantic: os
};
class Ze {
  constructor(e) {
    V(this, "tokens");
    V(this, "options");
    V(this, "state");
    V(this, "tokenizer");
    V(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Et, this.options.tokenizer = this.options.tokenizer || new xn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: mn.normal,
      inline: Wt.normal
    };
    this.options.pedantic ? (t.block = mn.pedantic, t.inline = Wt.pedantic) : this.options.gfm && (t.block = mn.gfm, this.options.breaks ? t.inline = Wt.breaks : t.inline = Wt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: mn,
      inline: Wt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Ze(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Ze(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, i, a, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (a = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(a))) {
          i = t[t.length - 1], l && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), l = a.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, a, l = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, r.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const m = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((g) => {
            d = g.call({ lexer: this }, m), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (a = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(a)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Rn {
  constructor(e) {
    V(this, "options");
    this.options = e || Et;
  }
  code(e, t, n) {
    var a;
    const i = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + Fe(i) + '">' + (n ? e : Fe(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Fe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", a = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + a + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = Io(e);
    if (i === null)
      return n;
    e = i;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + n + "</a>", a;
  }
  image(e, t, n) {
    const i = Io(e);
    if (i === null)
      return n;
    e = i;
    let a = `<img src="${e}" alt="${n}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class io {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Ye {
  constructor(e) {
    V(this, "options");
    V(this, "renderer");
    V(this, "textRenderer");
    this.options = e || Et, this.options.renderer = this.options.renderer || new Rn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new io();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Ye(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Ye(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const l = a, r = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += r || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = a;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, Tr(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = a;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = a;
          let r = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const m = l.rows[c];
            s = "";
            for (let d = 0; d < m.length; d++)
              s += this.renderer.tablecell(this.parseInline(m[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const l = a, r = this.parse(l.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const l = a, r = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let m = 0; m < l.items.length; m++) {
            const d = l.items[m], g = d.checked, b = d.task;
            let p = "";
            if (d.task) {
              const D = this.renderer.checkbox(!!g);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = D + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = D + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: D + " "
              }) : p += D + " ";
            }
            p += this.parse(d.tokens, u), c += this.renderer.listitem(p, b, !!g);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const l = a;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = a;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = a, r = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            l = e[++i], r += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const l = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const l = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          n += l || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const l = a;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = a;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = a;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = a;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = a;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = a;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = a;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = a;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = a;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class nn {
  constructor(e) {
    V(this, "options");
    this.options = e || Et;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
V(nn, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var kt, Pi, va;
class as {
  constructor(...e) {
    Co(this, kt);
    V(this, "defaults", Ki());
    V(this, "options", this.setOptions);
    V(this, "parse", hn(this, kt, Pi).call(this, Ze.lex, Ye.parse));
    V(this, "parseInline", hn(this, kt, Pi).call(this, Ze.lexInline, Ye.parseInline));
    V(this, "Parser", Ye);
    V(this, "Renderer", Rn);
    V(this, "TextRenderer", io);
    V(this, "Lexer", Ze);
    V(this, "Tokenizer", xn);
    V(this, "Hooks", nn);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, a;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const r = l;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = l;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = l;
          (a = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && a[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const l = t.renderers[a.name];
          l ? t.renderers[a.name] = function(...r) {
            let s = a.renderer.apply(this, r);
            return s === !1 && (s = l.apply(this, r)), s;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[a.level];
          l ? l.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), i.extensions = t), n.renderer) {
        const a = this.defaults.renderer || new Rn(this.defaults);
        for (const l in n.renderer) {
          if (!(l in a))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.renderer[r], u = a[r];
          a[r] = (...c) => {
            let m = s.apply(a, c);
            return m === !1 && (m = u.apply(a, c)), m || "";
          };
        }
        i.renderer = a;
      }
      if (n.tokenizer) {
        const a = this.defaults.tokenizer || new xn(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in a))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const r = l, s = n.tokenizer[r], u = a[r];
          a[r] = (...c) => {
            let m = s.apply(a, c);
            return m === !1 && (m = u.apply(a, c)), m;
          };
        }
        i.tokenizer = a;
      }
      if (n.hooks) {
        const a = this.defaults.hooks || new nn();
        for (const l in n.hooks) {
          if (!(l in a))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.hooks[r], u = a[r];
          nn.passThroughHooks.has(l) ? a[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(a, c)).then((d) => u.call(a, d));
            const m = s.call(a, c);
            return u.call(a, m);
          } : a[r] = (...c) => {
            let m = s.apply(a, c);
            return m === !1 && (m = u.apply(a, c)), m;
          };
        }
        i.hooks = a;
      }
      if (n.walkTokens) {
        const a = this.defaults.walkTokens, l = n.walkTokens;
        i.walkTokens = function(r) {
          let s = [];
          return s.push(l.call(this, r)), a && (s = s.concat(a.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Ze.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Ye.parse(e, t ?? this.defaults);
  }
}
kt = new WeakSet(), Pi = function(e, t) {
  return (n, i) => {
    const a = { ...i }, l = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const r = hn(this, kt, va).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(r);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, va = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + Fe(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const yt = new as();
function U(o, e) {
  return yt.parse(o, e);
}
U.options = U.setOptions = function(o) {
  return yt.setOptions(o), U.defaults = yt.defaults, sa(U.defaults), U;
};
U.getDefaults = Ki;
U.defaults = Et;
U.use = function(...o) {
  return yt.use(...o), U.defaults = yt.defaults, sa(U.defaults), U;
};
U.walkTokens = function(o, e) {
  return yt.walkTokens(o, e);
};
U.parseInline = yt.parseInline;
U.Parser = Ye;
U.parser = Ye.parse;
U.Renderer = Rn;
U.TextRenderer = io;
U.Lexer = Ze;
U.lexer = Ze.lex;
U.Tokenizer = xn;
U.Hooks = nn;
U.parse = U;
U.options;
U.setOptions;
U.use;
U.walkTokens;
U.parseInline;
Ye.parse;
Ze.lex;
const rs = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, ss = Object.hasOwnProperty;
class ba {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = us(e, t === !0);
    const a = i;
    for (; ss.call(n.occurrences, i); )
      n.occurrences[a]++, i = a + "-" + n.occurrences[a];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function us(o, e) {
  return typeof o != "string" ? "" : (e || (o = o.toLowerCase()), o.replace(rs, "").replace(/ /g, "-"));
}
new ba();
var No = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, cs = { exports: {} };
(function(o) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, l = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function h(_) {
          return _ instanceof s ? new s(_.type, h(_.content), _.alias) : Array.isArray(_) ? _.map(h) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(h) {
          return Object.prototype.toString.call(h).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(h) {
          return h.__id || Object.defineProperty(h, "__id", { value: ++a }), h.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function h(_, v) {
          v = v || {};
          var y, w;
          switch (r.util.type(_)) {
            case "Object":
              if (w = r.util.objId(_), v[w])
                return v[w];
              y = /** @type {Record<string, any>} */
              {}, v[w] = y;
              for (var A in _)
                _.hasOwnProperty(A) && (y[A] = h(_[A], v));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return w = r.util.objId(_), v[w] ? v[w] : (y = [], v[w] = y, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(F, S) {
                y[S] = h(F, v);
              }), /** @type {any} */
              y);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(h) {
          for (; h; ) {
            var _ = i.exec(h.className);
            if (_)
              return _[1].toLowerCase();
            h = h.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(h, _) {
          h.className = h.className.replace(RegExp(i, "gi"), ""), h.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var h = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (h) {
              var _ = document.getElementsByTagName("script");
              for (var v in _)
                if (_[v].src == h)
                  return _[v];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(h, _, v) {
          for (var y = "no-" + _; h; ) {
            var w = h.classList;
            if (w.contains(_))
              return !0;
            if (w.contains(y))
              return !1;
            h = h.parentElement;
          }
          return !!v;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(h, _) {
          var v = r.util.clone(r.languages[h]);
          for (var y in _)
            v[y] = _[y];
          return v;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(h, _, v, y) {
          y = y || /** @type {any} */
          r.languages;
          var w = y[h], A = {};
          for (var F in w)
            if (w.hasOwnProperty(F)) {
              if (F == _)
                for (var S in v)
                  v.hasOwnProperty(S) && (A[S] = v[S]);
              v.hasOwnProperty(F) || (A[F] = w[F]);
            }
          var I = y[h];
          return y[h] = A, r.languages.DFS(r.languages, function(T, L) {
            L === I && T != h && (this[T] = A);
          }), A;
        },
        // Traverse a language definition with Depth First Search
        DFS: function h(_, v, y, w) {
          w = w || {};
          var A = r.util.objId;
          for (var F in _)
            if (_.hasOwnProperty(F)) {
              v.call(_, F, _[F], y || F);
              var S = _[F], I = r.util.type(S);
              I === "Object" && !w[A(S)] ? (w[A(S)] = !0, h(S, v, null, w)) : I === "Array" && !w[A(S)] && (w[A(S)] = !0, h(S, v, F, w));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(h, _) {
        r.highlightAllUnder(document, h, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(h, _, v) {
        var y = {
          callback: v,
          container: h,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), r.hooks.run("before-all-elements-highlight", y);
        for (var w = 0, A; A = y.elements[w++]; )
          r.highlightElement(A, _ === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(h, _, v) {
        var y = r.util.getLanguage(h), w = r.languages[y];
        r.util.setLanguage(h, y);
        var A = h.parentElement;
        A && A.nodeName.toLowerCase() === "pre" && r.util.setLanguage(A, y);
        var F = h.textContent, S = {
          element: h,
          language: y,
          grammar: w,
          code: F
        };
        function I(L) {
          S.highlightedCode = L, r.hooks.run("before-insert", S), S.element.innerHTML = S.highlightedCode, r.hooks.run("after-highlight", S), r.hooks.run("complete", S), v && v.call(S.element);
        }
        if (r.hooks.run("before-sanity-check", S), A = S.element.parentElement, A && A.nodeName.toLowerCase() === "pre" && !A.hasAttribute("tabindex") && A.setAttribute("tabindex", "0"), !S.code) {
          r.hooks.run("complete", S), v && v.call(S.element);
          return;
        }
        if (r.hooks.run("before-highlight", S), !S.grammar) {
          I(r.util.encode(S.code));
          return;
        }
        if (_ && n.Worker) {
          var T = new Worker(r.filename);
          T.onmessage = function(L) {
            I(L.data);
          }, T.postMessage(JSON.stringify({
            language: S.language,
            code: S.code,
            immediateClose: !0
          }));
        } else
          I(r.highlight(S.code, S.grammar, S.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(h, _, v) {
        var y = {
          code: h,
          grammar: _,
          language: v
        };
        if (r.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = r.tokenize(y.code, y.grammar), r.hooks.run("after-tokenize", y), s.stringify(r.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(h, _) {
        var v = _.rest;
        if (v) {
          for (var y in v)
            _[y] = v[y];
          delete _.rest;
        }
        var w = new m();
        return d(w, w.head, h), c(h, w, _, w.head, 0), b(w);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(h, _) {
          var v = r.hooks.all;
          v[h] = v[h] || [], v[h].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(h, _) {
          var v = r.hooks.all[h];
          if (!(!v || !v.length))
            for (var y = 0, w; w = v[y++]; )
              w(_);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(h, _, v, y) {
      this.type = h, this.content = _, this.alias = v, this.length = (y || "").length | 0;
    }
    s.stringify = function h(_, v) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var y = "";
        return _.forEach(function(I) {
          y += h(I, v);
        }), y;
      }
      var w = {
        type: _.type,
        content: h(_.content, v),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: v
      }, A = _.alias;
      A && (Array.isArray(A) ? Array.prototype.push.apply(w.classes, A) : w.classes.push(A)), r.hooks.run("wrap", w);
      var F = "";
      for (var S in w.attributes)
        F += " " + S + '="' + (w.attributes[S] || "").replace(/"/g, "&quot;") + '"';
      return "<" + w.tag + ' class="' + w.classes.join(" ") + '"' + F + ">" + w.content + "</" + w.tag + ">";
    };
    function u(h, _, v, y) {
      h.lastIndex = _;
      var w = h.exec(v);
      if (w && y && w[1]) {
        var A = w[1].length;
        w.index += A, w[0] = w[0].slice(A);
      }
      return w;
    }
    function c(h, _, v, y, w, A) {
      for (var F in v)
        if (!(!v.hasOwnProperty(F) || !v[F])) {
          var S = v[F];
          S = Array.isArray(S) ? S : [S];
          for (var I = 0; I < S.length; ++I) {
            if (A && A.cause == F + "," + I)
              return;
            var T = S[I], L = T.inside, Q = !!T.lookbehind, j = !!T.greedy, oe = T.alias;
            if (j && !T.pattern.global) {
              var J = T.pattern.toString().match(/[imsuy]*$/)[0];
              T.pattern = RegExp(T.pattern.source, J + "g");
            }
            for (var te = T.pattern || T, N = y.next, G = w; N !== _.tail && !(A && G >= A.reach); G += N.value.length, N = N.next) {
              var ve = N.value;
              if (_.length > h.length)
                return;
              if (!(ve instanceof s)) {
                var E = 1, ne;
                if (j) {
                  if (ne = u(te, G, h, Q), !ne || ne.index >= h.length)
                    break;
                  var ke = ne.index, W = ne.index + ne[0].length, re = G;
                  for (re += N.value.length; ke >= re; )
                    N = N.next, re += N.value.length;
                  if (re -= N.value.length, G = re, N.value instanceof s)
                    continue;
                  for (var C = N; C !== _.tail && (re < W || typeof C.value == "string"); C = C.next)
                    E++, re += C.value.length;
                  E--, ve = h.slice(G, re), ne.index -= G;
                } else if (ne = u(te, 0, ve, Q), !ne)
                  continue;
                var ke = ne.index, at = ne[0], At = ve.slice(0, ke), Ct = ve.slice(ke + at.length), St = G + ve.length;
                A && St > A.reach && (A.reach = St);
                var vt = N.prev;
                At && (vt = d(_, vt, At), G += At.length), g(_, vt, E);
                var rt = new s(F, L ? r.tokenize(at, L) : at, oe, at);
                if (N = d(_, vt, rt), Ct && d(_, N, Ct), E > 1) {
                  var st = {
                    cause: F + "," + I,
                    reach: St
                  };
                  c(h, _, v, N.prev, G, st), A && st.reach > A.reach && (A.reach = st.reach);
                }
              }
            }
          }
        }
    }
    function m() {
      var h = { value: null, prev: null, next: null }, _ = { value: null, prev: h, next: null };
      h.next = _, this.head = h, this.tail = _, this.length = 0;
    }
    function d(h, _, v) {
      var y = _.next, w = { value: v, prev: _, next: y };
      return _.next = w, y.prev = w, h.length++, w;
    }
    function g(h, _, v) {
      for (var y = _.next, w = 0; w < v && y !== h.tail; w++)
        y = y.next;
      _.next = y, y.prev = _, h.length -= w;
    }
    function b(h) {
      for (var _ = [], v = h.head.next; v !== h.tail; )
        _.push(v.value), v = v.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(h) {
        var _ = JSON.parse(h.data), v = _.language, y = _.code, w = _.immediateClose;
        n.postMessage(r.highlight(y, r.languages[v], v)), w && n.close();
      }, !1)), r;
    var p = r.util.currentScript();
    p && (r.filename = p.src, p.hasAttribute("data-manual") && (r.manual = !0));
    function D() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var $ = document.readyState;
      $ === "loading" || $ === "interactive" && p && p.defer ? document.addEventListener("DOMContentLoaded", D) : window.requestAnimationFrame ? window.requestAnimationFrame(D) : window.setTimeout(D, 16);
    }
    return r;
  }(e);
  o.exports && (o.exports = t), typeof No < "u" && (No.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, a) {
      var l = {};
      l["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      r["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var a = n.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(p, D) {
      return "✖ Error " + p + " while fetching file: " + D;
    }, a = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", m = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function d(p, D, $) {
      var h = new XMLHttpRequest();
      h.open("GET", p, !0), h.onreadystatechange = function() {
        h.readyState == 4 && (h.status < 400 && h.responseText ? D(h.responseText) : h.status >= 400 ? $(i(h.status, h.statusText)) : $(a));
      }, h.send(null);
    }
    function g(p) {
      var D = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(p || "");
      if (D) {
        var $ = Number(D[1]), h = D[2], _ = D[3];
        return h ? _ ? [$, Number(_)] : [$, void 0] : [$, $];
      }
    }
    t.hooks.add("before-highlightall", function(p) {
      p.selector += ", " + m;
    }), t.hooks.add("before-sanity-check", function(p) {
      var D = (
        /** @type {HTMLPreElement} */
        p.element
      );
      if (D.matches(m)) {
        p.code = "", D.setAttribute(r, s);
        var $ = D.appendChild(document.createElement("CODE"));
        $.textContent = n;
        var h = D.getAttribute("data-src"), _ = p.language;
        if (_ === "none") {
          var v = (/\.(\w+)$/.exec(h) || [, "none"])[1];
          _ = l[v] || v;
        }
        t.util.setLanguage($, _), t.util.setLanguage(D, _);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(_), d(
          h,
          function(w) {
            D.setAttribute(r, u);
            var A = g(D.getAttribute("data-range"));
            if (A) {
              var F = w.split(/\r\n?|\n/g), S = A[0], I = A[1] == null ? F.length : A[1];
              S < 0 && (S += F.length), S = Math.max(0, Math.min(S - 1, F.length)), I < 0 && (I += F.length), I = Math.max(0, Math.min(I, F.length)), w = F.slice(S, I).join(`
`), D.hasAttribute("data-start") || D.setAttribute("data-start", String(S + 1));
            }
            $.textContent = w, t.highlightElement($);
          },
          function(w) {
            D.setAttribute(r, c), $.textContent = w;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(D) {
        for (var $ = (D || document).querySelectorAll(m), h = 0, _; _ = $[h++]; )
          t.highlightElement(_);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(cs);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(o) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  o.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, o.languages.tex = o.languages.latex, o.languages.context = o.languages.latex;
})(Prism);
(function(o) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  o.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = o.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = n.variable[1].inside, l = 0; l < i.length; l++)
    a[i[l]] = o.languages.bash[i[l]];
  o.languages.sh = o.languages.bash, o.languages.shell = o.languages.bash;
})(Prism);
new ba();
const _s = (o) => {
  const e = {};
  for (let t = 0, n = o.length; t < n; t++) {
    const i = o[t];
    for (const a in i)
      e[a] ? e[a] = e[a].concat(i[a]) : e[a] = i[a];
  }
  return e;
}, ds = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], fs = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], hs = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
_s([
  Object.fromEntries(ds.map((o) => [o, ["*"]])),
  Object.fromEntries(fs.map((o) => [o, ["svg:*"]])),
  Object.fromEntries(hs.map((o) => [o, ["math:*"]]))
]);
const {
  HtmlTagHydration: zd,
  SvelteComponent: Ud,
  attr: Hd,
  binding_callbacks: Gd,
  children: jd,
  claim_element: Vd,
  claim_html_tag: Wd,
  detach: Zd,
  element: Yd,
  init: Xd,
  insert_hydration: Kd,
  noop: Qd,
  safe_not_equal: Jd,
  toggle_class: ef
} = window.__gradio__svelte__internal, { afterUpdate: tf, tick: nf, onMount: of } = window.__gradio__svelte__internal, {
  SvelteComponent: lf,
  attr: af,
  children: rf,
  claim_component: sf,
  claim_element: uf,
  create_component: cf,
  destroy_component: _f,
  detach: df,
  element: ff,
  init: hf,
  insert_hydration: pf,
  mount_component: mf,
  safe_not_equal: gf,
  transition_in: vf,
  transition_out: bf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Df,
  attr: wf,
  check_outros: yf,
  children: Ff,
  claim_component: $f,
  claim_element: kf,
  claim_space: Ef,
  create_component: Af,
  create_slot: Cf,
  destroy_component: Sf,
  detach: Tf,
  element: xf,
  empty: Bf,
  get_all_dirty_from_scope: Rf,
  get_slot_changes: If,
  group_outros: Lf,
  init: qf,
  insert_hydration: Of,
  mount_component: Nf,
  safe_not_equal: Mf,
  space: Pf,
  toggle_class: zf,
  transition_in: Uf,
  transition_out: Hf,
  update_slot_base: Gf
} = window.__gradio__svelte__internal, {
  SvelteComponent: ps,
  append_hydration: ui,
  attr: qt,
  children: Mo,
  claim_component: ms,
  claim_element: Po,
  claim_space: gs,
  claim_text: vs,
  create_component: bs,
  destroy_component: Ds,
  detach: ci,
  element: zo,
  init: ws,
  insert_hydration: ys,
  mount_component: Fs,
  safe_not_equal: $s,
  set_data: ks,
  space: Es,
  text: As,
  toggle_class: ut,
  transition_in: Cs,
  transition_out: Ss
} = window.__gradio__svelte__internal;
function Ts(o) {
  let e, t, n, i, a, l, r;
  return n = new /*Icon*/
  o[1]({}), {
    c() {
      e = zo("label"), t = zo("span"), bs(n.$$.fragment), i = Es(), a = As(
        /*label*/
        o[0]
      ), this.h();
    },
    l(s) {
      e = Po(s, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var u = Mo(e);
      t = Po(u, "SPAN", { class: !0 });
      var c = Mo(t);
      ms(n.$$.fragment, c), c.forEach(ci), i = gs(u), a = vs(
        u,
        /*label*/
        o[0]
      ), u.forEach(ci), this.h();
    },
    h() {
      qt(t, "class", "svelte-13ao5pu"), qt(e, "for", ""), qt(e, "data-testid", "block-label"), qt(e, "dir", l = /*rtl*/
      o[5] ? "rtl" : "ltr"), qt(e, "class", "svelte-13ao5pu"), ut(e, "hide", !/*show_label*/
      o[2]), ut(e, "sr-only", !/*show_label*/
      o[2]), ut(
        e,
        "float",
        /*float*/
        o[4]
      ), ut(
        e,
        "hide-label",
        /*disable*/
        o[3]
      );
    },
    m(s, u) {
      ys(s, e, u), ui(e, t), Fs(n, t, null), ui(e, i), ui(e, a), r = !0;
    },
    p(s, [u]) {
      (!r || u & /*label*/
      1) && ks(
        a,
        /*label*/
        s[0]
      ), (!r || u & /*rtl*/
      32 && l !== (l = /*rtl*/
      s[5] ? "rtl" : "ltr")) && qt(e, "dir", l), (!r || u & /*show_label*/
      4) && ut(e, "hide", !/*show_label*/
      s[2]), (!r || u & /*show_label*/
      4) && ut(e, "sr-only", !/*show_label*/
      s[2]), (!r || u & /*float*/
      16) && ut(
        e,
        "float",
        /*float*/
        s[4]
      ), (!r || u & /*disable*/
      8) && ut(
        e,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      r || (Cs(n.$$.fragment, s), r = !0);
    },
    o(s) {
      Ss(n.$$.fragment, s), r = !1;
    },
    d(s) {
      s && ci(e), Ds(n);
    }
  };
}
function xs(o, e, t) {
  let { label: n = null } = e, { Icon: i } = e, { show_label: a = !0 } = e, { disable: l = !1 } = e, { float: r = !0 } = e, { rtl: s = !1 } = e;
  return o.$$set = (u) => {
    "label" in u && t(0, n = u.label), "Icon" in u && t(1, i = u.Icon), "show_label" in u && t(2, a = u.show_label), "disable" in u && t(3, l = u.disable), "float" in u && t(4, r = u.float), "rtl" in u && t(5, s = u.rtl);
  }, [n, i, a, l, r, s];
}
class Bs extends ps {
  constructor(e) {
    super(), ws(this, e, xs, Ts, $s, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: Rs,
  append_hydration: Cn,
  attr: ot,
  bubble: Is,
  check_outros: Ls,
  children: zi,
  claim_component: qs,
  claim_element: Ui,
  claim_space: Uo,
  claim_text: Os,
  construct_svelte_component: Ho,
  create_component: Go,
  create_slot: Ns,
  destroy_component: jo,
  detach: on,
  element: Hi,
  get_all_dirty_from_scope: Ms,
  get_slot_changes: Ps,
  group_outros: zs,
  init: Us,
  insert_hydration: Da,
  listen: Hs,
  mount_component: Vo,
  safe_not_equal: Gs,
  set_data: js,
  set_style: gn,
  space: Wo,
  text: Vs,
  toggle_class: ce,
  transition_in: _i,
  transition_out: di,
  update_slot_base: Ws
} = window.__gradio__svelte__internal;
function Zo(o) {
  let e, t;
  return {
    c() {
      e = Hi("span"), t = Vs(
        /*label*/
        o[1]
      ), this.h();
    },
    l(n) {
      e = Ui(n, "SPAN", { class: !0 });
      var i = zi(e);
      t = Os(
        i,
        /*label*/
        o[1]
      ), i.forEach(on), this.h();
    },
    h() {
      ot(e, "class", "svelte-qgco6m");
    },
    m(n, i) {
      Da(n, e, i), Cn(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && js(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && on(e);
    }
  };
}
function Zs(o) {
  let e, t, n, i, a, l, r, s, u = (
    /*show_label*/
    o[2] && Zo(o)
  );
  var c = (
    /*Icon*/
    o[0]
  );
  function m(b, p) {
    return {};
  }
  c && (i = Ho(c, m()));
  const d = (
    /*#slots*/
    o[14].default
  ), g = Ns(
    d,
    o,
    /*$$scope*/
    o[13],
    null
  );
  return {
    c() {
      e = Hi("button"), u && u.c(), t = Wo(), n = Hi("div"), i && Go(i.$$.fragment), a = Wo(), g && g.c(), this.h();
    },
    l(b) {
      e = Ui(b, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var p = zi(e);
      u && u.l(p), t = Uo(p), n = Ui(p, "DIV", { class: !0 });
      var D = zi(n);
      i && qs(i.$$.fragment, D), a = Uo(D), g && g.l(D), D.forEach(on), p.forEach(on), this.h();
    },
    h() {
      ot(n, "class", "svelte-qgco6m"), ce(
        n,
        "x-small",
        /*size*/
        o[4] === "x-small"
      ), ce(
        n,
        "small",
        /*size*/
        o[4] === "small"
      ), ce(
        n,
        "large",
        /*size*/
        o[4] === "large"
      ), ce(
        n,
        "medium",
        /*size*/
        o[4] === "medium"
      ), e.disabled = /*disabled*/
      o[7], ot(
        e,
        "aria-label",
        /*label*/
        o[1]
      ), ot(
        e,
        "aria-haspopup",
        /*hasPopup*/
        o[8]
      ), ot(
        e,
        "title",
        /*label*/
        o[1]
      ), ot(e, "class", "svelte-qgco6m"), ce(
        e,
        "pending",
        /*pending*/
        o[3]
      ), ce(
        e,
        "padded",
        /*padded*/
        o[5]
      ), ce(
        e,
        "highlight",
        /*highlight*/
        o[6]
      ), ce(
        e,
        "transparent",
        /*transparent*/
        o[9]
      ), gn(e, "color", !/*disabled*/
      o[7] && /*_color*/
      o[11] ? (
        /*_color*/
        o[11]
      ) : "var(--block-label-text-color)"), gn(e, "--bg-color", /*disabled*/
      o[7] ? "auto" : (
        /*background*/
        o[10]
      ));
    },
    m(b, p) {
      Da(b, e, p), u && u.m(e, null), Cn(e, t), Cn(e, n), i && Vo(i, n, null), Cn(n, a), g && g.m(n, null), l = !0, r || (s = Hs(
        e,
        "click",
        /*click_handler*/
        o[15]
      ), r = !0);
    },
    p(b, [p]) {
      if (/*show_label*/
      b[2] ? u ? u.p(b, p) : (u = Zo(b), u.c(), u.m(e, t)) : u && (u.d(1), u = null), p & /*Icon*/
      1 && c !== (c = /*Icon*/
      b[0])) {
        if (i) {
          zs();
          const D = i;
          di(D.$$.fragment, 1, 0, () => {
            jo(D, 1);
          }), Ls();
        }
        c ? (i = Ho(c, m()), Go(i.$$.fragment), _i(i.$$.fragment, 1), Vo(i, n, a)) : i = null;
      }
      g && g.p && (!l || p & /*$$scope*/
      8192) && Ws(
        g,
        d,
        b,
        /*$$scope*/
        b[13],
        l ? Ps(
          d,
          /*$$scope*/
          b[13],
          p,
          null
        ) : Ms(
          /*$$scope*/
          b[13]
        ),
        null
      ), (!l || p & /*size*/
      16) && ce(
        n,
        "x-small",
        /*size*/
        b[4] === "x-small"
      ), (!l || p & /*size*/
      16) && ce(
        n,
        "small",
        /*size*/
        b[4] === "small"
      ), (!l || p & /*size*/
      16) && ce(
        n,
        "large",
        /*size*/
        b[4] === "large"
      ), (!l || p & /*size*/
      16) && ce(
        n,
        "medium",
        /*size*/
        b[4] === "medium"
      ), (!l || p & /*disabled*/
      128) && (e.disabled = /*disabled*/
      b[7]), (!l || p & /*label*/
      2) && ot(
        e,
        "aria-label",
        /*label*/
        b[1]
      ), (!l || p & /*hasPopup*/
      256) && ot(
        e,
        "aria-haspopup",
        /*hasPopup*/
        b[8]
      ), (!l || p & /*label*/
      2) && ot(
        e,
        "title",
        /*label*/
        b[1]
      ), (!l || p & /*pending*/
      8) && ce(
        e,
        "pending",
        /*pending*/
        b[3]
      ), (!l || p & /*padded*/
      32) && ce(
        e,
        "padded",
        /*padded*/
        b[5]
      ), (!l || p & /*highlight*/
      64) && ce(
        e,
        "highlight",
        /*highlight*/
        b[6]
      ), (!l || p & /*transparent*/
      512) && ce(
        e,
        "transparent",
        /*transparent*/
        b[9]
      ), p & /*disabled, _color*/
      2176 && gn(e, "color", !/*disabled*/
      b[7] && /*_color*/
      b[11] ? (
        /*_color*/
        b[11]
      ) : "var(--block-label-text-color)"), p & /*disabled, background*/
      1152 && gn(e, "--bg-color", /*disabled*/
      b[7] ? "auto" : (
        /*background*/
        b[10]
      ));
    },
    i(b) {
      l || (i && _i(i.$$.fragment, b), _i(g, b), l = !0);
    },
    o(b) {
      i && di(i.$$.fragment, b), di(g, b), l = !1;
    },
    d(b) {
      b && on(e), u && u.d(), i && jo(i), g && g.d(b), r = !1, s();
    }
  };
}
function Ys(o, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e, { Icon: l } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: m = !0 } = e, { highlight: d = !1 } = e, { disabled: g = !1 } = e, { hasPopup: b = !1 } = e, { color: p = "var(--block-label-text-color)" } = e, { transparent: D = !1 } = e, { background: $ = "var(--block-background-fill)" } = e;
  function h(_) {
    Is.call(this, o, _);
  }
  return o.$$set = (_) => {
    "Icon" in _ && t(0, l = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, m = _.padded), "highlight" in _ && t(6, d = _.highlight), "disabled" in _ && t(7, g = _.disabled), "hasPopup" in _ && t(8, b = _.hasPopup), "color" in _ && t(12, p = _.color), "transparent" in _ && t(9, D = _.transparent), "background" in _ && t(10, $ = _.background), "$$scope" in _ && t(13, a = _.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : p);
  }, [
    l,
    r,
    s,
    u,
    c,
    m,
    d,
    g,
    b,
    D,
    $,
    n,
    p,
    a,
    i,
    h
  ];
}
class jn extends Rs {
  constructor(e) {
    super(), Us(this, e, Ys, Zs, Gs, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: jf,
  append_hydration: Vf,
  attr: Wf,
  binding_callbacks: Zf,
  children: Yf,
  claim_element: Xf,
  create_slot: Kf,
  detach: Qf,
  element: Jf,
  get_all_dirty_from_scope: eh,
  get_slot_changes: th,
  init: nh,
  insert_hydration: ih,
  safe_not_equal: oh,
  toggle_class: lh,
  transition_in: ah,
  transition_out: rh,
  update_slot_base: sh
} = window.__gradio__svelte__internal, {
  SvelteComponent: uh,
  append_hydration: ch,
  attr: _h,
  children: dh,
  claim_svg_element: fh,
  detach: hh,
  init: ph,
  insert_hydration: mh,
  noop: gh,
  safe_not_equal: vh,
  svg_element: bh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dh,
  append_hydration: wh,
  attr: yh,
  children: Fh,
  claim_svg_element: $h,
  detach: kh,
  init: Eh,
  insert_hydration: Ah,
  noop: Ch,
  safe_not_equal: Sh,
  svg_element: Th
} = window.__gradio__svelte__internal, {
  SvelteComponent: xh,
  append_hydration: Bh,
  attr: Rh,
  children: Ih,
  claim_svg_element: Lh,
  detach: qh,
  init: Oh,
  insert_hydration: Nh,
  noop: Mh,
  safe_not_equal: Ph,
  svg_element: zh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uh,
  append_hydration: Hh,
  attr: Gh,
  children: jh,
  claim_svg_element: Vh,
  detach: Wh,
  init: Zh,
  insert_hydration: Yh,
  noop: Xh,
  safe_not_equal: Kh,
  svg_element: Qh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jh,
  append_hydration: ep,
  attr: tp,
  children: np,
  claim_svg_element: ip,
  detach: op,
  init: lp,
  insert_hydration: ap,
  noop: rp,
  safe_not_equal: sp,
  svg_element: up
} = window.__gradio__svelte__internal, {
  SvelteComponent: cp,
  append_hydration: _p,
  attr: dp,
  children: fp,
  claim_svg_element: hp,
  detach: pp,
  init: mp,
  insert_hydration: gp,
  noop: vp,
  safe_not_equal: bp,
  svg_element: Dp
} = window.__gradio__svelte__internal, {
  SvelteComponent: wp,
  append_hydration: yp,
  attr: Fp,
  children: $p,
  claim_svg_element: kp,
  detach: Ep,
  init: Ap,
  insert_hydration: Cp,
  noop: Sp,
  safe_not_equal: Tp,
  svg_element: xp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bp,
  append_hydration: Rp,
  attr: Ip,
  children: Lp,
  claim_svg_element: qp,
  detach: Op,
  init: Np,
  insert_hydration: Mp,
  noop: Pp,
  safe_not_equal: zp,
  svg_element: Up
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hp,
  append_hydration: Gp,
  attr: jp,
  children: Vp,
  claim_svg_element: Wp,
  detach: Zp,
  init: Yp,
  insert_hydration: Xp,
  noop: Kp,
  safe_not_equal: Qp,
  svg_element: Jp
} = window.__gradio__svelte__internal, {
  SvelteComponent: em,
  append_hydration: tm,
  attr: nm,
  children: im,
  claim_svg_element: om,
  detach: lm,
  init: am,
  insert_hydration: rm,
  noop: sm,
  safe_not_equal: um,
  svg_element: cm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xs,
  append_hydration: Ks,
  attr: Ee,
  children: Yo,
  claim_svg_element: Xo,
  detach: fi,
  init: Qs,
  insert_hydration: Js,
  noop: hi,
  safe_not_equal: eu,
  svg_element: Ko
} = window.__gradio__svelte__internal;
function tu(o) {
  let e, t;
  return {
    c() {
      e = Ko("svg"), t = Ko("path"), this.h();
    },
    l(n) {
      e = Xo(n, "svg", {
        width: !0,
        height: !0,
        "stroke-width": !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        color: !0
      });
      var i = Yo(e);
      t = Xo(i, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Yo(t).forEach(fi), i.forEach(fi), this.h();
    },
    h() {
      Ee(t, "d", "M5 13L9 17L19 7"), Ee(t, "stroke", "currentColor"), Ee(t, "stroke-width", "1.5"), Ee(t, "stroke-linecap", "round"), Ee(t, "stroke-linejoin", "round"), Ee(e, "width", "100%"), Ee(e, "height", "100%"), Ee(e, "stroke-width", "1.5"), Ee(e, "viewBox", "0 0 24 24"), Ee(e, "fill", "none"), Ee(e, "xmlns", "http://www.w3.org/2000/svg"), Ee(e, "color", "currentColor");
    },
    m(n, i) {
      Js(n, e, i), Ks(e, t);
    },
    p: hi,
    i: hi,
    o: hi,
    d(n) {
      n && fi(e);
    }
  };
}
class Qo extends Xs {
  constructor(e) {
    super(), Qs(this, e, null, tu, eu, {});
  }
}
const {
  SvelteComponent: _m,
  append_hydration: dm,
  attr: fm,
  children: hm,
  claim_svg_element: pm,
  detach: mm,
  init: gm,
  insert_hydration: vm,
  noop: bm,
  safe_not_equal: Dm,
  svg_element: wm
} = window.__gradio__svelte__internal, {
  SvelteComponent: nu,
  append_hydration: pi,
  attr: Ie,
  children: vn,
  claim_svg_element: bn,
  detach: Zt,
  init: iu,
  insert_hydration: ou,
  noop: mi,
  safe_not_equal: lu,
  set_style: Ue,
  svg_element: Dn
} = window.__gradio__svelte__internal;
function au(o) {
  let e, t, n, i;
  return {
    c() {
      e = Dn("svg"), t = Dn("g"), n = Dn("path"), i = Dn("path"), this.h();
    },
    l(a) {
      e = bn(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = vn(e);
      t = bn(l, "g", { transform: !0 });
      var r = vn(t);
      n = bn(r, "path", { d: !0, style: !0 }), vn(n).forEach(Zt), r.forEach(Zt), i = bn(l, "path", { d: !0, style: !0 }), vn(i).forEach(Zt), l.forEach(Zt), this.h();
    },
    h() {
      Ie(n, "d", "M18,6L6.087,17.913"), Ue(n, "fill", "none"), Ue(n, "fill-rule", "nonzero"), Ue(n, "stroke-width", "2px"), Ie(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Ie(i, "d", "M4.364,4.364L19.636,19.636"), Ue(i, "fill", "none"), Ue(i, "fill-rule", "nonzero"), Ue(i, "stroke-width", "2px"), Ie(e, "width", "100%"), Ie(e, "height", "100%"), Ie(e, "viewBox", "0 0 24 24"), Ie(e, "version", "1.1"), Ie(e, "xmlns", "http://www.w3.org/2000/svg"), Ie(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ie(e, "xml:space", "preserve"), Ie(e, "stroke", "currentColor"), Ue(e, "fill-rule", "evenodd"), Ue(e, "clip-rule", "evenodd"), Ue(e, "stroke-linecap", "round"), Ue(e, "stroke-linejoin", "round");
    },
    m(a, l) {
      ou(a, e, l), pi(e, t), pi(t, n), pi(e, i);
    },
    p: mi,
    i: mi,
    o: mi,
    d(a) {
      a && Zt(e);
    }
  };
}
let ru = class extends nu {
  constructor(e) {
    super(), iu(this, e, null, au, lu, {});
  }
};
const {
  SvelteComponent: Fm,
  append_hydration: $m,
  attr: km,
  children: Em,
  claim_svg_element: Am,
  detach: Cm,
  init: Sm,
  insert_hydration: Tm,
  noop: xm,
  safe_not_equal: Bm,
  svg_element: Rm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Im,
  append_hydration: Lm,
  attr: qm,
  children: Om,
  claim_svg_element: Nm,
  detach: Mm,
  init: Pm,
  insert_hydration: zm,
  noop: Um,
  safe_not_equal: Hm,
  svg_element: Gm
} = window.__gradio__svelte__internal, {
  SvelteComponent: jm,
  append_hydration: Vm,
  attr: Wm,
  children: Zm,
  claim_svg_element: Ym,
  detach: Xm,
  init: Km,
  insert_hydration: Qm,
  noop: Jm,
  safe_not_equal: eg,
  svg_element: tg
} = window.__gradio__svelte__internal, {
  SvelteComponent: ng,
  append_hydration: ig,
  attr: og,
  children: lg,
  claim_svg_element: ag,
  detach: rg,
  init: sg,
  insert_hydration: ug,
  noop: cg,
  safe_not_equal: _g,
  svg_element: dg
} = window.__gradio__svelte__internal, {
  SvelteComponent: su,
  append_hydration: Jo,
  attr: He,
  children: gi,
  claim_svg_element: vi,
  detach: wn,
  init: uu,
  insert_hydration: cu,
  noop: bi,
  safe_not_equal: _u,
  svg_element: Di
} = window.__gradio__svelte__internal;
function du(o) {
  let e, t, n;
  return {
    c() {
      e = Di("svg"), t = Di("path"), n = Di("path"), this.h();
    },
    l(i) {
      e = vi(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        color: !0,
        "aria-hidden": !0,
        width: !0,
        height: !0
      });
      var a = gi(e);
      t = vi(a, "path", { fill: !0, d: !0 }), gi(t).forEach(wn), n = vi(a, "path", { fill: !0, d: !0 }), gi(n).forEach(wn), a.forEach(wn), this.h();
    },
    h() {
      He(t, "fill", "currentColor"), He(t, "d", "M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"), He(n, "fill", "currentColor"), He(n, "d", "M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"), He(e, "xmlns", "http://www.w3.org/2000/svg"), He(e, "viewBox", "0 0 33 33"), He(e, "color", "currentColor"), He(e, "aria-hidden", "true"), He(e, "width", "100%"), He(e, "height", "100%");
    },
    m(i, a) {
      cu(i, e, a), Jo(e, t), Jo(e, n);
    },
    p: bi,
    i: bi,
    o: bi,
    d(i) {
      i && wn(e);
    }
  };
}
class el extends su {
  constructor(e) {
    super(), uu(this, e, null, du, _u, {});
  }
}
const {
  SvelteComponent: fg,
  append_hydration: hg,
  attr: pg,
  children: mg,
  claim_svg_element: gg,
  detach: vg,
  init: bg,
  insert_hydration: Dg,
  noop: wg,
  safe_not_equal: yg,
  svg_element: Fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: fu,
  append_hydration: hu,
  attr: Ot,
  children: tl,
  claim_svg_element: nl,
  detach: wi,
  init: pu,
  insert_hydration: mu,
  noop: yi,
  safe_not_equal: gu,
  svg_element: il
} = window.__gradio__svelte__internal;
function vu(o) {
  let e, t;
  return {
    c() {
      e = il("svg"), t = il("path"), this.h();
    },
    l(n) {
      e = nl(n, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var i = tl(e);
      t = nl(i, "path", { fill: !0, d: !0 }), tl(t).forEach(wi), i.forEach(wi), this.h();
    },
    h() {
      Ot(t, "fill", "currentColor"), Ot(t, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), Ot(e, "xmlns", "http://www.w3.org/2000/svg"), Ot(e, "width", "100%"), Ot(e, "height", "100%"), Ot(e, "viewBox", "0 0 32 32");
    },
    m(n, i) {
      mu(n, e, i), hu(e, t);
    },
    p: yi,
    i: yi,
    o: yi,
    d(n) {
      n && wi(e);
    }
  };
}
class bu extends fu {
  constructor(e) {
    super(), pu(this, e, null, vu, gu, {});
  }
}
const {
  SvelteComponent: $g,
  append_hydration: kg,
  attr: Eg,
  children: Ag,
  claim_svg_element: Cg,
  detach: Sg,
  init: Tg,
  insert_hydration: xg,
  noop: Bg,
  safe_not_equal: Rg,
  svg_element: Ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lg,
  append_hydration: qg,
  attr: Og,
  children: Ng,
  claim_svg_element: Mg,
  detach: Pg,
  init: zg,
  insert_hydration: Ug,
  noop: Hg,
  safe_not_equal: Gg,
  svg_element: jg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vg,
  append_hydration: Wg,
  attr: Zg,
  children: Yg,
  claim_svg_element: Xg,
  detach: Kg,
  init: Qg,
  insert_hydration: Jg,
  noop: e0,
  safe_not_equal: t0,
  svg_element: n0
} = window.__gradio__svelte__internal, {
  SvelteComponent: i0,
  append_hydration: o0,
  attr: l0,
  children: a0,
  claim_svg_element: r0,
  detach: s0,
  init: u0,
  insert_hydration: c0,
  noop: _0,
  safe_not_equal: d0,
  svg_element: f0
} = window.__gradio__svelte__internal, {
  SvelteComponent: h0,
  append_hydration: p0,
  attr: m0,
  children: g0,
  claim_svg_element: v0,
  detach: b0,
  init: D0,
  insert_hydration: w0,
  noop: y0,
  safe_not_equal: F0,
  svg_element: $0
} = window.__gradio__svelte__internal, {
  SvelteComponent: k0,
  append_hydration: E0,
  attr: A0,
  children: C0,
  claim_svg_element: S0,
  detach: T0,
  init: x0,
  insert_hydration: B0,
  noop: R0,
  safe_not_equal: I0,
  svg_element: L0
} = window.__gradio__svelte__internal, {
  SvelteComponent: q0,
  append_hydration: O0,
  attr: N0,
  children: M0,
  claim_svg_element: P0,
  detach: z0,
  init: U0,
  insert_hydration: H0,
  noop: G0,
  safe_not_equal: j0,
  svg_element: V0
} = window.__gradio__svelte__internal, {
  SvelteComponent: W0,
  append_hydration: Z0,
  attr: Y0,
  children: X0,
  claim_svg_element: K0,
  detach: Q0,
  init: J0,
  insert_hydration: e1,
  noop: t1,
  safe_not_equal: n1,
  svg_element: i1
} = window.__gradio__svelte__internal, {
  SvelteComponent: o1,
  append_hydration: l1,
  attr: a1,
  children: r1,
  claim_svg_element: s1,
  detach: u1,
  init: c1,
  insert_hydration: _1,
  noop: d1,
  safe_not_equal: f1,
  svg_element: h1
} = window.__gradio__svelte__internal, {
  SvelteComponent: p1,
  append_hydration: m1,
  attr: g1,
  children: v1,
  claim_svg_element: b1,
  detach: D1,
  init: w1,
  insert_hydration: y1,
  noop: F1,
  safe_not_equal: $1,
  svg_element: k1
} = window.__gradio__svelte__internal, {
  SvelteComponent: E1,
  append_hydration: A1,
  attr: C1,
  children: S1,
  claim_svg_element: T1,
  detach: x1,
  init: B1,
  insert_hydration: R1,
  noop: I1,
  safe_not_equal: L1,
  svg_element: q1
} = window.__gradio__svelte__internal, {
  SvelteComponent: O1,
  append_hydration: N1,
  attr: M1,
  children: P1,
  claim_svg_element: z1,
  detach: U1,
  init: H1,
  insert_hydration: G1,
  noop: j1,
  safe_not_equal: V1,
  svg_element: W1
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z1,
  append_hydration: Y1,
  attr: X1,
  children: K1,
  claim_svg_element: Q1,
  detach: J1,
  init: ev,
  insert_hydration: tv,
  noop: nv,
  safe_not_equal: iv,
  svg_element: ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: lv,
  append_hydration: av,
  attr: rv,
  children: sv,
  claim_svg_element: uv,
  detach: cv,
  init: _v,
  insert_hydration: dv,
  noop: fv,
  safe_not_equal: hv,
  svg_element: pv
} = window.__gradio__svelte__internal, {
  SvelteComponent: mv,
  append_hydration: gv,
  attr: vv,
  children: bv,
  claim_svg_element: Dv,
  detach: wv,
  init: yv,
  insert_hydration: Fv,
  noop: $v,
  safe_not_equal: kv,
  svg_element: Ev
} = window.__gradio__svelte__internal, {
  SvelteComponent: Av,
  append_hydration: Cv,
  attr: Sv,
  children: Tv,
  claim_svg_element: xv,
  detach: Bv,
  init: Rv,
  insert_hydration: Iv,
  noop: Lv,
  safe_not_equal: qv,
  svg_element: Ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nv,
  append_hydration: Mv,
  attr: Pv,
  children: zv,
  claim_svg_element: Uv,
  detach: Hv,
  init: Gv,
  insert_hydration: jv,
  noop: Vv,
  safe_not_equal: Wv,
  svg_element: Zv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yv,
  append_hydration: Xv,
  attr: Kv,
  children: Qv,
  claim_svg_element: Jv,
  detach: eb,
  init: tb,
  insert_hydration: nb,
  noop: ib,
  safe_not_equal: ob,
  svg_element: lb
} = window.__gradio__svelte__internal, {
  SvelteComponent: ab,
  append_hydration: rb,
  attr: sb,
  children: ub,
  claim_svg_element: cb,
  detach: _b,
  init: db,
  insert_hydration: fb,
  noop: hb,
  safe_not_equal: pb,
  svg_element: mb
} = window.__gradio__svelte__internal, {
  SvelteComponent: gb,
  append_hydration: vb,
  attr: bb,
  children: Db,
  claim_svg_element: wb,
  detach: yb,
  init: Fb,
  insert_hydration: $b,
  noop: kb,
  safe_not_equal: Eb,
  svg_element: Ab
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cb,
  append_hydration: Sb,
  attr: Tb,
  children: xb,
  claim_svg_element: Bb,
  detach: Rb,
  init: Ib,
  insert_hydration: Lb,
  noop: qb,
  safe_not_equal: Ob,
  svg_element: Nb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mb,
  append_hydration: Pb,
  attr: zb,
  children: Ub,
  claim_svg_element: Hb,
  detach: Gb,
  init: jb,
  insert_hydration: Vb,
  noop: Wb,
  safe_not_equal: Zb,
  svg_element: Yb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xb,
  append_hydration: Kb,
  attr: Qb,
  children: Jb,
  claim_svg_element: eD,
  detach: tD,
  init: nD,
  insert_hydration: iD,
  noop: oD,
  safe_not_equal: lD,
  svg_element: aD
} = window.__gradio__svelte__internal, {
  SvelteComponent: rD,
  append_hydration: sD,
  attr: uD,
  children: cD,
  claim_svg_element: _D,
  detach: dD,
  init: fD,
  insert_hydration: hD,
  noop: pD,
  safe_not_equal: mD,
  svg_element: gD
} = window.__gradio__svelte__internal, {
  SvelteComponent: vD,
  append_hydration: bD,
  attr: DD,
  children: wD,
  claim_svg_element: yD,
  detach: FD,
  init: $D,
  insert_hydration: kD,
  noop: ED,
  safe_not_equal: AD,
  svg_element: CD
} = window.__gradio__svelte__internal, {
  SvelteComponent: SD,
  append_hydration: TD,
  attr: xD,
  children: BD,
  claim_svg_element: RD,
  detach: ID,
  init: LD,
  insert_hydration: qD,
  noop: OD,
  safe_not_equal: ND,
  svg_element: MD
} = window.__gradio__svelte__internal, {
  SvelteComponent: PD,
  append_hydration: zD,
  attr: UD,
  children: HD,
  claim_svg_element: GD,
  detach: jD,
  init: VD,
  insert_hydration: WD,
  noop: ZD,
  safe_not_equal: YD,
  svg_element: XD
} = window.__gradio__svelte__internal, {
  SvelteComponent: KD,
  append_hydration: QD,
  attr: JD,
  children: ew,
  claim_svg_element: tw,
  detach: nw,
  init: iw,
  insert_hydration: ow,
  noop: lw,
  safe_not_equal: aw,
  set_style: rw,
  svg_element: sw
} = window.__gradio__svelte__internal, {
  SvelteComponent: uw,
  append_hydration: cw,
  attr: _w,
  children: dw,
  claim_svg_element: fw,
  detach: hw,
  init: pw,
  insert_hydration: mw,
  noop: gw,
  safe_not_equal: vw,
  svg_element: bw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dw,
  append_hydration: ww,
  attr: yw,
  children: Fw,
  claim_svg_element: $w,
  detach: kw,
  init: Ew,
  insert_hydration: Aw,
  noop: Cw,
  safe_not_equal: Sw,
  svg_element: Tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: xw,
  append_hydration: Bw,
  attr: Rw,
  children: Iw,
  claim_svg_element: Lw,
  detach: qw,
  init: Ow,
  insert_hydration: Nw,
  noop: Mw,
  safe_not_equal: Pw,
  svg_element: zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uw,
  append_hydration: Hw,
  attr: Gw,
  children: jw,
  claim_svg_element: Vw,
  detach: Ww,
  init: Zw,
  insert_hydration: Yw,
  noop: Xw,
  safe_not_equal: Kw,
  svg_element: Qw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jw,
  append_hydration: ey,
  attr: ty,
  children: ny,
  claim_svg_element: iy,
  detach: oy,
  init: ly,
  insert_hydration: ay,
  noop: ry,
  safe_not_equal: sy,
  svg_element: uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: cy,
  append_hydration: _y,
  attr: dy,
  children: fy,
  claim_svg_element: hy,
  detach: py,
  init: my,
  insert_hydration: gy,
  noop: vy,
  safe_not_equal: by,
  svg_element: Dy
} = window.__gradio__svelte__internal, {
  SvelteComponent: wy,
  append_hydration: yy,
  attr: Fy,
  children: $y,
  claim_svg_element: ky,
  detach: Ey,
  init: Ay,
  insert_hydration: Cy,
  noop: Sy,
  safe_not_equal: Ty,
  svg_element: xy
} = window.__gradio__svelte__internal, {
  SvelteComponent: By,
  append_hydration: Ry,
  attr: Iy,
  children: Ly,
  claim_svg_element: qy,
  detach: Oy,
  init: Ny,
  insert_hydration: My,
  noop: Py,
  safe_not_equal: zy,
  svg_element: Uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Du,
  append_hydration: ct,
  attr: Y,
  children: _t,
  claim_svg_element: dt,
  claim_text: wu,
  detach: it,
  init: yu,
  insert_hydration: Fu,
  noop: Fi,
  safe_not_equal: $u,
  svg_element: ft,
  text: ku
} = window.__gradio__svelte__internal;
function Eu(o) {
  let e, t, n, i, a, l, r, s, u;
  return {
    c() {
      e = ft("svg"), t = ft("defs"), n = ft("style"), i = ku(`.cls-1 {
				fill: none;
			}
		`), a = ft("rect"), l = ft("rect"), r = ft("path"), s = ft("rect"), u = ft("rect"), this.h();
    },
    l(c) {
      e = dt(c, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        fill: !0,
        width: !0,
        height: !0
      });
      var m = _t(e);
      t = dt(m, "defs", {});
      var d = _t(t);
      n = dt(d, "style", {});
      var g = _t(n);
      i = wu(g, `.cls-1 {
				fill: none;
			}
		`), g.forEach(it), d.forEach(it), a = dt(m, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), _t(a).forEach(it), l = dt(m, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), _t(l).forEach(it), r = dt(m, "path", { d: !0 }), _t(r).forEach(it), s = dt(m, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), _t(s).forEach(it), u = dt(m, "rect", {
        id: !0,
        "data-name": !0,
        class: !0,
        width: !0,
        height: !0
      }), _t(u).forEach(it), m.forEach(it), this.h();
    },
    h() {
      Y(a, "x", "12"), Y(a, "y", "12"), Y(a, "width", "2"), Y(a, "height", "12"), Y(l, "x", "18"), Y(l, "y", "12"), Y(l, "width", "2"), Y(l, "height", "12"), Y(r, "d", "M4,6V8H6V28a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V8h2V6ZM8,28V8H24V28Z"), Y(s, "x", "12"), Y(s, "y", "2"), Y(s, "width", "8"), Y(s, "height", "2"), Y(u, "id", "_Transparent_Rectangle_"), Y(u, "data-name", "<Transparent Rectangle>"), Y(u, "class", "cls-1"), Y(u, "width", "32"), Y(u, "height", "32"), Y(e, "id", "icon"), Y(e, "xmlns", "http://www.w3.org/2000/svg"), Y(e, "viewBox", "0 0 32 32"), Y(e, "fill", "currentColor"), Y(e, "width", "100%"), Y(e, "height", "100%");
    },
    m(c, m) {
      Fu(c, e, m), ct(e, t), ct(t, n), ct(n, i), ct(e, a), ct(e, l), ct(e, r), ct(e, s), ct(e, u);
    },
    p: Fi,
    i: Fi,
    o: Fi,
    d(c) {
      c && it(e);
    }
  };
}
class Au extends Du {
  constructor(e) {
    super(), yu(this, e, null, Eu, $u, {});
  }
}
const {
  SvelteComponent: Hy,
  append_hydration: Gy,
  attr: jy,
  children: Vy,
  claim_svg_element: Wy,
  detach: Zy,
  init: Yy,
  insert_hydration: Xy,
  noop: Ky,
  safe_not_equal: Qy,
  svg_element: Jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: eF,
  append_hydration: tF,
  attr: nF,
  children: iF,
  claim_svg_element: oF,
  detach: lF,
  init: aF,
  insert_hydration: rF,
  noop: sF,
  safe_not_equal: uF,
  svg_element: cF
} = window.__gradio__svelte__internal, {
  SvelteComponent: _F,
  append_hydration: dF,
  attr: fF,
  children: hF,
  claim_svg_element: pF,
  detach: mF,
  init: gF,
  insert_hydration: vF,
  noop: bF,
  safe_not_equal: DF,
  svg_element: wF
} = window.__gradio__svelte__internal, {
  SvelteComponent: yF,
  append_hydration: FF,
  attr: $F,
  children: kF,
  claim_svg_element: EF,
  detach: AF,
  init: CF,
  insert_hydration: SF,
  noop: TF,
  safe_not_equal: xF,
  svg_element: BF
} = window.__gradio__svelte__internal, {
  SvelteComponent: RF,
  append_hydration: IF,
  attr: LF,
  children: qF,
  claim_svg_element: OF,
  detach: NF,
  init: MF,
  insert_hydration: PF,
  noop: zF,
  safe_not_equal: UF,
  svg_element: HF
} = window.__gradio__svelte__internal, {
  SvelteComponent: GF,
  append_hydration: jF,
  attr: VF,
  children: WF,
  claim_svg_element: ZF,
  detach: YF,
  init: XF,
  insert_hydration: KF,
  noop: QF,
  safe_not_equal: JF,
  svg_element: e$
} = window.__gradio__svelte__internal, {
  SvelteComponent: t$,
  append_hydration: n$,
  attr: i$,
  children: o$,
  claim_svg_element: l$,
  detach: a$,
  init: r$,
  insert_hydration: s$,
  noop: u$,
  safe_not_equal: c$,
  svg_element: _$
} = window.__gradio__svelte__internal, {
  SvelteComponent: d$,
  append_hydration: f$,
  attr: h$,
  children: p$,
  claim_svg_element: m$,
  claim_text: g$,
  detach: v$,
  init: b$,
  insert_hydration: D$,
  noop: w$,
  safe_not_equal: y$,
  svg_element: F$,
  text: $$
} = window.__gradio__svelte__internal, {
  SvelteComponent: k$,
  append_hydration: E$,
  attr: A$,
  children: C$,
  claim_svg_element: S$,
  claim_text: T$,
  detach: x$,
  init: B$,
  insert_hydration: R$,
  noop: I$,
  safe_not_equal: L$,
  svg_element: q$,
  text: O$
} = window.__gradio__svelte__internal, {
  SvelteComponent: N$,
  append_hydration: M$,
  attr: P$,
  children: z$,
  claim_svg_element: U$,
  claim_text: H$,
  detach: G$,
  init: j$,
  insert_hydration: V$,
  noop: W$,
  safe_not_equal: Z$,
  svg_element: Y$,
  text: X$
} = window.__gradio__svelte__internal, {
  SvelteComponent: K$,
  append_hydration: Q$,
  attr: J$,
  children: e2,
  claim_svg_element: t2,
  detach: n2,
  init: i2,
  insert_hydration: o2,
  noop: l2,
  safe_not_equal: a2,
  svg_element: r2
} = window.__gradio__svelte__internal, {
  SvelteComponent: s2,
  append_hydration: u2,
  attr: c2,
  children: _2,
  claim_svg_element: d2,
  detach: f2,
  init: h2,
  insert_hydration: p2,
  noop: m2,
  safe_not_equal: g2,
  svg_element: v2
} = window.__gradio__svelte__internal, {
  SvelteComponent: b2,
  append_hydration: D2,
  attr: w2,
  children: y2,
  claim_svg_element: F2,
  detach: $2,
  init: k2,
  insert_hydration: E2,
  noop: A2,
  safe_not_equal: C2,
  svg_element: S2
} = window.__gradio__svelte__internal, {
  SvelteComponent: T2,
  append_hydration: x2,
  attr: B2,
  children: R2,
  claim_svg_element: I2,
  detach: L2,
  init: q2,
  insert_hydration: O2,
  noop: N2,
  safe_not_equal: M2,
  svg_element: P2
} = window.__gradio__svelte__internal, {
  SvelteComponent: z2,
  append_hydration: U2,
  attr: H2,
  children: G2,
  claim_svg_element: j2,
  detach: V2,
  init: W2,
  insert_hydration: Z2,
  noop: Y2,
  safe_not_equal: X2,
  svg_element: K2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q2,
  append_hydration: J2,
  attr: ek,
  children: tk,
  claim_svg_element: nk,
  detach: ik,
  init: ok,
  insert_hydration: lk,
  noop: ak,
  safe_not_equal: rk,
  svg_element: sk
} = window.__gradio__svelte__internal, {
  SvelteComponent: uk,
  append_hydration: ck,
  attr: _k,
  children: dk,
  claim_svg_element: fk,
  detach: hk,
  init: pk,
  insert_hydration: mk,
  noop: gk,
  safe_not_equal: vk,
  svg_element: bk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dk,
  append_hydration: wk,
  attr: yk,
  children: Fk,
  claim_svg_element: $k,
  detach: kk,
  init: Ek,
  insert_hydration: Ak,
  noop: Ck,
  safe_not_equal: Sk,
  svg_element: Tk
} = window.__gradio__svelte__internal, Cu = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ol = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Cu.reduce(
  (o, { color: e, primary: t, secondary: n }) => ({
    ...o,
    [e]: {
      primary: ol[e][t],
      secondary: ol[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: xk,
  claim_component: Bk,
  create_component: Rk,
  destroy_component: Ik,
  init: Lk,
  mount_component: qk,
  safe_not_equal: Ok,
  transition_in: Nk,
  transition_out: Mk
} = window.__gradio__svelte__internal, { createEventDispatcher: Pk } = window.__gradio__svelte__internal, {
  SvelteComponent: zk,
  append_hydration: Uk,
  attr: Hk,
  check_outros: Gk,
  children: jk,
  claim_component: Vk,
  claim_element: Wk,
  claim_space: Zk,
  claim_text: Yk,
  create_component: Xk,
  destroy_component: Kk,
  detach: Qk,
  element: Jk,
  empty: eE,
  group_outros: tE,
  init: nE,
  insert_hydration: iE,
  mount_component: oE,
  safe_not_equal: lE,
  set_data: aE,
  space: rE,
  text: sE,
  toggle_class: uE,
  transition_in: cE,
  transition_out: _E
} = window.__gradio__svelte__internal, {
  SvelteComponent: dE,
  attr: fE,
  children: hE,
  claim_element: pE,
  create_slot: mE,
  detach: gE,
  element: vE,
  get_all_dirty_from_scope: bE,
  get_slot_changes: DE,
  init: wE,
  insert_hydration: yE,
  safe_not_equal: FE,
  toggle_class: $E,
  transition_in: kE,
  transition_out: EE,
  update_slot_base: AE
} = window.__gradio__svelte__internal, {
  SvelteComponent: CE,
  append_hydration: SE,
  attr: TE,
  check_outros: xE,
  children: BE,
  claim_component: RE,
  claim_element: IE,
  claim_space: LE,
  create_component: qE,
  destroy_component: OE,
  detach: NE,
  element: ME,
  empty: PE,
  group_outros: zE,
  init: UE,
  insert_hydration: HE,
  listen: GE,
  mount_component: jE,
  safe_not_equal: VE,
  space: WE,
  toggle_class: ZE,
  transition_in: YE,
  transition_out: XE
} = window.__gradio__svelte__internal, {
  SvelteComponent: Su,
  attr: ll,
  children: Tu,
  claim_element: xu,
  create_slot: Bu,
  detach: al,
  element: Ru,
  get_all_dirty_from_scope: Iu,
  get_slot_changes: Lu,
  init: qu,
  insert_hydration: Ou,
  null_to_empty: rl,
  safe_not_equal: Nu,
  transition_in: Mu,
  transition_out: Pu,
  update_slot_base: zu
} = window.__gradio__svelte__internal;
function Uu(o) {
  let e, t, n;
  const i = (
    /*#slots*/
    o[3].default
  ), a = Bu(
    i,
    o,
    /*$$scope*/
    o[2],
    null
  );
  return {
    c() {
      e = Ru("div"), a && a.c(), this.h();
    },
    l(l) {
      e = xu(l, "DIV", { class: !0 });
      var r = Tu(e);
      a && a.l(r), r.forEach(al), this.h();
    },
    h() {
      ll(e, "class", t = rl(`icon-button-wrapper ${/*top_panel*/
      o[0] ? "top-panel" : ""} ${/*display_top_corner*/
      o[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4");
    },
    m(l, r) {
      Ou(l, e, r), a && a.m(e, null), n = !0;
    },
    p(l, [r]) {
      a && a.p && (!n || r & /*$$scope*/
      4) && zu(
        a,
        i,
        l,
        /*$$scope*/
        l[2],
        n ? Lu(
          i,
          /*$$scope*/
          l[2],
          r,
          null
        ) : Iu(
          /*$$scope*/
          l[2]
        ),
        null
      ), (!n || r & /*top_panel, display_top_corner*/
      3 && t !== (t = rl(`icon-button-wrapper ${/*top_panel*/
      l[0] ? "top-panel" : ""} ${/*display_top_corner*/
      l[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4")) && ll(e, "class", t);
    },
    i(l) {
      n || (Mu(a, l), n = !0);
    },
    o(l) {
      Pu(a, l), n = !1;
    },
    d(l) {
      l && al(e), a && a.d(l);
    }
  };
}
function Hu(o, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { top_panel: a = !0 } = e, { display_top_corner: l = !1 } = e;
  return o.$$set = (r) => {
    "top_panel" in r && t(0, a = r.top_panel), "display_top_corner" in r && t(1, l = r.display_top_corner), "$$scope" in r && t(2, i = r.$$scope);
  }, [a, l, i, n];
}
class Gu extends Su {
  constructor(e) {
    super(), qu(this, e, Hu, Uu, Nu, { top_panel: 0, display_top_corner: 1 });
  }
}
const {
  SvelteComponent: KE,
  check_outros: QE,
  claim_component: JE,
  create_component: eA,
  destroy_component: tA,
  detach: nA,
  empty: iA,
  group_outros: oA,
  init: lA,
  insert_hydration: aA,
  mount_component: rA,
  noop: sA,
  safe_not_equal: uA,
  transition_in: cA,
  transition_out: _A
} = window.__gradio__svelte__internal, { createEventDispatcher: dA } = window.__gradio__svelte__internal;
function Pt(o) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; o > 1e3 && t < e.length - 1; )
    o /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(o) ? o : o.toFixed(1)) + n;
}
function Sn() {
}
const wa = typeof window < "u";
let sl = wa ? () => window.performance.now() : () => Date.now(), ya = wa ? (o) => requestAnimationFrame(o) : Sn;
const Ut = /* @__PURE__ */ new Set();
function Fa(o) {
  Ut.forEach((e) => {
    e.c(o) || (Ut.delete(e), e.f());
  }), Ut.size !== 0 && ya(Fa);
}
function ju(o) {
  let e;
  return Ut.size === 0 && ya(Fa), { promise: new Promise((t) => {
    Ut.add(e = { c: o, f: t });
  }), abort() {
    Ut.delete(e);
  } };
}
const Nt = [];
function Vu(o, e = Sn) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(l) {
    if (s = l, ((r = o) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (o = l, t)) {
      const u = !Nt.length;
      for (const c of n) c[1](), Nt.push(c, o);
      if (u) {
        for (let c = 0; c < Nt.length; c += 2) Nt[c][0](Nt[c + 1]);
        Nt.length = 0;
      }
    }
    var r, s;
  }
  function a(l) {
    i(l(o));
  }
  return { set: i, update: a, subscribe: function(l, r = Sn) {
    const s = [l, r];
    return n.add(s), n.size === 1 && (t = e(i, a) || Sn), l(o), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ul(o) {
  return Object.prototype.toString.call(o) === "[object Date]";
}
function Gi(o, e, t, n) {
  if (typeof t == "number" || ul(t)) {
    const i = n - t, a = (t - e) / (o.dt || 1 / 60), l = (a + (o.opts.stiffness * i - o.opts.damping * a) * o.inv_mass) * o.dt;
    return Math.abs(l) < o.opts.precision && Math.abs(i) < o.opts.precision ? n : (o.settled = !1, ul(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((i, a) => Gi(o, e[a], t[a], n[a]));
  if (typeof t == "object") {
    const i = {};
    for (const a in t) i[a] = Gi(o, e[a], t[a], n[a]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function cl(o, e = {}) {
  const t = Vu(o), { stiffness: n = 0.15, damping: i = 0.8, precision: a = 0.01 } = e;
  let l, r, s, u = o, c = o, m = 1, d = 0, g = !1;
  function b(D, $ = {}) {
    c = D;
    const h = s = {};
    return o == null || $.hard || p.stiffness >= 1 && p.damping >= 1 ? (g = !0, l = sl(), u = D, t.set(o = c), Promise.resolve()) : ($.soft && (d = 1 / (60 * ($.soft === !0 ? 0.5 : +$.soft)), m = 0), r || (l = sl(), g = !1, r = ju((_) => {
      if (g) return g = !1, r = null, !1;
      m = Math.min(m + d, 1);
      const v = { inv_mass: m, opts: p, settled: !0, dt: 60 * (_ - l) / 1e3 }, y = Gi(v, u, o, c);
      return l = _, u = o, t.set(o = y), v.settled && (r = null), !v.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        h === s && _();
      });
    }));
  }
  const p = { set: b, update: (D, $) => b(D(c, o), $), subscribe: t.subscribe, stiffness: n, damping: i, precision: a };
  return p;
}
const {
  SvelteComponent: Wu,
  append_hydration: Le,
  attr: M,
  children: Ae,
  claim_element: Zu,
  claim_svg_element: qe,
  component_subscribe: _l,
  detach: De,
  element: Yu,
  init: Xu,
  insert_hydration: Ku,
  noop: dl,
  safe_not_equal: Qu,
  set_style: yn,
  svg_element: Oe,
  toggle_class: fl
} = window.__gradio__svelte__internal, { onMount: Ju } = window.__gradio__svelte__internal;
function ec(o) {
  let e, t, n, i, a, l, r, s, u, c, m, d;
  return {
    c() {
      e = Yu("div"), t = Oe("svg"), n = Oe("g"), i = Oe("path"), a = Oe("path"), l = Oe("path"), r = Oe("path"), s = Oe("g"), u = Oe("path"), c = Oe("path"), m = Oe("path"), d = Oe("path"), this.h();
    },
    l(g) {
      e = Zu(g, "DIV", { class: !0 });
      var b = Ae(e);
      t = qe(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var p = Ae(t);
      n = qe(p, "g", { style: !0 });
      var D = Ae(n);
      i = qe(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ae(i).forEach(De), a = qe(D, "path", { d: !0, fill: !0, class: !0 }), Ae(a).forEach(De), l = qe(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ae(l).forEach(De), r = qe(D, "path", { d: !0, fill: !0, class: !0 }), Ae(r).forEach(De), D.forEach(De), s = qe(p, "g", { style: !0 });
      var $ = Ae(s);
      u = qe($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ae(u).forEach(De), c = qe($, "path", { d: !0, fill: !0, class: !0 }), Ae(c).forEach(De), m = qe($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ae(m).forEach(De), d = qe($, "path", { d: !0, fill: !0, class: !0 }), Ae(d).forEach(De), $.forEach(De), p.forEach(De), b.forEach(De), this.h();
    },
    h() {
      M(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), M(i, "fill", "#FF7C00"), M(i, "fill-opacity", "0.4"), M(i, "class", "svelte-43sxxs"), M(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), M(a, "fill", "#FF7C00"), M(a, "class", "svelte-43sxxs"), M(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), M(l, "fill", "#FF7C00"), M(l, "fill-opacity", "0.4"), M(l, "class", "svelte-43sxxs"), M(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), M(r, "fill", "#FF7C00"), M(r, "class", "svelte-43sxxs"), yn(n, "transform", "translate(" + /*$top*/
      o[1][0] + "px, " + /*$top*/
      o[1][1] + "px)"), M(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), M(u, "fill", "#FF7C00"), M(u, "fill-opacity", "0.4"), M(u, "class", "svelte-43sxxs"), M(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), M(c, "fill", "#FF7C00"), M(c, "class", "svelte-43sxxs"), M(m, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), M(m, "fill", "#FF7C00"), M(m, "fill-opacity", "0.4"), M(m, "class", "svelte-43sxxs"), M(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), M(d, "fill", "#FF7C00"), M(d, "class", "svelte-43sxxs"), yn(s, "transform", "translate(" + /*$bottom*/
      o[2][0] + "px, " + /*$bottom*/
      o[2][1] + "px)"), M(t, "viewBox", "-1200 -1200 3000 3000"), M(t, "fill", "none"), M(t, "xmlns", "http://www.w3.org/2000/svg"), M(t, "class", "svelte-43sxxs"), M(e, "class", "svelte-43sxxs"), fl(
        e,
        "margin",
        /*margin*/
        o[0]
      );
    },
    m(g, b) {
      Ku(g, e, b), Le(e, t), Le(t, n), Le(n, i), Le(n, a), Le(n, l), Le(n, r), Le(t, s), Le(s, u), Le(s, c), Le(s, m), Le(s, d);
    },
    p(g, [b]) {
      b & /*$top*/
      2 && yn(n, "transform", "translate(" + /*$top*/
      g[1][0] + "px, " + /*$top*/
      g[1][1] + "px)"), b & /*$bottom*/
      4 && yn(s, "transform", "translate(" + /*$bottom*/
      g[2][0] + "px, " + /*$bottom*/
      g[2][1] + "px)"), b & /*margin*/
      1 && fl(
        e,
        "margin",
        /*margin*/
        g[0]
      );
    },
    i: dl,
    o: dl,
    d(g) {
      g && De(e);
    }
  };
}
function tc(o, e, t) {
  let n, i;
  var a = this && this.__awaiter || function(g, b, p, D) {
    function $(h) {
      return h instanceof p ? h : new p(function(_) {
        _(h);
      });
    }
    return new (p || (p = Promise))(function(h, _) {
      function v(A) {
        try {
          w(D.next(A));
        } catch (F) {
          _(F);
        }
      }
      function y(A) {
        try {
          w(D.throw(A));
        } catch (F) {
          _(F);
        }
      }
      function w(A) {
        A.done ? h(A.value) : $(A.value).then(v, y);
      }
      w((D = D.apply(g, b || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const r = cl([0, 0]);
  _l(o, r, (g) => t(1, n = g));
  const s = cl([0, 0]);
  _l(o, s, (g) => t(2, i = g));
  let u;
  function c() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function m() {
    return a(this, void 0, void 0, function* () {
      yield c(), u || m();
    });
  }
  function d() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), m();
    });
  }
  return Ju(() => (d(), () => u = !0)), o.$$set = (g) => {
    "margin" in g && t(0, l = g.margin);
  }, [l, n, i, r, s];
}
class nc extends Wu {
  constructor(e) {
    super(), Xu(this, e, tc, ec, Qu, { margin: 0 });
  }
}
const {
  SvelteComponent: ic,
  append_hydration: wt,
  attr: Pe,
  binding_callbacks: hl,
  check_outros: ji,
  children: Xe,
  claim_component: $a,
  claim_element: Ke,
  claim_space: Se,
  claim_text: X,
  create_component: ka,
  create_slot: Ea,
  destroy_component: Aa,
  destroy_each: Ca,
  detach: R,
  element: Qe,
  empty: xe,
  ensure_array_like: In,
  get_all_dirty_from_scope: Sa,
  get_slot_changes: Ta,
  group_outros: Vi,
  init: oc,
  insert_hydration: q,
  mount_component: xa,
  noop: Wi,
  safe_not_equal: lc,
  set_data: Be,
  set_style: pt,
  space: Te,
  text: K,
  toggle_class: Ce,
  transition_in: Me,
  transition_out: Je,
  update_slot_base: Ba
} = window.__gradio__svelte__internal, { tick: ac } = window.__gradio__svelte__internal, { onDestroy: rc } = window.__gradio__svelte__internal, { createEventDispatcher: sc } = window.__gradio__svelte__internal, uc = (o) => ({}), pl = (o) => ({}), cc = (o) => ({}), ml = (o) => ({});
function gl(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n[42] = t, n;
}
function vl(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n;
}
function _c(o) {
  let e, t, n, i, a = (
    /*i18n*/
    o[1]("common.error") + ""
  ), l, r, s;
  t = new jn({
    props: {
      Icon: ru,
      label: (
        /*i18n*/
        o[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    o[32]
  );
  const u = (
    /*#slots*/
    o[30].error
  ), c = Ea(
    u,
    o,
    /*$$scope*/
    o[29],
    pl
  );
  return {
    c() {
      e = Qe("div"), ka(t.$$.fragment), n = Te(), i = Qe("span"), l = K(a), r = Te(), c && c.c(), this.h();
    },
    l(m) {
      e = Ke(m, "DIV", { class: !0 });
      var d = Xe(e);
      $a(t.$$.fragment, d), d.forEach(R), n = Se(m), i = Ke(m, "SPAN", { class: !0 });
      var g = Xe(i);
      l = X(g, a), g.forEach(R), r = Se(m), c && c.l(m), this.h();
    },
    h() {
      Pe(e, "class", "clear-status svelte-17v219f"), Pe(i, "class", "error svelte-17v219f");
    },
    m(m, d) {
      q(m, e, d), xa(t, e, null), q(m, n, d), q(m, i, d), wt(i, l), q(m, r, d), c && c.m(m, d), s = !0;
    },
    p(m, d) {
      const g = {};
      d[0] & /*i18n*/
      2 && (g.label = /*i18n*/
      m[1]("common.clear")), t.$set(g), (!s || d[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      m[1]("common.error") + "") && Be(l, a), c && c.p && (!s || d[0] & /*$$scope*/
      536870912) && Ba(
        c,
        u,
        m,
        /*$$scope*/
        m[29],
        s ? Ta(
          u,
          /*$$scope*/
          m[29],
          d,
          uc
        ) : Sa(
          /*$$scope*/
          m[29]
        ),
        pl
      );
    },
    i(m) {
      s || (Me(t.$$.fragment, m), Me(c, m), s = !0);
    },
    o(m) {
      Je(t.$$.fragment, m), Je(c, m), s = !1;
    },
    d(m) {
      m && (R(e), R(n), R(i), R(r)), Aa(t), c && c.d(m);
    }
  };
}
function dc(o) {
  let e, t, n, i, a, l, r, s, u, c = (
    /*variant*/
    o[8] === "default" && /*show_eta_bar*/
    o[18] && /*show_progress*/
    o[6] === "full" && bl(o)
  );
  function m(_, v) {
    if (
      /*progress*/
      _[7]
    ) return pc;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return hc;
    if (
      /*queue_position*/
      _[2] === 0
    ) return fc;
  }
  let d = m(o), g = d && d(o), b = (
    /*timer*/
    o[5] && yl(o)
  );
  const p = [bc, vc], D = [];
  function $(_, v) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = $(o)) && (l = D[a] = p[a](o));
  let h = !/*timer*/
  o[5] && Sl(o);
  return {
    c() {
      c && c.c(), e = Te(), t = Qe("div"), g && g.c(), n = Te(), b && b.c(), i = Te(), l && l.c(), r = Te(), h && h.c(), s = xe(), this.h();
    },
    l(_) {
      c && c.l(_), e = Se(_), t = Ke(_, "DIV", { class: !0 });
      var v = Xe(t);
      g && g.l(v), n = Se(v), b && b.l(v), v.forEach(R), i = Se(_), l && l.l(_), r = Se(_), h && h.l(_), s = xe(), this.h();
    },
    h() {
      Pe(t, "class", "progress-text svelte-17v219f"), Ce(
        t,
        "meta-text-center",
        /*variant*/
        o[8] === "center"
      ), Ce(
        t,
        "meta-text",
        /*variant*/
        o[8] === "default"
      );
    },
    m(_, v) {
      c && c.m(_, v), q(_, e, v), q(_, t, v), g && g.m(t, null), wt(t, n), b && b.m(t, null), q(_, i, v), ~a && D[a].m(_, v), q(_, r, v), h && h.m(_, v), q(_, s, v), u = !0;
    },
    p(_, v) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, v) : (c = bl(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = m(_)) && g ? g.p(_, v) : (g && g.d(1), g = d && d(_), g && (g.c(), g.m(t, n))), /*timer*/
      _[5] ? b ? b.p(_, v) : (b = yl(_), b.c(), b.m(t, null)) : b && (b.d(1), b = null), (!u || v[0] & /*variant*/
      256) && Ce(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || v[0] & /*variant*/
      256) && Ce(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let y = a;
      a = $(_), a === y ? ~a && D[a].p(_, v) : (l && (Vi(), Je(D[y], 1, 1, () => {
        D[y] = null;
      }), ji()), ~a ? (l = D[a], l ? l.p(_, v) : (l = D[a] = p[a](_), l.c()), Me(l, 1), l.m(r.parentNode, r)) : l = null), /*timer*/
      _[5] ? h && (Vi(), Je(h, 1, 1, () => {
        h = null;
      }), ji()) : h ? (h.p(_, v), v[0] & /*timer*/
      32 && Me(h, 1)) : (h = Sl(_), h.c(), Me(h, 1), h.m(s.parentNode, s));
    },
    i(_) {
      u || (Me(l), Me(h), u = !0);
    },
    o(_) {
      Je(l), Je(h), u = !1;
    },
    d(_) {
      _ && (R(e), R(t), R(i), R(r), R(s)), c && c.d(_), g && g.d(), b && b.d(), ~a && D[a].d(_), h && h.d(_);
    }
  };
}
function bl(o) {
  let e, t = `translateX(${/*eta_level*/
  (o[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Qe("div"), this.h();
    },
    l(n) {
      e = Ke(n, "DIV", { class: !0 }), Xe(e).forEach(R), this.h();
    },
    h() {
      Pe(e, "class", "eta-bar svelte-17v219f"), pt(e, "transform", t);
    },
    m(n, i) {
      q(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && pt(e, "transform", t);
    },
    d(n) {
      n && R(e);
    }
  };
}
function fc(o) {
  let e;
  return {
    c() {
      e = K("processing |");
    },
    l(t) {
      e = X(t, "processing |");
    },
    m(t, n) {
      q(t, e, n);
    },
    p: Wi,
    d(t) {
      t && R(e);
    }
  };
}
function hc(o) {
  let e, t = (
    /*queue_position*/
    o[2] + 1 + ""
  ), n, i, a, l;
  return {
    c() {
      e = K("queue: "), n = K(t), i = K("/"), a = K(
        /*queue_size*/
        o[3]
      ), l = K(" |");
    },
    l(r) {
      e = X(r, "queue: "), n = X(r, t), i = X(r, "/"), a = X(
        r,
        /*queue_size*/
        o[3]
      ), l = X(r, " |");
    },
    m(r, s) {
      q(r, e, s), q(r, n, s), q(r, i, s), q(r, a, s), q(r, l, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && Be(n, t), s[0] & /*queue_size*/
      8 && Be(
        a,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (R(e), R(n), R(i), R(a), R(l));
    }
  };
}
function pc(o) {
  let e, t = In(
    /*progress*/
    o[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = wl(vl(o, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = xe();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = xe();
    },
    m(i, a) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, a);
      q(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      128) {
        t = In(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = vl(i, t, l);
          n[l] ? n[l].p(r, a) : (n[l] = wl(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && R(e), Ca(n, i);
    }
  };
}
function Dl(o) {
  let e, t = (
    /*p*/
    o[40].unit + ""
  ), n, i, a = " ", l;
  function r(c, m) {
    return (
      /*p*/
      c[40].length != null ? gc : mc
    );
  }
  let s = r(o), u = s(o);
  return {
    c() {
      u.c(), e = Te(), n = K(t), i = K(" | "), l = K(a);
    },
    l(c) {
      u.l(c), e = Se(c), n = X(c, t), i = X(c, " | "), l = X(c, a);
    },
    m(c, m) {
      u.m(c, m), q(c, e, m), q(c, n, m), q(c, i, m), q(c, l, m);
    },
    p(c, m) {
      s === (s = r(c)) && u ? u.p(c, m) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), m[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Be(n, t);
    },
    d(c) {
      c && (R(e), R(n), R(i), R(l)), u.d(c);
    }
  };
}
function mc(o) {
  let e = Pt(
    /*p*/
    o[40].index || 0
  ) + "", t;
  return {
    c() {
      t = K(e);
    },
    l(n) {
      t = X(n, e);
    },
    m(n, i) {
      q(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = Pt(
        /*p*/
        n[40].index || 0
      ) + "") && Be(t, e);
    },
    d(n) {
      n && R(t);
    }
  };
}
function gc(o) {
  let e = Pt(
    /*p*/
    o[40].index || 0
  ) + "", t, n, i = Pt(
    /*p*/
    o[40].length
  ) + "", a;
  return {
    c() {
      t = K(e), n = K("/"), a = K(i);
    },
    l(l) {
      t = X(l, e), n = X(l, "/"), a = X(l, i);
    },
    m(l, r) {
      q(l, t, r), q(l, n, r), q(l, a, r);
    },
    p(l, r) {
      r[0] & /*progress*/
      128 && e !== (e = Pt(
        /*p*/
        l[40].index || 0
      ) + "") && Be(t, e), r[0] & /*progress*/
      128 && i !== (i = Pt(
        /*p*/
        l[40].length
      ) + "") && Be(a, i);
    },
    d(l) {
      l && (R(t), R(n), R(a));
    }
  };
}
function wl(o) {
  let e, t = (
    /*p*/
    o[40].index != null && Dl(o)
  );
  return {
    c() {
      t && t.c(), e = xe();
    },
    l(n) {
      t && t.l(n), e = xe();
    },
    m(n, i) {
      t && t.m(n, i), q(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].index != null ? t ? t.p(n, i) : (t = Dl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && R(e), t && t.d(n);
    }
  };
}
function yl(o) {
  let e, t = (
    /*eta*/
    o[0] ? `/${/*formatted_eta*/
    o[19]}` : ""
  ), n, i;
  return {
    c() {
      e = K(
        /*formatted_timer*/
        o[20]
      ), n = K(t), i = K("s");
    },
    l(a) {
      e = X(
        a,
        /*formatted_timer*/
        o[20]
      ), n = X(a, t), i = X(a, "s");
    },
    m(a, l) {
      q(a, e, l), q(a, n, l), q(a, i, l);
    },
    p(a, l) {
      l[0] & /*formatted_timer*/
      1048576 && Be(
        e,
        /*formatted_timer*/
        a[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && Be(n, t);
    },
    d(a) {
      a && (R(e), R(n), R(i));
    }
  };
}
function vc(o) {
  let e, t;
  return e = new nc({
    props: { margin: (
      /*variant*/
      o[8] === "default"
    ) }
  }), {
    c() {
      ka(e.$$.fragment);
    },
    l(n) {
      $a(e.$$.fragment, n);
    },
    m(n, i) {
      xa(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*variant*/
      256 && (a.margin = /*variant*/
      n[8] === "default"), e.$set(a);
    },
    i(n) {
      t || (Me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Je(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Aa(e, n);
    }
  };
}
function bc(o) {
  let e, t, n, i, a, l = `${/*last_progress_level*/
  o[15] * 100}%`, r = (
    /*progress*/
    o[7] != null && Fl(o)
  );
  return {
    c() {
      e = Qe("div"), t = Qe("div"), r && r.c(), n = Te(), i = Qe("div"), a = Qe("div"), this.h();
    },
    l(s) {
      e = Ke(s, "DIV", { class: !0 });
      var u = Xe(e);
      t = Ke(u, "DIV", { class: !0 });
      var c = Xe(t);
      r && r.l(c), c.forEach(R), n = Se(u), i = Ke(u, "DIV", { class: !0 });
      var m = Xe(i);
      a = Ke(m, "DIV", { class: !0 }), Xe(a).forEach(R), m.forEach(R), u.forEach(R), this.h();
    },
    h() {
      Pe(t, "class", "progress-level-inner svelte-17v219f"), Pe(a, "class", "progress-bar svelte-17v219f"), pt(a, "width", l), Pe(i, "class", "progress-bar-wrap svelte-17v219f"), Pe(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      q(s, e, u), wt(e, t), r && r.m(t, null), wt(e, n), wt(e, i), wt(i, a), o[31](a);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = Fl(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && pt(a, "width", l);
    },
    i: Wi,
    o: Wi,
    d(s) {
      s && R(e), r && r.d(), o[31](null);
    }
  };
}
function Fl(o) {
  let e, t = In(
    /*progress*/
    o[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Cl(gl(o, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = xe();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = xe();
    },
    m(i, a) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, a);
      q(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        t = In(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = gl(i, t, l);
          n[l] ? n[l].p(r, a) : (n[l] = Cl(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && R(e), Ca(n, i);
    }
  };
}
function $l(o) {
  let e, t, n, i, a = (
    /*i*/
    o[42] !== 0 && Dc()
  ), l = (
    /*p*/
    o[40].desc != null && kl(o)
  ), r = (
    /*p*/
    o[40].desc != null && /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null && El()
  ), s = (
    /*progress_level*/
    o[14] != null && Al(o)
  );
  return {
    c() {
      a && a.c(), e = Te(), l && l.c(), t = Te(), r && r.c(), n = Te(), s && s.c(), i = xe();
    },
    l(u) {
      a && a.l(u), e = Se(u), l && l.l(u), t = Se(u), r && r.l(u), n = Se(u), s && s.l(u), i = xe();
    },
    m(u, c) {
      a && a.m(u, c), q(u, e, c), l && l.m(u, c), q(u, t, c), r && r.m(u, c), q(u, n, c), s && s.m(u, c), q(u, i, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, c) : (l = kl(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = El(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = Al(u), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (R(e), R(t), R(n), R(i)), a && a.d(u), l && l.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function Dc(o) {
  let e;
  return {
    c() {
      e = K(" /");
    },
    l(t) {
      e = X(t, " /");
    },
    m(t, n) {
      q(t, e, n);
    },
    d(t) {
      t && R(e);
    }
  };
}
function kl(o) {
  let e = (
    /*p*/
    o[40].desc + ""
  ), t;
  return {
    c() {
      t = K(e);
    },
    l(n) {
      t = X(n, e);
    },
    m(n, i) {
      q(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Be(t, e);
    },
    d(n) {
      n && R(t);
    }
  };
}
function El(o) {
  let e;
  return {
    c() {
      e = K("-");
    },
    l(t) {
      e = X(t, "-");
    },
    m(t, n) {
      q(t, e, n);
    },
    d(t) {
      t && R(e);
    }
  };
}
function Al(o) {
  let e = (100 * /*progress_level*/
  (o[14][
    /*i*/
    o[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = K(e), n = K("%");
    },
    l(i) {
      t = X(i, e), n = X(i, "%");
    },
    m(i, a) {
      q(i, t, a), q(i, n, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && Be(t, e);
    },
    d(i) {
      i && (R(t), R(n));
    }
  };
}
function Cl(o) {
  let e, t = (
    /*p*/
    (o[40].desc != null || /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null) && $l(o)
  );
  return {
    c() {
      t && t.c(), e = xe();
    },
    l(n) {
      t && t.l(n), e = xe();
    },
    m(n, i) {
      t && t.m(n, i), q(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, i) : (t = $l(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && R(e), t && t.d(n);
    }
  };
}
function Sl(o) {
  let e, t, n, i;
  const a = (
    /*#slots*/
    o[30]["additional-loading-text"]
  ), l = Ea(
    a,
    o,
    /*$$scope*/
    o[29],
    ml
  );
  return {
    c() {
      e = Qe("p"), t = K(
        /*loading_text*/
        o[9]
      ), n = Te(), l && l.c(), this.h();
    },
    l(r) {
      e = Ke(r, "P", { class: !0 });
      var s = Xe(e);
      t = X(
        s,
        /*loading_text*/
        o[9]
      ), s.forEach(R), n = Se(r), l && l.l(r), this.h();
    },
    h() {
      Pe(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      q(r, e, s), wt(e, t), q(r, n, s), l && l.m(r, s), i = !0;
    },
    p(r, s) {
      (!i || s[0] & /*loading_text*/
      512) && Be(
        t,
        /*loading_text*/
        r[9]
      ), l && l.p && (!i || s[0] & /*$$scope*/
      536870912) && Ba(
        l,
        a,
        r,
        /*$$scope*/
        r[29],
        i ? Ta(
          a,
          /*$$scope*/
          r[29],
          s,
          cc
        ) : Sa(
          /*$$scope*/
          r[29]
        ),
        ml
      );
    },
    i(r) {
      i || (Me(l, r), i = !0);
    },
    o(r) {
      Je(l, r), i = !1;
    },
    d(r) {
      r && (R(e), R(n)), l && l.d(r);
    }
  };
}
function wc(o) {
  let e, t, n, i, a;
  const l = [dc, _c], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(o)) && (n = r[t] = l[t](o)), {
    c() {
      e = Qe("div"), n && n.c(), this.h();
    },
    l(u) {
      e = Ke(u, "DIV", { class: !0 });
      var c = Xe(e);
      n && n.l(c), c.forEach(R), this.h();
    },
    h() {
      Pe(e, "class", i = "wrap " + /*variant*/
      o[8] + " " + /*show_progress*/
      o[6] + " svelte-17v219f"), Ce(e, "hide", !/*status*/
      o[4] || /*status*/
      o[4] === "complete" || /*show_progress*/
      o[6] === "hidden" || /*status*/
      o[4] == "streaming"), Ce(
        e,
        "translucent",
        /*variant*/
        o[8] === "center" && /*status*/
        (o[4] === "pending" || /*status*/
        o[4] === "error") || /*translucent*/
        o[11] || /*show_progress*/
        o[6] === "minimal"
      ), Ce(
        e,
        "generating",
        /*status*/
        o[4] === "generating" && /*show_progress*/
        o[6] === "full"
      ), Ce(
        e,
        "border",
        /*border*/
        o[12]
      ), pt(
        e,
        "position",
        /*absolute*/
        o[10] ? "absolute" : "static"
      ), pt(
        e,
        "padding",
        /*absolute*/
        o[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      q(u, e, c), ~t && r[t].m(e, null), o[33](e), a = !0;
    },
    p(u, c) {
      let m = t;
      t = s(u), t === m ? ~t && r[t].p(u, c) : (n && (Vi(), Je(r[m], 1, 1, () => {
        r[m] = null;
      }), ji()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), Me(n, 1), n.m(e, null)) : n = null), (!a || c[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Pe(e, "class", i), (!a || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Ce(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!a || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Ce(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!a || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Ce(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!a || c[0] & /*variant, show_progress, border*/
      4416) && Ce(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && pt(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && pt(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      a || (Me(n), a = !0);
    },
    o(u) {
      Je(n), a = !1;
    },
    d(u) {
      u && R(e), ~t && r[t].d(), o[33](null);
    }
  };
}
var yc = function(o, e, t, n) {
  function i(a) {
    return a instanceof t ? a : new t(function(l) {
      l(a);
    });
  }
  return new (t || (t = Promise))(function(a, l) {
    function r(c) {
      try {
        u(n.next(c));
      } catch (m) {
        l(m);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (m) {
        l(m);
      }
    }
    function u(c) {
      c.done ? a(c.value) : i(c.value).then(r, s);
    }
    u((n = n.apply(o, e || [])).next());
  });
};
let Fn = [], $i = !1;
const Fc = typeof window < "u", Ra = Fc ? window.requestAnimationFrame : (o) => {
};
function $c(o) {
  return yc(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Fn.push(e), !$i) $i = !0;
      else return;
      yield ac(), Ra(() => {
        let n = [0, 0];
        for (let i = 0; i < Fn.length; i++) {
          const l = Fn[i].getBoundingClientRect();
          (i === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), $i = !1, Fn = [];
      });
    }
  });
}
function kc(o, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e;
  const l = sc();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: m } = e, { scroll_to_output: d = !1 } = e, { timer: g = !0 } = e, { show_progress: b = "full" } = e, { message: p = null } = e, { progress: D = null } = e, { variant: $ = "default" } = e, { loading_text: h = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: v = !1 } = e, { border: y = !1 } = e, { autoscroll: w } = e, A, F = !1, S = 0, I = 0, T = null, L = null, Q = 0, j = null, oe, J = null, te = !0;
  const N = () => {
    t(0, s = t(27, T = t(19, E = null))), t(25, S = performance.now()), t(26, I = 0), F = !0, G();
  };
  function G() {
    Ra(() => {
      t(26, I = (performance.now() - S) / 1e3), F && G();
    });
  }
  function ve() {
    t(26, I = 0), t(0, s = t(27, T = t(19, E = null))), F && (F = !1);
  }
  rc(() => {
    F && ve();
  });
  let E = null;
  function ne(C) {
    hl[C ? "unshift" : "push"](() => {
      J = C, t(16, J), t(7, D), t(14, j), t(15, oe);
    });
  }
  const W = () => {
    l("clear_status");
  };
  function re(C) {
    hl[C ? "unshift" : "push"](() => {
      A = C, t(13, A);
    });
  }
  return o.$$set = (C) => {
    "i18n" in C && t(1, r = C.i18n), "eta" in C && t(0, s = C.eta), "queue_position" in C && t(2, u = C.queue_position), "queue_size" in C && t(3, c = C.queue_size), "status" in C && t(4, m = C.status), "scroll_to_output" in C && t(22, d = C.scroll_to_output), "timer" in C && t(5, g = C.timer), "show_progress" in C && t(6, b = C.show_progress), "message" in C && t(23, p = C.message), "progress" in C && t(7, D = C.progress), "variant" in C && t(8, $ = C.variant), "loading_text" in C && t(9, h = C.loading_text), "absolute" in C && t(10, _ = C.absolute), "translucent" in C && t(11, v = C.translucent), "border" in C && t(12, y = C.border), "autoscroll" in C && t(24, w = C.autoscroll), "$$scope" in C && t(29, a = C.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = T), s != null && T !== s && (t(28, L = (performance.now() - S) / 1e3 + s), t(19, E = L.toFixed(1)), t(27, T = s))), o.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, Q = L === null || L <= 0 || !I ? null : Math.min(I / L, 1)), o.$$.dirty[0] & /*progress*/
    128 && D != null && t(18, te = !1), o.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (D != null ? t(14, j = D.map((C) => {
      if (C.index != null && C.length != null)
        return C.index / C.length;
      if (C.progress != null)
        return C.progress;
    })) : t(14, j = null), j ? (t(15, oe = j[j.length - 1]), J && (oe === 0 ? t(16, J.style.transition = "0", J) : t(16, J.style.transition = "150ms", J))) : t(15, oe = void 0)), o.$$.dirty[0] & /*status*/
    16 && (m === "pending" ? N() : ve()), o.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && A && d && (m === "pending" || m === "complete") && $c(A, w), o.$$.dirty[0] & /*status, message*/
    8388624, o.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = I.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    m,
    g,
    b,
    D,
    $,
    h,
    _,
    v,
    y,
    A,
    j,
    oe,
    J,
    Q,
    te,
    E,
    n,
    l,
    d,
    p,
    w,
    S,
    I,
    T,
    L,
    a,
    i,
    ne,
    W,
    re
  ];
}
class Ec extends ic {
  constructor(e) {
    super(), oc(
      this,
      e,
      kc,
      wc,
      lc,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Ia,
  setPrototypeOf: Tl,
  isFrozen: Ac,
  getPrototypeOf: Cc,
  getOwnPropertyDescriptor: Sc
} = Object;
let {
  freeze: me,
  seal: Re,
  create: La
} = Object, {
  apply: Zi,
  construct: Yi
} = typeof Reflect < "u" && Reflect;
me || (me = function(e) {
  return e;
});
Re || (Re = function(e) {
  return e;
});
Zi || (Zi = function(e, t, n) {
  return e.apply(t, n);
});
Yi || (Yi = function(e, t) {
  return new e(...t);
});
const $n = ge(Array.prototype.forEach), Tc = ge(Array.prototype.lastIndexOf), xl = ge(Array.prototype.pop), Yt = ge(Array.prototype.push), xc = ge(Array.prototype.splice), Tn = ge(String.prototype.toLowerCase), ki = ge(String.prototype.toString), Bl = ge(String.prototype.match), Xt = ge(String.prototype.replace), Bc = ge(String.prototype.indexOf), Rc = ge(String.prototype.trim), Ne = ge(Object.prototype.hasOwnProperty), pe = ge(RegExp.prototype.test), Kt = Ic(TypeError);
function ge(o) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
      n[i - 1] = arguments[i];
    return Zi(o, e, n);
  };
}
function Ic(o) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return Yi(o, t);
  };
}
function O(o, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Tn;
  Tl && Tl(o, null);
  let n = e.length;
  for (; n--; ) {
    let i = e[n];
    if (typeof i == "string") {
      const a = t(i);
      a !== i && (Ac(e) || (e[n] = a), i = a);
    }
    o[i] = !0;
  }
  return o;
}
function Lc(o) {
  for (let e = 0; e < o.length; e++)
    Ne(o, e) || (o[e] = null);
  return o;
}
function lt(o) {
  const e = La(null);
  for (const [t, n] of Ia(o))
    Ne(o, t) && (Array.isArray(n) ? e[t] = Lc(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = lt(n) : e[t] = n);
  return e;
}
function Qt(o, e) {
  for (; o !== null; ) {
    const n = Sc(o, e);
    if (n) {
      if (n.get)
        return ge(n.get);
      if (typeof n.value == "function")
        return ge(n.value);
    }
    o = Cc(o);
  }
  function t() {
    return null;
  }
  return t;
}
const Rl = me(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Ei = me(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Ai = me(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), qc = me(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Ci = me(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Oc = me(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Il = me(["#text"]), Ll = me(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Si = me(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), ql = me(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), kn = me(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Nc = Re(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Mc = Re(/<%[\w\W]*|[\w\W]*%>/gm), Pc = Re(/\$\{[\w\W]*/gm), zc = Re(/^data-[\-\w.\u00B7-\uFFFF]+$/), Uc = Re(/^aria-[\-\w]+$/), qa = Re(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Hc = Re(/^(?:\w+script|data):/i), Gc = Re(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Oa = Re(/^html$/i), jc = Re(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ol = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Uc,
  ATTR_WHITESPACE: Gc,
  CUSTOM_ELEMENT: jc,
  DATA_ATTR: zc,
  DOCTYPE_NAME: Oa,
  ERB_EXPR: Mc,
  IS_ALLOWED_URI: qa,
  IS_SCRIPT_OR_DATA: Hc,
  MUSTACHE_EXPR: Nc,
  TMPLIT_EXPR: Pc
});
const Jt = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Vc = function() {
  return typeof window > "u" ? null : window;
}, Wc = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const i = "data-tt-policy-suffix";
  t && t.hasAttribute(i) && (n = t.getAttribute(i));
  const a = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(a, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Nl = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Na() {
  let o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Vc();
  const e = (B) => Na(B);
  if (e.version = "3.2.6", e.removed = [], !o || !o.document || o.document.nodeType !== Jt.document || !o.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = o;
  const n = t, i = n.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: l,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = o.NamedNodeMap || o.MozNamedAttrMap,
    HTMLFormElement: m,
    DOMParser: d,
    trustedTypes: g
  } = o, b = s.prototype, p = Qt(b, "cloneNode"), D = Qt(b, "remove"), $ = Qt(b, "nextSibling"), h = Qt(b, "childNodes"), _ = Qt(b, "parentNode");
  if (typeof l == "function") {
    const B = t.createElement("template");
    B.content && B.content.ownerDocument && (t = B.content.ownerDocument);
  }
  let v, y = "";
  const {
    implementation: w,
    createNodeIterator: A,
    createDocumentFragment: F,
    getElementsByTagName: S
  } = t, {
    importNode: I
  } = n;
  let T = Nl();
  e.isSupported = typeof Ia == "function" && typeof _ == "function" && w && w.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: L,
    ERB_EXPR: Q,
    TMPLIT_EXPR: j,
    DATA_ATTR: oe,
    ARIA_ATTR: J,
    IS_SCRIPT_OR_DATA: te,
    ATTR_WHITESPACE: N,
    CUSTOM_ELEMENT: G
  } = Ol;
  let {
    IS_ALLOWED_URI: ve
  } = Ol, E = null;
  const ne = O({}, [...Rl, ...Ei, ...Ai, ...Ci, ...Il]);
  let W = null;
  const re = O({}, [...Ll, ...Si, ...ql, ...kn]);
  let C = Object.seal(La(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), ke = null, at = null, At = !0, Ct = !0, St = !1, vt = !0, rt = !1, st = !0, bt = !1, Qn = !1, Jn = !1, Tt = !1, sn = !1, un = !1, so = !0, uo = !1;
  const Ja = "user-content-";
  let ei = !0, Gt = !1, xt = {}, Bt = null;
  const co = O({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let _o = null;
  const fo = O({}, ["audio", "video", "img", "source", "image", "track"]);
  let ti = null;
  const ho = O({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), cn = "http://www.w3.org/1998/Math/MathML", _n = "http://www.w3.org/2000/svg", et = "http://www.w3.org/1999/xhtml";
  let Rt = et, ni = !1, ii = null;
  const er = O({}, [cn, _n, et], ki);
  let dn = O({}, ["mi", "mo", "mn", "ms", "mtext"]), fn = O({}, ["annotation-xml"]);
  const tr = O({}, ["title", "style", "font", "a", "script"]);
  let jt = null;
  const nr = ["application/xhtml+xml", "text/html"], ir = "text/html";
  let le = null, It = null;
  const or = t.createElement("form"), po = function(f) {
    return f instanceof RegExp || f instanceof Function;
  }, oi = function() {
    let f = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(It && It === f)) {
      if ((!f || typeof f != "object") && (f = {}), f = lt(f), jt = // eslint-disable-next-line unicorn/prefer-includes
      nr.indexOf(f.PARSER_MEDIA_TYPE) === -1 ? ir : f.PARSER_MEDIA_TYPE, le = jt === "application/xhtml+xml" ? ki : Tn, E = Ne(f, "ALLOWED_TAGS") ? O({}, f.ALLOWED_TAGS, le) : ne, W = Ne(f, "ALLOWED_ATTR") ? O({}, f.ALLOWED_ATTR, le) : re, ii = Ne(f, "ALLOWED_NAMESPACES") ? O({}, f.ALLOWED_NAMESPACES, ki) : er, ti = Ne(f, "ADD_URI_SAFE_ATTR") ? O(lt(ho), f.ADD_URI_SAFE_ATTR, le) : ho, _o = Ne(f, "ADD_DATA_URI_TAGS") ? O(lt(fo), f.ADD_DATA_URI_TAGS, le) : fo, Bt = Ne(f, "FORBID_CONTENTS") ? O({}, f.FORBID_CONTENTS, le) : co, ke = Ne(f, "FORBID_TAGS") ? O({}, f.FORBID_TAGS, le) : lt({}), at = Ne(f, "FORBID_ATTR") ? O({}, f.FORBID_ATTR, le) : lt({}), xt = Ne(f, "USE_PROFILES") ? f.USE_PROFILES : !1, At = f.ALLOW_ARIA_ATTR !== !1, Ct = f.ALLOW_DATA_ATTR !== !1, St = f.ALLOW_UNKNOWN_PROTOCOLS || !1, vt = f.ALLOW_SELF_CLOSE_IN_ATTR !== !1, rt = f.SAFE_FOR_TEMPLATES || !1, st = f.SAFE_FOR_XML !== !1, bt = f.WHOLE_DOCUMENT || !1, Tt = f.RETURN_DOM || !1, sn = f.RETURN_DOM_FRAGMENT || !1, un = f.RETURN_TRUSTED_TYPE || !1, Jn = f.FORCE_BODY || !1, so = f.SANITIZE_DOM !== !1, uo = f.SANITIZE_NAMED_PROPS || !1, ei = f.KEEP_CONTENT !== !1, Gt = f.IN_PLACE || !1, ve = f.ALLOWED_URI_REGEXP || qa, Rt = f.NAMESPACE || et, dn = f.MATHML_TEXT_INTEGRATION_POINTS || dn, fn = f.HTML_INTEGRATION_POINTS || fn, C = f.CUSTOM_ELEMENT_HANDLING || {}, f.CUSTOM_ELEMENT_HANDLING && po(f.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (C.tagNameCheck = f.CUSTOM_ELEMENT_HANDLING.tagNameCheck), f.CUSTOM_ELEMENT_HANDLING && po(f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (C.attributeNameCheck = f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), f.CUSTOM_ELEMENT_HANDLING && typeof f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (C.allowCustomizedBuiltInElements = f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), rt && (Ct = !1), sn && (Tt = !0), xt && (E = O({}, Il), W = [], xt.html === !0 && (O(E, Rl), O(W, Ll)), xt.svg === !0 && (O(E, Ei), O(W, Si), O(W, kn)), xt.svgFilters === !0 && (O(E, Ai), O(W, Si), O(W, kn)), xt.mathMl === !0 && (O(E, Ci), O(W, ql), O(W, kn))), f.ADD_TAGS && (E === ne && (E = lt(E)), O(E, f.ADD_TAGS, le)), f.ADD_ATTR && (W === re && (W = lt(W)), O(W, f.ADD_ATTR, le)), f.ADD_URI_SAFE_ATTR && O(ti, f.ADD_URI_SAFE_ATTR, le), f.FORBID_CONTENTS && (Bt === co && (Bt = lt(Bt)), O(Bt, f.FORBID_CONTENTS, le)), ei && (E["#text"] = !0), bt && O(E, ["html", "head", "body"]), E.table && (O(E, ["tbody"]), delete ke.tbody), f.TRUSTED_TYPES_POLICY) {
        if (typeof f.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Kt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof f.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Kt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        v = f.TRUSTED_TYPES_POLICY, y = v.createHTML("");
      } else
        v === void 0 && (v = Wc(g, i)), v !== null && typeof y == "string" && (y = v.createHTML(""));
      me && me(f), It = f;
    }
  }, mo = O({}, [...Ei, ...Ai, ...qc]), go = O({}, [...Ci, ...Oc]), lr = function(f) {
    let k = _(f);
    (!k || !k.tagName) && (k = {
      namespaceURI: Rt,
      tagName: "template"
    });
    const x = Tn(f.tagName), Z = Tn(k.tagName);
    return ii[f.namespaceURI] ? f.namespaceURI === _n ? k.namespaceURI === et ? x === "svg" : k.namespaceURI === cn ? x === "svg" && (Z === "annotation-xml" || dn[Z]) : !!mo[x] : f.namespaceURI === cn ? k.namespaceURI === et ? x === "math" : k.namespaceURI === _n ? x === "math" && fn[Z] : !!go[x] : f.namespaceURI === et ? k.namespaceURI === _n && !fn[Z] || k.namespaceURI === cn && !dn[Z] ? !1 : !go[x] && (tr[x] || !mo[x]) : !!(jt === "application/xhtml+xml" && ii[f.namespaceURI]) : !1;
  }, ze = function(f) {
    Yt(e.removed, {
      element: f
    });
    try {
      _(f).removeChild(f);
    } catch {
      D(f);
    }
  }, Lt = function(f, k) {
    try {
      Yt(e.removed, {
        attribute: k.getAttributeNode(f),
        from: k
      });
    } catch {
      Yt(e.removed, {
        attribute: null,
        from: k
      });
    }
    if (k.removeAttribute(f), f === "is")
      if (Tt || sn)
        try {
          ze(k);
        } catch {
        }
      else
        try {
          k.setAttribute(f, "");
        } catch {
        }
  }, vo = function(f) {
    let k = null, x = null;
    if (Jn)
      f = "<remove></remove>" + f;
    else {
      const ie = Bl(f, /^[\r\n\t ]+/);
      x = ie && ie[0];
    }
    jt === "application/xhtml+xml" && Rt === et && (f = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + f + "</body></html>");
    const Z = v ? v.createHTML(f) : f;
    if (Rt === et)
      try {
        k = new d().parseFromString(Z, jt);
      } catch {
      }
    if (!k || !k.documentElement) {
      k = w.createDocument(Rt, "template", null);
      try {
        k.documentElement.innerHTML = ni ? y : Z;
      } catch {
      }
    }
    const se = k.body || k.documentElement;
    return f && x && se.insertBefore(t.createTextNode(x), se.childNodes[0] || null), Rt === et ? S.call(k, bt ? "html" : "body")[0] : bt ? k.documentElement : se;
  }, bo = function(f) {
    return A.call(
      f.ownerDocument || f,
      f,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, li = function(f) {
    return f instanceof m && (typeof f.nodeName != "string" || typeof f.textContent != "string" || typeof f.removeChild != "function" || !(f.attributes instanceof c) || typeof f.removeAttribute != "function" || typeof f.setAttribute != "function" || typeof f.namespaceURI != "string" || typeof f.insertBefore != "function" || typeof f.hasChildNodes != "function");
  }, Do = function(f) {
    return typeof r == "function" && f instanceof r;
  };
  function tt(B, f, k) {
    $n(B, (x) => {
      x.call(e, f, k, It);
    });
  }
  const wo = function(f) {
    let k = null;
    if (tt(T.beforeSanitizeElements, f, null), li(f))
      return ze(f), !0;
    const x = le(f.nodeName);
    if (tt(T.uponSanitizeElement, f, {
      tagName: x,
      allowedTags: E
    }), st && f.hasChildNodes() && !Do(f.firstElementChild) && pe(/<[/\w!]/g, f.innerHTML) && pe(/<[/\w!]/g, f.textContent) || f.nodeType === Jt.progressingInstruction || st && f.nodeType === Jt.comment && pe(/<[/\w]/g, f.data))
      return ze(f), !0;
    if (!E[x] || ke[x]) {
      if (!ke[x] && Fo(x) && (C.tagNameCheck instanceof RegExp && pe(C.tagNameCheck, x) || C.tagNameCheck instanceof Function && C.tagNameCheck(x)))
        return !1;
      if (ei && !Bt[x]) {
        const Z = _(f) || f.parentNode, se = h(f) || f.childNodes;
        if (se && Z) {
          const ie = se.length;
          for (let be = ie - 1; be >= 0; --be) {
            const nt = p(se[be], !0);
            nt.__removalCount = (f.__removalCount || 0) + 1, Z.insertBefore(nt, $(f));
          }
        }
      }
      return ze(f), !0;
    }
    return f instanceof s && !lr(f) || (x === "noscript" || x === "noembed" || x === "noframes") && pe(/<\/no(script|embed|frames)/i, f.innerHTML) ? (ze(f), !0) : (rt && f.nodeType === Jt.text && (k = f.textContent, $n([L, Q, j], (Z) => {
      k = Xt(k, Z, " ");
    }), f.textContent !== k && (Yt(e.removed, {
      element: f.cloneNode()
    }), f.textContent = k)), tt(T.afterSanitizeElements, f, null), !1);
  }, yo = function(f, k, x) {
    if (so && (k === "id" || k === "name") && (x in t || x in or))
      return !1;
    if (!(Ct && !at[k] && pe(oe, k))) {
      if (!(At && pe(J, k))) {
        if (!W[k] || at[k]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Fo(f) && (C.tagNameCheck instanceof RegExp && pe(C.tagNameCheck, f) || C.tagNameCheck instanceof Function && C.tagNameCheck(f)) && (C.attributeNameCheck instanceof RegExp && pe(C.attributeNameCheck, k) || C.attributeNameCheck instanceof Function && C.attributeNameCheck(k)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            k === "is" && C.allowCustomizedBuiltInElements && (C.tagNameCheck instanceof RegExp && pe(C.tagNameCheck, x) || C.tagNameCheck instanceof Function && C.tagNameCheck(x)))
          ) return !1;
        } else if (!ti[k]) {
          if (!pe(ve, Xt(x, N, ""))) {
            if (!((k === "src" || k === "xlink:href" || k === "href") && f !== "script" && Bc(x, "data:") === 0 && _o[f])) {
              if (!(St && !pe(te, Xt(x, N, "")))) {
                if (x)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Fo = function(f) {
    return f !== "annotation-xml" && Bl(f, G);
  }, $o = function(f) {
    tt(T.beforeSanitizeAttributes, f, null);
    const {
      attributes: k
    } = f;
    if (!k || li(f))
      return;
    const x = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: W,
      forceKeepAttr: void 0
    };
    let Z = k.length;
    for (; Z--; ) {
      const se = k[Z], {
        name: ie,
        namespaceURI: be,
        value: nt
      } = se, Vt = le(ie), ai = nt;
      let ue = ie === "value" ? ai : Rc(ai);
      if (x.attrName = Vt, x.attrValue = ue, x.keepAttr = !0, x.forceKeepAttr = void 0, tt(T.uponSanitizeAttribute, f, x), ue = x.attrValue, uo && (Vt === "id" || Vt === "name") && (Lt(ie, f), ue = Ja + ue), st && pe(/((--!?|])>)|<\/(style|title)/i, ue)) {
        Lt(ie, f);
        continue;
      }
      if (x.forceKeepAttr)
        continue;
      if (!x.keepAttr) {
        Lt(ie, f);
        continue;
      }
      if (!vt && pe(/\/>/i, ue)) {
        Lt(ie, f);
        continue;
      }
      rt && $n([L, Q, j], (Eo) => {
        ue = Xt(ue, Eo, " ");
      });
      const ko = le(f.nodeName);
      if (!yo(ko, Vt, ue)) {
        Lt(ie, f);
        continue;
      }
      if (v && typeof g == "object" && typeof g.getAttributeType == "function" && !be)
        switch (g.getAttributeType(ko, Vt)) {
          case "TrustedHTML": {
            ue = v.createHTML(ue);
            break;
          }
          case "TrustedScriptURL": {
            ue = v.createScriptURL(ue);
            break;
          }
        }
      if (ue !== ai)
        try {
          be ? f.setAttributeNS(be, ie, ue) : f.setAttribute(ie, ue), li(f) ? ze(f) : xl(e.removed);
        } catch {
          Lt(ie, f);
        }
    }
    tt(T.afterSanitizeAttributes, f, null);
  }, ar = function B(f) {
    let k = null;
    const x = bo(f);
    for (tt(T.beforeSanitizeShadowDOM, f, null); k = x.nextNode(); )
      tt(T.uponSanitizeShadowNode, k, null), wo(k), $o(k), k.content instanceof a && B(k.content);
    tt(T.afterSanitizeShadowDOM, f, null);
  };
  return e.sanitize = function(B) {
    let f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, k = null, x = null, Z = null, se = null;
    if (ni = !B, ni && (B = "<!-->"), typeof B != "string" && !Do(B))
      if (typeof B.toString == "function") {
        if (B = B.toString(), typeof B != "string")
          throw Kt("dirty is not a string, aborting");
      } else
        throw Kt("toString is not a function");
    if (!e.isSupported)
      return B;
    if (Qn || oi(f), e.removed = [], typeof B == "string" && (Gt = !1), Gt) {
      if (B.nodeName) {
        const nt = le(B.nodeName);
        if (!E[nt] || ke[nt])
          throw Kt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (B instanceof r)
      k = vo("<!---->"), x = k.ownerDocument.importNode(B, !0), x.nodeType === Jt.element && x.nodeName === "BODY" || x.nodeName === "HTML" ? k = x : k.appendChild(x);
    else {
      if (!Tt && !rt && !bt && // eslint-disable-next-line unicorn/prefer-includes
      B.indexOf("<") === -1)
        return v && un ? v.createHTML(B) : B;
      if (k = vo(B), !k)
        return Tt ? null : un ? y : "";
    }
    k && Jn && ze(k.firstChild);
    const ie = bo(Gt ? B : k);
    for (; Z = ie.nextNode(); )
      wo(Z), $o(Z), Z.content instanceof a && ar(Z.content);
    if (Gt)
      return B;
    if (Tt) {
      if (sn)
        for (se = F.call(k.ownerDocument); k.firstChild; )
          se.appendChild(k.firstChild);
      else
        se = k;
      return (W.shadowroot || W.shadowrootmode) && (se = I.call(n, se, !0)), se;
    }
    let be = bt ? k.outerHTML : k.innerHTML;
    return bt && E["!doctype"] && k.ownerDocument && k.ownerDocument.doctype && k.ownerDocument.doctype.name && pe(Oa, k.ownerDocument.doctype.name) && (be = "<!DOCTYPE " + k.ownerDocument.doctype.name + `>
` + be), rt && $n([L, Q, j], (nt) => {
      be = Xt(be, nt, " ");
    }), v && un ? v.createHTML(be) : be;
  }, e.setConfig = function() {
    let B = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    oi(B), Qn = !0;
  }, e.clearConfig = function() {
    It = null, Qn = !1;
  }, e.isValidAttribute = function(B, f, k) {
    It || oi({});
    const x = le(B), Z = le(f);
    return yo(x, Z, k);
  }, e.addHook = function(B, f) {
    typeof f == "function" && Yt(T[B], f);
  }, e.removeHook = function(B, f) {
    if (f !== void 0) {
      const k = Tc(T[B], f);
      return k === -1 ? void 0 : xc(T[B], k, 1)[0];
    }
    return xl(T[B]);
  }, e.removeHooks = function(B) {
    T[B] = [];
  }, e.removeAllHooks = function() {
    T = Nl();
  }, e;
}
Na();
const {
  HtmlTagHydration: fA,
  SvelteComponent: hA,
  add_render_callback: pA,
  append_hydration: mA,
  attr: gA,
  bubble: vA,
  check_outros: bA,
  children: DA,
  claim_component: wA,
  claim_element: yA,
  claim_html_tag: FA,
  claim_space: $A,
  claim_text: kA,
  create_component: EA,
  create_in_transition: AA,
  create_out_transition: CA,
  destroy_component: SA,
  detach: TA,
  element: xA,
  get_svelte_dataset: BA,
  group_outros: RA,
  init: IA,
  insert_hydration: LA,
  listen: qA,
  mount_component: OA,
  run_all: NA,
  safe_not_equal: MA,
  set_data: PA,
  space: zA,
  stop_propagation: UA,
  text: HA,
  toggle_class: GA,
  transition_in: jA,
  transition_out: VA
} = window.__gradio__svelte__internal, { createEventDispatcher: WA, onMount: ZA } = window.__gradio__svelte__internal, {
  SvelteComponent: YA,
  append_hydration: XA,
  attr: KA,
  bubble: QA,
  check_outros: JA,
  children: eC,
  claim_component: tC,
  claim_element: nC,
  claim_space: iC,
  create_animation: oC,
  create_component: lC,
  destroy_component: aC,
  detach: rC,
  element: sC,
  ensure_array_like: uC,
  fix_and_outro_and_destroy_block: cC,
  fix_position: _C,
  group_outros: dC,
  init: fC,
  insert_hydration: hC,
  mount_component: pC,
  noop: mC,
  safe_not_equal: gC,
  set_style: vC,
  space: bC,
  transition_in: DC,
  transition_out: wC,
  update_keyed_each: yC
} = window.__gradio__svelte__internal, {
  SvelteComponent: FC,
  attr: $C,
  children: kC,
  claim_element: EC,
  detach: AC,
  element: CC,
  empty: SC,
  init: TC,
  insert_hydration: xC,
  noop: BC,
  safe_not_equal: RC,
  set_style: IC
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zc,
  append_hydration: Ml,
  attr: we,
  children: Ti,
  claim_svg_element: xi,
  detach: En,
  init: Yc,
  insert_hydration: Xc,
  noop: Bi,
  safe_not_equal: Kc,
  svg_element: Ri
} = window.__gradio__svelte__internal;
function Qc(o) {
  let e, t, n;
  return {
    c() {
      e = Ri("svg"), t = Ri("polyline"), n = Ri("line"), this.h();
    },
    l(i) {
      e = xi(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      });
      var a = Ti(e);
      t = xi(a, "polyline", { points: !0 }), Ti(t).forEach(En), n = xi(a, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Ti(n).forEach(En), a.forEach(En), this.h();
    },
    h() {
      we(t, "points", "4 17 10 11 4 5"), we(n, "x1", "12"), we(n, "y1", "19"), we(n, "x2", "20"), we(n, "y2", "19"), we(e, "width", "100%"), we(e, "height", "100%"), we(e, "viewBox", "0 0 24 24"), we(e, "fill", "none"), we(e, "stroke", "currentColor"), we(e, "stroke-width", "2"), we(e, "stroke-linecap", "round"), we(e, "stroke-linejoin", "round");
    },
    m(i, a) {
      Xc(i, e, a), Ml(e, t), Ml(e, n);
    },
    p: Bi,
    i: Bi,
    o: Bi,
    d(i) {
      i && En(e);
    }
  };
}
class Jc extends Zc {
  constructor(e) {
    super(), Yc(this, e, null, Qc, Kc, {});
  }
}
const {
  SvelteComponent: e_,
  claim_component: t_,
  create_component: n_,
  destroy_component: i_,
  init: o_,
  mount_component: l_,
  safe_not_equal: a_,
  transition_in: r_,
  transition_out: s_
} = window.__gradio__svelte__internal, { onDestroy: u_ } = window.__gradio__svelte__internal;
function c_(o) {
  let e, t;
  return e = new jn({
    props: { Icon: (
      /*copied*/
      o[0] ? Qo : el
    ) }
  }), e.$on(
    "click",
    /*handle_copy*/
    o[1]
  ), {
    c() {
      n_(e.$$.fragment);
    },
    l(n) {
      t_(e.$$.fragment, n);
    },
    m(n, i) {
      l_(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*copied*/
      1 && (a.Icon = /*copied*/
      n[0] ? Qo : el), e.$set(a);
    },
    i(n) {
      t || (r_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      s_(e.$$.fragment, n), t = !1;
    },
    d(n) {
      i_(e, n);
    }
  };
}
function __(o, e, t) {
  var n = this && this.__awaiter || function(u, c, m, d) {
    function g(b) {
      return b instanceof m ? b : new m(function(p) {
        p(b);
      });
    }
    return new (m || (m = Promise))(function(b, p) {
      function D(_) {
        try {
          h(d.next(_));
        } catch (v) {
          p(v);
        }
      }
      function $(_) {
        try {
          h(d.throw(_));
        } catch (v) {
          p(v);
        }
      }
      function h(_) {
        _.done ? b(_.value) : g(_.value).then(D, $);
      }
      h((d = d.apply(u, c || [])).next());
    });
  };
  let i = !1, { value: a } = e, l;
  function r() {
    t(0, i = !0), l && clearTimeout(l), l = setTimeout(
      () => {
        t(0, i = !1);
      },
      2e3
    );
  }
  function s() {
    return n(this, void 0, void 0, function* () {
      "clipboard" in navigator && (yield navigator.clipboard.writeText(a), r());
    });
  }
  return u_(() => {
    l && clearTimeout(l);
  }), o.$$set = (u) => {
    "value" in u && t(2, a = u.value);
  }, [i, s, a];
}
class d_ extends e_ {
  constructor(e) {
    super(), o_(this, e, __, c_, a_, { value: 2 });
  }
}
const { setContext: LC, getContext: f_ } = window.__gradio__svelte__internal, h_ = "WORKER_PROXY_CONTEXT_KEY";
function p_() {
  return f_(h_);
}
const m_ = "lite.local";
function g_(o) {
  return o.host === window.location.host || o.host === "localhost:7860" || o.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  o.host === m_;
}
function v_(o, e) {
  const t = e.toLowerCase();
  for (const [n, i] of Object.entries(o))
    if (n.toLowerCase() === t)
      return i;
}
function b_(o) {
  const e = typeof window < "u";
  if (o == null || !e)
    return !1;
  const t = new URL(o, window.location.href);
  return !(!g_(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
const {
  SvelteComponent: D_,
  assign: Ln,
  check_outros: Ma,
  children: Pa,
  claim_element: za,
  compute_rest_props: Pl,
  create_slot: oo,
  detach: Ht,
  element: Ua,
  empty: qn,
  exclude_internal_props: w_,
  get_all_dirty_from_scope: lo,
  get_slot_changes: ao,
  get_spread_update: Ha,
  group_outros: Ga,
  init: y_,
  insert_hydration: Vn,
  listen: ja,
  prevent_default: F_,
  safe_not_equal: $_,
  set_attributes: On,
  set_style: zl,
  toggle_class: Nn,
  transition_in: Ft,
  transition_out: $t,
  update_slot_base: ro
} = window.__gradio__svelte__internal, { createEventDispatcher: k_, onMount: qC } = window.__gradio__svelte__internal;
function E_(o) {
  let e, t, n, i, a;
  const l = (
    /*#slots*/
    o[8].default
  ), r = oo(
    l,
    o,
    /*$$scope*/
    o[7],
    null
  );
  let s = [
    { class: "download-link" },
    { href: (
      /*href*/
      o[0]
    ) },
    {
      target: t = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      o[1]
    ) },
    /*$$restProps*/
    o[6]
  ], u = {};
  for (let c = 0; c < s.length; c += 1)
    u = Ln(u, s[c]);
  return {
    c() {
      e = Ua("a"), r && r.c(), this.h();
    },
    l(c) {
      e = za(c, "A", {
        class: !0,
        href: !0,
        target: !0,
        rel: !0,
        download: !0
      });
      var m = Pa(e);
      r && r.l(m), m.forEach(Ht), this.h();
    },
    h() {
      On(e, u), zl(e, "position", "relative"), Nn(e, "svelte-151nsdd", !0);
    },
    m(c, m) {
      Vn(c, e, m), r && r.m(e, null), n = !0, i || (a = ja(
        e,
        "click",
        /*dispatch*/
        o[3].bind(null, "click")
      ), i = !0);
    },
    p(c, m) {
      r && r.p && (!n || m & /*$$scope*/
      128) && ro(
        r,
        l,
        c,
        /*$$scope*/
        c[7],
        n ? ao(
          l,
          /*$$scope*/
          c[7],
          m,
          null
        ) : lo(
          /*$$scope*/
          c[7]
        ),
        null
      ), On(e, u = Ha(s, [
        { class: "download-link" },
        (!n || m & /*href*/
        1) && { href: (
          /*href*/
          c[0]
        ) },
        { target: t },
        { rel: "noopener noreferrer" },
        (!n || m & /*download*/
        2) && { download: (
          /*download*/
          c[1]
        ) },
        m & /*$$restProps*/
        64 && /*$$restProps*/
        c[6]
      ])), zl(e, "position", "relative"), Nn(e, "svelte-151nsdd", !0);
    },
    i(c) {
      n || (Ft(r, c), n = !0);
    },
    o(c) {
      $t(r, c), n = !1;
    },
    d(c) {
      c && Ht(e), r && r.d(c), i = !1, a();
    }
  };
}
function A_(o) {
  let e, t, n, i;
  const a = [S_, C_], l = [];
  function r(s, u) {
    return (
      /*is_downloading*/
      s[2] ? 0 : 1
    );
  }
  return e = r(o), t = l[e] = a[e](o), {
    c() {
      t.c(), n = qn();
    },
    l(s) {
      t.l(s), n = qn();
    },
    m(s, u) {
      l[e].m(s, u), Vn(s, n, u), i = !0;
    },
    p(s, u) {
      let c = e;
      e = r(s), e === c ? l[e].p(s, u) : (Ga(), $t(l[c], 1, 1, () => {
        l[c] = null;
      }), Ma(), t = l[e], t ? t.p(s, u) : (t = l[e] = a[e](s), t.c()), Ft(t, 1), t.m(n.parentNode, n));
    },
    i(s) {
      i || (Ft(t), i = !0);
    },
    o(s) {
      $t(t), i = !1;
    },
    d(s) {
      s && Ht(n), l[e].d(s);
    }
  };
}
function C_(o) {
  let e, t, n, i;
  const a = (
    /*#slots*/
    o[8].default
  ), l = oo(
    a,
    o,
    /*$$scope*/
    o[7],
    null
  );
  let r = [
    /*$$restProps*/
    o[6],
    { href: (
      /*href*/
      o[0]
    ) }
  ], s = {};
  for (let u = 0; u < r.length; u += 1)
    s = Ln(s, r[u]);
  return {
    c() {
      e = Ua("a"), l && l.c(), this.h();
    },
    l(u) {
      e = za(u, "A", { href: !0 });
      var c = Pa(e);
      l && l.l(c), c.forEach(Ht), this.h();
    },
    h() {
      On(e, s), Nn(e, "svelte-151nsdd", !0);
    },
    m(u, c) {
      Vn(u, e, c), l && l.m(e, null), t = !0, n || (i = ja(e, "click", F_(
        /*wasm_click_handler*/
        o[5]
      )), n = !0);
    },
    p(u, c) {
      l && l.p && (!t || c & /*$$scope*/
      128) && ro(
        l,
        a,
        u,
        /*$$scope*/
        u[7],
        t ? ao(
          a,
          /*$$scope*/
          u[7],
          c,
          null
        ) : lo(
          /*$$scope*/
          u[7]
        ),
        null
      ), On(e, s = Ha(r, [
        c & /*$$restProps*/
        64 && /*$$restProps*/
        u[6],
        (!t || c & /*href*/
        1) && { href: (
          /*href*/
          u[0]
        ) }
      ])), Nn(e, "svelte-151nsdd", !0);
    },
    i(u) {
      t || (Ft(l, u), t = !0);
    },
    o(u) {
      $t(l, u), t = !1;
    },
    d(u) {
      u && Ht(e), l && l.d(u), n = !1, i();
    }
  };
}
function S_(o) {
  let e;
  const t = (
    /*#slots*/
    o[8].default
  ), n = oo(
    t,
    o,
    /*$$scope*/
    o[7],
    null
  );
  return {
    c() {
      n && n.c();
    },
    l(i) {
      n && n.l(i);
    },
    m(i, a) {
      n && n.m(i, a), e = !0;
    },
    p(i, a) {
      n && n.p && (!e || a & /*$$scope*/
      128) && ro(
        n,
        t,
        i,
        /*$$scope*/
        i[7],
        e ? ao(
          t,
          /*$$scope*/
          i[7],
          a,
          null
        ) : lo(
          /*$$scope*/
          i[7]
        ),
        null
      );
    },
    i(i) {
      e || (Ft(n, i), e = !0);
    },
    o(i) {
      $t(n, i), e = !1;
    },
    d(i) {
      n && n.d(i);
    }
  };
}
function T_(o) {
  let e, t, n, i, a;
  const l = [A_, E_], r = [];
  function s(u, c) {
    return c & /*href*/
    1 && (e = null), e == null && (e = !!/*worker_proxy*/
    (u[4] && b_(
      /*href*/
      u[0]
    ))), e ? 0 : 1;
  }
  return t = s(o, -1), n = r[t] = l[t](o), {
    c() {
      n.c(), i = qn();
    },
    l(u) {
      n.l(u), i = qn();
    },
    m(u, c) {
      r[t].m(u, c), Vn(u, i, c), a = !0;
    },
    p(u, [c]) {
      let m = t;
      t = s(u, c), t === m ? r[t].p(u, c) : (Ga(), $t(r[m], 1, 1, () => {
        r[m] = null;
      }), Ma(), n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), Ft(n, 1), n.m(i.parentNode, i));
    },
    i(u) {
      a || (Ft(n), a = !0);
    },
    o(u) {
      $t(n), a = !1;
    },
    d(u) {
      u && Ht(i), r[t].d(u);
    }
  };
}
function x_(o, e, t) {
  const n = ["href", "download"];
  let i = Pl(e, n), { $$slots: a = {}, $$scope: l } = e;
  var r = this && this.__awaiter || function(b, p, D, $) {
    function h(_) {
      return _ instanceof D ? _ : new D(function(v) {
        v(_);
      });
    }
    return new (D || (D = Promise))(function(_, v) {
      function y(F) {
        try {
          A($.next(F));
        } catch (S) {
          v(S);
        }
      }
      function w(F) {
        try {
          A($.throw(F));
        } catch (S) {
          v(S);
        }
      }
      function A(F) {
        F.done ? _(F.value) : h(F.value).then(y, w);
      }
      A(($ = $.apply(b, p || [])).next());
    });
  };
  let { href: s = void 0 } = e, { download: u } = e;
  const c = k_();
  let m = !1;
  const d = p_();
  function g() {
    return r(this, void 0, void 0, function* () {
      if (m)
        return;
      if (c("click"), s == null)
        throw new Error("href is not defined.");
      if (d == null)
        throw new Error("Wasm worker proxy is not available.");
      const p = new URL(s, window.location.href).pathname;
      t(2, m = !0), d.httpRequest({
        method: "GET",
        path: p,
        headers: {},
        query_string: ""
      }).then((D) => {
        if (D.status !== 200)
          throw new Error(`Failed to get file ${p} from the Wasm worker.`);
        const $ = new Blob(
          [D.body],
          {
            type: v_(D.headers, "content-type")
          }
        ), h = URL.createObjectURL($), _ = document.createElement("a");
        _.href = h, _.download = u, _.click(), URL.revokeObjectURL(h);
      }).finally(() => {
        t(2, m = !1);
      });
    });
  }
  return o.$$set = (b) => {
    e = Ln(Ln({}, e), w_(b)), t(6, i = Pl(e, n)), "href" in b && t(0, s = b.href), "download" in b && t(1, u = b.download), "$$scope" in b && t(7, l = b.$$scope);
  }, [
    s,
    u,
    m,
    c,
    d,
    g,
    i,
    l,
    a
  ];
}
class B_ extends D_ {
  constructor(e) {
    super(), y_(this, e, x_, T_, $_, { href: 0, download: 1 });
  }
}
const {
  SvelteComponent: R_,
  claim_component: Va,
  create_component: Wa,
  destroy_component: Za,
  init: I_,
  mount_component: Ya,
  noop: L_,
  safe_not_equal: q_,
  transition_in: Xa,
  transition_out: Ka
} = window.__gradio__svelte__internal;
function O_(o) {
  let e, t;
  return e = new jn({ props: { Icon: bu } }), {
    c() {
      Wa(e.$$.fragment);
    },
    l(n) {
      Va(e.$$.fragment, n);
    },
    m(n, i) {
      Ya(e, n, i), t = !0;
    },
    p: L_,
    i(n) {
      t || (Xa(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ka(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Za(e, n);
    }
  };
}
function N_(o) {
  let e, t;
  return e = new B_({
    props: {
      download: "logs.txt",
      href: (
        /*download_value*/
        o[0]
      ),
      $$slots: { default: [O_] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      Wa(e.$$.fragment);
    },
    l(n) {
      Va(e.$$.fragment, n);
    },
    m(n, i) {
      Ya(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*download_value*/
      1 && (a.href = /*download_value*/
      n[0]), i & /*$$scope*/
      4 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (Xa(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ka(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Za(e, n);
    }
  };
}
function M_(o, e, t) {
  let { value: n } = e, i;
  return o.$$set = (a) => {
    "value" in a && t(1, n = a.value);
  }, o.$$.update = () => {
    o.$$.dirty & /*value*/
    2 && n && t(0, i = URL.createObjectURL(new Blob([n])));
  }, [i, n];
}
class P_ extends R_ {
  constructor(e) {
    super(), I_(this, e, M_, N_, q_, { value: 1 });
  }
}
const {
  SvelteComponent: z_,
  claim_component: U_,
  create_component: H_,
  destroy_component: G_,
  init: j_,
  mount_component: V_,
  noop: W_,
  safe_not_equal: Z_,
  transition_in: Y_,
  transition_out: X_
} = window.__gradio__svelte__internal, { createEventDispatcher: K_ } = window.__gradio__svelte__internal;
function Q_(o) {
  let e, t;
  return e = new jn({ props: { Icon: Au } }), e.$on(
    "click",
    /*click_handler*/
    o[1]
  ), {
    c() {
      H_(e.$$.fragment);
    },
    l(n) {
      U_(e.$$.fragment, n);
    },
    m(n, i) {
      V_(e, n, i), t = !0;
    },
    p: W_,
    i(n) {
      t || (Y_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      X_(e.$$.fragment, n), t = !1;
    },
    d(n) {
      G_(e, n);
    }
  };
}
function J_(o) {
  const e = K_();
  return [e, () => e("click")];
}
class ed extends z_ {
  constructor(e) {
    super(), j_(this, e, J_, Q_, Z_, {});
  }
}
const {
  SvelteComponent: td,
  check_outros: Ii,
  claim_component: Wn,
  claim_space: Ul,
  create_component: Zn,
  destroy_component: Yn,
  detach: Li,
  empty: Hl,
  group_outros: qi,
  init: nd,
  insert_hydration: Oi,
  mount_component: Xn,
  noop: id,
  safe_not_equal: od,
  space: Gl,
  transition_in: ye,
  transition_out: Ve
} = window.__gradio__svelte__internal, { createEventDispatcher: ld } = window.__gradio__svelte__internal;
function jl(o) {
  let e, t;
  return e = new ed({}), e.$on(
    "click",
    /*click_handler*/
    o[5]
  ), {
    c() {
      Zn(e.$$.fragment);
    },
    l(n) {
      Wn(e.$$.fragment, n);
    },
    m(n, i) {
      Xn(e, n, i), t = !0;
    },
    p: id,
    i(n) {
      t || (ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Yn(e, n);
    }
  };
}
function Vl(o) {
  let e, t;
  return e = new d_({ props: { value: (
    /*value*/
    o[0]
  ) } }), {
    c() {
      Zn(e.$$.fragment);
    },
    l(n) {
      Wn(e.$$.fragment, n);
    },
    m(n, i) {
      Xn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*value*/
      1 && (a.value = /*value*/
      n[0]), e.$set(a);
    },
    i(n) {
      t || (ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Yn(e, n);
    }
  };
}
function Wl(o) {
  let e, t;
  return e = new P_({ props: { value: (
    /*value*/
    o[0]
  ) } }), {
    c() {
      Zn(e.$$.fragment);
    },
    l(n) {
      Wn(e.$$.fragment, n);
    },
    m(n, i) {
      Xn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*value*/
      1 && (a.value = /*value*/
      n[0]), e.$set(a);
    },
    i(n) {
      t || (ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Yn(e, n);
    }
  };
}
function ad(o) {
  let e, t, n, i, a = (
    /*show_clear_button*/
    o[3] && jl(o)
  ), l = (
    /*show_copy_button*/
    o[2] && Vl(o)
  ), r = (
    /*show_download_button*/
    o[1] && Wl(o)
  );
  return {
    c() {
      a && a.c(), e = Gl(), l && l.c(), t = Gl(), r && r.c(), n = Hl();
    },
    l(s) {
      a && a.l(s), e = Ul(s), l && l.l(s), t = Ul(s), r && r.l(s), n = Hl();
    },
    m(s, u) {
      a && a.m(s, u), Oi(s, e, u), l && l.m(s, u), Oi(s, t, u), r && r.m(s, u), Oi(s, n, u), i = !0;
    },
    p(s, u) {
      /*show_clear_button*/
      s[3] ? a ? (a.p(s, u), u & /*show_clear_button*/
      8 && ye(a, 1)) : (a = jl(s), a.c(), ye(a, 1), a.m(e.parentNode, e)) : a && (qi(), Ve(a, 1, 1, () => {
        a = null;
      }), Ii()), /*show_copy_button*/
      s[2] ? l ? (l.p(s, u), u & /*show_copy_button*/
      4 && ye(l, 1)) : (l = Vl(s), l.c(), ye(l, 1), l.m(t.parentNode, t)) : l && (qi(), Ve(l, 1, 1, () => {
        l = null;
      }), Ii()), /*show_download_button*/
      s[1] ? r ? (r.p(s, u), u & /*show_download_button*/
      2 && ye(r, 1)) : (r = Wl(s), r.c(), ye(r, 1), r.m(n.parentNode, n)) : r && (qi(), Ve(r, 1, 1, () => {
        r = null;
      }), Ii());
    },
    i(s) {
      i || (ye(a), ye(l), ye(r), i = !0);
    },
    o(s) {
      Ve(a), Ve(l), Ve(r), i = !1;
    },
    d(s) {
      s && (Li(e), Li(t), Li(n)), a && a.d(s), l && l.d(s), r && r.d(s);
    }
  };
}
function rd(o) {
  let e, t;
  return e = new Gu({
    props: {
      $$slots: { default: [ad] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      Zn(e.$$.fragment);
    },
    l(n) {
      Wn(e.$$.fragment, n);
    },
    m(n, i) {
      Xn(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*$$scope, value, show_download_button, show_copy_button, show_clear_button*/
      79 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Yn(e, n);
    }
  };
}
function sd(o, e, t) {
  let { value: n } = e, { show_download_button: i } = e, { show_copy_button: a } = e, { show_clear_button: l } = e;
  const r = ld(), s = () => r("clear");
  return o.$$set = (u) => {
    "value" in u && t(0, n = u.value), "show_download_button" in u && t(1, i = u.show_download_button), "show_copy_button" in u && t(2, a = u.show_copy_button), "show_clear_button" in u && t(3, l = u.show_clear_button);
  }, [
    n,
    i,
    a,
    l,
    r,
    s
  ];
}
class ud extends td {
  constructor(e) {
    super(), nd(this, e, sd, rd, od, {
      value: 0,
      show_download_button: 1,
      show_copy_button: 2,
      show_clear_button: 3
    });
  }
}
const {
  SvelteComponent: cd,
  add_flush_callback: _d,
  append_hydration: P,
  attr: $e,
  bind: dd,
  binding_callbacks: Qa,
  children: de,
  claim_component: fd,
  claim_element: fe,
  claim_space: mt,
  claim_text: Ge,
  create_component: hd,
  destroy_component: pd,
  destroy_each: md,
  detach: ee,
  element: he,
  ensure_array_like: Zl,
  init: gd,
  insert_hydration: Kn,
  mount_component: vd,
  safe_not_equal: bd,
  set_data: Mt,
  set_style: ht,
  space: gt,
  text: je,
  toggle_class: An,
  transition_in: Dd,
  transition_out: wd
} = window.__gradio__svelte__internal, { afterUpdate: yd, createEventDispatcher: Fd } = window.__gradio__svelte__internal, { tick: $d } = window.__gradio__svelte__internal;
function Yl(o, e, t) {
  const n = o.slice();
  return n[21] = e[t], n[23] = t, n;
}
function Xl(o) {
  let e, t = (
    /*i*/
    o[23] + 1 + ""
  ), n;
  return {
    c() {
      e = he("span"), n = je(t), this.h();
    },
    l(i) {
      e = fe(i, "SPAN", { class: !0 });
      var a = de(e);
      n = Ge(a, t), a.forEach(ee), this.h();
    },
    h() {
      $e(e, "class", "line-number svelte-fg67bo");
    },
    m(i, a) {
      Kn(i, e, a), P(e, n);
    },
    d(i) {
      i && ee(e);
    }
  };
}
function Kl(o) {
  let e, t, n, i = (
    /*log*/
    o[21].content + ""
  ), a, l, r, s = (
    /*line_numbers*/
    o[0] && Xl(o)
  );
  return {
    c() {
      e = he("div"), s && s.c(), t = gt(), n = he("pre"), a = je(i), r = gt(), this.h();
    },
    l(u) {
      e = fe(u, "DIV", { class: !0 });
      var c = de(e);
      s && s.l(c), t = mt(c), n = fe(c, "PRE", { class: !0 });
      var m = de(n);
      a = Ge(m, i), m.forEach(ee), r = mt(c), c.forEach(ee), this.h();
    },
    h() {
      $e(n, "class", l = "log-content log-level-" + /*log*/
      o[21].level.toLowerCase() + " svelte-fg67bo"), $e(e, "class", "log-line svelte-fg67bo");
    },
    m(u, c) {
      Kn(u, e, c), s && s.m(e, null), P(e, t), P(e, n), P(n, a), P(e, r);
    },
    p(u, c) {
      /*line_numbers*/
      u[0] ? s || (s = Xl(u), s.c(), s.m(e, t)) : s && (s.d(1), s = null), c & /*log_lines*/
      128 && i !== (i = /*log*/
      u[21].content + "") && Mt(a, i), c & /*log_lines*/
      128 && l !== (l = "log-content log-level-" + /*log*/
      u[21].level.toLowerCase() + " svelte-fg67bo") && $e(n, "class", l);
    },
    d(u) {
      u && ee(e), s && s.d();
    }
  };
}
function Ql(o) {
  let e, t, n, i = (
    /*progress*/
    o[6].desc + ""
  ), a, l, r, s = (
    /*progress*/
    o[6].rate.toFixed(1) + ""
  ), u, c, m, d, g, b, p, D, $ = Math.round(
    /*progress*/
    o[6].percentage
  ) + "", h, _, v, y, w = (
    /*progress*/
    o[6].current + ""
  ), A, F, S = (
    /*progress*/
    o[6].total + ""
  ), I;
  return {
    c() {
      e = he("div"), t = he("div"), n = he("span"), a = je(i), l = gt(), r = he("span"), u = je(s), c = je(" it/s"), m = gt(), d = he("div"), g = he("div"), b = gt(), p = he("div"), D = he("span"), h = je($), _ = je("%"), v = gt(), y = he("span"), A = je(w), F = je(" / "), I = je(S), this.h();
    },
    l(T) {
      e = fe(T, "DIV", { class: !0 });
      var L = de(e);
      t = fe(L, "DIV", { class: !0 });
      var Q = de(t);
      n = fe(Q, "SPAN", {});
      var j = de(n);
      a = Ge(j, i), j.forEach(ee), l = mt(Q), r = fe(Q, "SPAN", {});
      var oe = de(r);
      u = Ge(oe, s), c = Ge(oe, " it/s"), oe.forEach(ee), Q.forEach(ee), m = mt(L), d = fe(L, "DIV", { class: !0 });
      var J = de(d);
      g = fe(J, "DIV", { class: !0, style: !0 }), de(g).forEach(ee), J.forEach(ee), b = mt(L), p = fe(L, "DIV", { class: !0 });
      var te = de(p);
      D = fe(te, "SPAN", {});
      var N = de(D);
      h = Ge(N, $), _ = Ge(N, "%"), N.forEach(ee), v = mt(te), y = fe(te, "SPAN", {});
      var G = de(y);
      A = Ge(G, w), F = Ge(G, " / "), I = Ge(G, S), G.forEach(ee), te.forEach(ee), L.forEach(ee), this.h();
    },
    h() {
      $e(t, "class", "progress-label-top svelte-fg67bo"), $e(g, "class", "progress-bar-fill svelte-fg67bo"), ht(
        g,
        "width",
        /*progress*/
        o[6].percentage.toFixed(1) + "%"
      ), An(
        g,
        "success",
        /*progress*/
        o[6].status === "success"
      ), An(
        g,
        "error",
        /*progress*/
        o[6].status === "error"
      ), $e(d, "class", "progress-bar-background svelte-fg67bo"), $e(p, "class", "progress-label-bottom svelte-fg67bo"), $e(e, "class", "progress-container svelte-fg67bo");
    },
    m(T, L) {
      Kn(T, e, L), P(e, t), P(t, n), P(n, a), P(t, l), P(t, r), P(r, u), P(r, c), P(e, m), P(e, d), P(d, g), P(e, b), P(e, p), P(p, D), P(D, h), P(D, _), P(p, v), P(p, y), P(y, A), P(y, F), P(y, I);
    },
    p(T, L) {
      L & /*progress*/
      64 && i !== (i = /*progress*/
      T[6].desc + "") && Mt(a, i), L & /*progress*/
      64 && s !== (s = /*progress*/
      T[6].rate.toFixed(1) + "") && Mt(u, s), L & /*progress*/
      64 && ht(
        g,
        "width",
        /*progress*/
        T[6].percentage.toFixed(1) + "%"
      ), L & /*progress*/
      64 && An(
        g,
        "success",
        /*progress*/
        T[6].status === "success"
      ), L & /*progress*/
      64 && An(
        g,
        "error",
        /*progress*/
        T[6].status === "error"
      ), L & /*progress*/
      64 && $ !== ($ = Math.round(
        /*progress*/
        T[6].percentage
      ) + "") && Mt(h, $), L & /*progress*/
      64 && w !== (w = /*progress*/
      T[6].current + "") && Mt(A, w), L & /*progress*/
      64 && S !== (S = /*progress*/
      T[6].total + "") && Mt(I, S);
    },
    d(T) {
      T && ee(e);
    }
  };
}
function kd(o) {
  let e, t, n, i, a, l, r, s, u;
  function c(p) {
    o[17](p);
  }
  let m = {
    show_download_button: (
      /*show_download_button*/
      o[3]
    ),
    show_copy_button: (
      /*show_copy_button*/
      o[4]
    ),
    show_clear_button: (
      /*show_clear_button*/
      o[5]
    )
  };
  /*all_logs_as_text*/
  o[9] !== void 0 && (m.value = /*all_logs_as_text*/
  o[9]), i = new ud({ props: m }), Qa.push(() => dd(i, "value", c)), i.$on(
    "clear",
    /*clear_handler*/
    o[18]
  );
  let d = Zl(
    /*log_lines*/
    o[7]
  ), g = [];
  for (let p = 0; p < d.length; p += 1)
    g[p] = Kl(Yl(o, d, p));
  let b = (
    /*progress*/
    o[6].visible && /*display_mode*/
    (o[2] === "full" || /*display_mode*/
    o[2] === "progress") && Ql(o)
  );
  return {
    c() {
      e = he("div"), t = he("div"), n = he("div"), hd(i.$$.fragment), l = gt(), r = he("div");
      for (let p = 0; p < g.length; p += 1)
        g[p].c();
      s = gt(), b && b.c(), this.h();
    },
    l(p) {
      e = fe(p, "DIV", { class: !0 });
      var D = de(e);
      t = fe(D, "DIV", { class: !0 });
      var $ = de(t);
      n = fe($, "DIV", { class: !0 });
      var h = de(n);
      fd(i.$$.fragment, h), h.forEach(ee), l = mt($), r = fe($, "DIV", { class: !0, style: !0 });
      var _ = de(r);
      for (let v = 0; v < g.length; v += 1)
        g[v].l(_);
      _.forEach(ee), $.forEach(ee), s = mt(D), b && b.l(D), D.forEach(ee), this.h();
    },
    h() {
      $e(n, "class", "header svelte-fg67bo"), $e(r, "class", "log-panel svelte-fg67bo"), ht(
        r,
        "background-color",
        /*background_color*/
        o[1]
      ), $e(t, "class", "log-view-container svelte-fg67bo"), ht(
        t,
        "display",
        /*display_mode*/
        o[2] === "progress" ? "none" : "flex"
      ), $e(e, "class", "panel-container svelte-fg67bo"), ht(
        e,
        "height",
        /*height_style*/
        o[10]
      );
    },
    m(p, D) {
      Kn(p, e, D), P(e, t), P(t, n), vd(i, n, null), P(t, l), P(t, r);
      for (let $ = 0; $ < g.length; $ += 1)
        g[$] && g[$].m(r, null);
      o[19](r), P(e, s), b && b.m(e, null), u = !0;
    },
    p(p, [D]) {
      const $ = {};
      if (D & /*show_download_button*/
      8 && ($.show_download_button = /*show_download_button*/
      p[3]), D & /*show_copy_button*/
      16 && ($.show_copy_button = /*show_copy_button*/
      p[4]), D & /*show_clear_button*/
      32 && ($.show_clear_button = /*show_clear_button*/
      p[5]), !a && D & /*all_logs_as_text*/
      512 && (a = !0, $.value = /*all_logs_as_text*/
      p[9], _d(() => a = !1)), i.$set($), D & /*log_lines, line_numbers*/
      129) {
        d = Zl(
          /*log_lines*/
          p[7]
        );
        let h;
        for (h = 0; h < d.length; h += 1) {
          const _ = Yl(p, d, h);
          g[h] ? g[h].p(_, D) : (g[h] = Kl(_), g[h].c(), g[h].m(r, null));
        }
        for (; h < g.length; h += 1)
          g[h].d(1);
        g.length = d.length;
      }
      (!u || D & /*background_color*/
      2) && ht(
        r,
        "background-color",
        /*background_color*/
        p[1]
      ), D & /*display_mode*/
      4 && ht(
        t,
        "display",
        /*display_mode*/
        p[2] === "progress" ? "none" : "flex"
      ), /*progress*/
      p[6].visible && /*display_mode*/
      (p[2] === "full" || /*display_mode*/
      p[2] === "progress") ? b ? b.p(p, D) : (b = Ql(p), b.c(), b.m(e, null)) : b && (b.d(1), b = null), D & /*height_style*/
      1024 && ht(
        e,
        "height",
        /*height_style*/
        p[10]
      );
    },
    i(p) {
      u || (Dd(i.$$.fragment, p), u = !0);
    },
    o(p) {
      wd(i.$$.fragment, p), u = !1;
    },
    d(p) {
      p && ee(e), pd(i), md(g, p), o[19](null), b && b.d();
    }
  };
}
function Ed(o, e, t) {
  var n = this && this.__awaiter || function(F, S, I, T) {
    function L(Q) {
      return Q instanceof I ? Q : new I(function(j) {
        j(Q);
      });
    }
    return new (I || (I = Promise))(function(Q, j) {
      function oe(N) {
        try {
          te(T.next(N));
        } catch (G) {
          j(G);
        }
      }
      function J(N) {
        try {
          te(T.throw(N));
        } catch (G) {
          j(G);
        }
      }
      function te(N) {
        N.done ? Q(N.value) : L(N.value).then(oe, J);
      }
      te((T = T.apply(F, S || [])).next());
    });
  };
  let { value: i = null } = e, { height: a } = e, { autoscroll: l } = e, { line_numbers: r } = e, { background_color: s } = e, { display_mode: u } = e, { show_download_button: c } = e, { show_copy_button: m } = e, { show_clear_button: d } = e;
  const g = Fd();
  let b, p = {
    visible: !0,
    current: 0,
    total: 100,
    desc: "",
    percentage: 0,
    rate: 0,
    status: "running"
  }, D = [], $ = "", h, _ = "Processing...", v;
  yd(() => {
    l && b && u !== "progress" && t(8, b.scrollTop = b.scrollHeight, b);
  });
  function y(F) {
    $ = F, t(9, $), t(12, i), t(16, v), t(20, n), t(7, D), t(15, _), t(2, u), t(6, p);
  }
  const w = () => g("clear");
  function A(F) {
    Qa[F ? "unshift" : "push"](() => {
      b = F, t(8, b);
    });
  }
  return o.$$set = (F) => {
    "value" in F && t(12, i = F.value), "height" in F && t(13, a = F.height), "autoscroll" in F && t(14, l = F.autoscroll), "line_numbers" in F && t(0, r = F.line_numbers), "background_color" in F && t(1, s = F.background_color), "display_mode" in F && t(2, u = F.display_mode), "show_download_button" in F && t(3, c = F.show_download_button), "show_copy_button" in F && t(4, m = F.show_copy_button), "show_clear_button" in F && t(5, d = F.show_clear_button);
  }, o.$$.update = () => {
    o.$$.dirty & /*value, debounceTimeout, log_lines, initial_desc, display_mode, progress*/
    102596 && i !== null && (clearTimeout(v), t(16, v = setTimeout(
      () => n(void 0, void 0, void 0, function* () {
        if (i === null)
          t(7, D = []), t(6, p = {
            visible: !1,
            current: 0,
            total: 100,
            desc: "",
            percentage: 0,
            rate: 0,
            status: "running"
          }), t(9, $ = ""), t(15, _ = "Processing...");
        else if (i) {
          if (Array.isArray(i)) {
            t(7, D = []), t(6, p.visible = !1, p);
            for (const F of i)
              F.type === "log" ? t(7, D = [
                ...D,
                {
                  level: F.level || "INFO",
                  content: F.content
                }
              ]) : F.type === "progress" && (t(6, p.visible = !0, p), t(6, p.current = F.current, p), t(6, p.total = F.total || 100, p), F.current === 0 && F.desc && _ === "Processing..." && t(15, _ = F.desc), t(
                6,
                p.desc = u === "progress" && D.length > 0 ? D[D.length - 1].content : _,
                p
              ), t(6, p.rate = F.rate || 0, p), t(
                6,
                p.percentage = p.total > 0 ? F.current / p.total * 100 : 0,
                p
              ), t(6, p.status = F.status || "running", p));
          } else typeof i == "object" && i.type && (i.type === "log" ? t(7, D = [
            ...D,
            {
              level: i.level || "INFO",
              content: i.content
            }
          ]) : i.type === "progress" && (t(6, p.visible = !0, p), t(6, p.current = i.current, p), t(6, p.total = i.total || 100, p), i.current === 0 && i.desc && _ === "Processing..." && t(15, _ = i.desc), t(
            6,
            p.desc = u === "progress" && D.length > 0 ? D[D.length - 1].content : _,
            p
          ), t(6, p.rate = i.rate || 0, p), t(
            6,
            p.percentage = p.total > 0 ? i.current / p.total * 100 : 0,
            p
          ), t(6, p.status = i.status || "running", p), t(7, D = Array.isArray(i.logs) ? i.logs.map((F) => ({
            level: F.level || "INFO",
            content: F.content
          })) : D)));
          t(9, $ = D.map((F) => F.content).join(`
`));
        }
        yield $d();
      }),
      50
    ))), o.$$.dirty & /*display_mode, progress, height*/
    8260 && (u === "progress" && p.visible ? t(10, h = "auto") : t(10, h = typeof a == "number" ? a + "px" : a));
  }, [
    r,
    s,
    u,
    c,
    m,
    d,
    p,
    D,
    b,
    $,
    h,
    g,
    i,
    a,
    l,
    _,
    v,
    y,
    w,
    A
  ];
}
class Ad extends cd {
  constructor(e) {
    super(), gd(this, e, Ed, kd, bd, {
      value: 12,
      height: 13,
      autoscroll: 14,
      line_numbers: 0,
      background_color: 1,
      display_mode: 2,
      show_download_button: 3,
      show_copy_button: 4,
      show_clear_button: 5
    });
  }
}
const {
  SvelteComponent: Cd,
  attr: Sd,
  check_outros: Td,
  children: xd,
  claim_component: Mn,
  claim_element: Bd,
  claim_space: Jl,
  create_component: Pn,
  destroy_component: zn,
  detach: Un,
  element: Rd,
  group_outros: Id,
  init: Ld,
  insert_hydration: Xi,
  mount_component: Hn,
  safe_not_equal: qd,
  space: ea,
  transition_in: Dt,
  transition_out: zt
} = window.__gradio__svelte__internal;
function ta(o) {
  let e, t, n;
  return t = new Bs({
    props: {
      Icon: Jc,
      show_label: (
        /*show_label*/
        o[9]
      ),
      label: (
        /*label*/
        o[2]
      )
    }
  }), {
    c() {
      e = Rd("div"), Pn(t.$$.fragment), this.h();
    },
    l(i) {
      e = Bd(i, "DIV", { class: !0 });
      var a = xd(e);
      Mn(t.$$.fragment, a), a.forEach(Un), this.h();
    },
    h() {
      Sd(e, "class", "block-label-wrapper svelte-10ojysx");
    },
    m(i, a) {
      Xi(i, e, a), Hn(t, e, null), n = !0;
    },
    p(i, a) {
      const l = {};
      a & /*show_label*/
      512 && (l.show_label = /*show_label*/
      i[9]), a & /*label*/
      4 && (l.label = /*label*/
      i[2]), t.$set(l);
    },
    i(i) {
      n || (Dt(t.$$.fragment, i), n = !0);
    },
    o(i) {
      zt(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && Un(e), zn(t);
    }
  };
}
function Od(o) {
  let e, t, n, i, a, l = (
    /*show_label*/
    o[9] && ta(o)
  );
  return t = new Ec({
    props: {
      loading_status: (
        /*loading_status*/
        o[17]
      ),
      autoscroll: (
        /*gradio*/
        o[0].autoscroll
      ),
      i18n: (
        /*gradio*/
        o[0].i18n
      )
    }
  }), i = new Ad({
    props: {
      value: (
        /*value*/
        o[1]
      ),
      height: (
        /*height*/
        o[3]
      ),
      autoscroll: (
        /*autoscroll*/
        o[4]
      ),
      line_numbers: (
        /*line_numbers*/
        o[5]
      ),
      background_color: (
        /*background_color*/
        o[6]
      ),
      display_mode: (
        /*display_mode*/
        o[7]
      ),
      show_download_button: (
        /*show_download_button*/
        o[10]
      ),
      show_copy_button: (
        /*show_copy_button*/
        o[11]
      ),
      show_clear_button: (
        /*show_clear_button*/
        o[12]
      )
    }
  }), i.$on(
    "clear",
    /*clear_handler*/
    o[18]
  ), {
    c() {
      l && l.c(), e = ea(), Pn(t.$$.fragment), n = ea(), Pn(i.$$.fragment);
    },
    l(r) {
      l && l.l(r), e = Jl(r), Mn(t.$$.fragment, r), n = Jl(r), Mn(i.$$.fragment, r);
    },
    m(r, s) {
      l && l.m(r, s), Xi(r, e, s), Hn(t, r, s), Xi(r, n, s), Hn(i, r, s), a = !0;
    },
    p(r, s) {
      /*show_label*/
      r[9] ? l ? (l.p(r, s), s & /*show_label*/
      512 && Dt(l, 1)) : (l = ta(r), l.c(), Dt(l, 1), l.m(e.parentNode, e)) : l && (Id(), zt(l, 1, 1, () => {
        l = null;
      }), Td());
      const u = {};
      s & /*loading_status*/
      131072 && (u.loading_status = /*loading_status*/
      r[17]), s & /*gradio*/
      1 && (u.autoscroll = /*gradio*/
      r[0].autoscroll), s & /*gradio*/
      1 && (u.i18n = /*gradio*/
      r[0].i18n), t.$set(u);
      const c = {};
      s & /*value*/
      2 && (c.value = /*value*/
      r[1]), s & /*height*/
      8 && (c.height = /*height*/
      r[3]), s & /*autoscroll*/
      16 && (c.autoscroll = /*autoscroll*/
      r[4]), s & /*line_numbers*/
      32 && (c.line_numbers = /*line_numbers*/
      r[5]), s & /*background_color*/
      64 && (c.background_color = /*background_color*/
      r[6]), s & /*display_mode*/
      128 && (c.display_mode = /*display_mode*/
      r[7]), s & /*show_download_button*/
      1024 && (c.show_download_button = /*show_download_button*/
      r[10]), s & /*show_copy_button*/
      2048 && (c.show_copy_button = /*show_copy_button*/
      r[11]), s & /*show_clear_button*/
      4096 && (c.show_clear_button = /*show_clear_button*/
      r[12]), i.$set(c);
    },
    i(r) {
      a || (Dt(l), Dt(t.$$.fragment, r), Dt(i.$$.fragment, r), a = !0);
    },
    o(r) {
      zt(l), zt(t.$$.fragment, r), zt(i.$$.fragment, r), a = !1;
    },
    d(r) {
      r && (Un(e), Un(n)), l && l.d(r), zn(t, r), zn(i, r);
    }
  };
}
function Nd(o) {
  let e, t;
  return e = new kr({
    props: {
      visible: (
        /*visible*/
        o[8]
      ),
      elem_id: (
        /*elem_id*/
        o[13]
      ),
      elem_classes: (
        /*elem_classes*/
        o[14]
      ),
      scale: (
        /*scale*/
        o[15]
      ),
      min_width: (
        /*min_width*/
        o[16]
      ),
      allow_overflow: !1,
      $$slots: { default: [Od] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      Pn(e.$$.fragment);
    },
    l(n) {
      Mn(e.$$.fragment, n);
    },
    m(n, i) {
      Hn(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*visible*/
      256 && (a.visible = /*visible*/
      n[8]), i & /*elem_id*/
      8192 && (a.elem_id = /*elem_id*/
      n[13]), i & /*elem_classes*/
      16384 && (a.elem_classes = /*elem_classes*/
      n[14]), i & /*scale*/
      32768 && (a.scale = /*scale*/
      n[15]), i & /*min_width*/
      65536 && (a.min_width = /*min_width*/
      n[16]), i & /*$$scope, value, height, autoscroll, line_numbers, background_color, display_mode, show_download_button, show_copy_button, show_clear_button, gradio, loading_status, show_label, label*/
      663295 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (Dt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      zt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      zn(e, n);
    }
  };
}
function Md(o, e, t) {
  let { gradio: n } = e, { value: i = null } = e, { label: a } = e, { height: l } = e, { autoscroll: r } = e, { line_numbers: s } = e, { background_color: u } = e, { display_mode: c } = e, { visible: m = !0 } = e, { show_label: d = !0 } = e, { show_download_button: g } = e, { show_copy_button: b } = e, { show_clear_button: p } = e, { elem_id: D = "" } = e, { elem_classes: $ = [] } = e, { scale: h = null } = e, { min_width: _ = void 0 } = e, { loading_status: v } = e;
  const y = () => n.dispatch("clear");
  return o.$$set = (w) => {
    "gradio" in w && t(0, n = w.gradio), "value" in w && t(1, i = w.value), "label" in w && t(2, a = w.label), "height" in w && t(3, l = w.height), "autoscroll" in w && t(4, r = w.autoscroll), "line_numbers" in w && t(5, s = w.line_numbers), "background_color" in w && t(6, u = w.background_color), "display_mode" in w && t(7, c = w.display_mode), "visible" in w && t(8, m = w.visible), "show_label" in w && t(9, d = w.show_label), "show_download_button" in w && t(10, g = w.show_download_button), "show_copy_button" in w && t(11, b = w.show_copy_button), "show_clear_button" in w && t(12, p = w.show_clear_button), "elem_id" in w && t(13, D = w.elem_id), "elem_classes" in w && t(14, $ = w.elem_classes), "scale" in w && t(15, h = w.scale), "min_width" in w && t(16, _ = w.min_width), "loading_status" in w && t(17, v = w.loading_status);
  }, [
    n,
    i,
    a,
    l,
    r,
    s,
    u,
    c,
    m,
    d,
    g,
    b,
    p,
    D,
    $,
    h,
    _,
    v,
    y
  ];
}
class OC extends Cd {
  constructor(e) {
    super(), Ld(this, e, Md, Nd, qd, {
      gradio: 0,
      value: 1,
      label: 2,
      height: 3,
      autoscroll: 4,
      line_numbers: 5,
      background_color: 6,
      display_mode: 7,
      visible: 8,
      show_label: 9,
      show_download_button: 10,
      show_copy_button: 11,
      show_clear_button: 12,
      elem_id: 13,
      elem_classes: 14,
      scale: 15,
      min_width: 16,
      loading_status: 17
    });
  }
}
export {
  OC as default
};
