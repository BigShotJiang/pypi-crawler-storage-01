"""API module for TikTok downloader/uploader"""
