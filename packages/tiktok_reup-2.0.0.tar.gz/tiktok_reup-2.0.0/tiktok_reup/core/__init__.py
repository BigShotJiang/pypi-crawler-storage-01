"""Core module for TikTok downloader/uploader"""
