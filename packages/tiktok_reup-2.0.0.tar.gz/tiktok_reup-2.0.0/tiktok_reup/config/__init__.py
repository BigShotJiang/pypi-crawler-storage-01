"""Config module for TikTok downloader/uploader"""
