def get_notifications(*args, **kwargs):
    return None


def mark_as_read(*args, **kwargs):
    return None


def mark_all_as_read(*args, **kwargs):
    return None
