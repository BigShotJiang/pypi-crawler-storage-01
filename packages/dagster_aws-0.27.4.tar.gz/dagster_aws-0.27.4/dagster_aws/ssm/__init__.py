from dagster_aws.ssm.resources import (
    ParameterStoreResource as ParameterStoreResource,
    ParameterStoreTag as ParameterStoreTag,
    SSMResource as SSMResource,
    parameter_store_resource as parameter_store_resource,
    ssm_resource as ssm_resource,
)
