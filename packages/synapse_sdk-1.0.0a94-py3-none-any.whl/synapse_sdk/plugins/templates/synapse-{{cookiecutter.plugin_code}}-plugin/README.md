# 실행방법

```bash
$ python main.py run --help
```
