<div align="center">

<img width="392" alt="kash"
src="https://github.com/user-attachments/assets/a5d62ae4-17e6-46bb-a9cb-3b6ec8d8d3fe" />

</div>

</div>

{a1_what_is_kash}

{a2_installation}

{a3_getting_started}

{a4_elements}

{a5_tips_for_use_with_other_tools}

<br/>

<div align="center">

⛭

</div>

* * *

*This project was built from
[simple-modern-uv](https://github.com/jlevy/simple-modern-uv).*
