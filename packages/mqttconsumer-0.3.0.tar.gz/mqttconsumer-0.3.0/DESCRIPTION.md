This code facilitates the use of the MQTT protocol in analytics-related applications.
It is based on [Eclipse Paho™ MQTT Python Client](https://github.com/eclipse/paho.mqtt.python).
