from egorovsystem import get_variable, Egorov


print(Egorov["test"])