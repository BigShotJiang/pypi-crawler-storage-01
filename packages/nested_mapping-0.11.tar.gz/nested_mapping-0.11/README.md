# Summary

[![python](https://img.shields.io/badge/python-3.11-purple.svg)](https://www.python.org/)
[![pipeline](https://git.jinr.ru/dagflow-team/nested-mapping/badges/master/pipeline.svg)](https://git.jinr.ru/dagflow-team/nested-mapping/commits/master)
[![coverage report](https://git.jinr.ru/dagflow-team/nested-mapping/badges/master/coverage.svg)](https://git.jinr.ru/dagflow-team/nested-mapping/-/commits/master)
<!--- Uncomment here after adding docs!
[![pages](https://img.shields.io/badge/pages-link-white.svg)](http://dagflow-team.pages.jinr.ru/nested-mapping)
-->

A package to work with nested dictionaries.

# Repositories

- Development/CI: https://git.jinr.ru/dagflow-team/nested-mapping
- Contact/pypi/mirror: https://github.com/dagflow-team/nested-mapping
- PYPI: https://pypi.org/project/nested-mapping
