# torchpathdiffeq

torchpathdiffeq is an adaptive numerical path integrator that parallelizes the numerical integration step evaluations. This repo serves as the path integration backbone for popcornn. torchpathdiffeq is still under construction; those interested in using it can reach out.
