#!/bin/python3

# Copyright 2025, A Baldwin, National Oceanography Centre
#
# This file is part of libflowcam.
#
# libflowcam is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# libflowcam is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with libflowcam.  If not, see <http://www.gnu.org/licenses/>.

'''
sample.py

An interface for image data from the FlowCam sensor
'''

import argparse
import os
import re
import csv
import glob
import struct
import json
from PIL import Image, ImageDraw
import numpy as np
from .utils import to_snake_case


class ROI:
    def __init__(self, roi_reader, fp_dict, src_img, w, h, x, y, index):
        self.__fp_dict = fp_dict
        self.__roi_reader = roi_reader
        self.__src_img = src_img
        self.x = x
        self.y = y
        self.width = w
        self.height = h
        self.index = index

    def __get_image(self):
        self.__roi_reader._aidx += 1
        if self.__src_img not in self.__fp_dict.keys():
            fp = open(self.__src_img, "rb")
            self.__fp_dict[self.__src_img] = {
                "fp": fp,
                "im": Image.open(fp),
                "aidx": self.__roi_reader._aidx
            }
        else:
            self.__fp_dict[self.__src_img]["aidx"] = self.__roi_reader._aidx
        while len(self.__fp_dict.keys()) > 16: # Start culling file pointers at 16
            del_keys = []
            for fp in self.__fp_dict.keys():
                if self.__fp_dict[fp]["aidx"] < (self.__roi_reader._aidx - 8):
                    self.__fp_dict[fp]["im"].close()
                    self.__fp_dict[fp]["fp"].close()
                    del_keys.append(fp)
            for key in del_keys:
                del self.__fp_dict[key]

        shape = [self.x, self.y, self.x + self.width, self.y + self.height]

        #This section is for quickly debugging issues with the decoder
        #img = self.__fp_dict[self.__src_img]["im"]
        #imd = ImageDraw.Draw(img)
        #imd.rectangle(shape, fill = None, outline = "red")
        #return img

        return self.__fp_dict[self.__src_img]["im"].crop(shape)

    image = property(
            fget = __get_image,
            doc = "Dynamically generated image object"
        )

class ROIReader:
    def __to_snake_case_flowcam_preprocess(self, str_in):
        # We might want to do something special in future if a new revision messes up column names
        return to_snake_case(str_in)

    def __init__(self, csv_fp, verbose = False):
        self.__close_csv = False
        self._aidx = 0
        if type(csv_fp) == str:
            csv_fp = open(csv_fp, "r", encoding="iso-8859-1")
            self.__close_csv = True
        sample_path = csv_fp.name
        sample_dir = sample_path[:-len(os.path.basename(sample_path))]
        sample_summary_file = sample_path[:-4] + "_summary.csv"

        if verbose:
            print("Sample directory = " + sample_dir)

        self.csv_data = []
        reader = csv.DictReader(csv_fp, skipinitialspace=True)
        for row in reader:
            csv_data_row = {}
            for key in row:
                csv_data_row[self.__to_snake_case_flowcam_preprocess(key)] = row[key]
            self.csv_data.append(csv_data_row)
        if self.__close_csv:
            csv_fp.close()


        frame_rate = 7.0

        with open(sample_summary_file, "r", encoding="iso-8859-1") as sf_fp:
            for line in sf_fp:
                if "frame rate" in line.lower():
                    fridx = line.lower().index("frame rate")
                    frn = re.sub("[^\d\.]", "", line[fridx + 11:])
                    frame_rate = float(frn)
                    break

        if verbose:
            print("Average frame rate = " + str(frame_rate) + " fps")

        # ['name', 'area_abd_m', 'area_filled_m', 'aspect_ratio', 'average_blue', 'average_green', 'average_red', 'biovolume_cylinder_m', 'biovolume_p_spheroid_m', 'biovolume_sphere_m', 'calibration_factor', 'calibration_image', 'capture_id', 'capture_x_px', 'capture_y_px', 'ch1_area', 'ch1_peak', 'ch1_width', 'ch2_area', 'ch2_peak', 'ch2_width', 'ch2_or_ch1_ratio', 'circle_fit', 'circularity', 'circularity_hu', 'compactness', 'convex_perimeter_m', 'convexity', 'date', 'diameter_abd_m', 'diameter_esd_m', 'diameter_fd_m', 'edge_gradient', 'elapsed_time_s', 'elongation', 'feret_angle_max', 'feret_angle_min', 'fiber_curl', 'fiber_straightness', 'filter_score', 'geodesic_aspect_ratio', 'geodesic_length_m', 'geodesic_thickness_m', 'group_id', 'image_height_px', 'image_width_px', 'intensity', 'length_m', 'particles_per_chain', 'perimeter_m', 'ratio_blue_or_green', 'ratio_red_or_blue', 'ratio_red_or_green', 'roughness', 'sigma_intensity', 'source_image', 'sphere_complement_m', 'sphere_count', 'sphere_unknown_m', 'sphere_volume_m', 'sqrt_circularity', 'sum_intensity', 'symmetry', 'time', 'timestamp', 'transparency', 'uuid', 'volume_abd_m', 'volume_esd_m', 'width_m']

        si_offset = int(self.csv_data[0]["source_image"])
        last_etime = float(self.csv_data[0]["elapsed_time_s"])
        calibration_frames = 1
        calibration_offset_frames = round(last_etime * frame_rate)
        cframe = calibration_offset_frames

        if verbose:
            print("Time to first capture = " + str(int(last_etime * 1000)) + "ms")
            print("Calibration offset frame loss = ~" + str(calibration_offset_frames) + " frames per calibration")

        # This is a HORRIBLE bodge, but neccesary because we're missing an accurate source_image column
        idx = 0
        for csv_row in self.csv_data:
            c_etime = float(csv_row["elapsed_time_s"])
            if c_etime > (last_etime + 0.001):
                offset_frames = round((c_etime - last_etime) * frame_rate)
                if offset_frames > (calibration_offset_frames - 2): # Whenever we have a large skip, it's usually a calibration event - and this means an extra skipped frame!
                    if verbose:
                        print("Skipped " + str(int((c_etime - last_etime) * 1000)) + "ms (~" + str(offset_frames) + " frames) at ROI " + str(idx) + ", assuming recalibration")
                    calibration_frames += 1
                cframe = cframe + offset_frames
                last_etime = c_etime
            csv_row["rawfile_index"] = cframe - calibration_frames
            idx += 1



        cal_images = glob.glob(sample_dir + "cal_image_*.tif")

        if verbose:
            print("Detected " + str(calibration_frames) + " calibration events and " + str(len(cal_images)) + " calibration images")
        if calibration_frames == len(cal_images):
            if verbose:
                print("As calibration event count matches image count we likely have good synchronisation, continuing")
        else:
            raise IndexError("Could not establish stable frame timings! - This is likely an issue with your data")

        self.__fp_dict = {}

        self.rois = []
        roi_index = 1
        for csv_row in self.csv_data:
            if int(csv_row["image_width_px"].split(".")[0]) != 0:
                source_image_index = csv_row["rawfile_index"]
                source_image = sample_dir + "rawfile_" + str(source_image_index).zfill(6) + ".tif"
                roi_def = ROI(self, self.__fp_dict, source_image, int(csv_row["image_width_px"].split(".")[0]), int(csv_row["image_height_px"].split(".")[0]), int(csv_row["capture_x_px"].split(".")[0]), int(csv_row["capture_y_px"].split(".")[0]), roi_index)
                self.rois.append(roi_def)
            roi_index += 1
