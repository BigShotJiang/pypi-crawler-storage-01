## cdf 

### Added

- [alpha] The command `cdf profile assets/asset-centric` now has an
interactive selection option.

## templates

No changes.