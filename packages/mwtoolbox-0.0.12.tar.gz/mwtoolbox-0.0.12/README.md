# Project Description

Current version = "0.0.12"

MWTOOLBOX is a library for general processing of multiport RF/Microwave networks. Detailed documentation is at [https://terdol.github.io/mwtoolboxdoc](https://terdol.github.io/mwtoolboxdoc).

API documentation is at [https://terdol.github.io/apidoc](https://terdol.github.io/apidoc).

Source code is available at: [https://github.com/terdol/microwave_toolbox](https://github.com/terdol/microwave_toolbox).
