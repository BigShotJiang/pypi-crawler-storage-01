"""
mwtoolbox

An python library for processing of RF/Microwave networks.
"""

__version__ = "0.0.12"
__author__ = 'Tuncay Erdöl'
