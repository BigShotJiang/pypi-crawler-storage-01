"""
AWS SNS Verifier based on the official documentation:
https://docs.aws.amazon.com/sns/latest/dg/sns-verify-signature-of-message.html

"""
