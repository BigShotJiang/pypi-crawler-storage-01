from .cli.main import run_app

run_app(prog_name="tamp")
