"""Lamin CLI."""

__version__ = "1.6.1"
