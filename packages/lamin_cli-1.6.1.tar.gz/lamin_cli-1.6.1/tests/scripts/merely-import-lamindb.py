import lamindb as ln

if __name__ == "__main__":
    print("hello!")
