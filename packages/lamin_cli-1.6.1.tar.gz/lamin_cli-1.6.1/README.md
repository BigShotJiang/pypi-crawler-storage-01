# Lamin CLI

The CLI that exposes `lamindb` and `lamindb_setup` to the command line.
