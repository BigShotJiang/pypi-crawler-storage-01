# coding: utf-8

# Число дней, после которых необходимо обновить message_id для
# потребителя
CHANGE_MESSAGE_ID_IN_DAYS = 1
