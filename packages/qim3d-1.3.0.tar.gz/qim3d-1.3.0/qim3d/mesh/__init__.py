from ._common_mesh_methods import from_volume

__all__ = [
    'from_volume',
]