# atomic-mcp
Building MCPs on the atomic agent framework
