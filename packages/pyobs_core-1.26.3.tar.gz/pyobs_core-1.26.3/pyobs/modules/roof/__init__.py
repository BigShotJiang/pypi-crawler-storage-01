"""
Modules for roofs.
TODO: write doc
"""

__title__ = "Roofs"

from .baseroof import BaseRoof
from .dummyroof import DummyRoof
from .basedome import BaseDome
