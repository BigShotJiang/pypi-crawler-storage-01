class PixelOffsets:
    def __init__(self, dx: float = 0, dy: float = 0):
        self.dx = dx
        self.dy = dy


__all__ = ["PixelOffsets"]
