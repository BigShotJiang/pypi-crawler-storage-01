from enum import Enum


class Backend(Enum):
    NUMPYRO = 1
    PROVIDED = 2
