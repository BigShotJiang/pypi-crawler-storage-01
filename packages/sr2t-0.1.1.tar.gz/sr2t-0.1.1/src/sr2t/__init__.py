# SPDX-FileCopyrightText: 2019-present Guido Kroon <gkroon@maelstrom.ninja>
#
# SPDX-License-Identifier: GPL-3.0-only
