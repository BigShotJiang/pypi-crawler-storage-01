To use this module, you need to:

#. Create a VAT Statement.
#. Post the VAT Statement: a new tab VAT Statement Extended will be displayed; the tab contains the lines of the German VAT Statement report extended by a separated statement for the Intra-Community transactions declaration (Zusammenfassende Meldung).
#. In tab Zusammenfassende Meldung press the Update button in order to recompute the  statement lines for this report.
#. The values for product deliveries and services are separated in two columns.
#. If you want to transmit the values to the official report form, f.e. by "www.elster.de" you would have to enter two lines if both columns product + services contains values.

Printing a PDF report:

#. If you need to print the report in PDF, open a statement form and click: `Print -> Zusammenfassende Meldung`
