To install this module, you need to:

#. Install module *l10n_de_tax_statement* version >= *11.0.1.0.0*.
