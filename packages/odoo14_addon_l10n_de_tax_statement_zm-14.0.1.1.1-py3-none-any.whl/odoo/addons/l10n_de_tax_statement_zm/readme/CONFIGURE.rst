To configure this module, you need to:

#. Follow the configuration steps as described in *l10n_de_tax_statement* and set the tags *Ust-VA KZ 41* and *Ust-VA KZ 21* needed for this report.
