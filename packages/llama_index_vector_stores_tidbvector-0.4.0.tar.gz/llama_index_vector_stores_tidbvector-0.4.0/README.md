# LlamaIndex Vector-Stores Integration: Tidbvector
