# 这是一个适配原有conftest的文件，重定向到新的插件入口
# 保留此文件是为了向后兼容

from pytest_dsl.plugin import *
