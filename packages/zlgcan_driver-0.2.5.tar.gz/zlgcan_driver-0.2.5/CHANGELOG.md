Version 0.2.5
=============

Features
--------

* 项目管理部署改用uv
* 新增`USBCANFD-400U`支持


Version 0.2.4
=============

Bug Fixes
---------

* 修复v0.2.x 引入的USBCANFD-200U高版本硬件打开通道失败


Version 0.2.1
=============

Features
--------

* 更改库文件配置方式

Bug Fixes
---------

* 修复v0.2.0 Windows下不能接收CAN报文的Bug
