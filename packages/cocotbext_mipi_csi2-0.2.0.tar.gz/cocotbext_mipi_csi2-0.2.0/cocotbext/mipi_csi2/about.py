"""
Version information for cocotbext-csi2
"""

__version__ = "0.2.0"
__author__ = "CSI-2 Extension Contributors"
__email__ = "contributors@cocotbext-csi2.org"
__license__ = "MIT"
__copyright__ = "Copyright (c) 2024 CSI-2 Extension Contributors"