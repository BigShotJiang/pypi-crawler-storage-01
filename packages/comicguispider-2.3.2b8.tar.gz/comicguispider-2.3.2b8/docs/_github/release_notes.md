
> [!Warning]  
> 由于绿色包内部执行已更改为 `uv tool`，旧版本绿色包需删掉后使用新版本，无论win还是mac

## 🎁 Feat

✅ 已打包上传至 pypi ，可使用 uv tool 管理/运行 CGS [查看细则](https://jasoneri.github.io/ComicGUISpider/deploy/quick-start)  

## 🐞 Fix

✅ kemono域名更换  
