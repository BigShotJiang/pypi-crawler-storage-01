"""MKTMP - Command-line tool for creating temporary directories with symbolic links."""
