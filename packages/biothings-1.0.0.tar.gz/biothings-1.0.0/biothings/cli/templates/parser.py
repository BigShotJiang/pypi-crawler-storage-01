def load_data(data_folder):
    pass
