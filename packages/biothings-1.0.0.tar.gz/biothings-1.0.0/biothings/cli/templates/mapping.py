def custom_mapping(cls):
    return {
        "root_field": {
            "properties": {
                "subfield": {
                    "type": "text",
                }
            }
        }
    }
