# An empty data plugin template

This plugin is created by using `biothings-cli` command.
Example:

```shell
biothings-cli dataplugin create --name test --parallelizer
```

Use `biothings-cli dataplugin create --help` for more detail
