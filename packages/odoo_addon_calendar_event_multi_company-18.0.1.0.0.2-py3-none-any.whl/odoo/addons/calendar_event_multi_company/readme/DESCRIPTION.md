This module add multi-company management to calendar events
