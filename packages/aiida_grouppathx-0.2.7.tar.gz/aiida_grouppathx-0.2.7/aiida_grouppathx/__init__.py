"""
aiida_grouppathx

AiiDA plugin provides the GroupPathX class
"""

from aiida_grouppathx.launch_manager import *
from aiida_grouppathx.pathx import *

__version__ = '0.2.7'
