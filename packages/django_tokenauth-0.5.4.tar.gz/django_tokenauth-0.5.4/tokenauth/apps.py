from django.apps import AppConfig


class TokenauthConfig(AppConfig):
    name = "tokenauth"
