class AwsCloudObjectProviderException(Exception):
    pass
