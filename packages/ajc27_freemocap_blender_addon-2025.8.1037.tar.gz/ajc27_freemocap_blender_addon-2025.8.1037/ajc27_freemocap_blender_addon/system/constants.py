# Armature names
FREEMOCAP_ARMATURE = "armature_freemocap"
UE_METAHUMAN_SIMPLE_ARMATURE = "armature_ue_metahuman_simple"
# Pose names
FREEMOCAP_TPOSE = "freemocap_tpose"
FREEMOCAP_APOSE = "freemocap_apose"
UE_METAHUMAN_DEFAULT = "ue_metahuman_default"
UE_METAHUMAN_TPOSE = "ue_metahuman_tpose"