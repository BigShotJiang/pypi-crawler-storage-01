ROOT_BONE_NAME = "root_bone"
