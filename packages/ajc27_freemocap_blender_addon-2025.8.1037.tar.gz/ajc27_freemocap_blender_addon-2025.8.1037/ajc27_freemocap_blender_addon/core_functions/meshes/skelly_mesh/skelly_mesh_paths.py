from ajc27_freemocap_blender_addon import PACKAGE_ROOT_PATH
from pathlib import Path
SKELLY_MESH_PATH = str(Path(PACKAGE_ROOT_PATH) / "assets" / "skelly_lowpoly_mesh.fbx")
SKELLY_BONES_PATH = str(Path(PACKAGE_ROOT_PATH) / "assets" / "skelly_bones")
SKELLY_FULL_MESH_PATH = str(Path(PACKAGE_ROOT_PATH) / "assets" / "skelly_full_mesh_20k_faces.blend")
