from enum import Enum


class AddRigMethods(Enum):
    RIGIFY = "rigify"
    BY_BONE = "by_bone"
