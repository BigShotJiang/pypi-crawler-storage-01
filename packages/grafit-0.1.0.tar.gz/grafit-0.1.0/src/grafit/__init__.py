"""GraFIT - Import Garmin FIT files into SQLite database."""

__version__ = "0.1.0"
