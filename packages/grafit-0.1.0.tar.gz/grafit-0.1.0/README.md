# GraFIT

Visualize your FIT files in Grafana