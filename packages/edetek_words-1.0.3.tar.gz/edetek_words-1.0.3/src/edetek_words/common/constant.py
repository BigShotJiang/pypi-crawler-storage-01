# !/usr/bin/python3
# -*- coding:utf-8 -*-
"""
@Author: xiaodong.li
@Time: 7/30/2025 10:02 AM
@Description: Description
@File: constant.py
"""
EN_US = "en_US"
