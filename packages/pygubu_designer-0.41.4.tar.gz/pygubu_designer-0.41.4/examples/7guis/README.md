# 7GUIs

Examples based on site [7GUIs](https://eugenkiss.github.io/7guis/tasks)
