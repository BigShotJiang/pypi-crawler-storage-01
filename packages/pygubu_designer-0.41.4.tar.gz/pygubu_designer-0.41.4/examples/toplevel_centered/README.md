# Toplevel Centered on screen

Shows howto center a toplevel window on screen.

For configurations with multiple monitors see screeninfo package on pypi.
