# Simple pygubu application integration with py2exe

Install py2exe:

```bash
pip install py2exe
```

Create your setup.py similar to the provided by the example.

Note: tested with py2exe version 0.11.1

Build executable

```bash
python setup.py py2exe
```
