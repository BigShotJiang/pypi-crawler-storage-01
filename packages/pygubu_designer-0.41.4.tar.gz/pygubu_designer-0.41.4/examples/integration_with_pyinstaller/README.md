# Simple pygubu application integration with pyinstaller

Install pyinstaller:

```bash
pip install pyinstaller
```

Create your spec file (myapp.spec), similar to the provided by the example.

Note: tested with pyinstaller version 4.10

Build executable

```bash
pyinstaller myapp.spec
```
