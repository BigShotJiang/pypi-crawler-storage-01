# Pygubu Dialog Example

Shows howto use the pygubu Dialog widget class.
