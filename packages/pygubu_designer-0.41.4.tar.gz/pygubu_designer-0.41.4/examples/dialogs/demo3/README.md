# Pygubu Dialog Example

Advanced level example. Uses Threads to run multiple dialogs with tasks.
