# Simple pygubu application integration with cxFreeze

Install cxFreeze:

```bash
pip install cxFreeze
```

Create your setup.py similar to the provided by the example.

Note: tested with cxFreeze version 6.10

Build executable

```bash
python setup.py build
```

Build single installer on Windows

```bash
python setup.py bdist_msi
```
