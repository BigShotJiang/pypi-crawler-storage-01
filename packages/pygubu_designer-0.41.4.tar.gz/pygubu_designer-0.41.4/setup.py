#!/usr/bin/env python3
from setuptools import setup

setup()
