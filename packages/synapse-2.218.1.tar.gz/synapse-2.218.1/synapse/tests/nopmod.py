'''
A python module used for testing dmon dynamic module loading.
'''
