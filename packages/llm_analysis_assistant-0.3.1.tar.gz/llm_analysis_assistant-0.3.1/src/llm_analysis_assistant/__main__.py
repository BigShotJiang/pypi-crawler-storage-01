# __main__.py

from llm_analysis_assistant.server import main

if __name__ == '__main__':
    main()
