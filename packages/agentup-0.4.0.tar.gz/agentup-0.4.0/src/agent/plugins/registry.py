"""
Plugin registry module - placeholder for future plugin management.

This module currently serves as a placeholder. All plugin configuration
and management is handled through explicit configuration in agentup.yml.
"""

# This file is intentionally minimal.
# Plugin management is handled through configuration, not code.
