# Python Unfolded Circle Library

This is a library to interact with the unfolded circle devices. More detail to follow