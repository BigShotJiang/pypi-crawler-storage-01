# Sociable Bot

This is a package used by bots on Sociable.

Learn how to make bots:
https://docs.sociable.bot
