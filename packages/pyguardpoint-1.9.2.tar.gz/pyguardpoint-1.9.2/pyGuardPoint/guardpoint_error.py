class GuardPointError(Exception):
    pass

class GuardPointUnauthorized(Exception):
    pass



