class SystemdNotAvailable(AssertionError):
    pass


class SystemdServiceError(RuntimeError):
    pass
