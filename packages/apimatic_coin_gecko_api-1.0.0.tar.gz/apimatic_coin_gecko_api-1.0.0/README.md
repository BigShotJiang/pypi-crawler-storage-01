
# Getting Started with CoinGecko Public API V3

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install apimatic-coin-gecko-api==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/apimatic-coin-gecko-api/1.0.0

## Test the SDK

You can test the generated SDK and the server with test cases. `unittest` is used as the testing framework and `pytest` is used as the test runner. You can run the tests as follows:

Navigate to the root directory of the SDK and run the following commands

```
pip install -r test-requirements.txt
pytest
```

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| http_client_instance | `HttpClient` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT']** |
| api_key_auth_credentials | [`ApiKeyAuthCredentials`](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/auth/custom-header-signature.md) | The credential object for Custom Header Signature |
| api_key_query_param_credentials | [`ApiKeyQueryParamCredentials`](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/auth/custom-query-parameter.md) | The credential object for Custom Query Parameter |

The API client can be initialized as follows:

```python
from coingeckopublicapiv3.coingeckopublicapiv_3_client import Coingeckopublicapiv3Client
from coingeckopublicapiv3.configuration import Environment
from coingeckopublicapiv3.http.auth.api_key_auth import ApiKeyAuthCredentials
from coingeckopublicapiv3.http.auth.api_key_query_param import ApiKeyQueryParamCredentials

client = Coingeckopublicapiv3Client(
    api_key_auth_credentials=ApiKeyAuthCredentials(
        x_cg_demo_api_key='x-cg-demo-api-key'
    ),
    api_key_query_param_credentials=ApiKeyQueryParamCredentials(
        x_cg_demo_api_key='x_cg_demo_api_key'
    ),
    environment=Environment.PRODUCTION
)
```

## Authorization

This API uses the following authentication schemes.

* [`apiKeyAuth (Custom Header Signature)`](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/auth/custom-header-signature.md)
* [`apiKeyQueryParam (Custom Query Parameter)`](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/auth/custom-query-parameter.md)

## List of APIs

* [Asset Platforms](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/asset-platforms.md)
* [NF Ts Beta](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/nf-ts-beta.md)
* [Exchange Rates](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/exchange-rates.md)
* [Companies Beta](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/companies-beta.md)
* [Ping](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/ping.md)
* [Simple](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/simple.md)
* [Coins](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/coins.md)
* [Contract](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/contract.md)
* [Categories](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/categories.md)
* [Exchanges](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/exchanges.md)
* [Derivatives](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/derivatives.md)
* [Search](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/search.md)
* [Trending](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/trending.md)
* [Global](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/controllers/global.md)

## SDK Infrastructure

### HTTP

* [HttpResponse](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/http-response.md)
* [HttpRequest](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/http-request.md)

### Utilities

* [ApiHelper](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/MuHamza30/coin-gecko-pythonsdk/tree/1.0.0/doc/unix-date-time.md)

