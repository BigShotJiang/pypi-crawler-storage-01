class BcfObject:
    def __init__(self, file_name, line_no):
        self.file_name = file_name
        self.line_no = line_no
