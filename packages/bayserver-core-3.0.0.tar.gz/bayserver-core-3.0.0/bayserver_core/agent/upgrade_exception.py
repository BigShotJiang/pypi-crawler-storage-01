class UpgradeException(IOError):
    pass