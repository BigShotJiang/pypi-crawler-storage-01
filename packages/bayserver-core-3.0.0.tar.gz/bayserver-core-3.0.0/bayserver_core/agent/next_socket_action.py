class NextSocketAction:
    CONTINUE = 1
    SUSPEND = 2
    READ = 3
    WRITE = 4
    CLOSE = 5