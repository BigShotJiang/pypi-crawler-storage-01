from typing import Callable

DataConsumeListener = Callable[[], None]