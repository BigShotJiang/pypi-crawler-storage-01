from enum import IntEnum

class CubeType(IntEnum):

    R = 12,
    G = 13,
    B = 14,
    Y = 15,
    V = 16,


