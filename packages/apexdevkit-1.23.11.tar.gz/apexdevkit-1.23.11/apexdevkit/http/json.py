from typing import Any

from apexdevkit.fluent import FluentDict

JsonDict = FluentDict[Any]
