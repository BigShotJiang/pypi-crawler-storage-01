"""
Rendering system components for camera and visual output.
"""

from .camera import Camera

__all__ = [
    'Camera'
] 