"""
Input handling system for keyboard, mouse, and joystick input.
"""

from .input import Input

__all__ = [
    'Input'
] 