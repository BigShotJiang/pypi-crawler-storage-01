__all__ = [
    'DOMAIN_FACTORY'
]

from .configuration import DOMAIN_FACTORY
