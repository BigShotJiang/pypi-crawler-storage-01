from talisman_api import version
from ._abstract import TalismanDomainAPIImpl


@version('0.14.10')
class _ImplV10(TalismanDomainAPIImpl):
    pass
