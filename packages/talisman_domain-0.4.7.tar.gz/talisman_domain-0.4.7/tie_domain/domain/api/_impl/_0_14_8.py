from talisman_api import version
from ._abstract import TalismanDomainAPIImpl


@version('0.14.8')
class _ImplV8(TalismanDomainAPIImpl):
    pass
