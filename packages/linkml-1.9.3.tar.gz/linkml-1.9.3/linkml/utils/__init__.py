from linkml.utils.deprecation import deprecation_warning

__all__ = ["deprecation_warning"]
