from linkml.cli.main import linkml as cli

if __name__ == "__main__":
    cli()
