"""Word MCP Server package for manipulating Word documents."""

__version__ = "0.1.0"