_enum_title_class_label
=======================

.. exercise:: Test exercise directive
	:class: test-exc
	:label: test-exc-label

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
