
from setuptools import setup

setup(package_data={'jack-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
