# 请复制函数名到名单中。https://akshare.akfamily.xyz/data/index.html

# 白名单
white_list = [
    "stock_zh_index_spot_em",
    "index_global_spot_em",
    "stock_zh_a_spot_em",
    "stock_yjbb_em",
    "stock_zt_pool_em",
]

# 黑名单
black_list = [
    "car_market_total_cpca",
]

# 打印当前配置文件路径
print('current config:', __file__)
