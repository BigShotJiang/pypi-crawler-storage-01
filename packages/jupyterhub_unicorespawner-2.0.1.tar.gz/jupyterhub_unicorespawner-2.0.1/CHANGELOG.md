## 2.0.1 (2025-07-29)

Use aiohttp instead of requests

## 2.0.0 (2025-07-11)
Support JupyterHub >= 5.0.0

## 1.1.2 (2025-03-21)

No changes.

## 1.1.1 (2025-02-24)

No changes.

## 1.1.0 (2025-02-20)

No changes.

## 1.0.3 (2024-11-08)

No changes.

## 1.0.2 (2024-11-07)

No changes.

## 1.0.1 (2024-11-07)

No changes.

## 1.0.0 (2024-04-22)

### added (1 change)

- [Resolve "Create Version 1.0.0"](jupyterjsc/packages/jupyterhub-unicorespawner@86ffa77e6903426f2650f439a48b4506d3c359a1) ([merge request](jupyterjsc/packages/jupyterhub-unicorespawner!1))
