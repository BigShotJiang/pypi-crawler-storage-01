class sdkinfo:
  def __init__(self):
    self.identifier = "cuda"
    self.architecture = "cuda"
    #self.c_compiler = "clang"
    #self.cxx_compiler = "clang++"
    self.supports_host = ["x86_64-linux","aarch64-linux"]

