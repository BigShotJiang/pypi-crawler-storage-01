#!/usr/bin/env sh
sudo apt install debhelper-compat findutils git libasound2-dev libavcodec-dev libavfilter-dev libavformat-dev libdbus-1-dev libbluetooth-dev libglib2.0-dev libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev libsbc-dev libsdl2-dev libudev-dev libva-dev libv4l-dev libx11-dev meson ninja-build pkg-config python3-docutils systemd

