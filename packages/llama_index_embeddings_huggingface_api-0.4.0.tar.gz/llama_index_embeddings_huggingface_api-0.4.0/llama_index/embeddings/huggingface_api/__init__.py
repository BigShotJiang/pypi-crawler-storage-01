from llama_index.embeddings.huggingface_api.base import (
    HuggingFaceInferenceAPIEmbedding,
)

__all__ = [
    "HuggingFaceInferenceAPIEmbedding",
]
