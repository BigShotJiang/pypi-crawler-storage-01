This module allows you to send invoices to Voxel. Sending are queued in
jobs running in the background.
