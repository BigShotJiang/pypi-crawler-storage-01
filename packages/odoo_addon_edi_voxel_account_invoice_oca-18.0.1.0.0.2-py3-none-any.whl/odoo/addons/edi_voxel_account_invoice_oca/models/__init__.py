# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import account_move
from . import res_company
from . import res_config_settings
