# PyPI pythonic-fp namespace stub project

**WARNING: DO NOT INSTALL THIS PACKAGE**

It is an empty module whose purpose is to claim the`pythonic-fp` name on
PyPI. This name is used by the Pythonic FP namespace projects, a PyPI
family of packages all under the `pythonic-fp` namespace. This family
supports a functional style of programming which still endeavors to
remain Pythonic.

If this project is installed, the rest of the namespace projects will no
longer work.
