from . import test_path

__name__ == '__main__' and test_path.build_alpharep_fixture().extractall('alpharep')
