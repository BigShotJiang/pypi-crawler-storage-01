#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Soukaina Timouma
@email: soukaina.timouma@well.OX.AC.UK
"""

from .run_RandomForest_functions import run_RandomForest_classification_model, run_rf_regression_model