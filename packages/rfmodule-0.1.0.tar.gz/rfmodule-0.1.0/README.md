# Random forest functions

# RFmodule

 This python library contains useful Python functions to create finely tuned classification and regression models.

## Installation

```bash
pip install RFmodule
