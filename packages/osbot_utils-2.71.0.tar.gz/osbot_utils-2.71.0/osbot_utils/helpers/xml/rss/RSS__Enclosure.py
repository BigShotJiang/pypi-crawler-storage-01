from osbot_utils.type_safe.Type_Safe import Type_Safe


class RSS__Enclosure(Type_Safe):
    url    : str
    type   : str
    length : int