class Constants:
    DEFAULT_CONFIG_FILE_NAME = "config.yml"
    DEFAULT_SESSION_DURATION = "P90D"
    DEFAULT_OAUTH2_CLIENT_ID = "front_end_client"
    DEFAULT_BRANCH_NAME = "main"
