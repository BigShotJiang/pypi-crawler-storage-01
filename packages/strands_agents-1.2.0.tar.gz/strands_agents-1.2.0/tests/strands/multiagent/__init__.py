"""Tests for the multiagent module."""
