# fps-akernel-task

An FPS plugin for the kernel task API.
