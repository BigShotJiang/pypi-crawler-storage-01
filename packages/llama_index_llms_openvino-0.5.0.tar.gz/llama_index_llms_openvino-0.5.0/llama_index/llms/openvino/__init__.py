from llama_index.llms.openvino.base import OpenVINOLLM


__all__ = ["OpenVINOLLM"]
