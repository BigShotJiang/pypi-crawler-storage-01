from typing import TypedDict


class TextDelta(TypedDict):
    text: str
