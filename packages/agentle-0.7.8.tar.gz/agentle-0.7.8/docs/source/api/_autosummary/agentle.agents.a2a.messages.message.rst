agentle.agents.a2a.messages.message
===================================

.. automodule:: agentle.agents.a2a.messages.message

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      Any
      BaseModel
      DataPart
      FilePart
      Message
      Sequence
      TextPart
   