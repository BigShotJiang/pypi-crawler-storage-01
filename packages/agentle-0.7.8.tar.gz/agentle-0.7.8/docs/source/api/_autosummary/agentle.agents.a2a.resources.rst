agentle.agents.a2a.resources
============================

.. automodule:: agentle.agents.a2a.resources

   
   .. rubric:: Classes

   .. autosummary::
   
      PushNotificationResource
      TaskResource
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   push_notification_resource
   task_resource
