agentle.agents.a2a.message\_parts.file\_part
============================================

.. automodule:: agentle.agents.a2a.message_parts.file_part

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      BaseModel
      File
      FilePart
   