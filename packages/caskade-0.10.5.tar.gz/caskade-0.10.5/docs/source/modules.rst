caskade docstrings
==================

Someday I'll make a nicely formatted interface to all this, but for now, here's
a list of all the modules and their functions. You can just search for what you
need here and get more detailed information.

.. automodule:: caskade
    :members: