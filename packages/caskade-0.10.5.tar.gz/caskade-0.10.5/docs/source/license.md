# License

See here: [https://github.com/ConnorStoneAstro/caskade/blob/main/LICENSE](https://github.com/ConnorStoneAstro/caskade/blob/main/LICENSE)