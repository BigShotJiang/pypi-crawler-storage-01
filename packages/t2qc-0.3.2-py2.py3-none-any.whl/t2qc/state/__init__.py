class State:
    COMPLETE = 1
    FAILED = 2
    RUNNING = 3
    TERMINATED = 4
    NOT_FOUND = 5
