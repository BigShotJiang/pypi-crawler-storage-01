"""Geometry utilities used by :mod:`differt.geometry`."""

__all__ = ("TriangleMesh",)

from ._triangle_mesh import TriangleMesh
