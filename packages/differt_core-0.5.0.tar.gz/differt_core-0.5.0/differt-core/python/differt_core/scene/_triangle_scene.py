__all__ = ("TriangleScene",)

from differt_core import _differt_core

TriangleScene = _differt_core.scene.triangle_scene.TriangleScene
