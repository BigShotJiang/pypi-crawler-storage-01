"""Flock logging system with Rich integration and structured logging support."""

from .logging import configure_logging

__all__ = ["configure_logging"]

