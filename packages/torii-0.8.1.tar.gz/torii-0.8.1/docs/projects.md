# Projects Using Torii

The following is an incomplete list of projects that use Torii, we'd love to add yours to this list too! [submit pull request] or an [issue] so we can add it!

* [Squishy] - A SCSI Multitool and framework
* [SOL] - A framework for developing USB-enabled gateware

[submit pull request]: https://github.com/shrine-maiden-heavy-industries/torii-hdl/pulls
[issue]: https://github.com/shrine-maiden-heavy-industries/torii-hdl/issues
[Squishy]: https://github.com/squishy-scsi/squishy
[SOL]: https://github.com/shrine-maiden-heavy-industries/sol
