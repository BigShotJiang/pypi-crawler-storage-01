# Events

```{eval-rst}

.. autoclass:: torii.lib.soc.event.Source
.. autoclass:: torii.lib.soc.event.EventMap
.. autoclass:: torii.lib.soc.event.Monitor

```
