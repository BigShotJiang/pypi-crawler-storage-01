# Peripherals

```{eval-rst}

.. autoclass:: torii.lib.soc.periph.ConstantValue
.. autoclass:: torii.lib.soc.periph.ConstantBool
.. autoclass:: torii.lib.soc.periph.ConstantInt
.. autoclass:: torii.lib.soc.periph.ConstantMap
.. autoclass:: torii.lib.soc.periph.PeripheralInfo

```
