# System on Chip

The {py:mod}`torii.lib.soc` module provides various modules for use in SoCs and other complex designs.

```{toctree}
:maxdepth: 2

event
periph

csr/index

```
