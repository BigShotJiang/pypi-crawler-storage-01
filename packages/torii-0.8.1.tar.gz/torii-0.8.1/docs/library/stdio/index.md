# Industry Standard I/O

The {py:mod}`torii.lib.stdio` module provides industry standard I/O modules.

## Serial I/O

```{eval-rst}

.. autoclass:: torii.lib.stdio.serial.AsyncSerialRX
.. autoclass:: torii.lib.stdio.serial.AsyncSerialTX
.. autoclass:: torii.lib.stdio.serial.AsyncSerial

```
