# Memory Map

```{eval-rst}

.. autoclass:: torii.lib.mem.map.ResourceInfo
.. autoclass:: torii.lib.mem.map.MemoryMap

```
