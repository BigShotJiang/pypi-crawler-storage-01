# Wishbone Bus

```{eval-rst}

.. autoclass:: torii.lib.bus.wishbone.CycleType
.. autoclass:: torii.lib.bus.wishbone.BurstTypeExt
.. autoclass:: torii.lib.bus.wishbone.Interface
.. autoclass:: torii.lib.bus.wishbone.Decoder
.. autoclass:: torii.lib.bus.wishbone.Arbiter

```
