# Stream Library

```{eval-rst}

.. automodule:: torii.lib.stream

```

```{toctree}
:maxdepth: 2

simple
```
