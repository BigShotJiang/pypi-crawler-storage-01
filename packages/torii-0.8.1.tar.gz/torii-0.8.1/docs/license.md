# License

## BSD-2-Clause

```{literalinclude} ../LICENSE
---
language: text
---
```
