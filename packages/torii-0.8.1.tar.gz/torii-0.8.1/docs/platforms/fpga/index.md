# Torii FPGA Platforms

Torii has support for many FPGA vendors, the following platforms implement the ability to produce designs for various FPGAs.

```{toctree}
:maxdepth: 2

gowin
altera
lattice-ecp5
lattice-ice40
lattice-machxo-2-3l
quicklogic
xilinx
```
