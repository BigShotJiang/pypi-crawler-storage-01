# Platform Integration

Torii integrates with several FPGA vendors, it allows for a full end-to-end flow from design to implementation.

```{toctree}
:maxdepth: 2

fpga/index

```
