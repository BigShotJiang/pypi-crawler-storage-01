# Copyright 2022 Zurich Instruments AG
# SPDX-License-Identifier: Apache-2.0

# For backwards compatibility only
from laboneq.data.scheduled_experiment import MixerType  # noqa: F401
