Módulo para la exportación de ficheros bancarios según el formato
Confirming, para Banco Sabadell.
