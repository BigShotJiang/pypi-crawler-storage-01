class House:
    def yummy(self):
        return True
