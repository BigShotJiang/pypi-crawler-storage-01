# flake8: noqa

# import apis into api package
from upstream_api_client.api.auth_api import AuthApi
from upstream_api_client.api.campaigns_api import CampaignsApi
from upstream_api_client.api.measurements_api import MeasurementsApi
from upstream_api_client.api.projects_api import ProjectsApi
from upstream_api_client.api.sensor_variables_api import SensorVariablesApi
from upstream_api_client.api.sensors_api import SensorsApi
from upstream_api_client.api.stations_api import StationsApi
from upstream_api_client.api.uploadfile_csv_api import UploadfileCsvApi

