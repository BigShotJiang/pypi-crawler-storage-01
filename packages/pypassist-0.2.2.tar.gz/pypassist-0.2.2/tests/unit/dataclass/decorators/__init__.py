"""Unit tests for dataclass decorators."""
