#!/usr/bin/env python3
"""Package stub."""
