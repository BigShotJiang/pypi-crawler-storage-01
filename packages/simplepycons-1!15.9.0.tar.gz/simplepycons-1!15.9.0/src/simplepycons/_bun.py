#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class BunIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "bun"

    @property
    def original_file_name(self) -> "str":
        return "bun.svg"

    @property
    def title(self) -> "str":
        return "Bun"

    @property
    def primary_color(self) -> "str":
        return "#000000"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Bun</title>
     <path d="M12 22.596c6.628 0 12-4.338 12-9.688
 0-3.318-2.057-6.248-5.219-7.986-1.286-.715-2.297-1.357-3.139-1.89C14.058
 2.025 13.08 1.404 12 1.404c-1.097 0-2.334.785-3.966 1.821a49.92 49.92
 0 0 1-2.816 1.697C2.057 6.66 0 9.59 0 12.908c0 5.35 5.372 9.687 12
 9.687v.001ZM10.599 4.715c.334-.759.503-1.58.498-2.409
 0-.145.202-.187.23-.029.658 2.783-.902 4.162-2.057
 4.624-.124.048-.199-.121-.103-.209a5.763 5.763 0 0 0
 1.432-1.977Zm2.058-.102a5.82 5.82 0 0
 0-.782-2.306v-.016c-.069-.123.086-.263.185-.172 1.962 2.111 1.307
 4.067.556 5.051-.082.103-.23-.003-.189-.126a5.85 5.85 0 0 0
 .23-2.431Zm1.776-.561a5.727 5.727 0 0
 0-1.612-1.806v-.014c-.112-.085-.024-.274.114-.218 2.595 1.087 2.774
 3.18 2.459 4.407a.116.116 0 0 1-.049.071.11.11 0 0
 1-.153-.026.122.122 0 0 1-.022-.083 5.891 5.891 0 0
 0-.737-2.331Zm-5.087.561c-.617.546-1.282.76-2.063 1-.117
 0-.195-.078-.156-.181 1.752-.909 2.376-1.649 2.999-2.778 0 0
 .155-.118.188.085 0 .304-.349 1.329-.968 1.874Zm4.945 11.237a2.957
 2.957 0 0 1-.937 1.553c-.346.346-.8.565-1.286.62a2.178 2.178 0 0
 1-1.327-.62 2.955 2.955 0 0 1-.925-1.553.244.244 0 0 1
 .064-.198.234.234 0 0 1 .193-.069h3.965a.226.226 0 0 1
 .19.07c.05.053.073.125.063.197Zm-5.458-2.176a1.862 1.862 0 0
 1-2.384-.245 1.98 1.98 0 0
 1-.233-2.447c.207-.319.503-.566.848-.713a1.84 1.84 0 0 1
 1.092-.11c.366.075.703.261.967.531a1.98 1.98 0 0 1 .408 2.114 1.931
 1.931 0 0 1-.698.869v.001Zm8.495.005a1.86 1.86 0 0 1-2.381-.253 1.964
 1.964 0 0
 1-.547-1.366c0-.384.11-.76.32-1.079.207-.319.503-.567.849-.713a1.844
 1.844 0 0 1 1.093-.108c.367.076.704.262.968.534a1.98 1.98 0 0 1 .4
 2.117 1.932 1.932 0 0 1-.702.868Z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
