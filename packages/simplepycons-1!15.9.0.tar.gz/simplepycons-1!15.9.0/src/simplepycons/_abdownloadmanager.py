#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class AbDownloadManagerIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "abdownloadmanager"

    @property
    def original_file_name(self) -> "str":
        return "abdownloadmanager.svg"

    @property
    def title(self) -> "str":
        return "AB Download Manager"

    @property
    def primary_color(self) -> "str":
        return "#897BFF"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>AB Download Manager</title>
     <path d="M10.98 0c-.235 0-.425.2-.425.446V8.92c0
 .246-.19.446-.425.446h-.704c-.346 0-.547.41-.346.705l2.574
 3.782c.17.25.522.25.692 0l2.574-3.782c.201-.295
 0-.705-.346-.705h-.704a.436.436 0 0 1-.425-.446V.446A.436.436 0 0 0
 13.02 0ZM7.387 1.562a.732.732 0 0 0-.405.161l-1.096.883a.77.77 0 0
 0-.123 1.066.735.735 0 0 0 1.045.126l1.096-.882a.77.77 0 0 0
 .123-1.067.738.738 0 0 0-.64-.287Zm9.346 0a.737.737 0 0
 0-.64.287.77.77 0 0 0 .123 1.067l1.096.882c.323.26.79.204
 1.045-.126a.77.77 0 0 0-.123-1.066l-1.096-.883a.733.733 0 0
 0-.405-.16ZM3.039 6.036a.745.745 0 0 0-.675.48l-.512
 1.326c-.15.39.037.831.42.985a.74.74 0 0 0
 .965-.428l.512-1.325a.765.765 0 0 0-.419-.985.728.728 0 0
 0-.291-.053Zm18.042 0a.738.738 0 0 0-.29.053.765.765 0 0
 0-.42.985l.512 1.325a.74.74 0 0 0 .965.428.765.765 0 0 0
 .42-.985l-.512-1.325a.745.745 0 0 0-.675-.481ZM0 12a12 12 0 0 0 .913
 4.592 11.997 11.997 0 0 0 2.42 3.703c.684-.681 1.565-1
 2.489-1.053.925-.055 1.893.156 2.745.532a8.497 8.497 0 0 0 6.866
 0c1.702-.751 3.865-.843 5.234.52a11.997 11.997 0 0 0 2.42-3.702A12 12
 0 0 0 24 12h-3.687c-1.301 0-2.315 1.094-2.813 2.296a6 6 0 0 1-11.087
 0C5.915 13.094 4.902 12 3.601 12Zm5.875
 7.769c-.727.04-1.407.275-1.957.727-.073.06-.14.119-.204.18a11.997
 11.997 0 0 0 3.694 2.41 12 12 0 0 0 9.184 0 11.997 11.997 0 0 0
 3.694-2.41 3.977 3.977 0 0
 0-.204-.18c-1.173-.963-2.96-.892-4.436-.24a9.023 9.023 0 0 1-7.292
 0c-.478-.211-1.418-.546-2.48-.487Z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from [
            "ABDM",
        ]
