from typing import TypedDict


class DatasetViewDataTypedDict(TypedDict):
    dataset_name: str
    table_name: str
