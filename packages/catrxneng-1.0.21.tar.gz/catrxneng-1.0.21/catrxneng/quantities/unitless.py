from .quantity import Quantity


class Unitless(Quantity):
    pass
