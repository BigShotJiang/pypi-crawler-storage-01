# md2lobster

This is a small tool that takes a markdown file
and produces a lobster tracking file for the markdown
file.

It takes links to requiremnts and traces those.
It's intended for free text test reports or manual
 analysis reports to ensure the lobster tracing is
in place.


---
[![status-badge](https://ci.codeberg.org/api/badges/14974/status.svg)](https://ci.codeberg.org/repos/14974)
