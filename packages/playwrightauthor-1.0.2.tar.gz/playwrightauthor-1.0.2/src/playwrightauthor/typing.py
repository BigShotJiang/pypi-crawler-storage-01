# this_file: playwrightauthor/typing.py

"""Shared type hints for the project."""
