STEPS = ["sample", "barcode", "mapping_tag", "count_tag", "analysis_tag", "split_tag"]
__ASSAY__ = "tag"
