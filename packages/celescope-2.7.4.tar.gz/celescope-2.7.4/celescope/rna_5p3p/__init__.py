STEPS = [
    "sample",
    "convert",
    "starsolo",
    "cells",
    "analysis",
]
__ASSAY__ = "rna_5p3p"

IMPORT_DICT = {"analysis": "celescope.rna"}

REMOVE_FROM_MULTI = {
    "cells",
}
