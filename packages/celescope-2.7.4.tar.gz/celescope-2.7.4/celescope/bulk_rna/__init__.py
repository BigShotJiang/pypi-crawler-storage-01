STEPS = ["sample", "starsolo", "cells", "split"]
__ASSAY__ = "bulk_rna"
REMOVE_FROM_MULTI = {
    "cells",
}
