"""The runx package for OST (Self-Executing Templates) execution."""

from .runx_main import runx_main

__all__ = ["runx_main"]
