"""OST (Self-Executing Templates) implementation.

This package contains modules for turning .ost templates into self-executing
mini-CLIs with embedded schemas and global argument policy enforcement.
"""

__version__ = "0.1.0"
