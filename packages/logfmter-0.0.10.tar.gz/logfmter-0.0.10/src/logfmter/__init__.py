# flake8: noqa

from logfmter.formatter import Logfmter as Logfmter

__version__ = "0.0.10"
