"""
A library to create automatically test benches for systemverilog codes.
"""

from . import generate
from . import basetypes
from . import generators