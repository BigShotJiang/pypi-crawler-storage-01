# PySVBench

A collection of scripts for debugging easily systemverilog code.

## PySVBench.basetypes

PySVBench.basetypes includes classes to represent signals and sequences (sequences being arrays of signals).

## PySVBench.generate

PySVBench.generate has Testbench class to create a testbench.

## Documentation

Currently the project doesn't have documentation as everything is in docstring. In the future I may add it.
