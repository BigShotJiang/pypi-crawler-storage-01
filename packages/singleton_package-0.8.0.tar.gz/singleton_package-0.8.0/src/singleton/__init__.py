from .singleton import AbstractSingleton, Singleton

__all__ = ["Singleton", "AbstractSingleton"]
