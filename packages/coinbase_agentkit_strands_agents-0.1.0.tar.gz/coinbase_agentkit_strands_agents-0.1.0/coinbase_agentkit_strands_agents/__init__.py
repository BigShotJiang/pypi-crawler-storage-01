"""Strands Agents extension for AgentKit."""

from .strands_agents_tools import get_strands_tools

__all__ = ["get_strands_tools"]
