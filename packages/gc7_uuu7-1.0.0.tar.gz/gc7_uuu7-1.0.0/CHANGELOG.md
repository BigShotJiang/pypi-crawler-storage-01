# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-08-03)

### Bug Fixes

- V7 ([`696e48d`](https://github.com/PyMoX-fr/GC7/commit/696e48db36cbe6b57484a981f56f25b88766b37f))


## v0.0.0 (2025-08-03)

- Initial Release
