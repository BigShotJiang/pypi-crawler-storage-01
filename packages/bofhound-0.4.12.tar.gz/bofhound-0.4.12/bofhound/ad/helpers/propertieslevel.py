from enum import Enum

class PropertiesLevel(Enum):
    Standard    = 'Standard'
    Member      = 'Member'
    All         = 'All'