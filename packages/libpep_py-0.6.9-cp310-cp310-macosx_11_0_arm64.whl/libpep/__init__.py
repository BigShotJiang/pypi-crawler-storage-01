from .libpep import *

__doc__ = libpep.__doc__
if hasattr(libpep, "__all__"):
    __all__ = libpep.__all__