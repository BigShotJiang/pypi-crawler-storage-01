# LlamaIndex Index_Store Integration: Mongo Index Store
