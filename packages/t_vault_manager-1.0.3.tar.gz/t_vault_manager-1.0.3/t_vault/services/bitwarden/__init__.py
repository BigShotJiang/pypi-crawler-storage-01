"""Bitwarden service."""

from .bitwarden import Bitwarden

__all__ = ["Bitwarden"]
