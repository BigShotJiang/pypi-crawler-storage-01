"""Core module for the keeper service."""

from .types import TKeeperRecord

__all__ = ["TKeeperRecord"]
