class BitwardenInstallError(Exception):
    """Exception raised when an installation operation fails."""
