class VaultError(Exception):
    """Exception raised when an error occurs with the vault."""
