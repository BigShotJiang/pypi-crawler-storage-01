class VaultItemNotFoundError(Exception):
    """Exception raised when a vault item is not found."""
