class VaultItemError(Exception):
    """Exception raised when an error occurs with a vault item."""
