# Scaffold connection
The scaffold connection acts as a boilerplate for a newly created connection.

## Usage
Create a scaffold connection with the `aea scaffold connection {NAME}` command and implement your own connection.
