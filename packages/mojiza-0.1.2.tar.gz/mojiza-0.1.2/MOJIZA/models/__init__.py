# MOJIZA/models/__init__.py

from .base import Model
