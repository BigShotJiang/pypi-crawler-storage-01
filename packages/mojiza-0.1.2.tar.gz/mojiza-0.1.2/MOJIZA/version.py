"""

MOJIZA V:0.1.0

"""


__VERSION__ = '0.1.0'