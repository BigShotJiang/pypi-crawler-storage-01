Main class: Github
==================

.. autoclass:: github.MainClass.Github
