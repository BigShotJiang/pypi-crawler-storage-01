"""Stub symbolic diff CI check."""


def check_symbolic_diff() -> bool:
    """Return True if diff passes."""
    return True

__all__ = ["check_symbolic_diff"]
