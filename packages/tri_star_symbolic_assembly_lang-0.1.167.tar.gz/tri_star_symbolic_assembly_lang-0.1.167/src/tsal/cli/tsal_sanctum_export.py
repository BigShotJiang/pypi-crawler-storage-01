from tsal.tools.sanctum_export import main

if __name__ == "__main__":
    main()
