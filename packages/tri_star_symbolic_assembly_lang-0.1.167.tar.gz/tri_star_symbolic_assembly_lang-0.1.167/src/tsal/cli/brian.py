from tsal.tools.brian.optimizer import main

if __name__ == "__main__":
    main()
