from tsal.tools.watchdog import main

if __name__ == "__main__":
    main()
