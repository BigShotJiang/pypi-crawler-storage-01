from tsal.tools.meshkeeper import main

if __name__ == "__main__":
    main()
