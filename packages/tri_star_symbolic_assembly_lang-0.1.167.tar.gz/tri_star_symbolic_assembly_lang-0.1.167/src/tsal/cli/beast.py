from tsal.audit.brian_self_audit import cli_main as main

if __name__ == "__main__":
    main()
