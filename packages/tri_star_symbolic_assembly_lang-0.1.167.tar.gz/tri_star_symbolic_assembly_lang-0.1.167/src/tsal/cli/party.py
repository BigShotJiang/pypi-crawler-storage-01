from tsal.tools.party_tricks import main

if __name__ == "__main__":
    main()
