
from enum import Enum


class CovarEstimatorType(Enum):
    EWMA = 1
    LASSO = 2
