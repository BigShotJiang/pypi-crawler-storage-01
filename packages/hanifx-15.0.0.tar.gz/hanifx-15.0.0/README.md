# hanifx

OSINT phone number info tool without APIs and user permission.

## Installation

```bash
pip install hanifx
