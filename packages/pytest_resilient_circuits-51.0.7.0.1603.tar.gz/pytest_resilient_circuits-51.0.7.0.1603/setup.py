#!/usr/bin/env python
# -*- coding: utf-8 -*-
# (c) Copyright IBM Corp. 2010, 2023. All Rights Reserved.

""" Setup for pytest_resilient_circuits module """

from setuptools import setup

setup()
