# sage_setup: distribution = sagemath-maxima

from sage.all__sagemath_categories import *
