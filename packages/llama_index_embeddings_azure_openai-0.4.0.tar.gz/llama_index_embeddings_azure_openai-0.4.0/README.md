# LlamaIndex Embeddings Integration: Azure Openai
