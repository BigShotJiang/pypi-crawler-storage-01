from src.routes.auth import auth_routes
from src.routes.items import items_routes

public_routes = [auth_routes, items_routes]
