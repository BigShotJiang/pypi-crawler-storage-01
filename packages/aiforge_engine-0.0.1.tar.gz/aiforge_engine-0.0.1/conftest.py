from dotenv import load_dotenv

# 在所有测试运行前加载环境变量
load_dotenv()
