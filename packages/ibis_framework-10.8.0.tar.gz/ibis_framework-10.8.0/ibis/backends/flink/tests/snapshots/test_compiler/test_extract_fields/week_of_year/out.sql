SELECT
  EXTRACT(week FROM `t0`.`i`) AS `tmp`
FROM `table` AS `t0`