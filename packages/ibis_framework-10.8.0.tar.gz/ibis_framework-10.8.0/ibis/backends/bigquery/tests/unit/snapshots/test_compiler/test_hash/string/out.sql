SELECT
  farm_fingerprint('test of hash') AS `Hash_'test of hash'`