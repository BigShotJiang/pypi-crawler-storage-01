SELECT
  st_geogpoint(`t0`.`lon`, `t0`.`lat`) AS `tmp`
FROM `t` AS `t0`