function f(_) {
    let x = (new Set());
    let y = 1;
    x.add(y);
    return y;
}