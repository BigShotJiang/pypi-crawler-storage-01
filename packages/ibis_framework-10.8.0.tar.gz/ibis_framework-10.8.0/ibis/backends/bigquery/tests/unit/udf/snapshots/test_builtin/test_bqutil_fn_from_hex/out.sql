SELECT
  bqutil.fn.from_hex('face') AS `from_hex_0_'face'`