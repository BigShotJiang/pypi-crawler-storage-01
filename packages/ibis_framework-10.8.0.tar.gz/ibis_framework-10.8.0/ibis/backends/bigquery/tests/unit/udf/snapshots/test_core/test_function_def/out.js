function f(a, b) {
    return (a + b);
}