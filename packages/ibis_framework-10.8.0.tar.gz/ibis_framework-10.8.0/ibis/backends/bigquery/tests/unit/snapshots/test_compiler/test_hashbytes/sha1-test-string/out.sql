SELECT
  SHA1('test') AS `tmp`