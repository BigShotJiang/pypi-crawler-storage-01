SELECT
  MD5('test') AS `tmp`