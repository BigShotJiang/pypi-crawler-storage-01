SELECT
  'a\'b"c' AS `'a_'b_c'`