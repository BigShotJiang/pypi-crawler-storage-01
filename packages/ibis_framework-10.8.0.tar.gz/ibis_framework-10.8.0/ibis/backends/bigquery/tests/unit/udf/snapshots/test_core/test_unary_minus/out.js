function f() {
    let a = 1;
    return (-a);
}