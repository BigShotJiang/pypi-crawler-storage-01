function mul(x, y) {
    return (x * y);
}