function my_range(n) {
    return [n].map(((x) => 1));
}