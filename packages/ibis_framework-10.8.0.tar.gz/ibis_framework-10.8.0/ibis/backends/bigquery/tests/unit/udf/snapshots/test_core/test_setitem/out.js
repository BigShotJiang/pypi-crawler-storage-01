function f(_) {
    let x = {};
    let y = '2';
    x[y] = y;
    return x;
}