function* f(a) {
    yield* [1, 2, 3];
}