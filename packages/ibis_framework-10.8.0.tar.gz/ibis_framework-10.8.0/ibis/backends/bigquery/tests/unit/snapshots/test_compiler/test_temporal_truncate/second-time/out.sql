SELECT
  TIME_TRUNC(`t0`.`a`, SECOND) AS `tmp`
FROM `t` AS `t0`