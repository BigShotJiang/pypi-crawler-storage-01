SELECT
  now() AS "TimestampNow()"