SELECT
  *
FROM "functional_alltypes" AS "t0"
WHERE
  "t0"."int_col" > 0 AND "t0"."float_col" BETWEEN 0 AND 1