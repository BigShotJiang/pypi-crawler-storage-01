SELECT
  LN("t0"."double_col") AS "Log(double_col)"
FROM "functional_alltypes" AS "t0"