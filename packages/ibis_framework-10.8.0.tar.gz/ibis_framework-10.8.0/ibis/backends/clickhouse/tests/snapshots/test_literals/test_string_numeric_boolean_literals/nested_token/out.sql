SELECT
  'An "escape"' AS "'An ""escape""'"