SELECT
  *
FROM "functional_alltypes" AS "t0"