from typing import Final


class Aws:

    Message: Final[str] = "message"

