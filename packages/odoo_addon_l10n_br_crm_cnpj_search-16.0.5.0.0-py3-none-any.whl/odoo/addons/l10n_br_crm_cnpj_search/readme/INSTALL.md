Este módulo depende do módulo l10n_br_cnpj_search e l10n_br_crm.
