Contributing
------------
We welcome contributions from anyone, even if you are new to open source we will be happy to help you to get started. Most of the Ladybug Tools developers started learning programming through developing for Ladybug Tools.

### Code contribution
This project follows Ladybug Tools contributing guideline. See [contributing to Ladybug Tools projects](https://github.com/ladybug-tools/contributing/blob/master/README.md).
