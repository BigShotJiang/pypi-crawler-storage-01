---
title: "Cleaner"
description: |
  API reference for the Cleaner class.
---

# `Cleaner`

::: pfd_toolkit.Cleaner
