---
title: "Scraper"
description: |
  API reference for the Scraper class.
---

# `Scraper`

::: pfd_toolkit.Scraper