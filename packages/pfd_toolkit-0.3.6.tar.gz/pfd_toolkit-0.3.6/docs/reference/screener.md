---
title: "Screener"
description: |
  API reference for the Screener class.
---

# `Screener`

::: pfd_toolkit.Screener