---
title: "Extractor"
description: |
  API reference for the Extractor class.
---

# `Extractor`

::: pfd_toolkit.Extractor
