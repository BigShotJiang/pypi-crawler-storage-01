welcom to library nofex
This is a Python library for hacking and security.