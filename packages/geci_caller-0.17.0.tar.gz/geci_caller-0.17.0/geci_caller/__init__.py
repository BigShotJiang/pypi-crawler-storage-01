"""A template Python module"""

__version__ = "0.17.0"
from .cli import *  # noqa
