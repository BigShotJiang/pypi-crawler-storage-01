# dbcache
Cache a large table: select into a DataFrame, to_csv into a buffer, compress, insert as a longblob

Use as a library and/or a standalone program.

For options:
dbcache.py --help

See docs: [Dbcache2025](https://docs.google.com/document/d/1QMFd4NwRwndlj4ySmeSX0noZ2Okf55HakDzMwWP3B_E/edit?usp=drive_link)
