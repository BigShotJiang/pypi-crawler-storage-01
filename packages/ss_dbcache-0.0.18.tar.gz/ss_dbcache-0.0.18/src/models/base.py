"""
Created on 15 Jul 2025

@author: ph1jb
"""

# models/base.py
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass
