from pydevops.version import __version__
from pydevops.__main__ import main