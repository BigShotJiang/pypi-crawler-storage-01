"""A collection of credential providers."""
