from .tui import Voting
def run():
    app = Voting()
    app.run()