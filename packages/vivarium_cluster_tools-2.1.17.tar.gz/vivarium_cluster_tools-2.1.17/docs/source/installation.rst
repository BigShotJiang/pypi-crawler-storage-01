.. toctree::
   :maxdepth: 2
   :caption: Contents:

Installation
============

You can install this package with

.. code-block:: console

    pip install vivarium-cluster-tools

In addition, this tool needs the redis client. This must be installed using conda.

.. code-block:: console

    conda install redis
