.. Vivarium Cluster Tools documentation main file, created by
   sphinx-quickstart on Thu Feb 28 09:37:02 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Vivarium Cluster Tools Documentation
====================================
Vivarium cluster tools is a python package that makes running ``vivarium``
simulations at scale on a Slurm cluster easy.

.. toctree::
   :maxdepth: 2

   installation
   distributed_runner
   yaml_basics
   branch
   logging
   api_reference/index
   glossary
