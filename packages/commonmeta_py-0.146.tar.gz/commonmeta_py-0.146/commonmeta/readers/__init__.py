"""Readers for different metadata formats"""
