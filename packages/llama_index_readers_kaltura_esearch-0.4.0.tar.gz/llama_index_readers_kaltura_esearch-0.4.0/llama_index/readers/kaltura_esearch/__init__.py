"""Init file."""

from llama_index.readers.kaltura_esearch.base import KalturaESearchReader

__all__ = ["KalturaESearchReader"]
