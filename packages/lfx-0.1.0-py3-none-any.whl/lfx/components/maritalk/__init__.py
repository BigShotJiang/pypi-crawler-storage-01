from .maritalk import MaritalkModelComponent

__all__ = ["MaritalkModelComponent"]
