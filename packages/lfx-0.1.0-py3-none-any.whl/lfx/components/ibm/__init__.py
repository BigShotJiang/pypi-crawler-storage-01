from .watsonx import WatsonxAIComponent
from .watsonx_embeddings import WatsonxEmbeddingsComponent

__all__ = ["WatsonxAIComponent", "WatsonxEmbeddingsComponent"]
