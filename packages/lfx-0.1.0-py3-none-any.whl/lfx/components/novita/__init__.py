from .novita import NovitaModelComponent

__all__ = ["NovitaModelComponent"]
