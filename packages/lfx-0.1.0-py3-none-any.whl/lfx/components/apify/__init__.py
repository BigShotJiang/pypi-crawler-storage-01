from .apify_actor import ApifyActorsComponent

__all__ = [
    "ApifyActorsComponent",
]
