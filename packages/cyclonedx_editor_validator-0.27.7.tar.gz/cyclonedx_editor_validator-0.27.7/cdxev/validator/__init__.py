# SPDX-License-Identifier: GPL-3.0-or-later

from .validate import validate_sbom

__all__ = ["validate_sbom"]
