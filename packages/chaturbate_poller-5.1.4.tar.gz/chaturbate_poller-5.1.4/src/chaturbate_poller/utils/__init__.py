"""Helper functions for the Chaturbate Poller."""
