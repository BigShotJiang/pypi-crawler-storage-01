<!-- confluence-page-id: 00000000000 -->

## Advanced fenced code blocks

A code block with an ordered list:

1. a list item:
   ```
   alice@example.com
   ```
1. another list item:
   ```
   bob@example.com
   ```

A code block with an unordered list:

- a list item:
  ```
  alice@example.com
  ```
- another list item:
  ```
  bob@example.com
  ```
