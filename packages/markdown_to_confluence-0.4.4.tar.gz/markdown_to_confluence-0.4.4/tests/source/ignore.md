## Ignored files

This Markdown document is skipped as per the rules defined in `.mdignore`.
