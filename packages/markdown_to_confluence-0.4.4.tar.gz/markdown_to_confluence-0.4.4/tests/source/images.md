<!-- confluence-page-id: 00000000000 -->

## Images

![PNG image with caption](figure/raster.png)

![SVG image with caption](figure/vector.svg)

![draw.io image embedded in PNG](figure/diagram.drawio.png)

![draw.io image embedded in SVG](figure/diagram.drawio.svg)

![External image](http://confluence.atlassian.com/images/logo/confluence_48_trans.png)

<img src="http://confluence.atlassian.com/images/logo/confluence_48_trans.png" width="24" height="24" />
