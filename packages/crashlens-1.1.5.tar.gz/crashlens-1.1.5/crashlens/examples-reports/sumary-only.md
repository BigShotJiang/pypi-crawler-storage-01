📊 156 traces | $1.18 total | $0.92 waste
🚨 87 issues: 2 retry, 5 fallback, 7 failure, 73 overkill
💡 77% potential savings