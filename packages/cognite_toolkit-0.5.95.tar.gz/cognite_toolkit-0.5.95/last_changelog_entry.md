## cdf 

### Fixed

- [alpha] When running `cdf profile ... ` with output to a spreadsheet
file, Toolkit ensures that the spreadsheet title is sanitized.

## templates

No changes.