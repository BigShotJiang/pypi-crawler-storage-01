def hello() -> str:
    return "Hello from uv-shell-hook!"
