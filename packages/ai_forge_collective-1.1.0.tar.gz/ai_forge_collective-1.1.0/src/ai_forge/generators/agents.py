# This module has been removed as part of MVP scope cleanup.
# The AgentsGenerator was a Phase 2 feature not part of the MVP scope.

raise ImportError(
    "AgentsGenerator has been removed in MVP scope cleanup. "
    "This functionality is planned for Phase 2."
)
