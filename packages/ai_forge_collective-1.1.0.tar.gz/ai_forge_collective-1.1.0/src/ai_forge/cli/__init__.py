"""AI Forge CLI module for command-line interface functionality."""

from ai_forge.cli.console import Console, console

__all__: list[str] = ["Console", "console"]
