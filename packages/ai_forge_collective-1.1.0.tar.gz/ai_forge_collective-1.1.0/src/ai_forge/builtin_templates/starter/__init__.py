"""Starter template for AI Forge - Universal project initialization."""
