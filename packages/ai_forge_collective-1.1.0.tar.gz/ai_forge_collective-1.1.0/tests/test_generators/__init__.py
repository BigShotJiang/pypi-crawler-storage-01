"""Tests for the generators module."""
