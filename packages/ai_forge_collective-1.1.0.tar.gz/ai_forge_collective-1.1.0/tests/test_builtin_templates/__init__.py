"""Tests for builtin templates."""
