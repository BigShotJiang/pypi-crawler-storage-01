"""AI Forge test suite."""
