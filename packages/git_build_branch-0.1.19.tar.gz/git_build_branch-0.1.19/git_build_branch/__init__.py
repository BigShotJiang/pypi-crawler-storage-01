"""Top-level package for git-build-branch."""

__author__ = """Dimagi"""
__email__ = 'dev@dimagi.com'
__version__ = '0.1.19'
