
from .quick_fault_detector import quick_fault_detector
