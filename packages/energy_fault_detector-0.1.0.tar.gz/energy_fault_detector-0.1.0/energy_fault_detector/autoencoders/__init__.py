"""Autoencoder model classes."""

from energy_fault_detector.autoencoders.multilayer_autoencoder import MultilayerAutoencoder
