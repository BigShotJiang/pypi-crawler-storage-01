https://github.com/Esri/lerc/tree/master/testData
Apache License - 2.0
