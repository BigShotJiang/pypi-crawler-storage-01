from sqlalchemy.exc import IntegrityError

SQLAIntegrityErrors = (IntegrityError, )