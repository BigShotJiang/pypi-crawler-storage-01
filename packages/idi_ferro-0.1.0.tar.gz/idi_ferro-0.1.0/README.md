﻿# idi-ferro

This is a placeholder package to reserve the name idi-ferro and prevent dependency confusion attacks.

Do not install or use this package.
