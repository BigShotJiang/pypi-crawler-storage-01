The existing definitions in the old web_pwa_oca of 16.0 (not existing or customizable
in core) are maintained.
