This module allows to configure data for Progressive Web App: Short name, Background color, Theme color and Icon.
