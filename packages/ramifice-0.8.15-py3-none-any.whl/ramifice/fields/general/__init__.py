"""Ramifice - Abstract classes for the fields."""
