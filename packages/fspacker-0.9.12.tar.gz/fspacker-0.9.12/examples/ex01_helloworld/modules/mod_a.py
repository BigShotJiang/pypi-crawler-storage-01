def function_mod_a():
    print("Called from function_mod_a, in folder")
