* `KMEE <https://kmee.com.br>`_:

  * Felipe Zago Rodrigues <felipe.zago@kmee.com.br>
  * Ygor Carvalho <ygor.carvalho@kmee.com.br>

* `ESCODOO <https://escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>

* `AKRETION <https://akretion.com/pt-BR/>`_:

  * Raphaël Valyi <raphael.valyi@akretion.com.br>

* `Engenere <https://engenere.one>`_:

  * Antônio S. Pereira Neto <neto@engenere.one>
