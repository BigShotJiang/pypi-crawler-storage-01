kubectl delete -f https://raw.githubusercontent.com/karmab/autolabeller/main/autorules.yml
