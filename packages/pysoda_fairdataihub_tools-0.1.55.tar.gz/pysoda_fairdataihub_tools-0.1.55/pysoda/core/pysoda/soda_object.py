soda = {
  "starting-point": {

  },
  "ps-dataset-selected": {

  },
  "ps-accoint-selected": {

  },
  "guided-manifest-file-data": {
    "headers": [
      "filename",
      "timestamp",
      "description",
      "file type",
      "entity",
      "data modality",
      "also in dataset",
      "also in dataset path",
      "data dictionary path",
      "entity is transitive",
      "Additional Metadata"
    ],
    "data": []
  },
  "dataset-validated": False, 
  "dataset-validation-errors": {},
  "dataset-structure": {
    "folders": {
      "data": {}
    }, 
    "files": {},
    "relativePath": "/"
  },
  "dataset-metadata": {
    "description-metadata": {},
    "shared-metadata": {},
    "protocol-data": {},
    "subject-metadata": {},
    "sample-metadata": {},
    "submission-metadata": {},
    "code-metadata": {},
    "README": "",
    "CHANGES": "",
    "performances": {},
    "sites": {},
    "resources": {}
  },
  "digital-metadata": {},
  "generate-dataset": {},
  "dataset-entity-structure": {},
  "dataset-entity-obj": {},
  "standard": ""
}