"""Entrypoint for Kina Jobs."""


# Install Flux Operator
