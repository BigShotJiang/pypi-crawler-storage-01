pip uninstall zcbot-io-sdk

pip install --upgrade zcbot-io-sdk -i https://pypi.python.org/simple
pip show zcbot-io-sdk
