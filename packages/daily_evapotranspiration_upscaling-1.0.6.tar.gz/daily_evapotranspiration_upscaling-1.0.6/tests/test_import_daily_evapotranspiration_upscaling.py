def test_import_daily_evapotranspiration_upscaling():
    import daily_evapotranspiration_upscaling
