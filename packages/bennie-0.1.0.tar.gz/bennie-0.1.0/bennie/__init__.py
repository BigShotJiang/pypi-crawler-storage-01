from .detectors.prepositions import find_dangling_prepositions

__all__ = [
    "find_dangling_prepositions",
]

__version__ = "0.1.0"