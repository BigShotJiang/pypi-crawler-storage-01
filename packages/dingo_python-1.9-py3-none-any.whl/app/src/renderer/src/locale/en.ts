export default {
    'app.name': 'Dingo',
    'error.count': '统计',
    'error.type': '类型与详情',
    'error.type.tooltip': '如需了解指标详细定义，请查看 {link}',
    'error.rate': '占比',
    'tab.overview': '总览',
    'tab.detailedData': '详细数据',
    'button.selectDirectory': '选择目录',
    'empty.title': '暂无数据',
    'summary.config.popover.title': '配置信息',
};
