import { createFromIconfontCN } from '@ant-design/icons';

const IconFont = createFromIconfontCN({
    scriptUrl: 'src/assets/iconfont.js',
});

export default IconFont;
