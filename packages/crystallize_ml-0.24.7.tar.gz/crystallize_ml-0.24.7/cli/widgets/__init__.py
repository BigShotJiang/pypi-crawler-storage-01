from .config_editor import ConfigEditorWidget
