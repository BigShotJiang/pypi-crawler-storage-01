from .like import Like

__all__ = [
    "Like",
]
