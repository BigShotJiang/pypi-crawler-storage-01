class Audio():
    def __init__(array=None, path=None, points=1024):
        pass

    def to_bytes():
        pass

    def play_process():
        pass

    def play():
        pass

    def finish():
        pass
