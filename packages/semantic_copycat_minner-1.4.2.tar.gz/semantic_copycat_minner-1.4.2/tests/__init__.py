"""
Tests for CopycatM.
""" 