"""Misc re-usable utilities."""
