::: imgtools.dicom.dicom_find
