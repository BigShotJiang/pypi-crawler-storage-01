::: imgtools.dicom.crawl.parse_dicoms
