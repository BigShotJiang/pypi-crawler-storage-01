::: imgtools.dicom.dicom_metadata.extractor_base
