::: imgtools.pattern_parser.pattern_resolver
