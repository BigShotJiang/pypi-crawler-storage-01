::: imgtools.utils.path_limits
