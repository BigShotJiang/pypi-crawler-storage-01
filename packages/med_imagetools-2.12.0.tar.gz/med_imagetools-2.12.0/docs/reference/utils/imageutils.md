::: imgtools.utils.imageutils
