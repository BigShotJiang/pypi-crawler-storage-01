::: imgtools.coretypes.box
