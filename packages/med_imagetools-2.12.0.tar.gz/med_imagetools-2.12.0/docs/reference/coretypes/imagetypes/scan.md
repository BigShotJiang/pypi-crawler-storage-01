::: imgtools.coretypes.imagetypes.scan
