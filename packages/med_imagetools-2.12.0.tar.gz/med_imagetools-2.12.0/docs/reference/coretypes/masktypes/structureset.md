::: imgtools.coretypes.masktypes.structureset
