::: imgtools.coretypes.masktypes.roi_matching
