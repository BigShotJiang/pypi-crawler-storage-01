::: imgtools.io.readers
