::: imgtools.io.writers.abstract_base_writer
