::: imgtools.io.writers.numpy_writer
