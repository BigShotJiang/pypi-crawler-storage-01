::: imgtools.loggers.json_logging
