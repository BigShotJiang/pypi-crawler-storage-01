"""Version identifier."""

__version__ = "2025.7.30"
