class AtcfsUnavailable(Exception):
    """
    Если сервер ATC FS недоступен.
    """
