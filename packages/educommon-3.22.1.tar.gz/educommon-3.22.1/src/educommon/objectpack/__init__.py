default_app_config = 'educommon.objectpack.apps.EduObjectPackConfig'
