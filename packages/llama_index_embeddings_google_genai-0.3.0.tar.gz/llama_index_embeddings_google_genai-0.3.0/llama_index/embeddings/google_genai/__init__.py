from llama_index.embeddings.google_genai.base import GoogleGenAIEmbedding

__all__ = ["GoogleGenAIEmbedding"]
