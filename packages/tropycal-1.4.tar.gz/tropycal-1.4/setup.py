from setuptools import setup

setup(name='tropycal',
      packages=['tropycal'],
      package_dir={'': 'src'},
      )
