r"""Functionality for reading and analyzing SHIPS data."""

from .ships import Ships
