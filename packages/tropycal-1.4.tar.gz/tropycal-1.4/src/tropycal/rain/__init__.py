r"""Functionality for reading and analyzing tropical cyclone rain data."""

from .dataset import RainDataset
