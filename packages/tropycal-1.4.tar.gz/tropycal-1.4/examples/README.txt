.. _examples-index:

Examples
========

Examples of using tropycal to generate images and text.
