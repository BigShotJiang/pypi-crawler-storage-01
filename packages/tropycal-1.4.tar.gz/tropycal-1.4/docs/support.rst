=======
Support
=======

If you encounter any bugs or issues that have not been reported yet,
please open an issue on Github_.

For any other questions or inquiries, feel free to reach out to the
project developers:

* Tomer Burg (tomerburg@gmail.com)
* Sam Lillo (splillo@gmail.com)

We are grateful to Tomer Aberbach and Ryan May for help and support in developing Tropycal. We also thank Dr. Ray Bell for helping to add Tropycal to conda-forge.

.. _Github: https://github.com/tropycal/tropycal/issues
