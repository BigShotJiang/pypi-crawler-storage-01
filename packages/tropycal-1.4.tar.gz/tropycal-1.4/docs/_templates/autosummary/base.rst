{{ objname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. auto{{ objtype }}:: {{ objname }}

.. include:: {{fullname}}

.. raw:: html

      <div style='clear:both'></div>
