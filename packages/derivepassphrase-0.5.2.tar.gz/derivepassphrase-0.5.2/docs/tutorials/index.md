---
title: Tutorial overview
---

* [Setting up `derivepassphrase vault` for three accounts, with a master
  passphrase][BASIC_SETUP_PASSPHRASE]

[BASIC_SETUP_PASSPHRASE]: basic-setup-passphrase.md
