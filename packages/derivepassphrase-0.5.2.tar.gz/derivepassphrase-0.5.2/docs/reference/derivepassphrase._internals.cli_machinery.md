::: derivepassphrase._internals.cli_machinery
    options:
      heading_level: 1
