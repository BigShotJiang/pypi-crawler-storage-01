::: derivepassphrase.cli
    options:
      heading_level: 1
