::: derivepassphrase._internals.cli_messages
    options:
      heading_level: 1
