::: tests
    options:
      heading_level: 1

::: tests.conftest
    options:
      heading_level: 2

