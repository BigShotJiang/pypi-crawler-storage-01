::: derivepassphrase._internals.cli_helpers
    options:
      heading_level: 1
