---
title: How-to overview
---

* [How to setup `derivepassphrase vault` with an SSH key][SSH_KEY]

[SSH_KEY]: ssh-key.md
