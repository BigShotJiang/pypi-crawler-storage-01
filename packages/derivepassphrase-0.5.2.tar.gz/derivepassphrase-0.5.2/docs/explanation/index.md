---
title: Explanation overview
---

* [How to comply with the "altered versions" clause of the
  license][FAQ_ALTERED_VERSIONS]
* [What are "interchangable passphrases" in `vault`, and what does that mean
  in practice?][FAQ_INTERCHANGABLE_PASSPHRASES]

[FAQ_ALTERED_VERSIONS]: faq-altered-versions.md
[FAQ_INTERCHANGABLE_PASSPHRASES]: faq-vault-interchangable-passphrases.md
