#!!!!! do not change this file !!!!!
app_version="0.7.407"
app_bulld_number=7407
app_bulld_anchor="pengjun@xinyu668.com_2025-07-30 20:04:10.536667"
app_name="mecord-cli"
