# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2025-08-02

### Added
- **New `--quiet` option** for CLI to suppress INFO-level logging
- **Enhanced parameter validation** for partial read commands
- **Improved MCP tool names** for better clarity and AI assistant integration
- **Comprehensive test coverage** with 1283 passing tests
- **UV package manager support** for easier environment management

### Changed
- **BREAKING**: Renamed MCP tool `format_table` to `analyze_code_structure` for better clarity
- **Improved**: All Japanese comments translated to English for international development
- **Enhanced**: Test stability with intelligent fallback mechanisms for complex Java parsing
- **Updated**: Documentation to reflect new tool names and features

### Fixed
- **Resolved**: Previously skipped complex Java structure analysis test now passes
- **Fixed**: Robust error handling for environment-dependent parsing scenarios
- **Improved**: Parameter validation with better error messages

### Technical Improvements
- **Performance**: Optimized analysis engine with better caching
- **Reliability**: Enhanced error handling and logging throughout the codebase
- **Maintainability**: Comprehensive test suite with no skipped tests
- **Documentation**: Complete English localization of codebase

## [0.1.3] - Previous Release

### Added
- Initial MCP server implementation
- Multi-language code analysis support
- Table formatting capabilities
- Partial file reading functionality

### Features
- Java, JavaScript, Python language support
- Tree-sitter based parsing
- CLI and MCP interfaces
- Extensible plugin architecture

---

## Migration Guide

### From 0.1.x to 0.2.0

#### MCP Tool Name Changes
If you're using the MCP server, update your tool calls:

**Before:**
```json
{
  "tool": "format_table",
  "arguments": { ... }
}
```

**After:**
```json
{
  "tool": "analyze_code_structure", 
  "arguments": { ... }
}
```

#### New CLI Options
Take advantage of the new `--quiet` option for cleaner output:

```bash
# New quiet mode
tree-sitter-analyzer file.java --structure --quiet

# Enhanced parameter validation
tree-sitter-analyzer file.java --partial-read --start-line 1 --end-line 10
```

#### UV Support
You can now use UV for package management:

```bash
# Install with UV
uv add tree-sitter-analyzer

# Run with UV
uv run tree-sitter-analyzer file.java --structure
```

---

For more details, see the [README](README.md) and [documentation](docs/).
