class IpswException(Exception):
    pass


class NoSuchBuildIdentityError(IpswException):
    pass
