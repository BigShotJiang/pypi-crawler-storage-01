# plain-pages changelog

## [0.10.5](https://github.com/dropseed/plain/releases/plain-pages@0.10.5) (2025-07-31)

### What's changed

- Support for symlinks when discovering pages in templates/pages directories ([c5e610d](https://github.com/dropseed/plain/commit/c5e610dfb7161551efdc82a23dac985e89078059))
- Updated package description and comprehensive README documentation ([4ebecd1](https://github.com/dropseed/plain/commit/4ebecd1856f96afc09a2ad6887224ae94b1a7395))

### Upgrade instructions

- No changes required

## [0.10.4](https://github.com/dropseed/plain/releases/plain-pages@0.10.4) (2025-06-23)

### What's changed

- No user-facing changes. This release only updates internal project metadata and documentation.

### Upgrade instructions

- No changes required.
