class PageNotFoundError(Exception):
    pass


class RedirectPageError(Exception):
    pass
