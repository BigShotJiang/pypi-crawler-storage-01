"""OEIS formula collection and analysis."""
