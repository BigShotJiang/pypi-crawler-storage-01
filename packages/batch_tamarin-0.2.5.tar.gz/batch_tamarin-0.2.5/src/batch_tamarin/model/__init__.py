"""Data models for batch Tamarin."""
