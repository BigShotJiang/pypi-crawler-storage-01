"""Tamarin Python Wrapper - Run Tamarin Prover models with JSON recipes."""

__version__ = "0.2.5"
__author__ = "Luca Mandrelli <luca.mandrelli@icloud.com>"

from .main import app

__all__ = ["app"]
