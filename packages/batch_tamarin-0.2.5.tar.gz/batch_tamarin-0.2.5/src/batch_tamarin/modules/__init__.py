"""Core modules for batch Tamarin functionality."""

from .output_manager import output_manager

__all__ = ["output_manager"]
