# __init__.py
__version__ = "0.1.4"
__author__ = "Jeroen Uleman"
__email__ = "j.f.uleman@gmail.com"