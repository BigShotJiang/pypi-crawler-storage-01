# systemdynamics
 Converting causal loop diagrams into computational system dynamics models

## Setup Instructions

### Install Dependencies

Make sure you have `pip` installed. Then, you can install the package using

```sh
pip install systemdynamics
```

## Additional Information

- If you encounter any issues, please ensure that you have all the necessary dependencies installed.
- For more information, refer to the [documentation]() or [contact us](j.f.uleman@gmail.com).