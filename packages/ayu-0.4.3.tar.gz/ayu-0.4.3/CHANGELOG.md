# 0.4.3
- Upgrade dependencies to next major textual

# 0.4.2
- Fix NoMatches Error after textual v4.0.0 Update

# 0.4.1
- Fix Tooltip for Filewatcher-Button, to show correct path if `self.test_path` is `None`
i.e. `ayu` is run without any arguments

# 0.4.0
- Add File Watcher to rerun tests in changed file automatically

# 0.3.0
- Add Test Run duration to detailview border

# 0.2.0
- Fix Coverage Explorer Scroll
- Fix Marked Test Execution with spaces in parametrize args
- Add PluginExplorer

# 0.1.6
- Add CoverageExplorer
- Add LogWidget

# 0.1.5
- Increase `MAX_EVENT_SIZE` to send via websocket

# 0.1.4
- Fix runner command

# 0.1.3
- Add `textual-tags` to filter based on test markers
- Add SearchModal to search for tests also add favourite function
and filtering for NodeTypes

# 0.1.X
- Initial test releases
