# Iris Pie

Macroeconomic modeling package for Python


## Project URLs

Homepage: [`https://github.com/iris-solutions-team/irispie`](https://github.com/iris-solutions-team/irispie)

Documentation: [`https://iris-solutions-team.github.io/irispie-pages`](https://iris-solutions-team.github.io/irispie-pages)

Bug Tracker: [`https://github.com/iris-solutions-team/irispie/issues`](https://github.com/iris-solutions-team/irispie/issues)


