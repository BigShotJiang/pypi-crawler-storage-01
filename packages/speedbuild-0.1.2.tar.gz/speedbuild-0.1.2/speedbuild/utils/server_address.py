url_address = "https://backend.speedbuild.dev/"
ws_address = "wss://backend.speedbuild.dev/ws/"
app_address = "https://app.speedbuild.dev/"