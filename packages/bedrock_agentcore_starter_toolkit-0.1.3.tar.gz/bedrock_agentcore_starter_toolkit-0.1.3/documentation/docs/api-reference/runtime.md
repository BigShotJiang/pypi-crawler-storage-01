# Runtime

Runtime management and application context for Bedrock AgentCore.

::: bedrock_agentcore.runtime
