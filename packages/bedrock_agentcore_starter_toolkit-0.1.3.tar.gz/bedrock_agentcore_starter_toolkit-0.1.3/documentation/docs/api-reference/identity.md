# Identity

Memory management for Bedrock AgentCore SDK.

## Service client

::: bedrock_agentcore.services.identity
    options:
      heading_level: 3

## Decorators

::: bedrock_agentcore.identity
    options:
      heading_level: 3
