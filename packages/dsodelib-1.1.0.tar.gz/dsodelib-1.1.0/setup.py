from setuptools import setup, find_packages

setup(
    name="dsodelib",
    version="1.1.0",
    packages=find_packages(),
    author="danilavkariev",
    description="Testlibrarry",
    python_requires=">=3.6",
)