#
#
#


class BaseErrorException(Exception):
    """Base class for other exceptions"""
    pass
