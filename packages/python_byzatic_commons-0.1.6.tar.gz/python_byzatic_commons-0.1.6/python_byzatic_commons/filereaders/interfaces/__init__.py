#
#
#

# interfaces
from python_byzatic_commons.filereaders.interfaces.BaseReaderInterface import BaseReaderInterface

__all__ = [
    'BaseReaderInterface'
]
