#
#
#

# interfaces
from python_byzatic_commons.flattener.list_flattener.ListFlattener import ListFlattener

__all__ = [
    'ListFlattener'
]
