from django.db import models

class StoreQuerySet(models.QuerySet):
    pass