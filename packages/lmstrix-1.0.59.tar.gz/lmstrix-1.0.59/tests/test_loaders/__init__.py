"""Loader module tests."""
