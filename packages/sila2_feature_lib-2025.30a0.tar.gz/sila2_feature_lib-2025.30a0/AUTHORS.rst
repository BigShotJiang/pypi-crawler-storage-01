=======
Credits
=======

Development Lead
----------------

* Erik Trygg <etrg@novonordisk.com>

Contributors
------------

None yet. Why not be the first?


Other mentions
--------------

* Novo Nordisk A/S, Denmark, for open sourcing the initial version of this piece software (June 2024).
