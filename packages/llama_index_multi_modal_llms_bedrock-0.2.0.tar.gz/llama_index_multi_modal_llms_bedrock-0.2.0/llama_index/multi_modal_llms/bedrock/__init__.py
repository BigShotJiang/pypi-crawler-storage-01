from llama_index.multi_modal_llms.bedrock.base import BedrockMultiModal

__all__ = ["BedrockMultiModal"]
