"""mitol.olposthog"""

default_app_config = "mitol.olposthog.apps.OlPosthog"

__version__ = "2025.8.1"
__distributionname__ = "mitol-django-OlPosthog"
