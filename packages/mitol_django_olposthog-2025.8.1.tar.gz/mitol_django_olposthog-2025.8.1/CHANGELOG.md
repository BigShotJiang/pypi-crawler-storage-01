
<a id='changelog-2025.8.1'></a>
## [2025.8.1] - 2025-08-01

### Added

- Added posthog application.

### Changed

- Version date from using 04 to 4.

- Updated PostHog dependency to >=6.3.1,<7.

### Fixed

- Renamed `api_key` to `project_api_key` named keyword argument when creating PostHog client after posthog update.

<a id='changelog-2025.3.17'></a>
## [2025.3.17] - 2025-03-17

- Support for Python 3.13

### Added

- Added posthog application.

### Changed

- Version date from using 04 to 4.

- Update paths in pyproject.toml to ensure versioning continues to work.

### added

### removed

- support for python 3.8 and 3.9.
