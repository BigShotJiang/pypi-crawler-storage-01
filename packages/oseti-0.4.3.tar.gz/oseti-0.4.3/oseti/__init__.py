# -*- coding: utf-8 -*-
from .oseti import Analyzer

VERSION = (0, 4, 3)
__version__ = '0.4.3'
__all__ = ['Analyzer']
