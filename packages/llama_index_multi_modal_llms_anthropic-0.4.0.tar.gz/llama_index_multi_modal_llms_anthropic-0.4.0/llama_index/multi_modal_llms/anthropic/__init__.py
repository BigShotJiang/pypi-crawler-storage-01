from llama_index.multi_modal_llms.anthropic.base import AnthropicMultiModal

__all__ = ["AnthropicMultiModal"]
