# LlamaIndex Multi-Modal-Llms Integration: Anthropic
