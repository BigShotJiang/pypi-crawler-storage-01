import pytest

def test_dummy():
    assert 1 == 1
