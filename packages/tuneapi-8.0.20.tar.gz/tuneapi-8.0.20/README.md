# tuneapi

A swiss knife python package for building application with LLMs. Very opinionated.

I originally built at Tune AI (nimblebox.ai) for building assistants. Was MIT licensed since conception I've forked and run the latest code.

# license

MIT License.
