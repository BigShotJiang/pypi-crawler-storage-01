from __future__ import annotations

import base64
import ctypes
import logging
import re
import struct
import time
import traceback
import typing
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from datetime import timedelta
from functools import partial
from io import BytesIO
from os import urandom
from threading import Thread
from types import NoneType
from typing import List, Optional, Sequence, overload
from uuid import uuid4

import magic
from google.protobuf.internal.containers import RepeatedCompositeFieldContainer
from linkpreview import link_preview
from PIL import Image, ImageSequence

from ._binder import (
    free_bytes,
    func_callback_bytes,
    func_callback_bytes2,
    func_string,
    gocode,
)
from .builder import build_edit, build_revoke
from .events import Event, EventsManager
from .exc import (
    BuildPollVoteCreationError,
    BuildPollVoteError,
    ContactStoreError,
    ConvertStickerError,
    CreateGroupError,
    CreateNewsletterError,
    DecryptPollVoteError,
    DownloadError,
    FollowNewsletterError,
    GetBlocklistError,
    GetChatSettingsError,
    GetContactQrLinkError,
    GetGroupInfoError,
    GetGroupInviteLinkError,
    GetGroupRequestParticipantsError,
    GetJIDFromStoreError,
    GetJoinedGroupsError,
    GetLinkedGroupParticipantsError,
    GetNewsletterInfoError,
    GetNewsletterInfoWithInviteError,
    GetNewsletterMessagesError,
    GetNewsletterMessageUpdateError,
    GetProfilePictureError,
    GetStatusPrivacyError,
    GetSubGroupsError,
    GetSubscribedNewslettersError,
    GetUserDevicesError,
    GetUserInfoError,
    InviteLinkError,
    IsOnWhatsAppError,
    JoinGroupWithInviteError,
    LinkGroupError,
    LogoutError,
    MarkReadError,
    NewsletterMarkViewedError,
    NewsletterSendReactionError,
    NewsletterSubscribeLiveUpdatesError,
    NewsletterToggleMuteError,
    PutArchivedError,
    PutMutedUntilError,
    PutPinnedError,
    ResolveContactQRLinkError,
    SendAppStateError,
    SendMessageError,
    SendPresenceError,
    SetDefaultDisappearingTimerError,
    SetDisappearingTimerError,
    SetGroupAnnounceError,
    SetGroupLockedError,
    SetGroupPhotoError,
    SetGroupTopicError,
    SetPassiveError,
    SetPrivacySettingError,
    SetStatusMessageError,
    SubscribePresenceError,
    UnfollowNewsletterError,
    UnlinkGroupError,
    UpdateBlocklistError,
    UpdateGroupParticipantsError,
    UploadError,
)
from .proto import Neonize_pb2 as neonize_proto
from .proto.Neonize_pb2 import (
    JID,
    Blocklist,
    BuildMessageReturnFunction,
    Contact,
    ContactEntry,
    ContactEntryArray,
    ContactInfo,
    ContactsGetContactReturnFunction,
    ContactsPutPushNameReturnFunction,
    Device,
    DownloadReturnFunction,
    GetGroupInfoReturnFunction,
    GetGroupInviteLinkReturnFunction,
    GetJIDFromStoreReturnFunction,
    GetUserInfoReturnFunction,
    GetUserInfoSingleReturnFunction,
    GroupInfo,
    GroupLinkedParent,
    GroupLinkTarget,
    GroupParent,
    GroupParticipant,
    GroupParticipantRequest,
    IsOnWhatsAppResponse,
    IsOnWhatsAppReturnFunction,
    JIDArray,
    JoinGroupWithLinkReturnFunction,
    LocalChatSettings,
    MessageInfo,
    NewsletterMessage,
    NewsletterMetadata,
    PrivacySettings,
    ProfilePictureInfo,
    ReqCreateGroup,
    ReturnFunctionWithError,
    SendMessageReturnFunction,
    SendRequestExtra,
    SendResponse,
    SetGroupPhotoReturnFunction,
    StatusPrivacy,
    UploadResponse,
    UploadReturnFunction,
)
from .proto.waCommon.WACommon_pb2 import MessageKey
from .proto.waCompanionReg.WAWebProtobufsCompanionReg_pb2 import DeviceProps
from .proto.waConsumerApplication.WAConsumerApplication_pb2 import ConsumerApplication
from .proto.waE2E.WAWebProtobufsE2E_pb2 import (
    AlbumMessage,
    AudioMessage,
    ContactMessage,
    ContextInfo,
    DocumentMessage,
    ExtendedTextMessage,
    GroupMention,
    ImageMessage,
    Message,
    MessageAssociation,
    PollVoteMessage,
    StickerMessage,
    StickerPackMessage,
    VideoMessage,
)
from .proto.waMsgApplication.WAMsgApplication_pb2 import MessageApplication
from .types import MessageServerID, MessageWithContextInfo
from .utils import (
    add_exif,
    gen_vcard,
    get_message_type,
    log,
    log_whatsmeow,
    validate_link,
)
from .utils.calc import AspectRatioMethod, auto_sticker, original_sticker
from .utils.enum import (
    BlocklistAction,
    ChatPresence,
    ChatPresenceMedia,
    ClientName,
    ClientType,
    LogLevel,
    MediaType,
    MediaTypeToMMS,
    ParticipantChange,
    Presence,
    PrivacySetting,
    PrivacySettingType,
    ReceiptType,
)
from .utils.ffmpeg import FFmpeg
from .utils.iofile import get_bytes_from_name_or_url, prepare_zip_file_content
from .utils.jid import Jid2String, JIDToNonAD, build_jid, jid_is_lid
from .utils.sticker import convert_to_sticker, convert_to_webp

_log_ = logging.getLogger(__name__)


class ContactStore:
    def __init__(self, uuid: bytes) -> None:
        self.uuid = uuid
        self.__client = gocode

    def put_pushname(
        self, user: JID, pushname: str
    ) -> ContactsPutPushNameReturnFunction:
        """
        Updates the pushname of a specific user.

        :param user: The JID (Jabber ID) of the user whose pushname needs to be updated.
        :type user: JID
        :param pushname: The new pushname for the user.
        :type pushname: str
        :raises ContactStoreError: If there is any error updating the pushname.
        :return: The updated contact model after the pushname has been updated.
        :rtype: ContactsPutPushNameReturnFunction
        """
        user_bytes = user.SerializeToString()
        bytes_ptr = self.__client.PutPushName(
            user_bytes, len(user_bytes), pushname.encode()
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = ContactsPutPushNameReturnFunction.FromString(protobytes)
        if model.Error:
            raise ContactStoreError(model.Error)
        return model

    def put_contact_name(self, user: JID, fullname: str, firstname: str):
        """
        This method is used to update the contact name in the contact store. It takes the user's JID,
        full name and first name as input parameters,
        then calls the PutContactName method of the client with the user's JID, full name and first name.
        If there is an error, it returns a ContactStoreError with the error message.

        :param user: The JID of the user whose contact name is to be updated
        :type user: JID
        :param fullname: The full name of the user
        :type fullname: str
        :param firstname: The first name of the user
        :type firstname: str
        :return: If there is an error, return a ContactStoreError with the error message, else None
        :rtype: ContactStoreError or None
        """
        user_bytes = user.SerializeToString()
        err = self.__client.PutContactName(
            self.uuid,
            user_bytes,
            len(user_bytes),
            fullname.encode(),
            firstname.encode(),
        ).decode()
        if err:
            return ContactStoreError(err)

    def put_all_contact_name(self, contact_entry: List[ContactEntry]):
        """
        This method serializes a list of ContactEntry objects and sends them to a
        remote service using the client's PutAllContactNames method. If the service
        returns an error, it raises a ContactStoreError with the error message.

        :param contact_entry: List of ContactEntry objects to be serialized and sent
        :type contact_entry: List[ContactEntry]
        :raises ContactStoreError: If the remote service returns an error message
        """
        entry = ContactEntryArray(ContactEntry=contact_entry).SerializeToString()
        err = self.__client.PutAllContactNames(self.uuid, entry, len(entry)).decode()
        if err:
            raise ContactStoreError(err)

    def get_contact(self, user: JID) -> ContactInfo:
        """
        This method retrieves a user's contact information based on their JID (Jabber Identifier).

        :param user: The Jabber Identifier of the user whose contact information is to be retrieved.
        :type user: JID
        :raises ContactStoreError: If there is an error while retrieving the contact information.
        :return: The contact information of the user.
        :rtype: ContactInfo
        """
        jid = user.SerializeToString()
        bytes_ptr = self.__client.GetContact(self.uuid, jid, len(jid))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = ContactsGetContactReturnFunction.FromString(protobytes)
        if model.Error:
            raise ContactStoreError(model.Error)
        return model.ContactInfo

    def get_all_contacts(self) -> RepeatedCompositeFieldContainer[Contact]:
        """
        This function retrieves all contacts from the client. It deserializes the response
        from the client, checks for any errors, and if there are no errors, returns the contacts.

        :raises ContactStoreError: If there is an error in the response from the client.
        :return: A list of all contacts.
        :rtype: RepeatedCompositeFieldContainer[Contact]
        """
        bytes_ptr = self.__client.GetAllContacts(self.uuid)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.ContactsGetAllContactsReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise ContactStoreError(model.Error)
        return model.Contact


class ChatSettingsStore:
    def __init__(self, uuid: bytes) -> None:
        """
        Initialize the ChatSettingsStore with a unique identifier.

        :param uuid: Unique identifier for the chat settings store.
        :type uuid: bytes
        """
        self.uuid = uuid
        self.__client = gocode

    def put_muted_until(self, user: JID, until: timedelta):
        """
        Mute a user until a specified time.

        :param user: The user to be muted.
        :type user: JID
        :param until: The duration until when the user will be muted.
        :type until: timedelta
        :raises PutMutedUntilError: If there is an error while muting the user.
        """
        user_buf = user.SerializeToString()
        return_ = self.__client.PutMutedUntil(
            self.uuid, user_buf, len(user_buf), until.total_seconds()
        )
        if return_:
            raise PutMutedUntilError(return_.decode())

    def put_pinned(self, user: JID, pinned: bool):
        """
        Pin or unpin a user.

        :param user: The user to be pinned or unpinned.
        :type user: JID
        :param pinned: True if the user should be pinned, False otherwise.
        :type pinned: bool
        :raises PutPinnedError: If there is an error while pinning the user.
        """
        user_buf = user.SerializeToString()
        return_ = self.__client.PutPinned(self.uuid, user_buf, len(user_buf), pinned)
        if return_:
            raise PutPinnedError(return_.decode())

    def put_archived(self, user: JID, archived: bool):
        """
        Archive or unarchive a user.

        :param user: The user to be archived or unarchived.
        :type user: JID
        :param archived: True if the user should be archived, False otherwise.
        :type archived: bool
        :raises PutArchivedError: If there is an error while archiving the user.
        """
        user_buf = user.SerializeToString()
        return_ = self.__client.PutArchived(
            self.uuid, user_buf, len(user_buf), archived
        )
        if return_:
            raise PutArchivedError(return_.decode())

    def get_chat_settings(self, user: JID) -> LocalChatSettings:
        """
        Retrieve the chat settings for a user.

        :param user: The user whose chat settings are to be retrieved.
        :type user: JID
        :raises GetChatSettingsError: If there is an error while retrieving the chat settings.
        :return: The chat settings for the specified user.
        :rtype: LocalChatSettings
        """
        user_buf = user.SerializeToString()
        bytes_ptr = self.__client.GetChatSettings(self.uuid, user_buf, len(user_buf))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        return_ = ReturnFunctionWithError.FromString(protobytes)
        if return_.Error:
            raise GetChatSettingsError(return_.Error)
        return return_.LocalChatSettings


class NewClient:
    def __init__(
        self,
        name: str,
        jid: Optional[JID] = None,
        props: Optional[DeviceProps] = None,
        uuid: Optional[str] = None,
    ):
        """Initializes a new client instance.

        :param name: The name or identifier for the new client.
        :type name: str
        :param jid: Optional. The JID (Jabber Identifier) for the client. If not provided, first client is used.
        :param qrCallback: Optional. A callback function for handling QR code updates, defaults to None.
        :type qrCallback: Optional[Callable[[NewClient, bytes], None]], optional
        :param messageCallback: Optional. A callback function for handling incoming messages, defaults to None.
        :type messageCallback: Optional[Callable[[NewClient, MessageSource, Message], None]], optional
        :param uuid: Optional. A unique identifier for the client, defaults to None.
        :type uuid: Optional[str], optional
        """
        self.name = name
        self.device_props = props
        self.jid = jid
        self.uuid = (jid.User if jid else (uuid or name)).encode()
        self.__client = gocode
        self.event = Event(self)
        self.qr = self.event.qr
        self.contact = ContactStore(self.uuid)
        self.chat_settings = ChatSettingsStore(self.uuid)
        self.connected = False
        self.me = None
        _log_.debug("🔨 Creating a NewClient instance")

    def __onLoginStatus(self, uuid: int, status: int):
        print(status)

    def __onQr(self, uuid: int, qr_protoaddr: int):
        """
        This method triggers an event when a QR code is detected.

        :param qr_protoaddr: The address of the QR code in memory.
        :type qr_protoaddr: int
        """
        self.event._qr(self, ctypes.string_at(qr_protoaddr))

    def _parse_mention(
        self, text: Optional[str] = None, are_lids: bool = False
    ) -> list[str]:
        """
        This function parses a given text and returns a list of 'mentions' in the format of 'mention@s.whatsapp.net'.
        A 'mention' is defined as a sequence of numbers (5 to 16 digits long) that is prefixed by '@' in the text.

        :param text: The text to be parsed for mentions, defaults to None
        :type text: Optional[str], optional
        :param are_lids: whether the mentions are lids defaults to False
        :type are_lids: bool, optional
        :return: A list of mentions in the format of 'mention@s.whatsapp.net'
        :rtype: list[str]
        """
        if text is None:
            return []
        # Definitely need a better method
        # WIP
        server = "@s.whatsapp.net" if not are_lids else "@lid"
        return [jid.group(1) + server for jid in re.finditer(r"@([0-9]{5,16}|0)", text)]

    def _parse_group_mention(self, text: Optional[str] = None) -> list[GroupMention]:
        """
        This function parses a given text and returns a list of 'mentions' in the format of 'GroupMention(…'
        A 'mention' is defined as a sequence of numbers (11 to 26 digits long) (might also include an hypen) that is prefixed by '@' and suffixed by @g.us in the text.

        :param text: The text to be parsed for mentions, defaults to None
        :type text: Optional[str], optional
        :return: A list of mentions in the format of 'GroupMention(groupJID="group_id@g.us", groupSubject="group_name")'
        :rtype: list[GroupMention]
        """
        if text is None:
            return []

        gc_mentions = []
        for jid in re.finditer(r"@([0-9-]{11,26}|0)@g\.us", text):
            try:
                group = self.get_group_info(build_jid(jid.group(1), "g.us"))
            except GetGroupInfoError:
                continue
            except Exception:
                _log_.error(traceback.format_exc())
                continue
            gc_mentions.append(
                GroupMention(
                    groupJID=Jid2String(group.JID), groupSubject=group.GroupName.Name
                )
            )

        return gc_mentions

    def _generate_link_preview(self, text: str) -> ExtendedTextMessage | None:
        youtube_url_pattern = re.compile(
            r"(?:https?:)?//(?:www\.)?(?:youtube\.com/(?:[^/\n\s]+"
            r"/\S+/|(?:v|e(?:mbed)?)/|\S*?[?&]v=)|youtu\.be/)([a-zA-Z0-9_-]{11})",
            re.IGNORECASE,
        )
        links = re.findall(r"https?://\S+", text)
        valid_links = list(filter(validate_link, links))
        if valid_links:
            preview = link_preview(valid_links[0])
            preview_type = (
                ExtendedTextMessage.PreviewType.VIDEO
                if re.match(youtube_url_pattern, valid_links[0])
                else ExtendedTextMessage.PreviewType.NONE
            )
            msg = ExtendedTextMessage(
                title=str(preview.title),
                description=str(preview.description),
                matchedText=valid_links[0],
                previewType=preview_type,
            )
            if preview.absolute_image:
                thumbnail = get_bytes_from_name_or_url(str(preview.absolute_image))
                mimetype = magic.from_buffer(thumbnail, mime=True)
                if "jpeg" in mimetype or "png" in mimetype:
                    image = Image.open(BytesIO(thumbnail))
                    upload = self.upload(thumbnail, MediaType.MediaLinkThumbnail)
                    msg.MergeFrom(
                        ExtendedTextMessage(
                            JPEGThumbnail=thumbnail,
                            thumbnailDirectPath=upload.DirectPath,
                            thumbnailSHA256=upload.FileSHA256,
                            thumbnailEncSHA256=upload.FileEncSHA256,
                            mediaKey=upload.MediaKey,
                            mediaKeyTimestamp=int(time.time()),
                            thumbnailWidth=image.size[0],
                            thumbnailHeight=image.size[1],
                        )
                    )
            return msg
        return None

    def _make_quoted_message(
        self, message: neonize_proto.Message, reply_privately: bool = False
    ) -> ContextInfo:
        if not isinstance((msg := get_message_type(message.Message)), str):
            try:
                msg.contextInfo.Clear()
            except Exception:
                _log_.warning(
                    "@_make_quoted_message; Couldn't clear the contextInfo of:"
                )
                _log_.warning(msg)
        sender = message.Info.MessageSource.Sender
        if jid_is_lid(sender):
            senderalt = message.Info.MessageSource.SenderAlt
            sender = senderalt if senderalt.ListFields() else sender
        return ContextInfo(
            stanzaID=message.Info.ID,
            participant=Jid2String(JIDToNonAD(sender)),
            quotedMessage=message.Message,
            remoteJID=(
                Jid2String(JIDToNonAD(message.Info.MessageSource.Chat))
                if reply_privately
                else None
            ),
        )

    def send_message(
        self,
        to: JID,
        message: typing.Union[Message, str],
        link_preview: bool = False,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
        add_msg_secret: bool = False,
    ) -> SendResponse:
        """Send a message to the specified JID.

        :param to: The JID to send the message to.
        :type to: JID
        :param message: The message to send.
        :type message: typing.Union[Message, str]
        :param link_preview: Whether to send a link preview, defaults to False
        :type link_preview: bool, optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :param add_msg_secret: Whether to generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :raises SendMessageError: If there was an error sending the message.
        :return: The response from the server.
        :rtype: SendResponse
        """
        to_bytes = to.SerializeToString()
        if isinstance(message, str):
            mentioned_groups = self._parse_group_mention(message)
            mentioned_jid = self._parse_mention(
                (ghost_mentions or message), mentions_are_lids
            )
            partial_msg = ExtendedTextMessage(
                text=message,
                contextInfo=ContextInfo(
                    mentionedJID=mentioned_jid, groupMentions=mentioned_groups
                ),
            )
            if link_preview:
                preview = self._generate_link_preview(message)
                if preview:
                    partial_msg.MergeFrom(preview)
            if partial_msg.previewType is None and not (
                mentioned_groups or mentioned_jid
            ):
                msg = Message(conversation=message)
            else:
                msg = Message(extendedTextMessage=partial_msg)
        else:
            msg = message
        if add_msg_secret:
            msg.messageContextInfo.messageSecret = urandom(32)
        message_bytes = msg.SerializeToString()
        bytes_ptr = self.__client.SendMessage(
            self.uuid, to_bytes, len(to_bytes), message_bytes, len(message_bytes)
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = SendMessageReturnFunction.FromString(protobytes)
        if model.Error:
            raise SendMessageError(model.Error)
        model.SendResponse.MergeFrom(model.SendResponse.__class__(Message=msg))
        return model.SendResponse

    def build_reply_message(
        self,
        message: typing.Union[str, MessageWithContextInfo],
        quoted: neonize_proto.Message,
        link_preview: bool = False,
        reply_privately: bool = False,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
    ) -> Message:
        """Send a reply message to a specified JID.

        :param message: The message to be sent. Can be a string or a MessageWithContextInfo object.
        :type message: typing.Union[str, MessageWithContextInfo]
        :param quoted: The message to be quoted in the message being sent.
        :type quoted: neonize_proto.Message
        :param link_preview: If set to True, enables link previews in the message being sent. Defaults to False.
        :type link_preview: bool, optional
        :param reply_privately: If set to True, the message is sent as a private reply. Defaults to False.
        :type reply_privately: bool, optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :return: Response of the send operation.
        :rtype: SendResponse
        """
        build_message = Message()
        if isinstance(message, str):
            partial_message = ExtendedTextMessage(
                text=message,
                contextInfo=ContextInfo(
                    mentionedJID=self._parse_mention(
                        (ghost_mentions or message), mentions_are_lids
                    ),
                    groupMentions=(self._parse_group_mention(message)),
                ),
            )
            if link_preview:
                preview = self._generate_link_preview(message)
                if preview is not None:
                    partial_message.MergeFrom(preview)
        else:
            partial_message = message
        field_name = (
            partial_message.__class__.__name__[0].lower()
            + partial_message.__class__.__name__[1:]
        )  # type: ignore
        partial_message.contextInfo.MergeFrom(
            self._make_quoted_message(quoted, reply_privately)
        )
        getattr(build_message, field_name).MergeFrom(partial_message)
        return build_message

    def reply_message(
        self,
        message: typing.Union[str, MessageWithContextInfo],
        quoted: neonize_proto.Message,
        to: Optional[JID] = None,
        link_preview: bool = False,
        reply_privately: bool = False,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
        add_msg_secret: bool = False,
    ) -> SendResponse:
        """Send a reply message to a specified JID.

        :param message: The message to be sent. Can be a string or a MessageWithContextInfo object.
        :type message: typing.Union[str, MessageWithContextInfo]
        :param quoted: The message to be quoted in the message being sent.
        :type quoted: neonize_proto.Message
        :param to: The recipient of the message. If not specified, the message is sent to the default recipient.
        :type to: Optional[JID], optional
        :param link_preview: If set to True, enables link previews in the message being sent. Defaults to False.
        :type link_preview: bool, optional
        :param reply_privately: If set to True, the message is sent as a private reply. Defaults to False.
        :type reply_privately: bool, optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :param add_msg_secret: If set to True generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: Response of the send operation.
        :rtype: SendResponse
        """
        if to is None:
            if reply_privately:
                sender = quoted.Info.MessageSource.Sender
                if jid_is_lid(sender):
                    sender = quoted.Info.MessageSource.SenderAlt or sender
                to = JIDToNonAD(sender)
            else:
                to = quoted.Info.MessageSource.Chat
        return self.send_message(
            to,
            self.build_reply_message(
                message=message,
                quoted=quoted,
                link_preview=link_preview,
                reply_privately=reply_privately,
                ghost_mentions=ghost_mentions,
                mentions_are_lids=mentions_are_lids,
            ),
            link_preview,
            add_msg_secret=add_msg_secret,
        )

    def edit_message(
        self, chat: JID, message_id: str, new_message: Message
    ) -> SendResponse:
        """Edit a message.

        :param chat: Chat ID
        :type chat: JID
        :param message_id: Message ID
        :type message_id: str
        :param new_message: New message
        :type new_message: Message
        :return: Response from server
        :rtype: SendResponse
        """
        return self.send_message(chat, build_edit(chat, message_id, new_message))

    def revoke_message(self, chat: JID, sender: JID, message_id: str) -> SendResponse:
        """Revoke a message.

        :param chat: Chat ID
        :type chat: JID
        :param sender: Sender ID
        :type sender: JID
        :param message_id: Message ID
        :type message_id: str
        :return: Response from server
        :rtype: SendResponse
        """
        return self.send_message(chat, self.build_revoke(chat, sender, message_id))

    def build_poll_vote_creation(
        self,
        name: str,
        options: List[str],
        selectable_count: int,
        quoted: Optional[neonize_proto.Message] = None,
    ) -> Message:
        """Build a poll vote creation message.

        :param name: The name of the poll.
        :type name: str
        :param options: The options for the poll.
        :type options: List[str]
        :param selectable_count: The number of selectable options.
        :type selectable_count: int
        :param quoted: A message that the poll message is a reply to, defaults to None
        :type quoted: Optional[neonize_proto.Message], optional
        :return: The poll vote creation message.
        :rtype: Message
        """
        options_buf = neonize_proto.ArrayString(data=options).SerializeToString()
        bytes_ptr = self.__client.BuildPollVoteCreation(
            self.uuid,
            name.encode(),
            options_buf,
            len(options_buf),
            selectable_count,
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = BuildMessageReturnFunction.FromString(protobytes)
        if model.Error:
            raise BuildPollVoteCreationError(model.Error)
        message = model.Message

        if quoted:
            message.pollCreationMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return message

    def build_poll_vote(
        self, poll_info: MessageInfo, option_names: List[str]
    ) -> Message:
        """Builds a poll vote.

        :param poll_info: The information about the poll.
        :type poll_info: MessageInfo
        :param option_names: The names of the options to vote for.
        :type option_names: List[str]
        :return: The poll vote message.
        :rtype: Message
        :raises BuildPollVoteError: If there is an error building the poll vote.
        """
        option_names_proto = neonize_proto.ArrayString(
            data=option_names
        ).SerializeToString()
        poll_info_proto = poll_info.SerializeToString()
        bytes_ptr = self.__client.BuildPollVote(
            self.uuid,
            poll_info_proto,
            len(poll_info_proto),
            option_names_proto,
            len(option_names_proto),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.BuildPollVoteReturnFunction.FromString(protobytes)
        if model.Error:
            raise BuildPollVoteError(model.Error)
        return model.PollVote

    def build_reaction(
        self, chat: JID, sender: JID, message_id: str, reaction: str
    ) -> Message:
        """
        This function builds a reaction message in a chat. It takes the chat and sender IDs,
        the message ID to which the reaction is being made, and the reaction itself as input.
        It then serializes the chat and sender IDs to strings, and calls the BuildReaction
        function of the client with these serialized IDs, the message ID, and the reaction.
        It finally returns the reaction message.

        :param chat: The ID of the chat in which the reaction is being made
        :type chat: JID
        :param sender: The ID of the sender making the reaction
        :type sender: JID
        :param message_id: The ID of the message to which the reaction is being made
        :type message_id: str
        :param reaction: The reaction being made
        :type reaction: str
        :return: The reaction message
        :rtype: Message
        """
        sender_proto = sender.SerializeToString()
        chat_proto = chat.SerializeToString()
        bytes_ptr = self.__client.BuildReaction(
            self.uuid,
            chat_proto,
            len(chat_proto),
            sender_proto,
            len(sender_proto),
            message_id.encode(),
            reaction.encode(),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        result = BuildMessageReturnFunction.FromString(protobytes)
        if result.Error:
            raise SendMessageError(result.Error)
        return result.Message

    def build_revoke(
        self, chat: JID, sender: JID, message_id: str, with_go: bool = False
    ) -> Message:
        """Builds a message to revoke a previous message.

        :param chat: The JID (Jabber Identifier) of the chat where the message should be revoked.
        :type chat: JID
        :param sender: The JID of the sender of the message to be revoked.
        :type sender: JID
        :param message_id: The unique identifier of the message to be revoked.
        :type message_id: str
        :return: The constructed Message object for revoking the specified message.
        :rtype: Message
        """
        if with_go:
            chat_buf = chat.SerializeToString()
            sender_buf = sender.SerializeToString()
            bytes_ptr = self.__client.BuildRevoke(
                self.uuid,
                chat_buf,
                len(chat_buf),
                sender_buf,
                len(sender_buf),
                message_id.encode(),
            )
            protobytes = bytes_ptr.contents.get_bytes()
            free_bytes(bytes_ptr)
            result = Message.FromString(protobytes)
            return result
        else:
            return build_revoke(chat, sender, message_id, self.get_me().JID)

    def build_sticker_message(
        self,
        file: typing.Union[str, bytes],
        quoted: Optional[neonize_proto.Message] = None,
        name: str = "",
        packname: str = "",
        crop: bool = False,
        enforce_not_broken: bool = False,
        animated_gif: bool = False,
        passthrough: bool = False,
    ) -> Message:
        """
        This function builds a sticker message from a given image or video file.
        The file is converted to a webp format and uploaded to a server.
        The resulting URL and other metadata are used to construct the sticker message.

        :param file: The path to the image or video file or the file data in bytes
        :type file: typing.Union[str, bytes]
        :param quoted: A message that the sticker message is a reply to, defaults to None
        :type quoted: Optional[neonize_proto.Message], optional
        :param name: The name of the sticker, defaults to ""
        :type name: str, optional
        :param packname: The name of the sticker pack, defaults to ""
        :type packname: str, optional
        :param crop: Crop-center the image, defaults to False
        :type crop: bool, optional
        :param enforce_not_broken: Enforce non-broken stickers by constraining sticker size to WA limits, defaults to False
        :type enforce_not_broken: bool, optional
        :param animated_gif: Ensure transparent media are properly processed, defaults to False
        :type animated_gif: bool, optional
        :param passthrough: Don't process sticker, send as is, defaults to False.
        :type passthrough: bool, optional
        :return: The constructed sticker message
        :rtype: Message
        """
        sticker = get_bytes_from_name_or_url(file)
        animated = is_webm = is_webp = is_image = saved_exif = False
        mime = magic.from_buffer(sticker, mime=True)
        if mime == "image/webp":
            is_webp = True
            io_save = BytesIO(sticker)
            img = Image.open(io_save)
            if len(ImageSequence.all_frames(img)) < 2:
                is_image = True
        elif mime == "video/webm":
            is_webm = True
        elif (mime := mime.split("/"))[0] == "image":
            is_image = True
        animated = not (is_image)
        if not passthrough and not animated_gif and is_image:
            io_save = BytesIO(sticker)
            stk = auto_sticker(io_save) if crop else original_sticker(io_save)
            io_save = BytesIO()
            # io_save.seek(0)
        elif not passthrough:
            animated = True
            sticker, saved_exif = convert_to_sticker(
                sticker, name, packname, enforce_not_broken, animated_gif, is_webm
            )
            if saved_exif:
                io_save = BytesIO(sticker)
            else:
                stk = Image.open(BytesIO(sticker))
                io_save = BytesIO()
        else:
            if not is_webp:
                raise ConvertStickerError(
                    "File is not a webp, which is required for passthrough."
                )
        if not (passthrough or saved_exif):
            stk.save(
                io_save,
                format="webp",
                exif=add_exif(name, packname),
                save_all=True,
                loop=0,
            )
        upload = self.upload(io_save.getvalue())
        message = Message(
            stickerMessage=StickerMessage(
                URL=upload.url,
                directPath=upload.DirectPath,
                fileEncSHA256=upload.FileEncSHA256,
                fileLength=upload.FileLength,
                fileSHA256=upload.FileSHA256,
                mediaKey=upload.MediaKey,
                mimetype=magic.from_buffer(io_save.getvalue(), mime=True),
                isAnimated=animated,
            )
        )
        if quoted:
            message.stickerMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return message

    def send_sticker(
        self,
        to: JID,
        file: typing.Union[str, bytes],
        quoted: Optional[neonize_proto.Message] = None,
        name: str = "",
        packname: str = "",
        crop: bool = False,
        enforce_not_broken: bool = False,
        animated_gif: bool = False,
        passthrough: bool = False,
        add_msg_secret: bool = False,
    ) -> SendResponse:
        """
        Send a sticker to a specific JID.

        :param to: The JID to send the sticker to.
        :type to: JID
        :param file: The file path of the sticker or the sticker data in bytes.
        :type file: typing.Union[str, bytes]
        :param quoted: The quoted message, if any, defaults to None.
        :type quoted: Optional[neonize_proto.Message], optional
        :param name: The name of the sticker, defaults to "".
        :type name: str, optional
        :param packname: The name of the sticker pack, defaults to "".
        :type packname: str, optional
        :param crop: Whether to crop-center the image, defaults to False
        :type crop: bool, optional
        :param enforce_not_broken: Whether to enforce non-broken stickers by constraining sticker size to WA limits, defaults to False
        :type enforce_not_broken: bool, optional
        :param animated_gif: Ensure transparent media are properly processed, defaults to False
        :type animated_gif: bool, optional
        :param passthrough: Don't process sticker, send as is, defaults to False.
        :type passthrough: bool, optional
        :param add_msg_secret: Whether to generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: The response from the send message function.
        :rtype: SendResponse
        """
        return self.send_message(
            to,
            self.build_sticker_message(
                file,
                quoted,
                name,
                packname,
                crop,
                enforce_not_broken,
                animated_gif,
                passthrough,
            ),
            add_msg_secret=add_msg_secret,
        )

    def _process_single_pack(
        self,
        stickers: List[List[bytes, bool]],
        pack_name: str,
        publisher: str = "",
        quoted: Optional[neonize_proto.Message] = None,
    ) -> Message:
        """
        Helper function to process a single sticker pack chunk

        """
        zip_dict = {}
        # Upload all stickers concurrently
        with ThreadPoolExecutor(max_workers=50) as executor:
            futures = [
                executor.submit(self._upload_sticker, sticker, animated, zip_dict)
                for sticker, animated in stickers
            ]
            sticker_metadata = [future.result() for future in futures]

        # Generate unique pack ID
        sticker_id = f"{uuid4()}"

        tray_icon = f"{sticker_id}.png"
        io_save = BytesIO()
        img = Image.open(BytesIO(stickers[0][0]))
        img = img.resize((252, 252))
        img.save(
            io_save,
            format="png",
            save_all=False,
            loop=0,
        )
        cover = io_save.getvalue()
        zip_dict.update({tray_icon: cover})
        file_size = 0
        for f in zip_dict.values():
            file_size += len(f)

        # Create zip archive
        sticker_pack = prepare_zip_file_content(zip_dict)
        thumbnail = self.upload(cover)
        img_hash = (
            base64.b64encode(thumbnail.FileSHA256).decode("utf-8").replace("/", "-")
        )
        upload = self.upload(sticker_pack, MediaType.MediaStickerPack)

        message = Message(
            stickerPackMessage=StickerPackMessage(
                stickerPackID=sticker_id,
                name=pack_name,
                publisher=publisher,
                stickers=sticker_metadata,
                # fileLength=upload.FileLength,
                fileLength=upload.FileLength,
                fileSHA256=upload.FileSHA256,
                fileEncSHA256=upload.FileEncSHA256,
                mediaKey=upload.MediaKey,
                directPath=upload.DirectPath,
                mediaKeyTimestamp=int(time.time()),
                trayIconFileName=tray_icon,
                thumbnailDirectPath=thumbnail.DirectPath,
                thumbnailSHA256=thumbnail.FileSHA256,
                thumbnailEncSHA256=thumbnail.FileEncSHA256,
                thumbnailHeight=252,
                thumbnailWidth=252,
                imageDataHash=img_hash,
                stickerPackSize=file_size,
                # stickerPackOrigin=StickerPackMessage.StickerPackOrigin.USER_CREATED,
                stickerPackOrigin=StickerPackMessage.StickerPackOrigin.THIRD_PARTY,
            )
        )
        if quoted:
            message.stickerPackMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return message

    def _upload_sticker(
        self, sticker: bytes, animated: bool, zip_dict: dict
    ) -> StickerPackMessage.Sticker:
        upload = self.upload(sticker)
        b64 = base64.b64encode(upload.FileSHA256)
        file_name = b64.decode("ascii").replace("/", "-") + ".webp"
        # b64 = base64.urlsafe_b64encode(upload.FileSHA256)
        # file_name = b64.decode("ascii") + ".webp"
        zip_dict.update({file_name: sticker})
        mimetype = magic.from_buffer(sticker, mime=True)
        return StickerPackMessage.Sticker(
            fileName=file_name,
            isAnimated=animated,
            accessibilityLabel="",
            isLottie=False,
            mimetype=mimetype,
        )

    def build_stickerpack_message(
        self,
        files: list,
        quoted: Optional[neonize_proto.Message] = None,
        packname: str = "Sticker pack",
        publisher: str = "",
        crop: bool = False,
        animated_gif: bool = False,
        passthrough: bool = False,
    ) -> List[Message]:
        p_func = partial(
            convert_to_webp,
            name=packname,
            packname=publisher,
            crop=crop,
            passthrough=passthrough,
            transparent=animated_gif,
        )

        def ensure_non_broken_packs(stickers):
            return [sticker for sticker in stickers if len(sticker[0]) < 1000000]

        with ProcessPoolExecutor(max_workers=20) as executor:
            stickers = list(executor.map(p_func, files))
        stickers = ensure_non_broken_packs(
            stickers
        )  # prevents broken packs by removing invalid stickers
        CHUNK_SIZE = 60
        chunks = [
            stickers[i : i + CHUNK_SIZE] for i in range(0, len(stickers), CHUNK_SIZE)
        ]
        total = len(chunks)

        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = []
            for idx, chunk in enumerate(chunks):
                suffix = f" ({idx + 1})" if total > 1 else ""
                full_name = packname + suffix
                futures.append(
                    executor.submit(
                        self._process_single_pack,
                        stickers=chunk,
                        pack_name=full_name,
                        publisher=publisher,
                        quoted=quoted,
                    )
                )
            return [future.result() for future in futures]

    def send_stickerpack(
        self,
        to: JID,
        files: list,
        quoted: Optional[neonize_proto.Message] = None,
        packname: str = "Sticker pack",
        publisher: str = "",
        crop: bool = False,
        animated_gif: bool = False,
        passthrough: bool = False,
        add_msg_secret: bool = False,
    ) -> List[SendResponse]:
        """
        Send a sticker pack to a specific JID.

        :param to: The JID to send the sticker to.
        :type to: JID
        :param files:  A list of file paths of the stickers or a list of stickers data in bytes.
        :type file: List[typing.Union[str, bytes]]
        :param quoted: The quoted message, if any, defaults to None.
        :type quoted: Optional[neonize_proto.Message], optional
        :param packname: The name of the sticker pack, defaults to "Sticker pack".
        :type packname: str, optional
        :param publisher: The name of the publisher, defaults to "".
        :type publisher: str, optional
        :param crop: Whether to crop-center the image, defaults to False
        :type crop: bool, optional
        :param add_msg_secret: Whether to generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: A list of response(s) from the send message function.
        :rtype: List[SendResponse]
        """
        responses = []
        msgs = self.build_stickerpack_message(
            files, quoted, packname, publisher, crop, animated_gif, passthrough
        )
        for msg in msgs:
            response = self.send_message(
                to,
                msg,
                add_msg_secret=add_msg_secret,
            )
            responses.append(response)
        return responses

    def build_video_message(
        self,
        file: str | bytes,
        caption: Optional[str] = None,
        quoted: Optional[neonize_proto.Message] = None,
        viewonce: bool = False,
        gifplayback: bool = False,
        is_gif: bool = False,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
    ) -> Message:
        """
        This function is used to build a video message. It uploads a video file, extracts necessary information,
        and constructs a message with the given parameters.

        :param file: The file path or bytes of the video file to be uploaded.
        :type file: str | bytes
        :param caption: The caption to be added to the video message, defaults to None
        :type caption: Optional[str], optional
        :param quoted: A message that the video message is in response to, defaults to None
        :type quoted: Optional[neonize_proto.Message], optional
        :param viewonce: A flag indicating if the video message can be viewed only once, defaults to False
        :type viewonce: bool, optional
        :param gifplayback: Optional. Whether the video should be sent as gif. Defaults to False.
        :type gifplayback: bool, optional
        :param is_gif: Optional. Whether the video to be sent is a gif. Defaults to False.
        :type is_gif: bool, optional
        :return: A video message with the given parameters.
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :rtype: Message
        """
        io = BytesIO(get_bytes_from_name_or_url(file))
        io.seek(0)
        buff = io.read()
        if is_gif:
            with FFmpeg(file) as ffmpeg:
                buff = file = ffmpeg.gif_to_mp4()
        with FFmpeg(file) as ffmpeg:
            duration = int(ffmpeg.extract_info().format.duration)
            thumbnail = ffmpeg.extract_thumbnail()
        upload = self.upload(buff)
        message = Message(
            videoMessage=VideoMessage(
                URL=upload.url,
                caption=caption,
                gifPlayback=gifplayback,
                seconds=duration,
                directPath=upload.DirectPath,
                fileEncSHA256=upload.FileEncSHA256,
                fileLength=upload.FileLength,
                fileSHA256=upload.FileSHA256,
                mediaKey=upload.MediaKey,
                mimetype=magic.from_buffer(buff, mime=True),
                JPEGThumbnail=thumbnail,
                thumbnailDirectPath=upload.DirectPath,
                thumbnailEncSHA256=upload.FileEncSHA256,
                thumbnailSHA256=upload.FileSHA256,
                viewOnce=viewonce,
                contextInfo=ContextInfo(
                    mentionedJID=self._parse_mention(
                        (ghost_mentions or caption), mentions_are_lids
                    ),
                    groupMentions=(self._parse_group_mention(caption)),
                ),
            )
        )
        if quoted:
            message.videoMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return message

    def send_video(
        self,
        to: JID,
        file: str | bytes,
        caption: Optional[str] = None,
        quoted: Optional[neonize_proto.Message] = None,
        viewonce: bool = False,
        gifplayback: bool = False,
        is_gif: bool = False,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
        add_msg_secret: bool = False,
    ) -> SendResponse:
        """Sends a video to the specified recipient.

        :param to: The JID (Jabber Identifier) of the recipient.
        :type to: JID
        :param file: Either a file path (str), url (str) or binary data (bytes) representing the video.
        :type file: typing.Union[str | bytes]
        :param caption: Optional. The caption of the video. Defaults to None.
        :type caption: Optional[str], optional
        :param quoted: Optional. The message to which the video is a reply. Defaults to None.
        :type quoted: Optional[Message], optional
        :param viewonce: Optional. Whether the video should be viewonce. Defaults to False.
        :type viewonce: bool, optional
        :param gifplayback: Optional. Whether the video should be sent as gif. Defaults to False.
        :type gifplayback: bool, optional
        :param is_gif: Optional. Whether the video to be sent is a gif. Defaults to False.
        :type is_gif: bool, optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :param add_msg_secret: Optional. Whether to generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: A function for handling the result of the video sending process.
        :rtype: SendResponse
        """
        return self.send_message(
            to,
            self.build_video_message(
                file,
                caption,
                quoted,
                viewonce,
                gifplayback,
                is_gif,
                ghost_mentions,
                mentions_are_lids,
            ),
            add_msg_secret=add_msg_secret,
        )

    def build_image_message(
        self,
        file: str | bytes,
        caption: Optional[str] = None,
        quoted: Optional[neonize_proto.Message] = None,
        viewonce: bool = False,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
    ) -> Message:
        """
        This function builds an image message. It takes a file (either a string or bytes),
        an optional caption, an optional quoted message, and a boolean indicating whether
        the message should be viewed once. It then uploads the image, generates a thumbnail,
        and constructs the message with the given parameters and the information from the
        uploaded image.

        :param file: The image file to be uploaded and sent, either as a string URL or bytes.
        :type file: str | bytes
        :param caption: The caption for the image message, defaults to None.
        :type caption: Optional[str], optional
        :param quoted: The message to be quoted in the image message, defaults to None.
        :type quoted: Optional[neonize_proto.Message], optional
        :param viewonce: Whether the image message should be viewable only once, defaults to False.
        :type viewonce: bool, optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :return: The constructed image message.
        :rtype: Message
        """
        n_file = get_bytes_from_name_or_url(file)
        img = Image.open(BytesIO(n_file))
        img.thumbnail(AspectRatioMethod(*img.size, res=200))
        thumbnail = BytesIO()
        img_saveable = img if img.mode == "RGB" else img.convert("RGB")
        img_saveable.save(thumbnail, format="jpeg")
        upload = self.upload(n_file)
        message = Message(
            imageMessage=ImageMessage(
                URL=upload.url,
                caption=caption,
                directPath=upload.DirectPath,
                fileEncSHA256=upload.FileEncSHA256,
                fileLength=upload.FileLength,
                fileSHA256=upload.FileSHA256,
                mediaKey=upload.MediaKey,
                mimetype=magic.from_buffer(n_file, mime=True),
                JPEGThumbnail=thumbnail.getvalue(),
                thumbnailDirectPath=upload.DirectPath,
                thumbnailEncSHA256=upload.FileEncSHA256,
                thumbnailSHA256=upload.FileSHA256,
                viewOnce=viewonce,
                contextInfo=ContextInfo(
                    mentionedJID=self._parse_mention(
                        (ghost_mentions or caption), mentions_are_lids
                    ),
                    groupMentions=(self._parse_group_mention(caption)),
                ),
            )
        )
        if quoted:
            message.imageMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return message

    def send_image(
        self,
        to: JID,
        file: str | bytes,
        caption: Optional[str] = None,
        quoted: Optional[neonize_proto.Message] = None,
        viewonce: bool = False,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
        add_msg_secret: bool = False,
    ) -> SendResponse:
        """Sends an image to the specified recipient.

        :param to: The JID (Jabber Identifier) of the recipient.
        :type to: JID
        :param file: Either a file path (str), url (str) or binary data (bytes) representing the image.
        :type file: typing.Union[str | bytes]
        :param caption: Optional. The caption of the image. Defaults to None.
        :type caption: Optional[str], optional
        :param quoted: Optional. The message to which the image is a reply. Defaults to None.
        :type quoted: Optional[Message], optional
        :param viewonce: Optional. Whether the image should be viewonce. Defaults to False.
        :type viewonce: bool, optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :param add_msg_secret: Optional. Whether to generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: A function for handling the result of the image sending process.
        :rtype: SendResponse
        """
        return self.send_message(
            to,
            self.build_image_message(
                file,
                caption,
                quoted,
                viewonce=viewonce,
                ghost_mentions=ghost_mentions,
                mentions_are_lids=mentions_are_lids,
            ),
            add_msg_secret=add_msg_secret,
        )

    def build_album_content(
        self,
        file: str | bytes,
        media_type: str,
        msg_association: MessageAssociation,
        **kwargs,
    ) -> Message:
        build_message = (
            self.build_image_message
            if media_type == "image"
            else self.build_video_message
        )
        msg = build_message(file, **kwargs)
        msg.messageContextInfo.MergeFrom(
            msg.messageContextInfo.__class__(messageAssociation=msg_association)
        )
        return msg

    def send_album(
        self,
        to: JID,
        files: list,
        caption: Optional[str] = None,
        quoted: Optional[neonize_proto.Message] = None,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
        add_msg_secret: bool = False,
    ) -> List[SendResponse, List[SendResponse]]:
        """Sends an album containing images, videos or both to the specified recipient.

        :param to: The JID (Jabber Identifier) of the recipient.
        :type to: JID
        :param files: A list containing either a file path (str), url (str) or binary data (bytes) representing the image/video.
        :type file: List[typing.Union[str | bytes]]
        :param caption: Optional. The caption of the first media in the album. Defaults to None.
        :type caption: Optional[str], optional
        :param quoted: Optional. The message to which the album is a reply. Defaults to None.
        :type quoted: Optional[Message], optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param add_msg_secret: Optional. Whether to generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: A function for handling the result of the album sending process.
        :rtype: List[SendResponse, List[SendResponse]]
        """
        image_count = video_count = 0
        medias = []
        for file in files:
            file = get_bytes_from_name_or_url(file)
            mime = magic.from_buffer(file, mime=True)
            media_type = mime.split("/")[0]
            if media_type == "image":
                image_count += 1
            elif media_type == "video":
                video_count += 1
            else:
                _log_.warning(
                    f"File with mime_type: {mime} was wrongly passed to send_album_message, ignoring…"
                )
                continue
            medias.append((file, media_type))
        if not (image_count or video_count):
            raise SendMessageError("No media found to send!")
        elif len(medias) < 2:
            raise SendMessageError("No enough media to send an album")
        message = Message(
            albumMessage=AlbumMessage(
                expectedImageCount=image_count,
                expectedVideoCount=video_count,
                contextInfo=ContextInfo(
                    mentionedJID=self._parse_mention(
                        (ghost_mentions or caption), mentions_are_lids
                    ),
                    groupMentions=(self._parse_group_mention(caption)),
                ),
            )
        )
        if quoted:
            message.albumMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        response = self.send_message(to, message, add_msg_secret=add_msg_secret)
        msg_association = MessageAssociation(
            associationType=MessageAssociation.AssociationType.MEDIA_ALBUM,
            parentMessageKey=MessageKey(
                remoteJID=Jid2String(to),
                fromMe=True,
                ID=response.ID,
            ),
        )
        with ThreadPoolExecutor(max_workers=25) as executor:
            futures = [
                executor.submit(
                    self.build_album_content,
                    file,
                    media_type,
                    msg_association,
                    caption=caption,
                    quoted=quoted,
                    ghost_mentions=ghost_mentions,
                    mentions_are_lids=mentions_are_lids,
                )
                for file, media_type in medias[:1]
            ]
            futures.extend(
                [
                    executor.submit(
                        self.build_album_content,
                        file,
                        media_type,
                        msg_association,
                        quoted=quoted,
                    )
                    for file, media_type in medias[1:]
                ]
            )

            messages = [fut.result() for fut in futures]

        with ThreadPoolExecutor(max_workers=25) as executor:
            send_futures = [
                executor.submit(
                    self.send_message, to, msg, add_msg_secret=add_msg_secret
                )
                for msg in messages
            ]
            responses = [fut.result() for fut in send_futures]
        return [response, responses]

    def build_audio_message(
        self,
        file: str | bytes,
        ptt: bool = False,
        quoted: Optional[neonize_proto.Message] = None,
    ) -> Message:
        """
        This method builds an audio message from a given file or bytes.

        :param file: The audio file in string or bytes format to be converted into an audio message
        :type file: str | bytes
        :param ptt: A boolean indicating if the audio message is a 'push to talk' message, defaults to False
        :type ptt: bool, optional
        :param quoted: A message that the audio message may be replying to, defaults to None
        :type quoted: Optional[neonize_proto.Message], optional
        :return: The audio message built from the given parameters
        :rtype: Message
        """
        io = BytesIO(get_bytes_from_name_or_url(file))
        io.seek(0)
        buff = io.read()
        upload = self.upload(buff)
        with FFmpeg(io.getvalue()) as ffmpeg:
            duration = int(ffmpeg.extract_info().format.duration)
        message = Message(
            audioMessage=AudioMessage(
                URL=upload.url,
                seconds=duration,
                directPath=upload.DirectPath,
                fileEncSHA256=upload.FileEncSHA256,
                fileLength=upload.FileLength,
                fileSHA256=upload.FileSHA256,
                mediaKey=upload.MediaKey,
                mimetype=magic.from_buffer(buff, mime=True),
                PTT=ptt,
            )
        )
        if quoted:
            message.audioMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return message

    def send_audio(
        self,
        to: JID,
        file: str | bytes,
        ptt: bool = False,
        quoted: Optional[neonize_proto.Message] = None,
        add_msg_secret: bool = False,
    ) -> SendResponse:
        """Sends an audio to the specified recipient.

        :param to: The JID (Jabber Identifier) of the recipient.
        :type to: JID
        :param file: Either a file path (str), url (str) or binary data (bytes) representing the audio.
        :type file: typing.Union[str | bytes]
        :param ptt: Optional. Whether the audio should be ptt. Defaults to False.
        :type ptt: bool, optional
        :param quoted: Optional. The message to which the audio is a reply. Defaults to None.
        :type quoted: Optional[Message], optional
        :param add_msg_secret: Optional. Whether to  generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: A function for handling the result of the audio sending process.
        :rtype: SendResponse
        """

        return self.send_message(
            to,
            self.build_audio_message(file, ptt, quoted),
            add_msg_secret=add_msg_secret,
        )

    def build_document_message(
        self,
        file: str | bytes,
        caption: Optional[str] = None,
        title: Optional[str] = None,
        filename: Optional[str] = None,
        mimetype: Optional[str] = None,
        quoted: Optional[neonize_proto.Message] = None,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
    ):
        io = BytesIO(get_bytes_from_name_or_url(file))
        io.seek(0)
        buff = io.read()
        upload = self.upload(buff, MediaType.MediaDocument)
        message = Message(
            documentMessage=DocumentMessage(
                URL=upload.url,
                caption=caption,
                directPath=upload.DirectPath,
                fileEncSHA256=upload.FileEncSHA256,
                fileLength=upload.FileLength,
                fileSHA256=upload.FileSHA256,
                mediaKey=upload.MediaKey,
                mimetype=mimetype or magic.from_buffer(buff, mime=True),
                title=title,
                fileName=filename,
                contextInfo=ContextInfo(
                    mentionedJID=self._parse_mention(
                        (ghost_mentions or caption), mentions_are_lids
                    ),
                    groupMentions=(self._parse_group_mention(caption)),
                ),
            )
        )
        if quoted:
            message.documentMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return message

    def send_document(
        self,
        to: JID,
        file: str | bytes,
        caption: Optional[str] = None,
        title: Optional[str] = None,
        filename: Optional[str] = None,
        mimetype: Optional[str] = None,
        quoted: Optional[neonize_proto.Message] = None,
        ghost_mentions: Optional[str] = None,
        mentions_are_lids: bool = False,
        add_msg_secret: bool = False,
    ) -> SendResponse:
        """Sends a document to the specified recipient.

        :param to: The JID (Jabber Identifier) of the recipient.
        :type to: JID
        :param file: Either a file path (str), url (str) or binary data (bytes) representing the document.
        :type file: typing.Union[str | bytes]
        :param caption: Optional. The caption of the document. Defaults to None.
        :type caption: Optional[str], optional
        :param title: Optional. The title of the document. Defaults to None.
        :type title: Optional[str], optional
        :param filename: Optional. The filename of the document. Defaults to None.
        :type filename: Optional[str], optional
        :param quoted: Optional. The message to which the document is a reply. Defaults to None.
        :type quoted: Optional[Message], optional
        :param ghost_mentions: List of users to tag silently (Takes precedence over auto detected mentions)
        :type ghost_mentions: str, optional
        :param mentions_are_lids: whether mentions contained in message or ghost_mentions are lids, defaults to False.
        :type mentions_are_lids: bool, optional
        :param add_msg_secret: Optional. Whether to generate 32 random bytes for messageSecret inside MessageContextInfo before sending, defaults to False
        :type add_msg_secret: bool, optional
        :return: A function for handling the result of the document sending process.
        :rtype: SendResponse
        """
        return self.send_message(
            to,
            self.build_document_message(
                file,
                caption,
                title,
                filename,
                mimetype,
                quoted,
                ghost_mentions,
                mentions_are_lids,
            ),
            add_msg_secret=add_msg_secret,
        )

    def send_contact(
        self,
        to: JID,
        contact_name: str,
        contact_number: str,
        quoted: Optional[neonize_proto.Message] = None,
    ) -> SendResponse:
        """Sends a contact to the specified recipient.

        :param to: The JID (Jabber Identifier) of the recipient.
        :type to: JID
        :param contact_name: The name of the contact.
        :type contact_name: str
        :param contact_number: The number of the contact.
        :type contact_number: str
        :param quoted: Optional. The message to which the contact is a reply. Defaults to None.
        :type quoted: Optional[Message], optional
        :return: A function for handling the result of the contact sending process.
        :rtype: SendResponse
        """
        message = Message(
            contactMessage=ContactMessage(
                displayName=contact_name,
                vcard=gen_vcard(contact_name, contact_number),
            )
        )
        if quoted:
            message.contactMessage.contextInfo.MergeFrom(
                self._make_quoted_message(quoted)
            )
        return self.send_message(to, message)

    def upload(
        self, binary: bytes, media_type: Optional[MediaType] = None
    ) -> UploadResponse:
        """Uploads media content.

        :param binary: The binary data to be uploaded.
        :type binary: bytes
        :param media_type: Optional. The media type of the binary data, defaults to None.
        :type media_type: Optional[MediaType], optional
        :raises UploadError: Raised if there is an issue with the upload.
        :return: An UploadResponse containing information about the upload.
        :rtype: UploadResponse
        """
        if not media_type:
            mime = MediaType.from_magic(binary)
        else:
            mime = media_type
        bytes_ptr = self.__client.Upload(self.uuid, binary, len(binary), mime.value)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        upload_model = UploadReturnFunction.FromString(protobytes)
        if upload_model.Error:
            raise UploadError(upload_model.Error)
        return upload_model.UploadResponse

    @overload
    def download_any(self, message: Message) -> bytes: ...

    @overload
    def download_any(self, message: Message, path: str) -> NoneType: ...

    def download_any(
        self, message: Message, path: Optional[str] = None
    ) -> typing.Union[None, bytes]:
        """Downloads content from a message.

        :param message: The message containing the content to download.
        :type message: Message
        :param path: Optional. The local path to save the downloaded content, defaults to None.
        :type path: Optional[str], optional
        :raises DownloadException: Raised if there is an issue with the download.
        :return: The downloaded content as bytes, or None if the content is not available.
        :rtype: Union[None, bytes]
        """
        msg_protobuf = message.SerializeToString()
        bytes_ptr = self.__client.DownloadAny(
            self.uuid, msg_protobuf, len(msg_protobuf)
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        media = DownloadReturnFunction.FromString(protobytes)
        if media.Error:
            raise DownloadError(media.Error)
        if path:
            with open(path, "wb") as file:
                file.write(media.Binary)
        else:
            return media.Binary
        return None

    def download_media_with_path(
        self,
        direct_path: str,
        enc_file_hash: bytes,
        file_hash: bytes,
        media_key: bytes,
        file_length: int,
        media_type: MediaType,
        mms_type: MediaTypeToMMS,
    ) -> bytes:
        """
        Downloads media with the given parameters and path. The media is downloaded from the path specified.

        :param direct_path: The direct path to the media to be downloaded.
        :type direct_path: str
        :param enc_file_hash: The encrypted hash of the file.
        :type enc_file_hash: bytes
        :param file_hash: The hash of the file.
        :type file_hash: bytes
        :param media_key: The key of the media to be downloaded.
        :type media_key: bytes
        :param file_length: The length of the file to be downloaded.
        :type file_length: int
        :param media_type: The type of the media to be downloaded.
        :type media_type: MediaType
        :param mms_type: The type of the MMS to be downloaded.
        :type mms_type: str
        :raises DownloadError: If there is an error in the download process.
        :return: The downloaded media in bytes.
        :rtype: bytes
        """
        bytes_ptr = self.__client.DownloadMediaWithPath(
            self.uuid,
            direct_path.encode(),
            enc_file_hash,
            len(enc_file_hash),
            file_hash,
            len(file_hash),
            media_key,
            len(media_key),
            file_length,
            media_type.value,
            mms_type.value.encode(),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.DownloadReturnFunction.FromString(protobytes)
        if model.Error:
            raise DownloadError(model.Error)
        return model.Binary

    def generate_message_id(self) -> str:
        """Generates a unique identifier for a message.

        :return: A string representing the unique identifier for the message.
        :rtype: str
        """
        return self.__client.GenerateMessageID(self.uuid).decode()

    def send_chat_presence(
        self, jid: JID, state: ChatPresence, media: ChatPresenceMedia
    ) -> str:
        """Sends chat presence information.

        :param jid: The JID (Jabber Identifier) of the chat.
        :type jid: JID
        :param state: The chat presence state.
        :type state: ChatPresence
        :param media: The chat presence media information.
        :type media: ChatPresenceMedia
        :return: A string indicating the result or status of the presence information sending.
        :rtype: str
        """
        jidbyte = jid.SerializeToString()
        return self.__client.SendChatPresence(
            self.uuid, jidbyte, len(jidbyte), state.value, media.value
        ).decode()

    def is_on_whatsapp(self, *numbers: str) -> Sequence[IsOnWhatsAppResponse]:
        """
        This function checks if the provided phone numbers are registered with WhatsApp.

        :param numbers: A series of phone numbers to be checked.
        :type numbers: str
        :raises IsOnWhatsAppError: If an error occurs while verifying the phone numbers.
        :return: A list of responses, each indicating whether the corresponding number is registered with WhatsApp.
        :rtype: Sequence[IsOnWhatsAppResponse]
        """
        if numbers:
            numbers_buf = " ".join(numbers).encode()
            bytes_ptr = self.__client.IsOnWhatsApp(
                self.uuid, numbers_buf, len(numbers_buf)
            )
            protobytes = bytes_ptr.contents.get_bytes()
            free_bytes(bytes_ptr)
            model = IsOnWhatsAppReturnFunction.FromString(protobytes)
            if model.Error:
                raise IsOnWhatsAppError(model.Error)
            return model.IsOnWhatsAppResponse
        return []

    @property
    def is_connected(self) -> bool:
        """Check if the object is currently connected.

        :return: True if the object is connected, False otherwise.
        :rtype: bool
        """
        return self.__client.IsConnected(self.uuid)

    @property
    def is_logged_in(self) -> bool:
        """Check if the user is currently logged in.

        :return: True if the user is logged in, False otherwise.
        :rtype: bool
        """
        return self.__client.IsLoggedIn(self.uuid)

    def get_user_info(
        self, *jid: JID
    ) -> RepeatedCompositeFieldContainer[GetUserInfoSingleReturnFunction]:
        """
        This function retrieves user information given a set of JID. It serializes the JID into a string,
        gets the user information from the client, deserializes the returned information, checks for any errors,
        and finally returns the user information.

        :param jid: JID of the users to retrieve information from
        :type jid: JID
        :raises GetUserInfoError: If there is an error in the model returned by the client
        :return: The user information for each JID
        :rtype: RepeatedCompositeFieldContainer[GetUserInfoSingleReturnFunction]
        """
        jidbuf = JIDArray(JIDS=jid).SerializeToString()
        bytes_ptr = self.__client.GetUserInfo(self.uuid, jidbuf, len(jidbuf))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetUserInfoReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetUserInfoError(model.Error)
        return model.UsersInfo

    def get_group_info(self, jid: JID) -> GroupInfo:
        """Retrieves information about a group.

        :param jid: The JID (Jabber Identifier) of the group.
        :type jid: JID
        :raises GetGroupInfoError: Raised if there is an issue retrieving group information.
        :return: Information about the specified group.
        :rtype: GroupInfo
        """
        jidbuf = jid.SerializeToString()
        bytes_ptr = self.__client.GetGroupInfo(
            self.uuid,
            jidbuf,
            len(jidbuf),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetGroupInfoReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetGroupInfoError(model.Error)
        return model.GroupInfo

    def get_group_info_from_link(self, code: str) -> GroupInfo:
        """Retrieves group information from a given link.

        :param code: The link code.
        :type code: str
        :return: An object containing the group information.
        :rtype: GroupInfo
        :raises GetGroupInfoError: If there is an error retrieving the group information.
        """
        bytes_ptr = self.__client.GetGroupInfoFromLink(self.uuid, code.encode())
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetGroupInfoReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetGroupInfoError(model.Error)
        return model.GroupInfo

    def get_group_info_from_invite(
        self, jid: JID, inviter: JID, code: str, expiration: int
    ) -> GroupInfo:
        """Retrieves group information from an invite.

        :param jid: The JID (Jabber ID) of the group.
        :type jid: JID
        :param inviter: The JID of the user who sent the invite.
        :type inviter: JID
        :param code: The invite code.
        :type code: str
        :param expiration: The expiration time of the invite.
        :type expiration: int

        :return: The group information.
        :rtype: GroupInfo

        :raises GetGroupInfoError: If there is an error retrieving the group information.
        """
        jidbyte = jid.SerializeToString()
        inviterbyte = inviter.SerializeToString()
        bytes_ptr = self.__client.GetGroupInfoFromInvite(
            self.uuid,
            jidbyte,
            len(jidbyte),
            inviterbyte,
            len(inviterbyte),
            code.encode(),
            expiration,
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetGroupInfoReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetGroupInfoError(model.Error)
        return model.GroupInfo

    def set_group_name(self, jid: JID, name: str) -> str:
        """Sets the name of a group.

        :param jid: The JID (Jabber Identifier) of the group.
        :type jid: JID
        :param name: The new name to be set for the group.
        :type name: str
        :return: A string indicating the result or an error status. Empty string if successful.
        :rtype: str
        """
        jidbuf = jid.SerializeToString()
        return self.__client.SetGroupName(
            self.uuid, jidbuf, len(jidbuf), ctypes.create_string_buffer(name.encode())
        ).decode()

    def set_group_photo(self, jid: JID, file_or_bytes: typing.Union[str, bytes]) -> str:
        """Sets the photo of a group.

        :param jid: The JID (Jabber Identifier) of the group.
        :type jid: JID
        :param file_or_bytes: Either a file path (str) or binary data (bytes) representing the group photo.
        :type file_or_bytes: typing.Union[str, bytes]
        :raises SetGroupPhotoError: Raised if there is an issue setting the group photo.
        :return: A string indicating the result or an error status.
        :rtype: str
        """
        data = get_bytes_from_name_or_url(file_or_bytes)
        jid_buf = jid.SerializeToString()
        bytes_ptr = self.__client.SetGroupPhoto(
            self.uuid, jid_buf, len(jid_buf), data, len(data)
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = SetGroupPhotoReturnFunction.FromString(protobytes)
        if model.Error:
            raise SetGroupPhotoError(model.Error)
        return model.PictureID

    def set_profile_photo(self, file_or_bytes: typing.Union[str, bytes]) -> str:
        """Sets profile photo.

        :param file_or_bytes: Either a file path (str) or binary data (bytes) representing the group photo.
        :type file_or_bytes: typing.Union[str, bytes]
        :raises SetGroupPhotoError: Raised if there is an issue setting the profile photo.
        :return: A string indicating the result or an error status.
        :rtype: str
        """
        data = get_bytes_from_name_or_url(file_or_bytes)
        bytes_ptr = self.__client.SetProfilePhoto(self.uuid, data, len(data))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = SetGroupPhotoReturnFunction.FromString(protobytes)
        if model.Error:
            raise SetGroupPhotoError(model.Error)
        return model.PictureID

    def get_lid_from_pn(self, jid: JID) -> JID:
        """Retrieves the matching lid from the supplied jid.

        :param jid: The JID (Jabber Identifier) (pn) of the target user.
        :type jid: JID
        :raises GetJIDFromStoreError: Raised if there is an issue getting the lid from the given jid.
        :return: The lid (hidden user) matching the supplied jid.
        :rtype: JID
        """
        jid_buf = jid.SerializeToString()
        bytes_ptr = self.__client.GetLIDFromPN(self.uuid, jid_buf, len(jid_buf))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetJIDFromStoreReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetJIDFromStoreError(model.Error)
        return model.Jid

    def get_pn_from_lid(self, jid: JID) -> JID:
        """Retrieves the matching jid from the supplied lid.

        :param jid: The JID (Jabber Identifier) (lid) of the target user.
        :type jid: JID
        :raises GetJIDFromStoreError: Raised if there is an issue getting the jid from the given lid.
        :return: The jid (phone number) matching the supplied lid.
        :rtype: JID
        """
        jid_buf = jid.SerializeToString()
        bytes_ptr = self.__client.GetPNFromLID(self.uuid, jid_buf, len(jid_buf))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetJIDFromStoreReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetJIDFromStoreError(model.Error)
        return model.Jid

    def pin_message(
        self, chat_jid: JID, sender_jid: JID, message_id: str, seconds: int
    ):
        """
        Currently Non-functional
        """
        chat_buf = chat_jid.SerializeToString()
        sender_buf = sender_jid.SerializeToString()
        bytes_ptr = self.__client.PinMessage(
            self.uuid,
            chat_buf,
            len(chat_buf),
            sender_buf,
            len(sender_buf),
            message_id.encode(),
            seconds,
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = SendMessageReturnFunction.FromString(protobytes)
        if model.Error:
            raise SendMessageError(model.Error)
        return model.SendResponse

    def leave_group(self, jid: JID) -> str:
        """Leaves a group.

        :param jid: The JID (Jabber Identifier) of the target group.
        :type jid: JID
        :return: A string indicating the result or an error status. Empty string if successful.
        :rtype: str
        """
        jid_buf = jid.SerializeToString()
        return self.__client.LeaveGroup(self.uuid, jid_buf, len(jid_buf)).decode()

    def get_group_invite_link(self, jid: JID, revoke: bool = False) -> str:
        """Gets or revokes the invite link for a group.

        :param jid: The JID (Jabber Identifier) of the group.
        :type jid: JID
        :param revoke: Optional. If True, revokes the existing invite link; if False, gets the invite link. Defaults to False.
        :type revoke: bool, optional
        :raises GetGroupInviteLinkError: Raised if there is an issue getting or revoking the invite link.
        :return: The group invite link or an error status.
        :rtype: str
        """
        jid_buf = jid.SerializeToString()
        bytes_ptr = self.__client.GetGroupInviteLink(
            self.uuid, jid_buf, len(jid_buf), revoke
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetGroupInviteLinkReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetGroupInviteLinkError(model.Error)
        return model.InviteLink

    def join_group_with_link(self, code: str) -> JID:
        """Join a group using an invite link.

        :param code: The invite code or link for joining the group.
        :type code: str
        :raises InviteLinkError: Raised if the group membership is pending approval or if the link is invalid.
        :return: The JID (Jabber Identifier) of the joined group.
        :rtype: JID
        """
        bytes_ptr = self.__client.JoinGroupWithLink(self.uuid, code.encode())
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = JoinGroupWithLinkReturnFunction.FromString(protobytes)
        if model.Error:
            raise InviteLinkError(model.Error)
        return model.Jid

    def join_group_with_invite(
        self, jid: JID, inviter: JID, code: str, expiration: int
    ):
        """
        This function allows a user to join a group in a chat application using an invite.
        It uses the JID (Jabber ID) of the group, the JID of the inviter, an invitation code, and an expiration time for the code.

        :param jid: The JID of the group to join.
        :type jid: JID
        :param inviter: The JID of the person who sent the invite.
        :type inviter: JID
        :param code: The invitation code.
        :type code: str
        :param expiration: The expiration time of the invitation code.
        :type expiration: int
        :raises JoinGroupWithInviteError: If there is an error in joining the group, such as an invalid code or expired invitation.
        """
        jidbytes = jid.SerializeToString()
        inviterbytes = inviter.SerializeToString()
        err = self.__client.JoinGroupWithInvite(
            self.uuid,
            jidbytes,
            len(jidbytes),
            inviterbytes,
            len(inviterbytes),
            code.encode(),
            expiration,
        ).decode()
        if err:
            raise JoinGroupWithInviteError(err)

    def link_group(self, parent: JID, child: JID):
        """
        Links a child group to a parent group.

        :param parent: The JID of the parent group
        :type parent: JID
        :param child: The JID of the child group
        :type child: JID
        :raises LinkGroupError: If there is an error while linking the groups
        """
        parent_bytes = parent.SerializeToString()
        child_bytes = child.SerializeToString()
        err = self.__client.LinkGroup(
            self.uuid, parent_bytes, len(parent_bytes), child_bytes, len(child_bytes)
        ).decode()
        if err:
            raise LinkGroupError(err)

    def logout(self):
        err = self.__client.Logout(self.uuid).decode()
        if err:
            raise LogoutError(err)

    def mark_read(
        self,
        *message_ids: str,
        chat: JID,
        sender: JID,
        receipt: ReceiptType,
        timestamp: Optional[int] = None,
    ):
        """Marks the specified messages as read.

        :param message_ids: Identifiers of the messages to mark as read.
        :type message_ids: str
        :param chat: The JID of the chat.
        :type chat: JID
        :param sender: The JID of the sender.
        :type sender: JID
        :param receipt: The type of receipt indicating the message status.
        :type receipt: ReceiptType
        :param timestamp: The timestamp of the read action, defaults to None.
        :type timestamp: Optional[int], optional
        :raises MarkReadError: If there is an error marking messages as read.
        """
        chat_proto = chat.SerializeToString()
        sender_proto = sender.SerializeToString()
        timestamp_args = int(time.time()) if timestamp is None else timestamp
        err = self.__client.MarkRead(
            self.uuid,
            " ".join(message_ids).encode(),
            timestamp_args,
            chat_proto,
            len(chat_proto),
            sender_proto,
            len(sender_proto),
            receipt.value,
        )
        if err:
            raise MarkReadError(err.decode())

    def newsletter_mark_viewed(
        self, jid: JID, message_server_ids: List[MessageServerID]
    ):
        """
        Marks the specified newsletters as viewed by the user with the given JID.

        :param jid: The JID (Jabber ID) of the user who has viewed the newsletters.
        :type jid: JID
        :param message_server_ids: List of server IDs of the newsletters that have been viewed.
        :type message_server_ids: List[MessageServerID]
        :raises NewsletterMarkViewedError: If an error occurs while marking the newsletters as viewed.
        """
        servers = struct.pack(f"{len(message_server_ids)}b", *message_server_ids)
        jid_proto = jid.SerializeToString()
        err = self.__client.NewsletterMarkViewed(
            self.uuid, jid_proto, len(jid_proto), servers, len(servers)
        )
        if err:
            raise NewsletterMarkViewedError(err)

    def newsletter_send_reaction(
        self,
        jid: JID,
        message_server_id: MessageServerID,
        reaction: str,
        message_id: str,
    ):
        """
        Sends a reaction to a newsletter.

        :param jid: The unique identifier for the recipient of the newsletter.
        :type jid: JID
        :param message_server_id: The unique identifier for the server where the message is stored.
        :type message_server_id: MessageServerID
        :param reaction: The reaction to be sent.
        :type reaction: str
        :param message_id: The unique identifier for the message to which the reaction is being sent.
        :type message_id: str
        :raises NewsletterSendReactionError: If an error occurs while sending the reaction.
        """
        jid_proto = jid.SerializeToString()
        err = self.__client.NewsletterSendReaction(
            self.uuid,
            jid_proto,
            len(jid_proto),
            message_server_id,
            reaction.encode(),
            message_id.encode(),
        )
        if err:
            raise NewsletterSendReactionError(err)
        return

    def newsletter_subscribe_live_updates(self, jid: JID) -> int:
        """Subscribes a user to live updates of a newsletter.

        :param jid: The unique identifier of the user subscribing to the newsletter.
        :type jid: JID
        :raises NewsletterSubscribeLiveUpdatesError: If there is an error during the subscription process.
        :return: The duration for which the subscription is valid.
        :rtype: int
        """
        jid_proto = jid.SerializeToString()
        bytes_ptr = self.__client.NewsletterSubscribeLiveUpdates(
            self.uuid, jid_proto, len(jid_proto)
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.NewsletterSubscribeLiveUpdatesReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise NewsletterSubscribeLiveUpdatesError(model.Error)
        return model.Duration

    def newsletter_toggle_mute(self, jid: JID, mute: bool):
        """Toggle the mute status of a given JID.

        :param jid: The JID (Jabber Identifier) of the user.
        :type jid: JID
        :param mute: The desired mute status. If True, the user will be muted. If False, the user will be unmuted.
        :type mute: bool
        :raises NewsletterToggleMuteError: If there is an error while toggling the mute status.
        """
        jid_proto = jid.SerializeToString()
        err = self.__client.NewsletterToggleMute(
            self.uuid, jid_proto, len(jid_proto), mute
        ).decode()
        if err:
            raise NewsletterToggleMuteError(err)

    def resolve_business_message_link(
        self, code: str
    ) -> neonize_proto.BusinessMessageLinkTarget:
        """Resolves the target of a business message link.

        :param code: The code of the business message link to be resolved.
        :type code: str
        :raises ResolveContactQRLinkError: If an error occurs while resolving the link.
        :return: The target of the business message link.
        :rtype: neonize_proto.BusinessMessageLinkTarget
        """
        bytes_ptr = self.__client.ResolveBusinessMessageLink(self.uuid, code.encode())
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.ResolveBusinessMessageLinkReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise ResolveContactQRLinkError(model.Error)
        return model.MessageLinkTarget

    def resolve_contact_qr_link(self, code: str) -> neonize_proto.ContactQRLinkTarget:
        """Resolves a QR link for a specific contact.

        :param code: The QR code to be resolved.
        :type code: str
        :raises ResolveContactQRLinkError: If an error occurs while resolving the QR link.
        :return: The target contact of the QR link.
        :rtype: neonize_proto.ContactQRLinkTarget
        """
        bytes_ptr = self.__client.ResolveContactQRLink(self.uuid, code.encode())
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.ResolveContactQRLinkReturnFunction.FromString(protobytes)
        if model.Error:
            raise ResolveContactQRLinkError(model.Error)
        return model.ContactQrLink

    def send_app_state(self, patch_info: neonize_proto.PatchInfo):
        """
        This function serializes the application state and sends it to the client. If there's an error during this process,
        it raises a SendAppStateError exception.

        :param patch_info: Contains the information about the application state that needs to be patched.
        :type patch_info: neonize_proto.PatchInfo
        :raises SendAppStateError: If there's an error while sending the application state, this exception is raised.
        """
        patch = patch_info.SerializeToString()
        err = self.__client.SendAppState(self.uuid, patch, len(patch)).decode()
        if err:
            raise SendAppStateError(err)

    def set_default_disappearing_timer(self, timer: typing.Union[timedelta, int]):
        """
        Sets a default disappearing timer for messages. The timer can be specified as a timedelta or an integer.
        If a timedelta is provided, it is converted to nanoseconds. If an integer is provided, it is used directly as the timer.

        :param timer: The duration for messages to exist before disappearing. Can be a timedelta or an integer.
        :type timer: typing.Union[timedelta, int]
        :raises SetDefaultDisappearingTimerError: If an error occurs while setting the disappearing timer.
        """
        timestamp = 0
        if isinstance(timer, timedelta):
            timestamp = int(timer.total_seconds() * 1000**3)
        else:
            timestamp = timer
        err = self.__client.SetDefaultDisappearingTimer(self.uuid, timestamp).decode()
        if err:
            raise SetDefaultDisappearingTimerError(err)

    def set_disappearing_timer(self, jid: JID, timer: typing.Union[timedelta, int]):
        """
        Set a disappearing timer for a specific JID. The timer can be set as either a timedelta object or an integer.
        If a timedelta object is provided, it's converted into nanoseconds. If an integer is provided, it's interpreted as nanoseconds.

        :param jid: The JID for which the disappearing timer is to be set
        :type jid: JID
        :param timer: The duration for the disappearing timer. Can be a timedelta object or an integer representing nanoseconds.
        :type timer: typing.Union[timedelta, int]
        :raises SetDisappearingTimerError: If there is an error in setting the disappearing timer
        """
        timestamp = 0
        jid_proto = jid.SerializeToString()
        if isinstance(timer, timedelta):
            timestamp = int(timer.total_seconds() * 1000**3)
        else:
            timestamp = timer
        err = self.__client.SetDisappearingTimer(
            self.uuid, jid_proto, len(jid_proto), timestamp
        ).decode()
        if err:
            raise SetDisappearingTimerError(err)

    def set_force_activate_delivery_receipts(self, active: bool):
        """
        This method is used to forcibly activate or deactivate the delivery receipts for a client.

        :param active: This parameter determines whether the delivery receipts should be forcibly activated or deactivated. If it's True, the delivery receipts will be forcibly activated, otherwise, they will be deactivated.
        :type active: bool
        """
        self.__client.SetForceActiveDeliveryReceipts(self.uuid, active)

    def set_group_announce(self, jid: JID, announce: bool):
        """
        Sets the announcement status of a group.

        :param jid: The unique identifier of the group
        :type jid: JID
        :param announce: The announcement status to be set. If True, announcements are enabled. If False, they are disabled.
        :type announce: bool
        :raises SetGroupAnnounceError: If there is an error while setting the announcement status
        """
        jid_proto = jid.SerializeToString()
        err = self.__client.SetGroupAnnounce(
            self.uuid, jid_proto, len(jid_proto), announce
        ).decode()
        if err:
            raise SetGroupAnnounceError(err)

    def set_group_locked(self, jid: JID, locked: bool):
        """
        Sets the locked status of a group identified by the given JID.

        :param jid: The JID (Jabber ID) of the group to be locked/unlocked.
        :type jid: JID
        :param locked: The new locked status of the group. True to lock the group, False to unlock.
        :type locked: bool
        :raises SetGroupLockedError: If the operation fails, an error with the reason for the failure is raised.
        """
        jid_proto = jid.SerializeToString()
        err = self.__client.SetGroupLocked(
            self.uuid, jid_proto, len(jid_proto), locked
        ).decode()
        if err:
            raise SetGroupLockedError(err)

    def set_group_topic(self, jid: JID, previous_id: str, new_id: str, topic: str):
        """
        Set the topic of a group in a chat application.

        :param jid: The unique identifier of the group
        :type jid: JID
        :param previous_id: The previous identifier of the topic
        :type previous_id: str
        :param new_id: The new identifier for the topic
        :type new_id: str
        :param topic: The new topic to be set
        :type topic: str
        :raises SetGroupTopicError: If there is an error setting the group topic
        """
        jid_proto = jid.SerializeToString()
        err = self.__client.SetGroupTopic(
            self.uuid,
            jid_proto,
            len(jid_proto),
            previous_id.encode(),
            new_id.encode(),
            topic.encode(),
        ).decode()
        if err:
            raise SetGroupTopicError(err)

    def set_privacy_setting(self, name: PrivacySettingType, value: PrivacySetting):
        """
        This method is used to set the privacy settings of a user.

        :param name: The name of the privacy setting to be changed.
        :type name: PrivacySettingType
        :param value: The new value for the privacy setting.
        :type value: PrivacySetting
        :raises SetPrivacySettingError: If there is an error while setting the privacy setting.
        """
        err = self.__client.SetPrivacySetting(
            self.uuid, name.value.encode(), value.value.encode()
        ).decode()
        if err:
            raise SetPrivacySettingError(err)

    def set_passive(self, passive: bool):
        """
        Sets the passive mode of the client.

        :param passive: If True, sets the client to passive mode. If False, sets the client to active mode.
        :type passive: bool
        :raises SetPassiveError: If an error occurs while setting the client to passive mode.
        """
        err = self.__client.SetPassive(self.uuid, passive)
        if err:
            raise SetPassiveError(err)

    def set_status_message(self, msg: str):
        """
        Sets a status message for a client using the client's UUID.

        :param msg: The status message to be set.
        :type msg: str
        :raises SetStatusMessageError: If there is an error while setting the status message.
        """
        err = self.__client.SetStatusMessage(self.uuid, msg.encode()).decode()
        if err:
            raise SetStatusMessageError(err)

    def subscribe_presence(self, jid: JID):
        """
        This method is used to subscribe to the presence of a certain JID (Jabber ID).

        :param jid: The Jabber ID (JID) that we want to subscribe to.
        :type jid: JID
        :raises SubscribePresenceError: If there is an error while subscribing to the presence of the JID.
        """
        jid_proto = jid.SerializeToString()
        err = self.__client.SubscribePresence(
            self.uuid, jid_proto, len(jid_proto)
        ).decode()
        if err:
            raise SubscribePresenceError(err)

    def unfollow_newsletter(self, jid: JID):
        """
        Unfollows a newsletter by providing the JID (Jabber ID) of the newsletter.

        :param jid: The Jabber ID of the newsletter to unfollow.
        :type jid: JID
        :raises UnfollowNewsletterError: If there is an error while attempting to unfollow the newsletter.
        """
        jid_proto = jid.SerializeToString()
        err = self.__client.UnfollowNewsletter(
            self.uuid, jid_proto, len(jid_proto)
        ).decode()
        if err:
            raise UnfollowNewsletterError(err)

    def unlink_group(self, parent: JID, child: JID):
        """
        This method is used to unlink a child group from a parent group.

        :param parent: The JID of the parent group from which the child group is to be unlinked.
        :type parent: JID
        :param child: The JID of the child group which is to be unlinked from the parent group.
        :type child: JID
        :raises UnlinkGroupError: If there is an error while unlinking the child group from the parent group.
        """
        parent_proto = parent.SerializeToString()
        child_proto = child.SerializeToString()
        err = self.__client.UnlinkGroup(
            self.uuid, parent_proto, len(parent_proto), child_proto, len(child_proto)
        ).decode()
        if err:
            raise UnlinkGroupError(err)

    def update_blocklist(self, jid: JID, action: BlocklistAction) -> Blocklist:
        """
        Function to update the blocklist with a given action on a specific JID.

        :param jid: The Jabber ID (JID) of the user to be blocked or unblocked.
        :type jid: JID
        :param action: The action to be performed (block or unblock) on the JID.
        :type action: BlocklistAction
        :raises UpdateBlocklistError: If there is an error while updating the blocklist.
        :return: The updated blocklist.
        :rtype: Blocklist
        """
        jid_proto = jid.SerializeToString()
        bytes_ptr = self.__client.UpdateBlocklist(
            self.uuid, jid_proto, len(jid_proto), action.value.encode()
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetBlocklistReturnFunction.FromString(protobytes)
        if model.Error:
            raise UpdateBlocklistError(model.Error)
        return model.Blocklist

    def update_group_participants(
        self, jid: JID, participants_changes: List[JID], action: ParticipantChange
    ) -> RepeatedCompositeFieldContainer[GroupParticipant]:
        """
        This method is used to update the list of participants in a group.
        It takes in the group's JID, a list of participant changes, and an action to perform.

        :param jid: The JID (Jabber ID) of the group to update.
        :type jid: JID
        :param participants_changes: A list of JIDs representing the participants to be added or removed.
        :type participants_changes: List[JID]
        :param action: The action to perform (add, remove, promote or demote participants).
        :type action: ParticipantChange
        :raises UpdateGroupParticipantsError: This error is raised if there is a problem updating the group participants.
        :return: A list of the updated group participants.
        :rtype: RepeatedCompositeFieldContainer[GroupParticipant]
        """
        jid_proto = jid.SerializeToString()
        jids_proto = neonize_proto.JIDArray(
            JIDS=participants_changes
        ).SerializeToString()
        bytes_ptr = self.__client.UpdateGroupParticipants(
            self.uuid,
            jid_proto,
            len(jid_proto),
            jids_proto,
            len(jids_proto),
            action.value.encode(),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.UpdateGroupParticipantsReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise UpdateGroupParticipantsError(model.Error)
        return model.participants

    def upload_newsletter(self, data: bytes, media_type: MediaType) -> UploadResponse:
        """Uploads the newsletter to the server.

        :param data: The newsletter content in bytes.
        :type data: bytes
        :param media_type: The type of media being uploaded.
        :type media_type: MediaType
        :raises UploadError: If there is an error during the upload process.
        :return: The response from the server after the upload.
        :rtype: UploadResponse
        """
        bytes_ptr = self.__client.UploadNewsletter(
            self.uuid, data, len(data), media_type.value
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = UploadReturnFunction.FromString(protobytes)
        if model.Error:
            raise UploadError(model.Error)
        return model.UploadResponse

    def create_group(
        self,
        name: str,
        participants: List[JID] = [],
        linked_parent: Optional[GroupLinkedParent] = None,
        group_parent: Optional[GroupParent] = None,
    ) -> GroupInfo:
        """Create a new group.

        :param name: The name of the new group.
        :type name: str
        :param participants: Optional. A list of participant JIDs (Jabber Identifiers) to be included in the group. Defaults to an empty list.
        :type participants: List[JID], optional
        :param linked_parent: Optional. Information about a linked parent group, if applicable. Defaults to None.
        :type linked_parent: Optional[GroupLinkedParent], optional
        :param group_parent: Optional. Information about a parent group, if applicable. Defaults to None.
        :type group_parent: Optional[GroupParent], optional
        :return: Information about the newly created group.
        :rtype: GroupInfo
        """
        group_info = ReqCreateGroup(
            name=name, Participants=participants, CreateKey=self.generate_message_id()
        )
        if linked_parent:
            group_info.GroupLinkedParent.MergeFrom(linked_parent)
        if group_parent:
            group_info.GroupParent.MergeFrom(group_parent)
        group_info_buf = group_info.SerializeToString()
        bytes_ptr = self.__client.CreateGroup(
            self.uuid, group_info_buf, len(group_info_buf)
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = GetGroupInfoReturnFunction.FromString(protobytes)
        if model.Error:
            raise CreateGroupError(model.Error)
        return model.GroupInfo

    def get_group_request_participants(
        self, jid: JID
    ) -> RepeatedCompositeFieldContainer[GroupParticipantRequest]:
        """Get the participants of a group request.

        :param jid: The JID of the group request.
        :type jid: JID
        :return: A list of JIDs representing the participants of the group request.
        :rtype: RepeatedCompositeFieldContainer[JID]
        """
        jidbyte = jid.SerializeToString()
        bytes_ptr = self.__client.GetGroupRequestParticipants(
            self.uuid, jidbyte, len(jidbyte)
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetGroupRequestParticipantsReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise GetGroupRequestParticipantsError(model.Error)
        return model.Participants

    def get_joined_groups(self) -> RepeatedCompositeFieldContainer[GroupInfo]:
        """Get the joined groups for the current user.

        :return: A list of :class:`GroupInfo` objects representing the joined groups.
        :rtype: RepeatedCompositeFieldContainer[GroupInfo]

        :raises GetJoinedGroupsError: If there was an error retrieving the joined groups.
        """
        bytes_ptr = self.__client.GetJoinedGroups(self.uuid)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetJoinedGroupsReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetJoinedGroupsError(model.Error)
        return model.Group

    def create_newsletter(
        self, name: str, description: str, picture: typing.Union[str, bytes]
    ) -> NewsletterMetadata:
        """Create a newsletter with the given name, description, and picture.

        :param name: The name of the newsletter.
        :type name: str
        :param description: The description of the newsletter.
        :type description: str
        :param picture: The picture of the newsletter. It can be either a URL or bytes.
        :type picture: Union[str, bytes]
        :return: The metadata of the created newsletter.
        :rtype: NewsletterMetadata
        :raises CreateNewsletterError: If there is an error creating the newsletter.
        """
        protobuf = neonize_proto.CreateNewsletterParams(
            Name=name,
            Description=description,
            Picture=get_bytes_from_name_or_url(picture),
        ).SerializeToString()
        bytes_ptr = self.__client.CreateNewsletter(self.uuid, protobuf, len(protobuf))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.CreateNewsLetterReturnFunction.FromString(protobytes)
        if model.Error:
            raise CreateNewsletterError(model.Error)
        return model.NewsletterMetadata

    def follow_newsletter(self, jid: JID):
        """Follows a newsletter with the given JID.

        :param jid: The JID of the newsletter to follow.
        :type jid: JID
        :return: None
        :rtype: None
        :raises FollowNewsletterError: If there is an error following the newsletter.
        """

        jidbyte = jid.SerializeToString()
        err = self.__client.FollowNewsletter(self.uuid, jidbyte, len(jidbyte)).decode()
        if err:
            raise FollowNewsletterError(err)

    def get_newsletter_info_with_invite(self, key: str) -> NewsletterMetadata:
        """Retrieves the newsletter information with an invite using the provided key.

        :param key: The key used to identify the newsletter.
        :type key: str
        :return: The newsletter metadata.
        :rtype: NewsletterMetadata
        :raises GetNewsletterInfoWithInviteError: If there is an error retrieving the newsletter information.
        """
        bytes_ptr = self.__client.GetNewsletterInfoWithInvite(self.uuid, key.encode())
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.CreateNewsLetterReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetNewsletterInfoWithInviteError(model.Error)
        return model.NewsletterMetadata

    def get_newsletter_message_update(
        self, jid: JID, count: int, since: int, after: int
    ) -> RepeatedCompositeFieldContainer[NewsletterMessage]:
        """Retrieves a list of newsletter messages that have been updated since a given timestamp.

        :param jid: The JID (Jabber ID) of the user.
        :type jid: JID
        :param count: The maximum number of messages to retrieve.
        :type count: int
        :param since: The timestamp (in milliseconds) to retrieve messages from.
        :type since: int
        :param after: The timestamp (in milliseconds) to retrieve messages after.
        :type after: int

        :return: A list of updated newsletter messages.
        :rtype: RepeatedCompositeFieldContainer[NewsletterMessage]

        :raises GetNewsletterMessageUpdateError: If there was an error retrieving the newsletter messages.
        """
        jidbyte = jid.SerializeToString()
        bytes_ptr = self.__client.GetNewsletterMessageUpdate(
            self.uuid, jidbyte, len(jidbyte), count, since, after
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetNewsletterMessageUpdateReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise GetNewsletterMessageUpdateError(model.Error)
        return model.NewsletterMessage

    def get_newsletter_messages(
        self, jid: JID, count: int, before: MessageServerID
    ) -> RepeatedCompositeFieldContainer[NewsletterMessage]:
        """Retrieves a list of newsletter messages for a given JID.

        :param jid: The JID (Jabber Identifier) of the user.
        :type jid: JID
        :param count: The maximum number of messages to retrieve.
        :type count: int
        :param before: The ID of the message before which to retrieve messages.
        :type before: MessageServerID
        :return: A list of newsletter messages.
        :rtype: RepeatedCompositeFieldContaine[NewsletterMessage]
        """
        jidbyte = jid.SerializeToString()
        bytes_ptr = self.__client.GetNewsletterMessages(
            self.uuid, jidbyte, len(jidbyte), count, before
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetNewsletterMessageUpdateReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise GetNewsletterMessagesError(model.Error)
        return model.NewsletterMessage

    def get_privacy_settings(self) -> PrivacySettings:
        """
        This function retrieves the my privacy settings.

        :return: privacy settings
        :rtype: PrivacySettings
        """
        bytes_ptr = self.__client.GetPrivacySettings(self.uuid)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        result = neonize_proto.PrivacySettings.FromString(protobytes)
        return result

    def get_profile_picture(
        self,
        jid: JID,
        extra: neonize_proto.GetProfilePictureParams = neonize_proto.GetProfilePictureParams(),
    ) -> ProfilePictureInfo:
        """
        This function is used to get the profile picture of a user.

        :param jid: The unique identifier of the user whose profile picture we want to retrieve.
        :type jid: JID
        :param extra: Additional parameters, defaults to neonize_proto.GetProfilePictureParams()
        :type extra: neonize_proto.GetProfilePictureParams, optional
        :raises GetProfilePictureError: If there is an error while trying to get the profile picture.
        :return: The information about the profile picture.
        :rtype: ProfilePictureInfo
        """
        jid_bytes = jid.SerializeToString()
        extra_bytes = extra.SerializeToString()
        bytes_ptr = self.__client.GetProfilePicture(
            self.uuid,
            jid_bytes,
            len(jid_bytes),
            extra_bytes,
            len(extra_bytes),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetProfilePictureReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetProfilePictureError(model)
        return model.Picture

    def get_status_privacy(
        self,
    ) -> RepeatedCompositeFieldContainer[StatusPrivacy]:
        """Returns the status privacy settings of the user.

        :raises GetStatusPrivacyError: If there is an error in getting the status privacy.
        :return: The status privacy settings of the user.
        :rtype: RepeatedCompositeFieldContainer[StatusPrivacy]
        """
        bytes_ptr = self.__client.GetStatusPrivacy(self.uuid)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetStatusPrivacyReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetStatusPrivacyError(model.Error)
        return model.StatusPrivacy

    def get_sub_groups(
        self, community: JID
    ) -> RepeatedCompositeFieldContainer[GroupLinkTarget]:
        """
        Get the subgroups of a given community.

        :param community: The community for which to get the subgroups.
        :type community: JID
        :raises GetSubGroupsError: If there is an error while getting the subgroups.
        :return: The subgroups of the given community.
        :rtype: RepeatedCompositeFieldContainer[GroupLinkTarget]
        """
        jid = community.SerializeToString()
        bytes_ptr = self.__client.GetSubGroups(self.uuid, jid, len(jid))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetSubGroupsReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetSubGroupsError(model.Error)
        return model.GroupLinkTarget

    def get_subscribed_newletters(
        self,
    ) -> RepeatedCompositeFieldContainer[NewsletterMetadata]:
        """
        This function retrieves the newsletters the user has subscribed to.

        :raises GetSubscribedNewslettersError: If there is an error while fetching the subscribed newsletters
        :return: A container with the metadata of each subscribed newsletter
        :rtype: RepeatedCompositeFieldContainer[NewsletterMetadata]
        """
        bytes_ptr = self.__client.GetSubscribedNewsletters(self.uuid)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetSubscribedNewslettersReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise GetSubscribedNewslettersError(model.Error)
        return model.Newsletter

    def get_user_devices(self, *jids: JID) -> RepeatedCompositeFieldContainer[JID]:
        """
        Retrieve devices associated with specified user JIDs.

        :param jids: Variable number of JIDs (Jabber Identifiers) of users.
        :type jids: JID
        :raises GetUserDevicesError: If there is an error retrieving user devices.
        :return: Devices associated with the specified user JIDs.
        :rtype: RepeatedCompositeFieldContainer[JID]
        """
        jids_ = neonize_proto.JIDArray(JIDS=jids).SerializeToString()
        bytes_ptr = self.__client.GetUserDevices(self.uuid, jids_, len(jids_))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetUserDevicesreturnFunction.FromString(protobytes)
        if model.Error:
            raise GetUserDevicesError(model.Error)
        return model.JID

    def get_blocklist(self) -> Blocklist:
        """Retrieves the blocklist from the client.

        :return: Blocklist: The retrieved blocklist.
        :raises GetBlocklistError: If there was an error retrieving the blocklist.
        """
        bytes_ptr = self.__client.GetBlocklist(self.uuid)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetBlocklistReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetBlocklistError(model.Error)
        return model.Blocklist

    def get_me(self) -> Device:
        """
        This method is used to get the device information associated with a given UUID.

        :return: It returns a Device object created from the byte string response from the client's GetMe method.
        :rtype: Device
        """
        bytes_ptr = self.__client.GetMe(self.uuid)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        result = Device.FromString(protobytes)
        return result

    def get_contact_qr_link(self, revoke: bool = False) -> str:
        """
        This function returns a QR link for a specific contact. If the 'revoke' parameter is set to True,
        it revokes the existing QR link and generates a new one.

        :param revoke: If set to True, revokes the existing QR link and generates a new one. Defaults to False.
        :type revoke: bool, optional
        :raises GetContactQrLinkError: If there is an error in getting the QR link.
        :return: The QR link for the contact.
        :rtype: str
        """
        bytes_ptr = self.__client.GetContactQRLink(self.uuid, revoke)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetContactQRLinkReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetContactQrLinkError(model.Error)
        return model.Link

    def get_linked_group_participants(
        self, community: JID
    ) -> RepeatedCompositeFieldContainer[GroupParticipantRequest]:
        """Fetches the participants of a linked group in a community.

        :param community: The community in which the linked group belongs.
        :type community: JID
        :raises GetLinkedGroupParticipantsError: If there is an error while fetching the participants.
        :return: A list of participants in the linked group.
        :rtype: RepeatedCompositeFieldContainer[JID]
        """
        jidbyte = community.SerializeToString()
        bytes_ptr = self.__client.GetLinkedGroupsParticipants(
            self.uuid, jidbyte, len(jidbyte)
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetGroupRequestParticipantsReturnFunction.FromString(
            protobytes
        )
        if model.Error:
            raise GetLinkedGroupParticipantsError(model.Error)
        return model.Participants

    def get_newsletter_info(self, jid: JID) -> neonize_proto.NewsletterMetadata:
        """
        Fetches the metadata of a specific newsletter using its JID.

        :param jid: The unique identifier of the newsletter
        :type jid: JID
        :raises GetNewsletterInfoError: If there is an error while fetching the newsletter information
        :return: The metadata of the requested newsletter
        :rtype: neonize_proto.NewsletterMetadata
        """
        jidbyte = jid.SerializeToString()
        bytes_ptr = self.__client.GetNewsletterInfo(self.uuid, jidbyte, len(jidbyte))
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.CreateNewsLetterReturnFunction.FromString(protobytes)
        if model.Error:
            raise GetNewsletterInfoError(model.Error)
        return model.NewsletterMetadata

    def PairPhone(
        self,
        phone: str,
        show_push_notification: bool,
        client_name: ClientName = ClientName.LINUX,
        client_type: Optional[ClientType] = None,
    ):
        """
        Pair a phone with the client. This function will try to connect to the WhatsApp servers and pair the phone.
        If successful, it will show a push notification on the paired phone.

        :param phone: The phone number to be paired.
        :type phone: str
        :param show_push_notification: If true, a push notification will be shown on the paired phone.
        :type show_push_notification: bool
        :param client_name: The name of the client, defaults to LINUX.
        :type client_name: ClientName, optional
        :param client_type: The type of the client, defaults to None. If None, it will be set to FIREFOX or determined by the device properties.
        :type client_type: Optional[ClientType], optional
        """

        if client_type is None:
            if self.device_props is None:
                client_type = ClientType.FIREFOX
            else:
                try:
                    client_type = ClientType(self.device_props.platformType)
                except ValueError:
                    client_type = ClientType.FIREFOX

        pl = neonize_proto.PairPhoneParams(
            phone=phone,
            clientDisplayName="%s (%s)" % (client_type.name, client_name.name),
            clientType=client_type.value,
            showPushNotification=show_push_notification,
        )
        payload = pl.SerializeToString()
        d = bytearray(list(self.event.list_func))

        _log_.debug("trying connect to whatsapp servers")

        deviceprops = (
            DeviceProps(os="Neonize", platformType=DeviceProps.SAFARI)
            if self.device_props is None
            else self.device_props
        ).SerializeToString()

        jidbuf_size = 0
        jidbuf = b""
        if self.jid:
            jidbuf = self.jid.SerializeToString()
            jidbuf_size = len(jidbuf)

        self.__client.Neonize(
            self.name.encode(),
            self.uuid,
            jidbuf,
            jidbuf_size,
            LogLevel.from_logging(log.level).level,
            func_string(self.__onQr),
            func_string(self.__onLoginStatus),
            func_callback_bytes(self.event.execute),
            func_callback_bytes2(log_whatsmeow),
            (ctypes.c_char * self.event.list_func.__len__()).from_buffer(d),
            len(d),
            deviceprops,
            len(deviceprops),
            payload,
            len(payload),
        )

    def stop(self):
        """
        Stops the client by disconnecting it from the WhatsApp servers.
        """
        _log_.debug("Stopping client and disconnecting from WhatsApp servers.")
        self.__client.stop()

    def get_message_for_retry(
        self, requester: JID, to: JID, message_id: str
    ) -> typing.Union[None, Message]:
        """
        This function retrieves a specific message for retrying transmission.
        It communicates with a client to get the message using provided requester, recipient, and message ID.

        :param requester: The JID of the entity requesting the message.
        :type requester: JID
        :param to: The JID of the intended recipient of the message.
        :type to: JID
        :param message_id: The unique identifier of the message to be retrieved.
        :type message_id: str
        :return: The message to be retried if found, None otherwise.
        :rtype: Union[None, Message]
        """
        requester_buf = requester.SerializeToString()
        to_buf = to.SerializeToString()
        bytes_ptr = self.__client.GetMessageForRetry(
            self.uuid,
            requester_buf,
            len(requester_buf),
            to_buf,
            len(to_buf),
            message_id.encode(),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = neonize_proto.GetMessageForRetryReturnFunction.FromString(protobytes)
        if model.Error:
            raise Exception(model.Error)
        if not model.isEmpty:
            return model.Message

    def send_fb_message(
        self,
        to: JID,
        message: ConsumerApplication,
        metadata: MessageApplication.Metadata,
        extra: SendRequestExtra,
    ):
        to_buff = to.SerializeToString()
        message_buff = message.SerializeToString()
        metadata_buff = metadata.SerializeToString()
        extra_buff = extra.SerializeToString()
        bytes_ptr = self.__client.SendFBMessage(
            self.uuid,
            to_buff,
            len(to_buff),
            message_buff,
            len(message_buff),
            metadata_buff,
            len(metadata_buff),
            extra_buff,
            len(extra_buff),
        )
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        result = SendMessageReturnFunction.FromString(protobytes)
        if result.Error:
            raise SendMessageError(result.Error)

    def send_presence(self, presence: Presence):
        response = self.__client.SendPresence(self.uuid, presence.value)
        if response:
            raise SendPresenceError(response)

    def decrypt_poll_vote(self, message: neonize_proto.Message) -> PollVoteMessage:
        """Decrypt PollMessage"""
        msg_buff = message.SerializeToString()
        bytes_ptr = self.__client.DecryptPollVote(self.uuid, msg_buff)
        protobytes = bytes_ptr.contents.get_bytes()
        free_bytes(bytes_ptr)
        model = ReturnFunctionWithError.FromString(protobytes)
        if model.Error:
            raise DecryptPollVoteError(model.Error)
        return model.PollVoteMessage

    def connect(self):
        """Establishes a connection to the WhatsApp servers."""
        # Convert the list of functions to a bytearray
        d = bytearray(list(self.event.list_func))
        _log_.debug("🔒 Attempting to connect to the WhatsApp servers.")
        # Set device properties
        deviceprops = (
            DeviceProps(os="Neonize", platformType=DeviceProps.SAFARI)
            if self.device_props is None
            else self.device_props
        ).SerializeToString()

        jidbuf_size = 0
        jidbuf = b""
        if self.jid:
            jidbuf = self.jid.SerializeToString()
            jidbuf_size = len(jidbuf)

        # Initiate connection to the server
        self.__client.Neonize(
            self.name.encode(),
            self.uuid,
            jidbuf,
            jidbuf_size,
            LogLevel.from_logging(log.level).level,
            func_string(self.__onQr),
            func_string(self.__onLoginStatus),
            func_callback_bytes(self.event.execute),
            func_callback_bytes2(log_whatsmeow),
            (ctypes.c_char * len(self.event.list_func)).from_buffer(d),
            len(d),
            deviceprops,
            len(deviceprops),
            b"",
            0,
        )

    def disconnect(self) -> None:
        """
        Disconnect the client
        """
        self.__client.Disconnect(self.uuid)


class ClientFactory:
    def __init__(self, database_name: str = "neonize.db") -> None:
        """
        This class is used to create new instances of the client.
        """
        self.database_name = database_name
        self.clients: list[NewClient] = []
        self.event = EventsManager(self)

    @staticmethod
    def get_all_devices_from_db(db: str) -> List[Device]:
        """
        Retrieves all devices associated with the current account.
        :param db: The name of the database to retrieve the devices from.
        :return: A list of Device-like objects representing all associated devices.
        :rtype: List[neonize_proto.Device]
        """
        c_string = gocode.GetAllDevices(
            db.encode(), func_callback_bytes2(log_whatsmeow)
        ).decode()
        if not c_string:
            return []

        devices: list[Device] = []

        for device_str in c_string.split("|\u0001|"):
            id, push_name, bussniess_name, initialized = device_str.split(",")
            id, server = id.split("@")
            jid = build_jid(id, server)

            device = Device(
                JID=jid,
                PushName=push_name,
                BussinessName=bussniess_name,
                Initialized=initialized == "true",
            )
            devices.append(device)

        return devices

    def get_all_devices(self) -> List["Device"]:
        """Retrieves all devices associated with the current account from the database."""
        return self.get_all_devices_from_db(self.database_name)

    def new_client(
        self,
        jid: Optional[JID] = None,
        uuid: Optional[str] = None,
        props: Optional[DeviceProps] = None,
    ) -> NewClient:
        """
        This function creates a new instance of the client. If the jid parameter is not provided, a new client will be created.
        :param name: The name of the client.
        :type name: str
        :param uuid: The unique identifier of the client.
        :type uuid: str
        :param jid: The JID of the client.
        :type jid: JID
        :param props: The device properties of the client.
        :type props: Optional[DeviceProps]
        """

        if not jid and not uuid:
            # you must at least provide a uuid to make sure the client is
            # unique
            raise Exception("JID and UUID cannot be none")

        client = NewClient(self.database_name, jid, props, uuid)
        client.event.list_func = self.event.list_func
        self.clients.append(client)
        return client

    def run(self):
        for client in self.clients:
            Thread(
                target=client.connect,
                daemon=True,
                name=client.uuid.decode(),
            ).start()
