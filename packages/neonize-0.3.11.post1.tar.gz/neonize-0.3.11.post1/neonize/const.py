DEFAULT_USER_SERVER = "s.whatsapp.net"
HIDDEN_USER_SERVER = "lid"
