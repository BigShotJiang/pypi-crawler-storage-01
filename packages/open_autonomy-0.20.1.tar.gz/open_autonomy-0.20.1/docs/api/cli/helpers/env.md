<a id="autonomy.cli.helpers.env"></a>

# autonomy.cli.helpers.env

Environment variable helpers.

<a id="autonomy.cli.helpers.env.load_json"></a>

#### load`_`json

```python
def load_json(file: Path, serialize: bool = False) -> None
```

Load json.

<a id="autonomy.cli.helpers.env.load_env_file"></a>

#### load`_`env`_`file

```python
def load_env_file(file: Path, serialize_json: bool = False) -> None
```

Load env file.

