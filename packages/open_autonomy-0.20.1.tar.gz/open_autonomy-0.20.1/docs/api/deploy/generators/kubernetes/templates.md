<a id="autonomy.deploy.generators.kubernetes.templates"></a>

# autonomy.deploy.generators.kubernetes.templates

Kubernetes Templates module.

<a id="autonomy.deploy.generators.kubernetes.templates.SECRET_STRING_DATA_TEMPLATE"></a>

#### SECRET`_`STRING`_`DATA`_`TEMPLATE

nosec

