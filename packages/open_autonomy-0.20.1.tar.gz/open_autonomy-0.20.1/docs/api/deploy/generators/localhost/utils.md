<a id="autonomy.deploy.generators.localhost.utils"></a>

# autonomy.deploy.generators.localhost.utils

Localhost Deployment utilities.

<a id="autonomy.deploy.generators.localhost.utils.check_tendermint_version"></a>

#### check`_`tendermint`_`version

```python
def check_tendermint_version() -> Path
```

Check tendermint version.

<a id="autonomy.deploy.generators.localhost.utils.setup_agent"></a>

#### setup`_`agent

```python
def setup_agent(working_dir: Path, agent_dir: Path, keys_file: Path) -> None
```

Setup locally deployed agent.

