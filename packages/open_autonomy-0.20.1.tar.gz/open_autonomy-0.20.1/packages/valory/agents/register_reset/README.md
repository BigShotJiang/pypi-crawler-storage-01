# Register Reset ABCI Agent

This agent uses the registration and reset skills to debug the Tendermint issue.
