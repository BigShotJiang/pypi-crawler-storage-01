/usr/bin/tendermint testnet --config /etc/tendermint/config-template.toml --v $1 --o . $2
chown $3 -R /tendermint