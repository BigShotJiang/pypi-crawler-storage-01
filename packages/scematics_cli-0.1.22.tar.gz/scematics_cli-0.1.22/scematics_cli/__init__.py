
"""ScematicsCli module for file upload CLI tools."""

__version__ = ' 0.1.22'

# You can import key functions to make them available at the package level
from .cli import main
