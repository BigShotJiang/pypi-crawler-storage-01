1.start all server in dir "demo_server"
2.run runner.py