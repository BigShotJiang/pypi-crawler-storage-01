function count(a, b) {
    return a + b;
}