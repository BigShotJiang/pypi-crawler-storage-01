"""
PyEgen: Python implementation of Stata's egen command

This package provides Stata-style data manipulation functions for pandas DataFrames,
making it easier for researchers to transition from Stata to Python.
"""

from .core import (
    # Basic functions
    rank,
    rowmean,
    rowtotal,
    rowmax,
    rowmin,
    rowcount,
    rowsd,
    
    # New row-wise functions
    rowfirst,
    rowlast,
    rowmedian,
    rowmiss,
    rownonmiss,
    rowpctile,
    
    # Grouping functions
    tag,
    count,
    mean,
    sum,
    max,
    min,
    sd,
    
    # Statistical functions
    median,
    mode,
    kurt,
    skew,
    mad,
    mdev,
    pctile,
    std,
    total,
    
    # Utility functions
    anycount,
    anymatch,
    anyvalue,
    concat,
    cut,
    diff,
    ends,
    fill,
    
    # Advanced functions
    seq,
    group,
    pc,
    iqr,
)

try:
    from ._version import __version__
except ImportError:
    __version__ = "unknown"

__all__ = [
    # Basic functions
    "rank",
    "rowmean", 
    "rowtotal",
    "rowmax",
    "rowmin",
    "rowcount",
    "rowsd",
    
    # New row-wise functions
    "rowfirst",
    "rowlast", 
    "rowmedian",
    "rowmiss",
    "rownonmiss",
    "rowpctile",
    
    # Grouping functions
    "tag",
    "count",
    "mean",
    "sum",
    "max",
    "min", 
    "sd",
    
    # Statistical functions
    "median",
    "mode",
    "kurt",
    "skew",
    "mad",
    "mdev",
    "pctile",
    "std",
    "total",
    
    # Utility functions
    "anycount",
    "anymatch",
    "anyvalue",
    "concat",
    "cut",
    "diff",
    "ends",
    "fill",
    
    # Advanced functions
    "seq",
    "group",
    "pc",
    "iqr",
    
    "__version__",
]
