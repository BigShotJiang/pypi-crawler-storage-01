import text_imp

messages = text_imp.get_messages()

print(messages)

contacts = text_imp.get_contacts()

print(contacts)

attachments = text_imp.get_attachments()

print(attachments)

chats = text_imp.get_chats()

print(chats)

handles = text_imp.get_chat_handles()

print(handles)
