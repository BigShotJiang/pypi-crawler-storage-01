from pypiactl import PIA

pia = PIA()

pia.dedicated_ip.remove("dedicated-sweden-000.000.000.000")
