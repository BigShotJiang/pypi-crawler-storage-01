from llama_index.embeddings.oci_data_science.base import OCIDataScienceEmbedding


__all__ = ["OCIDataScienceEmbedding"]
