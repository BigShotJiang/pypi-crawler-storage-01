This module allows you to create a nonconformity from a helpdesk ticket,
and keeps it linked.
