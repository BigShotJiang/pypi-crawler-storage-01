"""ILSpy MCP Server - Model Context Protocol server for .NET decompilation."""

__version__ = "0.1.0"