#!/usr/bin/env python3
"""
Entry point for keprompt package when run as python -m keprompt
"""

from .keprompt import main

if __name__ == "__main__":
    main()
