"""Entry point for the CatSCAN application."""
from catscan.main import main

if __name__ == "__main__":
    main()