from nonebot.log import logger

from . import functions, login, otp, subs  # subs_cfg, subs_request  # noqa: F401

logger.success("Loaded: nonebot_plugin_bilichat.command")
