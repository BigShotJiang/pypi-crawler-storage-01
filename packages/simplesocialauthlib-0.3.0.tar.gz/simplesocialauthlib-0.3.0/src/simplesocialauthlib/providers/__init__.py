from simplesocialauthlib.providers.github import GithubSocialAuth
from simplesocialauthlib.providers.google import GoogleSocialAuth

__all__ = ["GithubSocialAuth", "GoogleSocialAuth"]
