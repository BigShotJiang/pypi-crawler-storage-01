"""Integration examples for macOS UI Automation."""
