"""Examples package for macOS UI Automation."""
