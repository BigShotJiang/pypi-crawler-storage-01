"""Integration tests for macOS UI automation."""
