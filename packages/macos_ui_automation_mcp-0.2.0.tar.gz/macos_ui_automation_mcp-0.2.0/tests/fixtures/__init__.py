"""Fixtures for macOS UI automation tests."""
