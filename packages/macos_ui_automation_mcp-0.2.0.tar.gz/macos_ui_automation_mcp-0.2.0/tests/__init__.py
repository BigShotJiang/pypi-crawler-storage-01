"""Test package for macos_ui_automation."""
