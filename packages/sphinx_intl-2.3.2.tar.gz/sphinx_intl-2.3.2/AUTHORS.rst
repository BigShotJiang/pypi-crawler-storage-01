=======
AUTHORS
=======

* Takayuki Shimizukawa <https://github.com/shimizukawa>
* Takeshi Komiya <https://github.com/tk0miya>

Original
--------

This utility derived from these projects.

* ``https://bitbucket.org/tk0miya/sphinx-gettext-helper``
* ``https://bitbucket.org/shimizukawa/sphinx-transifex``
