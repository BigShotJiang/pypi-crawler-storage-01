if __name__ == "__main__":
    from sphinx_intl.commands import main

    main()
