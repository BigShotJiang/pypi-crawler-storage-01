from .print_me_funcs import print_me

def main():
    print_me()

if __name__ == "__main__":
    main()
    