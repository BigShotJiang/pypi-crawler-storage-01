from aws_lambda_powertools.utilities.typing import LambdaContext


class MockLambdaContext(LambdaContext):
    pass
