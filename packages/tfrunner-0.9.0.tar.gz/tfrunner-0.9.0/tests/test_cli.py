def test_mock() -> None:
    assert True
