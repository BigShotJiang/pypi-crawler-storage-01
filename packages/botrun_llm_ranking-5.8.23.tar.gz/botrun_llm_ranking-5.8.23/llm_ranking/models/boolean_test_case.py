from typing import Dict, List
from .base_test_case import BaseTestCase


class BooleanTestCase(BaseTestCase):
    """A test case class that inherits from BaseTestCase for boolean evaluations"""
