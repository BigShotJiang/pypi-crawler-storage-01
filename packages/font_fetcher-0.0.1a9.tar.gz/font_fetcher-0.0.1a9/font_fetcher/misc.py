import logging

logger = logging.getLogger("font_fetcher")
