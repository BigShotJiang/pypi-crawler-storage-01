## [1.0.0](https://github.com/castoredc/avrocurio/tree/v1.0.0) - 2025-07-31

Initial public release.
