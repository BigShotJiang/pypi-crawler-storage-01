from setuptools import setup, find_packages

setup(
    name="dsidelib",
    version="0.3.0",
    packages=find_packages(),
    author="fuqasha",
    description="Simple example library with run function",
    python_requires=">=3.6",
)