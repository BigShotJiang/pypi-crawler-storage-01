"""Utility functions for the gitingest package."""
