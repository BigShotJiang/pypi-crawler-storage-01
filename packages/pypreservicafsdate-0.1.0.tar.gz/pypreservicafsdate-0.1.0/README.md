# pyPreservicaFSDate

Python module which queries a local file system to try and add file system dates (created, modified, accessed) 
etc to objects in already in Preservica.

## Contributing

Bug reports and pull requests are welcome on GitHub at https://github.com/carj/pyPreservicaFSDate

## Support 

pyPreservicaFSDate is 3rd party open source client and is not affiliated or supported by Preservica Ltd.
There is no support for use of the library by Preservica Ltd.
Bug reports can be raised directly on GitHub.

Users of pyPreservicaFSDate should make sure they are licensed to use the Preservica REST APIs. 

## License

The package is available as open source under the terms of the Apache License 2.0

## Installation

pyPreservica is available from the Python Package Index (PyPI)

https://pypi.org/project/pyPreservicaFSDate/

To install pyPreservicaFSDate, simply run this simple command in your terminal of choice:


    $ pip install pyPreservicaFSDate



## Usage

pyPreservicaFSDate uses the pyPreservica python library for ingesting content. This means that pyPreservicaFSDate 
can use the same authentication methods as pyPreservica for reading Preservica credentials. See: 
https://pypreservica.readthedocs.io/en/latest/intro.html#authentication

The most straightforward way is to use a properties file to hold the Preservica credentials.

### Properties File

Create a properties file called "credentials.properties" with the following property names
and save to the working directory ::

    [credentials]
    username=test@test.com
    password=123444
    tenant=PREVIEW
    server=preview.preservica.com



To run the module you need to specify a Preservica collection you wish to process and a local directory
containing the original files:


    $ python -m pyPreservicaFSDate -c a7ad52e3-2cb3-4cb5-af2a-3ab08829a2a8 -p c://my-directory/images

By default, the module will try and match Preservica assets to local file names by using the Asset title, this is 
the fastest way of processing the dates, but may not correctly match files to assets.

The alternative to to match using fixity values stored in Preservica, this can be turned on by using the -f flag:

    $ python -m pyPreservicaFSDate -c a7ad52e3-2cb3-4cb5-af2a-3ab08829a2a8 -p c://my-directory/images -f

Matching using fixity will be slower than using Asset titles.

```
usage: pyPreservicaFSDate [-h] [-c COLLECTION] [-p PATH] [-f]

Add file system dates to Preservica assets Search local file system for
matching files and add the file system dates to Preservica. Files are either
matched on Asset title and filename or by fixity which is slower You provide
both a Preservica collection UUID and a local file system folder to look for
matches

options:
  -h, --help            show this help message and exit
  -c, --collection COLLECTION
                        The Preservica parent collection uuid
  -p, --path PATH       The file system path to search
  -f, --fixity          Use fixity matching (slow)

```

The dates will appear as a new metadata form within the Asset

![Metadata Dates](https://github.com/carj/pyPreservicaFSDate/blob/main/dates.png?raw=true)
