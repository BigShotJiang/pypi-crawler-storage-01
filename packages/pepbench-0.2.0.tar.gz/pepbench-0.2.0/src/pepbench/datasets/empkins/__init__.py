"""Module for the EmpkinS dataset."""

from pepbench.datasets.empkins._dataset import EmpkinsDataset

__all__ = ["EmpkinsDataset"]
