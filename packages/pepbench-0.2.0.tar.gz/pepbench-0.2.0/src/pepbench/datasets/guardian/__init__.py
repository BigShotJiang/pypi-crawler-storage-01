"""Module for the Guardian dataset."""

from pepbench.datasets.guardian._dataset import GuardianDataset

__all__ = ["GuardianDataset"]
