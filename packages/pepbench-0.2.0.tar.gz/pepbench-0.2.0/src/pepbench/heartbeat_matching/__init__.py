"""Module to match two lists of heartbeats."""

from pepbench.heartbeat_matching._heartbeat_matching import match_heartbeat_lists

__all__ = ["match_heartbeat_lists"]
