# Test by Johra

This package provides a simple function to add a signature to a given string.
