# Autovix

Autovix is a deployment utility to automate Git-based project setup, run React or FastAPI apps, and more.
