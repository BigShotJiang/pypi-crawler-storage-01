# Copyright (c) Alibaba, Inc. and its affiliates.
from .base import Callback
from .utils import callbacks_mapping
