"""UI patches for Pro mode - now just a placeholder since we're not modifying the banner."""
def patch_banner(label):
    """No longer needed - banner stays the same regardless of toggle state."""
    pass
