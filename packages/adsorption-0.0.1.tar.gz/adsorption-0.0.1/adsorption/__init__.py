from ._interface import Adsorption  # noqa: D104

__all__ = ["Adsorption"]
