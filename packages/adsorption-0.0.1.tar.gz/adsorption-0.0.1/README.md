# Adsorption

[![Pypi version](https://img.shields.io/pypi/v/adsorption)](https://pypi.org/project/adsorption/)
[![Pypi downloads](https://img.shields.io/pypi/dm/adsorption)](https://pypi.org/project/adsorption/)
[![Pypi downloads](https://img.shields.io/pypi/dw/adsorption)](https://pypi.org/project/adsorption/)
[![Pypi downloads](https://img.shields.io/pypi/dd/adsorption)](https://pypi.org/project/adsorption/)

The Adsorption package is a Python package for the adsorption of molecules on clusters or surfaces.