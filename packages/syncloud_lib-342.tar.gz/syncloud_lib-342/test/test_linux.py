from syncloudlib.linux import useradd

def test_useradd():
    assert True