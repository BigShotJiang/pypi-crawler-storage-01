from syncloudlib.fs import makepath

def test_import():
    assert True