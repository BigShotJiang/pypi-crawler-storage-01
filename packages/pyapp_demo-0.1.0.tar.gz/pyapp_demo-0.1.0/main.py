import pandas as pd

def main():
    df = pd.DataFrame({"foo": [1, 2], "bar": [3, 4]})
    print(df)


if __name__ == "__main__":
    main()
