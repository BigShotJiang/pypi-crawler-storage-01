// Shim for scripts/metadata/gltf.ts
export const getGltfBinaryMetadata = window.comfyAPI.gltf.getGltfBinaryMetadata;
