// Shim for scripts/metadata/mp3.ts
export const getMp3Metadata = window.comfyAPI.mp3.getMp3Metadata;
