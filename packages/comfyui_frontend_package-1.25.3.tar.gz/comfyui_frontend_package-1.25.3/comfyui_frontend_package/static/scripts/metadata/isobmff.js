// Shim for scripts/metadata/isobmff.ts
export const getFromIsobmffFile = window.comfyAPI.isobmff.getFromIsobmffFile;
