// Shim for scripts/ui/components/button.ts
export const ComfyButton = window.comfyAPI.button.ComfyButton;
