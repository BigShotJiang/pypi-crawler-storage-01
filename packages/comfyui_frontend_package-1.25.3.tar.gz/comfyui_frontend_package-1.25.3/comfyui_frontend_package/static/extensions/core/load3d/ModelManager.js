// Shim for extensions/core/load3d/ModelManager.ts
export const ModelManager = window.comfyAPI.ModelManager.ModelManager;
