#!/usr/bin/env python3
__version__ = "1.1.0"

if (__name__ == "__main__"):
    print(f"GHA_VERSION={__version__}")
