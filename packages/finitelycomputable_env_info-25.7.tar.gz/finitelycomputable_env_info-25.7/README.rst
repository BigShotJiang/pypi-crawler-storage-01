=======================
FinitelyComputable-Info
=======================

This distribution provides code to implement the index and info endpoints
across the frameworks of the microsites of finitelycomputable.net. In contrast
to the helloworld apps which are written with framework-specific code with
applications that can run on their own, this is written without
framework-specific code with each hosting app adding all of the
framework-specific parts.
