from ._tektronix_tk512cb import TektronixTK512CBMaterial

__all__ = [
    "TektronixTK512CBMaterial",
]
