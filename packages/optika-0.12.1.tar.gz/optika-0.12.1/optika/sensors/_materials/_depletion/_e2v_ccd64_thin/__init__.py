from ._e2v_ccd64_thin import E2VCCD64ThinDepletionModel

__all__ = [
    "E2VCCD64ThinDepletionModel",
]
