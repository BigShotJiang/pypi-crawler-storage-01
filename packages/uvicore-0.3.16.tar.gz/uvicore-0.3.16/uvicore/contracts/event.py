from abc import ABC, abstractmethod

# class Event(ABC):

#     is_async: bool

# #from uvicore.typing import Dict
# class Event(Dict):
#     """Event Definition"""
#     # These class level properties for for type annotations only.
#     # They do not restrict of define valid properties like a dataclass would.
#     # This is still a fully dynamic SuperDict!
#     name: str
#     description: str
#     dynamic: bool
#     is_async: bool




