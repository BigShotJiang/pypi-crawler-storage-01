from uvicore.typing import Dict


class Config(Dict):
    pass
