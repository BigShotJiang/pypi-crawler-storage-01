import uvicore

@uvicore.service()
class Handler:
    # Currently, empty, but a great place to override all of your own handlers base
    pass
