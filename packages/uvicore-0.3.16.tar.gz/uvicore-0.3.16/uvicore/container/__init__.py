from uvicore.contracts import Binding as BindingInterface

class Binding(BindingInterface):
    pass
