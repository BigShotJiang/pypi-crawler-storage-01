This was modified from https://github.com/python-trio/asyncclick tag 7.1.2.2+async

Instead of actually forking on github and creating a new pypi package I just copied the code here.  This should be temporary until `smurfix` fixes issue https://github.com/python-trio/asyncclick/issues/16 where call_on_close does not handle async callbacks
