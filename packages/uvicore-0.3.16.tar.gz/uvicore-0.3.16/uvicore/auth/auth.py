import uvicore

@uvicore.service(aliases=['Auth', 'auth'])
class Auth:
    pass
