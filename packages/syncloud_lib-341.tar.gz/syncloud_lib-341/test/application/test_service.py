from syncloudlib.application.service import restart


def test_import():
    assert True