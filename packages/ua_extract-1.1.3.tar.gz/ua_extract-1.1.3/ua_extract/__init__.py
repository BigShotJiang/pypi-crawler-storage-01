__version__ = '1.1.3'
from .settings import *
from .parser import *
from .device_detector import *
from .update_regex import Regexes