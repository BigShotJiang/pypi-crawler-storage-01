# Support

For assistance with Job Defense Shield, please post an issue on the GitHub repository: <a href="https://github.com/PrincetonUniversity/job_defense_shield" target="_blank">https://github.com/PrincetonUniversity/job_defense_shield</a>

Please include the versions of Python and pandas that you are using.

For assistance with the Jobstats platform, please post an issue on the Jobstats GitHub repository: <a href="https://github.com/PrincetonUniversity/jobstats" target="_blank">https://github.com/PrincetonUniversity/jobstats</a>
