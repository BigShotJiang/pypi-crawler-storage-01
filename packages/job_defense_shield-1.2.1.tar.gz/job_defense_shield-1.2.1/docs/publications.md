# Publications

**Combating Underutilization with the Jobstats Job Monitoring Platform**  
PEARC 2025, Columbus, Ohio (July 23, 2025)  
Poster: ([PDF](https://researchcomputing.princeton.edu/document/6246))  

**Integration of Open OnDemand with the Jobstats Job Monitoring Platform**  
Global Open OnDemand Conference, Harvard University, Cambridge, MA (March 19, 2025)    
Slides: [PDF](https://researchcomputing.princeton.edu/document/6081)

- PEARC 2024 poster: [PDF](https://tigress-web.princeton.edu/~jdh4/jobstats_poster_PEARC2024_V2.pdf)
- PEARC 2023 slides: [PDF](https://tigress-web.princeton.edu/~jdh4/jobstats_pearc_2023.pdf)
- PEARC 2023 paper: [PDF](https://doi.org/10.1145/3569951.3604396)
