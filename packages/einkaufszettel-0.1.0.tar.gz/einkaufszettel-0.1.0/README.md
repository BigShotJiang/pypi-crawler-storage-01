```
mise i
uv sync
```
