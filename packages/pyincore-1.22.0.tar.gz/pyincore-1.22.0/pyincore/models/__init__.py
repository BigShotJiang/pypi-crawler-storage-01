from scipy.stats import norm
