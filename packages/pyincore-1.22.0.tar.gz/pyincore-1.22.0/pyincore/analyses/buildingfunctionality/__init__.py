from pyincore.analyses.buildingfunctionality.buildingfunctionality import (
    BuildingFunctionality,
)
