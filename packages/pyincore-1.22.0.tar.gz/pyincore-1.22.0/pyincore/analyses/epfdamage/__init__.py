from pyincore.analyses.epfdamage.epfdamage import EpfDamage
from pyincore.analyses.epfdamage.epfutil import EpfUtil
