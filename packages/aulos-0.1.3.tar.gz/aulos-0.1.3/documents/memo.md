Todo
* Chord 和音
* Note  音名・階名
* Scale 音階・旋法
* Tuner 音律