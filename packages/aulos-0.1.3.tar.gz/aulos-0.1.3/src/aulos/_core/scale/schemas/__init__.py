from .scale import ScaleSchema

__all__ = [
    "ScaleSchema",
]
