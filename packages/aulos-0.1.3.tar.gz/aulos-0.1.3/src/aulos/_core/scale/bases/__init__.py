from .scale import BaseScale

__all__ = [
    "BaseScale",
]
