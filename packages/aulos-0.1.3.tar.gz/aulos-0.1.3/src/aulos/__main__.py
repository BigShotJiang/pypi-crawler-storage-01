import argparse


def main() -> None:
    parser = argparse.ArgumentParser("aulos")
    parser.description = "Aulos Application"


if __name__ == "__main__":
    main()
