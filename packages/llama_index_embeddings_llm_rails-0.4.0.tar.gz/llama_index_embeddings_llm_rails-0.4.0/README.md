# LlamaIndex Embeddings Integration: Llm Rails
