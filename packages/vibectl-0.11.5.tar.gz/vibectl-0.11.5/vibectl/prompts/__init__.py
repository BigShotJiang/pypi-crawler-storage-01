"""
Prompt modules for vibectl commands.

This package contains prompt definitions organized by functionality
to keep the main prompt.py file manageable.
"""
