# -*- coding: utf-8 -*-


class Scheduled:
    """
    定时任务\n
    """
    pass
