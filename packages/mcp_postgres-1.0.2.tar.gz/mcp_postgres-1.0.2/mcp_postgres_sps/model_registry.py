from .models import PedidosVenda, Itenspedidovenda, Produtos, Entidades

MODELS_MCP = [PedidosVenda, Itenspedidovenda, Produtos, Entidades]
