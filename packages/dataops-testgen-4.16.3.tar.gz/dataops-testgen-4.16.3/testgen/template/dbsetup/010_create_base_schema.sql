-- Create base tg schema
create schema if not exists {SCHEMA_NAME};
