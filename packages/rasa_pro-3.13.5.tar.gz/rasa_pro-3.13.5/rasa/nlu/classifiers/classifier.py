class IntentClassifier:
    """An intent classifier."""

    # TODO: move "add intent / rankings to message" functions here
    pass
