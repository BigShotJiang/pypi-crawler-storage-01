"""Main entry point for the kreuzberg_benchmarks module."""

from .cli import app

if __name__ == "__main__":
    app()
