"""Test dbt_score package."""
