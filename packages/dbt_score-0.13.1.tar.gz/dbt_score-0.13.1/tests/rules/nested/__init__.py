"""Nested package for testing rule discovery."""
