"""CLI module for KGE."""
