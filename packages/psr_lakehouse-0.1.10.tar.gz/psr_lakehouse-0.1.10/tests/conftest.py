import dotenv

dotenv.load_dotenv(override=True)
