# Saintcord - Official Wrapper for Discord API

saintcord is made for @saint#8878 more at http://saint.dev

## Features
- Guild/user permission checks
- Mobile status integration
- Optimized for faster speeds

## Installation
```bash
pip install saintcord
