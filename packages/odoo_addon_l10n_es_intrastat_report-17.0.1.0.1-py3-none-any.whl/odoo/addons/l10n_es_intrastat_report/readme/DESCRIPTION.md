This module implements the Spanish Intrastat reporting.

The report can be reviewed and corrected where needed before the
creation of the csv file for the declaration.
