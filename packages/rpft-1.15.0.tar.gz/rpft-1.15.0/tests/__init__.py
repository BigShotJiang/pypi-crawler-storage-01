from pathlib import Path


TESTS_ROOT = Path(__file__).parent
