from rpft.parsers.creation.datarowmodel import DataRowModel


class NameModel(DataRowModel):
    name: str = ""
