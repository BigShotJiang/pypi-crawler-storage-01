import uuid


def generate_new_uuid():
    return str(uuid.uuid4())
