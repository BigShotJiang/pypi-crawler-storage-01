=============
Release notes
=============


.. toctree::
   :maxdepth: 1

   releases/0.3.0.rst
   releases/0.2.28.rst
   releases/0.2.27.rst
   releases/0.2.26.rst
   releases/0.2.25.rst
   releases/0.2.24.rst
   releases/0.2.23.rst
   releases/0.2.22.rst
   releases/0.2.21.rst
   releases/0.2.20.rst
   releases/0.2.19.rst
   releases/0.2.18.rst
   releases/0.2.17.rst
   releases/0.2.16.rst
   releases/0.2.15.rst
   releases/0.2.14.rst
   releases/0.2.13.rst
   releases/0.2.12.rst
   releases/0.2.11.rst
   releases/0.2.10.rst
   releases/0.2.9.rst
   releases/0.2.8.rst
   releases/0.2.7.rst
   releases/0.2.6.rst
   releases/0.2.5.rst
   releases/0.2.4.rst
   releases/0.2.3.rst
   releases/0.2.2.rst
   releases/0.2.1.rst
   releases/0.2.0.rst
   releases/0.1.0.rst
