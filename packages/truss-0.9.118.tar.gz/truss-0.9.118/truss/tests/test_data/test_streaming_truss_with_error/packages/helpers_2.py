def bar(x):
    raise Exception("Crashed in `bar`.")
