"""
a.k.a Clean Slate Utils
"""

__version__ = "1.15.1"
