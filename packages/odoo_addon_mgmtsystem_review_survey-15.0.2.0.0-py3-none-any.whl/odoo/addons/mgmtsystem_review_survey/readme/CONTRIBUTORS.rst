* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Loïc Faure-Lacroix <loic.lacroix@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Luk Vermeylen <luk@allmas-it.be>
* Eugen Don <eugen.don@don-systems.de>
* Jose Maria Alzaga <jose.alzaga@aselcis.com>
* Julien Coux <julien.coux@camptocamp.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
  * Víctor Martínez

Trobz

* Dung Tran <dungtd@trobz.com>
* Yvan Dotet <yvan.dotet@logicasoft.eu>