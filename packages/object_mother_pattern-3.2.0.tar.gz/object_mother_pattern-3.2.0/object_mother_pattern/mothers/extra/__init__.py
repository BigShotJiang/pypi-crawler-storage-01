from .text_mother import TextMother

__all__ = ('TextMother',)
