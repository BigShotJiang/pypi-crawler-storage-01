import logging
from .dw_logger import DwLogger

logging.setLoggerClass(DwLogger)
