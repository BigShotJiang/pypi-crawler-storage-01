print('歡迎使用 tsengmodtool 中文化版本')
