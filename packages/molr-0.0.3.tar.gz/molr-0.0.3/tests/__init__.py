"""
Test suite for molr.space package.
"""
