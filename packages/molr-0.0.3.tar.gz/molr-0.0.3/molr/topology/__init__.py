"""
Topology detection and bond analysis.
"""
