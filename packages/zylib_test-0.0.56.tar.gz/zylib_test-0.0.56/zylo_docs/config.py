EXTERNAL_API_BASE = "https://api.zylosystems.com/v1"
# EXTERNAL_API_BASE = "http://0.0.0.0:8001/v1"
