"""Utilities migrating V1 legacy Flow360 inputs to V2 SimulationParams"""

from flow360.component.simulation.migration import BETDisk

__all__ = ["BETDisk"]
