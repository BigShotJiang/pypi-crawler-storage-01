# holospooky
Unofficial fixed module + pre-built programs + self-made features for Cozmo SDK

IMPORTANT LINKS:

[GitHub](https://github.com/montypythonist/holospooky)

[Website](https://montypythonist.carrd.co/)

[Wiki](https://github.com/montypythonist/holospooky/wiki)

[YouTube](https://www.youtube.com/@montypythonist)

[PyPI](https://pypi.org/user/montypythonist/)

[Email](mailto:julia.alotoom.contact@gmail.com)
