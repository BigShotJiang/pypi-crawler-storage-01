# deepctl-cmd-debug-audio

Audio debug subcommand for the Deepgram CLI (deepctl). This package provides the `audio` subcommand under the `debug` command group, allowing users to debug audio-related issues using ffprobe presets.

`ffmpeg` is required.
