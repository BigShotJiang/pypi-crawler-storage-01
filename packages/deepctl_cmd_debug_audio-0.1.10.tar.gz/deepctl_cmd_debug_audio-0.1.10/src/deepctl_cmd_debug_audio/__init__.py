"""Audio debug subcommand for deepctl."""

from .command import AudioCommand

__all__ = ["AudioCommand"]
