from pathlib import Path
import stonefish_runtime
stonefish_runtime.load_25d(Path(__file__).with_name("betterbib.cpython-310.sfc"), __package__)
