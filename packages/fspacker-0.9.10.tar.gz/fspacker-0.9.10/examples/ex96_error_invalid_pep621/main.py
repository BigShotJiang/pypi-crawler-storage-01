def main():
    print("Hello from ex96-error-invalid-pep621!")


if __name__ == "__main__":
    main()
