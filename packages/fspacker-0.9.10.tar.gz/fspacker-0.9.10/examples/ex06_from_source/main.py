import orderedset


def main():
    print("Hello from ex06-from-source!")
    print(f"Orderedset version: {orderedset.__version__}")


if __name__ == "__main__":
    main()
