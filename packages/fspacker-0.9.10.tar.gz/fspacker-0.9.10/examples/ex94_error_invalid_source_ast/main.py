import

def main():
    print("Hello from ex94-error-invalid-source-ast!")


if __name__ == "__main__":
    main()
