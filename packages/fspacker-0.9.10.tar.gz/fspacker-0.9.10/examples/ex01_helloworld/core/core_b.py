import tomli


def function_core_b():
    print("Called from function_core_b, in folder")
    print(tomli.__version__)
