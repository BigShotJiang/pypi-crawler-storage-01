def main():
    print("Hello from ex98-error-invalid-poetry-cfg!")


if __name__ == "__main__":
    main()
