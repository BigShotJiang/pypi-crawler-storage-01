fspacker.parsers package
========================

Submodules
----------

fspacker.parsers.manager module
-------------------------------

.. automodule:: fspacker.parsers.manager
   :members:
   :undoc-members:
   :show-inheritance:

fspacker.parsers.package module
-------------------------------

.. automodule:: fspacker.parsers.package
   :members:
   :undoc-members:
   :show-inheritance:

fspacker.parsers.project module
-------------------------------

.. automodule:: fspacker.parsers.project
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: fspacker.parsers
   :members:
   :undoc-members:
   :show-inheritance:
