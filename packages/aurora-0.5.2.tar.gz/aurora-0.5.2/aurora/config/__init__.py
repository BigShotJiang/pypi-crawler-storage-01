from aurora.config.emtf_band_setup import (
    BANDS_DEFAULT_FILE,
    BANDS_TEST_FAST_FILE,
    BANDS_256_26_FILE,
    BANDS_256_29_FILE,
)
