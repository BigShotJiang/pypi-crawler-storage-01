from aurora.general_helper_functions import BAND_SETUP_PATH

BANDS_DEFAULT_FILE = BAND_SETUP_PATH.joinpath("bs_test.cfg")
BANDS_TEST_FAST_FILE = BAND_SETUP_PATH.joinpath("bs_test_fast.cfg")
BANDS_256_26_FILE = BAND_SETUP_PATH.joinpath("bs_256_26.cfg")
BANDS_256_29_FILE = BAND_SETUP_PATH.joinpath("bs_256_29.cfg")
