from mth5 import RUN_SUMMARY_DTYPE, RUN_SUMMARY_COLUMNS

MINI_SUMMARY_COLUMNS = [
    "survey",
    "station",
    "run",
    "start",
    "end",
    "duration",
]
