aurora.config.metadata package
==============================

Submodules
----------

aurora.config.metadata.processing module
----------------------------------------

.. automodule:: aurora.config.metadata.processing
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.config.metadata
   :members:
   :undoc-members:
   :show-inheritance:
