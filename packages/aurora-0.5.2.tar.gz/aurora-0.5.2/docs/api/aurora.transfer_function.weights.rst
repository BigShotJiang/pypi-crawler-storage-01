aurora.transfer\_function.weights package
=========================================

Submodules
----------

aurora.transfer\_function.weights.edf\_weights module
-----------------------------------------------------

.. automodule:: aurora.transfer_function.weights.edf_weights
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.transfer_function.weights
   :members:
   :undoc-members:
   :show-inheritance:
