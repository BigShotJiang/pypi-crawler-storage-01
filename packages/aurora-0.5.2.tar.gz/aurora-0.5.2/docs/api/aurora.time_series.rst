aurora.time\_series package
===========================

Submodules
----------

aurora.time\_series.apodization\_window module
----------------------------------------------

.. automodule:: aurora.time_series.apodization_window
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.decorators module
-------------------------------------

.. automodule:: aurora.time_series.decorators
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.frequency\_band\_helpers module
---------------------------------------------------

.. automodule:: aurora.time_series.frequency_band_helpers
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.spectrogram module
--------------------------------------

.. automodule:: aurora.time_series.spectrogram
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.time\_axis\_helpers module
----------------------------------------------

.. automodule:: aurora.time_series.time_axis_helpers
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.window\_helpers module
------------------------------------------

.. automodule:: aurora.time_series.window_helpers
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.windowed\_time\_series module
-------------------------------------------------

.. automodule:: aurora.time_series.windowed_time_series
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.windowing\_scheme module
--------------------------------------------

.. automodule:: aurora.time_series.windowing_scheme
   :members:
   :undoc-members:
   :show-inheritance:

aurora.time\_series.xarray\_helpers module
------------------------------------------

.. automodule:: aurora.time_series.xarray_helpers
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.time_series
   :members:
   :undoc-members:
   :show-inheritance:
