aurora.config.emtf\_band\_setup package
=======================================

Module contents
---------------

.. automodule:: aurora.config.emtf_band_setup
   :members:
   :undoc-members:
   :show-inheritance:
