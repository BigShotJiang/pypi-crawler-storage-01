aurora.test\_utils package
==========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aurora.test_utils.mth5
   aurora.test_utils.parkfield
   aurora.test_utils.synthetic

Submodules
----------

aurora.test\_utils.dataset\_definitions module
----------------------------------------------

.. automodule:: aurora.test_utils.dataset_definitions
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.test_utils
   :members:
   :undoc-members:
   :show-inheritance:
