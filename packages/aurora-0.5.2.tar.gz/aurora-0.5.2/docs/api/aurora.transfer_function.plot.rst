aurora.transfer\_function.plot package
======================================

Submodules
----------

aurora.transfer\_function.plot.comparison\_plots module
-------------------------------------------------------

.. automodule:: aurora.transfer_function.plot.comparison_plots
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.plot.error\_bar\_helpers module
---------------------------------------------------------

.. automodule:: aurora.transfer_function.plot.error_bar_helpers
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.plot.rho\_phi\_helpers module
-------------------------------------------------------

.. automodule:: aurora.transfer_function.plot.rho_phi_helpers
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.plot.rho\_plot module
-----------------------------------------------

.. automodule:: aurora.transfer_function.plot.rho_plot
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.transfer_function.plot
   :members:
   :undoc-members:
   :show-inheritance:
