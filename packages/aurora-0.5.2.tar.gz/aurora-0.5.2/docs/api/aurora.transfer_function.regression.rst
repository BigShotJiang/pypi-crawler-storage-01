aurora.transfer\_function.regression package
============================================

Submodules
----------

aurora.transfer\_function.regression.RME module
------------------------------------------------

.. automodule:: aurora.transfer_function.regression.RME
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.regression.RME\_RR module
----------------------------------------------------

.. automodule:: aurora.transfer_function.regression.RME_RR
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.regression.base module
------------------------------------------------

.. automodule:: aurora.transfer_function.regression.base
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.regression.helper\_functions module
-------------------------------------------------------------

.. automodule:: aurora.transfer_function.regression.helper_functions
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.regression.iter\_control module
---------------------------------------------------------

.. automodule:: aurora.transfer_function.regression.iter_control
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.regression.m\_estimator module
--------------------------------------------------------

.. automodule:: aurora.transfer_function.regression.m_estimator
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.transfer_function.regression
   :members:
   :undoc-members:
   :show-inheritance:
