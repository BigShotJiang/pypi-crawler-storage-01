aurora package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aurora.config
   aurora.pipelines
   aurora.sandbox
   aurora.test_utils
   aurora.time_series
   aurora.transfer_function

Submodules
----------

aurora.general\_helper\_functions module
----------------------------------------

.. automodule:: aurora.general_helper_functions
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora
   :members:
   :undoc-members:
   :show-inheritance:
