aurora.config package
=====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aurora.config.emtf_band_setup
   aurora.config.metadata

Submodules
----------

aurora.config.config\_creator module
------------------------------------

.. automodule:: aurora.config.config_creator
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.config
   :members:
   :undoc-members:
   :show-inheritance:
