aurora.transfer\_function package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aurora.transfer_function.plot
   aurora.transfer_function.regression
   aurora.transfer_function.weights

Submodules
----------

aurora.transfer\_function.TTFZ module
-------------------------------------

.. automodule:: aurora.transfer_function.TTFZ
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.base module
-------------------------------------

.. automodule:: aurora.transfer_function.base
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.emtf\_z\_file\_helpers module
-------------------------------------------------------

.. automodule:: aurora.transfer_function.emtf_z_file_helpers
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.kernel\_dataset module
------------------------------------------------

.. automodule:: aurora.transfer_function.kernel_dataset
   :members:
   :undoc-members:
   :show-inheritance:

aurora.transfer\_function.transfer\_function\_collection module
---------------------------------------------------------------

.. automodule:: aurora.transfer_function.transfer_function_collection
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aurora.transfer_function
   :members:
   :undoc-members:
   :show-inheritance:
