This application allows you to track your customers/vendors claims and
grievances.

It is fully integrated with the email gateway so that you can create
automatically new claims based on incoming emails.
