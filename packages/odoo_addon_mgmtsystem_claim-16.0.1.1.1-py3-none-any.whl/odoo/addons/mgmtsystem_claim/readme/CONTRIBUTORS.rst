* Savoir-faire Linux
* `Guadaltech <https://www.guadaltech.es>`_:

  * Fernando La Chica <fernando.lachica@guadaltech.es>
* Yvan Dotet <yvan.dotet@logicasoft.eu>
