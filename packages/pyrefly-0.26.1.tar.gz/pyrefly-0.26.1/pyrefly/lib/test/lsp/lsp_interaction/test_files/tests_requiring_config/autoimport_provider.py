# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.


def this_is_a_very_long_function_name_so_we_can_deterministically_test_autoimport_with_fuzzy_search() -> (
    None
):
    return


this_is_a_very_long_function_name_so_we_can_deterministically_test_autoimport_with_fuzzy_search
