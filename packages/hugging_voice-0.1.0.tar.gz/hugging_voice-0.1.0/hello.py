def main():
    print("Hello from voiceai!")


if __name__ == "__main__":
    main()
