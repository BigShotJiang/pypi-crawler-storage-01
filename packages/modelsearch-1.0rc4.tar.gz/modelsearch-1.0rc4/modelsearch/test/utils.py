from django.test import TestCase


class ModelSearchTestCase(TestCase):
    pass
