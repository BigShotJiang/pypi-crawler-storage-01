from .eagle3 import OfflineEagle3Model, OnlineEagle3Model

__all__ = ["OnlineEagle3Model", "OfflineEagle3Model"]
