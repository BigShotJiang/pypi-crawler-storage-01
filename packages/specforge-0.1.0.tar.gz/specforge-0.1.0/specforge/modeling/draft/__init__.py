from .base import Eagle3DraftModel
from .llama3_eagle import LlamaForCausalLMEagle3

__all__ = ["Eagle3DraftModel", "LlamaForCausalLMEagle3"]
