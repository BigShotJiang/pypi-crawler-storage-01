#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test package for MCP tools

This package contains tests for all MCP tools including
analyze_code_scale, read_code_partial, and get_code_positions.
"""

__version__ = "1.0.0"