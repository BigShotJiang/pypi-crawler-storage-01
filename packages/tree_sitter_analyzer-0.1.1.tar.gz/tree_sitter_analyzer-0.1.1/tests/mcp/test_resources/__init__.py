#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test package for MCP resources

This package contains tests for all MCP resources including
code file resources and code statistics resources.
"""

__version__ = "1.0.0"