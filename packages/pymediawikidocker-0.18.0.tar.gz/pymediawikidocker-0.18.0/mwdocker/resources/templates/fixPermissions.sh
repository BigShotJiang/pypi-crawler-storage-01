#!/bin/bash
# fix the permissions 
# WF 2023-04-22
cd /var/www/html
chown -R www-data .
chgrp -R www-data .