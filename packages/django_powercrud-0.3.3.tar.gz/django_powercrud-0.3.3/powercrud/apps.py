from django.apps import AppConfig

class powercrudConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "powercrud"
    verbose_name = "powercrud"
