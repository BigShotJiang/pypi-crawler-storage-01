# Shaheenviz - Unified EDA Solution 🚀

[![PyPI version](https://badge.fury.io/py/shaheenviz.svg)](https://badge.fury.io/py/shaheenviz)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)

Shaheenviz combines the analytical power of **YData Profiling** with the stunning visuals of **Sweetviz** to deliver a unified, automatic EDA solution. With optional **Rust acceleration**, it's now blazingly fast! ⚡

## ✨ Features

- 🎯 **Automatic Backend Selection**: Intelligently chooses between YData Profiling and Sweetviz based on dataset characteristics
- ⚡ **Rust Acceleration**: Optional high-performance Rust backend for 10-100x speedup on statistical computations
- 📊 **Comprehensive Analysis**: Statistical summaries, correlations, missing values, outliers, and more
- 🎨 **Beautiful Visualizations**: Interactive plots, histograms, correlation heatmaps, and comparison charts
- 🔍 **Smart Target Detection**: Automatically identifies target columns for supervised learning
- 📈 **Dataset Comparison**: Compare train/test distributions and detect data drift
- 🛡️ **Data Quality Warnings**: Automatic detection of data quality issues
- 💻 **Multiple Interfaces**: Python API, CLI tool, and Jupyter notebook integration
- 📤 **Flexible Output**: HTML reports, JSON export, PDF generation (optional)

## 🚀 Performance Benchmarks

With Rust acceleration enabled, Shaheenviz achieves significant performance improvements:

| Operation | Pure Python | Rust Accelerated | Speedup |
|-----------|-------------|------------------|---------|
| Statistical Description | 45ms | 2ms | **22.5x** |
| Correlation Matrix (1000x50) | 890ms | 12ms | **74x** |
| Outlier Detection | 156ms | 8ms | **19.5x** |
| Missing Value Analysis | 67ms | 3ms | **22x** |
| Categorical Profiling | 234ms | 15ms | **15.6x** |

*Benchmarks run on Intel i7-10700K, 32GB RAM, datasets ranging from 1K-100K rows*

## 📦 Installation

### Basic Installation
```bash
pip install shaheenviz
```

### With Rust Acceleration (Recommended)
```bash
# Install Rust (if not already installed)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install with development dependencies
pip install shaheenviz[dev]

# Build Rust extension
cd shaheenviz
maturin develop --release
```

### With All Optional Dependencies
```bash
pip install shaheenviz[dev,pdf]
```

## 🎯 Quick Start

### Basic Usage

```python
import pandas as pd
from shaheenviz import generate_report

# Load your data
df = pd.read_csv('your_data.csv')

# Generate report (automatically detects target and chooses optimal backend)
report = generate_report(df, title="My Dataset Analysis")

# Save as HTML
report.save_html('analysis_report.html')

# Or display in Jupyter notebook
report.show_notebook()
```

### Rust-Accelerated Analysis

```python
from shaheenviz import generate_report, rust_accelerated

# Check if Rust acceleration is available
print(f"Rust acceleration: {'✅ Available' if rust_accelerated.available else '❌ Not available'}")

# Generate report with automatic Rust acceleration
report = generate_report(df, target='target_column')

# Manual Rust-accelerated operations
stats = rust_accelerated.fast_describe(df['numeric_column'])
correlation_matrix = rust_accelerated.fast_correlation_matrix(df)
outliers = rust_accelerated.fast_outlier_detection(df['numeric_column'])
```

### Dataset Comparison

```python
from shaheenviz import compare_datasets

# Compare training and validation sets
train_df = pd.read_csv('train.csv')
val_df = pd.read_csv('validation.csv')

comparison_report = compare_datasets(train_df, val_df, target='target')
comparison_report.save_html('train_vs_val_comparison.html')
```

### Command Line Interface

```bash
# Basic analysis
shaheenviz --file data.csv

# With specific target and output
shaheenviz --file train.csv --target label --output my_report.html

# Compare datasets
shaheenviz --file train.csv --compare test.csv --target target

# Quick analysis with minimal processing
shaheenviz --file large_dataset.csv --minimal --mode ydata

# Verbose output with system info
shaheenviz --file data.csv --verbose --system-info
```

## 🏗️ Architecture

Shaheenviz uses a modular architecture that automatically selects the best backend:

```
┌─────────────────────────────────────────┐
│            Shaheenviz Core              │
├─────────────────────────────────────────┤
│  🎯 Automatic Backend Selection         │
│  📊 Unified Report Interface            │
│  🔍 Smart Target Detection              │
└─────────────────────────────────────────┘
           │                    │
    ┌─────────────┐    ┌─────────────────┐
    │  YData      │    │   Sweetviz      │
    │  Profiling  │    │   Wrapper       │
    │  Wrapper    │    │                 │
    └─────────────┘    └─────────────────┘
           │                    │
    ┌─────────────┐    ┌─────────────────┐
    │   📈        │    │      🎨         │
    │ Statistical │    │ Beautiful       │
    │ Analysis    │    │ Visualizations  │
    └─────────────┘    └─────────────────┘
           │
    ┌─────────────────────────────────────┐
    │        ⚡ Rust Acceleration         │
    │  • Statistical Functions            │
    │  • Correlation Computations         │
    │  • Data Quality Analysis            │
    │  • Outlier Detection                │
    └─────────────────────────────────────┘
```

## 🔧 Advanced Configuration

### Backend Selection Logic

```python
# Manual backend selection
report = generate_report(df, mode='ydata')     # Force YData Profiling
report = generate_report(df, mode='sweetviz')  # Force Sweetviz
report = generate_report(df, mode='auto')      # Automatic (default)
```

### Rust Acceleration Settings

```python
from shaheenviz.rust_accelerated import rust_accelerated

# Check availability
if rust_accelerated.available:
    print("🚀 Rust acceleration is available!")
    
    # Use individual accelerated functions
    desc = rust_accelerated.fast_describe(df['column'])
    corr_matrix = rust_accelerated.fast_correlation_matrix(df)
    missing_info = rust_accelerated.fast_missing_analysis(df)
    outliers = rust_accelerated.fast_outlier_detection(df['column'], method='iqr')
```

### Custom Profiling

```python
from shaheenviz import ProfileWrapper, SweetvizWrapper

# Custom YData Profiling configuration
profile_wrapper = ProfileWrapper()
config_overrides = {
    "correlations": {
        "spearman": {"calculate": False},  # Disable Spearman for speed
        "cramers": {"calculate": True}     # Enable Cramér's V
    }
}

report = profile_wrapper.generate_profile(
    df, 
    target='target',
    config_overrides=config_overrides
)
```

## 🎨 Sample Reports

### Numeric Data Analysis
![Numeric Analysis](https://via.placeholder.com/600x300?text=Numeric+Data+Analysis)

### Categorical Data Analysis  
![Categorical Analysis](https://via.placeholder.com/600x300?text=Categorical+Data+Analysis)

### Correlation Heatmap
![Correlation Heatmap](https://via.placeholder.com/600x300?text=Correlation+Heatmap)

### Dataset Comparison
![Dataset Comparison](https://via.placeholder.com/600x300?text=Dataset+Comparison)

## 🧪 Example Notebooks

Check out our comprehensive examples:

- [Basic Usage](examples/sample_usage.ipynb) - Getting started with Shaheenviz
- [Rust Acceleration](examples/rust_acceleration_demo.ipynb) - Performance comparisons
- [Advanced Features](examples/advanced_features.ipynb) - Custom configurations
- [Real-world Examples](examples/real_world_examples.ipynb) - Complete analysis workflows

## 🛠️ Development

### Building from Source

```bash
# Clone the repository
git clone https://github.com/hamza/shaheenviz.git
cd shaheenviz

# Install Rust (if not installed)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install Python dependencies
pip install -e .[dev]

# Build Rust extension
maturin develop --release

# Run tests
pytest tests/

# Run benchmarks
python benchmarks/performance_comparison.py
```

### Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=shaheenviz

# Test only Rust functions
pytest tests/test_rust_acceleration.py

# Performance tests
pytest tests/test_performance.py --benchmark-only
```

## 📊 Performance Tips

1. **Enable Rust Acceleration**: Build the Rust extension for significant speedups
2. **Use Minimal Mode**: For quick analysis, use `minimal=True`
3. **Choose Backend Wisely**: YData Profiling for large datasets, Sweetviz for detailed comparisons
4. **Optimize Memory**: Use appropriate data types (e.g., category for strings)

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md).

### Areas for Contribution
- 🐛 Bug fixes and improvements
- ⚡ Performance optimizations
- 📊 New statistical functions
- 🎨 Visualization enhancements
- 📚 Documentation improvements
- 🧪 Test coverage expansion

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [YData Profiling](https://github.com/ydataai/ydata-profiling) - Comprehensive data profiling
- [Sweetviz](https://github.com/fbdesignpro/sweetviz) - Beautiful EDA visualizations  
- [PyO3](https://github.com/PyO3/pyo3) - Rust-Python bindings
- [Polars](https://github.com/pola-rs/polars) - Fast dataframe operations in Rust

## 🔗 Links

- 📖 [Documentation](https://shaheenviz.readthedocs.io/)
- 🐛 [Issue Tracker](https://github.com/hamza/shaheenviz/issues)
- 💬 [Discussions](https://github.com/hamza/shaheenviz/discussions)
- 📦 [PyPI Package](https://pypi.org/project/shaheenviz/)

---

**Made with ❤️ by Hamza**

*Shaheenviz - Making EDA fast, beautiful, and effortless!*
