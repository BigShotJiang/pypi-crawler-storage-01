# __init__.py
from llama_index.tools.slack.base import (
    SlackToolSpec,
)

__all__ = ["SlackToolSpec"]
