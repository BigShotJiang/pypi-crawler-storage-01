# SteadyText Accuracy Benchmark Results

**Date**: 2025-06-23 18:44:04


================================================================================
ACCURACY BENCHMARK RESULTS
================================================================================

## Simple Accuracy Tests

### Determinism
  - all_deterministic: True
  - determinism_rate: 1.0

### Quality
  - code_generation: True
  - explanation_length: False

### Embeddings
  - similar_texts_similarity: 0.6944207549095154
  - different_texts_similarity: 0.4657367467880249
  - similarity_check_passed: True
