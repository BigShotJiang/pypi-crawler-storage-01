"""Utility functions associated with 'Mapping Inorganic Crystal Space' using SMACT."""
