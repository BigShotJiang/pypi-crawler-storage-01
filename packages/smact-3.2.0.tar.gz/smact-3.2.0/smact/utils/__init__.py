"""Utility functions for SMACT."""
