r"""
\mainpage.

This is the mainpage of the smact package

Authors Keith T. Butler, Adam J. Jackson, Daniel Davies, Josh Evans, Tim Gauntlet, Aron Walsh.

Semiconducting Materials from Analogy and Chemical Theory (SMACT)
"""
