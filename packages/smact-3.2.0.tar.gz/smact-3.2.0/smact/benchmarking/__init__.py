"""SMACT benchmarking."""
