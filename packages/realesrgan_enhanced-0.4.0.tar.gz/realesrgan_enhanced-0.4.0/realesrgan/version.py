# GENERATED VERSION FILE
# TIME: Wed Jul 30 09:57:39 2025
__version__ = '0.4.0'
__gitsha__ = 'a4abfb2'
version_info = (0, 4, 0)
