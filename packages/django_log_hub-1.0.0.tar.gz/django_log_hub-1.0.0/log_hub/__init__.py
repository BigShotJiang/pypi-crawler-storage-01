# Django Admin Logs Hub
# A reusable Django app for managing and viewing application logs 