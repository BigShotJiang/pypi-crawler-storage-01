"""Module for the Spoofy Archiver service."""

from .main import SpoofyArchiver

__all__ = ["SpoofyArchiver"]
