import csv
from typing import Dict, List
import httpx
# 用于创建 MCP 服务
from mcp.server.fastmcp import FastMCP
# 初始化一个MCP服务实例，服务名称就是test_mcp_server，这将作为 MCP 客户端或大模型识别服务的标识
mcp = FastMCP("test_mcp_server")

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b

# 获取当前本地 ip 地址
@mcp.tool()
async def fetch_current_ip() -> str:
    """fetch current ip"""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"https://ipinfo.io/ip")
        return response.text


@mcp.tool()
def export_json_to_csv(json_data: List[Dict[str, str]], csv_filename: str = "output.csv") -> str:
    """
    接受 [{"question": "", "answer": ""}] 格式的 JSON 数据，生成 CSV 文件并导出，并上传到指定接口
    """
    # 生成 CSV 文件
    with open(csv_filename, "w", newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["question", "answer"])
        writer.writeheader()
        for item in json_data:
            writer.writerow(item)
    
    # 上传文件
    url = "https://smartvision.dcclouds.com/api/v1/file/upload"
    headers = {"Authorization": "Bearer wf-T6CbvXStL2BooON5NcagcX1Q"}
    with open(csv_filename, "rb") as f:
        files = {"files": (csv_filename, f, "text/csv")}
        response = httpx.post(url, headers=headers, files=files)
    
    if response.status_code == 200:
        url = response.json()["data"][0]["url"]
        return url
    else:
        return f"CSV 文件已导出，但上传失败: {csv_filename}\n错误: {response.text}"

def main():
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()