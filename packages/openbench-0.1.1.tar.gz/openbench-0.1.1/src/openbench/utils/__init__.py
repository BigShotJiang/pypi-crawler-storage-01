"""Core utilities for benchmarking."""
