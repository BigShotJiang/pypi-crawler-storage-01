EXTEND_NON_EXTENSIBLE_MODEL_ENUMERATION_ERROR = (
    'Нельзя расширять модель-перечисление элементами перечисления вне класса, если установлено свойство '
    'extensible = False в Meta!'
)
