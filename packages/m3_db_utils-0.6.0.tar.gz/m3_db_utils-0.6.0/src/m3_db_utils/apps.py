from django.apps import (
    AppConfig,
)


class M3DBUtilsConfig(AppConfig):
    name = label = 'm3_db_utils'
    verbose_name = 'Утилиты для работы с БД'
