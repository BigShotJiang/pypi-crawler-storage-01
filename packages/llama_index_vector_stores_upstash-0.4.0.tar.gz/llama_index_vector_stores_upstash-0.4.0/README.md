# LlamaIndex Vector Stores Integration: Upstash
