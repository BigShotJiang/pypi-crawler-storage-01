#!/usr/bin/env python3
"""
Setup script for semantic-copycat-miner.
"""

from setuptools import setup, find_packages

if __name__ == "__main__":
    setup() 