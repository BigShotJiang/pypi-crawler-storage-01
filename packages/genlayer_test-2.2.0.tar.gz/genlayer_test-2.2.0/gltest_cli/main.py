import pytest


def main():
    return pytest.main()
