# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name="SkillLink",
    version="0.2.5",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pyperclip",
        "pyautogui",
        "python-dotenv",
        "google-genai",
        "uv",
        "SyncLink",
        "SynMem",
        "SynLrn",
        "BitSig",
        "requests",
    ],
    author="Tristan McBride Sr.",
    author_email="TristanMcBrideSr@users.noreply.github.com",
    description="Modern manager for AI skills, tools, loading, execution, and automation.",
)
