=========
Changelog
=========

Version 0.1.0
=============

- Breaking change: made absolute path generation for object storage to be optional.


Version 0.0.1
=============

- Initial commit
