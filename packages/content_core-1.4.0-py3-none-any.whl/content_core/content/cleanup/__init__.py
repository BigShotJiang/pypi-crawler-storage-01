"""Content cleaning functionality for content-core."""

from .core import cleanup_content

__all__ = ["cleanup_content"]
