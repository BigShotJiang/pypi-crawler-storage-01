"""Graph and style helpers for PyRetailScience."""
