# Base Segmentation

::: pyretailscience.segmentation.base
