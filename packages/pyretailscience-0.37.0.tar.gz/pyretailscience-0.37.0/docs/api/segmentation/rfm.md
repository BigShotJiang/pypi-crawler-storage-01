# RFM Segmentation

::: pyretailscience.segmentation.rfm
