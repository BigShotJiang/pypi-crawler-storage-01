# Options Analysis

::: pyretailscience.options
