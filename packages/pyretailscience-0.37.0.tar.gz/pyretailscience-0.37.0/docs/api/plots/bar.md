# Bar Plot

::: pyretailscience.plots.bar
