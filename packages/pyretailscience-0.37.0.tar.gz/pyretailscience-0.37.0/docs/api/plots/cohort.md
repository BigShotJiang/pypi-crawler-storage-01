# Cohort Plot

::: pyretailscience.plots.cohort
