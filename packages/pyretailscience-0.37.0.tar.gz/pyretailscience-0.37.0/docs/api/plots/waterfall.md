# Waterfall Plot

::: pyretailscience.plots.waterfall
