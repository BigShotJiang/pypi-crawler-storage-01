# Time Plot

::: pyretailscience.plots.time
