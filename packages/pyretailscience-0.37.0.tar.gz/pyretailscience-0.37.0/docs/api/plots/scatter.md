# Scatter Plot

::: pyretailscience.plots.scatter
