---
template: home.html
title: PyRetailScience
social:
  cards_layout_options:
    title: PyRetailScience | Retail Analytics Toolbox
---

Welcome to PyRetailScience.
