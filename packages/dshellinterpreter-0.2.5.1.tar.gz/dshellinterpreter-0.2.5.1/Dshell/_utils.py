NoneType = type(None)
