"""MkDocs Exec Plugin - Execute Python code snippets in documentation."""

from .plugin import MkDocsExecPlugin

__version__ = "0.1.0"
__all__ = ["MkDocsExecPlugin"]