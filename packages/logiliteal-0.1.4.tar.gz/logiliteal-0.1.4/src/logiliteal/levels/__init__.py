"""
日志级别模块
Log level module

"""
# encoding: utf-8
# python 3.13.5

from .levels import Logger

__all__ = ["Logger"]