from imodelsx import explain_dataset_iprompt, get_add_two_numbers_dataset, AugLinearClassifier


def test_auggam():
    m = AugLinearClassifier()
