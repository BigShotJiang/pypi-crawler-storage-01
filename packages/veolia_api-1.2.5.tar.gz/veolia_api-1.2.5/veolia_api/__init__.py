"""veolia_api package"""

from .veolia_api import VeoliaAPI

# Define the __all__ variable
__all__ = ["VeoliaAPI"]
