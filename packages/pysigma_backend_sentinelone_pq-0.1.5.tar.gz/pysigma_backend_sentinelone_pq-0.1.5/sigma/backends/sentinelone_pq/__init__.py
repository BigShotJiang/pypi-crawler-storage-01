from .sentinelone_pq import SentinelOnePQBackend

backends = {
    "sentinelone_pq": SentinelOnePQBackend
}