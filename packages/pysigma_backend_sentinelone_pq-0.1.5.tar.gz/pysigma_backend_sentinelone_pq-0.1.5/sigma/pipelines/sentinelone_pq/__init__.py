from .sentinelone_pq import sentinelonepq_pipeline

pipelines = {
    "sentinelonepq_pipeline": sentinelonepq_pipeline
}