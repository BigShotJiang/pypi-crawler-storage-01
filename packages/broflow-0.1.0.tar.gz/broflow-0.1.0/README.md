# broflow
A library for pipeline and workflow inspired by pocketflow.  

It's for practicing and making all the workflows more readable.  
