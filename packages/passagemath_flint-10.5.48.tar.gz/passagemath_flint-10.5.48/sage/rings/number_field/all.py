# sage_setup: distribution = sagemath-pari

from sage.rings.number_field.all__sagemath_flint import *
from sage.rings.number_field.all__sagemath_pari import *
