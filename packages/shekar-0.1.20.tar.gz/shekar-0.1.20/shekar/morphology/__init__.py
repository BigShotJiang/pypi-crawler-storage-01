from .conjugator import Conjugator
from .inflector import Inflector

__all__ = ["Conjugator", "Inflector"]
