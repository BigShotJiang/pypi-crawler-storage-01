## What's Changed

- refactor: replace diagram-renderer submodule with PyPI dependency (fb093a5)

**Full Changelog**: https://github.com/djvolz/coda-code-assistant/compare/v2025.8.2.1041...v2025.8.2.1052
