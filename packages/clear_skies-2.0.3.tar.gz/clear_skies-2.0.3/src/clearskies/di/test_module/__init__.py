from . import another_module
from .module_class import ModuleClass


class Hi:
    pass
