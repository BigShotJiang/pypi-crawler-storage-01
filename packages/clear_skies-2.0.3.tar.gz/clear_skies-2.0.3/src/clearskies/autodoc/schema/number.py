from .schema import Schema


class Number(Schema):
    _type = "number"
    _format = "float"
