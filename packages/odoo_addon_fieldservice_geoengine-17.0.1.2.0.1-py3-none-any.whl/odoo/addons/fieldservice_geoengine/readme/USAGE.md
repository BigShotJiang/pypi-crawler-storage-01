To use this module, you need to:

- Go to Field Service \> Master Data \> Locations
- Make sure to provide all the address information to geolocalize
  properly
- Check the map tab to display the location as a point on the map
- Go to Field Service \> Dashboard
- Select the map view to show the orders on a map with a different
  colors based on their stage
