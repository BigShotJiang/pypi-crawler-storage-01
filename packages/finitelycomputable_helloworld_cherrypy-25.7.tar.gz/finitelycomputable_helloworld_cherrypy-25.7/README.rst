===================
HelloWorld-CherryPy
===================

finitelycomputable.helloworld_cherrypy provides a hello_world endpoint using
the CherryPy framework wherever it is mounted.
