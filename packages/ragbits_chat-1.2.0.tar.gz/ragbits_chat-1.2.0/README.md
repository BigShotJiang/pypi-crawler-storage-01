# Ragbits Chat

ragbits-chat is a Python package that provides tools for building conversational AI applications.

The package includes:
- Framework for building chat experiences
- History management for conversation tracking
- UI components for building chat interfaces

For detailed information, please refer to the [API documentation](https://ragbits.deepsense.ai/how-to/chatbots/api/).