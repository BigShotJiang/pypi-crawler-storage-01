import{aY as a,aZ as e,a_ as t}from"./index-CnISK-Rc.js";const n={renderer:t,...e,...a};var o=n;export{o as default};
