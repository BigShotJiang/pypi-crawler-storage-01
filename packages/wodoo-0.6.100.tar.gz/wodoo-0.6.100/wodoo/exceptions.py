class NoProjectNameException(Exception):
    pass
