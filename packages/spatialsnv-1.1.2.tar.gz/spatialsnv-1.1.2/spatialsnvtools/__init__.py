# __init__.py
from .cli import main

