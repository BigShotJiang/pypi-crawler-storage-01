A test taking 99 seconds::

    sage: import time
    sage: time.sleep(99)
