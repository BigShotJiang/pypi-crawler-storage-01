This module relies on:

- The OCA module '2D matrix for x2many fields', and can be downloaded
  from Github:
  <https://github.com/OCA/web/tree/16.0/web_widget_x2many_2d_matrix>
