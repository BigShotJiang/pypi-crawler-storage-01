from llama_index.llms.zhipuai.base import ZhipuAI


__all__ = ["ZhipuAI"]
