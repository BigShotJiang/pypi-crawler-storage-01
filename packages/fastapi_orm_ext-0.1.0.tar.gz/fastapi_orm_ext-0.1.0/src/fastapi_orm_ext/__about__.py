# SPDX-FileCopyrightText: 2025-present Pavel Kozhemjachenko <pkozhem@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.0"
