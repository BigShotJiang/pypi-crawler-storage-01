from fastapi_orm_ext.table._table import TableBase

__all__ = ("TableBase",)
