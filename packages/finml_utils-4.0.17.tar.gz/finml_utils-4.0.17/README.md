Utility functions of all of our Financial Machine Learning projects

