from .base import IntEnum


class Location(IntEnum):
    ...
