from .base import IntEnum


class AlignEnum(IntEnum):
    ...


class FormatEnum(IntEnum):
    ...


class WrapEnum(IntEnum):
    ...
