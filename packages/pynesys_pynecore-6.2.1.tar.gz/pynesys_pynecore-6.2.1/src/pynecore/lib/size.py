from ..types.size import Size

#
# Constants
#

huge = Size()
large = Size()
normal = Size()
small = Size()
tiny = Size()
auto = Size()
