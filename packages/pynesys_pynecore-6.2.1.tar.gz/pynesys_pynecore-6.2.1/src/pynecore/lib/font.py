from ..types.font import FontFamilyEnum

# Font family constants
family_default = FontFamilyEnum()
family_monospace = FontFamilyEnum()
