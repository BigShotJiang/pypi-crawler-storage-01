from ..types.location import Location

#
# Constants
#

abovebar = Location()
absolute = Location()
belowbar = Location()
bottom = Location()
top = Location()
