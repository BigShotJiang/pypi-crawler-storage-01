from ...types.strategy import Direction

#
# Constants
#

all = Direction("all")  # noqa
long = Direction("long")
short = Direction("short")
