from ..types.format import Format

#
# Constants
#

inherit = Format("inherit")
mintick = Format("mintick")
percent = Format("percent")
price = Format("price")
volume = Format("volume")
