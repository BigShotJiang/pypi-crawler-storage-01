.. blacs documentation master file, created by
   sphinx-quickstart on Thu Jun 18 17:05:42 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

blacs |version|
===============

A graphical interface to scientific instruments and experiment supervision.

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: DOCUMENTATION

   introduction
   usage
   api/index

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: FURTHER DOCUMENTATION

   components

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: LINKS

   Home Page <http://labscriptsuite.org>
   Source Code <https://github.com/labscript-suite/blacs>
   PyPI <https://pypi.org/project/blacs/>
   Anaconda Cloud <https://anaconda.org/labscript-suite/blacs>
   BitBucket Archive <http://bitbucket-archive.labscriptsuite.org/#!/labscript_suite/blacs>

.. todolist::
