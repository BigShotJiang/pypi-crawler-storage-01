"""Allow running cogency as a module: python -m cogency 'message' [--trace]"""

from cogency.utils import main

if __name__ == "__main__":
    main()
