from django.apps import AppConfig


class DjangocmsTimedPublicationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djangocms_timed_publishing'
    verbose_name = "django CMS Timed Publishing"