A procmacro and trait for implementing state machines in Rust

We should move this to it's own repo once we're done iterating.