import falcon


class App(falcon.App):
    '''this will have __module__ == finitelycomputable.idtrust_falcon.peewee'''
