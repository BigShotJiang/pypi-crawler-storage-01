import datetime
import json
import os
import unicodedata
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

import dash
import dash_bootstrap_components as dbc
from dash import dcc, html
from openai import OpenAI


class DashAIChat(dash.Dash):
    def __init__(
        self, name=__name__, external_stylesheets=None, chat_config=None, **kwargs
    ):
        if external_stylesheets is None:
            external_stylesheets = [dbc.themes.BOOTSTRAP]
        super().__init__(name, external_stylesheets=external_stylesheets, **kwargs)
        self.chat_config = chat_config or {}
        self.required_ids = {
            "burger-menu",
            "sidebar-offcanvas",
            "conversation-list",
            "url",
            "chat_area_div",
            "user_input_textarea",
            "new-chat-button",
        }
        self.BASE_DIR = Path("")
        self.client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        self.AI_REGISTRY = {
            ("openai", "chat.completions"): {
                "call": lambda messages,
                model,
                **kwargs: self.client.chat.completions.create(
                    model=model, messages=messages, **kwargs
                ),
                "extract": lambda resp: resp["choices"][0]["message"]["content"],
                "format_messages": lambda history: [
                    {"role": m["role"], "content": m["content"]} for m in history
                ],
            },
            ("openai", "completions"): {
                "call": lambda prompt, model, **kwargs: self.client.completions.create(
                    model=model, prompt=prompt, **kwargs
                ),
                "extract": lambda resp: resp["choices"][0]["text"],
                "format_messages": lambda history: "\n".join(
                    f"{m['role']}: {m['content']}" for m in history
                ),
            },
        }
        self.layout = self.default_layout()
        self._validate_layout()
        self._register_callbacks()
        self._register_clientside_callbacks()

    # --- Layout Factories ---
    def sidebar(self):
        return dbc.Offcanvas(
            [
                html.Div(
                    [
                        html.I(className="bi bi-pencil-square icon-new-chat"),
                        " New chat",
                    ],
                    id="new-chat-button",
                    className="mb-3 w-100",
                ),
                html.Div(
                    id="conversation-list",
                    children=[],
                    className="conversation-list",
                ),
            ],
            id="sidebar-offcanvas",
            title="Conversations",
            is_open=False,
            placement="start",
        )

    @property
    def sidebar_string(self):
        return 'html.Div([...], id="sidebar-offcanvas", className="offcanvas offcanvas-start sidebar-offcanvas")'

    def chat_area(self):
        return html.Div(
            id="chat_area_div",
            children=[],
            className="chat-area-div",
        )

    @property
    def chat_area_string(self):
        return 'html.Div(id="chat_area_div", className="chat-area-div")'

    def input_area(self):
        return html.Div(
            [
                dbc.Textarea(
                    id="user_input_textarea",
                    placeholder="Ask...",
                    rows=4,
                    autoFocus=True,
                    className="form-control user-input-textarea",
                ),
            ]
        )

    @property
    def input_area_string(self):
        return 'dcc.Textarea(id="user_input_textarea", className="form-control user-input-textarea")'

    def default_layout(self):
        return html.Div(
            [
                html.Button(
                    "☰",
                    id="burger-menu",
                    className="burger-menu btn btn-outline-secondary",
                ),
                self.sidebar(),
                dcc.Location(id="url", refresh=False),
                html.Div(
                    [
                        html.Br(),
                        html.Div(
                            [
                                html.Div(
                                    [dcc.Loading(self.chat_area(), type="circle")],
                                    className="col",
                                )
                            ],
                            className="row",
                        ),
                        html.Div(
                            [html.Div([self.input_area()], className="col")],
                            className="row",
                        ),
                    ],
                    className="container main-container",
                ),
            ]
        )

    @property
    def default_layout_string(self):
        return 'html.Div([...], className="main-app-div")'

    def _validate_layout(self):
        def collect_ids(component):
            ids = set()
            if hasattr(component, "id") and component.id:
                ids.add(component.id)
            if hasattr(component, "children"):
                children = component.children
                if isinstance(children, list):
                    for child in children:
                        ids |= collect_ids(child)
                elif children is not None:
                    ids |= collect_ids(children)
            return ids

        ids = collect_ids(self.layout)
        missing = self.required_ids - ids
        if missing:
            raise ValueError(
                f"DashAIChat: The following required component IDs are missing from the layout: {missing}"
            )

    def set_layout(self, layout):
        self.layout = layout
        self._validate_layout()

    # --- Engine Methods (to be overridden as needed) ---
    def load_messages(self, user_id: str, conversation_id: str) -> List[Dict]:
        path = self._get_convo_dir(user_id, conversation_id) / "messages.json"
        return self._read_json(path) if path.exists() else []

    def save_messages(
        self, user_id: str, conversation_id: str, messages: List[Dict]
    ) -> None:
        path = self._ensure_convo_dir(user_id, conversation_id) / "messages.json"
        self._write_json(path, messages)

    def add_message(self, user_id: str, conversation_id: str, message: Dict) -> None:
        messages = self.load_messages(user_id, conversation_id)
        messages.append(message)
        self.save_messages(user_id, conversation_id, messages)

    def append_raw_response(
        self, user_id: str, conversation_id: str, response: Dict
    ) -> None:
        path = (
            self._ensure_convo_dir(user_id, conversation_id) / "raw_api_responses.jsonl"
        )
        self._append_jsonl(path, response)

    def load_metadata(self, user_id: str, conversation_id: str) -> Dict:
        path = self._get_convo_dir(user_id, conversation_id) / "metadata.json"
        return self._read_json(path) if path.exists() else {}

    def save_metadata(self, user_id: str, conversation_id: str, metadata: Dict) -> None:
        path = self._ensure_convo_dir(user_id, conversation_id) / "metadata.json"
        self._write_json(path, metadata)

    def list_users(self) -> List[str]:
        return sorted([p.name for p in self.BASE_DIR.iterdir() if p.is_dir()])

    def list_conversations(self, user_id: str) -> List[str]:
        user_dir = self._get_user_dir(user_id)
        if not user_dir.exists():
            return []
        return sorted([p.name for p in user_dir.iterdir() if p.is_dir()])

    def get_conversation_titles(self, user_id: str) -> List[Dict[str, str]]:
        conversations = self.list_conversations(user_id)
        result = []
        for convo_id in conversations:
            messages = self.load_messages(user_id, convo_id)
            if messages:
                first_message = messages[0].get("content", "")
                title = (
                    first_message[:30] + "..."
                    if len(first_message) > 30
                    else first_message
                )
                title = title.capitalize() if title else ""
                result.append({"id": convo_id, "title": title})
        return result

    def get_last_convo_id(self, user_id: str) -> Optional[str]:
        conversations = self.list_conversations(user_id)
        return conversations[-1] if conversations else self.get_next_convo_id(user_id)

    def get_next_convo_id(self, user_id: str) -> str:
        user_dir = self._get_user_dir(user_id)
        if not user_dir.exists():
            return "001"
        existing_ids = [
            int(p.name) for p in user_dir.iterdir() if p.is_dir() and p.name.isdigit()
        ]
        if not existing_ids:
            return "001"
        next_id = max(existing_ids) + 1
        return f"{next_id:03d}"

    def fetch_ai_response(
        self,
        messages: List[Dict],
        model: str,
        provider: str = "openai",
        endpoint: str = "chat.completions",
        **kwargs,
    ) -> Dict:
        key = (provider, endpoint)
        if key not in self.AI_REGISTRY:
            raise ValueError(f"Unknown provider/endpoint: {provider}/{endpoint}")
        if not model:
            raise ValueError("Model must be specified explicitly.")
        call_fn = self.AI_REGISTRY[key]["call"]
        format_fn = self.AI_REGISTRY[key]["format_messages"]
        resp = call_fn(format_fn(messages), model, **kwargs)
        return resp.model_dump() if hasattr(resp, "model_dump") else resp

    def extract_assistant_content(
        self,
        raw_response: Dict,
        provider: str = "openai",
        endpoint: str = "chat.completions",
    ) -> str:
        key = (provider, endpoint)
        if key not in self.AI_REGISTRY:
            raise ValueError(f"Unknown provider/endpoint: {provider}/{endpoint}")
        extract_fn = self.AI_REGISTRY[key]["extract"]
        return extract_fn(raw_response)

    def update_convo(
        self,
        user_id: str,
        user_message: str,
        convo_id: Optional[str] = None,
        provider: str = "openai",
        endpoint: str = "chat.completions",
    ) -> str:
        convo_id = convo_id or self.get_next_convo_id(user_id)
        user_msg = {"role": "user", "content": user_message}
        self.add_message(user_id, convo_id, user_msg)
        history = self.load_messages(user_id, convo_id)
        raw_response = self.fetch_ai_response(
            history,
            model="gpt-4o",
            provider=provider,
            endpoint=endpoint,
        )
        self.append_raw_response(user_id, convo_id, raw_response)
        assistant_content = self.extract_assistant_content(
            raw_response, provider, endpoint
        )
        assistant_msg = {"role": "assistant", "content": assistant_content}
        self.add_message(user_id, convo_id, assistant_msg)
        return convo_id

    def _register_callbacks(self):
        @self.callback(
            dash.Output("chat_area_div", "children"),
            dash.Output("user_input_textarea", "value"),
            dash.Input("user_input_textarea", "n_submit"),
            dash.Input("url", "pathname"),
            dash.State("user_input_textarea", "value"),
        )
        def handle_user_input(n_submit, pathname, value):
            import uuid

            segments = (pathname or "/").strip("/").split("/")
            user_id = segments[0] if segments and segments[0] else str(uuid.uuid4())[:5]
            convo_id = segments[1] if len(segments) > 1 and segments[1] else None
            engine_user_id = f"chat_data/{user_id}"
            if not convo_id:
                convo_id = self.get_next_convo_id(engine_user_id)
            if n_submit and value:
                self.update_convo(
                    user_id=engine_user_id, user_message=value, convo_id=convo_id
                )
            messages = self.load_messages(engine_user_id, convo_id)
            return self.format_messages(messages), ""

        @self.callback(
            dash.Output("sidebar-offcanvas", "is_open"),
            dash.Output("url", "pathname", allow_duplicate=True),
            dash.Input("burger-menu", "n_clicks"),
            dash.Input({"type": "conversation-item", "index": dash.ALL}, "n_clicks"),
            dash.State("sidebar-offcanvas", "is_open"),
            dash.State("url", "pathname"),
            prevent_initial_call=True,
        )
        def toggle_offcanvas_and_navigate(
            burger_clicks, convo_clicks, is_open, current_pathname
        ):
            ctx = dash.callback_context
            if not ctx.triggered:
                return dash.no_update, dash.no_update
            trigger_id = ctx.triggered[0]["prop_id"]
            if "conversation-item" in trigger_id and any(convo_clicks):
                clicked_index = next(
                    i for i, clicks in enumerate(convo_clicks) if clicks and clicks > 0
                )
                convo_id = f"{clicked_index + 1:03d}"
                import re

                new_path = re.sub(r"/[^/]*$", f"/{convo_id}", current_pathname or "/")
                return False, new_path
            if "burger-menu" in trigger_id and burger_clicks:
                return not is_open, dash.no_update
            return dash.no_update, dash.no_update

        @self.callback(
            dash.Output("conversation-list", "children"),
            dash.Input("url", "pathname"),
        )
        def update_conversation_list(pathname):
            import uuid

            if not pathname:
                return []
            segments = pathname.strip("/").split("/")
            user_id = segments[0] if segments and segments[0] else str(uuid.uuid4())[:5]
            engine_user_id = f"chat_data/{user_id}"
            conversations = self.get_conversation_titles(engine_user_id)
            if not conversations:
                return []
            conversation_items = []
            for convo in conversations:
                conversation_items.append(
                    html.Div(
                        convo["title"],
                        id={"type": "conversation-item", "index": convo["id"]},
                        style={
                            "cursor": "pointer",
                            "padding": "0.5rem",
                            "margin-bottom": "0.25rem",
                            "border-radius": "5px",
                        },
                    )
                )
            return conversation_items

    def _register_clientside_callbacks(self):
        self.clientside_callback(
            """
            function(chat_content) {
                if (chat_content && chat_content.length > 0) {
                    setTimeout(() => {
                        const chatArea = document.getElementById('chat_area_div');
                        if (chatArea) {
                            chatArea.scrollTop = chatArea.scrollHeight;
                        }
                    }, 100);
                }
                return window.dash_clientside.no_update;
            }
            """,
            dash.Output("chat_area_div", "data-scroll-trigger", allow_duplicate=True),
            dash.Input("chat_area_div", "children"),
            prevent_initial_call=True,
        )
        self.clientside_callback(
            """
            function(textarea_value) {
                const textarea = document.getElementById('user_input_textarea');
                if (textarea && textarea_value) {
                    const rtlPattern = '[\u0590-\u05ff\u0600-\u06ff\u0750-\u077f' +
                                       '\u08a0-\u08ff\ufb1d-\ufb4f\ufb50-\ufdff\ufe70-\ufeff]';
                    const rtlRegex = new RegExp(rtlPattern);
                    const isRTL = rtlRegex.test(textarea_value);
                    textarea.style.direction = isRTL ? 'rtl' : 'ltr';
                    textarea.style.textAlign = isRTL ? 'right' : 'left';
                }
                return window.dash_clientside.no_update;
            }
            """,
            dash.Output("user_input_textarea", "title", allow_duplicate=True),
            dash.Input("user_input_textarea", "value"),
            prevent_initial_call=True,
        )

    # --- RTL Detection ---
    def _is_rtl(self, text):
        if not text or not text.strip():
            return False
        for char in text:
            bidi = unicodedata.bidirectional(char)
            if bidi in ("R", "AL"):
                return True
            elif bidi == "L":
                return False
        return False

    # --- Time ---
    def _now(self):
        return datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%d %H:%M:%S")

    # --- Path Operations ---
    def _get_user_dir(self, user_id: str) -> Path:
        return self.BASE_DIR / user_id

    def _get_convo_dir(self, user_id: str, conversation_id: str) -> Path:
        return self._get_user_dir(user_id) / conversation_id

    def _ensure_convo_dir(self, user_id: str, conversation_id: str) -> Path:
        path = self._get_convo_dir(user_id, conversation_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    # --- File I/O ---
    def _read_json(self, path: Path) -> Any:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _read_jsonl(self, path: Path) -> Iterator[Dict]:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield json.loads(line)

    def _write_json(self, path: Path, data: Any) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _append_jsonl(self, path: Path, entry: Dict) -> None:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def format_messages(self, messages):
        if not messages:
            return []
        formatted = []
        current_msg_direction = "ltr"
        for i, msg in enumerate(messages):
            if msg["role"] == "user":
                current_msg_direction = "rtl" if self._is_rtl(msg["content"]) else "ltr"
                formatted.append(
                    html.Div(
                        [
                            dcc.Markdown(
                                msg["content"],
                                id=f"user-msg-{i}",
                                style={
                                    "text-align": "right",
                                    "width": "80%",
                                    "margin-left": "auto",
                                    "padding": "0.3em 0.3em",
                                    "background-color": "var(--bs-light)",
                                    "border-radius": "15px",
                                },
                            ),
                            html.Div(
                                [
                                    dcc.Clipboard(
                                        content=msg["content"],
                                        id=f"clipboard-user-{i}",
                                        style={"cursor": "pointer"},
                                    ),
                                    dbc.Tooltip(
                                        "Copy",
                                        target=f"clipboard-user-{i}",
                                        placement="top",
                                    ),
                                ],
                                style={
                                    "text-align": "right",
                                    "width": "4%",
                                    "margin-left": "auto",
                                },
                            ),
                        ],
                        dir=current_msg_direction,
                    )
                )
            elif msg["role"] == "assistant":
                formatted.append(
                    html.Div(
                        [
                            dcc.Markdown(
                                msg["content"],
                                id=f"assistant-msg-{i}",
                                className="table table-striped table-hover",
                            ),
                            html.Div(
                                [
                                    dcc.Clipboard(
                                        content=msg["content"],
                                        id=f"clipboard-assistant-{i}",
                                        style={"cursor": "pointer"},
                                    ),
                                    dbc.Tooltip(
                                        "Copy",
                                        target=f"clipboard-assistant-{i}",
                                        placement="top",
                                    ),
                                ],
                                style={"width": "4%"},
                            ),
                        ],
                        dir=current_msg_direction,
                    )
                )
        return formatted
