# Snipster
Snipster is a code snippet management tool
