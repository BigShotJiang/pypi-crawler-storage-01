class SnippetNotFoundError(Exception):
    pass
