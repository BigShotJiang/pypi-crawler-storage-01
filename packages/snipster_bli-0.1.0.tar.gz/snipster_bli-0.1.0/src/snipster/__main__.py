from .cli import app


def main():
    return app()


if __name__ == "__main__":
    main()
