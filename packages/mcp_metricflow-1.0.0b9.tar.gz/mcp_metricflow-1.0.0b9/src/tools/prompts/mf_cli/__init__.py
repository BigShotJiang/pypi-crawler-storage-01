"""MetricFlow CLI prompts for MCP tools."""
