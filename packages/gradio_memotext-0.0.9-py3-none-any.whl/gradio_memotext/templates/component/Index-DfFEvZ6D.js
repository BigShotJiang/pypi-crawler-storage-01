var Jm = Object.defineProperty;
var Ou = (n) => {
  throw TypeError(n);
};
var Ym = (n, e, t) => e in n ? Jm(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var we = (n, e, t) => Ym(n, typeof e != "symbol" ? e + "" : e, t), Xm = (n, e, t) => e.has(n) || Ou("Cannot " + t);
var Nu = (n, e, t) => e.has(n) ? Ou("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t);
var Zi = (n, e, t) => (Xm(n, e, "access private method"), t);
const {
  SvelteComponent: Zm,
  append_hydration: Il,
  assign: Qm,
  attr: Ye,
  binding_callbacks: eg,
  children: gi,
  claim_element: wf,
  claim_space: Ef,
  claim_svg_element: Ko,
  create_slot: tg,
  detach: en,
  element: Sf,
  empty: Ru,
  get_all_dirty_from_scope: ng,
  get_slot_changes: rg,
  get_spread_update: ig,
  init: sg,
  insert_hydration: Fi,
  listen: og,
  noop: lg,
  safe_not_equal: ag,
  set_dynamic_element_data: Iu,
  set_style: pe,
  space: Cf,
  svg_element: Go,
  toggle_class: Be,
  transition_in: Df,
  transition_out: Af,
  update_slot_base: ug
} = window.__gradio__svelte__internal;
function Lu(n) {
  let e, t, r, i, s;
  return {
    c() {
      e = Go("svg"), t = Go("line"), r = Go("line"), this.h();
    },
    l(o) {
      e = Ko(o, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var l = gi(e);
      t = Ko(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), gi(t).forEach(en), r = Ko(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), gi(r).forEach(en), l.forEach(en), this.h();
    },
    h() {
      Ye(t, "x1", "1"), Ye(t, "y1", "9"), Ye(t, "x2", "9"), Ye(t, "y2", "1"), Ye(t, "stroke", "gray"), Ye(t, "stroke-width", "0.5"), Ye(r, "x1", "5"), Ye(r, "y1", "9"), Ye(r, "x2", "9"), Ye(r, "y2", "5"), Ye(r, "stroke", "gray"), Ye(r, "stroke-width", "0.5"), Ye(e, "class", "resize-handle svelte-239wnu"), Ye(e, "xmlns", "http://www.w3.org/2000/svg"), Ye(e, "viewBox", "0 0 10 10");
    },
    m(o, l) {
      Fi(o, e, l), Il(e, t), Il(e, r), i || (s = og(
        e,
        "mousedown",
        /*resize*/
        n[27]
      ), i = !0);
    },
    p: lg,
    d(o) {
      o && en(e), i = !1, s();
    }
  };
}
function cg(n) {
  var d;
  let e, t, r, i, s;
  const o = (
    /*#slots*/
    n[31].default
  ), l = tg(
    o,
    n,
    /*$$scope*/
    n[30],
    null
  );
  let a = (
    /*resizable*/
    n[19] && Lu(n)
  ), u = [
    { "data-testid": (
      /*test_id*/
      n[11]
    ) },
    { id: (
      /*elem_id*/
      n[6]
    ) },
    {
      class: r = "block " + /*elem_classes*/
      (((d = n[7]) == null ? void 0 : d.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      n[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let f = 0; f < u.length; f += 1)
    c = Qm(c, u[f]);
  return {
    c() {
      e = Sf(
        /*tag*/
        n[25]
      ), l && l.c(), t = Cf(), a && a.c(), this.h();
    },
    l(f) {
      e = wf(
        f,
        /*tag*/
        (n[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = gi(e);
      l && l.l(h), t = Ef(h), a && a.l(h), h.forEach(en), this.h();
    },
    h() {
      Iu(
        /*tag*/
        n[25]
      )(e, c), Be(
        e,
        "hidden",
        /*visible*/
        n[14] === !1
      ), Be(
        e,
        "padded",
        /*padding*/
        n[10]
      ), Be(
        e,
        "flex",
        /*flex*/
        n[1]
      ), Be(
        e,
        "border_focus",
        /*border_mode*/
        n[9] === "focus"
      ), Be(
        e,
        "border_contrast",
        /*border_mode*/
        n[9] === "contrast"
      ), Be(e, "hide-container", !/*explicit_call*/
      n[12] && !/*container*/
      n[13]), Be(
        e,
        "fullscreen",
        /*fullscreen*/
        n[0]
      ), Be(
        e,
        "animating",
        /*fullscreen*/
        n[0] && /*preexpansionBoundingRect*/
        n[24] !== null
      ), Be(
        e,
        "auto-margin",
        /*scale*/
        n[17] === null
      ), pe(
        e,
        "height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*height*/
            n[2]
          )
        )
      ), pe(
        e,
        "min-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*min_height*/
            n[3]
          )
        )
      ), pe(
        e,
        "max-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*max_height*/
            n[4]
          )
        )
      ), pe(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].top}px` : "0px"
      ), pe(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].left}px` : "0px"
      ), pe(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].width}px` : "0px"
      ), pe(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].height}px` : "0px"
      ), pe(
        e,
        "width",
        /*fullscreen*/
        n[0] ? void 0 : typeof /*width*/
        n[5] == "number" ? `calc(min(${/*width*/
        n[5]}px, 100%))` : (
          /*get_dimension*/
          n[26](
            /*width*/
            n[5]
          )
        )
      ), pe(
        e,
        "border-style",
        /*variant*/
        n[8]
      ), pe(
        e,
        "overflow",
        /*allow_overflow*/
        n[15] ? (
          /*overflow_behavior*/
          n[16]
        ) : "hidden"
      ), pe(
        e,
        "flex-grow",
        /*scale*/
        n[17]
      ), pe(e, "min-width", `calc(min(${/*min_width*/
      n[18]}px, 100%))`), pe(e, "border-width", "var(--block-border-width)");
    },
    m(f, h) {
      Fi(f, e, h), l && l.m(e, null), Il(e, t), a && a.m(e, null), n[32](e), s = !0;
    },
    p(f, h) {
      var p;
      l && l.p && (!s || h[0] & /*$$scope*/
      1073741824) && ug(
        l,
        o,
        f,
        /*$$scope*/
        f[30],
        s ? rg(
          o,
          /*$$scope*/
          f[30],
          h,
          null
        ) : ng(
          /*$$scope*/
          f[30]
        ),
        null
      ), /*resizable*/
      f[19] ? a ? a.p(f, h) : (a = Lu(f), a.c(), a.m(e, null)) : a && (a.d(1), a = null), Iu(
        /*tag*/
        f[25]
      )(e, c = ig(u, [
        (!s || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          f[11]
        ) },
        (!s || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          f[6]
        ) },
        (!s || h[0] & /*elem_classes*/
        128 && r !== (r = "block " + /*elem_classes*/
        (((p = f[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu")) && { class: r },
        (!s || h[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        f[20] ? "rtl" : "ltr")) && { dir: i }
      ])), Be(
        e,
        "hidden",
        /*visible*/
        f[14] === !1
      ), Be(
        e,
        "padded",
        /*padding*/
        f[10]
      ), Be(
        e,
        "flex",
        /*flex*/
        f[1]
      ), Be(
        e,
        "border_focus",
        /*border_mode*/
        f[9] === "focus"
      ), Be(
        e,
        "border_contrast",
        /*border_mode*/
        f[9] === "contrast"
      ), Be(e, "hide-container", !/*explicit_call*/
      f[12] && !/*container*/
      f[13]), Be(
        e,
        "fullscreen",
        /*fullscreen*/
        f[0]
      ), Be(
        e,
        "animating",
        /*fullscreen*/
        f[0] && /*preexpansionBoundingRect*/
        f[24] !== null
      ), Be(
        e,
        "auto-margin",
        /*scale*/
        f[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && pe(
        e,
        "height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*height*/
            f[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && pe(
        e,
        "min-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*min_height*/
            f[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && pe(
        e,
        "max-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*max_height*/
            f[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && pe(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && pe(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && pe(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && pe(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && pe(
        e,
        "width",
        /*fullscreen*/
        f[0] ? void 0 : typeof /*width*/
        f[5] == "number" ? `calc(min(${/*width*/
        f[5]}px, 100%))` : (
          /*get_dimension*/
          f[26](
            /*width*/
            f[5]
          )
        )
      ), h[0] & /*variant*/
      256 && pe(
        e,
        "border-style",
        /*variant*/
        f[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && pe(
        e,
        "overflow",
        /*allow_overflow*/
        f[15] ? (
          /*overflow_behavior*/
          f[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && pe(
        e,
        "flex-grow",
        /*scale*/
        f[17]
      ), h[0] & /*min_width*/
      262144 && pe(e, "min-width", `calc(min(${/*min_width*/
      f[18]}px, 100%))`);
    },
    i(f) {
      s || (Df(l, f), s = !0);
    },
    o(f) {
      Af(l, f), s = !1;
    },
    d(f) {
      f && en(e), l && l.d(f), a && a.d(), n[32](null);
    }
  };
}
function Pu(n) {
  let e;
  return {
    c() {
      e = Sf("div"), this.h();
    },
    l(t) {
      e = wf(t, "DIV", { class: !0 }), gi(e).forEach(en), this.h();
    },
    h() {
      Ye(e, "class", "placeholder svelte-239wnu"), pe(
        e,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), pe(
        e,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    m(t, r) {
      Fi(t, e, r);
    },
    p(t, r) {
      r[0] & /*placeholder_height*/
      4194304 && pe(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), r[0] & /*placeholder_width*/
      8388608 && pe(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && en(e);
    }
  };
}
function dg(n) {
  let e, t, r, i = (
    /*tag*/
    n[25] && cg(n)
  ), s = (
    /*fullscreen*/
    n[0] && Pu(n)
  );
  return {
    c() {
      i && i.c(), e = Cf(), s && s.c(), t = Ru();
    },
    l(o) {
      i && i.l(o), e = Ef(o), s && s.l(o), t = Ru();
    },
    m(o, l) {
      i && i.m(o, l), Fi(o, e, l), s && s.m(o, l), Fi(o, t, l), r = !0;
    },
    p(o, l) {
      /*tag*/
      o[25] && i.p(o, l), /*fullscreen*/
      o[0] ? s ? s.p(o, l) : (s = Pu(o), s.c(), s.m(t.parentNode, t)) : s && (s.d(1), s = null);
    },
    i(o) {
      r || (Df(i, o), r = !0);
    },
    o(o) {
      Af(i, o), r = !1;
    },
    d(o) {
      o && (en(e), en(t)), i && i.d(o), s && s.d(o);
    }
  };
}
function fg(n, e, t) {
  let { $$slots: r = {}, $$scope: i } = e, { height: s = void 0 } = e, { min_height: o = void 0 } = e, { max_height: l = void 0 } = e, { width: a = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: d = "solid" } = e, { border_mode: f = "base" } = e, { padding: h = !0 } = e, { type: p = "normal" } = e, { test_id: g = void 0 } = e, { explicit_call: _ = !1 } = e, { container: k = !0 } = e, { visible: b = !0 } = e, { allow_overflow: y = !0 } = e, { overflow_behavior: v = "auto" } = e, { scale: S = null } = e, { min_width: D = 0 } = e, { flex: T = !1 } = e, { resizable: x = !1 } = e, { rtl: M = !1 } = e, { fullscreen: L = !1 } = e, R = L, X, ke = p === "fieldset" ? "fieldset" : "div", ue = 0, ae = 0, ie = null;
  function ve(C) {
    L && C.key === "Escape" && t(0, L = !1);
  }
  const fe = (C) => {
    if (C !== void 0) {
      if (typeof C == "number")
        return C + "px";
      if (typeof C == "string")
        return C;
    }
  }, xe = (C) => {
    let H = C.clientY;
    const B = ($) => {
      const Y = $.clientY - H;
      H = $.clientY, t(21, X.style.height = `${X.offsetHeight + Y}px`, X);
    }, J = () => {
      window.removeEventListener("mousemove", B), window.removeEventListener("mouseup", J);
    };
    window.addEventListener("mousemove", B), window.addEventListener("mouseup", J);
  };
  function w(C) {
    eg[C ? "unshift" : "push"](() => {
      X = C, t(21, X);
    });
  }
  return n.$$set = (C) => {
    "height" in C && t(2, s = C.height), "min_height" in C && t(3, o = C.min_height), "max_height" in C && t(4, l = C.max_height), "width" in C && t(5, a = C.width), "elem_id" in C && t(6, u = C.elem_id), "elem_classes" in C && t(7, c = C.elem_classes), "variant" in C && t(8, d = C.variant), "border_mode" in C && t(9, f = C.border_mode), "padding" in C && t(10, h = C.padding), "type" in C && t(28, p = C.type), "test_id" in C && t(11, g = C.test_id), "explicit_call" in C && t(12, _ = C.explicit_call), "container" in C && t(13, k = C.container), "visible" in C && t(14, b = C.visible), "allow_overflow" in C && t(15, y = C.allow_overflow), "overflow_behavior" in C && t(16, v = C.overflow_behavior), "scale" in C && t(17, S = C.scale), "min_width" in C && t(18, D = C.min_width), "flex" in C && t(1, T = C.flex), "resizable" in C && t(19, x = C.resizable), "rtl" in C && t(20, M = C.rtl), "fullscreen" in C && t(0, L = C.fullscreen), "$$scope" in C && t(30, i = C.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && L !== R && (t(29, R = L), L ? (t(24, ie = X.getBoundingClientRect()), t(22, ue = X.offsetHeight), t(23, ae = X.offsetWidth), window.addEventListener("keydown", ve)) : (t(24, ie = null), window.removeEventListener("keydown", ve))), n.$$.dirty[0] & /*visible*/
    16384 && (b || t(1, T = !1));
  }, [
    L,
    T,
    s,
    o,
    l,
    a,
    u,
    c,
    d,
    f,
    h,
    g,
    _,
    k,
    b,
    y,
    v,
    S,
    D,
    x,
    M,
    X,
    ue,
    ae,
    ie,
    ke,
    fe,
    xe,
    p,
    R,
    i,
    r,
    w
  ];
}
class hg extends Zm {
  constructor(e) {
    super(), sg(
      this,
      e,
      fg,
      dg,
      ag,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Ca() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let yr = Ca();
function Tf(n) {
  yr = n;
}
const xf = /[&<>"']/, pg = new RegExp(xf.source, "g"), Mf = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, mg = new RegExp(Mf.source, "g"), gg = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Bu = (n) => gg[n];
function mt(n, e) {
  if (e) {
    if (xf.test(n))
      return n.replace(pg, Bu);
  } else if (Mf.test(n))
    return n.replace(mg, Bu);
  return n;
}
const _g = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function yg(n) {
  return n.replace(_g, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const bg = /(^|[^\[])\^/g;
function _e(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const r = {
    replace: (i, s) => {
      let o = typeof s == "string" ? s : s.source;
      return o = o.replace(bg, "$1"), t = t.replace(i, o), r;
    },
    getRegex: () => new RegExp(t, e)
  };
  return r;
}
function zu(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const _i = { exec: () => null };
function Hu(n, e) {
  const t = n.replace(/\|/g, (s, o, l) => {
    let a = !1, u = o;
    for (; --u >= 0 && l[u] === "\\"; )
      a = !a;
    return a ? "|" : " |";
  }), r = t.split(/ \|/);
  let i = 0;
  if (r[0].trim() || r.shift(), r.length > 0 && !r[r.length - 1].trim() && r.pop(), e)
    if (r.length > e)
      r.splice(e);
    else
      for (; r.length < e; )
        r.push("");
  for (; i < r.length; i++)
    r[i] = r[i].trim().replace(/\\\|/g, "|");
  return r;
}
function Qi(n, e, t) {
  const r = n.length;
  if (r === 0)
    return "";
  let i = 0;
  for (; i < r && n.charAt(r - i - 1) === e; )
    i++;
  return n.slice(0, r - i);
}
function kg(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let r = 0; r < n.length; r++)
    if (n[r] === "\\")
      r++;
    else if (n[r] === e[0])
      t++;
    else if (n[r] === e[1] && (t--, t < 0))
      return r;
  return -1;
}
function qu(n, e, t, r) {
  const i = e.href, s = e.title ? mt(e.title) : null, o = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    r.state.inLink = !0;
    const l = {
      type: "link",
      raw: t,
      href: i,
      title: s,
      text: o,
      tokens: r.inlineTokens(o)
    };
    return r.state.inLink = !1, l;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: s,
    text: mt(o)
  };
}
function vg(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const r = t[1];
  return e.split(`
`).map((i) => {
    const s = i.match(/^\s+/);
    if (s === null)
      return i;
    const [o] = s;
    return o.length >= r.length ? i.slice(r.length) : i;
  }).join(`
`);
}
class Is {
  // set by the lexer
  constructor(e) {
    we(this, "options");
    we(this, "rules");
    // set by the lexer
    we(this, "lexer");
    this.options = e || yr;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : Qi(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], i = vg(r, t[3] || "");
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (/#$/.test(r)) {
        const i = Qi(r, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (r = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      r = Qi(r.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const s = this.lexer.blockTokens(r);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: s,
        text: r
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const i = r.length > 1, s = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = i ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = i ? r : "[*+-]");
      const o = new RegExp(`^( {0,3}${r})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let l = "", a = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = o.exec(e)) || this.rules.block.hr.test(e))
          break;
        l = t[0], e = e.substring(l.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (k) => " ".repeat(3 * k.length)), f = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, a = d.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, a = d.slice(h), h += t[1].length);
        let p = !1;
        if (!d && /^ *$/.test(f) && (l += f + `
`, e = e.substring(f.length + 1), c = !0), !c) {
          const k = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), b = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), y = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), v = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const S = e.split(`
`, 1)[0];
            if (f = S, this.options.pedantic && (f = f.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), y.test(f) || v.test(f) || k.test(f) || b.test(e))
              break;
            if (f.search(/[^ ]/) >= h || !f.trim())
              a += `
` + f.slice(h);
            else {
              if (p || d.search(/[^ ]/) >= 4 || y.test(d) || v.test(d) || b.test(d))
                break;
              a += `
` + f;
            }
            !p && !f.trim() && (p = !0), l += S + `
`, e = e.substring(S.length + 1), d = f.slice(h);
          }
        }
        s.loose || (u ? s.loose = !0 : /\n *\n *$/.test(l) && (u = !0));
        let g = null, _;
        this.options.gfm && (g = /^\[[ xX]\] /.exec(a), g && (_ = g[0] !== "[ ] ", a = a.replace(/^\[[ xX]\] +/, ""))), s.items.push({
          type: "list_item",
          raw: l,
          task: !!g,
          checked: _,
          loose: !1,
          text: a,
          tokens: []
        }), s.raw += l;
      }
      s.items[s.items.length - 1].raw = l.trimEnd(), s.items[s.items.length - 1].text = a.trimEnd(), s.raw = s.raw.trimEnd();
      for (let c = 0; c < s.items.length; c++)
        if (this.lexer.state.top = !1, s.items[c].tokens = this.lexer.blockTokens(s.items[c].text, []), !s.loose) {
          const d = s.items[c].tokens.filter((h) => h.type === "space"), f = d.length > 0 && d.some((h) => /\n.*\n/.test(h.raw));
          s.loose = f;
        }
      if (s.loose)
        for (let c = 0; c < s.items.length; c++)
          s.items[c].loose = !0;
      return s;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", s = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: i,
        title: s
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const r = Hu(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), s = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === i.length) {
      for (const l of i)
        /^ *-+: *$/.test(l) ? o.align.push("right") : /^ *:-+: *$/.test(l) ? o.align.push("center") : /^ *:-+ *$/.test(l) ? o.align.push("left") : o.align.push(null);
      for (const l of r)
        o.header.push({
          text: l,
          tokens: this.lexer.inline(l)
        });
      for (const l of s)
        o.rows.push(Hu(l, o.header.length).map((a) => ({
          text: a,
          tokens: this.lexer.inline(a)
        })));
      return o;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: mt(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && /^</.test(r)) {
        if (!/>$/.test(r))
          return;
        const o = Qi(r.slice(0, -1), "\\");
        if ((r.length - o.length) % 2 === 0)
          return;
      } else {
        const o = kg(t[2], "()");
        if (o > -1) {
          const a = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + o;
          t[2] = t[2].substring(0, o), t[0] = t[0].substring(0, a).trim(), t[3] = "";
        }
      }
      let i = t[2], s = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        o && (i = o[1], s = o[3]);
      } else
        s = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(r) ? i = i.slice(1) : i = i.slice(1, -1)), qu(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: s && s.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const i = (r[2] || r[1]).replace(/\s+/g, " "), s = t[i.toLowerCase()];
      if (!s) {
        const o = r[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return qu(r, s, r[0], this.lexer);
    }
  }
  emStrong(e, t, r = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && r.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const o = [...i[0]].length - 1;
      let l, a, u = o, c = 0;
      const d = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + o); (i = d.exec(t)) != null; ) {
        if (l = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !l)
          continue;
        if (a = [...l].length, i[3] || i[4]) {
          u += a;
          continue;
        } else if ((i[5] || i[6]) && o % 3 && !((o + a) % 3)) {
          c += a;
          continue;
        }
        if (u -= a, u > 0)
          continue;
        a = Math.min(a, a + u + c);
        const f = [...i[0]][0].length, h = e.slice(0, o + i.index + f + a);
        if (Math.min(o, a) % 2) {
          const g = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: g,
            tokens: this.lexer.inlineTokens(g)
          };
        }
        const p = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(r), s = /^ /.test(r) && / $/.test(r);
      return i && s && (r = r.substring(1, r.length - 1)), r = mt(r, !0), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, i;
      return t[2] === "@" ? (r = mt(t[1]), i = "mailto:" + r) : (r = mt(t[1]), i = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: i,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, s;
      if (t[2] === "@")
        i = mt(t[0]), s = "mailto:" + i;
      else {
        let o;
        do
          o = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (o !== t[0]);
        i = mt(t[0]), t[1] === "www." ? s = "http://" + t[0] : s = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: s,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let r;
      return this.lexer.state.inRawBlock ? r = t[0] : r = mt(t[0]), {
        type: "text",
        raw: t[0],
        text: r
      };
    }
  }
}
const wg = /^(?: *(?:\n|$))+/, Eg = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Sg = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, ji = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Cg = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, $f = /(?:[*+-]|\d{1,9}[.)])/, Ff = _e(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, $f).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Da = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Dg = /^[^\n]+/, Aa = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Ag = _e(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Aa).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Tg = _e(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, $f).getRegex(), xo = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Ta = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, xg = _e("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Ta).replace("tag", xo).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Of = _e(Da).replace("hr", ji).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", xo).getRegex(), Mg = _e(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Of).getRegex(), xa = {
  blockquote: Mg,
  code: Eg,
  def: Ag,
  fences: Sg,
  heading: Cg,
  hr: ji,
  html: xg,
  lheading: Ff,
  list: Tg,
  newline: wg,
  paragraph: Of,
  table: _i,
  text: Dg
}, ju = _e("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", ji).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", xo).getRegex(), $g = {
  ...xa,
  table: ju,
  paragraph: _e(Da).replace("hr", ji).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", ju).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", xo).getRegex()
}, Fg = {
  ...xa,
  html: _e(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Ta).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: _i,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: _e(Da).replace("hr", ji).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Ff).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Nf = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Og = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Rf = /^( {2,}|\\)\n(?!\s*$)/, Ng = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Vi = "\\p{P}\\p{S}", Rg = _e(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Vi).getRegex(), Ig = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Lg = _e(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Vi).getRegex(), Pg = _e("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Vi).getRegex(), Bg = _e("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Vi).getRegex(), zg = _e(/\\([punct])/, "gu").replace(/punct/g, Vi).getRegex(), Hg = _e(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), qg = _e(Ta).replace("(?:-->|$)", "-->").getRegex(), jg = _e("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", qg).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Ls = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Vg = _e(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Ls).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), If = _e(/^!?\[(label)\]\[(ref)\]/).replace("label", Ls).replace("ref", Aa).getRegex(), Lf = _e(/^!?\[(ref)\](?:\[\])?/).replace("ref", Aa).getRegex(), Ug = _e("reflink|nolink(?!\\()", "g").replace("reflink", If).replace("nolink", Lf).getRegex(), Ma = {
  _backpedal: _i,
  // only used for GFM url
  anyPunctuation: zg,
  autolink: Hg,
  blockSkip: Ig,
  br: Rf,
  code: Og,
  del: _i,
  emStrongLDelim: Lg,
  emStrongRDelimAst: Pg,
  emStrongRDelimUnd: Bg,
  escape: Nf,
  link: Vg,
  nolink: Lf,
  punctuation: Rg,
  reflink: If,
  reflinkSearch: Ug,
  tag: jg,
  text: Ng,
  url: _i
}, Wg = {
  ...Ma,
  link: _e(/^!?\[(label)\]\((.*?)\)/).replace("label", Ls).getRegex(),
  reflink: _e(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Ls).getRegex()
}, Ll = {
  ...Ma,
  escape: _e(Nf).replace("])", "~|])").getRegex(),
  url: _e(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Kg = {
  ...Ll,
  br: _e(Rf).replace("{2,}", "*").getRegex(),
  text: _e(Ll.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, es = {
  normal: xa,
  gfm: $g,
  pedantic: Fg
}, ei = {
  normal: Ma,
  gfm: Ll,
  breaks: Kg,
  pedantic: Wg
};
class tn {
  constructor(e) {
    we(this, "tokens");
    we(this, "options");
    we(this, "state");
    we(this, "tokenizer");
    we(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || yr, this.options.tokenizer = this.options.tokenizer || new Is(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: es.normal,
      inline: ei.normal
    };
    this.options.pedantic ? (t.block = es.pedantic, t.inline = ei.pedantic) : this.options.gfm && (t.block = es.gfm, this.options.breaks ? t.inline = ei.breaks : t.inline = ei.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: es,
      inline: ei
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new tn(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new tn(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const r = this.inlineQueue[t];
      this.inlineTokens(r.src, r.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (l, a, u) => a + "    ".repeat(u.length));
    let r, i, s, o;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((l) => (r = l.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.space(e)) {
          e = e.substring(r.raw.length), r.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(r);
          continue;
        }
        if (r = this.tokenizer.code(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + r.raw, i.text += `
` + r.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.fences(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.heading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.hr(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.blockquote(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.list(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.html(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.def(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + r.raw, i.text += `
` + r.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = {
            href: r.href,
            title: r.title
          });
          continue;
        }
        if (r = this.tokenizer.table(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.lheading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (s = e, this.options.extensions && this.options.extensions.startBlock) {
          let l = 1 / 0;
          const a = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, a), typeof u == "number" && u >= 0 && (l = Math.min(l, u));
          }), l < 1 / 0 && l >= 0 && (s = e.substring(0, l + 1));
        }
        if (this.state.top && (r = this.tokenizer.paragraph(s))) {
          i = t[t.length - 1], o && i.type === "paragraph" ? (i.raw += `
` + r.raw, i.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(r), o = s.length !== e.length, e = e.substring(r.raw.length);
          continue;
        }
        if (r = this.tokenizer.text(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + r.raw, i.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(r);
          continue;
        }
        if (e) {
          const l = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(l);
            break;
          } else
            throw new Error(l);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let r, i, s, o = e, l, a, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (l = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          c.includes(l[0].slice(l[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (l = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (l = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, l.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (a || (u = ""), a = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (r = c.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.escape(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.tag(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && r.type === "text" && i.type === "text" ? (i.raw += r.raw, i.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.link(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && r.type === "text" && i.type === "text" ? (i.raw += r.raw, i.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.emStrong(e, o, u)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.codespan(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.br(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.del(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.autolink(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (!this.state.inLink && (r = this.tokenizer.url(e))) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (s = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const d = e.slice(1);
          let f;
          this.options.extensions.startInline.forEach((h) => {
            f = h.call({ lexer: this }, d), typeof f == "number" && f >= 0 && (c = Math.min(c, f));
          }), c < 1 / 0 && c >= 0 && (s = e.substring(0, c + 1));
        }
        if (r = this.tokenizer.inlineText(s)) {
          e = e.substring(r.raw.length), r.raw.slice(-1) !== "_" && (u = r.raw.slice(-1)), a = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += r.raw, i.text += r.text) : t.push(r);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Ps {
  constructor(e) {
    we(this, "options");
    this.options = e || yr;
  }
  code(e, t, r) {
    var s;
    const i = (s = (t || "").match(/^\S*/)) == null ? void 0 : s[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + mt(i) + '">' + (r ? e : mt(e, !0)) + `</code></pre>
` : "<pre><code>" + (r ? e : mt(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, r) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, r) {
    const i = t ? "ol" : "ul", s = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + i + s + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, r) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const r = t.header ? "th" : "td";
    return (t.align ? `<${r} align="${t.align}">` : `<${r}>`) + e + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, r) {
    const i = zu(e);
    if (i === null)
      return r;
    e = i;
    let s = '<a href="' + e + '"';
    return t && (s += ' title="' + t + '"'), s += ">" + r + "</a>", s;
  }
  image(e, t, r) {
    const i = zu(e);
    if (i === null)
      return r;
    e = i;
    let s = `<img src="${e}" alt="${r}"`;
    return t && (s += ` title="${t}"`), s += ">", s;
  }
  text(e) {
    return e;
  }
}
class $a {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, r) {
    return "" + r;
  }
  image(e, t, r) {
    return "" + r;
  }
  br() {
    return "";
  }
}
class nn {
  constructor(e) {
    we(this, "options");
    we(this, "renderer");
    we(this, "textRenderer");
    this.options = e || yr, this.options.renderer = this.options.renderer || new Ps(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new $a();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new nn(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new nn(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let r = "";
    for (let i = 0; i < e.length; i++) {
      const s = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[s.type]) {
        const o = s, l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          r += l || "";
          continue;
        }
      }
      switch (s.type) {
        case "space":
          continue;
        case "hr": {
          r += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = s;
          r += this.renderer.heading(this.parseInline(o.tokens), o.depth, yg(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = s;
          r += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = s;
          let l = "", a = "";
          for (let c = 0; c < o.header.length; c++)
            a += this.renderer.tablecell(this.parseInline(o.header[c].tokens), { header: !0, align: o.align[c] });
          l += this.renderer.tablerow(a);
          let u = "";
          for (let c = 0; c < o.rows.length; c++) {
            const d = o.rows[c];
            a = "";
            for (let f = 0; f < d.length; f++)
              a += this.renderer.tablecell(this.parseInline(d[f].tokens), { header: !1, align: o.align[f] });
            u += this.renderer.tablerow(a);
          }
          r += this.renderer.table(l, u);
          continue;
        }
        case "blockquote": {
          const o = s, l = this.parse(o.tokens);
          r += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          const o = s, l = o.ordered, a = o.start, u = o.loose;
          let c = "";
          for (let d = 0; d < o.items.length; d++) {
            const f = o.items[d], h = f.checked, p = f.task;
            let g = "";
            if (f.task) {
              const _ = this.renderer.checkbox(!!h);
              u ? f.tokens.length > 0 && f.tokens[0].type === "paragraph" ? (f.tokens[0].text = _ + " " + f.tokens[0].text, f.tokens[0].tokens && f.tokens[0].tokens.length > 0 && f.tokens[0].tokens[0].type === "text" && (f.tokens[0].tokens[0].text = _ + " " + f.tokens[0].tokens[0].text)) : f.tokens.unshift({
                type: "text",
                text: _ + " "
              }) : g += _ + " ";
            }
            g += this.parse(f.tokens, u), c += this.renderer.listitem(g, p, !!h);
          }
          r += this.renderer.list(c, l, a);
          continue;
        }
        case "html": {
          const o = s;
          r += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = s;
          r += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = s, l = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            o = e[++i], l += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          r += t ? this.renderer.paragraph(l) : l;
          continue;
        }
        default: {
          const o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return r;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let r = "";
    for (let i = 0; i < e.length; i++) {
      const s = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[s.type]) {
        const o = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          r += o || "";
          continue;
        }
      }
      switch (s.type) {
        case "escape": {
          const o = s;
          r += t.text(o.text);
          break;
        }
        case "html": {
          const o = s;
          r += t.html(o.text);
          break;
        }
        case "link": {
          const o = s;
          r += t.link(o.href, o.title, this.parseInline(o.tokens, t));
          break;
        }
        case "image": {
          const o = s;
          r += t.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = s;
          r += t.strong(this.parseInline(o.tokens, t));
          break;
        }
        case "em": {
          const o = s;
          r += t.em(this.parseInline(o.tokens, t));
          break;
        }
        case "codespan": {
          const o = s;
          r += t.codespan(o.text);
          break;
        }
        case "br": {
          r += t.br();
          break;
        }
        case "del": {
          const o = s;
          r += t.del(this.parseInline(o.tokens, t));
          break;
        }
        case "text": {
          const o = s;
          r += t.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return r;
  }
}
class yi {
  constructor(e) {
    we(this, "options");
    this.options = e || yr;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
we(yi, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var _r, Pl, Bf;
class Pf {
  constructor(...e) {
    Nu(this, _r);
    we(this, "defaults", Ca());
    we(this, "options", this.setOptions);
    we(this, "parse", Zi(this, _r, Pl).call(this, tn.lex, nn.parse));
    we(this, "parseInline", Zi(this, _r, Pl).call(this, tn.lexInline, nn.parseInline));
    we(this, "Parser", nn);
    we(this, "Renderer", Ps);
    we(this, "TextRenderer", $a);
    we(this, "Lexer", tn);
    we(this, "Tokenizer", Is);
    we(this, "Hooks", yi);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, s;
    let r = [];
    for (const o of e)
      switch (r = r.concat(t.call(this, o)), o.type) {
        case "table": {
          const l = o;
          for (const a of l.header)
            r = r.concat(this.walkTokens(a.tokens, t));
          for (const a of l.rows)
            for (const u of a)
              r = r.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const l = o;
          r = r.concat(this.walkTokens(l.items, t));
          break;
        }
        default: {
          const l = o;
          (s = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && s[l.type] ? this.defaults.extensions.childTokens[l.type].forEach((a) => {
            const u = l[a].flat(1 / 0);
            r = r.concat(this.walkTokens(u, t));
          }) : l.tokens && (r = r.concat(this.walkTokens(l.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const i = { ...r };
      if (i.async = this.defaults.async || i.async || !1, r.extensions && (r.extensions.forEach((s) => {
        if (!s.name)
          throw new Error("extension name required");
        if ("renderer" in s) {
          const o = t.renderers[s.name];
          o ? t.renderers[s.name] = function(...l) {
            let a = s.renderer.apply(this, l);
            return a === !1 && (a = o.apply(this, l)), a;
          } : t.renderers[s.name] = s.renderer;
        }
        if ("tokenizer" in s) {
          if (!s.level || s.level !== "block" && s.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = t[s.level];
          o ? o.unshift(s.tokenizer) : t[s.level] = [s.tokenizer], s.start && (s.level === "block" ? t.startBlock ? t.startBlock.push(s.start) : t.startBlock = [s.start] : s.level === "inline" && (t.startInline ? t.startInline.push(s.start) : t.startInline = [s.start]));
        }
        "childTokens" in s && s.childTokens && (t.childTokens[s.name] = s.childTokens);
      }), i.extensions = t), r.renderer) {
        const s = this.defaults.renderer || new Ps(this.defaults);
        for (const o in r.renderer) {
          if (!(o in s))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const l = o, a = r.renderer[l], u = s[l];
          s[l] = (...c) => {
            let d = a.apply(s, c);
            return d === !1 && (d = u.apply(s, c)), d || "";
          };
        }
        i.renderer = s;
      }
      if (r.tokenizer) {
        const s = this.defaults.tokenizer || new Is(this.defaults);
        for (const o in r.tokenizer) {
          if (!(o in s))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const l = o, a = r.tokenizer[l], u = s[l];
          s[l] = (...c) => {
            let d = a.apply(s, c);
            return d === !1 && (d = u.apply(s, c)), d;
          };
        }
        i.tokenizer = s;
      }
      if (r.hooks) {
        const s = this.defaults.hooks || new yi();
        for (const o in r.hooks) {
          if (!(o in s))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const l = o, a = r.hooks[l], u = s[l];
          yi.passThroughHooks.has(o) ? s[l] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(a.call(s, c)).then((f) => u.call(s, f));
            const d = a.call(s, c);
            return u.call(s, d);
          } : s[l] = (...c) => {
            let d = a.apply(s, c);
            return d === !1 && (d = u.apply(s, c)), d;
          };
        }
        i.hooks = s;
      }
      if (r.walkTokens) {
        const s = this.defaults.walkTokens, o = r.walkTokens;
        i.walkTokens = function(l) {
          let a = [];
          return a.push(o.call(this, l)), s && (a = a.concat(s.call(this, l))), a;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return tn.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return nn.parse(e, t ?? this.defaults);
  }
}
_r = new WeakSet(), Pl = function(e, t) {
  return (r, i) => {
    const s = { ...i }, o = { ...this.defaults, ...s };
    this.defaults.async === !0 && s.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const l = Zi(this, _r, Bf).call(this, !!o.silent, !!o.async);
    if (typeof r > "u" || r === null)
      return l(new Error("marked(): input parameter is undefined or null"));
    if (typeof r != "string")
      return l(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(r) : r).then((a) => e(a, o)).then((a) => o.hooks ? o.hooks.processAllTokens(a) : a).then((a) => o.walkTokens ? Promise.all(this.walkTokens(a, o.walkTokens)).then(() => a) : a).then((a) => t(a, o)).then((a) => o.hooks ? o.hooks.postprocess(a) : a).catch(l);
    try {
      o.hooks && (r = o.hooks.preprocess(r));
      let a = e(r, o);
      o.hooks && (a = o.hooks.processAllTokens(a)), o.walkTokens && this.walkTokens(a, o.walkTokens);
      let u = t(a, o);
      return o.hooks && (u = o.hooks.postprocess(u)), u;
    } catch (a) {
      return l(a);
    }
  };
}, Bf = function(e, t) {
  return (r) => {
    if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + mt(r.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(r);
    throw r;
  };
};
const dr = new Pf();
function ge(n, e) {
  return dr.parse(n, e);
}
ge.options = ge.setOptions = function(n) {
  return dr.setOptions(n), ge.defaults = dr.defaults, Tf(ge.defaults), ge;
};
ge.getDefaults = Ca;
ge.defaults = yr;
ge.use = function(...n) {
  return dr.use(...n), ge.defaults = dr.defaults, Tf(ge.defaults), ge;
};
ge.walkTokens = function(n, e) {
  return dr.walkTokens(n, e);
};
ge.parseInline = dr.parseInline;
ge.Parser = nn;
ge.parser = nn.parse;
ge.Renderer = Ps;
ge.TextRenderer = $a;
ge.Lexer = tn;
ge.lexer = tn.lex;
ge.Tokenizer = Is;
ge.Hooks = yi;
ge.parse = ge;
ge.options;
ge.setOptions;
ge.use;
ge.walkTokens;
ge.parseInline;
nn.parse;
tn.lex;
function Gg(n) {
  if (typeof n == "function" && (n = {
    highlight: n
  }), !n || typeof n.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof n.langPrefix != "string" && (n.langPrefix = "language-"), typeof n.emptyLangClass != "string" && (n.emptyLangClass = ""), {
    async: !!n.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const t = Vu(e.lang);
      if (n.async)
        return Promise.resolve(n.highlight(e.text, t, e.lang || "")).then(Uu(e));
      const r = n.highlight(e.text, t, e.lang || "");
      if (r instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      Uu(e)(r);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, t, r) {
        typeof e == "object" && (r = e.escaped, t = e.lang, e = e.text);
        const i = Vu(t), s = i ? n.langPrefix + Ku(i) : n.emptyLangClass, o = s ? ` class="${s}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${o}>${r ? e : Ku(e, !0)}
</code></pre>`;
      }
    }
  };
}
function Vu(n) {
  return (n || "").match(/\S*/)[0];
}
function Uu(n) {
  return (e) => {
    typeof e == "string" && e !== n.text && (n.escaped = !0, n.text = e);
  };
}
const zf = /[&<>"']/, Jg = new RegExp(zf.source, "g"), Hf = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Yg = new RegExp(Hf.source, "g"), Xg = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Wu = (n) => Xg[n];
function Ku(n, e) {
  if (e) {
    if (zf.test(n))
      return n.replace(Jg, Wu);
  } else if (Hf.test(n))
    return n.replace(Yg, Wu);
  return n;
}
const Zg = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Qg = Object.hasOwnProperty;
class Fa {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const r = this;
    let i = e_(e, t === !0);
    const s = i;
    for (; Qg.call(r.occurrences, i); )
      r.occurrences[s]++, i = s + "-" + r.occurrences[s];
    return r.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function e_(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(Zg, "").replace(/ /g, "-"));
}
let qf = new Fa(), jf = [];
function t_({ prefix: n = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return e || n_(), t;
      }
    },
    renderer: {
      heading(t, r, i) {
        i = i.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const s = `${n}${qf.slug(i)}`, o = { level: r, text: t, id: s };
        return jf.push(o), `<h${r} id="${s}">${t}</h${r}>
`;
      }
    }
  };
}
function n_() {
  jf = [], qf = new Fa();
}
var Gu = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function _C(n) {
  return n && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n;
}
var Vf = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(r) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, s = 0, o = {}, l = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: r.Prism && r.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: r.Prism && r.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function b(y) {
          return y instanceof a ? new a(y.type, b(y.content), y.alias) : Array.isArray(y) ? y.map(b) : y.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(b) {
          return Object.prototype.toString.call(b).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(b) {
          return b.__id || Object.defineProperty(b, "__id", { value: ++s }), b.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function b(y, v) {
          v = v || {};
          var S, D;
          switch (l.util.type(y)) {
            case "Object":
              if (D = l.util.objId(y), v[D])
                return v[D];
              S = /** @type {Record<string, any>} */
              {}, v[D] = S;
              for (var T in y)
                y.hasOwnProperty(T) && (S[T] = b(y[T], v));
              return (
                /** @type {any} */
                S
              );
            case "Array":
              return D = l.util.objId(y), v[D] ? v[D] : (S = [], v[D] = S, /** @type {Array} */
              /** @type {any} */
              y.forEach(function(x, M) {
                S[M] = b(x, v);
              }), /** @type {any} */
              S);
            default:
              return y;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(b) {
          for (; b; ) {
            var y = i.exec(b.className);
            if (y)
              return y[1].toLowerCase();
            b = b.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(b, y) {
          b.className = b.className.replace(RegExp(i, "gi"), ""), b.classList.add("language-" + y);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (S) {
            var b = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(S.stack) || [])[1];
            if (b) {
              var y = document.getElementsByTagName("script");
              for (var v in y)
                if (y[v].src == b)
                  return y[v];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(b, y, v) {
          for (var S = "no-" + y; b; ) {
            var D = b.classList;
            if (D.contains(y))
              return !0;
            if (D.contains(S))
              return !1;
            b = b.parentElement;
          }
          return !!v;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(b, y) {
          var v = l.util.clone(l.languages[b]);
          for (var S in y)
            v[S] = y[S];
          return v;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(b, y, v, S) {
          S = S || /** @type {any} */
          l.languages;
          var D = S[b], T = {};
          for (var x in D)
            if (D.hasOwnProperty(x)) {
              if (x == y)
                for (var M in v)
                  v.hasOwnProperty(M) && (T[M] = v[M]);
              v.hasOwnProperty(x) || (T[x] = D[x]);
            }
          var L = S[b];
          return S[b] = T, l.languages.DFS(l.languages, function(R, X) {
            X === L && R != b && (this[R] = T);
          }), T;
        },
        // Traverse a language definition with Depth First Search
        DFS: function b(y, v, S, D) {
          D = D || {};
          var T = l.util.objId;
          for (var x in y)
            if (y.hasOwnProperty(x)) {
              v.call(y, x, y[x], S || x);
              var M = y[x], L = l.util.type(M);
              L === "Object" && !D[T(M)] ? (D[T(M)] = !0, b(M, v, null, D)) : L === "Array" && !D[T(M)] && (D[T(M)] = !0, b(M, v, x, D));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(b, y) {
        l.highlightAllUnder(document, b, y);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(b, y, v) {
        var S = {
          callback: v,
          container: b,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        l.hooks.run("before-highlightall", S), S.elements = Array.prototype.slice.apply(S.container.querySelectorAll(S.selector)), l.hooks.run("before-all-elements-highlight", S);
        for (var D = 0, T; T = S.elements[D++]; )
          l.highlightElement(T, y === !0, S.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(b, y, v) {
        var S = l.util.getLanguage(b), D = l.languages[S];
        l.util.setLanguage(b, S);
        var T = b.parentElement;
        T && T.nodeName.toLowerCase() === "pre" && l.util.setLanguage(T, S);
        var x = b.textContent, M = {
          element: b,
          language: S,
          grammar: D,
          code: x
        };
        function L(X) {
          M.highlightedCode = X, l.hooks.run("before-insert", M), M.element.innerHTML = M.highlightedCode, l.hooks.run("after-highlight", M), l.hooks.run("complete", M), v && v.call(M.element);
        }
        if (l.hooks.run("before-sanity-check", M), T = M.element.parentElement, T && T.nodeName.toLowerCase() === "pre" && !T.hasAttribute("tabindex") && T.setAttribute("tabindex", "0"), !M.code) {
          l.hooks.run("complete", M), v && v.call(M.element);
          return;
        }
        if (l.hooks.run("before-highlight", M), !M.grammar) {
          L(l.util.encode(M.code));
          return;
        }
        if (y && r.Worker) {
          var R = new Worker(l.filename);
          R.onmessage = function(X) {
            L(X.data);
          }, R.postMessage(JSON.stringify({
            language: M.language,
            code: M.code,
            immediateClose: !0
          }));
        } else
          L(l.highlight(M.code, M.grammar, M.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(b, y, v) {
        var S = {
          code: b,
          grammar: y,
          language: v
        };
        if (l.hooks.run("before-tokenize", S), !S.grammar)
          throw new Error('The language "' + S.language + '" has no grammar.');
        return S.tokens = l.tokenize(S.code, S.grammar), l.hooks.run("after-tokenize", S), a.stringify(l.util.encode(S.tokens), S.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(b, y) {
        var v = y.rest;
        if (v) {
          for (var S in v)
            y[S] = v[S];
          delete y.rest;
        }
        var D = new d();
        return f(D, D.head, b), c(b, D, y, D.head, 0), p(D);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(b, y) {
          var v = l.hooks.all;
          v[b] = v[b] || [], v[b].push(y);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(b, y) {
          var v = l.hooks.all[b];
          if (!(!v || !v.length))
            for (var S = 0, D; D = v[S++]; )
              D(y);
        }
      },
      Token: a
    };
    r.Prism = l;
    function a(b, y, v, S) {
      this.type = b, this.content = y, this.alias = v, this.length = (S || "").length | 0;
    }
    a.stringify = function b(y, v) {
      if (typeof y == "string")
        return y;
      if (Array.isArray(y)) {
        var S = "";
        return y.forEach(function(L) {
          S += b(L, v);
        }), S;
      }
      var D = {
        type: y.type,
        content: b(y.content, v),
        tag: "span",
        classes: ["token", y.type],
        attributes: {},
        language: v
      }, T = y.alias;
      T && (Array.isArray(T) ? Array.prototype.push.apply(D.classes, T) : D.classes.push(T)), l.hooks.run("wrap", D);
      var x = "";
      for (var M in D.attributes)
        x += " " + M + '="' + (D.attributes[M] || "").replace(/"/g, "&quot;") + '"';
      return "<" + D.tag + ' class="' + D.classes.join(" ") + '"' + x + ">" + D.content + "</" + D.tag + ">";
    };
    function u(b, y, v, S) {
      b.lastIndex = y;
      var D = b.exec(v);
      if (D && S && D[1]) {
        var T = D[1].length;
        D.index += T, D[0] = D[0].slice(T);
      }
      return D;
    }
    function c(b, y, v, S, D, T) {
      for (var x in v)
        if (!(!v.hasOwnProperty(x) || !v[x])) {
          var M = v[x];
          M = Array.isArray(M) ? M : [M];
          for (var L = 0; L < M.length; ++L) {
            if (T && T.cause == x + "," + L)
              return;
            var R = M[L], X = R.inside, ke = !!R.lookbehind, ue = !!R.greedy, ae = R.alias;
            if (ue && !R.pattern.global) {
              var ie = R.pattern.toString().match(/[imsuy]*$/)[0];
              R.pattern = RegExp(R.pattern.source, ie + "g");
            }
            for (var ve = R.pattern || R, fe = S.next, xe = D; fe !== y.tail && !(T && xe >= T.reach); xe += fe.value.length, fe = fe.next) {
              var w = fe.value;
              if (y.length > b.length)
                return;
              if (!(w instanceof a)) {
                var C = 1, H;
                if (ue) {
                  if (H = u(ve, xe, b, ke), !H || H.index >= b.length)
                    break;
                  var Y = H.index, B = H.index + H[0].length, J = xe;
                  for (J += fe.value.length; Y >= J; )
                    fe = fe.next, J += fe.value.length;
                  if (J -= fe.value.length, xe = J, fe.value instanceof a)
                    continue;
                  for (var $ = fe; $ !== y.tail && (J < B || typeof $.value == "string"); $ = $.next)
                    C++, J += $.value.length;
                  C--, w = b.slice(xe, J), H.index -= xe;
                } else if (H = u(ve, 0, w, ke), !H)
                  continue;
                var Y = H.index, Le = H[0], he = w.slice(0, Y), ht = w.slice(Y + Le.length), Dn = xe + w.length;
                T && Dn > T.reach && (T.reach = Dn);
                var Wt = fe.prev;
                he && (Wt = f(y, Wt, he), xe += he.length), h(y, Wt, C);
                var Ft = new a(x, X ? l.tokenize(Le, X) : Le, ae, Le);
                if (fe = f(y, Wt, Ft), ht && f(y, fe, ht), C > 1) {
                  var Ot = {
                    cause: x + "," + L,
                    reach: Dn
                  };
                  c(b, y, v, fe.prev, xe, Ot), T && Ot.reach > T.reach && (T.reach = Ot.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var b = { value: null, prev: null, next: null }, y = { value: null, prev: b, next: null };
      b.next = y, this.head = b, this.tail = y, this.length = 0;
    }
    function f(b, y, v) {
      var S = y.next, D = { value: v, prev: y, next: S };
      return y.next = D, S.prev = D, b.length++, D;
    }
    function h(b, y, v) {
      for (var S = y.next, D = 0; D < v && S !== b.tail; D++)
        S = S.next;
      y.next = S, S.prev = y, b.length -= D;
    }
    function p(b) {
      for (var y = [], v = b.head.next; v !== b.tail; )
        y.push(v.value), v = v.next;
      return y;
    }
    if (!r.document)
      return r.addEventListener && (l.disableWorkerMessageHandler || r.addEventListener("message", function(b) {
        var y = JSON.parse(b.data), v = y.language, S = y.code, D = y.immediateClose;
        r.postMessage(l.highlight(S, l.languages[v], v)), D && r.close();
      }, !1)), l;
    var g = l.util.currentScript();
    g && (l.filename = g.src, g.hasAttribute("data-manual") && (l.manual = !0));
    function _() {
      l.manual || l.highlightAll();
    }
    if (!l.manual) {
      var k = document.readyState;
      k === "loading" || k === "interactive" && g && g.defer ? document.addEventListener("DOMContentLoaded", _) : window.requestAnimationFrame ? window.requestAnimationFrame(_) : window.setTimeout(_, 16);
    }
    return l;
  }(e);
  n.exports && (n.exports = t), typeof Gu < "u" && (Gu.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(r) {
    r.type === "entity" && (r.attributes.title = r.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, s) {
      var o = {};
      o["language-" + s] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[s]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var l = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      l["language-" + s] = {
        pattern: /[\s\S]+/,
        inside: t.languages[s]
      };
      var a = {};
      a[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: l
      }, t.languages.insertBefore("markup", "cdata", a);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(r, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + r + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(r) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    r.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, r.languages.css.atrule.inside.rest = r.languages.css;
    var s = r.languages.markup;
    s && (s.tag.addInlined("style", "css"), s.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var r = "Loading…", i = function(g, _) {
      return "✖ Error " + g + " while fetching file: " + _;
    }, s = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, l = "data-src-status", a = "loading", u = "loaded", c = "failed", d = "pre[data-src]:not([" + l + '="' + u + '"]):not([' + l + '="' + a + '"])';
    function f(g, _, k) {
      var b = new XMLHttpRequest();
      b.open("GET", g, !0), b.onreadystatechange = function() {
        b.readyState == 4 && (b.status < 400 && b.responseText ? _(b.responseText) : b.status >= 400 ? k(i(b.status, b.statusText)) : k(s));
      }, b.send(null);
    }
    function h(g) {
      var _ = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(g || "");
      if (_) {
        var k = Number(_[1]), b = _[2], y = _[3];
        return b ? y ? [k, Number(y)] : [k, void 0] : [k, k];
      }
    }
    t.hooks.add("before-highlightall", function(g) {
      g.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(g) {
      var _ = (
        /** @type {HTMLPreElement} */
        g.element
      );
      if (_.matches(d)) {
        g.code = "", _.setAttribute(l, a);
        var k = _.appendChild(document.createElement("CODE"));
        k.textContent = r;
        var b = _.getAttribute("data-src"), y = g.language;
        if (y === "none") {
          var v = (/\.(\w+)$/.exec(b) || [, "none"])[1];
          y = o[v] || v;
        }
        t.util.setLanguage(k, y), t.util.setLanguage(_, y);
        var S = t.plugins.autoloader;
        S && S.loadLanguages(y), f(
          b,
          function(D) {
            _.setAttribute(l, u);
            var T = h(_.getAttribute("data-range"));
            if (T) {
              var x = D.split(/\r\n?|\n/g), M = T[0], L = T[1] == null ? x.length : T[1];
              M < 0 && (M += x.length), M = Math.max(0, Math.min(M - 1, x.length)), L < 0 && (L += x.length), L = Math.max(0, Math.min(L, x.length)), D = x.slice(M, L).join(`
`), _.hasAttribute("data-start") || _.setAttribute("data-start", String(M + 1));
            }
            k.textContent = D, t.highlightElement(k);
          },
          function(D) {
            _.setAttribute(l, c), k.textContent = D;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(_) {
        for (var k = (_ || document).querySelectorAll(d), b = 0, y; y = k[b++]; )
          t.highlightElement(y);
      }
    };
    var p = !1;
    t.fileHighlight = function() {
      p || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), p = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Vf);
var Jo = Vf.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, r = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: r.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: r.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], s = r.variable[1].inside, o = 0; o < i.length; o++)
    s[i[o]] = n.languages.bash[i[o]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
const r_ = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', i_ = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, s_ = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, Ju = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${i_}</span>
  <span class="check">${s_}</span>
</button>`, Uf = /[&<>"']/, o_ = new RegExp(Uf.source, "g"), Wf = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, l_ = new RegExp(Wf.source, "g"), a_ = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Yu = (n) => a_[n] || "";
function Yo(n, e) {
  if (e) {
    if (Uf.test(n))
      return n.replace(o_, Yu);
  } else if (Wf.test(n))
    return n.replace(l_, Yu);
  return n;
}
function u_(n) {
  const e = n.map((t) => ({
    start: new RegExp(t.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(t.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(t) {
      for (const r of e) {
        const i = t.match(r.start);
        if (i)
          return i.index;
      }
      return -1;
    },
    tokenizer(t, r) {
      for (const i of e) {
        const s = new RegExp(
          `${i.start.source}([\\s\\S]+?)${i.end.source}`
        ).exec(t);
        if (s)
          return {
            type: "latex",
            raw: s[0],
            text: s[1].trim()
          };
      }
    },
    renderer(t) {
      return `<div class="latex-block">${t.text}</div>`;
    }
  };
}
function c_() {
  return {
    name: "mermaid",
    level: "block",
    start(n) {
      var e;
      return (e = n.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(n) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(n);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(n) {
      return `<div class="mermaid">${n.text}</div>
`;
    }
  };
}
const d_ = {
  code(n, e, t) {
    var i;
    const r = ((i = (e ?? "").match(/\S*/)) == null ? void 0 : i[0]) ?? "";
    return n = n.replace(/\n$/, "") + `
`, !r || r === "mermaid" ? '<div class="code_wrap">' + Ju + "<pre><code>" + (t ? n : Yo(n, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Ju + '<pre><code class="language-' + Yo(r) + '">' + (t ? n : Yo(n, !0)) + `</code></pre></div>
`;
  }
}, f_ = new Fa();
function h_({
  header_links: n,
  line_breaks: e,
  latex_delimiters: t
}) {
  const r = new Pf();
  r.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    Gg({
      highlight: (o, l) => {
        var a;
        return (a = Jo.languages) != null && a[l] ? Jo.highlight(o, Jo.languages[l], l) : o;
      }
    }),
    { renderer: d_ }
  ), n && (r.use(t_()), r.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(o) {
          const l = o.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), a = "h" + f_.slug(l), u = o.depth, c = this.parser.parseInline(o.tokens);
          return `<h${u} id="${a}"><a class="md-header-anchor" href="#${a}">${r_}</a>${c}</h${u}>
`;
        }
      }
    ]
  }));
  const i = c_(), s = u_(t);
  return r.use({
    extensions: [i, s]
  }), r;
}
const Bl = (n) => JSON.parse(JSON.stringify(n)), p_ = (n) => n.nodeType === 1, m_ = (n) => I_.has(n.tagName), g_ = (n) => "action" in n, __ = (n) => n.tagName === "IFRAME", y_ = (n) => "formAction" in n, b_ = (n) => "protocol" in n, ts = /* @__PURE__ */ (() => {
  const n = /^(?:\w+script|data):/i;
  return (e) => n.test(e);
})(), k_ = /* @__PURE__ */ (() => {
  const n = /(?:script|data):/i;
  return (e) => n.test(e);
})(), v_ = (n) => {
  const e = {};
  for (let t = 0, r = n.length; t < r; t++) {
    const i = n[t];
    for (const s in i)
      e[s] ? e[s] = e[s].concat(i[s]) : e[s] = i[s];
  }
  return e;
}, Kf = (n, e) => {
  let t = n.firstChild;
  for (; t; ) {
    const r = t.nextSibling;
    p_(t) && (e(t, n), t.parentNode && Kf(t, e)), t = r;
  }
}, w_ = (n, e) => {
  const t = document.createNodeIterator(n, NodeFilter.SHOW_ELEMENT);
  let r;
  for (; r = t.nextNode(); ) {
    const i = r.parentNode;
    i && e(r, i);
  }
}, E_ = (n, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? w_(n, e) : Kf(n, e), Gf = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], S_ = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], C_ = /* @__PURE__ */ new Set([
  ...Gf,
  ...S_
]), Jf = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], D_ = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], A_ = /* @__PURE__ */ new Set([
  ...Jf,
  ...D_
]), Yf = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], T_ = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], x_ = /* @__PURE__ */ new Set([
  ...Yf,
  ...T_
]), M_ = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], $_ = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], F_ = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], Vt = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, O_ = {
  [Vt.HTML]: C_,
  [Vt.SVG]: A_,
  [Vt.MATH]: x_
}, N_ = {
  [Vt.HTML]: "html",
  [Vt.SVG]: "svg",
  [Vt.MATH]: "math"
}, R_ = {
  [Vt.HTML]: "",
  [Vt.SVG]: "svg:",
  [Vt.MATH]: "math:"
}, I_ = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), Xf = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...Gf,
    ...Jf.map((n) => `svg:${n}`),
    ...Yf.map((n) => `math:${n}`)
  ],
  allowAttributes: v_([
    Object.fromEntries(M_.map((n) => [n, ["*"]])),
    Object.fromEntries($_.map((n) => [n, ["svg:*"]])),
    Object.fromEntries(F_.map((n) => [n, ["math:*"]]))
  ])
};
var Xo = function(n, e, t, r, i) {
  if (r === "m") throw new TypeError("Private method is not writable");
  if (r === "a" && !i) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? n !== e || !i : !e.has(n)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return r === "a" ? i.call(n, t) : i ? i.value = t : e.set(n, t), t;
}, Zn = function(n, e, t, r) {
  if (t === "a" && !r) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? n !== e || !r : !e.has(n)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? r : t === "a" ? r.call(n) : r ? r.value : e.get(n);
}, $n, Cs, Ds;
class Zf {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    $n.set(this, void 0), Cs.set(this, void 0), Ds.set(this, void 0), this.getConfiguration = () => Bl(Zn(this, $n, "f")), this.sanitize = (c) => {
      const d = Zn(this, Cs, "f"), f = Zn(this, Ds, "f");
      return E_(c, (h, p) => {
        const g = h.namespaceURI || Vt.HTML, _ = p.namespaceURI || Vt.HTML, k = O_[g], b = N_[g], y = R_[g], v = h.tagName.toLowerCase(), S = `${y}${v}`, T = `${y}*`;
        if (!k.has(v) || !d.has(S) || g !== _ && v !== b)
          p.removeChild(h);
        else {
          const x = h.getAttributeNames(), M = x.length;
          if (M) {
            for (let L = 0; L < M; L++) {
              const R = x[L], X = f[R];
              (!X || !X.has(T) && !X.has(S)) && h.removeAttribute(R);
            }
            if (m_(h))
              if (b_(h)) {
                const L = h.getAttribute("href");
                L && k_(L) && ts(h.protocol) && h.removeAttribute("href");
              } else g_(h) ? ts(h.action) && h.removeAttribute("action") : y_(h) ? ts(h.formAction) && h.removeAttribute("formaction") : __(h) && (ts(h.src) && h.removeAttribute("formaction"), h.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), c;
    }, this.sanitizeFor = (c, d) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: t, allowCustomElements: r, allowUnknownMarkup: i, blockElements: s, dropElements: o, dropAttributes: l } = e;
    if (t === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (r)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (i)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (s)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (l)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    Xo(this, $n, Bl(Xf), "f");
    const { allowElements: a, allowAttributes: u } = e;
    a && (Zn(this, $n, "f").allowElements = e.allowElements), u && (Zn(this, $n, "f").allowAttributes = e.allowAttributes), Xo(this, Cs, new Set(Zn(this, $n, "f").allowElements), "f"), Xo(this, Ds, Object.fromEntries(Object.entries(Zn(this, $n, "f").allowAttributes || {}).map(([c, d]) => [c, new Set(d)])), "f");
  }
}
$n = /* @__PURE__ */ new WeakMap(), Cs = /* @__PURE__ */ new WeakMap(), Ds = /* @__PURE__ */ new WeakMap();
Zf.getDefaultConfiguration = () => Bl(Xf);
const L_ = (n, e = location.href) => {
  try {
    return !!n && new URL(n).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function Xu(n) {
  const e = new Zf(), t = new DOMParser().parseFromString(n, "text/html");
  return Qf(t.body, "A", (r) => {
    r instanceof HTMLElement && "target" in r && L_(r.getAttribute("href"), location.href) && (r.setAttribute("target", "_blank"), r.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(t).body.innerHTML;
}
function Qf(n, e, t) {
  n && (n.nodeName === e || typeof e == "function") && t(n);
  const r = (n == null ? void 0 : n.childNodes) || [];
  for (let i = 0; i < r.length; i++)
    Qf(r[i], e, t);
}
const Zu = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], P_ = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], B_ = [
  ...Zu,
  ...P_.filter((n) => !Zu.includes(n))
], {
  HtmlTagHydration: z_,
  SvelteComponent: H_,
  attr: q_,
  binding_callbacks: j_,
  children: V_,
  claim_element: U_,
  claim_html_tag: W_,
  detach: Qu,
  element: K_,
  init: G_,
  insert_hydration: J_,
  noop: ec,
  safe_not_equal: Y_,
  toggle_class: ns
} = window.__gradio__svelte__internal, { afterUpdate: X_, tick: Z_, onMount: yC } = window.__gradio__svelte__internal;
function Q_(n) {
  let e, t;
  return {
    c() {
      e = K_("span"), t = new z_(!1), this.h();
    },
    l(r) {
      e = U_(r, "SPAN", { class: !0 });
      var i = V_(e);
      t = W_(i, !1), i.forEach(Qu), this.h();
    },
    h() {
      t.a = null, q_(e, "class", "md svelte-1m32c2s"), ns(
        e,
        "chatbot",
        /*chatbot*/
        n[0]
      ), ns(
        e,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    m(r, i) {
      J_(r, e, i), t.m(
        /*html*/
        n[3],
        e
      ), n[11](e);
    },
    p(r, [i]) {
      i & /*html*/
      8 && t.p(
        /*html*/
        r[3]
      ), i & /*chatbot*/
      1 && ns(
        e,
        "chatbot",
        /*chatbot*/
        r[0]
      ), i & /*render_markdown*/
      2 && ns(
        e,
        "prose",
        /*render_markdown*/
        r[1]
      );
    },
    i: ec,
    o: ec,
    d(r) {
      r && Qu(e), n[11](null);
    }
  };
}
function tc(n) {
  return n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function e0(n, e, t) {
  var r = this && this.__awaiter || function(D, T, x, M) {
    function L(R) {
      return R instanceof x ? R : new x(function(X) {
        X(R);
      });
    }
    return new (x || (x = Promise))(function(R, X) {
      function ke(ie) {
        try {
          ae(M.next(ie));
        } catch (ve) {
          X(ve);
        }
      }
      function ue(ie) {
        try {
          ae(M.throw(ie));
        } catch (ve) {
          X(ve);
        }
      }
      function ae(ie) {
        ie.done ? R(ie.value) : L(ie.value).then(ke, ue);
      }
      ae((M = M.apply(D, T || [])).next());
    });
  };
  let { chatbot: i = !0 } = e, { message: s } = e, { sanitize_html: o = !0 } = e, { latex_delimiters: l = [] } = e, { render_markdown: a = !0 } = e, { line_breaks: u = !0 } = e, { header_links: c = !1 } = e, { allow_tags: d = !1 } = e, { theme_mode: f = "system" } = e, h, p, g = !1;
  const _ = h_({
    header_links: c,
    line_breaks: u,
    latex_delimiters: l || []
  });
  function k(D) {
    return !l || l.length === 0 ? !1 : l.some((T) => D.includes(T.left) && D.includes(T.right));
  }
  function b(D, T) {
    if (T === !0) {
      const x = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return D.replace(x, (M, L, R) => B_.includes(L.toLowerCase()) ? M : M.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(T)) {
      const x = T.map((L) => ({
        open: new RegExp(`<(${L})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${L})>`, "gi")
      }));
      let M = D;
      return x.forEach((L) => {
        M = M.replace(L.open, (R) => R.replace(/</g, "&lt;").replace(/>/g, "&gt;")), M = M.replace(L.close, (R) => R.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), M;
    }
    return D;
  }
  function y(D) {
    let T = D;
    if (a) {
      const x = [];
      l.forEach((M, L) => {
        const R = tc(M.left), X = tc(M.right), ke = new RegExp(`${R}([\\s\\S]+?)${X}`, "g");
        T = T.replace(ke, (ue, ae) => (x.push(ue), `%%%LATEX_BLOCK_${x.length - 1}%%%`));
      }), T = _.parse(T), T = T.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (M, L) => x[parseInt(L, 10)]);
    }
    return d && (T = b(T, d)), o && Xu && (T = Xu(T)), T;
  }
  function v(D) {
    return r(this, void 0, void 0, function* () {
      if (l.length > 0 && D && k(D))
        if (!g)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-BwaQGe8P.js")
          ]).then(([, { default: T }]) => {
            g = !0, T(h, {
              delimiters: l,
              throwOnError: !1
            });
          });
        else {
          const { default: T } = yield import("./auto-render-BwaQGe8P.js");
          T(h, {
            delimiters: l,
            throwOnError: !1
          });
        }
      if (h) {
        const T = h.querySelectorAll(".mermaid");
        if (T.length > 0) {
          yield Z_();
          const { default: x } = yield import("./mermaid.core-44uyjPWj.js").then((M) => M.bB);
          x.initialize({
            startOnLoad: !1,
            theme: f === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield x.run({
            nodes: Array.from(T).map((M) => M)
          });
        }
      }
    });
  }
  X_(() => r(void 0, void 0, void 0, function* () {
    h && document.body.contains(h) ? yield v(s) : console.error("Element is not in the DOM");
  }));
  function S(D) {
    j_[D ? "unshift" : "push"](() => {
      h = D, t(2, h);
    });
  }
  return n.$$set = (D) => {
    "chatbot" in D && t(0, i = D.chatbot), "message" in D && t(4, s = D.message), "sanitize_html" in D && t(5, o = D.sanitize_html), "latex_delimiters" in D && t(6, l = D.latex_delimiters), "render_markdown" in D && t(1, a = D.render_markdown), "line_breaks" in D && t(7, u = D.line_breaks), "header_links" in D && t(8, c = D.header_links), "allow_tags" in D && t(9, d = D.allow_tags), "theme_mode" in D && t(10, f = D.theme_mode);
  }, n.$$.update = () => {
    n.$$.dirty & /*message*/
    16 && (s && s.trim() ? t(3, p = y(s)) : t(3, p = ""));
  }, [
    i,
    a,
    h,
    p,
    s,
    o,
    l,
    u,
    c,
    d,
    f,
    S
  ];
}
class t0 extends H_ {
  constructor(e) {
    super(), G_(this, e, e0, Q_, Y_, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: n0,
  attr: r0,
  children: i0,
  claim_component: s0,
  claim_element: o0,
  create_component: l0,
  destroy_component: a0,
  detach: nc,
  element: u0,
  init: c0,
  insert_hydration: d0,
  mount_component: f0,
  safe_not_equal: h0,
  transition_in: p0,
  transition_out: m0
} = window.__gradio__svelte__internal;
function g0(n) {
  let e, t, r;
  return t = new t0({
    props: {
      message: (
        /*info*/
        n[0]
      ),
      sanitize_html: !0
    }
  }), {
    c() {
      e = u0("div"), l0(t.$$.fragment), this.h();
    },
    l(i) {
      e = o0(i, "DIV", { class: !0 });
      var s = i0(e);
      s0(t.$$.fragment, s), s.forEach(nc), this.h();
    },
    h() {
      r0(e, "class", "svelte-17qq50w");
    },
    m(i, s) {
      d0(i, e, s), f0(t, e, null), r = !0;
    },
    p(i, [s]) {
      const o = {};
      s & /*info*/
      1 && (o.message = /*info*/
      i[0]), t.$set(o);
    },
    i(i) {
      r || (p0(t.$$.fragment, i), r = !0);
    },
    o(i) {
      m0(t.$$.fragment, i), r = !1;
    },
    d(i) {
      i && nc(e), a0(t);
    }
  };
}
function _0(n, e, t) {
  let { info: r } = e;
  return n.$$set = (i) => {
    "info" in i && t(0, r = i.info);
  }, [r];
}
class y0 extends n0 {
  constructor(e) {
    super(), c0(this, e, _0, g0, h0, { info: 0 });
  }
}
const {
  SvelteComponent: b0,
  attr: rs,
  check_outros: k0,
  children: v0,
  claim_component: w0,
  claim_element: E0,
  claim_space: S0,
  create_component: C0,
  create_slot: D0,
  destroy_component: A0,
  detach: is,
  element: T0,
  empty: rc,
  get_all_dirty_from_scope: x0,
  get_slot_changes: M0,
  group_outros: $0,
  init: F0,
  insert_hydration: Zo,
  mount_component: O0,
  safe_not_equal: N0,
  space: R0,
  toggle_class: Dr,
  transition_in: ui,
  transition_out: As,
  update_slot_base: I0
} = window.__gradio__svelte__internal;
function ic(n) {
  let e, t;
  return e = new y0({ props: { info: (
    /*info*/
    n[1]
  ) } }), {
    c() {
      C0(e.$$.fragment);
    },
    l(r) {
      w0(e.$$.fragment, r);
    },
    m(r, i) {
      O0(e, r, i), t = !0;
    },
    p(r, i) {
      const s = {};
      i & /*info*/
      2 && (s.info = /*info*/
      r[1]), e.$set(s);
    },
    i(r) {
      t || (ui(e.$$.fragment, r), t = !0);
    },
    o(r) {
      As(e.$$.fragment, r), t = !1;
    },
    d(r) {
      A0(e, r);
    }
  };
}
function L0(n) {
  let e, t, r, i, s;
  const o = (
    /*#slots*/
    n[4].default
  ), l = D0(
    o,
    n,
    /*$$scope*/
    n[3],
    null
  );
  let a = (
    /*info*/
    n[1] && ic(n)
  );
  return {
    c() {
      e = T0("span"), l && l.c(), r = R0(), a && a.c(), i = rc(), this.h();
    },
    l(u) {
      e = E0(u, "SPAN", {
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var c = v0(e);
      l && l.l(c), c.forEach(is), r = S0(u), a && a.l(u), i = rc(), this.h();
    },
    h() {
      rs(e, "data-testid", "block-info"), rs(e, "dir", t = /*rtl*/
      n[2] ? "rtl" : "ltr"), rs(e, "class", "svelte-zgrq3"), Dr(e, "sr-only", !/*show_label*/
      n[0]), Dr(e, "hide", !/*show_label*/
      n[0]), Dr(
        e,
        "has-info",
        /*info*/
        n[1] != null
      );
    },
    m(u, c) {
      Zo(u, e, c), l && l.m(e, null), Zo(u, r, c), a && a.m(u, c), Zo(u, i, c), s = !0;
    },
    p(u, [c]) {
      l && l.p && (!s || c & /*$$scope*/
      8) && I0(
        l,
        o,
        u,
        /*$$scope*/
        u[3],
        s ? M0(
          o,
          /*$$scope*/
          u[3],
          c,
          null
        ) : x0(
          /*$$scope*/
          u[3]
        ),
        null
      ), (!s || c & /*rtl*/
      4 && t !== (t = /*rtl*/
      u[2] ? "rtl" : "ltr")) && rs(e, "dir", t), (!s || c & /*show_label*/
      1) && Dr(e, "sr-only", !/*show_label*/
      u[0]), (!s || c & /*show_label*/
      1) && Dr(e, "hide", !/*show_label*/
      u[0]), (!s || c & /*info*/
      2) && Dr(
        e,
        "has-info",
        /*info*/
        u[1] != null
      ), /*info*/
      u[1] ? a ? (a.p(u, c), c & /*info*/
      2 && ui(a, 1)) : (a = ic(u), a.c(), ui(a, 1), a.m(i.parentNode, i)) : a && ($0(), As(a, 1, 1, () => {
        a = null;
      }), k0());
    },
    i(u) {
      s || (ui(l, u), ui(a), s = !0);
    },
    o(u) {
      As(l, u), As(a), s = !1;
    },
    d(u) {
      u && (is(e), is(r), is(i)), l && l.d(u), a && a.d(u);
    }
  };
}
function P0(n, e, t) {
  let { $$slots: r = {}, $$scope: i } = e, { show_label: s = !0 } = e, { info: o = void 0 } = e, { rtl: l = !1 } = e;
  return n.$$set = (a) => {
    "show_label" in a && t(0, s = a.show_label), "info" in a && t(1, o = a.info), "rtl" in a && t(2, l = a.rtl), "$$scope" in a && t(3, i = a.$$scope);
  }, [s, o, l, i, r];
}
class B0 extends b0 {
  constructor(e) {
    super(), F0(this, e, P0, L0, N0, { show_label: 0, info: 1, rtl: 2 });
  }
}
const {
  SvelteComponent: bC,
  append_hydration: kC,
  attr: vC,
  children: wC,
  claim_component: EC,
  claim_element: SC,
  claim_space: CC,
  claim_text: DC,
  create_component: AC,
  destroy_component: TC,
  detach: xC,
  element: MC,
  init: $C,
  insert_hydration: FC,
  mount_component: OC,
  safe_not_equal: NC,
  set_data: RC,
  space: IC,
  text: LC,
  toggle_class: PC,
  transition_in: BC,
  transition_out: zC
} = window.__gradio__svelte__internal, {
  SvelteComponent: z0,
  append_hydration: Ts,
  attr: yn,
  bubble: H0,
  check_outros: q0,
  children: zl,
  claim_component: j0,
  claim_element: Hl,
  claim_space: sc,
  claim_text: V0,
  construct_svelte_component: oc,
  create_component: lc,
  create_slot: U0,
  destroy_component: ac,
  detach: bi,
  element: ql,
  get_all_dirty_from_scope: W0,
  get_slot_changes: K0,
  group_outros: G0,
  init: J0,
  insert_hydration: eh,
  listen: Y0,
  mount_component: uc,
  safe_not_equal: X0,
  set_data: Z0,
  set_style: ss,
  space: cc,
  text: Q0,
  toggle_class: Je,
  transition_in: Qo,
  transition_out: el,
  update_slot_base: ey
} = window.__gradio__svelte__internal;
function dc(n) {
  let e, t;
  return {
    c() {
      e = ql("span"), t = Q0(
        /*label*/
        n[1]
      ), this.h();
    },
    l(r) {
      e = Hl(r, "SPAN", { class: !0 });
      var i = zl(e);
      t = V0(
        i,
        /*label*/
        n[1]
      ), i.forEach(bi), this.h();
    },
    h() {
      yn(e, "class", "svelte-qgco6m");
    },
    m(r, i) {
      eh(r, e, i), Ts(e, t);
    },
    p(r, i) {
      i & /*label*/
      2 && Z0(
        t,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && bi(e);
    }
  };
}
function ty(n) {
  let e, t, r, i, s, o, l, a, u = (
    /*show_label*/
    n[2] && dc(n)
  );
  var c = (
    /*Icon*/
    n[0]
  );
  function d(p, g) {
    return {};
  }
  c && (i = oc(c, d()));
  const f = (
    /*#slots*/
    n[14].default
  ), h = U0(
    f,
    n,
    /*$$scope*/
    n[13],
    null
  );
  return {
    c() {
      e = ql("button"), u && u.c(), t = cc(), r = ql("div"), i && lc(i.$$.fragment), s = cc(), h && h.c(), this.h();
    },
    l(p) {
      e = Hl(p, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var g = zl(e);
      u && u.l(g), t = sc(g), r = Hl(g, "DIV", { class: !0 });
      var _ = zl(r);
      i && j0(i.$$.fragment, _), s = sc(_), h && h.l(_), _.forEach(bi), g.forEach(bi), this.h();
    },
    h() {
      yn(r, "class", "svelte-qgco6m"), Je(
        r,
        "x-small",
        /*size*/
        n[4] === "x-small"
      ), Je(
        r,
        "small",
        /*size*/
        n[4] === "small"
      ), Je(
        r,
        "large",
        /*size*/
        n[4] === "large"
      ), Je(
        r,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], yn(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), yn(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), yn(
        e,
        "title",
        /*label*/
        n[1]
      ), yn(e, "class", "svelte-qgco6m"), Je(
        e,
        "pending",
        /*pending*/
        n[3]
      ), Je(
        e,
        "padded",
        /*padded*/
        n[5]
      ), Je(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), Je(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), ss(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), ss(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(p, g) {
      eh(p, e, g), u && u.m(e, null), Ts(e, t), Ts(e, r), i && uc(i, r, null), Ts(r, s), h && h.m(r, null), o = !0, l || (a = Y0(
        e,
        "click",
        /*click_handler*/
        n[15]
      ), l = !0);
    },
    p(p, [g]) {
      if (/*show_label*/
      p[2] ? u ? u.p(p, g) : (u = dc(p), u.c(), u.m(e, t)) : u && (u.d(1), u = null), g & /*Icon*/
      1 && c !== (c = /*Icon*/
      p[0])) {
        if (i) {
          G0();
          const _ = i;
          el(_.$$.fragment, 1, 0, () => {
            ac(_, 1);
          }), q0();
        }
        c ? (i = oc(c, d()), lc(i.$$.fragment), Qo(i.$$.fragment, 1), uc(i, r, s)) : i = null;
      }
      h && h.p && (!o || g & /*$$scope*/
      8192) && ey(
        h,
        f,
        p,
        /*$$scope*/
        p[13],
        o ? K0(
          f,
          /*$$scope*/
          p[13],
          g,
          null
        ) : W0(
          /*$$scope*/
          p[13]
        ),
        null
      ), (!o || g & /*size*/
      16) && Je(
        r,
        "x-small",
        /*size*/
        p[4] === "x-small"
      ), (!o || g & /*size*/
      16) && Je(
        r,
        "small",
        /*size*/
        p[4] === "small"
      ), (!o || g & /*size*/
      16) && Je(
        r,
        "large",
        /*size*/
        p[4] === "large"
      ), (!o || g & /*size*/
      16) && Je(
        r,
        "medium",
        /*size*/
        p[4] === "medium"
      ), (!o || g & /*disabled*/
      128) && (e.disabled = /*disabled*/
      p[7]), (!o || g & /*label*/
      2) && yn(
        e,
        "aria-label",
        /*label*/
        p[1]
      ), (!o || g & /*hasPopup*/
      256) && yn(
        e,
        "aria-haspopup",
        /*hasPopup*/
        p[8]
      ), (!o || g & /*label*/
      2) && yn(
        e,
        "title",
        /*label*/
        p[1]
      ), (!o || g & /*pending*/
      8) && Je(
        e,
        "pending",
        /*pending*/
        p[3]
      ), (!o || g & /*padded*/
      32) && Je(
        e,
        "padded",
        /*padded*/
        p[5]
      ), (!o || g & /*highlight*/
      64) && Je(
        e,
        "highlight",
        /*highlight*/
        p[6]
      ), (!o || g & /*transparent*/
      512) && Je(
        e,
        "transparent",
        /*transparent*/
        p[9]
      ), g & /*disabled, _color*/
      2176 && ss(e, "color", !/*disabled*/
      p[7] && /*_color*/
      p[11] ? (
        /*_color*/
        p[11]
      ) : "var(--block-label-text-color)"), g & /*disabled, background*/
      1152 && ss(e, "--bg-color", /*disabled*/
      p[7] ? "auto" : (
        /*background*/
        p[10]
      ));
    },
    i(p) {
      o || (i && Qo(i.$$.fragment, p), Qo(h, p), o = !0);
    },
    o(p) {
      i && el(i.$$.fragment, p), el(h, p), o = !1;
    },
    d(p) {
      p && bi(e), u && u.d(), i && ac(i), h && h.d(p), l = !1, a();
    }
  };
}
function ny(n, e, t) {
  let r, { $$slots: i = {}, $$scope: s } = e, { Icon: o } = e, { label: l = "" } = e, { show_label: a = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: d = !0 } = e, { highlight: f = !1 } = e, { disabled: h = !1 } = e, { hasPopup: p = !1 } = e, { color: g = "var(--block-label-text-color)" } = e, { transparent: _ = !1 } = e, { background: k = "var(--block-background-fill)" } = e;
  function b(y) {
    H0.call(this, n, y);
  }
  return n.$$set = (y) => {
    "Icon" in y && t(0, o = y.Icon), "label" in y && t(1, l = y.label), "show_label" in y && t(2, a = y.show_label), "pending" in y && t(3, u = y.pending), "size" in y && t(4, c = y.size), "padded" in y && t(5, d = y.padded), "highlight" in y && t(6, f = y.highlight), "disabled" in y && t(7, h = y.disabled), "hasPopup" in y && t(8, p = y.hasPopup), "color" in y && t(12, g = y.color), "transparent" in y && t(9, _ = y.transparent), "background" in y && t(10, k = y.background), "$$scope" in y && t(13, s = y.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, r = f ? "var(--color-accent)" : g);
  }, [
    o,
    l,
    a,
    u,
    c,
    d,
    f,
    h,
    p,
    _,
    k,
    r,
    g,
    s,
    i,
    b
  ];
}
class ry extends z0 {
  constructor(e) {
    super(), J0(this, e, ny, ty, X0, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: HC,
  append_hydration: qC,
  attr: jC,
  binding_callbacks: VC,
  children: UC,
  claim_element: WC,
  create_slot: KC,
  detach: GC,
  element: JC,
  get_all_dirty_from_scope: YC,
  get_slot_changes: XC,
  init: ZC,
  insert_hydration: QC,
  safe_not_equal: eD,
  toggle_class: tD,
  transition_in: nD,
  transition_out: rD,
  update_slot_base: iD
} = window.__gradio__svelte__internal, {
  SvelteComponent: sD,
  append_hydration: oD,
  attr: lD,
  children: aD,
  claim_svg_element: uD,
  detach: cD,
  init: dD,
  insert_hydration: fD,
  noop: hD,
  safe_not_equal: pD,
  svg_element: mD
} = window.__gradio__svelte__internal, {
  SvelteComponent: gD,
  append_hydration: _D,
  attr: yD,
  children: bD,
  claim_svg_element: kD,
  detach: vD,
  init: wD,
  insert_hydration: ED,
  noop: SD,
  safe_not_equal: CD,
  svg_element: DD
} = window.__gradio__svelte__internal, {
  SvelteComponent: AD,
  append_hydration: TD,
  attr: xD,
  children: MD,
  claim_svg_element: $D,
  detach: FD,
  init: OD,
  insert_hydration: ND,
  noop: RD,
  safe_not_equal: ID,
  svg_element: LD
} = window.__gradio__svelte__internal, {
  SvelteComponent: PD,
  append_hydration: BD,
  attr: zD,
  children: HD,
  claim_svg_element: qD,
  detach: jD,
  init: VD,
  insert_hydration: UD,
  noop: WD,
  safe_not_equal: KD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: JD,
  append_hydration: YD,
  attr: XD,
  children: ZD,
  claim_svg_element: QD,
  detach: eA,
  init: tA,
  insert_hydration: nA,
  noop: rA,
  safe_not_equal: iA,
  svg_element: sA
} = window.__gradio__svelte__internal, {
  SvelteComponent: oA,
  append_hydration: lA,
  attr: aA,
  children: uA,
  claim_svg_element: cA,
  detach: dA,
  init: fA,
  insert_hydration: hA,
  noop: pA,
  safe_not_equal: mA,
  svg_element: gA
} = window.__gradio__svelte__internal, {
  SvelteComponent: _A,
  append_hydration: yA,
  attr: bA,
  children: kA,
  claim_svg_element: vA,
  detach: wA,
  init: EA,
  insert_hydration: SA,
  noop: CA,
  safe_not_equal: DA,
  svg_element: AA
} = window.__gradio__svelte__internal, {
  SvelteComponent: TA,
  append_hydration: xA,
  attr: MA,
  children: $A,
  claim_svg_element: FA,
  detach: OA,
  init: NA,
  insert_hydration: RA,
  noop: IA,
  safe_not_equal: LA,
  svg_element: PA
} = window.__gradio__svelte__internal, {
  SvelteComponent: BA,
  append_hydration: zA,
  attr: HA,
  children: qA,
  claim_svg_element: jA,
  detach: VA,
  init: UA,
  insert_hydration: WA,
  noop: KA,
  safe_not_equal: GA,
  svg_element: JA
} = window.__gradio__svelte__internal, {
  SvelteComponent: YA,
  append_hydration: XA,
  attr: ZA,
  children: QA,
  claim_svg_element: eT,
  detach: tT,
  init: nT,
  insert_hydration: rT,
  noop: iT,
  safe_not_equal: sT,
  svg_element: oT
} = window.__gradio__svelte__internal, {
  SvelteComponent: lT,
  append_hydration: aT,
  attr: uT,
  children: cT,
  claim_svg_element: dT,
  detach: fT,
  init: hT,
  insert_hydration: pT,
  noop: mT,
  safe_not_equal: gT,
  svg_element: _T
} = window.__gradio__svelte__internal, {
  SvelteComponent: yT,
  append_hydration: bT,
  attr: kT,
  children: vT,
  claim_svg_element: wT,
  detach: ET,
  init: ST,
  insert_hydration: CT,
  noop: DT,
  safe_not_equal: AT,
  svg_element: TT
} = window.__gradio__svelte__internal, {
  SvelteComponent: iy,
  append_hydration: tl,
  attr: Rt,
  children: ls,
  claim_svg_element: as,
  detach: ti,
  init: sy,
  insert_hydration: oy,
  noop: nl,
  safe_not_equal: ly,
  set_style: Yt,
  svg_element: us
} = window.__gradio__svelte__internal;
function ay(n) {
  let e, t, r, i;
  return {
    c() {
      e = us("svg"), t = us("g"), r = us("path"), i = us("path"), this.h();
    },
    l(s) {
      e = as(s, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var o = ls(e);
      t = as(o, "g", { transform: !0 });
      var l = ls(t);
      r = as(l, "path", { d: !0, style: !0 }), ls(r).forEach(ti), l.forEach(ti), i = as(o, "path", { d: !0, style: !0 }), ls(i).forEach(ti), o.forEach(ti), this.h();
    },
    h() {
      Rt(r, "d", "M18,6L6.087,17.913"), Yt(r, "fill", "none"), Yt(r, "fill-rule", "nonzero"), Yt(r, "stroke-width", "2px"), Rt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Rt(i, "d", "M4.364,4.364L19.636,19.636"), Yt(i, "fill", "none"), Yt(i, "fill-rule", "nonzero"), Yt(i, "stroke-width", "2px"), Rt(e, "width", "100%"), Rt(e, "height", "100%"), Rt(e, "viewBox", "0 0 24 24"), Rt(e, "version", "1.1"), Rt(e, "xmlns", "http://www.w3.org/2000/svg"), Rt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Rt(e, "xml:space", "preserve"), Rt(e, "stroke", "currentColor"), Yt(e, "fill-rule", "evenodd"), Yt(e, "clip-rule", "evenodd"), Yt(e, "stroke-linecap", "round"), Yt(e, "stroke-linejoin", "round");
    },
    m(s, o) {
      oy(s, e, o), tl(e, t), tl(t, r), tl(e, i);
    },
    p: nl,
    i: nl,
    o: nl,
    d(s) {
      s && ti(e);
    }
  };
}
class uy extends iy {
  constructor(e) {
    super(), sy(this, e, null, ay, ly, {});
  }
}
const {
  SvelteComponent: xT,
  append_hydration: MT,
  attr: $T,
  children: FT,
  claim_svg_element: OT,
  detach: NT,
  init: RT,
  insert_hydration: IT,
  noop: LT,
  safe_not_equal: PT,
  svg_element: BT
} = window.__gradio__svelte__internal, {
  SvelteComponent: zT,
  append_hydration: HT,
  attr: qT,
  children: jT,
  claim_svg_element: VT,
  detach: UT,
  init: WT,
  insert_hydration: KT,
  noop: GT,
  safe_not_equal: JT,
  svg_element: YT
} = window.__gradio__svelte__internal, {
  SvelteComponent: XT,
  append_hydration: ZT,
  attr: QT,
  children: ex,
  claim_svg_element: tx,
  detach: nx,
  init: rx,
  insert_hydration: ix,
  noop: sx,
  safe_not_equal: ox,
  svg_element: lx
} = window.__gradio__svelte__internal, {
  SvelteComponent: ax,
  append_hydration: ux,
  attr: cx,
  children: dx,
  claim_svg_element: fx,
  detach: hx,
  init: px,
  insert_hydration: mx,
  noop: gx,
  safe_not_equal: _x,
  svg_element: yx
} = window.__gradio__svelte__internal, {
  SvelteComponent: bx,
  append_hydration: kx,
  attr: vx,
  children: wx,
  claim_svg_element: Ex,
  detach: Sx,
  init: Cx,
  insert_hydration: Dx,
  noop: Ax,
  safe_not_equal: Tx,
  svg_element: xx
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mx,
  append_hydration: $x,
  attr: Fx,
  children: Ox,
  claim_svg_element: Nx,
  detach: Rx,
  init: Ix,
  insert_hydration: Lx,
  noop: Px,
  safe_not_equal: Bx,
  svg_element: zx
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hx,
  append_hydration: qx,
  attr: jx,
  children: Vx,
  claim_svg_element: Ux,
  detach: Wx,
  init: Kx,
  insert_hydration: Gx,
  noop: Jx,
  safe_not_equal: Yx,
  svg_element: Xx
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zx,
  append_hydration: Qx,
  attr: eM,
  children: tM,
  claim_svg_element: nM,
  detach: rM,
  init: iM,
  insert_hydration: sM,
  noop: oM,
  safe_not_equal: lM,
  svg_element: aM
} = window.__gradio__svelte__internal, {
  SvelteComponent: uM,
  append_hydration: cM,
  attr: dM,
  children: fM,
  claim_svg_element: hM,
  detach: pM,
  init: mM,
  insert_hydration: gM,
  noop: _M,
  safe_not_equal: yM,
  svg_element: bM
} = window.__gradio__svelte__internal, {
  SvelteComponent: kM,
  append_hydration: vM,
  attr: wM,
  children: EM,
  claim_svg_element: SM,
  detach: CM,
  init: DM,
  insert_hydration: AM,
  noop: TM,
  safe_not_equal: xM,
  svg_element: MM
} = window.__gradio__svelte__internal, {
  SvelteComponent: $M,
  append_hydration: FM,
  attr: OM,
  children: NM,
  claim_svg_element: RM,
  detach: IM,
  init: LM,
  insert_hydration: PM,
  noop: BM,
  safe_not_equal: zM,
  svg_element: HM
} = window.__gradio__svelte__internal, {
  SvelteComponent: qM,
  append_hydration: jM,
  attr: VM,
  children: UM,
  claim_svg_element: WM,
  detach: KM,
  init: GM,
  insert_hydration: JM,
  noop: YM,
  safe_not_equal: XM,
  svg_element: ZM
} = window.__gradio__svelte__internal, {
  SvelteComponent: QM,
  append_hydration: e$,
  attr: t$,
  children: n$,
  claim_svg_element: r$,
  detach: i$,
  init: s$,
  insert_hydration: o$,
  noop: l$,
  safe_not_equal: a$,
  svg_element: u$
} = window.__gradio__svelte__internal, {
  SvelteComponent: c$,
  append_hydration: d$,
  attr: f$,
  children: h$,
  claim_svg_element: p$,
  detach: m$,
  init: g$,
  insert_hydration: _$,
  noop: y$,
  safe_not_equal: b$,
  svg_element: k$
} = window.__gradio__svelte__internal, {
  SvelteComponent: v$,
  append_hydration: w$,
  attr: E$,
  children: S$,
  claim_svg_element: C$,
  detach: D$,
  init: A$,
  insert_hydration: T$,
  noop: x$,
  safe_not_equal: M$,
  svg_element: $$
} = window.__gradio__svelte__internal, {
  SvelteComponent: F$,
  append_hydration: O$,
  attr: N$,
  children: R$,
  claim_svg_element: I$,
  detach: L$,
  init: P$,
  insert_hydration: B$,
  noop: z$,
  safe_not_equal: H$,
  svg_element: q$
} = window.__gradio__svelte__internal, {
  SvelteComponent: j$,
  append_hydration: V$,
  attr: U$,
  children: W$,
  claim_svg_element: K$,
  detach: G$,
  init: J$,
  insert_hydration: Y$,
  noop: X$,
  safe_not_equal: Z$,
  svg_element: Q$
} = window.__gradio__svelte__internal, {
  SvelteComponent: e2,
  append_hydration: t2,
  attr: n2,
  children: r2,
  claim_svg_element: i2,
  detach: s2,
  init: o2,
  insert_hydration: l2,
  noop: a2,
  safe_not_equal: u2,
  svg_element: c2
} = window.__gradio__svelte__internal, {
  SvelteComponent: d2,
  append_hydration: f2,
  attr: h2,
  children: p2,
  claim_svg_element: m2,
  detach: g2,
  init: _2,
  insert_hydration: y2,
  noop: b2,
  safe_not_equal: k2,
  svg_element: v2
} = window.__gradio__svelte__internal, {
  SvelteComponent: w2,
  append_hydration: E2,
  attr: S2,
  children: C2,
  claim_svg_element: D2,
  detach: A2,
  init: T2,
  insert_hydration: x2,
  noop: M2,
  safe_not_equal: $2,
  svg_element: F2
} = window.__gradio__svelte__internal, {
  SvelteComponent: O2,
  append_hydration: N2,
  attr: R2,
  children: I2,
  claim_svg_element: L2,
  detach: P2,
  init: B2,
  insert_hydration: z2,
  noop: H2,
  safe_not_equal: q2,
  svg_element: j2
} = window.__gradio__svelte__internal, {
  SvelteComponent: V2,
  append_hydration: U2,
  attr: W2,
  children: K2,
  claim_svg_element: G2,
  detach: J2,
  init: Y2,
  insert_hydration: X2,
  noop: Z2,
  safe_not_equal: Q2,
  svg_element: eF
} = window.__gradio__svelte__internal, {
  SvelteComponent: tF,
  append_hydration: nF,
  attr: rF,
  children: iF,
  claim_svg_element: sF,
  detach: oF,
  init: lF,
  insert_hydration: aF,
  noop: uF,
  safe_not_equal: cF,
  svg_element: dF
} = window.__gradio__svelte__internal, {
  SvelteComponent: fF,
  append_hydration: hF,
  attr: pF,
  children: mF,
  claim_svg_element: gF,
  detach: _F,
  init: yF,
  insert_hydration: bF,
  noop: kF,
  safe_not_equal: vF,
  svg_element: wF
} = window.__gradio__svelte__internal, {
  SvelteComponent: EF,
  append_hydration: SF,
  attr: CF,
  children: DF,
  claim_svg_element: AF,
  detach: TF,
  init: xF,
  insert_hydration: MF,
  noop: $F,
  safe_not_equal: FF,
  svg_element: OF
} = window.__gradio__svelte__internal, {
  SvelteComponent: NF,
  append_hydration: RF,
  attr: IF,
  children: LF,
  claim_svg_element: PF,
  detach: BF,
  init: zF,
  insert_hydration: HF,
  noop: qF,
  safe_not_equal: jF,
  svg_element: VF
} = window.__gradio__svelte__internal, {
  SvelteComponent: UF,
  append_hydration: WF,
  attr: KF,
  children: GF,
  claim_svg_element: JF,
  detach: YF,
  init: XF,
  insert_hydration: ZF,
  noop: QF,
  safe_not_equal: eO,
  svg_element: tO
} = window.__gradio__svelte__internal, {
  SvelteComponent: nO,
  append_hydration: rO,
  attr: iO,
  children: sO,
  claim_svg_element: oO,
  detach: lO,
  init: aO,
  insert_hydration: uO,
  noop: cO,
  safe_not_equal: dO,
  svg_element: fO
} = window.__gradio__svelte__internal, {
  SvelteComponent: hO,
  append_hydration: pO,
  attr: mO,
  children: gO,
  claim_svg_element: _O,
  detach: yO,
  init: bO,
  insert_hydration: kO,
  noop: vO,
  safe_not_equal: wO,
  svg_element: EO
} = window.__gradio__svelte__internal, {
  SvelteComponent: SO,
  append_hydration: CO,
  attr: DO,
  children: AO,
  claim_svg_element: TO,
  detach: xO,
  init: MO,
  insert_hydration: $O,
  noop: FO,
  safe_not_equal: OO,
  svg_element: NO
} = window.__gradio__svelte__internal, {
  SvelteComponent: RO,
  append_hydration: IO,
  attr: LO,
  children: PO,
  claim_svg_element: BO,
  detach: zO,
  init: HO,
  insert_hydration: qO,
  noop: jO,
  safe_not_equal: VO,
  svg_element: UO
} = window.__gradio__svelte__internal, {
  SvelteComponent: WO,
  append_hydration: KO,
  attr: GO,
  children: JO,
  claim_svg_element: YO,
  detach: XO,
  init: ZO,
  insert_hydration: QO,
  noop: eN,
  safe_not_equal: tN,
  svg_element: nN
} = window.__gradio__svelte__internal, {
  SvelteComponent: rN,
  append_hydration: iN,
  attr: sN,
  children: oN,
  claim_svg_element: lN,
  detach: aN,
  init: uN,
  insert_hydration: cN,
  noop: dN,
  safe_not_equal: fN,
  svg_element: hN
} = window.__gradio__svelte__internal, {
  SvelteComponent: pN,
  append_hydration: mN,
  attr: gN,
  children: _N,
  claim_svg_element: yN,
  detach: bN,
  init: kN,
  insert_hydration: vN,
  noop: wN,
  safe_not_equal: EN,
  svg_element: SN
} = window.__gradio__svelte__internal, {
  SvelteComponent: CN,
  append_hydration: DN,
  attr: AN,
  children: TN,
  claim_svg_element: xN,
  detach: MN,
  init: $N,
  insert_hydration: FN,
  noop: ON,
  safe_not_equal: NN,
  set_style: RN,
  svg_element: IN
} = window.__gradio__svelte__internal, {
  SvelteComponent: LN,
  append_hydration: PN,
  attr: BN,
  children: zN,
  claim_svg_element: HN,
  detach: qN,
  init: jN,
  insert_hydration: VN,
  noop: UN,
  safe_not_equal: WN,
  svg_element: KN
} = window.__gradio__svelte__internal, {
  SvelteComponent: GN,
  append_hydration: JN,
  attr: YN,
  children: XN,
  claim_svg_element: ZN,
  detach: QN,
  init: eR,
  insert_hydration: tR,
  noop: nR,
  safe_not_equal: rR,
  svg_element: iR
} = window.__gradio__svelte__internal, {
  SvelteComponent: sR,
  append_hydration: oR,
  attr: lR,
  children: aR,
  claim_svg_element: uR,
  detach: cR,
  init: dR,
  insert_hydration: fR,
  noop: hR,
  safe_not_equal: pR,
  svg_element: mR
} = window.__gradio__svelte__internal, {
  SvelteComponent: gR,
  append_hydration: _R,
  attr: yR,
  children: bR,
  claim_svg_element: kR,
  detach: vR,
  init: wR,
  insert_hydration: ER,
  noop: SR,
  safe_not_equal: CR,
  svg_element: DR
} = window.__gradio__svelte__internal, {
  SvelteComponent: AR,
  append_hydration: TR,
  attr: xR,
  children: MR,
  claim_svg_element: $R,
  detach: FR,
  init: OR,
  insert_hydration: NR,
  noop: RR,
  safe_not_equal: IR,
  svg_element: LR
} = window.__gradio__svelte__internal, {
  SvelteComponent: PR,
  append_hydration: BR,
  attr: zR,
  children: HR,
  claim_svg_element: qR,
  detach: jR,
  init: VR,
  insert_hydration: UR,
  noop: WR,
  safe_not_equal: KR,
  svg_element: GR
} = window.__gradio__svelte__internal, {
  SvelteComponent: JR,
  append_hydration: YR,
  attr: XR,
  children: ZR,
  claim_svg_element: QR,
  detach: eI,
  init: tI,
  insert_hydration: nI,
  noop: rI,
  safe_not_equal: iI,
  svg_element: sI
} = window.__gradio__svelte__internal, {
  SvelteComponent: oI,
  append_hydration: lI,
  attr: aI,
  children: uI,
  claim_svg_element: cI,
  detach: dI,
  init: fI,
  insert_hydration: hI,
  noop: pI,
  safe_not_equal: mI,
  svg_element: gI
} = window.__gradio__svelte__internal, {
  SvelteComponent: _I,
  append_hydration: yI,
  attr: bI,
  children: kI,
  claim_svg_element: vI,
  claim_text: wI,
  detach: EI,
  init: SI,
  insert_hydration: CI,
  noop: DI,
  safe_not_equal: AI,
  svg_element: TI,
  text: xI
} = window.__gradio__svelte__internal, {
  SvelteComponent: MI,
  append_hydration: $I,
  attr: FI,
  children: OI,
  claim_svg_element: NI,
  detach: RI,
  init: II,
  insert_hydration: LI,
  noop: PI,
  safe_not_equal: BI,
  svg_element: zI
} = window.__gradio__svelte__internal, {
  SvelteComponent: HI,
  append_hydration: qI,
  attr: jI,
  children: VI,
  claim_svg_element: UI,
  detach: WI,
  init: KI,
  insert_hydration: GI,
  noop: JI,
  safe_not_equal: YI,
  svg_element: XI
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZI,
  append_hydration: QI,
  attr: e3,
  children: t3,
  claim_svg_element: n3,
  detach: r3,
  init: i3,
  insert_hydration: s3,
  noop: o3,
  safe_not_equal: l3,
  svg_element: a3
} = window.__gradio__svelte__internal, {
  SvelteComponent: u3,
  append_hydration: c3,
  attr: d3,
  children: f3,
  claim_svg_element: h3,
  detach: p3,
  init: m3,
  insert_hydration: g3,
  noop: _3,
  safe_not_equal: y3,
  svg_element: b3
} = window.__gradio__svelte__internal, {
  SvelteComponent: k3,
  append_hydration: v3,
  attr: w3,
  children: E3,
  claim_svg_element: S3,
  detach: C3,
  init: D3,
  insert_hydration: A3,
  noop: T3,
  safe_not_equal: x3,
  svg_element: M3
} = window.__gradio__svelte__internal, {
  SvelteComponent: $3,
  append_hydration: F3,
  attr: O3,
  children: N3,
  claim_svg_element: R3,
  detach: I3,
  init: L3,
  insert_hydration: P3,
  noop: B3,
  safe_not_equal: z3,
  svg_element: H3
} = window.__gradio__svelte__internal, {
  SvelteComponent: q3,
  append_hydration: j3,
  attr: V3,
  children: U3,
  claim_svg_element: W3,
  detach: K3,
  init: G3,
  insert_hydration: J3,
  noop: Y3,
  safe_not_equal: X3,
  svg_element: Z3
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q3,
  append_hydration: eL,
  attr: tL,
  children: nL,
  claim_svg_element: rL,
  claim_text: iL,
  detach: sL,
  init: oL,
  insert_hydration: lL,
  noop: aL,
  safe_not_equal: uL,
  svg_element: cL,
  text: dL
} = window.__gradio__svelte__internal, {
  SvelteComponent: fL,
  append_hydration: hL,
  attr: pL,
  children: mL,
  claim_svg_element: gL,
  claim_text: _L,
  detach: yL,
  init: bL,
  insert_hydration: kL,
  noop: vL,
  safe_not_equal: wL,
  svg_element: EL,
  text: SL
} = window.__gradio__svelte__internal, {
  SvelteComponent: CL,
  append_hydration: DL,
  attr: AL,
  children: TL,
  claim_svg_element: xL,
  claim_text: ML,
  detach: $L,
  init: FL,
  insert_hydration: OL,
  noop: NL,
  safe_not_equal: RL,
  svg_element: IL,
  text: LL
} = window.__gradio__svelte__internal, {
  SvelteComponent: PL,
  append_hydration: BL,
  attr: zL,
  children: HL,
  claim_svg_element: qL,
  detach: jL,
  init: VL,
  insert_hydration: UL,
  noop: WL,
  safe_not_equal: KL,
  svg_element: GL
} = window.__gradio__svelte__internal, {
  SvelteComponent: JL,
  append_hydration: YL,
  attr: XL,
  children: ZL,
  claim_svg_element: QL,
  detach: eP,
  init: tP,
  insert_hydration: nP,
  noop: rP,
  safe_not_equal: iP,
  svg_element: sP
} = window.__gradio__svelte__internal, {
  SvelteComponent: oP,
  append_hydration: lP,
  attr: aP,
  children: uP,
  claim_svg_element: cP,
  detach: dP,
  init: fP,
  insert_hydration: hP,
  noop: pP,
  safe_not_equal: mP,
  svg_element: gP
} = window.__gradio__svelte__internal, {
  SvelteComponent: _P,
  append_hydration: yP,
  attr: bP,
  children: kP,
  claim_svg_element: vP,
  detach: wP,
  init: EP,
  insert_hydration: SP,
  noop: CP,
  safe_not_equal: DP,
  svg_element: AP
} = window.__gradio__svelte__internal, {
  SvelteComponent: TP,
  append_hydration: xP,
  attr: MP,
  children: $P,
  claim_svg_element: FP,
  detach: OP,
  init: NP,
  insert_hydration: RP,
  noop: IP,
  safe_not_equal: LP,
  svg_element: PP
} = window.__gradio__svelte__internal, {
  SvelteComponent: BP,
  append_hydration: zP,
  attr: HP,
  children: qP,
  claim_svg_element: jP,
  detach: VP,
  init: UP,
  insert_hydration: WP,
  noop: KP,
  safe_not_equal: GP,
  svg_element: JP
} = window.__gradio__svelte__internal, {
  SvelteComponent: YP,
  append_hydration: XP,
  attr: ZP,
  children: QP,
  claim_svg_element: e4,
  detach: t4,
  init: n4,
  insert_hydration: r4,
  noop: i4,
  safe_not_equal: s4,
  svg_element: o4
} = window.__gradio__svelte__internal, {
  SvelteComponent: l4,
  append_hydration: a4,
  attr: u4,
  children: c4,
  claim_svg_element: d4,
  detach: f4,
  init: h4,
  insert_hydration: p4,
  noop: m4,
  safe_not_equal: g4,
  svg_element: _4
} = window.__gradio__svelte__internal, cy = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], fc = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
cy.reduce(
  (n, { color: e, primary: t, secondary: r }) => ({
    ...n,
    [e]: {
      primary: fc[e][t],
      secondary: fc[e][r]
    }
  }),
  {}
);
const {
  SvelteComponent: y4,
  claim_component: b4,
  create_component: k4,
  destroy_component: v4,
  init: w4,
  mount_component: E4,
  safe_not_equal: S4,
  transition_in: C4,
  transition_out: D4
} = window.__gradio__svelte__internal, { createEventDispatcher: A4 } = window.__gradio__svelte__internal, {
  SvelteComponent: T4,
  append_hydration: x4,
  attr: M4,
  check_outros: $4,
  children: F4,
  claim_component: O4,
  claim_element: N4,
  claim_space: R4,
  claim_text: I4,
  create_component: L4,
  destroy_component: P4,
  detach: B4,
  element: z4,
  empty: H4,
  group_outros: q4,
  init: j4,
  insert_hydration: V4,
  mount_component: U4,
  safe_not_equal: W4,
  set_data: K4,
  space: G4,
  text: J4,
  toggle_class: Y4,
  transition_in: X4,
  transition_out: Z4
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q4,
  attr: eB,
  children: tB,
  claim_element: nB,
  create_slot: rB,
  detach: iB,
  element: sB,
  get_all_dirty_from_scope: oB,
  get_slot_changes: lB,
  init: aB,
  insert_hydration: uB,
  safe_not_equal: cB,
  toggle_class: dB,
  transition_in: fB,
  transition_out: hB,
  update_slot_base: pB
} = window.__gradio__svelte__internal, {
  SvelteComponent: mB,
  append_hydration: gB,
  attr: _B,
  check_outros: yB,
  children: bB,
  claim_component: kB,
  claim_element: vB,
  claim_space: wB,
  create_component: EB,
  destroy_component: SB,
  detach: CB,
  element: DB,
  empty: AB,
  group_outros: TB,
  init: xB,
  insert_hydration: MB,
  listen: $B,
  mount_component: FB,
  safe_not_equal: OB,
  space: NB,
  toggle_class: RB,
  transition_in: IB,
  transition_out: LB
} = window.__gradio__svelte__internal, {
  SvelteComponent: PB,
  attr: BB,
  children: zB,
  claim_element: HB,
  create_slot: qB,
  detach: jB,
  element: VB,
  get_all_dirty_from_scope: UB,
  get_slot_changes: WB,
  init: KB,
  insert_hydration: GB,
  null_to_empty: JB,
  safe_not_equal: YB,
  transition_in: XB,
  transition_out: ZB,
  update_slot_base: QB
} = window.__gradio__svelte__internal, {
  SvelteComponent: e5,
  check_outros: t5,
  claim_component: n5,
  create_component: r5,
  destroy_component: i5,
  detach: s5,
  empty: o5,
  group_outros: l5,
  init: a5,
  insert_hydration: u5,
  mount_component: c5,
  noop: d5,
  safe_not_equal: f5,
  transition_in: h5,
  transition_out: p5
} = window.__gradio__svelte__internal, { createEventDispatcher: m5 } = window.__gradio__svelte__internal;
function Rr(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let r = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + r;
}
function xs() {
}
const th = typeof window < "u";
let hc = th ? () => window.performance.now() : () => Date.now(), nh = th ? (n) => requestAnimationFrame(n) : xs;
const Pr = /* @__PURE__ */ new Set();
function rh(n) {
  Pr.forEach((e) => {
    e.c(n) || (Pr.delete(e), e.f());
  }), Pr.size !== 0 && nh(rh);
}
function dy(n) {
  let e;
  return Pr.size === 0 && nh(rh), { promise: new Promise((t) => {
    Pr.add(e = { c: n, f: t });
  }), abort() {
    Pr.delete(e);
  } };
}
const Ar = [];
function fy(n, e = xs) {
  let t;
  const r = /* @__PURE__ */ new Set();
  function i(o) {
    if (a = o, ((l = n) != l ? a == a : l !== a || l && typeof l == "object" || typeof l == "function") && (n = o, t)) {
      const u = !Ar.length;
      for (const c of r) c[1](), Ar.push(c, n);
      if (u) {
        for (let c = 0; c < Ar.length; c += 2) Ar[c][0](Ar[c + 1]);
        Ar.length = 0;
      }
    }
    var l, a;
  }
  function s(o) {
    i(o(n));
  }
  return { set: i, update: s, subscribe: function(o, l = xs) {
    const a = [o, l];
    return r.add(a), r.size === 1 && (t = e(i, s) || xs), o(n), () => {
      r.delete(a), r.size === 0 && t && (t(), t = null);
    };
  } };
}
function pc(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function jl(n, e, t, r) {
  if (typeof t == "number" || pc(t)) {
    const i = r - t, s = (t - e) / (n.dt || 1 / 60), o = (s + (n.opts.stiffness * i - n.opts.damping * s) * n.inv_mass) * n.dt;
    return Math.abs(o) < n.opts.precision && Math.abs(i) < n.opts.precision ? r : (n.settled = !1, pc(t) ? new Date(t.getTime() + o) : t + o);
  }
  if (Array.isArray(t)) return t.map((i, s) => jl(n, e[s], t[s], r[s]));
  if (typeof t == "object") {
    const i = {};
    for (const s in t) i[s] = jl(n, e[s], t[s], r[s]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function mc(n, e = {}) {
  const t = fy(n), { stiffness: r = 0.15, damping: i = 0.8, precision: s = 0.01 } = e;
  let o, l, a, u = n, c = n, d = 1, f = 0, h = !1;
  function p(_, k = {}) {
    c = _;
    const b = a = {};
    return n == null || k.hard || g.stiffness >= 1 && g.damping >= 1 ? (h = !0, o = hc(), u = _, t.set(n = c), Promise.resolve()) : (k.soft && (f = 1 / (60 * (k.soft === !0 ? 0.5 : +k.soft)), d = 0), l || (o = hc(), h = !1, l = dy((y) => {
      if (h) return h = !1, l = null, !1;
      d = Math.min(d + f, 1);
      const v = { inv_mass: d, opts: g, settled: !0, dt: 60 * (y - o) / 1e3 }, S = jl(v, u, n, c);
      return o = y, u = n, t.set(n = S), v.settled && (l = null), !v.settled;
    })), new Promise((y) => {
      l.promise.then(() => {
        b === a && y();
      });
    }));
  }
  const g = { set: p, update: (_, k) => p(_(c, n), k), subscribe: t.subscribe, stiffness: r, damping: i, precision: s };
  return g;
}
const {
  SvelteComponent: hy,
  append_hydration: It,
  attr: ce,
  children: bt,
  claim_element: py,
  claim_svg_element: Lt,
  component_subscribe: gc,
  detach: pt,
  element: my,
  init: gy,
  insert_hydration: _y,
  noop: _c,
  safe_not_equal: yy,
  set_style: cs,
  svg_element: Pt,
  toggle_class: yc
} = window.__gradio__svelte__internal, { onMount: by } = window.__gradio__svelte__internal;
function ky(n) {
  let e, t, r, i, s, o, l, a, u, c, d, f;
  return {
    c() {
      e = my("div"), t = Pt("svg"), r = Pt("g"), i = Pt("path"), s = Pt("path"), o = Pt("path"), l = Pt("path"), a = Pt("g"), u = Pt("path"), c = Pt("path"), d = Pt("path"), f = Pt("path"), this.h();
    },
    l(h) {
      e = py(h, "DIV", { class: !0 });
      var p = bt(e);
      t = Lt(p, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var g = bt(t);
      r = Lt(g, "g", { style: !0 });
      var _ = bt(r);
      i = Lt(_, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), bt(i).forEach(pt), s = Lt(_, "path", { d: !0, fill: !0, class: !0 }), bt(s).forEach(pt), o = Lt(_, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), bt(o).forEach(pt), l = Lt(_, "path", { d: !0, fill: !0, class: !0 }), bt(l).forEach(pt), _.forEach(pt), a = Lt(g, "g", { style: !0 });
      var k = bt(a);
      u = Lt(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), bt(u).forEach(pt), c = Lt(k, "path", { d: !0, fill: !0, class: !0 }), bt(c).forEach(pt), d = Lt(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), bt(d).forEach(pt), f = Lt(k, "path", { d: !0, fill: !0, class: !0 }), bt(f).forEach(pt), k.forEach(pt), g.forEach(pt), p.forEach(pt), this.h();
    },
    h() {
      ce(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), ce(i, "fill", "#FF7C00"), ce(i, "fill-opacity", "0.4"), ce(i, "class", "svelte-43sxxs"), ce(s, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), ce(s, "fill", "#FF7C00"), ce(s, "class", "svelte-43sxxs"), ce(o, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), ce(o, "fill", "#FF7C00"), ce(o, "fill-opacity", "0.4"), ce(o, "class", "svelte-43sxxs"), ce(l, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), ce(l, "fill", "#FF7C00"), ce(l, "class", "svelte-43sxxs"), cs(r, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), ce(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), ce(u, "fill", "#FF7C00"), ce(u, "fill-opacity", "0.4"), ce(u, "class", "svelte-43sxxs"), ce(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), ce(c, "fill", "#FF7C00"), ce(c, "class", "svelte-43sxxs"), ce(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), ce(d, "fill", "#FF7C00"), ce(d, "fill-opacity", "0.4"), ce(d, "class", "svelte-43sxxs"), ce(f, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), ce(f, "fill", "#FF7C00"), ce(f, "class", "svelte-43sxxs"), cs(a, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), ce(t, "viewBox", "-1200 -1200 3000 3000"), ce(t, "fill", "none"), ce(t, "xmlns", "http://www.w3.org/2000/svg"), ce(t, "class", "svelte-43sxxs"), ce(e, "class", "svelte-43sxxs"), yc(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(h, p) {
      _y(h, e, p), It(e, t), It(t, r), It(r, i), It(r, s), It(r, o), It(r, l), It(t, a), It(a, u), It(a, c), It(a, d), It(a, f);
    },
    p(h, [p]) {
      p & /*$top*/
      2 && cs(r, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), p & /*$bottom*/
      4 && cs(a, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), p & /*margin*/
      1 && yc(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: _c,
    o: _c,
    d(h) {
      h && pt(e);
    }
  };
}
function vy(n, e, t) {
  let r, i;
  var s = this && this.__awaiter || function(h, p, g, _) {
    function k(b) {
      return b instanceof g ? b : new g(function(y) {
        y(b);
      });
    }
    return new (g || (g = Promise))(function(b, y) {
      function v(T) {
        try {
          D(_.next(T));
        } catch (x) {
          y(x);
        }
      }
      function S(T) {
        try {
          D(_.throw(T));
        } catch (x) {
          y(x);
        }
      }
      function D(T) {
        T.done ? b(T.value) : k(T.value).then(v, S);
      }
      D((_ = _.apply(h, p || [])).next());
    });
  };
  let { margin: o = !0 } = e;
  const l = mc([0, 0]);
  gc(n, l, (h) => t(1, r = h));
  const a = mc([0, 0]);
  gc(n, a, (h) => t(2, i = h));
  let u;
  function c() {
    return s(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 140]), a.set([-125, -140])]), yield Promise.all([l.set([-125, 140]), a.set([125, -140])]), yield Promise.all([l.set([-125, 0]), a.set([125, -0])]), yield Promise.all([l.set([125, 0]), a.set([-125, 0])]);
    });
  }
  function d() {
    return s(this, void 0, void 0, function* () {
      yield c(), u || d();
    });
  }
  function f() {
    return s(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 0]), a.set([-125, 0])]), d();
    });
  }
  return by(() => (f(), () => u = !0)), n.$$set = (h) => {
    "margin" in h && t(0, o = h.margin);
  }, [o, r, i, l, a];
}
class wy extends hy {
  constructor(e) {
    super(), gy(this, e, vy, ky, yy, { margin: 0 });
  }
}
const {
  SvelteComponent: Ey,
  append_hydration: tr,
  attr: qt,
  binding_callbacks: bc,
  check_outros: Vl,
  children: rn,
  claim_component: ih,
  claim_element: sn,
  claim_space: Dt,
  claim_text: De,
  create_component: sh,
  create_slot: oh,
  destroy_component: lh,
  destroy_each: ah,
  detach: K,
  element: on,
  empty: xt,
  ensure_array_like: Bs,
  get_all_dirty_from_scope: uh,
  get_slot_changes: ch,
  group_outros: Ul,
  init: Sy,
  insert_hydration: Q,
  mount_component: dh,
  noop: Wl,
  safe_not_equal: Cy,
  set_data: Mt,
  set_style: Pn,
  space: At,
  text: Ae,
  toggle_class: Et,
  transition_in: zt,
  transition_out: ln,
  update_slot_base: fh
} = window.__gradio__svelte__internal, { tick: Dy } = window.__gradio__svelte__internal, { onDestroy: Ay } = window.__gradio__svelte__internal, { createEventDispatcher: Ty } = window.__gradio__svelte__internal, xy = (n) => ({}), kc = (n) => ({}), My = (n) => ({}), vc = (n) => ({});
function wc(n, e, t) {
  const r = n.slice();
  return r[40] = e[t], r[42] = t, r;
}
function Ec(n, e, t) {
  const r = n.slice();
  return r[40] = e[t], r;
}
function $y(n) {
  let e, t, r, i, s = (
    /*i18n*/
    n[1]("common.error") + ""
  ), o, l, a;
  t = new ry({
    props: {
      Icon: uy,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const u = (
    /*#slots*/
    n[30].error
  ), c = oh(
    u,
    n,
    /*$$scope*/
    n[29],
    kc
  );
  return {
    c() {
      e = on("div"), sh(t.$$.fragment), r = At(), i = on("span"), o = Ae(s), l = At(), c && c.c(), this.h();
    },
    l(d) {
      e = sn(d, "DIV", { class: !0 });
      var f = rn(e);
      ih(t.$$.fragment, f), f.forEach(K), r = Dt(d), i = sn(d, "SPAN", { class: !0 });
      var h = rn(i);
      o = De(h, s), h.forEach(K), l = Dt(d), c && c.l(d), this.h();
    },
    h() {
      qt(e, "class", "clear-status svelte-17v219f"), qt(i, "class", "error svelte-17v219f");
    },
    m(d, f) {
      Q(d, e, f), dh(t, e, null), Q(d, r, f), Q(d, i, f), tr(i, o), Q(d, l, f), c && c.m(d, f), a = !0;
    },
    p(d, f) {
      const h = {};
      f[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      d[1]("common.clear")), t.$set(h), (!a || f[0] & /*i18n*/
      2) && s !== (s = /*i18n*/
      d[1]("common.error") + "") && Mt(o, s), c && c.p && (!a || f[0] & /*$$scope*/
      536870912) && fh(
        c,
        u,
        d,
        /*$$scope*/
        d[29],
        a ? ch(
          u,
          /*$$scope*/
          d[29],
          f,
          xy
        ) : uh(
          /*$$scope*/
          d[29]
        ),
        kc
      );
    },
    i(d) {
      a || (zt(t.$$.fragment, d), zt(c, d), a = !0);
    },
    o(d) {
      ln(t.$$.fragment, d), ln(c, d), a = !1;
    },
    d(d) {
      d && (K(e), K(r), K(i), K(l)), lh(t), c && c.d(d);
    }
  };
}
function Fy(n) {
  let e, t, r, i, s, o, l, a, u, c = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && Sc(n)
  );
  function d(y, v) {
    if (
      /*progress*/
      y[7]
    ) return Ry;
    if (
      /*queue_position*/
      y[2] !== null && /*queue_size*/
      y[3] !== void 0 && /*queue_position*/
      y[2] >= 0
    ) return Ny;
    if (
      /*queue_position*/
      y[2] === 0
    ) return Oy;
  }
  let f = d(n), h = f && f(n), p = (
    /*timer*/
    n[5] && Ac(n)
  );
  const g = [By, Py], _ = [];
  function k(y, v) {
    return (
      /*last_progress_level*/
      y[15] != null ? 0 : (
        /*show_progress*/
        y[6] === "full" ? 1 : -1
      )
    );
  }
  ~(s = k(n)) && (o = _[s] = g[s](n));
  let b = !/*timer*/
  n[5] && Nc(n);
  return {
    c() {
      c && c.c(), e = At(), t = on("div"), h && h.c(), r = At(), p && p.c(), i = At(), o && o.c(), l = At(), b && b.c(), a = xt(), this.h();
    },
    l(y) {
      c && c.l(y), e = Dt(y), t = sn(y, "DIV", { class: !0 });
      var v = rn(t);
      h && h.l(v), r = Dt(v), p && p.l(v), v.forEach(K), i = Dt(y), o && o.l(y), l = Dt(y), b && b.l(y), a = xt(), this.h();
    },
    h() {
      qt(t, "class", "progress-text svelte-17v219f"), Et(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), Et(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(y, v) {
      c && c.m(y, v), Q(y, e, v), Q(y, t, v), h && h.m(t, null), tr(t, r), p && p.m(t, null), Q(y, i, v), ~s && _[s].m(y, v), Q(y, l, v), b && b.m(y, v), Q(y, a, v), u = !0;
    },
    p(y, v) {
      /*variant*/
      y[8] === "default" && /*show_eta_bar*/
      y[18] && /*show_progress*/
      y[6] === "full" ? c ? c.p(y, v) : (c = Sc(y), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), f === (f = d(y)) && h ? h.p(y, v) : (h && h.d(1), h = f && f(y), h && (h.c(), h.m(t, r))), /*timer*/
      y[5] ? p ? p.p(y, v) : (p = Ac(y), p.c(), p.m(t, null)) : p && (p.d(1), p = null), (!u || v[0] & /*variant*/
      256) && Et(
        t,
        "meta-text-center",
        /*variant*/
        y[8] === "center"
      ), (!u || v[0] & /*variant*/
      256) && Et(
        t,
        "meta-text",
        /*variant*/
        y[8] === "default"
      );
      let S = s;
      s = k(y), s === S ? ~s && _[s].p(y, v) : (o && (Ul(), ln(_[S], 1, 1, () => {
        _[S] = null;
      }), Vl()), ~s ? (o = _[s], o ? o.p(y, v) : (o = _[s] = g[s](y), o.c()), zt(o, 1), o.m(l.parentNode, l)) : o = null), /*timer*/
      y[5] ? b && (Ul(), ln(b, 1, 1, () => {
        b = null;
      }), Vl()) : b ? (b.p(y, v), v[0] & /*timer*/
      32 && zt(b, 1)) : (b = Nc(y), b.c(), zt(b, 1), b.m(a.parentNode, a));
    },
    i(y) {
      u || (zt(o), zt(b), u = !0);
    },
    o(y) {
      ln(o), ln(b), u = !1;
    },
    d(y) {
      y && (K(e), K(t), K(i), K(l), K(a)), c && c.d(y), h && h.d(), p && p.d(), ~s && _[s].d(y), b && b.d(y);
    }
  };
}
function Sc(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = on("div"), this.h();
    },
    l(r) {
      e = sn(r, "DIV", { class: !0 }), rn(e).forEach(K), this.h();
    },
    h() {
      qt(e, "class", "eta-bar svelte-17v219f"), Pn(e, "transform", t);
    },
    m(r, i) {
      Q(r, e, i);
    },
    p(r, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && Pn(e, "transform", t);
    },
    d(r) {
      r && K(e);
    }
  };
}
function Oy(n) {
  let e;
  return {
    c() {
      e = Ae("processing |");
    },
    l(t) {
      e = De(t, "processing |");
    },
    m(t, r) {
      Q(t, e, r);
    },
    p: Wl,
    d(t) {
      t && K(e);
    }
  };
}
function Ny(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), r, i, s, o;
  return {
    c() {
      e = Ae("queue: "), r = Ae(t), i = Ae("/"), s = Ae(
        /*queue_size*/
        n[3]
      ), o = Ae(" |");
    },
    l(l) {
      e = De(l, "queue: "), r = De(l, t), i = De(l, "/"), s = De(
        l,
        /*queue_size*/
        n[3]
      ), o = De(l, " |");
    },
    m(l, a) {
      Q(l, e, a), Q(l, r, a), Q(l, i, a), Q(l, s, a), Q(l, o, a);
    },
    p(l, a) {
      a[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      l[2] + 1 + "") && Mt(r, t), a[0] & /*queue_size*/
      8 && Mt(
        s,
        /*queue_size*/
        l[3]
      );
    },
    d(l) {
      l && (K(e), K(r), K(i), K(s), K(o));
    }
  };
}
function Ry(n) {
  let e, t = Bs(
    /*progress*/
    n[7]
  ), r = [];
  for (let i = 0; i < t.length; i += 1)
    r[i] = Dc(Ec(n, t, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      e = xt();
    },
    l(i) {
      for (let s = 0; s < r.length; s += 1)
        r[s].l(i);
      e = xt();
    },
    m(i, s) {
      for (let o = 0; o < r.length; o += 1)
        r[o] && r[o].m(i, s);
      Q(i, e, s);
    },
    p(i, s) {
      if (s[0] & /*progress*/
      128) {
        t = Bs(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const l = Ec(i, t, o);
          r[o] ? r[o].p(l, s) : (r[o] = Dc(l), r[o].c(), r[o].m(e.parentNode, e));
        }
        for (; o < r.length; o += 1)
          r[o].d(1);
        r.length = t.length;
      }
    },
    d(i) {
      i && K(e), ah(r, i);
    }
  };
}
function Cc(n) {
  let e, t = (
    /*p*/
    n[40].unit + ""
  ), r, i, s = " ", o;
  function l(c, d) {
    return (
      /*p*/
      c[40].length != null ? Ly : Iy
    );
  }
  let a = l(n), u = a(n);
  return {
    c() {
      u.c(), e = At(), r = Ae(t), i = Ae(" | "), o = Ae(s);
    },
    l(c) {
      u.l(c), e = Dt(c), r = De(c, t), i = De(c, " | "), o = De(c, s);
    },
    m(c, d) {
      u.m(c, d), Q(c, e, d), Q(c, r, d), Q(c, i, d), Q(c, o, d);
    },
    p(c, d) {
      a === (a = l(c)) && u ? u.p(c, d) : (u.d(1), u = a(c), u && (u.c(), u.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Mt(r, t);
    },
    d(c) {
      c && (K(e), K(r), K(i), K(o)), u.d(c);
    }
  };
}
function Iy(n) {
  let e = Rr(
    /*p*/
    n[40].index || 0
  ) + "", t;
  return {
    c() {
      t = Ae(e);
    },
    l(r) {
      t = De(r, e);
    },
    m(r, i) {
      Q(r, t, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && e !== (e = Rr(
        /*p*/
        r[40].index || 0
      ) + "") && Mt(t, e);
    },
    d(r) {
      r && K(t);
    }
  };
}
function Ly(n) {
  let e = Rr(
    /*p*/
    n[40].index || 0
  ) + "", t, r, i = Rr(
    /*p*/
    n[40].length
  ) + "", s;
  return {
    c() {
      t = Ae(e), r = Ae("/"), s = Ae(i);
    },
    l(o) {
      t = De(o, e), r = De(o, "/"), s = De(o, i);
    },
    m(o, l) {
      Q(o, t, l), Q(o, r, l), Q(o, s, l);
    },
    p(o, l) {
      l[0] & /*progress*/
      128 && e !== (e = Rr(
        /*p*/
        o[40].index || 0
      ) + "") && Mt(t, e), l[0] & /*progress*/
      128 && i !== (i = Rr(
        /*p*/
        o[40].length
      ) + "") && Mt(s, i);
    },
    d(o) {
      o && (K(t), K(r), K(s));
    }
  };
}
function Dc(n) {
  let e, t = (
    /*p*/
    n[40].index != null && Cc(n)
  );
  return {
    c() {
      t && t.c(), e = xt();
    },
    l(r) {
      t && t.l(r), e = xt();
    },
    m(r, i) {
      t && t.m(r, i), Q(r, e, i);
    },
    p(r, i) {
      /*p*/
      r[40].index != null ? t ? t.p(r, i) : (t = Cc(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && K(e), t && t.d(r);
    }
  };
}
function Ac(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), r, i;
  return {
    c() {
      e = Ae(
        /*formatted_timer*/
        n[20]
      ), r = Ae(t), i = Ae("s");
    },
    l(s) {
      e = De(
        s,
        /*formatted_timer*/
        n[20]
      ), r = De(s, t), i = De(s, "s");
    },
    m(s, o) {
      Q(s, e, o), Q(s, r, o), Q(s, i, o);
    },
    p(s, o) {
      o[0] & /*formatted_timer*/
      1048576 && Mt(
        e,
        /*formatted_timer*/
        s[20]
      ), o[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      s[0] ? `/${/*formatted_eta*/
      s[19]}` : "") && Mt(r, t);
    },
    d(s) {
      s && (K(e), K(r), K(i));
    }
  };
}
function Py(n) {
  let e, t;
  return e = new wy({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      sh(e.$$.fragment);
    },
    l(r) {
      ih(e.$$.fragment, r);
    },
    m(r, i) {
      dh(e, r, i), t = !0;
    },
    p(r, i) {
      const s = {};
      i[0] & /*variant*/
      256 && (s.margin = /*variant*/
      r[8] === "default"), e.$set(s);
    },
    i(r) {
      t || (zt(e.$$.fragment, r), t = !0);
    },
    o(r) {
      ln(e.$$.fragment, r), t = !1;
    },
    d(r) {
      lh(e, r);
    }
  };
}
function By(n) {
  let e, t, r, i, s, o = `${/*last_progress_level*/
  n[15] * 100}%`, l = (
    /*progress*/
    n[7] != null && Tc(n)
  );
  return {
    c() {
      e = on("div"), t = on("div"), l && l.c(), r = At(), i = on("div"), s = on("div"), this.h();
    },
    l(a) {
      e = sn(a, "DIV", { class: !0 });
      var u = rn(e);
      t = sn(u, "DIV", { class: !0 });
      var c = rn(t);
      l && l.l(c), c.forEach(K), r = Dt(u), i = sn(u, "DIV", { class: !0 });
      var d = rn(i);
      s = sn(d, "DIV", { class: !0 }), rn(s).forEach(K), d.forEach(K), u.forEach(K), this.h();
    },
    h() {
      qt(t, "class", "progress-level-inner svelte-17v219f"), qt(s, "class", "progress-bar svelte-17v219f"), Pn(s, "width", o), qt(i, "class", "progress-bar-wrap svelte-17v219f"), qt(e, "class", "progress-level svelte-17v219f");
    },
    m(a, u) {
      Q(a, e, u), tr(e, t), l && l.m(t, null), tr(e, r), tr(e, i), tr(i, s), n[31](s);
    },
    p(a, u) {
      /*progress*/
      a[7] != null ? l ? l.p(a, u) : (l = Tc(a), l.c(), l.m(t, null)) : l && (l.d(1), l = null), u[0] & /*last_progress_level*/
      32768 && o !== (o = `${/*last_progress_level*/
      a[15] * 100}%`) && Pn(s, "width", o);
    },
    i: Wl,
    o: Wl,
    d(a) {
      a && K(e), l && l.d(), n[31](null);
    }
  };
}
function Tc(n) {
  let e, t = Bs(
    /*progress*/
    n[7]
  ), r = [];
  for (let i = 0; i < t.length; i += 1)
    r[i] = Oc(wc(n, t, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      e = xt();
    },
    l(i) {
      for (let s = 0; s < r.length; s += 1)
        r[s].l(i);
      e = xt();
    },
    m(i, s) {
      for (let o = 0; o < r.length; o += 1)
        r[o] && r[o].m(i, s);
      Q(i, e, s);
    },
    p(i, s) {
      if (s[0] & /*progress_level, progress*/
      16512) {
        t = Bs(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const l = wc(i, t, o);
          r[o] ? r[o].p(l, s) : (r[o] = Oc(l), r[o].c(), r[o].m(e.parentNode, e));
        }
        for (; o < r.length; o += 1)
          r[o].d(1);
        r.length = t.length;
      }
    },
    d(i) {
      i && K(e), ah(r, i);
    }
  };
}
function xc(n) {
  let e, t, r, i, s = (
    /*i*/
    n[42] !== 0 && zy()
  ), o = (
    /*p*/
    n[40].desc != null && Mc(n)
  ), l = (
    /*p*/
    n[40].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null && $c()
  ), a = (
    /*progress_level*/
    n[14] != null && Fc(n)
  );
  return {
    c() {
      s && s.c(), e = At(), o && o.c(), t = At(), l && l.c(), r = At(), a && a.c(), i = xt();
    },
    l(u) {
      s && s.l(u), e = Dt(u), o && o.l(u), t = Dt(u), l && l.l(u), r = Dt(u), a && a.l(u), i = xt();
    },
    m(u, c) {
      s && s.m(u, c), Q(u, e, c), o && o.m(u, c), Q(u, t, c), l && l.m(u, c), Q(u, r, c), a && a.m(u, c), Q(u, i, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? o ? o.p(u, c) : (o = Mc(u), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? l || (l = $c(), l.c(), l.m(r.parentNode, r)) : l && (l.d(1), l = null), /*progress_level*/
      u[14] != null ? a ? a.p(u, c) : (a = Fc(u), a.c(), a.m(i.parentNode, i)) : a && (a.d(1), a = null);
    },
    d(u) {
      u && (K(e), K(t), K(r), K(i)), s && s.d(u), o && o.d(u), l && l.d(u), a && a.d(u);
    }
  };
}
function zy(n) {
  let e;
  return {
    c() {
      e = Ae(" /");
    },
    l(t) {
      e = De(t, " /");
    },
    m(t, r) {
      Q(t, e, r);
    },
    d(t) {
      t && K(e);
    }
  };
}
function Mc(n) {
  let e = (
    /*p*/
    n[40].desc + ""
  ), t;
  return {
    c() {
      t = Ae(e);
    },
    l(r) {
      t = De(r, e);
    },
    m(r, i) {
      Q(r, t, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      r[40].desc + "") && Mt(t, e);
    },
    d(r) {
      r && K(t);
    }
  };
}
function $c(n) {
  let e;
  return {
    c() {
      e = Ae("-");
    },
    l(t) {
      e = De(t, "-");
    },
    m(t, r) {
      Q(t, e, r);
    },
    d(t) {
      t && K(e);
    }
  };
}
function Fc(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[42]
  ] || 0)).toFixed(1) + "", t, r;
  return {
    c() {
      t = Ae(e), r = Ae("%");
    },
    l(i) {
      t = De(i, e), r = De(i, "%");
    },
    m(i, s) {
      Q(i, t, s), Q(i, r, s);
    },
    p(i, s) {
      s[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && Mt(t, e);
    },
    d(i) {
      i && (K(t), K(r));
    }
  };
}
function Oc(n) {
  let e, t = (
    /*p*/
    (n[40].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null) && xc(n)
  );
  return {
    c() {
      t && t.c(), e = xt();
    },
    l(r) {
      t && t.l(r), e = xt();
    },
    m(r, i) {
      t && t.m(r, i), Q(r, e, i);
    },
    p(r, i) {
      /*p*/
      r[40].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[42]
      ] != null ? t ? t.p(r, i) : (t = xc(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && K(e), t && t.d(r);
    }
  };
}
function Nc(n) {
  let e, t, r, i;
  const s = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), o = oh(
    s,
    n,
    /*$$scope*/
    n[29],
    vc
  );
  return {
    c() {
      e = on("p"), t = Ae(
        /*loading_text*/
        n[9]
      ), r = At(), o && o.c(), this.h();
    },
    l(l) {
      e = sn(l, "P", { class: !0 });
      var a = rn(e);
      t = De(
        a,
        /*loading_text*/
        n[9]
      ), a.forEach(K), r = Dt(l), o && o.l(l), this.h();
    },
    h() {
      qt(e, "class", "loading svelte-17v219f");
    },
    m(l, a) {
      Q(l, e, a), tr(e, t), Q(l, r, a), o && o.m(l, a), i = !0;
    },
    p(l, a) {
      (!i || a[0] & /*loading_text*/
      512) && Mt(
        t,
        /*loading_text*/
        l[9]
      ), o && o.p && (!i || a[0] & /*$$scope*/
      536870912) && fh(
        o,
        s,
        l,
        /*$$scope*/
        l[29],
        i ? ch(
          s,
          /*$$scope*/
          l[29],
          a,
          My
        ) : uh(
          /*$$scope*/
          l[29]
        ),
        vc
      );
    },
    i(l) {
      i || (zt(o, l), i = !0);
    },
    o(l) {
      ln(o, l), i = !1;
    },
    d(l) {
      l && (K(e), K(r)), o && o.d(l);
    }
  };
}
function Hy(n) {
  let e, t, r, i, s;
  const o = [Fy, $y], l = [];
  function a(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = a(n)) && (r = l[t] = o[t](n)), {
    c() {
      e = on("div"), r && r.c(), this.h();
    },
    l(u) {
      e = sn(u, "DIV", { class: !0 });
      var c = rn(e);
      r && r.l(c), c.forEach(K), this.h();
    },
    h() {
      qt(e, "class", i = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), Et(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), Et(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), Et(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), Et(
        e,
        "border",
        /*border*/
        n[12]
      ), Pn(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), Pn(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      Q(u, e, c), ~t && l[t].m(e, null), n[33](e), s = !0;
    },
    p(u, c) {
      let d = t;
      t = a(u), t === d ? ~t && l[t].p(u, c) : (r && (Ul(), ln(l[d], 1, 1, () => {
        l[d] = null;
      }), Vl()), ~t ? (r = l[t], r ? r.p(u, c) : (r = l[t] = o[t](u), r.c()), zt(r, 1), r.m(e, null)) : r = null), (!s || c[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && qt(e, "class", i), (!s || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Et(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!s || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Et(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!s || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Et(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!s || c[0] & /*variant, show_progress, border*/
      4416) && Et(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Pn(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Pn(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      s || (zt(r), s = !0);
    },
    o(u) {
      ln(r), s = !1;
    },
    d(u) {
      u && K(e), ~t && l[t].d(), n[33](null);
    }
  };
}
var qy = function(n, e, t, r) {
  function i(s) {
    return s instanceof t ? s : new t(function(o) {
      o(s);
    });
  }
  return new (t || (t = Promise))(function(s, o) {
    function l(c) {
      try {
        u(r.next(c));
      } catch (d) {
        o(d);
      }
    }
    function a(c) {
      try {
        u(r.throw(c));
      } catch (d) {
        o(d);
      }
    }
    function u(c) {
      c.done ? s(c.value) : i(c.value).then(l, a);
    }
    u((r = r.apply(n, e || [])).next());
  });
};
let ds = [], rl = !1;
const jy = typeof window < "u", hh = jy ? window.requestAnimationFrame : (n) => {
};
function Vy(n) {
  return qy(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (ds.push(e), !rl) rl = !0;
      else return;
      yield Dy(), hh(() => {
        let r = [0, 0];
        for (let i = 0; i < ds.length; i++) {
          const o = ds[i].getBoundingClientRect();
          (i === 0 || o.top + window.scrollY <= r[0]) && (r[0] = o.top + window.scrollY, r[1] = i);
        }
        window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), rl = !1, ds = [];
      });
    }
  });
}
function Uy(n, e, t) {
  let r, { $$slots: i = {}, $$scope: s } = e;
  const o = Ty();
  let { i18n: l } = e, { eta: a = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: d } = e, { scroll_to_output: f = !1 } = e, { timer: h = !0 } = e, { show_progress: p = "full" } = e, { message: g = null } = e, { progress: _ = null } = e, { variant: k = "default" } = e, { loading_text: b = "Loading..." } = e, { absolute: y = !0 } = e, { translucent: v = !1 } = e, { border: S = !1 } = e, { autoscroll: D } = e, T, x = !1, M = 0, L = 0, R = null, X = null, ke = 0, ue = null, ae, ie = null, ve = !0;
  const fe = () => {
    t(0, a = t(27, R = t(19, C = null))), t(25, M = performance.now()), t(26, L = 0), x = !0, xe();
  };
  function xe() {
    hh(() => {
      t(26, L = (performance.now() - M) / 1e3), x && xe();
    });
  }
  function w() {
    t(26, L = 0), t(0, a = t(27, R = t(19, C = null))), x && (x = !1);
  }
  Ay(() => {
    x && w();
  });
  let C = null;
  function H($) {
    bc[$ ? "unshift" : "push"](() => {
      ie = $, t(16, ie), t(7, _), t(14, ue), t(15, ae);
    });
  }
  const B = () => {
    o("clear_status");
  };
  function J($) {
    bc[$ ? "unshift" : "push"](() => {
      T = $, t(13, T);
    });
  }
  return n.$$set = ($) => {
    "i18n" in $ && t(1, l = $.i18n), "eta" in $ && t(0, a = $.eta), "queue_position" in $ && t(2, u = $.queue_position), "queue_size" in $ && t(3, c = $.queue_size), "status" in $ && t(4, d = $.status), "scroll_to_output" in $ && t(22, f = $.scroll_to_output), "timer" in $ && t(5, h = $.timer), "show_progress" in $ && t(6, p = $.show_progress), "message" in $ && t(23, g = $.message), "progress" in $ && t(7, _ = $.progress), "variant" in $ && t(8, k = $.variant), "loading_text" in $ && t(9, b = $.loading_text), "absolute" in $ && t(10, y = $.absolute), "translucent" in $ && t(11, v = $.translucent), "border" in $ && t(12, S = $.border), "autoscroll" in $ && t(24, D = $.autoscroll), "$$scope" in $ && t(29, s = $.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (a === null && t(0, a = R), a != null && R !== a && (t(28, X = (performance.now() - M) / 1e3 + a), t(19, C = X.toFixed(1)), t(27, R = a))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ke = X === null || X <= 0 || !L ? null : Math.min(L / X, 1)), n.$$.dirty[0] & /*progress*/
    128 && _ != null && t(18, ve = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (_ != null ? t(14, ue = _.map(($) => {
      if ($.index != null && $.length != null)
        return $.index / $.length;
      if ($.progress != null)
        return $.progress;
    })) : t(14, ue = null), ue ? (t(15, ae = ue[ue.length - 1]), ie && (ae === 0 ? t(16, ie.style.transition = "0", ie) : t(16, ie.style.transition = "150ms", ie))) : t(15, ae = void 0)), n.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? fe() : w()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && T && f && (d === "pending" || d === "complete") && Vy(T, D), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, r = L.toFixed(1));
  }, [
    a,
    l,
    u,
    c,
    d,
    h,
    p,
    _,
    k,
    b,
    y,
    v,
    S,
    T,
    ue,
    ae,
    ie,
    ke,
    ve,
    C,
    r,
    o,
    f,
    g,
    D,
    M,
    L,
    R,
    X,
    s,
    i,
    H,
    B,
    J
  ];
}
class Wy extends Ey {
  constructor(e) {
    super(), Sy(
      this,
      e,
      Uy,
      Hy,
      Cy,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: ph,
  setPrototypeOf: Rc,
  isFrozen: Ky,
  getPrototypeOf: Gy,
  getOwnPropertyDescriptor: Jy
} = Object;
let {
  freeze: rt,
  seal: $t,
  create: mh
} = Object, {
  apply: Kl,
  construct: Gl
} = typeof Reflect < "u" && Reflect;
rt || (rt = function(e) {
  return e;
});
$t || ($t = function(e) {
  return e;
});
Kl || (Kl = function(e, t, r) {
  return e.apply(t, r);
});
Gl || (Gl = function(e, t) {
  return new e(...t);
});
const fs = it(Array.prototype.forEach), Yy = it(Array.prototype.lastIndexOf), Ic = it(Array.prototype.pop), ni = it(Array.prototype.push), Xy = it(Array.prototype.splice), Ms = it(String.prototype.toLowerCase), il = it(String.prototype.toString), Lc = it(String.prototype.match), ri = it(String.prototype.replace), Zy = it(String.prototype.indexOf), Qy = it(String.prototype.trim), Bt = it(Object.prototype.hasOwnProperty), tt = it(RegExp.prototype.test), ii = e1(TypeError);
function it(n) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
      r[i - 1] = arguments[i];
    return Kl(n, e, r);
  };
}
function e1(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    return Gl(n, t);
  };
}
function le(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Ms;
  Rc && Rc(n, null);
  let r = e.length;
  for (; r--; ) {
    let i = e[r];
    if (typeof i == "string") {
      const s = t(i);
      s !== i && (Ky(e) || (e[r] = s), i = s);
    }
    n[i] = !0;
  }
  return n;
}
function t1(n) {
  for (let e = 0; e < n.length; e++)
    Bt(n, e) || (n[e] = null);
  return n;
}
function bn(n) {
  const e = mh(null);
  for (const [t, r] of ph(n))
    Bt(n, t) && (Array.isArray(r) ? e[t] = t1(r) : r && typeof r == "object" && r.constructor === Object ? e[t] = bn(r) : e[t] = r);
  return e;
}
function si(n, e) {
  for (; n !== null; ) {
    const r = Jy(n, e);
    if (r) {
      if (r.get)
        return it(r.get);
      if (typeof r.value == "function")
        return it(r.value);
    }
    n = Gy(n);
  }
  function t() {
    return null;
  }
  return t;
}
const Pc = rt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), sl = rt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), ol = rt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), n1 = rt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), ll = rt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), r1 = rt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Bc = rt(["#text"]), zc = rt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), al = rt(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Hc = rt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), hs = rt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), i1 = $t(/\{\{[\w\W]*|[\w\W]*\}\}/gm), s1 = $t(/<%[\w\W]*|[\w\W]*%>/gm), o1 = $t(/\$\{[\w\W]*/gm), l1 = $t(/^data-[\-\w.\u00B7-\uFFFF]+$/), a1 = $t(/^aria-[\-\w]+$/), gh = $t(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), u1 = $t(/^(?:\w+script|data):/i), c1 = $t(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), _h = $t(/^html$/i), d1 = $t(/^[a-z][.\w]*(-[.\w]+)+$/i);
var qc = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: a1,
  ATTR_WHITESPACE: c1,
  CUSTOM_ELEMENT: d1,
  DATA_ATTR: l1,
  DOCTYPE_NAME: _h,
  ERB_EXPR: s1,
  IS_ALLOWED_URI: gh,
  IS_SCRIPT_OR_DATA: u1,
  MUSTACHE_EXPR: i1,
  TMPLIT_EXPR: o1
});
const oi = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, f1 = function() {
  return typeof window > "u" ? null : window;
}, h1 = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let r = null;
  const i = "data-tt-policy-suffix";
  t && t.hasAttribute(i) && (r = t.getAttribute(i));
  const s = "dompurify" + (r ? "#" + r : "");
  try {
    return e.createPolicy(s, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + s + " could not be created."), null;
  }
}, jc = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function yh() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : f1();
  const e = (W) => yh(W);
  if (e.version = "3.2.6", e.removed = [], !n || !n.document || n.document.nodeType !== oi.document || !n.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const r = t, i = r.currentScript, {
    DocumentFragment: s,
    HTMLTemplateElement: o,
    Node: l,
    Element: a,
    NodeFilter: u,
    NamedNodeMap: c = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: d,
    DOMParser: f,
    trustedTypes: h
  } = n, p = a.prototype, g = si(p, "cloneNode"), _ = si(p, "remove"), k = si(p, "nextSibling"), b = si(p, "childNodes"), y = si(p, "parentNode");
  if (typeof o == "function") {
    const W = t.createElement("template");
    W.content && W.content.ownerDocument && (t = W.content.ownerDocument);
  }
  let v, S = "";
  const {
    implementation: D,
    createNodeIterator: T,
    createDocumentFragment: x,
    getElementsByTagName: M
  } = t, {
    importNode: L
  } = r;
  let R = jc();
  e.isSupported = typeof ph == "function" && typeof y == "function" && D && D.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: X,
    ERB_EXPR: ke,
    TMPLIT_EXPR: ue,
    DATA_ATTR: ae,
    ARIA_ATTR: ie,
    IS_SCRIPT_OR_DATA: ve,
    ATTR_WHITESPACE: fe,
    CUSTOM_ELEMENT: xe
  } = qc;
  let {
    IS_ALLOWED_URI: w
  } = qc, C = null;
  const H = le({}, [...Pc, ...sl, ...ol, ...ll, ...Bc]);
  let B = null;
  const J = le({}, [...zc, ...al, ...Hc, ...hs]);
  let $ = Object.seal(mh(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Y = null, Le = null, he = !0, ht = !0, Dn = !1, Wt = !0, Ft = !1, Ot = !0, Kt = !1, Jn = !1, We = !1, Nt = !1, Yn = !1, vr = !1, oe = !0, Xn = !1;
  const Ji = "user-content-";
  let wr = !0, An = !1, cn = {}, Tn = null;
  const Yi = le({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Jr = null;
  const Yr = le({}, ["audio", "video", "img", "source", "image", "track"]);
  let Er = null;
  const Xr = le({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), dn = "http://www.w3.org/1998/Math/MathML", fn = "http://www.w3.org/2000/svg", at = "http://www.w3.org/1999/xhtml";
  let Gt = at, Sr = !1, m = null;
  const A = le({}, [dn, fn, at], il);
  let I = le({}, ["mi", "mo", "mn", "ms", "mtext"]), P = le({}, ["annotation-xml"]);
  const V = le({}, ["title", "style", "font", "a", "script"]);
  let ee = null;
  const te = ["application/xhtml+xml", "text/html"], de = "text/html";
  let U = null, et = null;
  const xn = t.createElement("form"), Xi = function(E) {
    return E instanceof RegExp || E instanceof Function;
  }, Zr = function() {
    let E = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(et && et === E)) {
      if ((!E || typeof E != "object") && (E = {}), E = bn(E), ee = // eslint-disable-next-line unicorn/prefer-includes
      te.indexOf(E.PARSER_MEDIA_TYPE) === -1 ? de : E.PARSER_MEDIA_TYPE, U = ee === "application/xhtml+xml" ? il : Ms, C = Bt(E, "ALLOWED_TAGS") ? le({}, E.ALLOWED_TAGS, U) : H, B = Bt(E, "ALLOWED_ATTR") ? le({}, E.ALLOWED_ATTR, U) : J, m = Bt(E, "ALLOWED_NAMESPACES") ? le({}, E.ALLOWED_NAMESPACES, il) : A, Er = Bt(E, "ADD_URI_SAFE_ATTR") ? le(bn(Xr), E.ADD_URI_SAFE_ATTR, U) : Xr, Jr = Bt(E, "ADD_DATA_URI_TAGS") ? le(bn(Yr), E.ADD_DATA_URI_TAGS, U) : Yr, Tn = Bt(E, "FORBID_CONTENTS") ? le({}, E.FORBID_CONTENTS, U) : Yi, Y = Bt(E, "FORBID_TAGS") ? le({}, E.FORBID_TAGS, U) : bn({}), Le = Bt(E, "FORBID_ATTR") ? le({}, E.FORBID_ATTR, U) : bn({}), cn = Bt(E, "USE_PROFILES") ? E.USE_PROFILES : !1, he = E.ALLOW_ARIA_ATTR !== !1, ht = E.ALLOW_DATA_ATTR !== !1, Dn = E.ALLOW_UNKNOWN_PROTOCOLS || !1, Wt = E.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Ft = E.SAFE_FOR_TEMPLATES || !1, Ot = E.SAFE_FOR_XML !== !1, Kt = E.WHOLE_DOCUMENT || !1, Nt = E.RETURN_DOM || !1, Yn = E.RETURN_DOM_FRAGMENT || !1, vr = E.RETURN_TRUSTED_TYPE || !1, We = E.FORCE_BODY || !1, oe = E.SANITIZE_DOM !== !1, Xn = E.SANITIZE_NAMED_PROPS || !1, wr = E.KEEP_CONTENT !== !1, An = E.IN_PLACE || !1, w = E.ALLOWED_URI_REGEXP || gh, Gt = E.NAMESPACE || at, I = E.MATHML_TEXT_INTEGRATION_POINTS || I, P = E.HTML_INTEGRATION_POINTS || P, $ = E.CUSTOM_ELEMENT_HANDLING || {}, E.CUSTOM_ELEMENT_HANDLING && Xi(E.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && ($.tagNameCheck = E.CUSTOM_ELEMENT_HANDLING.tagNameCheck), E.CUSTOM_ELEMENT_HANDLING && Xi(E.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && ($.attributeNameCheck = E.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), E.CUSTOM_ELEMENT_HANDLING && typeof E.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && ($.allowCustomizedBuiltInElements = E.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Ft && (ht = !1), Yn && (Nt = !0), cn && (C = le({}, Bc), B = [], cn.html === !0 && (le(C, Pc), le(B, zc)), cn.svg === !0 && (le(C, sl), le(B, al), le(B, hs)), cn.svgFilters === !0 && (le(C, ol), le(B, al), le(B, hs)), cn.mathMl === !0 && (le(C, ll), le(B, Hc), le(B, hs))), E.ADD_TAGS && (C === H && (C = bn(C)), le(C, E.ADD_TAGS, U)), E.ADD_ATTR && (B === J && (B = bn(B)), le(B, E.ADD_ATTR, U)), E.ADD_URI_SAFE_ATTR && le(Er, E.ADD_URI_SAFE_ATTR, U), E.FORBID_CONTENTS && (Tn === Yi && (Tn = bn(Tn)), le(Tn, E.FORBID_CONTENTS, U)), wr && (C["#text"] = !0), Kt && le(C, ["html", "head", "body"]), C.table && (le(C, ["tbody"]), delete Y.tbody), E.TRUSTED_TYPES_POLICY) {
        if (typeof E.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw ii('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof E.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw ii('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        v = E.TRUSTED_TYPES_POLICY, S = v.createHTML("");
      } else
        v === void 0 && (v = h1(h, i)), v !== null && typeof S == "string" && (S = v.createHTML(""));
      rt && rt(E), et = E;
    }
  }, wu = le({}, [...sl, ...ol, ...n1]), Eu = le({}, [...ll, ...r1]), Km = function(E) {
    let N = y(E);
    (!N || !N.tagName) && (N = {
      namespaceURI: Gt,
      tagName: "template"
    });
    const q = Ms(E.tagName), Se = Ms(N.tagName);
    return m[E.namespaceURI] ? E.namespaceURI === fn ? N.namespaceURI === at ? q === "svg" : N.namespaceURI === dn ? q === "svg" && (Se === "annotation-xml" || I[Se]) : !!wu[q] : E.namespaceURI === dn ? N.namespaceURI === at ? q === "math" : N.namespaceURI === fn ? q === "math" && P[Se] : !!Eu[q] : E.namespaceURI === at ? N.namespaceURI === fn && !P[Se] || N.namespaceURI === dn && !I[Se] ? !1 : !Eu[q] && (V[q] || !wu[q]) : !!(ee === "application/xhtml+xml" && m[E.namespaceURI]) : !1;
  }, Jt = function(E) {
    ni(e.removed, {
      element: E
    });
    try {
      y(E).removeChild(E);
    } catch {
      _(E);
    }
  }, Cr = function(E, N) {
    try {
      ni(e.removed, {
        attribute: N.getAttributeNode(E),
        from: N
      });
    } catch {
      ni(e.removed, {
        attribute: null,
        from: N
      });
    }
    if (N.removeAttribute(E), E === "is")
      if (Nt || Yn)
        try {
          Jt(N);
        } catch {
        }
      else
        try {
          N.setAttribute(E, "");
        } catch {
        }
  }, Su = function(E) {
    let N = null, q = null;
    if (We)
      E = "<remove></remove>" + E;
    else {
      const Pe = Lc(E, /^[\r\n\t ]+/);
      q = Pe && Pe[0];
    }
    ee === "application/xhtml+xml" && Gt === at && (E = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + E + "</body></html>");
    const Se = v ? v.createHTML(E) : E;
    if (Gt === at)
      try {
        N = new f().parseFromString(Se, ee);
      } catch {
      }
    if (!N || !N.documentElement) {
      N = D.createDocument(Gt, "template", null);
      try {
        N.documentElement.innerHTML = Sr ? S : Se;
      } catch {
      }
    }
    const Ke = N.body || N.documentElement;
    return E && q && Ke.insertBefore(t.createTextNode(q), Ke.childNodes[0] || null), Gt === at ? M.call(N, Kt ? "html" : "body")[0] : Kt ? N.documentElement : Ke;
  }, Cu = function(E) {
    return T.call(
      E.ownerDocument || E,
      E,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, Uo = function(E) {
    return E instanceof d && (typeof E.nodeName != "string" || typeof E.textContent != "string" || typeof E.removeChild != "function" || !(E.attributes instanceof c) || typeof E.removeAttribute != "function" || typeof E.setAttribute != "function" || typeof E.namespaceURI != "string" || typeof E.insertBefore != "function" || typeof E.hasChildNodes != "function");
  }, Du = function(E) {
    return typeof l == "function" && E instanceof l;
  };
  function hn(W, E, N) {
    fs(W, (q) => {
      q.call(e, E, N, et);
    });
  }
  const Au = function(E) {
    let N = null;
    if (hn(R.beforeSanitizeElements, E, null), Uo(E))
      return Jt(E), !0;
    const q = U(E.nodeName);
    if (hn(R.uponSanitizeElement, E, {
      tagName: q,
      allowedTags: C
    }), Ot && E.hasChildNodes() && !Du(E.firstElementChild) && tt(/<[/\w!]/g, E.innerHTML) && tt(/<[/\w!]/g, E.textContent) || E.nodeType === oi.progressingInstruction || Ot && E.nodeType === oi.comment && tt(/<[/\w]/g, E.data))
      return Jt(E), !0;
    if (!C[q] || Y[q]) {
      if (!Y[q] && xu(q) && ($.tagNameCheck instanceof RegExp && tt($.tagNameCheck, q) || $.tagNameCheck instanceof Function && $.tagNameCheck(q)))
        return !1;
      if (wr && !Tn[q]) {
        const Se = y(E) || E.parentNode, Ke = b(E) || E.childNodes;
        if (Ke && Se) {
          const Pe = Ke.length;
          for (let ut = Pe - 1; ut >= 0; --ut) {
            const pn = g(Ke[ut], !0);
            pn.__removalCount = (E.__removalCount || 0) + 1, Se.insertBefore(pn, k(E));
          }
        }
      }
      return Jt(E), !0;
    }
    return E instanceof a && !Km(E) || (q === "noscript" || q === "noembed" || q === "noframes") && tt(/<\/no(script|embed|frames)/i, E.innerHTML) ? (Jt(E), !0) : (Ft && E.nodeType === oi.text && (N = E.textContent, fs([X, ke, ue], (Se) => {
      N = ri(N, Se, " ");
    }), E.textContent !== N && (ni(e.removed, {
      element: E.cloneNode()
    }), E.textContent = N)), hn(R.afterSanitizeElements, E, null), !1);
  }, Tu = function(E, N, q) {
    if (oe && (N === "id" || N === "name") && (q in t || q in xn))
      return !1;
    if (!(ht && !Le[N] && tt(ae, N))) {
      if (!(he && tt(ie, N))) {
        if (!B[N] || Le[N]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(xu(E) && ($.tagNameCheck instanceof RegExp && tt($.tagNameCheck, E) || $.tagNameCheck instanceof Function && $.tagNameCheck(E)) && ($.attributeNameCheck instanceof RegExp && tt($.attributeNameCheck, N) || $.attributeNameCheck instanceof Function && $.attributeNameCheck(N)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            N === "is" && $.allowCustomizedBuiltInElements && ($.tagNameCheck instanceof RegExp && tt($.tagNameCheck, q) || $.tagNameCheck instanceof Function && $.tagNameCheck(q)))
          ) return !1;
        } else if (!Er[N]) {
          if (!tt(w, ri(q, fe, ""))) {
            if (!((N === "src" || N === "xlink:href" || N === "href") && E !== "script" && Zy(q, "data:") === 0 && Jr[E])) {
              if (!(Dn && !tt(ve, ri(q, fe, "")))) {
                if (q)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, xu = function(E) {
    return E !== "annotation-xml" && Lc(E, xe);
  }, Mu = function(E) {
    hn(R.beforeSanitizeAttributes, E, null);
    const {
      attributes: N
    } = E;
    if (!N || Uo(E))
      return;
    const q = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: B,
      forceKeepAttr: void 0
    };
    let Se = N.length;
    for (; Se--; ) {
      const Ke = N[Se], {
        name: Pe,
        namespaceURI: ut,
        value: pn
      } = Ke, Qr = U(Pe), Wo = pn;
      let Ge = Pe === "value" ? Wo : Qy(Wo);
      if (q.attrName = Qr, q.attrValue = Ge, q.keepAttr = !0, q.forceKeepAttr = void 0, hn(R.uponSanitizeAttribute, E, q), Ge = q.attrValue, Xn && (Qr === "id" || Qr === "name") && (Cr(Pe, E), Ge = Ji + Ge), Ot && tt(/((--!?|])>)|<\/(style|title)/i, Ge)) {
        Cr(Pe, E);
        continue;
      }
      if (q.forceKeepAttr)
        continue;
      if (!q.keepAttr) {
        Cr(Pe, E);
        continue;
      }
      if (!Wt && tt(/\/>/i, Ge)) {
        Cr(Pe, E);
        continue;
      }
      Ft && fs([X, ke, ue], (Fu) => {
        Ge = ri(Ge, Fu, " ");
      });
      const $u = U(E.nodeName);
      if (!Tu($u, Qr, Ge)) {
        Cr(Pe, E);
        continue;
      }
      if (v && typeof h == "object" && typeof h.getAttributeType == "function" && !ut)
        switch (h.getAttributeType($u, Qr)) {
          case "TrustedHTML": {
            Ge = v.createHTML(Ge);
            break;
          }
          case "TrustedScriptURL": {
            Ge = v.createScriptURL(Ge);
            break;
          }
        }
      if (Ge !== Wo)
        try {
          ut ? E.setAttributeNS(ut, Pe, Ge) : E.setAttribute(Pe, Ge), Uo(E) ? Jt(E) : Ic(e.removed);
        } catch {
          Cr(Pe, E);
        }
    }
    hn(R.afterSanitizeAttributes, E, null);
  }, Gm = function W(E) {
    let N = null;
    const q = Cu(E);
    for (hn(R.beforeSanitizeShadowDOM, E, null); N = q.nextNode(); )
      hn(R.uponSanitizeShadowNode, N, null), Au(N), Mu(N), N.content instanceof s && W(N.content);
    hn(R.afterSanitizeShadowDOM, E, null);
  };
  return e.sanitize = function(W) {
    let E = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, N = null, q = null, Se = null, Ke = null;
    if (Sr = !W, Sr && (W = "<!-->"), typeof W != "string" && !Du(W))
      if (typeof W.toString == "function") {
        if (W = W.toString(), typeof W != "string")
          throw ii("dirty is not a string, aborting");
      } else
        throw ii("toString is not a function");
    if (!e.isSupported)
      return W;
    if (Jn || Zr(E), e.removed = [], typeof W == "string" && (An = !1), An) {
      if (W.nodeName) {
        const pn = U(W.nodeName);
        if (!C[pn] || Y[pn])
          throw ii("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (W instanceof l)
      N = Su("<!---->"), q = N.ownerDocument.importNode(W, !0), q.nodeType === oi.element && q.nodeName === "BODY" || q.nodeName === "HTML" ? N = q : N.appendChild(q);
    else {
      if (!Nt && !Ft && !Kt && // eslint-disable-next-line unicorn/prefer-includes
      W.indexOf("<") === -1)
        return v && vr ? v.createHTML(W) : W;
      if (N = Su(W), !N)
        return Nt ? null : vr ? S : "";
    }
    N && We && Jt(N.firstChild);
    const Pe = Cu(An ? W : N);
    for (; Se = Pe.nextNode(); )
      Au(Se), Mu(Se), Se.content instanceof s && Gm(Se.content);
    if (An)
      return W;
    if (Nt) {
      if (Yn)
        for (Ke = x.call(N.ownerDocument); N.firstChild; )
          Ke.appendChild(N.firstChild);
      else
        Ke = N;
      return (B.shadowroot || B.shadowrootmode) && (Ke = L.call(r, Ke, !0)), Ke;
    }
    let ut = Kt ? N.outerHTML : N.innerHTML;
    return Kt && C["!doctype"] && N.ownerDocument && N.ownerDocument.doctype && N.ownerDocument.doctype.name && tt(_h, N.ownerDocument.doctype.name) && (ut = "<!DOCTYPE " + N.ownerDocument.doctype.name + `>
` + ut), Ft && fs([X, ke, ue], (pn) => {
      ut = ri(ut, pn, " ");
    }), v && vr ? v.createHTML(ut) : ut;
  }, e.setConfig = function() {
    let W = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Zr(W), Jn = !0;
  }, e.clearConfig = function() {
    et = null, Jn = !1;
  }, e.isValidAttribute = function(W, E, N) {
    et || Zr({});
    const q = U(W), Se = U(E);
    return Tu(q, Se, N);
  }, e.addHook = function(W, E) {
    typeof E == "function" && ni(R[W], E);
  }, e.removeHook = function(W, E) {
    if (E !== void 0) {
      const N = Yy(R[W], E);
      return N === -1 ? void 0 : Xy(R[W], N, 1)[0];
    }
    return Ic(R[W]);
  }, e.removeHooks = function(W) {
    R[W] = [];
  }, e.removeAllHooks = function() {
    R = jc();
  }, e;
}
var g5 = yh();
const {
  HtmlTagHydration: _5,
  SvelteComponent: y5,
  add_render_callback: b5,
  append_hydration: k5,
  attr: v5,
  bubble: w5,
  check_outros: E5,
  children: S5,
  claim_component: C5,
  claim_element: D5,
  claim_html_tag: A5,
  claim_space: T5,
  claim_text: x5,
  create_component: M5,
  create_in_transition: $5,
  create_out_transition: F5,
  destroy_component: O5,
  detach: N5,
  element: R5,
  get_svelte_dataset: I5,
  group_outros: L5,
  init: P5,
  insert_hydration: B5,
  listen: z5,
  mount_component: H5,
  run_all: q5,
  safe_not_equal: j5,
  set_data: V5,
  space: U5,
  stop_propagation: W5,
  text: K5,
  toggle_class: G5,
  transition_in: J5,
  transition_out: Y5
} = window.__gradio__svelte__internal, { createEventDispatcher: X5, onMount: Z5 } = window.__gradio__svelte__internal, {
  SvelteComponent: Q5,
  append_hydration: e9,
  attr: t9,
  bubble: n9,
  check_outros: r9,
  children: i9,
  claim_component: s9,
  claim_element: o9,
  claim_space: l9,
  create_animation: a9,
  create_component: u9,
  destroy_component: c9,
  detach: d9,
  element: f9,
  ensure_array_like: h9,
  fix_and_outro_and_destroy_block: p9,
  fix_position: m9,
  group_outros: g9,
  init: _9,
  insert_hydration: y9,
  mount_component: b9,
  noop: k9,
  safe_not_equal: v9,
  set_style: w9,
  space: E9,
  transition_in: S9,
  transition_out: C9,
  update_keyed_each: D9
} = window.__gradio__svelte__internal, {
  SvelteComponent: A9,
  attr: T9,
  children: x9,
  claim_element: M9,
  detach: $9,
  element: F9,
  empty: O9,
  init: N9,
  insert_hydration: R9,
  noop: I9,
  safe_not_equal: L9,
  set_style: P9
} = window.__gradio__svelte__internal;
function je(n) {
  this.content = n;
}
je.prototype = {
  constructor: je,
  find: function(n) {
    for (var e = 0; e < this.content.length; e += 2)
      if (this.content[e] === n) return e;
    return -1;
  },
  // :: (string) → ?any
  // Retrieve the value stored under `key`, or return undefined when
  // no such key exists.
  get: function(n) {
    var e = this.find(n);
    return e == -1 ? void 0 : this.content[e + 1];
  },
  // :: (string, any, ?string) → OrderedMap
  // Create a new map by replacing the value of `key` with a new
  // value, or adding a binding to the end of the map. If `newKey` is
  // given, the key of the binding will be replaced with that key.
  update: function(n, e, t) {
    var r = t && t != n ? this.remove(t) : this, i = r.find(n), s = r.content.slice();
    return i == -1 ? s.push(t || n, e) : (s[i + 1] = e, t && (s[i] = t)), new je(s);
  },
  // :: (string) → OrderedMap
  // Return a map with the given key removed, if it existed.
  remove: function(n) {
    var e = this.find(n);
    if (e == -1) return this;
    var t = this.content.slice();
    return t.splice(e, 2), new je(t);
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the start of the map.
  addToStart: function(n, e) {
    return new je([n, e].concat(this.remove(n).content));
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the end of the map.
  addToEnd: function(n, e) {
    var t = this.remove(n).content.slice();
    return t.push(n, e), new je(t);
  },
  // :: (string, string, any) → OrderedMap
  // Add a key after the given key. If `place` is not found, the new
  // key is added to the end.
  addBefore: function(n, e, t) {
    var r = this.remove(e), i = r.content.slice(), s = r.find(n);
    return i.splice(s == -1 ? i.length : s, 0, e, t), new je(i);
  },
  // :: ((key: string, value: any))
  // Call the given function for each key/value pair in the map, in
  // order.
  forEach: function(n) {
    for (var e = 0; e < this.content.length; e += 2)
      n(this.content[e], this.content[e + 1]);
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by prepending the keys in this map that don't
  // appear in `map` before the keys in `map`.
  prepend: function(n) {
    return n = je.from(n), n.size ? new je(n.content.concat(this.subtract(n).content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by appending the keys in this map that don't
  // appear in `map` after the keys in `map`.
  append: function(n) {
    return n = je.from(n), n.size ? new je(this.subtract(n).content.concat(n.content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a map containing all the keys in this map that don't
  // appear in `map`.
  subtract: function(n) {
    var e = this;
    n = je.from(n);
    for (var t = 0; t < n.content.length; t += 2)
      e = e.remove(n.content[t]);
    return e;
  },
  // :: () → Object
  // Turn ordered map into a plain object.
  toObject: function() {
    var n = {};
    return this.forEach(function(e, t) {
      n[e] = t;
    }), n;
  },
  // :: number
  // The amount of keys in this map.
  get size() {
    return this.content.length >> 1;
  }
};
je.from = function(n) {
  if (n instanceof je) return n;
  var e = [];
  if (n) for (var t in n) e.push(t, n[t]);
  return new je(e);
};
function bh(n, e, t) {
  for (let r = 0; ; r++) {
    if (r == n.childCount || r == e.childCount)
      return n.childCount == e.childCount ? null : t;
    let i = n.child(r), s = e.child(r);
    if (i == s) {
      t += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(s))
      return t;
    if (i.isText && i.text != s.text) {
      for (let o = 0; i.text[o] == s.text[o]; o++)
        t++;
      return t;
    }
    if (i.content.size || s.content.size) {
      let o = bh(i.content, s.content, t + 1);
      if (o != null)
        return o;
    }
    t += i.nodeSize;
  }
}
function kh(n, e, t, r) {
  for (let i = n.childCount, s = e.childCount; ; ) {
    if (i == 0 || s == 0)
      return i == s ? null : { a: t, b: r };
    let o = n.child(--i), l = e.child(--s), a = o.nodeSize;
    if (o == l) {
      t -= a, r -= a;
      continue;
    }
    if (!o.sameMarkup(l))
      return { a: t, b: r };
    if (o.isText && o.text != l.text) {
      let u = 0, c = Math.min(o.text.length, l.text.length);
      for (; u < c && o.text[o.text.length - u - 1] == l.text[l.text.length - u - 1]; )
        u++, t--, r--;
      return { a: t, b: r };
    }
    if (o.content.size || l.content.size) {
      let u = kh(o.content, l.content, t - 1, r - 1);
      if (u)
        return u;
    }
    t -= a, r -= a;
  }
}
class F {
  /**
  @internal
  */
  constructor(e, t) {
    if (this.content = e, this.size = t || 0, t == null)
      for (let r = 0; r < e.length; r++)
        this.size += e[r].nodeSize;
  }
  /**
  Invoke a callback for all descendant nodes between the given two
  positions (relative to start of this fragment). Doesn't descend
  into a node when the callback returns `false`.
  */
  nodesBetween(e, t, r, i = 0, s) {
    for (let o = 0, l = 0; l < t; o++) {
      let a = this.content[o], u = l + a.nodeSize;
      if (u > e && r(a, i + l, s || null, o) !== !1 && a.content.size) {
        let c = l + 1;
        a.nodesBetween(Math.max(0, e - c), Math.min(a.content.size, t - c), r, i + c);
      }
      l = u;
    }
  }
  /**
  Call the given callback for every descendant node. `pos` will be
  relative to the start of the fragment. The callback may return
  `false` to prevent traversal of a given node's children.
  */
  descendants(e) {
    this.nodesBetween(0, this.size, e);
  }
  /**
  Extract the text between `from` and `to`. See the same method on
  [`Node`](https://prosemirror.net/docs/ref/#model.Node.textBetween).
  */
  textBetween(e, t, r, i) {
    let s = "", o = !0;
    return this.nodesBetween(e, t, (l, a) => {
      let u = l.isText ? l.text.slice(Math.max(e, a) - a, t - a) : l.isLeaf ? i ? typeof i == "function" ? i(l) : i : l.type.spec.leafText ? l.type.spec.leafText(l) : "" : "";
      l.isBlock && (l.isLeaf && u || l.isTextblock) && r && (o ? o = !1 : s += r), s += u;
    }, 0), s;
  }
  /**
  Create a new fragment containing the combined content of this
  fragment and the other.
  */
  append(e) {
    if (!e.size)
      return this;
    if (!this.size)
      return e;
    let t = this.lastChild, r = e.firstChild, i = this.content.slice(), s = 0;
    for (t.isText && t.sameMarkup(r) && (i[i.length - 1] = t.withText(t.text + r.text), s = 1); s < e.content.length; s++)
      i.push(e.content[s]);
    return new F(i, this.size + e.size);
  }
  /**
  Cut out the sub-fragment between the two given positions.
  */
  cut(e, t = this.size) {
    if (e == 0 && t == this.size)
      return this;
    let r = [], i = 0;
    if (t > e)
      for (let s = 0, o = 0; o < t; s++) {
        let l = this.content[s], a = o + l.nodeSize;
        a > e && ((o < e || a > t) && (l.isText ? l = l.cut(Math.max(0, e - o), Math.min(l.text.length, t - o)) : l = l.cut(Math.max(0, e - o - 1), Math.min(l.content.size, t - o - 1))), r.push(l), i += l.nodeSize), o = a;
      }
    return new F(r, i);
  }
  /**
  @internal
  */
  cutByIndex(e, t) {
    return e == t ? F.empty : e == 0 && t == this.content.length ? this : new F(this.content.slice(e, t));
  }
  /**
  Create a new fragment in which the node at the given index is
  replaced by the given node.
  */
  replaceChild(e, t) {
    let r = this.content[e];
    if (r == t)
      return this;
    let i = this.content.slice(), s = this.size + t.nodeSize - r.nodeSize;
    return i[e] = t, new F(i, s);
  }
  /**
  Create a new fragment by prepending the given node to this
  fragment.
  */
  addToStart(e) {
    return new F([e].concat(this.content), this.size + e.nodeSize);
  }
  /**
  Create a new fragment by appending the given node to this
  fragment.
  */
  addToEnd(e) {
    return new F(this.content.concat(e), this.size + e.nodeSize);
  }
  /**
  Compare this fragment to another one.
  */
  eq(e) {
    if (this.content.length != e.content.length)
      return !1;
    for (let t = 0; t < this.content.length; t++)
      if (!this.content[t].eq(e.content[t]))
        return !1;
    return !0;
  }
  /**
  The first child of the fragment, or `null` if it is empty.
  */
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  /**
  The last child of the fragment, or `null` if it is empty.
  */
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  /**
  The number of child nodes in this fragment.
  */
  get childCount() {
    return this.content.length;
  }
  /**
  Get the child node at the given index. Raise an error when the
  index is out of range.
  */
  child(e) {
    let t = this.content[e];
    if (!t)
      throw new RangeError("Index " + e + " out of range for " + this);
    return t;
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content[e] || null;
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    for (let t = 0, r = 0; t < this.content.length; t++) {
      let i = this.content[t];
      e(i, r, t), r += i.nodeSize;
    }
  }
  /**
  Find the first position at which this fragment and another
  fragment differ, or `null` if they are the same.
  */
  findDiffStart(e, t = 0) {
    return bh(this, e, t);
  }
  /**
  Find the first position, searching from the end, at which this
  fragment and the given fragment differ, or `null` if they are
  the same. Since this position will not be the same in both
  nodes, an object with two separate positions is returned.
  */
  findDiffEnd(e, t = this.size, r = e.size) {
    return kh(this, e, t, r);
  }
  /**
  Find the index and inner offset corresponding to a given relative
  position in this fragment. The result object will be reused
  (overwritten) the next time the function is called. @internal
  */
  findIndex(e) {
    if (e == 0)
      return ps(0, e);
    if (e == this.size)
      return ps(this.content.length, e);
    if (e > this.size || e < 0)
      throw new RangeError(`Position ${e} outside of fragment (${this})`);
    for (let t = 0, r = 0; ; t++) {
      let i = this.child(t), s = r + i.nodeSize;
      if (s >= e)
        return s == e ? ps(t + 1, s) : ps(t, r);
      r = s;
    }
  }
  /**
  Return a debugging string that describes this fragment.
  */
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  /**
  @internal
  */
  toStringInner() {
    return this.content.join(", ");
  }
  /**
  Create a JSON-serializeable representation of this fragment.
  */
  toJSON() {
    return this.content.length ? this.content.map((e) => e.toJSON()) : null;
  }
  /**
  Deserialize a fragment from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return F.empty;
    if (!Array.isArray(t))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return new F(t.map(e.nodeFromJSON));
  }
  /**
  Build a fragment from an array of nodes. Ensures that adjacent
  text nodes with the same marks are joined together.
  */
  static fromArray(e) {
    if (!e.length)
      return F.empty;
    let t, r = 0;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      r += s.nodeSize, i && s.isText && e[i - 1].sameMarkup(s) ? (t || (t = e.slice(0, i)), t[t.length - 1] = s.withText(t[t.length - 1].text + s.text)) : t && t.push(s);
    }
    return new F(t || e, r);
  }
  /**
  Create a fragment from something that can be interpreted as a
  set of nodes. For `null`, it returns the empty fragment. For a
  fragment, the fragment itself. For a node or array of nodes, a
  fragment containing those nodes.
  */
  static from(e) {
    if (!e)
      return F.empty;
    if (e instanceof F)
      return e;
    if (Array.isArray(e))
      return this.fromArray(e);
    if (e.attrs)
      return new F([e], e.nodeSize);
    throw new RangeError("Can not convert " + e + " to a Fragment" + (e.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
F.empty = new F([], 0);
const ul = { index: 0, offset: 0 };
function ps(n, e) {
  return ul.index = n, ul.offset = e, ul;
}
function zs(n, e) {
  if (n === e)
    return !0;
  if (!(n && typeof n == "object") || !(e && typeof e == "object"))
    return !1;
  let t = Array.isArray(n);
  if (Array.isArray(e) != t)
    return !1;
  if (t) {
    if (n.length != e.length)
      return !1;
    for (let r = 0; r < n.length; r++)
      if (!zs(n[r], e[r]))
        return !1;
  } else {
    for (let r in n)
      if (!(r in e) || !zs(n[r], e[r]))
        return !1;
    for (let r in e)
      if (!(r in n))
        return !1;
  }
  return !0;
}
let be = class Jl {
  /**
  @internal
  */
  constructor(e, t) {
    this.type = e, this.attrs = t;
  }
  /**
  Given a set of marks, create a new set which contains this one as
  well, in the right position. If this mark is already in the set,
  the set itself is returned. If any marks that are set to be
  [exclusive](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) with this mark are present,
  those are replaced by this one.
  */
  addToSet(e) {
    let t, r = !1;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      if (this.eq(s))
        return e;
      if (this.type.excludes(s.type))
        t || (t = e.slice(0, i));
      else {
        if (s.type.excludes(this.type))
          return e;
        !r && s.type.rank > this.type.rank && (t || (t = e.slice(0, i)), t.push(this), r = !0), t && t.push(s);
      }
    }
    return t || (t = e.slice()), r || t.push(this), t;
  }
  /**
  Remove this mark from the given set, returning a new set. If this
  mark is not in the set, the set itself is returned.
  */
  removeFromSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return e.slice(0, t).concat(e.slice(t + 1));
    return e;
  }
  /**
  Test whether this mark is in the given set of marks.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return !0;
    return !1;
  }
  /**
  Test whether this mark has the same type and attributes as
  another mark.
  */
  eq(e) {
    return this == e || this.type == e.type && zs(this.attrs, e.attrs);
  }
  /**
  Convert this mark to a JSON-serializeable representation.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return e;
  }
  /**
  Deserialize a mark from JSON.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let r = e.marks[t.type];
    if (!r)
      throw new RangeError(`There is no mark type ${t.type} in this schema`);
    let i = r.create(t.attrs);
    return r.checkAttrs(i.attrs), i;
  }
  /**
  Test whether two sets of marks are identical.
  */
  static sameSet(e, t) {
    if (e == t)
      return !0;
    if (e.length != t.length)
      return !1;
    for (let r = 0; r < e.length; r++)
      if (!e[r].eq(t[r]))
        return !1;
    return !0;
  }
  /**
  Create a properly sorted mark set from null, a single mark, or an
  unsorted array of marks.
  */
  static setFrom(e) {
    if (!e || Array.isArray(e) && e.length == 0)
      return Jl.none;
    if (e instanceof Jl)
      return [e];
    let t = e.slice();
    return t.sort((r, i) => r.type.rank - i.type.rank), t;
  }
};
be.none = [];
class Hs extends Error {
}
class z {
  /**
  Create a slice. When specifying a non-zero open depth, you must
  make sure that there are nodes of at least that depth at the
  appropriate side of the fragment—i.e. if the fragment is an
  empty paragraph node, `openStart` and `openEnd` can't be greater
  than 1.
  
  It is not necessary for the content of open nodes to conform to
  the schema's content constraints, though it should be a valid
  start/end/middle for such a node, depending on which sides are
  open.
  */
  constructor(e, t, r) {
    this.content = e, this.openStart = t, this.openEnd = r;
  }
  /**
  The size this slice would add when inserted into a document.
  */
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  /**
  @internal
  */
  insertAt(e, t) {
    let r = wh(this.content, e + this.openStart, t);
    return r && new z(r, this.openStart, this.openEnd);
  }
  /**
  @internal
  */
  removeBetween(e, t) {
    return new z(vh(this.content, e + this.openStart, t + this.openStart), this.openStart, this.openEnd);
  }
  /**
  Tests whether this slice is equal to another slice.
  */
  eq(e) {
    return this.content.eq(e.content) && this.openStart == e.openStart && this.openEnd == e.openEnd;
  }
  /**
  @internal
  */
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  /**
  Convert a slice to a JSON-serializable representation.
  */
  toJSON() {
    if (!this.content.size)
      return null;
    let e = { content: this.content.toJSON() };
    return this.openStart > 0 && (e.openStart = this.openStart), this.openEnd > 0 && (e.openEnd = this.openEnd), e;
  }
  /**
  Deserialize a slice from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return z.empty;
    let r = t.openStart || 0, i = t.openEnd || 0;
    if (typeof r != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new z(F.fromJSON(e, t.content), r, i);
  }
  /**
  Create a slice from a fragment by taking the maximum possible
  open value on both side of the fragment.
  */
  static maxOpen(e, t = !0) {
    let r = 0, i = 0;
    for (let s = e.firstChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.firstChild)
      r++;
    for (let s = e.lastChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.lastChild)
      i++;
    return new z(e, r, i);
  }
}
z.empty = new z(F.empty, 0, 0);
function vh(n, e, t) {
  let { index: r, offset: i } = n.findIndex(e), s = n.maybeChild(r), { index: o, offset: l } = n.findIndex(t);
  if (i == e || s.isText) {
    if (l != t && !n.child(o).isText)
      throw new RangeError("Removing non-flat range");
    return n.cut(0, e).append(n.cut(t));
  }
  if (r != o)
    throw new RangeError("Removing non-flat range");
  return n.replaceChild(r, s.copy(vh(s.content, e - i - 1, t - i - 1)));
}
function wh(n, e, t, r) {
  let { index: i, offset: s } = n.findIndex(e), o = n.maybeChild(i);
  if (s == e || o.isText)
    return n.cut(0, e).append(t).append(n.cut(e));
  let l = wh(o.content, e - s - 1, t);
  return l && n.replaceChild(i, o.copy(l));
}
function p1(n, e, t) {
  if (t.openStart > n.depth)
    throw new Hs("Inserted content deeper than insertion position");
  if (n.depth - t.openStart != e.depth - t.openEnd)
    throw new Hs("Inconsistent open depths");
  return Eh(n, e, t, 0);
}
function Eh(n, e, t, r) {
  let i = n.index(r), s = n.node(r);
  if (i == e.index(r) && r < n.depth - t.openStart) {
    let o = Eh(n, e, t, r + 1);
    return s.copy(s.content.replaceChild(i, o));
  } else if (t.content.size)
    if (!t.openStart && !t.openEnd && n.depth == r && e.depth == r) {
      let o = n.parent, l = o.content;
      return lr(o, l.cut(0, n.parentOffset).append(t.content).append(l.cut(e.parentOffset)));
    } else {
      let { start: o, end: l } = m1(t, n);
      return lr(s, Ch(n, o, l, e, r));
    }
  else return lr(s, qs(n, e, r));
}
function Sh(n, e) {
  if (!e.type.compatibleContent(n.type))
    throw new Hs("Cannot join " + e.type.name + " onto " + n.type.name);
}
function Yl(n, e, t) {
  let r = n.node(t);
  return Sh(r, e.node(t)), r;
}
function or(n, e) {
  let t = e.length - 1;
  t >= 0 && n.isText && n.sameMarkup(e[t]) ? e[t] = n.withText(e[t].text + n.text) : e.push(n);
}
function ki(n, e, t, r) {
  let i = (e || n).node(t), s = 0, o = e ? e.index(t) : i.childCount;
  n && (s = n.index(t), n.depth > t ? s++ : n.textOffset && (or(n.nodeAfter, r), s++));
  for (let l = s; l < o; l++)
    or(i.child(l), r);
  e && e.depth == t && e.textOffset && or(e.nodeBefore, r);
}
function lr(n, e) {
  return n.type.checkContent(e), n.copy(e);
}
function Ch(n, e, t, r, i) {
  let s = n.depth > i && Yl(n, e, i + 1), o = r.depth > i && Yl(t, r, i + 1), l = [];
  return ki(null, n, i, l), s && o && e.index(i) == t.index(i) ? (Sh(s, o), or(lr(s, Ch(n, e, t, r, i + 1)), l)) : (s && or(lr(s, qs(n, e, i + 1)), l), ki(e, t, i, l), o && or(lr(o, qs(t, r, i + 1)), l)), ki(r, null, i, l), new F(l);
}
function qs(n, e, t) {
  let r = [];
  if (ki(null, n, t, r), n.depth > t) {
    let i = Yl(n, e, t + 1);
    or(lr(i, qs(n, e, t + 1)), r);
  }
  return ki(e, null, t, r), new F(r);
}
function m1(n, e) {
  let t = e.depth - n.openStart, i = e.node(t).copy(n.content);
  for (let s = t - 1; s >= 0; s--)
    i = e.node(s).copy(F.from(i));
  return {
    start: i.resolveNoCache(n.openStart + t),
    end: i.resolveNoCache(i.content.size - n.openEnd - t)
  };
}
class Oi {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.pos = e, this.path = t, this.parentOffset = r, this.depth = t.length / 3 - 1;
  }
  /**
  @internal
  */
  resolveDepth(e) {
    return e == null ? this.depth : e < 0 ? this.depth + e : e;
  }
  /**
  The parent node that the position points into. Note that even if
  a position points into a text node, that node is not considered
  the parent—text nodes are ‘flat’ in this model, and have no content.
  */
  get parent() {
    return this.node(this.depth);
  }
  /**
  The root node in which the position was resolved.
  */
  get doc() {
    return this.node(0);
  }
  /**
  The ancestor node at the given level. `p.node(p.depth)` is the
  same as `p.parent`.
  */
  node(e) {
    return this.path[this.resolveDepth(e) * 3];
  }
  /**
  The index into the ancestor at the given level. If this points
  at the 3rd node in the 2nd paragraph on the top level, for
  example, `p.index(0)` is 1 and `p.index(1)` is 2.
  */
  index(e) {
    return this.path[this.resolveDepth(e) * 3 + 1];
  }
  /**
  The index pointing after this position into the ancestor at the
  given level.
  */
  indexAfter(e) {
    return e = this.resolveDepth(e), this.index(e) + (e == this.depth && !this.textOffset ? 0 : 1);
  }
  /**
  The (absolute) position at the start of the node at the given
  level.
  */
  start(e) {
    return e = this.resolveDepth(e), e == 0 ? 0 : this.path[e * 3 - 1] + 1;
  }
  /**
  The (absolute) position at the end of the node at the given
  level.
  */
  end(e) {
    return e = this.resolveDepth(e), this.start(e) + this.node(e).content.size;
  }
  /**
  The (absolute) position directly before the wrapping node at the
  given level, or, when `depth` is `this.depth + 1`, the original
  position.
  */
  before(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position before the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1];
  }
  /**
  The (absolute) position directly after the wrapping node at the
  given level, or the original position when `depth` is `this.depth + 1`.
  */
  after(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position after the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1] + this.path[e * 3].nodeSize;
  }
  /**
  When this position points into a text node, this returns the
  distance between the position and the start of the text node.
  Will be zero for positions that point between nodes.
  */
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  /**
  Get the node directly after the position, if any. If the position
  points into a text node, only the part of that node after the
  position is returned.
  */
  get nodeAfter() {
    let e = this.parent, t = this.index(this.depth);
    if (t == e.childCount)
      return null;
    let r = this.pos - this.path[this.path.length - 1], i = e.child(t);
    return r ? e.child(t).cut(r) : i;
  }
  /**
  Get the node directly before the position, if any. If the
  position points into a text node, only the part of that node
  before the position is returned.
  */
  get nodeBefore() {
    let e = this.index(this.depth), t = this.pos - this.path[this.path.length - 1];
    return t ? this.parent.child(e).cut(0, t) : e == 0 ? null : this.parent.child(e - 1);
  }
  /**
  Get the position at the given index in the parent node at the
  given depth (which defaults to `this.depth`).
  */
  posAtIndex(e, t) {
    t = this.resolveDepth(t);
    let r = this.path[t * 3], i = t == 0 ? 0 : this.path[t * 3 - 1] + 1;
    for (let s = 0; s < e; s++)
      i += r.child(s).nodeSize;
    return i;
  }
  /**
  Get the marks at this position, factoring in the surrounding
  marks' [`inclusive`](https://prosemirror.net/docs/ref/#model.MarkSpec.inclusive) property. If the
  position is at the start of a non-empty node, the marks of the
  node after it (if any) are returned.
  */
  marks() {
    let e = this.parent, t = this.index();
    if (e.content.size == 0)
      return be.none;
    if (this.textOffset)
      return e.child(t).marks;
    let r = e.maybeChild(t - 1), i = e.maybeChild(t);
    if (!r) {
      let l = r;
      r = i, i = l;
    }
    let s = r.marks;
    for (var o = 0; o < s.length; o++)
      s[o].type.spec.inclusive === !1 && (!i || !s[o].isInSet(i.marks)) && (s = s[o--].removeFromSet(s));
    return s;
  }
  /**
  Get the marks after the current position, if any, except those
  that are non-inclusive and not present at position `$end`. This
  is mostly useful for getting the set of marks to preserve after a
  deletion. Will return `null` if this position is at the end of
  its parent node or its parent node isn't a textblock (in which
  case no marks should be preserved).
  */
  marksAcross(e) {
    let t = this.parent.maybeChild(this.index());
    if (!t || !t.isInline)
      return null;
    let r = t.marks, i = e.parent.maybeChild(e.index());
    for (var s = 0; s < r.length; s++)
      r[s].type.spec.inclusive === !1 && (!i || !r[s].isInSet(i.marks)) && (r = r[s--].removeFromSet(r));
    return r;
  }
  /**
  The depth up to which this position and the given (non-resolved)
  position share the same parent nodes.
  */
  sharedDepth(e) {
    for (let t = this.depth; t > 0; t--)
      if (this.start(t) <= e && this.end(t) >= e)
        return t;
    return 0;
  }
  /**
  Returns a range based on the place where this position and the
  given position diverge around block content. If both point into
  the same textblock, for example, a range around that textblock
  will be returned. If they point into different blocks, the range
  around those blocks in their shared ancestor is returned. You can
  pass in an optional predicate that will be called with a parent
  node to see if a range into that parent is acceptable.
  */
  blockRange(e = this, t) {
    if (e.pos < this.pos)
      return e.blockRange(this);
    for (let r = this.depth - (this.parent.inlineContent || this.pos == e.pos ? 1 : 0); r >= 0; r--)
      if (e.pos <= this.end(r) && (!t || t(this.node(r))))
        return new js(this, e, r);
    return null;
  }
  /**
  Query whether the given position shares the same parent node.
  */
  sameParent(e) {
    return this.pos - this.parentOffset == e.pos - e.parentOffset;
  }
  /**
  Return the greater of this and the given position.
  */
  max(e) {
    return e.pos > this.pos ? e : this;
  }
  /**
  Return the smaller of this and the given position.
  */
  min(e) {
    return e.pos < this.pos ? e : this;
  }
  /**
  @internal
  */
  toString() {
    let e = "";
    for (let t = 1; t <= this.depth; t++)
      e += (e ? "/" : "") + this.node(t).type.name + "_" + this.index(t - 1);
    return e + ":" + this.parentOffset;
  }
  /**
  @internal
  */
  static resolve(e, t) {
    if (!(t >= 0 && t <= e.content.size))
      throw new RangeError("Position " + t + " out of range");
    let r = [], i = 0, s = t;
    for (let o = e; ; ) {
      let { index: l, offset: a } = o.content.findIndex(s), u = s - a;
      if (r.push(o, l, i + a), !u || (o = o.child(l), o.isText))
        break;
      s = u - 1, i += a + 1;
    }
    return new Oi(t, r, s);
  }
  /**
  @internal
  */
  static resolveCached(e, t) {
    let r = Vc.get(e);
    if (r)
      for (let s = 0; s < r.elts.length; s++) {
        let o = r.elts[s];
        if (o.pos == t)
          return o;
      }
    else
      Vc.set(e, r = new g1());
    let i = r.elts[r.i] = Oi.resolve(e, t);
    return r.i = (r.i + 1) % _1, i;
  }
}
class g1 {
  constructor() {
    this.elts = [], this.i = 0;
  }
}
const _1 = 12, Vc = /* @__PURE__ */ new WeakMap();
class js {
  /**
  Construct a node range. `$from` and `$to` should point into the
  same node until at least the given `depth`, since a node range
  denotes an adjacent set of nodes in a single parent node.
  */
  constructor(e, t, r) {
    this.$from = e, this.$to = t, this.depth = r;
  }
  /**
  The position at the start of the range.
  */
  get start() {
    return this.$from.before(this.depth + 1);
  }
  /**
  The position at the end of the range.
  */
  get end() {
    return this.$to.after(this.depth + 1);
  }
  /**
  The parent node that the range points into.
  */
  get parent() {
    return this.$from.node(this.depth);
  }
  /**
  The start index of the range in the parent node.
  */
  get startIndex() {
    return this.$from.index(this.depth);
  }
  /**
  The end index of the range in the parent node.
  */
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const y1 = /* @__PURE__ */ Object.create(null);
class _t {
  /**
  @internal
  */
  constructor(e, t, r, i = be.none) {
    this.type = e, this.attrs = t, this.marks = i, this.content = r || F.empty;
  }
  /**
  The array of this node's child nodes.
  */
  get children() {
    return this.content.content;
  }
  /**
  The size of this node, as defined by the integer-based [indexing
  scheme](https://prosemirror.net/docs/guide/#doc.indexing). For text nodes, this is the
  amount of characters. For other leaf nodes, it is one. For
  non-leaf nodes, it is the size of the content plus two (the
  start and end token).
  */
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  /**
  The number of children that the node has.
  */
  get childCount() {
    return this.content.childCount;
  }
  /**
  Get the child node at the given index. Raises an error when the
  index is out of range.
  */
  child(e) {
    return this.content.child(e);
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content.maybeChild(e);
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    this.content.forEach(e);
  }
  /**
  Invoke a callback for all descendant nodes recursively between
  the given two positions that are relative to start of this
  node's content. The callback is invoked with the node, its
  position relative to the original node (method receiver),
  its parent node, and its child index. When the callback returns
  false for a given node, that node's children will not be
  recursed over. The last parameter can be used to specify a
  starting position to count from.
  */
  nodesBetween(e, t, r, i = 0) {
    this.content.nodesBetween(e, t, r, i, this);
  }
  /**
  Call the given callback for every descendant node. Doesn't
  descend into a node when the callback returns `false`.
  */
  descendants(e) {
    this.nodesBetween(0, this.content.size, e);
  }
  /**
  Concatenates all the text nodes found in this fragment and its
  children.
  */
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  /**
  Get all text between positions `from` and `to`. When
  `blockSeparator` is given, it will be inserted to separate text
  from different block nodes. If `leafText` is given, it'll be
  inserted for every non-text leaf node encountered, otherwise
  [`leafText`](https://prosemirror.net/docs/ref/#model.NodeSpec.leafText) will be used.
  */
  textBetween(e, t, r, i) {
    return this.content.textBetween(e, t, r, i);
  }
  /**
  Returns this node's first child, or `null` if there are no
  children.
  */
  get firstChild() {
    return this.content.firstChild;
  }
  /**
  Returns this node's last child, or `null` if there are no
  children.
  */
  get lastChild() {
    return this.content.lastChild;
  }
  /**
  Test whether two nodes represent the same piece of document.
  */
  eq(e) {
    return this == e || this.sameMarkup(e) && this.content.eq(e.content);
  }
  /**
  Compare the markup (type, attributes, and marks) of this node to
  those of another. Returns `true` if both have the same markup.
  */
  sameMarkup(e) {
    return this.hasMarkup(e.type, e.attrs, e.marks);
  }
  /**
  Check whether this node's markup correspond to the given type,
  attributes, and marks.
  */
  hasMarkup(e, t, r) {
    return this.type == e && zs(this.attrs, t || e.defaultAttrs || y1) && be.sameSet(this.marks, r || be.none);
  }
  /**
  Create a new node with the same markup as this node, containing
  the given content (or empty, if no content is given).
  */
  copy(e = null) {
    return e == this.content ? this : new _t(this.type, this.attrs, e, this.marks);
  }
  /**
  Create a copy of this node, with the given set of marks instead
  of the node's own marks.
  */
  mark(e) {
    return e == this.marks ? this : new _t(this.type, this.attrs, this.content, e);
  }
  /**
  Create a copy of this node with only the content between the
  given positions. If `to` is not given, it defaults to the end of
  the node.
  */
  cut(e, t = this.content.size) {
    return e == 0 && t == this.content.size ? this : this.copy(this.content.cut(e, t));
  }
  /**
  Cut out the part of the document between the given positions, and
  return it as a `Slice` object.
  */
  slice(e, t = this.content.size, r = !1) {
    if (e == t)
      return z.empty;
    let i = this.resolve(e), s = this.resolve(t), o = r ? 0 : i.sharedDepth(t), l = i.start(o), u = i.node(o).content.cut(i.pos - l, s.pos - l);
    return new z(u, i.depth - o, s.depth - o);
  }
  /**
  Replace the part of the document between the given positions with
  the given slice. The slice must 'fit', meaning its open sides
  must be able to connect to the surrounding content, and its
  content nodes must be valid children for the node they are placed
  into. If any of this is violated, an error of type
  [`ReplaceError`](https://prosemirror.net/docs/ref/#model.ReplaceError) is thrown.
  */
  replace(e, t, r) {
    return p1(this.resolve(e), this.resolve(t), r);
  }
  /**
  Find the node directly after the given position.
  */
  nodeAt(e) {
    for (let t = this; ; ) {
      let { index: r, offset: i } = t.content.findIndex(e);
      if (t = t.maybeChild(r), !t)
        return null;
      if (i == e || t.isText)
        return t;
      e -= i + 1;
    }
  }
  /**
  Find the (direct) child node after the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childAfter(e) {
    let { index: t, offset: r } = this.content.findIndex(e);
    return { node: this.content.maybeChild(t), index: t, offset: r };
  }
  /**
  Find the (direct) child node before the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childBefore(e) {
    if (e == 0)
      return { node: null, index: 0, offset: 0 };
    let { index: t, offset: r } = this.content.findIndex(e);
    if (r < e)
      return { node: this.content.child(t), index: t, offset: r };
    let i = this.content.child(t - 1);
    return { node: i, index: t - 1, offset: r - i.nodeSize };
  }
  /**
  Resolve the given position in the document, returning an
  [object](https://prosemirror.net/docs/ref/#model.ResolvedPos) with information about its context.
  */
  resolve(e) {
    return Oi.resolveCached(this, e);
  }
  /**
  @internal
  */
  resolveNoCache(e) {
    return Oi.resolve(this, e);
  }
  /**
  Test whether a given mark or mark type occurs in this document
  between the two given positions.
  */
  rangeHasMark(e, t, r) {
    let i = !1;
    return t > e && this.nodesBetween(e, t, (s) => (r.isInSet(s.marks) && (i = !0), !i)), i;
  }
  /**
  True when this is a block (non-inline node)
  */
  get isBlock() {
    return this.type.isBlock;
  }
  /**
  True when this is a textblock node, a block node with inline
  content.
  */
  get isTextblock() {
    return this.type.isTextblock;
  }
  /**
  True when this node allows inline content.
  */
  get inlineContent() {
    return this.type.inlineContent;
  }
  /**
  True when this is an inline node (a text node or a node that can
  appear among text).
  */
  get isInline() {
    return this.type.isInline;
  }
  /**
  True when this is a text node.
  */
  get isText() {
    return this.type.isText;
  }
  /**
  True when this is a leaf node.
  */
  get isLeaf() {
    return this.type.isLeaf;
  }
  /**
  True when this is an atom, i.e. when it does not have directly
  editable content. This is usually the same as `isLeaf`, but can
  be configured with the [`atom` property](https://prosemirror.net/docs/ref/#model.NodeSpec.atom)
  on a node's spec (typically used when the node is displayed as
  an uneditable [node view](https://prosemirror.net/docs/ref/#view.NodeView)).
  */
  get isAtom() {
    return this.type.isAtom;
  }
  /**
  Return a string representation of this node for debugging
  purposes.
  */
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let e = this.type.name;
    return this.content.size && (e += "(" + this.content.toStringInner() + ")"), Dh(this.marks, e);
  }
  /**
  Get the content match in this node at the given index.
  */
  contentMatchAt(e) {
    let t = this.type.contentMatch.matchFragment(this.content, 0, e);
    if (!t)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return t;
  }
  /**
  Test whether replacing the range between `from` and `to` (by
  child index) with the given replacement fragment (which defaults
  to the empty fragment) would leave the node's content valid. You
  can optionally pass `start` and `end` indices into the
  replacement fragment.
  */
  canReplace(e, t, r = F.empty, i = 0, s = r.childCount) {
    let o = this.contentMatchAt(e).matchFragment(r, i, s), l = o && o.matchFragment(this.content, t);
    if (!l || !l.validEnd)
      return !1;
    for (let a = i; a < s; a++)
      if (!this.type.allowsMarks(r.child(a).marks))
        return !1;
    return !0;
  }
  /**
  Test whether replacing the range `from` to `to` (by index) with
  a node of the given type would leave the node's content valid.
  */
  canReplaceWith(e, t, r, i) {
    if (i && !this.type.allowsMarks(i))
      return !1;
    let s = this.contentMatchAt(e).matchType(r), o = s && s.matchFragment(this.content, t);
    return o ? o.validEnd : !1;
  }
  /**
  Test whether the given node's content could be appended to this
  node. If that node is empty, this will only return true if there
  is at least one node type that can appear in both nodes (to avoid
  merging completely incompatible nodes).
  */
  canAppend(e) {
    return e.content.size ? this.canReplace(this.childCount, this.childCount, e.content) : this.type.compatibleContent(e.type);
  }
  /**
  Check whether this node and its descendants conform to the
  schema, and raise an exception when they do not.
  */
  check() {
    this.type.checkContent(this.content), this.type.checkAttrs(this.attrs);
    let e = be.none;
    for (let t = 0; t < this.marks.length; t++) {
      let r = this.marks[t];
      r.type.checkAttrs(r.attrs), e = r.addToSet(e);
    }
    if (!be.sameSet(e, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((t) => t.type.name)}`);
    this.content.forEach((t) => t.check());
  }
  /**
  Return a JSON-serializeable representation of this node.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return this.content.size && (e.content = this.content.toJSON()), this.marks.length && (e.marks = this.marks.map((t) => t.toJSON())), e;
  }
  /**
  Deserialize a node from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Node.fromJSON");
    let r;
    if (t.marks) {
      if (!Array.isArray(t.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      r = t.marks.map(e.markFromJSON);
    }
    if (t.type == "text") {
      if (typeof t.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return e.text(t.text, r);
    }
    let i = F.fromJSON(e, t.content), s = e.nodeType(t.type).create(t.attrs, i, r);
    return s.type.checkAttrs(s.attrs), s;
  }
}
_t.prototype.text = void 0;
class Vs extends _t {
  /**
  @internal
  */
  constructor(e, t, r, i) {
    if (super(e, t, null, i), !r)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = r;
  }
  toString() {
    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : Dh(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(e, t) {
    return this.text.slice(e, t);
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(e) {
    return e == this.marks ? this : new Vs(this.type, this.attrs, this.text, e);
  }
  withText(e) {
    return e == this.text ? this : new Vs(this.type, this.attrs, e, this.marks);
  }
  cut(e = 0, t = this.text.length) {
    return e == 0 && t == this.text.length ? this : this.withText(this.text.slice(e, t));
  }
  eq(e) {
    return this.sameMarkup(e) && this.text == e.text;
  }
  toJSON() {
    let e = super.toJSON();
    return e.text = this.text, e;
  }
}
function Dh(n, e) {
  for (let t = n.length - 1; t >= 0; t--)
    e = n[t].type.name + "(" + e + ")";
  return e;
}
class fr {
  /**
  @internal
  */
  constructor(e) {
    this.validEnd = e, this.next = [], this.wrapCache = [];
  }
  /**
  @internal
  */
  static parse(e, t) {
    let r = new b1(e, t);
    if (r.next == null)
      return fr.empty;
    let i = Ah(r);
    r.next && r.err("Unexpected trailing text");
    let s = D1(C1(i));
    return A1(s, r), s;
  }
  /**
  Match a node type, returning a match after that node if
  successful.
  */
  matchType(e) {
    for (let t = 0; t < this.next.length; t++)
      if (this.next[t].type == e)
        return this.next[t].next;
    return null;
  }
  /**
  Try to match a fragment. Returns the resulting match when
  successful.
  */
  matchFragment(e, t = 0, r = e.childCount) {
    let i = this;
    for (let s = t; i && s < r; s++)
      i = i.matchType(e.child(s).type);
    return i;
  }
  /**
  @internal
  */
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  /**
  Get the first matching node type at this match position that can
  be generated.
  */
  get defaultType() {
    for (let e = 0; e < this.next.length; e++) {
      let { type: t } = this.next[e];
      if (!(t.isText || t.hasRequiredAttrs()))
        return t;
    }
    return null;
  }
  /**
  @internal
  */
  compatible(e) {
    for (let t = 0; t < this.next.length; t++)
      for (let r = 0; r < e.next.length; r++)
        if (this.next[t].type == e.next[r].type)
          return !0;
    return !1;
  }
  /**
  Try to match the given fragment, and if that fails, see if it can
  be made to match by inserting nodes in front of it. When
  successful, return a fragment of inserted nodes (which may be
  empty if nothing had to be inserted). When `toEnd` is true, only
  return a fragment if the resulting match goes to the end of the
  content expression.
  */
  fillBefore(e, t = !1, r = 0) {
    let i = [this];
    function s(o, l) {
      let a = o.matchFragment(e, r);
      if (a && (!t || a.validEnd))
        return F.from(l.map((u) => u.createAndFill()));
      for (let u = 0; u < o.next.length; u++) {
        let { type: c, next: d } = o.next[u];
        if (!(c.isText || c.hasRequiredAttrs()) && i.indexOf(d) == -1) {
          i.push(d);
          let f = s(d, l.concat(c));
          if (f)
            return f;
        }
      }
      return null;
    }
    return s(this, []);
  }
  /**
  Find a set of wrapping node types that would allow a node of the
  given type to appear at this position. The result may be empty
  (when it fits directly) and will be null when no such wrapping
  exists.
  */
  findWrapping(e) {
    for (let r = 0; r < this.wrapCache.length; r += 2)
      if (this.wrapCache[r] == e)
        return this.wrapCache[r + 1];
    let t = this.computeWrapping(e);
    return this.wrapCache.push(e, t), t;
  }
  /**
  @internal
  */
  computeWrapping(e) {
    let t = /* @__PURE__ */ Object.create(null), r = [{ match: this, type: null, via: null }];
    for (; r.length; ) {
      let i = r.shift(), s = i.match;
      if (s.matchType(e)) {
        let o = [];
        for (let l = i; l.type; l = l.via)
          o.push(l.type);
        return o.reverse();
      }
      for (let o = 0; o < s.next.length; o++) {
        let { type: l, next: a } = s.next[o];
        !l.isLeaf && !l.hasRequiredAttrs() && !(l.name in t) && (!i.type || a.validEnd) && (r.push({ match: l.contentMatch, type: l, via: i }), t[l.name] = !0);
      }
    }
    return null;
  }
  /**
  The number of outgoing edges this node has in the finite
  automaton that describes the content expression.
  */
  get edgeCount() {
    return this.next.length;
  }
  /**
  Get the _n_​th outgoing edge from this node in the finite
  automaton that describes the content expression.
  */
  edge(e) {
    if (e >= this.next.length)
      throw new RangeError(`There's no ${e}th edge in this content match`);
    return this.next[e];
  }
  /**
  @internal
  */
  toString() {
    let e = [];
    function t(r) {
      e.push(r);
      for (let i = 0; i < r.next.length; i++)
        e.indexOf(r.next[i].next) == -1 && t(r.next[i].next);
    }
    return t(this), e.map((r, i) => {
      let s = i + (r.validEnd ? "*" : " ") + " ";
      for (let o = 0; o < r.next.length; o++)
        s += (o ? ", " : "") + r.next[o].type.name + "->" + e.indexOf(r.next[o].next);
      return s;
    }).join(`
`);
  }
}
fr.empty = new fr(!0);
class b1 {
  constructor(e, t) {
    this.string = e, this.nodeTypes = t, this.inline = null, this.pos = 0, this.tokens = e.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(e) {
    return this.next == e && (this.pos++ || !0);
  }
  err(e) {
    throw new SyntaxError(e + " (in content expression '" + this.string + "')");
  }
}
function Ah(n) {
  let e = [];
  do
    e.push(k1(n));
  while (n.eat("|"));
  return e.length == 1 ? e[0] : { type: "choice", exprs: e };
}
function k1(n) {
  let e = [];
  do
    e.push(v1(n));
  while (n.next && n.next != ")" && n.next != "|");
  return e.length == 1 ? e[0] : { type: "seq", exprs: e };
}
function v1(n) {
  let e = S1(n);
  for (; ; )
    if (n.eat("+"))
      e = { type: "plus", expr: e };
    else if (n.eat("*"))
      e = { type: "star", expr: e };
    else if (n.eat("?"))
      e = { type: "opt", expr: e };
    else if (n.eat("{"))
      e = w1(n, e);
    else
      break;
  return e;
}
function Uc(n) {
  /\D/.test(n.next) && n.err("Expected number, got '" + n.next + "'");
  let e = Number(n.next);
  return n.pos++, e;
}
function w1(n, e) {
  let t = Uc(n), r = t;
  return n.eat(",") && (n.next != "}" ? r = Uc(n) : r = -1), n.eat("}") || n.err("Unclosed braced range"), { type: "range", min: t, max: r, expr: e };
}
function E1(n, e) {
  let t = n.nodeTypes, r = t[e];
  if (r)
    return [r];
  let i = [];
  for (let s in t) {
    let o = t[s];
    o.isInGroup(e) && i.push(o);
  }
  return i.length == 0 && n.err("No node type or group '" + e + "' found"), i;
}
function S1(n) {
  if (n.eat("(")) {
    let e = Ah(n);
    return n.eat(")") || n.err("Missing closing paren"), e;
  } else if (/\W/.test(n.next))
    n.err("Unexpected token '" + n.next + "'");
  else {
    let e = E1(n, n.next).map((t) => (n.inline == null ? n.inline = t.isInline : n.inline != t.isInline && n.err("Mixing inline and block content"), { type: "name", value: t }));
    return n.pos++, e.length == 1 ? e[0] : { type: "choice", exprs: e };
  }
}
function C1(n) {
  let e = [[]];
  return i(s(n, 0), t()), e;
  function t() {
    return e.push([]) - 1;
  }
  function r(o, l, a) {
    let u = { term: a, to: l };
    return e[o].push(u), u;
  }
  function i(o, l) {
    o.forEach((a) => a.to = l);
  }
  function s(o, l) {
    if (o.type == "choice")
      return o.exprs.reduce((a, u) => a.concat(s(u, l)), []);
    if (o.type == "seq")
      for (let a = 0; ; a++) {
        let u = s(o.exprs[a], l);
        if (a == o.exprs.length - 1)
          return u;
        i(u, l = t());
      }
    else if (o.type == "star") {
      let a = t();
      return r(l, a), i(s(o.expr, a), a), [r(a)];
    } else if (o.type == "plus") {
      let a = t();
      return i(s(o.expr, l), a), i(s(o.expr, a), a), [r(a)];
    } else {
      if (o.type == "opt")
        return [r(l)].concat(s(o.expr, l));
      if (o.type == "range") {
        let a = l;
        for (let u = 0; u < o.min; u++) {
          let c = t();
          i(s(o.expr, a), c), a = c;
        }
        if (o.max == -1)
          i(s(o.expr, a), a);
        else
          for (let u = o.min; u < o.max; u++) {
            let c = t();
            r(a, c), i(s(o.expr, a), c), a = c;
          }
        return [r(a)];
      } else {
        if (o.type == "name")
          return [r(l, void 0, o.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function Th(n, e) {
  return e - n;
}
function Wc(n, e) {
  let t = [];
  return r(e), t.sort(Th);
  function r(i) {
    let s = n[i];
    if (s.length == 1 && !s[0].term)
      return r(s[0].to);
    t.push(i);
    for (let o = 0; o < s.length; o++) {
      let { term: l, to: a } = s[o];
      !l && t.indexOf(a) == -1 && r(a);
    }
  }
}
function D1(n) {
  let e = /* @__PURE__ */ Object.create(null);
  return t(Wc(n, 0));
  function t(r) {
    let i = [];
    r.forEach((o) => {
      n[o].forEach(({ term: l, to: a }) => {
        if (!l)
          return;
        let u;
        for (let c = 0; c < i.length; c++)
          i[c][0] == l && (u = i[c][1]);
        Wc(n, a).forEach((c) => {
          u || i.push([l, u = []]), u.indexOf(c) == -1 && u.push(c);
        });
      });
    });
    let s = e[r.join(",")] = new fr(r.indexOf(n.length - 1) > -1);
    for (let o = 0; o < i.length; o++) {
      let l = i[o][1].sort(Th);
      s.next.push({ type: i[o][0], next: e[l.join(",")] || t(l) });
    }
    return s;
  }
}
function A1(n, e) {
  for (let t = 0, r = [n]; t < r.length; t++) {
    let i = r[t], s = !i.validEnd, o = [];
    for (let l = 0; l < i.next.length; l++) {
      let { type: a, next: u } = i.next[l];
      o.push(a.name), s && !(a.isText || a.hasRequiredAttrs()) && (s = !1), r.indexOf(u) == -1 && r.push(u);
    }
    s && e.err("Only non-generatable nodes (" + o.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function xh(n) {
  let e = /* @__PURE__ */ Object.create(null);
  for (let t in n) {
    let r = n[t];
    if (!r.hasDefault)
      return null;
    e[t] = r.default;
  }
  return e;
}
function Mh(n, e) {
  let t = /* @__PURE__ */ Object.create(null);
  for (let r in n) {
    let i = e && e[r];
    if (i === void 0) {
      let s = n[r];
      if (s.hasDefault)
        i = s.default;
      else
        throw new RangeError("No value supplied for attribute " + r);
    }
    t[r] = i;
  }
  return t;
}
function $h(n, e, t, r) {
  for (let i in e)
    if (!(i in n))
      throw new RangeError(`Unsupported attribute ${i} for ${t} of type ${i}`);
  for (let i in n) {
    let s = n[i];
    s.validate && s.validate(e[i]);
  }
}
function Fh(n, e) {
  let t = /* @__PURE__ */ Object.create(null);
  if (e)
    for (let r in e)
      t[r] = new x1(n, r, e[r]);
  return t;
}
let Kc = class Oh {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.name = e, this.schema = t, this.spec = r, this.markSet = null, this.groups = r.group ? r.group.split(" ") : [], this.attrs = Fh(e, r.attrs), this.defaultAttrs = xh(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(r.inline || e == "text"), this.isText = e == "text";
  }
  /**
  True if this is an inline type.
  */
  get isInline() {
    return !this.isBlock;
  }
  /**
  True if this is a textblock type, a block that contains inline
  content.
  */
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  /**
  True for node types that allow no content.
  */
  get isLeaf() {
    return this.contentMatch == fr.empty;
  }
  /**
  True when this node is an atom, i.e. when it does not have
  directly editable content.
  */
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  /**
  Return true when this node type is part of the given
  [group](https://prosemirror.net/docs/ref/#model.NodeSpec.group).
  */
  isInGroup(e) {
    return this.groups.indexOf(e) > -1;
  }
  /**
  The node type's [whitespace](https://prosemirror.net/docs/ref/#model.NodeSpec.whitespace) option.
  */
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  /**
  Tells you whether this node type has any required attributes.
  */
  hasRequiredAttrs() {
    for (let e in this.attrs)
      if (this.attrs[e].isRequired)
        return !0;
    return !1;
  }
  /**
  Indicates whether this node allows some of the same content as
  the given node type.
  */
  compatibleContent(e) {
    return this == e || this.contentMatch.compatible(e.contentMatch);
  }
  /**
  @internal
  */
  computeAttrs(e) {
    return !e && this.defaultAttrs ? this.defaultAttrs : Mh(this.attrs, e);
  }
  /**
  Create a `Node` of this type. The given attributes are
  checked and defaulted (you can pass `null` to use the type's
  defaults entirely, if no required attributes exist). `content`
  may be a `Fragment`, a node, an array of nodes, or
  `null`. Similarly `marks` may be `null` to default to the empty
  set of marks.
  */
  create(e = null, t, r) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new _t(this, this.computeAttrs(e), F.from(t), be.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but check the given content
  against the node type's content restrictions, and throw an error
  if it doesn't match.
  */
  createChecked(e = null, t, r) {
    return t = F.from(t), this.checkContent(t), new _t(this, this.computeAttrs(e), t, be.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but see if it is
  necessary to add nodes to the start or end of the given fragment
  to make it fit the node. If no fitting wrapping can be found,
  return null. Note that, due to the fact that required nodes can
  always be created, this will always succeed if you pass null or
  `Fragment.empty` as content.
  */
  createAndFill(e = null, t, r) {
    if (e = this.computeAttrs(e), t = F.from(t), t.size) {
      let o = this.contentMatch.fillBefore(t);
      if (!o)
        return null;
      t = o.append(t);
    }
    let i = this.contentMatch.matchFragment(t), s = i && i.fillBefore(F.empty, !0);
    return s ? new _t(this, e, t.append(s), be.setFrom(r)) : null;
  }
  /**
  Returns true if the given fragment is valid content for this node
  type.
  */
  validContent(e) {
    let t = this.contentMatch.matchFragment(e);
    if (!t || !t.validEnd)
      return !1;
    for (let r = 0; r < e.childCount; r++)
      if (!this.allowsMarks(e.child(r).marks))
        return !1;
    return !0;
  }
  /**
  Throws a RangeError if the given fragment is not valid content for this
  node type.
  @internal
  */
  checkContent(e) {
    if (!this.validContent(e))
      throw new RangeError(`Invalid content for node ${this.name}: ${e.toString().slice(0, 50)}`);
  }
  /**
  @internal
  */
  checkAttrs(e) {
    $h(this.attrs, e, "node", this.name);
  }
  /**
  Check whether the given mark type is allowed in this node.
  */
  allowsMarkType(e) {
    return this.markSet == null || this.markSet.indexOf(e) > -1;
  }
  /**
  Test whether the given set of marks are allowed in this node.
  */
  allowsMarks(e) {
    if (this.markSet == null)
      return !0;
    for (let t = 0; t < e.length; t++)
      if (!this.allowsMarkType(e[t].type))
        return !1;
    return !0;
  }
  /**
  Removes the marks that are not allowed in this node from the given set.
  */
  allowedMarks(e) {
    if (this.markSet == null)
      return e;
    let t;
    for (let r = 0; r < e.length; r++)
      this.allowsMarkType(e[r].type) ? t && t.push(e[r]) : t || (t = e.slice(0, r));
    return t ? t.length ? t : be.none : e;
  }
  /**
  @internal
  */
  static compile(e, t) {
    let r = /* @__PURE__ */ Object.create(null);
    e.forEach((s, o) => r[s] = new Oh(s, t, o));
    let i = t.spec.topNode || "doc";
    if (!r[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!r.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let s in r.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return r;
  }
};
function T1(n, e, t) {
  let r = t.split("|");
  return (i) => {
    let s = i === null ? "null" : typeof i;
    if (r.indexOf(s) < 0)
      throw new RangeError(`Expected value of type ${r} for attribute ${e} on type ${n}, got ${s}`);
  };
}
class x1 {
  constructor(e, t, r) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(r, "default"), this.default = r.default, this.validate = typeof r.validate == "string" ? T1(e, t, r.validate) : r.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class Mo {
  /**
  @internal
  */
  constructor(e, t, r, i) {
    this.name = e, this.rank = t, this.schema = r, this.spec = i, this.attrs = Fh(e, i.attrs), this.excluded = null;
    let s = xh(this.attrs);
    this.instance = s ? new be(this, s) : null;
  }
  /**
  Create a mark of this type. `attrs` may be `null` or an object
  containing only some of the mark's attributes. The others, if
  they have defaults, will be added.
  */
  create(e = null) {
    return !e && this.instance ? this.instance : new be(this, Mh(this.attrs, e));
  }
  /**
  @internal
  */
  static compile(e, t) {
    let r = /* @__PURE__ */ Object.create(null), i = 0;
    return e.forEach((s, o) => r[s] = new Mo(s, i++, t, o)), r;
  }
  /**
  When there is a mark of this type in the given set, a new set
  without it is returned. Otherwise, the input set is returned.
  */
  removeFromSet(e) {
    for (var t = 0; t < e.length; t++)
      e[t].type == this && (e = e.slice(0, t).concat(e.slice(t + 1)), t--);
    return e;
  }
  /**
  Tests whether there is a mark of this type in the given set.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (e[t].type == this)
        return e[t];
  }
  /**
  @internal
  */
  checkAttrs(e) {
    $h(this.attrs, e, "mark", this.name);
  }
  /**
  Queries whether a given mark type is
  [excluded](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) by this one.
  */
  excludes(e) {
    return this.excluded.indexOf(e) > -1;
  }
}
class Nh {
  /**
  Construct a schema from a schema [specification](https://prosemirror.net/docs/ref/#model.SchemaSpec).
  */
  constructor(e) {
    this.linebreakReplacement = null, this.cached = /* @__PURE__ */ Object.create(null);
    let t = this.spec = {};
    for (let i in e)
      t[i] = e[i];
    t.nodes = je.from(e.nodes), t.marks = je.from(e.marks || {}), this.nodes = Kc.compile(this.spec.nodes, this), this.marks = Mo.compile(this.spec.marks, this);
    let r = /* @__PURE__ */ Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let s = this.nodes[i], o = s.spec.content || "", l = s.spec.marks;
      if (s.contentMatch = r[o] || (r[o] = fr.parse(o, this.nodes)), s.inlineContent = s.contentMatch.inlineContent, s.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!s.isInline || !s.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = s;
      }
      s.markSet = l == "_" ? null : l ? Gc(this, l.split(" ")) : l == "" || !s.inlineContent ? [] : null;
    }
    for (let i in this.marks) {
      let s = this.marks[i], o = s.spec.excludes;
      s.excluded = o == null ? [s] : o == "" ? [] : Gc(this, o.split(" "));
    }
    this.nodeFromJSON = (i) => _t.fromJSON(this, i), this.markFromJSON = (i) => be.fromJSON(this, i), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = /* @__PURE__ */ Object.create(null);
  }
  /**
  Create a node in this schema. The `type` may be a string or a
  `NodeType` instance. Attributes will be extended with defaults,
  `content` may be a `Fragment`, `null`, a `Node`, or an array of
  nodes.
  */
  node(e, t = null, r, i) {
    if (typeof e == "string")
      e = this.nodeType(e);
    else if (e instanceof Kc) {
      if (e.schema != this)
        throw new RangeError("Node type from different schema used (" + e.name + ")");
    } else throw new RangeError("Invalid node type: " + e);
    return e.createChecked(t, r, i);
  }
  /**
  Create a text node in the schema. Empty text nodes are not
  allowed.
  */
  text(e, t) {
    let r = this.nodes.text;
    return new Vs(r, r.defaultAttrs, e, be.setFrom(t));
  }
  /**
  Create a mark with the given type and attributes.
  */
  mark(e, t) {
    return typeof e == "string" && (e = this.marks[e]), e.create(t);
  }
  /**
  @internal
  */
  nodeType(e) {
    let t = this.nodes[e];
    if (!t)
      throw new RangeError("Unknown node type: " + e);
    return t;
  }
}
function Gc(n, e) {
  let t = [];
  for (let r = 0; r < e.length; r++) {
    let i = e[r], s = n.marks[i], o = s;
    if (s)
      t.push(s);
    else
      for (let l in n.marks) {
        let a = n.marks[l];
        (i == "_" || a.spec.group && a.spec.group.split(" ").indexOf(i) > -1) && t.push(o = a);
      }
    if (!o)
      throw new SyntaxError("Unknown mark type: '" + e[r] + "'");
  }
  return t;
}
function M1(n) {
  return n.tag != null;
}
function $1(n) {
  return n.style != null;
}
let vi = class Xl {
  /**
  Create a parser that targets the given schema, using the given
  parsing rules.
  */
  constructor(e, t) {
    this.schema = e, this.rules = t, this.tags = [], this.styles = [];
    let r = this.matchedStyles = [];
    t.forEach((i) => {
      if (M1(i))
        this.tags.push(i);
      else if ($1(i)) {
        let s = /[^=]*/.exec(i.style)[0];
        r.indexOf(s) < 0 && r.push(s), this.styles.push(i);
      }
    }), this.normalizeLists = !this.tags.some((i) => {
      if (!/^(ul|ol)\b/.test(i.tag) || !i.node)
        return !1;
      let s = e.nodes[i.node];
      return s.contentMatch.matchType(s);
    });
  }
  /**
  Parse a document from the content of a DOM node.
  */
  parse(e, t = {}) {
    let r = new Yc(this, t, !1);
    return r.addAll(e, be.none, t.from, t.to), r.finish();
  }
  /**
  Parses the content of the given DOM node, like
  [`parse`](https://prosemirror.net/docs/ref/#model.DOMParser.parse), and takes the same set of
  options. But unlike that method, which produces a whole node,
  this one returns a slice that is open at the sides, meaning that
  the schema constraints aren't applied to the start of nodes to
  the left of the input and the end of nodes at the end.
  */
  parseSlice(e, t = {}) {
    let r = new Yc(this, t, !0);
    return r.addAll(e, be.none, t.from, t.to), z.maxOpen(r.finish());
  }
  /**
  @internal
  */
  matchTag(e, t, r) {
    for (let i = r ? this.tags.indexOf(r) + 1 : 0; i < this.tags.length; i++) {
      let s = this.tags[i];
      if (N1(e, s.tag) && (s.namespace === void 0 || e.namespaceURI == s.namespace) && (!s.context || t.matchesContext(s.context))) {
        if (s.getAttrs) {
          let o = s.getAttrs(e);
          if (o === !1)
            continue;
          s.attrs = o || void 0;
        }
        return s;
      }
    }
  }
  /**
  @internal
  */
  matchStyle(e, t, r, i) {
    for (let s = i ? this.styles.indexOf(i) + 1 : 0; s < this.styles.length; s++) {
      let o = this.styles[s], l = o.style;
      if (!(l.indexOf(e) != 0 || o.context && !r.matchesContext(o.context) || // Test that the style string either precisely matches the prop,
      // or has an '=' sign after the prop, followed by the given
      // value.
      l.length > e.length && (l.charCodeAt(e.length) != 61 || l.slice(e.length + 1) != t))) {
        if (o.getAttrs) {
          let a = o.getAttrs(t);
          if (a === !1)
            continue;
          o.attrs = a || void 0;
        }
        return o;
      }
    }
  }
  /**
  @internal
  */
  static schemaRules(e) {
    let t = [];
    function r(i) {
      let s = i.priority == null ? 50 : i.priority, o = 0;
      for (; o < t.length; o++) {
        let l = t[o];
        if ((l.priority == null ? 50 : l.priority) < s)
          break;
      }
      t.splice(o, 0, i);
    }
    for (let i in e.marks) {
      let s = e.marks[i].spec.parseDOM;
      s && s.forEach((o) => {
        r(o = Xc(o)), o.mark || o.ignore || o.clearMark || (o.mark = i);
      });
    }
    for (let i in e.nodes) {
      let s = e.nodes[i].spec.parseDOM;
      s && s.forEach((o) => {
        r(o = Xc(o)), o.node || o.ignore || o.mark || (o.node = i);
      });
    }
    return t;
  }
  /**
  Construct a DOM parser using the parsing rules listed in a
  schema's [node specs](https://prosemirror.net/docs/ref/#model.NodeSpec.parseDOM), reordered by
  [priority](https://prosemirror.net/docs/ref/#model.GenericParseRule.priority).
  */
  static fromSchema(e) {
    return e.cached.domParser || (e.cached.domParser = new Xl(e, Xl.schemaRules(e)));
  }
};
const Rh = {
  address: !0,
  article: !0,
  aside: !0,
  blockquote: !0,
  canvas: !0,
  dd: !0,
  div: !0,
  dl: !0,
  fieldset: !0,
  figcaption: !0,
  figure: !0,
  footer: !0,
  form: !0,
  h1: !0,
  h2: !0,
  h3: !0,
  h4: !0,
  h5: !0,
  h6: !0,
  header: !0,
  hgroup: !0,
  hr: !0,
  li: !0,
  noscript: !0,
  ol: !0,
  output: !0,
  p: !0,
  pre: !0,
  section: !0,
  table: !0,
  tfoot: !0,
  ul: !0
}, F1 = {
  head: !0,
  noscript: !0,
  object: !0,
  script: !0,
  style: !0,
  title: !0
}, Ih = { ol: !0, ul: !0 }, Ni = 1, Zl = 2, wi = 4;
function Jc(n, e, t) {
  return e != null ? (e ? Ni : 0) | (e === "full" ? Zl : 0) : n && n.whitespace == "pre" ? Ni | Zl : t & ~wi;
}
class ms {
  constructor(e, t, r, i, s, o) {
    this.type = e, this.attrs = t, this.marks = r, this.solid = i, this.options = o, this.content = [], this.activeMarks = be.none, this.match = s || (o & wi ? null : e.contentMatch);
  }
  findWrapping(e) {
    if (!this.match) {
      if (!this.type)
        return [];
      let t = this.type.contentMatch.fillBefore(F.from(e));
      if (t)
        this.match = this.type.contentMatch.matchFragment(t);
      else {
        let r = this.type.contentMatch, i;
        return (i = r.findWrapping(e.type)) ? (this.match = r, i) : null;
      }
    }
    return this.match.findWrapping(e.type);
  }
  finish(e) {
    if (!(this.options & Ni)) {
      let r = this.content[this.content.length - 1], i;
      if (r && r.isText && (i = /[ \t\r\n\u000c]+$/.exec(r.text))) {
        let s = r;
        r.text.length == i[0].length ? this.content.pop() : this.content[this.content.length - 1] = s.withText(s.text.slice(0, s.text.length - i[0].length));
      }
    }
    let t = F.from(this.content);
    return !e && this.match && (t = t.append(this.match.fillBefore(F.empty, !0))), this.type ? this.type.create(this.attrs, t, this.marks) : t;
  }
  inlineContext(e) {
    return this.type ? this.type.inlineContent : this.content.length ? this.content[0].isInline : e.parentNode && !Rh.hasOwnProperty(e.parentNode.nodeName.toLowerCase());
  }
}
class Yc {
  constructor(e, t, r) {
    this.parser = e, this.options = t, this.isOpen = r, this.open = 0, this.localPreserveWS = !1;
    let i = t.topNode, s, o = Jc(null, t.preserveWhitespace, 0) | (r ? wi : 0);
    i ? s = new ms(i.type, i.attrs, be.none, !0, t.topMatch || i.type.contentMatch, o) : r ? s = new ms(null, null, be.none, !0, null, o) : s = new ms(e.schema.topNodeType, null, be.none, !0, null, o), this.nodes = [s], this.find = t.findPositions, this.needsBlock = !1;
  }
  get top() {
    return this.nodes[this.open];
  }
  // Add a DOM node to the content. Text is inserted as text node,
  // otherwise, the node is passed to `addElement` or, if it has a
  // `style` attribute, `addElementWithStyles`.
  addDOM(e, t) {
    e.nodeType == 3 ? this.addTextNode(e, t) : e.nodeType == 1 && this.addElement(e, t);
  }
  addTextNode(e, t) {
    let r = e.nodeValue, i = this.top, s = i.options & Zl ? "full" : this.localPreserveWS || (i.options & Ni) > 0;
    if (s === "full" || i.inlineContext(e) || /[^ \t\r\n\u000c]/.test(r)) {
      if (s)
        s !== "full" ? r = r.replace(/\r?\n|\r/g, " ") : r = r.replace(/\r\n?/g, `
`);
      else if (r = r.replace(/[ \t\r\n\u000c]+/g, " "), /^[ \t\r\n\u000c]/.test(r) && this.open == this.nodes.length - 1) {
        let o = i.content[i.content.length - 1], l = e.previousSibling;
        (!o || l && l.nodeName == "BR" || o.isText && /[ \t\r\n\u000c]$/.test(o.text)) && (r = r.slice(1));
      }
      r && this.insertNode(this.parser.schema.text(r), t, !/\S/.test(r)), this.findInText(e);
    } else
      this.findInside(e);
  }
  // Try to find a handler for the given tag and use that to parse. If
  // none is found, the element's content nodes are added directly.
  addElement(e, t, r) {
    let i = this.localPreserveWS, s = this.top;
    (e.tagName == "PRE" || /pre/.test(e.style && e.style.whiteSpace)) && (this.localPreserveWS = !0);
    let o = e.nodeName.toLowerCase(), l;
    Ih.hasOwnProperty(o) && this.parser.normalizeLists && O1(e);
    let a = this.options.ruleFromNode && this.options.ruleFromNode(e) || (l = this.parser.matchTag(e, this, r));
    e: if (a ? a.ignore : F1.hasOwnProperty(o))
      this.findInside(e), this.ignoreFallback(e, t);
    else if (!a || a.skip || a.closeParent) {
      a && a.closeParent ? this.open = Math.max(0, this.open - 1) : a && a.skip.nodeType && (e = a.skip);
      let u, c = this.needsBlock;
      if (Rh.hasOwnProperty(o))
        s.content.length && s.content[0].isInline && this.open && (this.open--, s = this.top), u = !0, s.type || (this.needsBlock = !0);
      else if (!e.firstChild) {
        this.leafFallback(e, t);
        break e;
      }
      let d = a && a.skip ? t : this.readStyles(e, t);
      d && this.addAll(e, d), u && this.sync(s), this.needsBlock = c;
    } else {
      let u = this.readStyles(e, t);
      u && this.addElementByRule(e, a, u, a.consuming === !1 ? l : void 0);
    }
    this.localPreserveWS = i;
  }
  // Called for leaf DOM nodes that would otherwise be ignored
  leafFallback(e, t) {
    e.nodeName == "BR" && this.top.type && this.top.type.inlineContent && this.addTextNode(e.ownerDocument.createTextNode(`
`), t);
  }
  // Called for ignored nodes
  ignoreFallback(e, t) {
    e.nodeName == "BR" && (!this.top.type || !this.top.type.inlineContent) && this.findPlace(this.parser.schema.text("-"), t, !0);
  }
  // Run any style parser associated with the node's styles. Either
  // return an updated array of marks, or null to indicate some of the
  // styles had a rule with `ignore` set.
  readStyles(e, t) {
    let r = e.style;
    if (r && r.length)
      for (let i = 0; i < this.parser.matchedStyles.length; i++) {
        let s = this.parser.matchedStyles[i], o = r.getPropertyValue(s);
        if (o)
          for (let l = void 0; ; ) {
            let a = this.parser.matchStyle(s, o, this, l);
            if (!a)
              break;
            if (a.ignore)
              return null;
            if (a.clearMark ? t = t.filter((u) => !a.clearMark(u)) : t = t.concat(this.parser.schema.marks[a.mark].create(a.attrs)), a.consuming === !1)
              l = a;
            else
              break;
          }
      }
    return t;
  }
  // Look up a handler for the given node. If none are found, return
  // false. Otherwise, apply it, use its return value to drive the way
  // the node's content is wrapped, and return true.
  addElementByRule(e, t, r, i) {
    let s, o;
    if (t.node)
      if (o = this.parser.schema.nodes[t.node], o.isLeaf)
        this.insertNode(o.create(t.attrs), r, e.nodeName == "BR") || this.leafFallback(e, r);
      else {
        let a = this.enter(o, t.attrs || null, r, t.preserveWhitespace);
        a && (s = !0, r = a);
      }
    else {
      let a = this.parser.schema.marks[t.mark];
      r = r.concat(a.create(t.attrs));
    }
    let l = this.top;
    if (o && o.isLeaf)
      this.findInside(e);
    else if (i)
      this.addElement(e, r, i);
    else if (t.getContent)
      this.findInside(e), t.getContent(e, this.parser.schema).forEach((a) => this.insertNode(a, r, !1));
    else {
      let a = e;
      typeof t.contentElement == "string" ? a = e.querySelector(t.contentElement) : typeof t.contentElement == "function" ? a = t.contentElement(e) : t.contentElement && (a = t.contentElement), this.findAround(e, a, !0), this.addAll(a, r), this.findAround(e, a, !1);
    }
    s && this.sync(l) && this.open--;
  }
  // Add all child nodes between `startIndex` and `endIndex` (or the
  // whole node, if not given). If `sync` is passed, use it to
  // synchronize after every block element.
  addAll(e, t, r, i) {
    let s = r || 0;
    for (let o = r ? e.childNodes[r] : e.firstChild, l = i == null ? null : e.childNodes[i]; o != l; o = o.nextSibling, ++s)
      this.findAtPoint(e, s), this.addDOM(o, t);
    this.findAtPoint(e, s);
  }
  // Try to find a way to fit the given node type into the current
  // context. May add intermediate wrappers and/or leave non-solid
  // nodes that we're in.
  findPlace(e, t, r) {
    let i, s;
    for (let o = this.open, l = 0; o >= 0; o--) {
      let a = this.nodes[o], u = a.findWrapping(e);
      if (u && (!i || i.length > u.length + l) && (i = u, s = a, !u.length))
        break;
      if (a.solid) {
        if (r)
          break;
        l += 2;
      }
    }
    if (!i)
      return null;
    this.sync(s);
    for (let o = 0; o < i.length; o++)
      t = this.enterInner(i[o], null, t, !1);
    return t;
  }
  // Try to insert the given node, adjusting the context when needed.
  insertNode(e, t, r) {
    if (e.isInline && this.needsBlock && !this.top.type) {
      let s = this.textblockFromContext();
      s && (t = this.enterInner(s, null, t));
    }
    let i = this.findPlace(e, t, r);
    if (i) {
      this.closeExtra();
      let s = this.top;
      s.match && (s.match = s.match.matchType(e.type));
      let o = be.none;
      for (let l of i.concat(e.marks))
        (s.type ? s.type.allowsMarkType(l.type) : Zc(l.type, e.type)) && (o = l.addToSet(o));
      return s.content.push(e.mark(o)), !0;
    }
    return !1;
  }
  // Try to start a node of the given type, adjusting the context when
  // necessary.
  enter(e, t, r, i) {
    let s = this.findPlace(e.create(t), r, !1);
    return s && (s = this.enterInner(e, t, r, !0, i)), s;
  }
  // Open a node of the given type
  enterInner(e, t, r, i = !1, s) {
    this.closeExtra();
    let o = this.top;
    o.match = o.match && o.match.matchType(e);
    let l = Jc(e, s, o.options);
    o.options & wi && o.content.length == 0 && (l |= wi);
    let a = be.none;
    return r = r.filter((u) => (o.type ? o.type.allowsMarkType(u.type) : Zc(u.type, e)) ? (a = u.addToSet(a), !1) : !0), this.nodes.push(new ms(e, t, a, i, null, l)), this.open++, r;
  }
  // Make sure all nodes above this.open are finished and added to
  // their parents
  closeExtra(e = !1) {
    let t = this.nodes.length - 1;
    if (t > this.open) {
      for (; t > this.open; t--)
        this.nodes[t - 1].content.push(this.nodes[t].finish(e));
      this.nodes.length = this.open + 1;
    }
  }
  finish() {
    return this.open = 0, this.closeExtra(this.isOpen), this.nodes[0].finish(!!(this.isOpen || this.options.topOpen));
  }
  sync(e) {
    for (let t = this.open; t >= 0; t--) {
      if (this.nodes[t] == e)
        return this.open = t, !0;
      this.localPreserveWS && (this.nodes[t].options |= Ni);
    }
    return !1;
  }
  get currentPos() {
    this.closeExtra();
    let e = 0;
    for (let t = this.open; t >= 0; t--) {
      let r = this.nodes[t].content;
      for (let i = r.length - 1; i >= 0; i--)
        e += r[i].nodeSize;
      t && e++;
    }
    return e;
  }
  findAtPoint(e, t) {
    if (this.find)
      for (let r = 0; r < this.find.length; r++)
        this.find[r].node == e && this.find[r].offset == t && (this.find[r].pos = this.currentPos);
  }
  findInside(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].pos == null && e.nodeType == 1 && e.contains(this.find[t].node) && (this.find[t].pos = this.currentPos);
  }
  findAround(e, t, r) {
    if (e != t && this.find)
      for (let i = 0; i < this.find.length; i++)
        this.find[i].pos == null && e.nodeType == 1 && e.contains(this.find[i].node) && t.compareDocumentPosition(this.find[i].node) & (r ? 2 : 4) && (this.find[i].pos = this.currentPos);
  }
  findInText(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].node == e && (this.find[t].pos = this.currentPos - (e.nodeValue.length - this.find[t].offset));
  }
  // Determines whether the given context string matches this context.
  matchesContext(e) {
    if (e.indexOf("|") > -1)
      return e.split(/\s*\|\s*/).some(this.matchesContext, this);
    let t = e.split("/"), r = this.options.context, i = !this.isOpen && (!r || r.parent.type == this.nodes[0].type), s = -(r ? r.depth + 1 : 0) + (i ? 0 : 1), o = (l, a) => {
      for (; l >= 0; l--) {
        let u = t[l];
        if (u == "") {
          if (l == t.length - 1 || l == 0)
            continue;
          for (; a >= s; a--)
            if (o(l - 1, a))
              return !0;
          return !1;
        } else {
          let c = a > 0 || a == 0 && i ? this.nodes[a].type : r && a >= s ? r.node(a - s).type : null;
          if (!c || c.name != u && !c.isInGroup(u))
            return !1;
          a--;
        }
      }
      return !0;
    };
    return o(t.length - 1, this.open);
  }
  textblockFromContext() {
    let e = this.options.context;
    if (e)
      for (let t = e.depth; t >= 0; t--) {
        let r = e.node(t).contentMatchAt(e.indexAfter(t)).defaultType;
        if (r && r.isTextblock && r.defaultAttrs)
          return r;
      }
    for (let t in this.parser.schema.nodes) {
      let r = this.parser.schema.nodes[t];
      if (r.isTextblock && r.defaultAttrs)
        return r;
    }
  }
}
function O1(n) {
  for (let e = n.firstChild, t = null; e; e = e.nextSibling) {
    let r = e.nodeType == 1 ? e.nodeName.toLowerCase() : null;
    r && Ih.hasOwnProperty(r) && t ? (t.appendChild(e), e = t) : r == "li" ? t = e : r && (t = null);
  }
}
function N1(n, e) {
  return (n.matches || n.msMatchesSelector || n.webkitMatchesSelector || n.mozMatchesSelector).call(n, e);
}
function Xc(n) {
  let e = {};
  for (let t in n)
    e[t] = n[t];
  return e;
}
function Zc(n, e) {
  let t = e.schema.nodes;
  for (let r in t) {
    let i = t[r];
    if (!i.allowsMarkType(n))
      continue;
    let s = [], o = (l) => {
      s.push(l);
      for (let a = 0; a < l.edgeCount; a++) {
        let { type: u, next: c } = l.edge(a);
        if (u == e || s.indexOf(c) < 0 && o(c))
          return !0;
      }
    };
    if (o(i.contentMatch))
      return !0;
  }
}
class br {
  /**
  Create a serializer. `nodes` should map node names to functions
  that take a node and return a description of the corresponding
  DOM. `marks` does the same for mark names, but also gets an
  argument that tells it whether the mark's content is block or
  inline content (for typical use, it'll always be inline). A mark
  serializer may be `null` to indicate that marks of that type
  should not be serialized.
  */
  constructor(e, t) {
    this.nodes = e, this.marks = t;
  }
  /**
  Serialize the content of this fragment to a DOM fragment. When
  not in the browser, the `document` option, containing a DOM
  document, should be passed so that the serializer can create
  nodes.
  */
  serializeFragment(e, t = {}, r) {
    r || (r = cl(t).createDocumentFragment());
    let i = r, s = [];
    return e.forEach((o) => {
      if (s.length || o.marks.length) {
        let l = 0, a = 0;
        for (; l < s.length && a < o.marks.length; ) {
          let u = o.marks[a];
          if (!this.marks[u.type.name]) {
            a++;
            continue;
          }
          if (!u.eq(s[l][0]) || u.type.spec.spanning === !1)
            break;
          l++, a++;
        }
        for (; l < s.length; )
          i = s.pop()[1];
        for (; a < o.marks.length; ) {
          let u = o.marks[a++], c = this.serializeMark(u, o.isInline, t);
          c && (s.push([u, i]), i.appendChild(c.dom), i = c.contentDOM || c.dom);
        }
      }
      i.appendChild(this.serializeNodeInner(o, t));
    }), r;
  }
  /**
  @internal
  */
  serializeNodeInner(e, t) {
    let { dom: r, contentDOM: i } = $s(cl(t), this.nodes[e.type.name](e), null, e.attrs);
    if (i) {
      if (e.isLeaf)
        throw new RangeError("Content hole not allowed in a leaf node spec");
      this.serializeFragment(e.content, t, i);
    }
    return r;
  }
  /**
  Serialize this node to a DOM node. This can be useful when you
  need to serialize a part of a document, as opposed to the whole
  document. To serialize a whole document, use
  [`serializeFragment`](https://prosemirror.net/docs/ref/#model.DOMSerializer.serializeFragment) on
  its [content](https://prosemirror.net/docs/ref/#model.Node.content).
  */
  serializeNode(e, t = {}) {
    let r = this.serializeNodeInner(e, t);
    for (let i = e.marks.length - 1; i >= 0; i--) {
      let s = this.serializeMark(e.marks[i], e.isInline, t);
      s && ((s.contentDOM || s.dom).appendChild(r), r = s.dom);
    }
    return r;
  }
  /**
  @internal
  */
  serializeMark(e, t, r = {}) {
    let i = this.marks[e.type.name];
    return i && $s(cl(r), i(e, t), null, e.attrs);
  }
  static renderSpec(e, t, r = null, i) {
    return $s(e, t, r, i);
  }
  /**
  Build a serializer using the [`toDOM`](https://prosemirror.net/docs/ref/#model.NodeSpec.toDOM)
  properties in a schema's node and mark specs.
  */
  static fromSchema(e) {
    return e.cached.domSerializer || (e.cached.domSerializer = new br(this.nodesFromSchema(e), this.marksFromSchema(e)));
  }
  /**
  Gather the serializers in a schema's node specs into an object.
  This can be useful as a base to build a custom serializer from.
  */
  static nodesFromSchema(e) {
    let t = Qc(e.nodes);
    return t.text || (t.text = (r) => r.text), t;
  }
  /**
  Gather the serializers in a schema's mark specs into an object.
  */
  static marksFromSchema(e) {
    return Qc(e.marks);
  }
}
function Qc(n) {
  let e = {};
  for (let t in n) {
    let r = n[t].spec.toDOM;
    r && (e[t] = r);
  }
  return e;
}
function cl(n) {
  return n.document || window.document;
}
const ed = /* @__PURE__ */ new WeakMap();
function R1(n) {
  let e = ed.get(n);
  return e === void 0 && ed.set(n, e = I1(n)), e;
}
function I1(n) {
  let e = null;
  function t(r) {
    if (r && typeof r == "object")
      if (Array.isArray(r))
        if (typeof r[0] == "string")
          e || (e = []), e.push(r);
        else
          for (let i = 0; i < r.length; i++)
            t(r[i]);
      else
        for (let i in r)
          t(r[i]);
  }
  return t(n), e;
}
function $s(n, e, t, r) {
  if (typeof e == "string")
    return { dom: n.createTextNode(e) };
  if (e.nodeType != null)
    return { dom: e };
  if (e.dom && e.dom.nodeType != null)
    return e;
  let i = e[0], s;
  if (typeof i != "string")
    throw new RangeError("Invalid array passed to renderSpec");
  if (r && (s = R1(r)) && s.indexOf(e) > -1)
    throw new RangeError("Using an array from an attribute object as a DOM spec. This may be an attempted cross site scripting attack.");
  let o = i.indexOf(" ");
  o > 0 && (t = i.slice(0, o), i = i.slice(o + 1));
  let l, a = t ? n.createElementNS(t, i) : n.createElement(i), u = e[1], c = 1;
  if (u && typeof u == "object" && u.nodeType == null && !Array.isArray(u)) {
    c = 2;
    for (let d in u)
      if (u[d] != null) {
        let f = d.indexOf(" ");
        f > 0 ? a.setAttributeNS(d.slice(0, f), d.slice(f + 1), u[d]) : d == "style" && a.style ? a.style.cssText = u[d] : a.setAttribute(d, u[d]);
      }
  }
  for (let d = c; d < e.length; d++) {
    let f = e[d];
    if (f === 0) {
      if (d < e.length - 1 || d > c)
        throw new RangeError("Content hole must be the only child of its parent node");
      return { dom: a, contentDOM: a };
    } else {
      let { dom: h, contentDOM: p } = $s(n, f, t, r);
      if (a.appendChild(h), p) {
        if (l)
          throw new RangeError("Multiple content holes");
        l = p;
      }
    }
  }
  return { dom: a, contentDOM: l };
}
const Lh = 65535, Ph = Math.pow(2, 16);
function L1(n, e) {
  return n + e * Ph;
}
function td(n) {
  return n & Lh;
}
function P1(n) {
  return (n - (n & Lh)) / Ph;
}
const Bh = 1, zh = 2, Fs = 4, Hh = 8;
class Ql {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.pos = e, this.delInfo = t, this.recover = r;
  }
  /**
  Tells you whether the position was deleted, that is, whether the
  step removed the token on the side queried (via the `assoc`)
  argument from the document.
  */
  get deleted() {
    return (this.delInfo & Hh) > 0;
  }
  /**
  Tells you whether the token before the mapped position was deleted.
  */
  get deletedBefore() {
    return (this.delInfo & (Bh | Fs)) > 0;
  }
  /**
  True when the token after the mapped position was deleted.
  */
  get deletedAfter() {
    return (this.delInfo & (zh | Fs)) > 0;
  }
  /**
  Tells whether any of the steps mapped through deletes across the
  position (including both the token before and after the
  position).
  */
  get deletedAcross() {
    return (this.delInfo & Fs) > 0;
  }
}
class gt {
  /**
  Create a position map. The modifications to the document are
  represented as an array of numbers, in which each group of three
  represents a modified chunk as `[start, oldSize, newSize]`.
  */
  constructor(e, t = !1) {
    if (this.ranges = e, this.inverted = t, !e.length && gt.empty)
      return gt.empty;
  }
  /**
  @internal
  */
  recover(e) {
    let t = 0, r = td(e);
    if (!this.inverted)
      for (let i = 0; i < r; i++)
        t += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[r * 3] + t + P1(e);
  }
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  map(e, t = 1) {
    return this._map(e, t, !0);
  }
  /**
  @internal
  */
  _map(e, t, r) {
    let i = 0, s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? i : 0);
      if (a > e)
        break;
      let u = this.ranges[l + s], c = this.ranges[l + o], d = a + u;
      if (e <= d) {
        let f = u ? e == a ? -1 : e == d ? 1 : t : t, h = a + i + (f < 0 ? 0 : c);
        if (r)
          return h;
        let p = e == (t < 0 ? a : d) ? null : L1(l / 3, e - a), g = e == a ? zh : e == d ? Bh : Fs;
        return (t < 0 ? e != a : e != d) && (g |= Hh), new Ql(h, g, p);
      }
      i += c - u;
    }
    return r ? e + i : new Ql(e + i, 0, null);
  }
  /**
  @internal
  */
  touches(e, t) {
    let r = 0, i = td(t), s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? r : 0);
      if (a > e)
        break;
      let u = this.ranges[l + s], c = a + u;
      if (e <= c && l == i * 3)
        return !0;
      r += this.ranges[l + o] - u;
    }
    return !1;
  }
  /**
  Calls the given function on each of the changed ranges included in
  this map.
  */
  forEach(e) {
    let t = this.inverted ? 2 : 1, r = this.inverted ? 1 : 2;
    for (let i = 0, s = 0; i < this.ranges.length; i += 3) {
      let o = this.ranges[i], l = o - (this.inverted ? s : 0), a = o + (this.inverted ? 0 : s), u = this.ranges[i + t], c = this.ranges[i + r];
      e(l, l + u, a, a + c), s += c - u;
    }
  }
  /**
  Create an inverted version of this map. The result can be used to
  map positions in the post-step document to the pre-step document.
  */
  invert() {
    return new gt(this.ranges, !this.inverted);
  }
  /**
  @internal
  */
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  /**
  Create a map that moves all positions by offset `n` (which may be
  negative). This can be useful when applying steps meant for a
  sub-document to a larger document, or vice-versa.
  */
  static offset(e) {
    return e == 0 ? gt.empty : new gt(e < 0 ? [0, -e, 0] : [0, 0, e]);
  }
}
gt.empty = new gt([]);
class Ri {
  /**
  Create a new mapping with the given position maps.
  */
  constructor(e, t, r = 0, i = e ? e.length : 0) {
    this.mirror = t, this.from = r, this.to = i, this._maps = e || [], this.ownData = !(e || t);
  }
  /**
  The step maps in this mapping.
  */
  get maps() {
    return this._maps;
  }
  /**
  Create a mapping that maps only through a part of this one.
  */
  slice(e = 0, t = this.maps.length) {
    return new Ri(this._maps, this.mirror, e, t);
  }
  /**
  Add a step map to the end of this mapping. If `mirrors` is
  given, it should be the index of the step map that is the mirror
  image of this one.
  */
  appendMap(e, t) {
    this.ownData || (this._maps = this._maps.slice(), this.mirror = this.mirror && this.mirror.slice(), this.ownData = !0), this.to = this._maps.push(e), t != null && this.setMirror(this._maps.length - 1, t);
  }
  /**
  Add all the step maps in a given mapping to this one (preserving
  mirroring information).
  */
  appendMapping(e) {
    for (let t = 0, r = this._maps.length; t < e._maps.length; t++) {
      let i = e.getMirror(t);
      this.appendMap(e._maps[t], i != null && i < t ? r + i : void 0);
    }
  }
  /**
  Finds the offset of the step map that mirrors the map at the
  given offset, in this mapping (as per the second argument to
  `appendMap`).
  */
  getMirror(e) {
    if (this.mirror) {
      for (let t = 0; t < this.mirror.length; t++)
        if (this.mirror[t] == e)
          return this.mirror[t + (t % 2 ? -1 : 1)];
    }
  }
  /**
  @internal
  */
  setMirror(e, t) {
    this.mirror || (this.mirror = []), this.mirror.push(e, t);
  }
  /**
  Append the inverse of the given mapping to this one.
  */
  appendMappingInverted(e) {
    for (let t = e.maps.length - 1, r = this._maps.length + e._maps.length; t >= 0; t--) {
      let i = e.getMirror(t);
      this.appendMap(e._maps[t].invert(), i != null && i > t ? r - i - 1 : void 0);
    }
  }
  /**
  Create an inverted version of this mapping.
  */
  invert() {
    let e = new Ri();
    return e.appendMappingInverted(this), e;
  }
  /**
  Map a position through this mapping.
  */
  map(e, t = 1) {
    if (this.mirror)
      return this._map(e, t, !0);
    for (let r = this.from; r < this.to; r++)
      e = this._maps[r].map(e, t);
    return e;
  }
  /**
  Map a position through this mapping, returning a mapping
  result.
  */
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  /**
  @internal
  */
  _map(e, t, r) {
    let i = 0;
    for (let s = this.from; s < this.to; s++) {
      let o = this._maps[s], l = o.mapResult(e, t);
      if (l.recover != null) {
        let a = this.getMirror(s);
        if (a != null && a > s && a < this.to) {
          s = a, e = this._maps[a].recover(l.recover);
          continue;
        }
      }
      i |= l.delInfo, e = l.pos;
    }
    return r ? e : new Ql(e, i, null);
  }
}
const dl = /* @__PURE__ */ Object.create(null);
class Qe {
  /**
  Get the step map that represents the changes made by this step,
  and which can be used to transform between positions in the old
  and the new document.
  */
  getMap() {
    return gt.empty;
  }
  /**
  Try to merge this step with another one, to be applied directly
  after it. Returns the merged step when possible, null if the
  steps can't be merged.
  */
  merge(e) {
    return null;
  }
  /**
  Deserialize a step from its JSON representation. Will call
  through to the step class' own implementation of this method.
  */
  static fromJSON(e, t) {
    if (!t || !t.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let r = dl[t.stepType];
    if (!r)
      throw new RangeError(`No step type ${t.stepType} defined`);
    return r.fromJSON(e, t);
  }
  /**
  To be able to serialize steps to JSON, each step needs a string
  ID to attach to its JSON representation. Use this method to
  register an ID for your step classes. Try to pick something
  that's unlikely to clash with steps from other modules.
  */
  static jsonID(e, t) {
    if (e in dl)
      throw new RangeError("Duplicate use of step JSON ID " + e);
    return dl[e] = t, t.prototype.jsonID = e, t;
  }
}
class Ne {
  /**
  @internal
  */
  constructor(e, t) {
    this.doc = e, this.failed = t;
  }
  /**
  Create a successful step result.
  */
  static ok(e) {
    return new Ne(e, null);
  }
  /**
  Create a failed step result.
  */
  static fail(e) {
    return new Ne(null, e);
  }
  /**
  Call [`Node.replace`](https://prosemirror.net/docs/ref/#model.Node.replace) with the given
  arguments. Create a successful result if it succeeds, and a
  failed one if it throws a `ReplaceError`.
  */
  static fromReplace(e, t, r, i) {
    try {
      return Ne.ok(e.replace(t, r, i));
    } catch (s) {
      if (s instanceof Hs)
        return Ne.fail(s.message);
      throw s;
    }
  }
}
function Oa(n, e, t) {
  let r = [];
  for (let i = 0; i < n.childCount; i++) {
    let s = n.child(i);
    s.content.size && (s = s.copy(Oa(s.content, e, s))), s.isInline && (s = e(s, t, i)), r.push(s);
  }
  return F.fromArray(r);
}
class Bn extends Qe {
  /**
  Create a mark step.
  */
  constructor(e, t, r) {
    super(), this.from = e, this.to = t, this.mark = r;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), r = e.resolve(this.from), i = r.node(r.sharedDepth(this.to)), s = new z(Oa(t.content, (o, l) => !o.isAtom || !l.type.allowsMarkType(this.mark.type) ? o : o.mark(this.mark.addToSet(o.marks)), i), t.openStart, t.openEnd);
    return Ne.fromReplace(e, this.from, this.to, s);
  }
  invert() {
    return new jt(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
    return t.deleted && r.deleted || t.pos >= r.pos ? null : new Bn(t.pos, r.pos, this.mark);
  }
  merge(e) {
    return e instanceof Bn && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new Bn(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new Bn(t.from, t.to, e.markFromJSON(t.mark));
  }
}
Qe.jsonID("addMark", Bn);
class jt extends Qe {
  /**
  Create a mark-removing step.
  */
  constructor(e, t, r) {
    super(), this.from = e, this.to = t, this.mark = r;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), r = new z(Oa(t.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), e), t.openStart, t.openEnd);
    return Ne.fromReplace(e, this.from, this.to, r);
  }
  invert() {
    return new Bn(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
    return t.deleted && r.deleted || t.pos >= r.pos ? null : new jt(t.pos, r.pos, this.mark);
  }
  merge(e) {
    return e instanceof jt && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new jt(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new jt(t.from, t.to, e.markFromJSON(t.mark));
  }
}
Qe.jsonID("removeMark", jt);
class zn extends Qe {
  /**
  Create a node mark step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return Ne.fail("No node at mark step's position");
    let r = t.type.create(t.attrs, null, this.mark.addToSet(t.marks));
    return Ne.fromReplace(e, this.pos, this.pos + 1, new z(F.from(r), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    if (t) {
      let r = this.mark.addToSet(t.marks);
      if (r.length == t.marks.length) {
        for (let i = 0; i < t.marks.length; i++)
          if (!t.marks[i].isInSet(r))
            return new zn(this.pos, t.marks[i]);
        return new zn(this.pos, this.mark);
      }
    }
    return new hr(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new zn(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new zn(t.pos, e.markFromJSON(t.mark));
  }
}
Qe.jsonID("addNodeMark", zn);
class hr extends Qe {
  /**
  Create a mark-removing step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return Ne.fail("No node at mark step's position");
    let r = t.type.create(t.attrs, null, this.mark.removeFromSet(t.marks));
    return Ne.fromReplace(e, this.pos, this.pos + 1, new z(F.from(r), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    return !t || !this.mark.isInSet(t.marks) ? this : new zn(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new hr(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new hr(t.pos, e.markFromJSON(t.mark));
  }
}
Qe.jsonID("removeNodeMark", hr);
class ze extends Qe {
  /**
  The given `slice` should fit the 'gap' between `from` and
  `to`—the depths must line up, and the surrounding nodes must be
  able to be joined with the open sides of the slice. When
  `structure` is true, the step will fail if the content between
  from and to is not just a sequence of closing and then opening
  tokens (this is to guard against rebased replace steps
  overwriting something they weren't supposed to).
  */
  constructor(e, t, r, i = !1) {
    super(), this.from = e, this.to = t, this.slice = r, this.structure = i;
  }
  apply(e) {
    return this.structure && ea(e, this.from, this.to) ? Ne.fail("Structure replace would overwrite content") : Ne.fromReplace(e, this.from, this.to, this.slice);
  }
  getMap() {
    return new gt([this.from, this.to - this.from, this.slice.size]);
  }
  invert(e) {
    return new ze(this.from, this.from + this.slice.size, e.slice(this.from, this.to));
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
    return t.deletedAcross && r.deletedAcross ? null : new ze(t.pos, Math.max(t.pos, r.pos), this.slice, this.structure);
  }
  merge(e) {
    if (!(e instanceof ze) || e.structure || this.structure)
      return null;
    if (this.from + this.slice.size == e.from && !this.slice.openEnd && !e.slice.openStart) {
      let t = this.slice.size + e.slice.size == 0 ? z.empty : new z(this.slice.content.append(e.slice.content), this.slice.openStart, e.slice.openEnd);
      return new ze(this.from, this.to + (e.to - e.from), t, this.structure);
    } else if (e.to == this.from && !this.slice.openStart && !e.slice.openEnd) {
      let t = this.slice.size + e.slice.size == 0 ? z.empty : new z(e.slice.content.append(this.slice.content), e.slice.openStart, this.slice.openEnd);
      return new ze(e.from, this.to, t, this.structure);
    } else
      return null;
  }
  toJSON() {
    let e = { stepType: "replace", from: this.from, to: this.to };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new ze(t.from, t.to, z.fromJSON(e, t.slice), !!t.structure);
  }
}
Qe.jsonID("replace", ze);
class He extends Qe {
  /**
  Create a replace-around step with the given range and gap.
  `insert` should be the point in the slice into which the content
  of the gap should be moved. `structure` has the same meaning as
  it has in the [`ReplaceStep`](https://prosemirror.net/docs/ref/#transform.ReplaceStep) class.
  */
  constructor(e, t, r, i, s, o, l = !1) {
    super(), this.from = e, this.to = t, this.gapFrom = r, this.gapTo = i, this.slice = s, this.insert = o, this.structure = l;
  }
  apply(e) {
    if (this.structure && (ea(e, this.from, this.gapFrom) || ea(e, this.gapTo, this.to)))
      return Ne.fail("Structure gap-replace would overwrite content");
    let t = e.slice(this.gapFrom, this.gapTo);
    if (t.openStart || t.openEnd)
      return Ne.fail("Gap is not a flat range");
    let r = this.slice.insertAt(this.insert, t.content);
    return r ? Ne.fromReplace(e, this.from, this.to, r) : Ne.fail("Content does not fit in gap");
  }
  getMap() {
    return new gt([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert
    ]);
  }
  invert(e) {
    let t = this.gapTo - this.gapFrom;
    return new He(this.from, this.from + this.slice.size + t, this.from + this.insert, this.from + this.insert + t, e.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1), i = this.from == this.gapFrom ? t.pos : e.map(this.gapFrom, -1), s = this.to == this.gapTo ? r.pos : e.map(this.gapTo, 1);
    return t.deletedAcross && r.deletedAcross || i < t.pos || s > r.pos ? null : new He(t.pos, r.pos, i, s, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let e = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert
    };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number" || typeof t.gapFrom != "number" || typeof t.gapTo != "number" || typeof t.insert != "number")
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new He(t.from, t.to, t.gapFrom, t.gapTo, z.fromJSON(e, t.slice), t.insert, !!t.structure);
  }
}
Qe.jsonID("replaceAround", He);
function ea(n, e, t) {
  let r = n.resolve(e), i = t - e, s = r.depth;
  for (; i > 0 && s > 0 && r.indexAfter(s) == r.node(s).childCount; )
    s--, i--;
  if (i > 0) {
    let o = r.node(s).maybeChild(r.indexAfter(s));
    for (; i > 0; ) {
      if (!o || o.isLeaf)
        return !0;
      o = o.firstChild, i--;
    }
  }
  return !1;
}
function B1(n, e, t, r) {
  let i = [], s = [], o, l;
  n.doc.nodesBetween(e, t, (a, u, c) => {
    if (!a.isInline)
      return;
    let d = a.marks;
    if (!r.isInSet(d) && c.type.allowsMarkType(r.type)) {
      let f = Math.max(u, e), h = Math.min(u + a.nodeSize, t), p = r.addToSet(d);
      for (let g = 0; g < d.length; g++)
        d[g].isInSet(p) || (o && o.to == f && o.mark.eq(d[g]) ? o.to = h : i.push(o = new jt(f, h, d[g])));
      l && l.to == f ? l.to = h : s.push(l = new Bn(f, h, r));
    }
  }), i.forEach((a) => n.step(a)), s.forEach((a) => n.step(a));
}
function z1(n, e, t, r) {
  let i = [], s = 0;
  n.doc.nodesBetween(e, t, (o, l) => {
    if (!o.isInline)
      return;
    s++;
    let a = null;
    if (r instanceof Mo) {
      let u = o.marks, c;
      for (; c = r.isInSet(u); )
        (a || (a = [])).push(c), u = c.removeFromSet(u);
    } else r ? r.isInSet(o.marks) && (a = [r]) : a = o.marks;
    if (a && a.length) {
      let u = Math.min(l + o.nodeSize, t);
      for (let c = 0; c < a.length; c++) {
        let d = a[c], f;
        for (let h = 0; h < i.length; h++) {
          let p = i[h];
          p.step == s - 1 && d.eq(i[h].style) && (f = p);
        }
        f ? (f.to = u, f.step = s) : i.push({ style: d, from: Math.max(l, e), to: u, step: s });
      }
    }
  }), i.forEach((o) => n.step(new jt(o.from, o.to, o.style)));
}
function Na(n, e, t, r = t.contentMatch, i = !0) {
  let s = n.doc.nodeAt(e), o = [], l = e + 1;
  for (let a = 0; a < s.childCount; a++) {
    let u = s.child(a), c = l + u.nodeSize, d = r.matchType(u.type);
    if (!d)
      o.push(new ze(l, c, z.empty));
    else {
      r = d;
      for (let f = 0; f < u.marks.length; f++)
        t.allowsMarkType(u.marks[f].type) || n.step(new jt(l, c, u.marks[f]));
      if (i && u.isText && t.whitespace != "pre") {
        let f, h = /\r?\n|\r/g, p;
        for (; f = h.exec(u.text); )
          p || (p = new z(F.from(t.schema.text(" ", t.allowedMarks(u.marks))), 0, 0)), o.push(new ze(l + f.index, l + f.index + f[0].length, p));
      }
    }
    l = c;
  }
  if (!r.validEnd) {
    let a = r.fillBefore(F.empty, !0);
    n.replace(l, l, new z(a, 0, 0));
  }
  for (let a = o.length - 1; a >= 0; a--)
    n.step(o[a]);
}
function H1(n, e, t) {
  return (e == 0 || n.canReplace(e, n.childCount)) && (t == n.childCount || n.canReplace(0, t));
}
function Gr(n) {
  let t = n.parent.content.cutByIndex(n.startIndex, n.endIndex);
  for (let r = n.depth; ; --r) {
    let i = n.$from.node(r), s = n.$from.index(r), o = n.$to.indexAfter(r);
    if (r < n.depth && i.canReplace(s, o, t))
      return r;
    if (r == 0 || i.type.spec.isolating || !H1(i, s, o))
      break;
  }
  return null;
}
function q1(n, e, t) {
  let { $from: r, $to: i, depth: s } = e, o = r.before(s + 1), l = i.after(s + 1), a = o, u = l, c = F.empty, d = 0;
  for (let p = s, g = !1; p > t; p--)
    g || r.index(p) > 0 ? (g = !0, c = F.from(r.node(p).copy(c)), d++) : a--;
  let f = F.empty, h = 0;
  for (let p = s, g = !1; p > t; p--)
    g || i.after(p + 1) < i.end(p) ? (g = !0, f = F.from(i.node(p).copy(f)), h++) : u++;
  n.step(new He(a, u, o, l, new z(c.append(f), d, h), c.size - d, !0));
}
function Ra(n, e, t = null, r = n) {
  let i = j1(n, e), s = i && V1(r, e);
  return s ? i.map(nd).concat({ type: e, attrs: t }).concat(s.map(nd)) : null;
}
function nd(n) {
  return { type: n, attrs: null };
}
function j1(n, e) {
  let { parent: t, startIndex: r, endIndex: i } = n, s = t.contentMatchAt(r).findWrapping(e);
  if (!s)
    return null;
  let o = s.length ? s[0] : e;
  return t.canReplaceWith(r, i, o) ? s : null;
}
function V1(n, e) {
  let { parent: t, startIndex: r, endIndex: i } = n, s = t.child(r), o = e.contentMatch.findWrapping(s.type);
  if (!o)
    return null;
  let a = (o.length ? o[o.length - 1] : e).contentMatch;
  for (let u = r; a && u < i; u++)
    a = a.matchType(t.child(u).type);
  return !a || !a.validEnd ? null : o;
}
function U1(n, e, t) {
  let r = F.empty;
  for (let o = t.length - 1; o >= 0; o--) {
    if (r.size) {
      let l = t[o].type.contentMatch.matchFragment(r);
      if (!l || !l.validEnd)
        throw new RangeError("Wrapper type given to Transform.wrap does not form valid content of its parent wrapper");
    }
    r = F.from(t[o].type.create(t[o].attrs, r));
  }
  let i = e.start, s = e.end;
  n.step(new He(i, s, i, s, new z(r, 0, 0), t.length, !0));
}
function W1(n, e, t, r, i) {
  if (!r.isTextblock)
    throw new RangeError("Type given to setBlockType should be a textblock");
  let s = n.steps.length;
  n.doc.nodesBetween(e, t, (o, l) => {
    let a = typeof i == "function" ? i(o) : i;
    if (o.isTextblock && !o.hasMarkup(r, a) && K1(n.doc, n.mapping.slice(s).map(l), r)) {
      let u = null;
      if (r.schema.linebreakReplacement) {
        let h = r.whitespace == "pre", p = !!r.contentMatch.matchType(r.schema.linebreakReplacement);
        h && !p ? u = !1 : !h && p && (u = !0);
      }
      u === !1 && jh(n, o, l, s), Na(n, n.mapping.slice(s).map(l, 1), r, void 0, u === null);
      let c = n.mapping.slice(s), d = c.map(l, 1), f = c.map(l + o.nodeSize, 1);
      return n.step(new He(d, f, d + 1, f - 1, new z(F.from(r.create(a, null, o.marks)), 0, 0), 1, !0)), u === !0 && qh(n, o, l, s), !1;
    }
  });
}
function qh(n, e, t, r) {
  e.forEach((i, s) => {
    if (i.isText) {
      let o, l = /\r?\n|\r/g;
      for (; o = l.exec(i.text); ) {
        let a = n.mapping.slice(r).map(t + 1 + s + o.index);
        n.replaceWith(a, a + 1, e.type.schema.linebreakReplacement.create());
      }
    }
  });
}
function jh(n, e, t, r) {
  e.forEach((i, s) => {
    if (i.type == i.type.schema.linebreakReplacement) {
      let o = n.mapping.slice(r).map(t + 1 + s);
      n.replaceWith(o, o + 1, e.type.schema.text(`
`));
    }
  });
}
function K1(n, e, t) {
  let r = n.resolve(e), i = r.index();
  return r.parent.canReplaceWith(i, i + 1, t);
}
function G1(n, e, t, r, i) {
  let s = n.doc.nodeAt(e);
  if (!s)
    throw new RangeError("No node at given position");
  t || (t = s.type);
  let o = t.create(r, null, i || s.marks);
  if (s.isLeaf)
    return n.replaceWith(e, e + s.nodeSize, o);
  if (!t.validContent(s.content))
    throw new RangeError("Invalid content for node type " + t.name);
  n.step(new He(e, e + s.nodeSize, e + 1, e + s.nodeSize - 1, new z(F.from(o), 0, 0), 1, !0));
}
function En(n, e, t = 1, r) {
  let i = n.resolve(e), s = i.depth - t, o = r && r[r.length - 1] || i.parent;
  if (s < 0 || i.parent.type.spec.isolating || !i.parent.canReplace(i.index(), i.parent.childCount) || !o.type.validContent(i.parent.content.cutByIndex(i.index(), i.parent.childCount)))
    return !1;
  for (let u = i.depth - 1, c = t - 2; u > s; u--, c--) {
    let d = i.node(u), f = i.index(u);
    if (d.type.spec.isolating)
      return !1;
    let h = d.content.cutByIndex(f, d.childCount), p = r && r[c + 1];
    p && (h = h.replaceChild(0, p.type.create(p.attrs)));
    let g = r && r[c] || d;
    if (!d.canReplace(f + 1, d.childCount) || !g.type.validContent(h))
      return !1;
  }
  let l = i.indexAfter(s), a = r && r[0];
  return i.node(s).canReplaceWith(l, l, a ? a.type : i.node(s + 1).type);
}
function J1(n, e, t = 1, r) {
  let i = n.doc.resolve(e), s = F.empty, o = F.empty;
  for (let l = i.depth, a = i.depth - t, u = t - 1; l > a; l--, u--) {
    s = F.from(i.node(l).copy(s));
    let c = r && r[u];
    o = F.from(c ? c.type.create(c.attrs, o) : i.node(l).copy(o));
  }
  n.step(new ze(e, e, new z(s.append(o), t, t), !0));
}
function Kn(n, e) {
  let t = n.resolve(e), r = t.index();
  return Vh(t.nodeBefore, t.nodeAfter) && t.parent.canReplace(r, r + 1);
}
function Y1(n, e) {
  e.content.size || n.type.compatibleContent(e.type);
  let t = n.contentMatchAt(n.childCount), { linebreakReplacement: r } = n.type.schema;
  for (let i = 0; i < e.childCount; i++) {
    let s = e.child(i), o = s.type == r ? n.type.schema.nodes.text : s.type;
    if (t = t.matchType(o), !t || !n.type.allowsMarks(s.marks))
      return !1;
  }
  return t.validEnd;
}
function Vh(n, e) {
  return !!(n && e && !n.isLeaf && Y1(n, e));
}
function $o(n, e, t = -1) {
  let r = n.resolve(e);
  for (let i = r.depth; ; i--) {
    let s, o, l = r.index(i);
    if (i == r.depth ? (s = r.nodeBefore, o = r.nodeAfter) : t > 0 ? (s = r.node(i + 1), l++, o = r.node(i).maybeChild(l)) : (s = r.node(i).maybeChild(l - 1), o = r.node(i + 1)), s && !s.isTextblock && Vh(s, o) && r.node(i).canReplace(l, l + 1))
      return e;
    if (i == 0)
      break;
    e = t < 0 ? r.before(i) : r.after(i);
  }
}
function X1(n, e, t) {
  let r = null, { linebreakReplacement: i } = n.doc.type.schema, s = n.doc.resolve(e - t), o = s.node().type;
  if (i && o.inlineContent) {
    let c = o.whitespace == "pre", d = !!o.contentMatch.matchType(i);
    c && !d ? r = !1 : !c && d && (r = !0);
  }
  let l = n.steps.length;
  if (r === !1) {
    let c = n.doc.resolve(e + t);
    jh(n, c.node(), c.before(), l);
  }
  o.inlineContent && Na(n, e + t - 1, o, s.node().contentMatchAt(s.index()), r == null);
  let a = n.mapping.slice(l), u = a.map(e - t);
  if (n.step(new ze(u, a.map(e + t, -1), z.empty, !0)), r === !0) {
    let c = n.doc.resolve(u);
    qh(n, c.node(), c.before(), n.steps.length);
  }
  return n;
}
function Z1(n, e, t) {
  let r = n.resolve(e);
  if (r.parent.canReplaceWith(r.index(), r.index(), t))
    return e;
  if (r.parentOffset == 0)
    for (let i = r.depth - 1; i >= 0; i--) {
      let s = r.index(i);
      if (r.node(i).canReplaceWith(s, s, t))
        return r.before(i + 1);
      if (s > 0)
        return null;
    }
  if (r.parentOffset == r.parent.content.size)
    for (let i = r.depth - 1; i >= 0; i--) {
      let s = r.indexAfter(i);
      if (r.node(i).canReplaceWith(s, s, t))
        return r.after(i + 1);
      if (s < r.node(i).childCount)
        return null;
    }
  return null;
}
function Uh(n, e, t) {
  let r = n.resolve(e);
  if (!t.content.size)
    return e;
  let i = t.content;
  for (let s = 0; s < t.openStart; s++)
    i = i.firstChild.content;
  for (let s = 1; s <= (t.openStart == 0 && t.size ? 2 : 1); s++)
    for (let o = r.depth; o >= 0; o--) {
      let l = o == r.depth ? 0 : r.pos <= (r.start(o + 1) + r.end(o + 1)) / 2 ? -1 : 1, a = r.index(o) + (l > 0 ? 1 : 0), u = r.node(o), c = !1;
      if (s == 1)
        c = u.canReplace(a, a, i);
      else {
        let d = u.contentMatchAt(a).findWrapping(i.firstChild.type);
        c = d && u.canReplaceWith(a, a, d[0]);
      }
      if (c)
        return l == 0 ? r.pos : l < 0 ? r.before(o + 1) : r.after(o + 1);
    }
  return null;
}
function Fo(n, e, t = e, r = z.empty) {
  if (e == t && !r.size)
    return null;
  let i = n.resolve(e), s = n.resolve(t);
  return Wh(i, s, r) ? new ze(e, t, r) : new Q1(i, s, r).fit();
}
function Wh(n, e, t) {
  return !t.openStart && !t.openEnd && n.start() == e.start() && n.parent.canReplace(n.index(), e.index(), t.content);
}
class Q1 {
  constructor(e, t, r) {
    this.$from = e, this.$to = t, this.unplaced = r, this.frontier = [], this.placed = F.empty;
    for (let i = 0; i <= e.depth; i++) {
      let s = e.node(i);
      this.frontier.push({
        type: s.type,
        match: s.contentMatchAt(e.indexAfter(i))
      });
    }
    for (let i = e.depth; i > 0; i--)
      this.placed = F.from(e.node(i).copy(this.placed));
  }
  get depth() {
    return this.frontier.length - 1;
  }
  fit() {
    for (; this.unplaced.size; ) {
      let u = this.findFittable();
      u ? this.placeNodes(u) : this.openMore() || this.dropNode();
    }
    let e = this.mustMoveInline(), t = this.placed.size - this.depth - this.$from.depth, r = this.$from, i = this.close(e < 0 ? this.$to : r.doc.resolve(e));
    if (!i)
      return null;
    let s = this.placed, o = r.depth, l = i.depth;
    for (; o && l && s.childCount == 1; )
      s = s.firstChild.content, o--, l--;
    let a = new z(s, o, l);
    return e > -1 ? new He(r.pos, e, this.$to.pos, this.$to.end(), a, t) : a.size || r.pos != this.$to.pos ? new ze(r.pos, i.pos, a) : null;
  }
  // Find a position on the start spine of `this.unplaced` that has
  // content that can be moved somewhere on the frontier. Returns two
  // depths, one for the slice and one for the frontier.
  findFittable() {
    let e = this.unplaced.openStart;
    for (let t = this.unplaced.content, r = 0, i = this.unplaced.openEnd; r < e; r++) {
      let s = t.firstChild;
      if (t.childCount > 1 && (i = 0), s.type.spec.isolating && i <= r) {
        e = r;
        break;
      }
      t = s.content;
    }
    for (let t = 1; t <= 2; t++)
      for (let r = t == 1 ? e : this.unplaced.openStart; r >= 0; r--) {
        let i, s = null;
        r ? (s = fl(this.unplaced.content, r - 1).firstChild, i = s.content) : i = this.unplaced.content;
        let o = i.firstChild;
        for (let l = this.depth; l >= 0; l--) {
          let { type: a, match: u } = this.frontier[l], c, d = null;
          if (t == 1 && (o ? u.matchType(o.type) || (d = u.fillBefore(F.from(o), !1)) : s && a.compatibleContent(s.type)))
            return { sliceDepth: r, frontierDepth: l, parent: s, inject: d };
          if (t == 2 && o && (c = u.findWrapping(o.type)))
            return { sliceDepth: r, frontierDepth: l, parent: s, wrap: c };
          if (s && u.matchType(s.type))
            break;
        }
      }
  }
  openMore() {
    let { content: e, openStart: t, openEnd: r } = this.unplaced, i = fl(e, t);
    return !i.childCount || i.firstChild.isLeaf ? !1 : (this.unplaced = new z(e, t + 1, Math.max(r, i.size + t >= e.size - r ? t + 1 : 0)), !0);
  }
  dropNode() {
    let { content: e, openStart: t, openEnd: r } = this.unplaced, i = fl(e, t);
    if (i.childCount <= 1 && t > 0) {
      let s = e.size - t <= t + i.size;
      this.unplaced = new z(ci(e, t - 1, 1), t - 1, s ? t - 1 : r);
    } else
      this.unplaced = new z(ci(e, t, 1), t, r);
  }
  // Move content from the unplaced slice at `sliceDepth` to the
  // frontier node at `frontierDepth`. Close that frontier node when
  // applicable.
  placeNodes({ sliceDepth: e, frontierDepth: t, parent: r, inject: i, wrap: s }) {
    for (; this.depth > t; )
      this.closeFrontierNode();
    if (s)
      for (let g = 0; g < s.length; g++)
        this.openFrontierNode(s[g]);
    let o = this.unplaced, l = r ? r.content : o.content, a = o.openStart - e, u = 0, c = [], { match: d, type: f } = this.frontier[t];
    if (i) {
      for (let g = 0; g < i.childCount; g++)
        c.push(i.child(g));
      d = d.matchFragment(i);
    }
    let h = l.size + e - (o.content.size - o.openEnd);
    for (; u < l.childCount; ) {
      let g = l.child(u), _ = d.matchType(g.type);
      if (!_)
        break;
      u++, (u > 1 || a == 0 || g.content.size) && (d = _, c.push(Kh(g.mark(f.allowedMarks(g.marks)), u == 1 ? a : 0, u == l.childCount ? h : -1)));
    }
    let p = u == l.childCount;
    p || (h = -1), this.placed = di(this.placed, t, F.from(c)), this.frontier[t].match = d, p && h < 0 && r && r.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
    for (let g = 0, _ = l; g < h; g++) {
      let k = _.lastChild;
      this.frontier.push({ type: k.type, match: k.contentMatchAt(k.childCount) }), _ = k.content;
    }
    this.unplaced = p ? e == 0 ? z.empty : new z(ci(o.content, e - 1, 1), e - 1, h < 0 ? o.openEnd : e - 1) : new z(ci(o.content, e, u), o.openStart, o.openEnd);
  }
  mustMoveInline() {
    if (!this.$to.parent.isTextblock)
      return -1;
    let e = this.frontier[this.depth], t;
    if (!e.type.isTextblock || !hl(this.$to, this.$to.depth, e.type, e.match, !1) || this.$to.depth == this.depth && (t = this.findCloseLevel(this.$to)) && t.depth == this.depth)
      return -1;
    let { depth: r } = this.$to, i = this.$to.after(r);
    for (; r > 1 && i == this.$to.end(--r); )
      ++i;
    return i;
  }
  findCloseLevel(e) {
    e: for (let t = Math.min(this.depth, e.depth); t >= 0; t--) {
      let { match: r, type: i } = this.frontier[t], s = t < e.depth && e.end(t + 1) == e.pos + (e.depth - (t + 1)), o = hl(e, t, i, r, s);
      if (o) {
        for (let l = t - 1; l >= 0; l--) {
          let { match: a, type: u } = this.frontier[l], c = hl(e, l, u, a, !0);
          if (!c || c.childCount)
            continue e;
        }
        return { depth: t, fit: o, move: s ? e.doc.resolve(e.after(t + 1)) : e };
      }
    }
  }
  close(e) {
    let t = this.findCloseLevel(e);
    if (!t)
      return null;
    for (; this.depth > t.depth; )
      this.closeFrontierNode();
    t.fit.childCount && (this.placed = di(this.placed, t.depth, t.fit)), e = t.move;
    for (let r = t.depth + 1; r <= e.depth; r++) {
      let i = e.node(r), s = i.type.contentMatch.fillBefore(i.content, !0, e.index(r));
      this.openFrontierNode(i.type, i.attrs, s);
    }
    return e;
  }
  openFrontierNode(e, t = null, r) {
    let i = this.frontier[this.depth];
    i.match = i.match.matchType(e), this.placed = di(this.placed, this.depth, F.from(e.create(t, r))), this.frontier.push({ type: e, match: e.contentMatch });
  }
  closeFrontierNode() {
    let t = this.frontier.pop().match.fillBefore(F.empty, !0);
    t.childCount && (this.placed = di(this.placed, this.frontier.length, t));
  }
}
function ci(n, e, t) {
  return e == 0 ? n.cutByIndex(t, n.childCount) : n.replaceChild(0, n.firstChild.copy(ci(n.firstChild.content, e - 1, t)));
}
function di(n, e, t) {
  return e == 0 ? n.append(t) : n.replaceChild(n.childCount - 1, n.lastChild.copy(di(n.lastChild.content, e - 1, t)));
}
function fl(n, e) {
  for (let t = 0; t < e; t++)
    n = n.firstChild.content;
  return n;
}
function Kh(n, e, t) {
  if (e <= 0)
    return n;
  let r = n.content;
  return e > 1 && (r = r.replaceChild(0, Kh(r.firstChild, e - 1, r.childCount == 1 ? t - 1 : 0))), e > 0 && (r = n.type.contentMatch.fillBefore(r).append(r), t <= 0 && (r = r.append(n.type.contentMatch.matchFragment(r).fillBefore(F.empty, !0)))), n.copy(r);
}
function hl(n, e, t, r, i) {
  let s = n.node(e), o = i ? n.indexAfter(e) : n.index(e);
  if (o == s.childCount && !t.compatibleContent(s.type))
    return null;
  let l = r.fillBefore(s.content, !0, o);
  return l && !eb(t, s.content, o) ? l : null;
}
function eb(n, e, t) {
  for (let r = t; r < e.childCount; r++)
    if (!n.allowsMarks(e.child(r).marks))
      return !0;
  return !1;
}
function tb(n) {
  return n.spec.defining || n.spec.definingForContent;
}
function nb(n, e, t, r) {
  if (!r.size)
    return n.deleteRange(e, t);
  let i = n.doc.resolve(e), s = n.doc.resolve(t);
  if (Wh(i, s, r))
    return n.step(new ze(e, t, r));
  let o = Jh(i, n.doc.resolve(t));
  o[o.length - 1] == 0 && o.pop();
  let l = -(i.depth + 1);
  o.unshift(l);
  for (let f = i.depth, h = i.pos - 1; f > 0; f--, h--) {
    let p = i.node(f).type.spec;
    if (p.defining || p.definingAsContext || p.isolating)
      break;
    o.indexOf(f) > -1 ? l = f : i.before(f) == h && o.splice(1, 0, -f);
  }
  let a = o.indexOf(l), u = [], c = r.openStart;
  for (let f = r.content, h = 0; ; h++) {
    let p = f.firstChild;
    if (u.push(p), h == r.openStart)
      break;
    f = p.content;
  }
  for (let f = c - 1; f >= 0; f--) {
    let h = u[f], p = tb(h.type);
    if (p && !h.sameMarkup(i.node(Math.abs(l) - 1)))
      c = f;
    else if (p || !h.type.isTextblock)
      break;
  }
  for (let f = r.openStart; f >= 0; f--) {
    let h = (f + c + 1) % (r.openStart + 1), p = u[h];
    if (p)
      for (let g = 0; g < o.length; g++) {
        let _ = o[(g + a) % o.length], k = !0;
        _ < 0 && (k = !1, _ = -_);
        let b = i.node(_ - 1), y = i.index(_ - 1);
        if (b.canReplaceWith(y, y, p.type, p.marks))
          return n.replace(i.before(_), k ? s.after(_) : t, new z(Gh(r.content, 0, r.openStart, h), h, r.openEnd));
      }
  }
  let d = n.steps.length;
  for (let f = o.length - 1; f >= 0 && (n.replace(e, t, r), !(n.steps.length > d)); f--) {
    let h = o[f];
    h < 0 || (e = i.before(h), t = s.after(h));
  }
}
function Gh(n, e, t, r, i) {
  if (e < t) {
    let s = n.firstChild;
    n = n.replaceChild(0, s.copy(Gh(s.content, e + 1, t, r, s)));
  }
  if (e > r) {
    let s = i.contentMatchAt(0), o = s.fillBefore(n).append(n);
    n = o.append(s.matchFragment(o).fillBefore(F.empty, !0));
  }
  return n;
}
function rb(n, e, t, r) {
  if (!r.isInline && e == t && n.doc.resolve(e).parent.content.size) {
    let i = Z1(n.doc, e, r.type);
    i != null && (e = t = i);
  }
  n.replaceRange(e, t, new z(F.from(r), 0, 0));
}
function ib(n, e, t) {
  let r = n.doc.resolve(e), i = n.doc.resolve(t), s = Jh(r, i);
  for (let o = 0; o < s.length; o++) {
    let l = s[o], a = o == s.length - 1;
    if (a && l == 0 || r.node(l).type.contentMatch.validEnd)
      return n.delete(r.start(l), i.end(l));
    if (l > 0 && (a || r.node(l - 1).canReplace(r.index(l - 1), i.indexAfter(l - 1))))
      return n.delete(r.before(l), i.after(l));
  }
  for (let o = 1; o <= r.depth && o <= i.depth; o++)
    if (e - r.start(o) == r.depth - o && t > r.end(o) && i.end(o) - t != i.depth - o && r.start(o - 1) == i.start(o - 1) && r.node(o - 1).canReplace(r.index(o - 1), i.index(o - 1)))
      return n.delete(r.before(o), t);
  n.delete(e, t);
}
function Jh(n, e) {
  let t = [], r = Math.min(n.depth, e.depth);
  for (let i = r; i >= 0; i--) {
    let s = n.start(i);
    if (s < n.pos - (n.depth - i) || e.end(i) > e.pos + (e.depth - i) || n.node(i).type.spec.isolating || e.node(i).type.spec.isolating)
      break;
    (s == e.start(i) || i == n.depth && i == e.depth && n.parent.inlineContent && e.parent.inlineContent && i && e.start(i - 1) == s - 1) && t.push(i);
  }
  return t;
}
class Br extends Qe {
  /**
  Construct an attribute step.
  */
  constructor(e, t, r) {
    super(), this.pos = e, this.attr = t, this.value = r;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return Ne.fail("No node at attribute step's position");
    let r = /* @__PURE__ */ Object.create(null);
    for (let s in t.attrs)
      r[s] = t.attrs[s];
    r[this.attr] = this.value;
    let i = t.type.create(r, null, t.marks);
    return Ne.fromReplace(e, this.pos, this.pos + 1, new z(F.from(i), 0, t.isLeaf ? 0 : 1));
  }
  getMap() {
    return gt.empty;
  }
  invert(e) {
    return new Br(this.pos, this.attr, e.nodeAt(this.pos).attrs[this.attr]);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new Br(t.pos, this.attr, this.value);
  }
  toJSON() {
    return { stepType: "attr", pos: this.pos, attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number" || typeof t.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new Br(t.pos, t.attr, t.value);
  }
}
Qe.jsonID("attr", Br);
class Ii extends Qe {
  /**
  Construct an attribute step.
  */
  constructor(e, t) {
    super(), this.attr = e, this.value = t;
  }
  apply(e) {
    let t = /* @__PURE__ */ Object.create(null);
    for (let i in e.attrs)
      t[i] = e.attrs[i];
    t[this.attr] = this.value;
    let r = e.type.create(t, e.content, e.marks);
    return Ne.ok(r);
  }
  getMap() {
    return gt.empty;
  }
  invert(e) {
    return new Ii(this.attr, e.attrs[this.attr]);
  }
  map(e) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new Ii(t.attr, t.value);
  }
}
Qe.jsonID("docAttr", Ii);
let Hr = class extends Error {
};
Hr = function n(e) {
  let t = Error.call(this, e);
  return t.__proto__ = n.prototype, t;
};
Hr.prototype = Object.create(Error.prototype);
Hr.prototype.constructor = Hr;
Hr.prototype.name = "TransformError";
class Yh {
  /**
  Create a transform that starts with the given document.
  */
  constructor(e) {
    this.doc = e, this.steps = [], this.docs = [], this.mapping = new Ri();
  }
  /**
  The starting document.
  */
  get before() {
    return this.docs.length ? this.docs[0] : this.doc;
  }
  /**
  Apply a new step in this transform, saving the result. Throws an
  error when the step fails.
  */
  step(e) {
    let t = this.maybeStep(e);
    if (t.failed)
      throw new Hr(t.failed);
    return this;
  }
  /**
  Try to apply a step in this transformation, ignoring it if it
  fails. Returns the step result.
  */
  maybeStep(e) {
    let t = e.apply(this.doc);
    return t.failed || this.addStep(e, t.doc), t;
  }
  /**
  True when the document has been changed (when there are any
  steps).
  */
  get docChanged() {
    return this.steps.length > 0;
  }
  /**
  @internal
  */
  addStep(e, t) {
    this.docs.push(this.doc), this.steps.push(e), this.mapping.appendMap(e.getMap()), this.doc = t;
  }
  /**
  Replace the part of the document between `from` and `to` with the
  given `slice`.
  */
  replace(e, t = e, r = z.empty) {
    let i = Fo(this.doc, e, t, r);
    return i && this.step(i), this;
  }
  /**
  Replace the given range with the given content, which may be a
  fragment, node, or array of nodes.
  */
  replaceWith(e, t, r) {
    return this.replace(e, t, new z(F.from(r), 0, 0));
  }
  /**
  Delete the content between the given positions.
  */
  delete(e, t) {
    return this.replace(e, t, z.empty);
  }
  /**
  Insert the given content at the given position.
  */
  insert(e, t) {
    return this.replaceWith(e, e, t);
  }
  /**
  Replace a range of the document with a given slice, using
  `from`, `to`, and the slice's
  [`openStart`](https://prosemirror.net/docs/ref/#model.Slice.openStart) property as hints, rather
  than fixed start and end points. This method may grow the
  replaced area or close open nodes in the slice in order to get a
  fit that is more in line with WYSIWYG expectations, by dropping
  fully covered parent nodes of the replaced region when they are
  marked [non-defining as
  context](https://prosemirror.net/docs/ref/#model.NodeSpec.definingAsContext), or including an
  open parent node from the slice that _is_ marked as [defining
  its content](https://prosemirror.net/docs/ref/#model.NodeSpec.definingForContent).
  
  This is the method, for example, to handle paste. The similar
  [`replace`](https://prosemirror.net/docs/ref/#transform.Transform.replace) method is a more
  primitive tool which will _not_ move the start and end of its given
  range, and is useful in situations where you need more precise
  control over what happens.
  */
  replaceRange(e, t, r) {
    return nb(this, e, t, r), this;
  }
  /**
  Replace the given range with a node, but use `from` and `to` as
  hints, rather than precise positions. When from and to are the same
  and are at the start or end of a parent node in which the given
  node doesn't fit, this method may _move_ them out towards a parent
  that does allow the given node to be placed. When the given range
  completely covers a parent node, this method may completely replace
  that parent node.
  */
  replaceRangeWith(e, t, r) {
    return rb(this, e, t, r), this;
  }
  /**
  Delete the given range, expanding it to cover fully covered
  parent nodes until a valid replace is found.
  */
  deleteRange(e, t) {
    return ib(this, e, t), this;
  }
  /**
  Split the content in the given range off from its parent, if there
  is sibling content before or after it, and move it up the tree to
  the depth specified by `target`. You'll probably want to use
  [`liftTarget`](https://prosemirror.net/docs/ref/#transform.liftTarget) to compute `target`, to make
  sure the lift is valid.
  */
  lift(e, t) {
    return q1(this, e, t), this;
  }
  /**
  Join the blocks around the given position. If depth is 2, their
  last and first siblings are also joined, and so on.
  */
  join(e, t = 1) {
    return X1(this, e, t), this;
  }
  /**
  Wrap the given [range](https://prosemirror.net/docs/ref/#model.NodeRange) in the given set of wrappers.
  The wrappers are assumed to be valid in this position, and should
  probably be computed with [`findWrapping`](https://prosemirror.net/docs/ref/#transform.findWrapping).
  */
  wrap(e, t) {
    return U1(this, e, t), this;
  }
  /**
  Set the type of all textblocks (partly) between `from` and `to` to
  the given node type with the given attributes.
  */
  setBlockType(e, t = e, r, i = null) {
    return W1(this, e, t, r, i), this;
  }
  /**
  Change the type, attributes, and/or marks of the node at `pos`.
  When `type` isn't given, the existing node type is preserved,
  */
  setNodeMarkup(e, t, r = null, i) {
    return G1(this, e, t, r, i), this;
  }
  /**
  Set a single attribute on a given node to a new value.
  The `pos` addresses the document content. Use `setDocAttribute`
  to set attributes on the document itself.
  */
  setNodeAttribute(e, t, r) {
    return this.step(new Br(e, t, r)), this;
  }
  /**
  Set a single attribute on the document to a new value.
  */
  setDocAttribute(e, t) {
    return this.step(new Ii(e, t)), this;
  }
  /**
  Add a mark to the node at position `pos`.
  */
  addNodeMark(e, t) {
    return this.step(new zn(e, t)), this;
  }
  /**
  Remove a mark (or all marks of the given type) from the node at
  position `pos`.
  */
  removeNodeMark(e, t) {
    let r = this.doc.nodeAt(e);
    if (!r)
      throw new RangeError("No node at position " + e);
    if (t instanceof be)
      t.isInSet(r.marks) && this.step(new hr(e, t));
    else {
      let i = r.marks, s, o = [];
      for (; s = t.isInSet(i); )
        o.push(new hr(e, s)), i = s.removeFromSet(i);
      for (let l = o.length - 1; l >= 0; l--)
        this.step(o[l]);
    }
    return this;
  }
  /**
  Split the node at the given position, and optionally, if `depth` is
  greater than one, any number of nodes above that. By default, the
  parts split off will inherit the node type of the original node.
  This can be changed by passing an array of types and attributes to
  use after the split (with the outermost nodes coming first).
  */
  split(e, t = 1, r) {
    return J1(this, e, t, r), this;
  }
  /**
  Add the given mark to the inline content between `from` and `to`.
  */
  addMark(e, t, r) {
    return B1(this, e, t, r), this;
  }
  /**
  Remove marks from inline nodes between `from` and `to`. When
  `mark` is a single mark, remove precisely that mark. When it is
  a mark type, remove all marks of that type. When it is null,
  remove all marks of any type.
  */
  removeMark(e, t, r) {
    return z1(this, e, t, r), this;
  }
  /**
  Removes all marks and nodes from the content of the node at
  `pos` that don't match the given new parent node type. Accepts
  an optional starting [content match](https://prosemirror.net/docs/ref/#model.ContentMatch) as
  third argument.
  */
  clearIncompatible(e, t, r) {
    return Na(this, e, t, r), this;
  }
}
const pl = /* @__PURE__ */ Object.create(null);
class re {
  /**
  Initialize a selection with the head and anchor and ranges. If no
  ranges are given, constructs a single range across `$anchor` and
  `$head`.
  */
  constructor(e, t, r) {
    this.$anchor = e, this.$head = t, this.ranges = r || [new sb(e.min(t), e.max(t))];
  }
  /**
  The selection's anchor, as an unresolved position.
  */
  get anchor() {
    return this.$anchor.pos;
  }
  /**
  The selection's head.
  */
  get head() {
    return this.$head.pos;
  }
  /**
  The lower bound of the selection's main range.
  */
  get from() {
    return this.$from.pos;
  }
  /**
  The upper bound of the selection's main range.
  */
  get to() {
    return this.$to.pos;
  }
  /**
  The resolved lower  bound of the selection's main range.
  */
  get $from() {
    return this.ranges[0].$from;
  }
  /**
  The resolved upper bound of the selection's main range.
  */
  get $to() {
    return this.ranges[0].$to;
  }
  /**
  Indicates whether the selection contains any content.
  */
  get empty() {
    let e = this.ranges;
    for (let t = 0; t < e.length; t++)
      if (e[t].$from.pos != e[t].$to.pos)
        return !1;
    return !0;
  }
  /**
  Get the content of this selection as a slice.
  */
  content() {
    return this.$from.doc.slice(this.from, this.to, !0);
  }
  /**
  Replace the selection with a slice or, if no slice is given,
  delete the selection. Will append to the given transaction.
  */
  replace(e, t = z.empty) {
    let r = t.content.lastChild, i = null;
    for (let l = 0; l < t.openEnd; l++)
      i = r, r = r.lastChild;
    let s = e.steps.length, o = this.ranges;
    for (let l = 0; l < o.length; l++) {
      let { $from: a, $to: u } = o[l], c = e.mapping.slice(s);
      e.replaceRange(c.map(a.pos), c.map(u.pos), l ? z.empty : t), l == 0 && sd(e, s, (r ? r.isInline : i && i.isTextblock) ? -1 : 1);
    }
  }
  /**
  Replace the selection with the given node, appending the changes
  to the given transaction.
  */
  replaceWith(e, t) {
    let r = e.steps.length, i = this.ranges;
    for (let s = 0; s < i.length; s++) {
      let { $from: o, $to: l } = i[s], a = e.mapping.slice(r), u = a.map(o.pos), c = a.map(l.pos);
      s ? e.deleteRange(u, c) : (e.replaceRangeWith(u, c, t), sd(e, r, t.isInline ? -1 : 1));
    }
  }
  /**
  Find a valid cursor or leaf node selection starting at the given
  position and searching back if `dir` is negative, and forward if
  positive. When `textOnly` is true, only consider cursor
  selections. Will return null when no valid selection position is
  found.
  */
  static findFrom(e, t, r = !1) {
    let i = e.parent.inlineContent ? new Z(e) : Mr(e.node(0), e.parent, e.pos, e.index(), t, r);
    if (i)
      return i;
    for (let s = e.depth - 1; s >= 0; s--) {
      let o = t < 0 ? Mr(e.node(0), e.node(s), e.before(s + 1), e.index(s), t, r) : Mr(e.node(0), e.node(s), e.after(s + 1), e.index(s) + 1, t, r);
      if (o)
        return o;
    }
    return null;
  }
  /**
  Find a valid cursor or leaf node selection near the given
  position. Searches forward first by default, but if `bias` is
  negative, it will search backwards first.
  */
  static near(e, t = 1) {
    return this.findFrom(e, t) || this.findFrom(e, -t) || new yt(e.node(0));
  }
  /**
  Find the cursor or leaf node selection closest to the start of
  the given document. Will return an
  [`AllSelection`](https://prosemirror.net/docs/ref/#state.AllSelection) if no valid position
  exists.
  */
  static atStart(e) {
    return Mr(e, e, 0, 0, 1) || new yt(e);
  }
  /**
  Find the cursor or leaf node selection closest to the end of the
  given document.
  */
  static atEnd(e) {
    return Mr(e, e, e.content.size, e.childCount, -1) || new yt(e);
  }
  /**
  Deserialize the JSON representation of a selection. Must be
  implemented for custom classes (as a static class method).
  */
  static fromJSON(e, t) {
    if (!t || !t.type)
      throw new RangeError("Invalid input for Selection.fromJSON");
    let r = pl[t.type];
    if (!r)
      throw new RangeError(`No selection type ${t.type} defined`);
    return r.fromJSON(e, t);
  }
  /**
  To be able to deserialize selections from JSON, custom selection
  classes must register themselves with an ID string, so that they
  can be disambiguated. Try to pick something that's unlikely to
  clash with classes from other modules.
  */
  static jsonID(e, t) {
    if (e in pl)
      throw new RangeError("Duplicate use of selection JSON ID " + e);
    return pl[e] = t, t.prototype.jsonID = e, t;
  }
  /**
  Get a [bookmark](https://prosemirror.net/docs/ref/#state.SelectionBookmark) for this selection,
  which is a value that can be mapped without having access to a
  current document, and later resolved to a real selection for a
  given document again. (This is used mostly by the history to
  track and restore old selections.) The default implementation of
  this method just converts the selection to a text selection and
  returns the bookmark for that.
  */
  getBookmark() {
    return Z.between(this.$anchor, this.$head).getBookmark();
  }
}
re.prototype.visible = !0;
class sb {
  /**
  Create a range.
  */
  constructor(e, t) {
    this.$from = e, this.$to = t;
  }
}
let rd = !1;
function id(n) {
  !rd && !n.parent.inlineContent && (rd = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + n.parent.type.name + ")"));
}
class Z extends re {
  /**
  Construct a text selection between the given points.
  */
  constructor(e, t = e) {
    id(e), id(t), super(e, t);
  }
  /**
  Returns a resolved position if this is a cursor selection (an
  empty text selection), and null otherwise.
  */
  get $cursor() {
    return this.$anchor.pos == this.$head.pos ? this.$head : null;
  }
  map(e, t) {
    let r = e.resolve(t.map(this.head));
    if (!r.parent.inlineContent)
      return re.near(r);
    let i = e.resolve(t.map(this.anchor));
    return new Z(i.parent.inlineContent ? i : r, r);
  }
  replace(e, t = z.empty) {
    if (super.replace(e, t), t == z.empty) {
      let r = this.$from.marksAcross(this.$to);
      r && e.ensureMarks(r);
    }
  }
  eq(e) {
    return e instanceof Z && e.anchor == this.anchor && e.head == this.head;
  }
  getBookmark() {
    return new Oo(this.anchor, this.head);
  }
  toJSON() {
    return { type: "text", anchor: this.anchor, head: this.head };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number" || typeof t.head != "number")
      throw new RangeError("Invalid input for TextSelection.fromJSON");
    return new Z(e.resolve(t.anchor), e.resolve(t.head));
  }
  /**
  Create a text selection from non-resolved positions.
  */
  static create(e, t, r = t) {
    let i = e.resolve(t);
    return new this(i, r == t ? i : e.resolve(r));
  }
  /**
  Return a text selection that spans the given positions or, if
  they aren't text positions, find a text selection near them.
  `bias` determines whether the method searches forward (default)
  or backwards (negative number) first. Will fall back to calling
  [`Selection.near`](https://prosemirror.net/docs/ref/#state.Selection^near) when the document
  doesn't contain a valid text position.
  */
  static between(e, t, r) {
    let i = e.pos - t.pos;
    if ((!r || i) && (r = i >= 0 ? 1 : -1), !t.parent.inlineContent) {
      let s = re.findFrom(t, r, !0) || re.findFrom(t, -r, !0);
      if (s)
        t = s.$head;
      else
        return re.near(t, r);
    }
    return e.parent.inlineContent || (i == 0 ? e = t : (e = (re.findFrom(e, -r, !0) || re.findFrom(e, r, !0)).$anchor, e.pos < t.pos != i < 0 && (e = t))), new Z(e, t);
  }
}
re.jsonID("text", Z);
class Oo {
  constructor(e, t) {
    this.anchor = e, this.head = t;
  }
  map(e) {
    return new Oo(e.map(this.anchor), e.map(this.head));
  }
  resolve(e) {
    return Z.between(e.resolve(this.anchor), e.resolve(this.head));
  }
}
class G extends re {
  /**
  Create a node selection. Does not verify the validity of its
  argument.
  */
  constructor(e) {
    let t = e.nodeAfter, r = e.node(0).resolve(e.pos + t.nodeSize);
    super(e, r), this.node = t;
  }
  map(e, t) {
    let { deleted: r, pos: i } = t.mapResult(this.anchor), s = e.resolve(i);
    return r ? re.near(s) : new G(s);
  }
  content() {
    return new z(F.from(this.node), 0, 0);
  }
  eq(e) {
    return e instanceof G && e.anchor == this.anchor;
  }
  toJSON() {
    return { type: "node", anchor: this.anchor };
  }
  getBookmark() {
    return new Ia(this.anchor);
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number")
      throw new RangeError("Invalid input for NodeSelection.fromJSON");
    return new G(e.resolve(t.anchor));
  }
  /**
  Create a node selection from non-resolved positions.
  */
  static create(e, t) {
    return new G(e.resolve(t));
  }
  /**
  Determines whether the given node may be selected as a node
  selection.
  */
  static isSelectable(e) {
    return !e.isText && e.type.spec.selectable !== !1;
  }
}
G.prototype.visible = !1;
re.jsonID("node", G);
class Ia {
  constructor(e) {
    this.anchor = e;
  }
  map(e) {
    let { deleted: t, pos: r } = e.mapResult(this.anchor);
    return t ? new Oo(r, r) : new Ia(r);
  }
  resolve(e) {
    let t = e.resolve(this.anchor), r = t.nodeAfter;
    return r && G.isSelectable(r) ? new G(t) : re.near(t);
  }
}
class yt extends re {
  /**
  Create an all-selection over the given document.
  */
  constructor(e) {
    super(e.resolve(0), e.resolve(e.content.size));
  }
  replace(e, t = z.empty) {
    if (t == z.empty) {
      e.delete(0, e.doc.content.size);
      let r = re.atStart(e.doc);
      r.eq(e.selection) || e.setSelection(r);
    } else
      super.replace(e, t);
  }
  toJSON() {
    return { type: "all" };
  }
  /**
  @internal
  */
  static fromJSON(e) {
    return new yt(e);
  }
  map(e) {
    return new yt(e);
  }
  eq(e) {
    return e instanceof yt;
  }
  getBookmark() {
    return ob;
  }
}
re.jsonID("all", yt);
const ob = {
  map() {
    return this;
  },
  resolve(n) {
    return new yt(n);
  }
};
function Mr(n, e, t, r, i, s = !1) {
  if (e.inlineContent)
    return Z.create(n, t);
  for (let o = r - (i > 0 ? 0 : 1); i > 0 ? o < e.childCount : o >= 0; o += i) {
    let l = e.child(o);
    if (l.isAtom) {
      if (!s && G.isSelectable(l))
        return G.create(n, t - (i < 0 ? l.nodeSize : 0));
    } else {
      let a = Mr(n, l, t + i, i < 0 ? l.childCount : 0, i, s);
      if (a)
        return a;
    }
    t += l.nodeSize * i;
  }
  return null;
}
function sd(n, e, t) {
  let r = n.steps.length - 1;
  if (r < e)
    return;
  let i = n.steps[r];
  if (!(i instanceof ze || i instanceof He))
    return;
  let s = n.mapping.maps[r], o;
  s.forEach((l, a, u, c) => {
    o == null && (o = c);
  }), n.setSelection(re.near(n.doc.resolve(o), t));
}
const od = 1, gs = 2, ld = 4;
class lb extends Yh {
  /**
  @internal
  */
  constructor(e) {
    super(e.doc), this.curSelectionFor = 0, this.updated = 0, this.meta = /* @__PURE__ */ Object.create(null), this.time = Date.now(), this.curSelection = e.selection, this.storedMarks = e.storedMarks;
  }
  /**
  The transaction's current selection. This defaults to the editor
  selection [mapped](https://prosemirror.net/docs/ref/#state.Selection.map) through the steps in the
  transaction, but can be overwritten with
  [`setSelection`](https://prosemirror.net/docs/ref/#state.Transaction.setSelection).
  */
  get selection() {
    return this.curSelectionFor < this.steps.length && (this.curSelection = this.curSelection.map(this.doc, this.mapping.slice(this.curSelectionFor)), this.curSelectionFor = this.steps.length), this.curSelection;
  }
  /**
  Update the transaction's current selection. Will determine the
  selection that the editor gets when the transaction is applied.
  */
  setSelection(e) {
    if (e.$from.doc != this.doc)
      throw new RangeError("Selection passed to setSelection must point at the current document");
    return this.curSelection = e, this.curSelectionFor = this.steps.length, this.updated = (this.updated | od) & ~gs, this.storedMarks = null, this;
  }
  /**
  Whether the selection was explicitly updated by this transaction.
  */
  get selectionSet() {
    return (this.updated & od) > 0;
  }
  /**
  Set the current stored marks.
  */
  setStoredMarks(e) {
    return this.storedMarks = e, this.updated |= gs, this;
  }
  /**
  Make sure the current stored marks or, if that is null, the marks
  at the selection, match the given set of marks. Does nothing if
  this is already the case.
  */
  ensureMarks(e) {
    return be.sameSet(this.storedMarks || this.selection.$from.marks(), e) || this.setStoredMarks(e), this;
  }
  /**
  Add a mark to the set of stored marks.
  */
  addStoredMark(e) {
    return this.ensureMarks(e.addToSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Remove a mark or mark type from the set of stored marks.
  */
  removeStoredMark(e) {
    return this.ensureMarks(e.removeFromSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Whether the stored marks were explicitly set for this transaction.
  */
  get storedMarksSet() {
    return (this.updated & gs) > 0;
  }
  /**
  @internal
  */
  addStep(e, t) {
    super.addStep(e, t), this.updated = this.updated & ~gs, this.storedMarks = null;
  }
  /**
  Update the timestamp for the transaction.
  */
  setTime(e) {
    return this.time = e, this;
  }
  /**
  Replace the current selection with the given slice.
  */
  replaceSelection(e) {
    return this.selection.replace(this, e), this;
  }
  /**
  Replace the selection with the given node. When `inheritMarks` is
  true and the content is inline, it inherits the marks from the
  place where it is inserted.
  */
  replaceSelectionWith(e, t = !0) {
    let r = this.selection;
    return t && (e = e.mark(this.storedMarks || (r.empty ? r.$from.marks() : r.$from.marksAcross(r.$to) || be.none))), r.replaceWith(this, e), this;
  }
  /**
  Delete the selection.
  */
  deleteSelection() {
    return this.selection.replace(this), this;
  }
  /**
  Replace the given range, or the selection if no range is given,
  with a text node containing the given string.
  */
  insertText(e, t, r) {
    let i = this.doc.type.schema;
    if (t == null)
      return e ? this.replaceSelectionWith(i.text(e), !0) : this.deleteSelection();
    {
      if (r == null && (r = t), r = r ?? t, !e)
        return this.deleteRange(t, r);
      let s = this.storedMarks;
      if (!s) {
        let o = this.doc.resolve(t);
        s = r == t ? o.marks() : o.marksAcross(this.doc.resolve(r));
      }
      return this.replaceRangeWith(t, r, i.text(e, s)), this.selection.empty || this.setSelection(re.near(this.selection.$to)), this;
    }
  }
  /**
  Store a metadata property in this transaction, keyed either by
  name or by plugin.
  */
  setMeta(e, t) {
    return this.meta[typeof e == "string" ? e : e.key] = t, this;
  }
  /**
  Retrieve a metadata property for a given name or plugin.
  */
  getMeta(e) {
    return this.meta[typeof e == "string" ? e : e.key];
  }
  /**
  Returns true if this transaction doesn't contain any metadata,
  and can thus safely be extended.
  */
  get isGeneric() {
    for (let e in this.meta)
      return !1;
    return !0;
  }
  /**
  Indicate that the editor should scroll the selection into view
  when updated to the state produced by this transaction.
  */
  scrollIntoView() {
    return this.updated |= ld, this;
  }
  /**
  True when this transaction has had `scrollIntoView` called on it.
  */
  get scrolledIntoView() {
    return (this.updated & ld) > 0;
  }
}
function ad(n, e) {
  return !e || !n ? n : n.bind(e);
}
class fi {
  constructor(e, t, r) {
    this.name = e, this.init = ad(t.init, r), this.apply = ad(t.apply, r);
  }
}
const ab = [
  new fi("doc", {
    init(n) {
      return n.doc || n.schema.topNodeType.createAndFill();
    },
    apply(n) {
      return n.doc;
    }
  }),
  new fi("selection", {
    init(n, e) {
      return n.selection || re.atStart(e.doc);
    },
    apply(n) {
      return n.selection;
    }
  }),
  new fi("storedMarks", {
    init(n) {
      return n.storedMarks || null;
    },
    apply(n, e, t, r) {
      return r.selection.$cursor ? n.storedMarks : null;
    }
  }),
  new fi("scrollToSelection", {
    init() {
      return 0;
    },
    apply(n, e) {
      return n.scrolledIntoView ? e + 1 : e;
    }
  })
];
class ml {
  constructor(e, t) {
    this.schema = e, this.plugins = [], this.pluginsByKey = /* @__PURE__ */ Object.create(null), this.fields = ab.slice(), t && t.forEach((r) => {
      if (this.pluginsByKey[r.key])
        throw new RangeError("Adding different instances of a keyed plugin (" + r.key + ")");
      this.plugins.push(r), this.pluginsByKey[r.key] = r, r.spec.state && this.fields.push(new fi(r.key, r.spec.state, r));
    });
  }
}
class Ir {
  /**
  @internal
  */
  constructor(e) {
    this.config = e;
  }
  /**
  The schema of the state's document.
  */
  get schema() {
    return this.config.schema;
  }
  /**
  The plugins that are active in this state.
  */
  get plugins() {
    return this.config.plugins;
  }
  /**
  Apply the given transaction to produce a new state.
  */
  apply(e) {
    return this.applyTransaction(e).state;
  }
  /**
  @internal
  */
  filterTransaction(e, t = -1) {
    for (let r = 0; r < this.config.plugins.length; r++)
      if (r != t) {
        let i = this.config.plugins[r];
        if (i.spec.filterTransaction && !i.spec.filterTransaction.call(i, e, this))
          return !1;
      }
    return !0;
  }
  /**
  Verbose variant of [`apply`](https://prosemirror.net/docs/ref/#state.EditorState.apply) that
  returns the precise transactions that were applied (which might
  be influenced by the [transaction
  hooks](https://prosemirror.net/docs/ref/#state.PluginSpec.filterTransaction) of
  plugins) along with the new state.
  */
  applyTransaction(e) {
    if (!this.filterTransaction(e))
      return { state: this, transactions: [] };
    let t = [e], r = this.applyInner(e), i = null;
    for (; ; ) {
      let s = !1;
      for (let o = 0; o < this.config.plugins.length; o++) {
        let l = this.config.plugins[o];
        if (l.spec.appendTransaction) {
          let a = i ? i[o].n : 0, u = i ? i[o].state : this, c = a < t.length && l.spec.appendTransaction.call(l, a ? t.slice(a) : t, u, r);
          if (c && r.filterTransaction(c, o)) {
            if (c.setMeta("appendedTransaction", e), !i) {
              i = [];
              for (let d = 0; d < this.config.plugins.length; d++)
                i.push(d < o ? { state: r, n: t.length } : { state: this, n: 0 });
            }
            t.push(c), r = r.applyInner(c), s = !0;
          }
          i && (i[o] = { state: r, n: t.length });
        }
      }
      if (!s)
        return { state: r, transactions: t };
    }
  }
  /**
  @internal
  */
  applyInner(e) {
    if (!e.before.eq(this.doc))
      throw new RangeError("Applying a mismatched transaction");
    let t = new Ir(this.config), r = this.config.fields;
    for (let i = 0; i < r.length; i++) {
      let s = r[i];
      t[s.name] = s.apply(e, this[s.name], this, t);
    }
    return t;
  }
  /**
  Start a [transaction](https://prosemirror.net/docs/ref/#state.Transaction) from this state.
  */
  get tr() {
    return new lb(this);
  }
  /**
  Create a new state.
  */
  static create(e) {
    let t = new ml(e.doc ? e.doc.type.schema : e.schema, e.plugins), r = new Ir(t);
    for (let i = 0; i < t.fields.length; i++)
      r[t.fields[i].name] = t.fields[i].init(e, r);
    return r;
  }
  /**
  Create a new state based on this one, but with an adjusted set
  of active plugins. State fields that exist in both sets of
  plugins are kept unchanged. Those that no longer exist are
  dropped, and those that are new are initialized using their
  [`init`](https://prosemirror.net/docs/ref/#state.StateField.init) method, passing in the new
  configuration object..
  */
  reconfigure(e) {
    let t = new ml(this.schema, e.plugins), r = t.fields, i = new Ir(t);
    for (let s = 0; s < r.length; s++) {
      let o = r[s].name;
      i[o] = this.hasOwnProperty(o) ? this[o] : r[s].init(e, i);
    }
    return i;
  }
  /**
  Serialize this state to JSON. If you want to serialize the state
  of plugins, pass an object mapping property names to use in the
  resulting JSON object to plugin objects. The argument may also be
  a string or number, in which case it is ignored, to support the
  way `JSON.stringify` calls `toString` methods.
  */
  toJSON(e) {
    let t = { doc: this.doc.toJSON(), selection: this.selection.toJSON() };
    if (this.storedMarks && (t.storedMarks = this.storedMarks.map((r) => r.toJSON())), e && typeof e == "object")
      for (let r in e) {
        if (r == "doc" || r == "selection")
          throw new RangeError("The JSON fields `doc` and `selection` are reserved");
        let i = e[r], s = i.spec.state;
        s && s.toJSON && (t[r] = s.toJSON.call(i, this[i.key]));
      }
    return t;
  }
  /**
  Deserialize a JSON representation of a state. `config` should
  have at least a `schema` field, and should contain array of
  plugins to initialize the state with. `pluginFields` can be used
  to deserialize the state of plugins, by associating plugin
  instances with the property names they use in the JSON object.
  */
  static fromJSON(e, t, r) {
    if (!t)
      throw new RangeError("Invalid input for EditorState.fromJSON");
    if (!e.schema)
      throw new RangeError("Required config field 'schema' missing");
    let i = new ml(e.schema, e.plugins), s = new Ir(i);
    return i.fields.forEach((o) => {
      if (o.name == "doc")
        s.doc = _t.fromJSON(e.schema, t.doc);
      else if (o.name == "selection")
        s.selection = re.fromJSON(s.doc, t.selection);
      else if (o.name == "storedMarks")
        t.storedMarks && (s.storedMarks = t.storedMarks.map(e.schema.markFromJSON));
      else {
        if (r)
          for (let l in r) {
            let a = r[l], u = a.spec.state;
            if (a.key == o.name && u && u.fromJSON && Object.prototype.hasOwnProperty.call(t, l)) {
              s[o.name] = u.fromJSON.call(a, e, t[l], s);
              return;
            }
          }
        s[o.name] = o.init(e, s);
      }
    }), s;
  }
}
function Xh(n, e, t) {
  for (let r in n) {
    let i = n[r];
    i instanceof Function ? i = i.bind(e) : r == "handleDOMEvents" && (i = Xh(i, e, {})), t[r] = i;
  }
  return t;
}
class Te {
  /**
  Create a plugin.
  */
  constructor(e) {
    this.spec = e, this.props = {}, e.props && Xh(e.props, this, this.props), this.key = e.key ? e.key.key : Zh("plugin");
  }
  /**
  Extract the plugin's state field from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const gl = /* @__PURE__ */ Object.create(null);
function Zh(n) {
  return n in gl ? n + "$" + ++gl[n] : (gl[n] = 0, n + "$");
}
class Ie {
  /**
  Create a plugin key.
  */
  constructor(e = "key") {
    this.key = Zh(e);
  }
  /**
  Get the active plugin with this key, if any, from an editor
  state.
  */
  get(e) {
    return e.config.pluginsByKey[this.key];
  }
  /**
  Get the plugin's state from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const Ve = function(n) {
  for (var e = 0; ; e++)
    if (n = n.previousSibling, !n)
      return e;
}, qr = function(n) {
  let e = n.assignedSlot || n.parentNode;
  return e && e.nodeType == 11 ? e.host : e;
};
let ta = null;
const vn = function(n, e, t) {
  let r = ta || (ta = document.createRange());
  return r.setEnd(n, t ?? n.nodeValue.length), r.setStart(n, e || 0), r;
}, ub = function() {
  ta = null;
}, pr = function(n, e, t, r) {
  return t && (ud(n, e, t, r, -1) || ud(n, e, t, r, 1));
}, cb = /^(img|br|input|textarea|hr)$/i;
function ud(n, e, t, r, i) {
  for (var s; ; ) {
    if (n == t && e == r)
      return !0;
    if (e == (i < 0 ? 0 : Ct(n))) {
      let o = n.parentNode;
      if (!o || o.nodeType != 1 || Ui(n) || cb.test(n.nodeName) || n.contentEditable == "false")
        return !1;
      e = Ve(n) + (i < 0 ? 0 : 1), n = o;
    } else if (n.nodeType == 1) {
      let o = n.childNodes[e + (i < 0 ? -1 : 0)];
      if (o.nodeType == 1 && o.contentEditable == "false")
        if (!((s = o.pmViewDesc) === null || s === void 0) && s.ignoreForSelection)
          e += i;
        else
          return !1;
      else
        n = o, e = i < 0 ? Ct(n) : 0;
    } else
      return !1;
  }
}
function Ct(n) {
  return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length;
}
function db(n, e) {
  for (; ; ) {
    if (n.nodeType == 3 && e)
      return n;
    if (n.nodeType == 1 && e > 0) {
      if (n.contentEditable == "false")
        return null;
      n = n.childNodes[e - 1], e = Ct(n);
    } else if (n.parentNode && !Ui(n))
      e = Ve(n), n = n.parentNode;
    else
      return null;
  }
}
function fb(n, e) {
  for (; ; ) {
    if (n.nodeType == 3 && e < n.nodeValue.length)
      return n;
    if (n.nodeType == 1 && e < n.childNodes.length) {
      if (n.contentEditable == "false")
        return null;
      n = n.childNodes[e], e = 0;
    } else if (n.parentNode && !Ui(n))
      e = Ve(n) + 1, n = n.parentNode;
    else
      return null;
  }
}
function hb(n, e, t) {
  for (let r = e == 0, i = e == Ct(n); r || i; ) {
    if (n == t)
      return !0;
    let s = Ve(n);
    if (n = n.parentNode, !n)
      return !1;
    r = r && s == 0, i = i && s == Ct(n);
  }
}
function Ui(n) {
  let e;
  for (let t = n; t && !(e = t.pmViewDesc); t = t.parentNode)
    ;
  return e && e.node && e.node.isBlock && (e.dom == n || e.contentDOM == n);
}
const No = function(n) {
  return n.focusNode && pr(n.focusNode, n.focusOffset, n.anchorNode, n.anchorOffset);
};
function er(n, e) {
  let t = document.createEvent("Event");
  return t.initEvent("keydown", !0, !0), t.keyCode = n, t.key = t.code = e, t;
}
function pb(n) {
  let e = n.activeElement;
  for (; e && e.shadowRoot; )
    e = e.shadowRoot.activeElement;
  return e;
}
function mb(n, e, t) {
  if (n.caretPositionFromPoint)
    try {
      let r = n.caretPositionFromPoint(e, t);
      if (r)
        return { node: r.offsetNode, offset: Math.min(Ct(r.offsetNode), r.offset) };
    } catch {
    }
  if (n.caretRangeFromPoint) {
    let r = n.caretRangeFromPoint(e, t);
    if (r)
      return { node: r.startContainer, offset: Math.min(Ct(r.startContainer), r.startOffset) };
  }
}
const an = typeof navigator < "u" ? navigator : null, cd = typeof document < "u" ? document : null, Gn = an && an.userAgent || "", na = /Edge\/(\d+)/.exec(Gn), Qh = /MSIE \d/.exec(Gn), ra = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(Gn), dt = !!(Qh || ra || na), qn = Qh ? document.documentMode : ra ? +ra[1] : na ? +na[1] : 0, Ut = !dt && /gecko\/(\d+)/i.test(Gn);
Ut && +(/Firefox\/(\d+)/.exec(Gn) || [0, 0])[1];
const ia = !dt && /Chrome\/(\d+)/.exec(Gn), Ze = !!ia, ep = ia ? +ia[1] : 0, st = !dt && !!an && /Apple Computer/.test(an.vendor), jr = st && (/Mobile\/\w+/.test(Gn) || !!an && an.maxTouchPoints > 2), St = jr || (an ? /Mac/.test(an.platform) : !1), gb = an ? /Win/.test(an.platform) : !1, wn = /Android \d/.test(Gn), Wi = !!cd && "webkitFontSmoothing" in cd.documentElement.style, _b = Wi ? +(/\bAppleWebKit\/(\d+)/.exec(navigator.userAgent) || [0, 0])[1] : 0;
function yb(n) {
  let e = n.defaultView && n.defaultView.visualViewport;
  return e ? {
    left: 0,
    right: e.width,
    top: 0,
    bottom: e.height
  } : {
    left: 0,
    right: n.documentElement.clientWidth,
    top: 0,
    bottom: n.documentElement.clientHeight
  };
}
function mn(n, e) {
  return typeof n == "number" ? n : n[e];
}
function bb(n) {
  let e = n.getBoundingClientRect(), t = e.width / n.offsetWidth || 1, r = e.height / n.offsetHeight || 1;
  return {
    left: e.left,
    right: e.left + n.clientWidth * t,
    top: e.top,
    bottom: e.top + n.clientHeight * r
  };
}
function dd(n, e, t) {
  let r = n.someProp("scrollThreshold") || 0, i = n.someProp("scrollMargin") || 5, s = n.dom.ownerDocument;
  for (let o = t || n.dom; o; ) {
    if (o.nodeType != 1) {
      o = qr(o);
      continue;
    }
    let l = o, a = l == s.body, u = a ? yb(s) : bb(l), c = 0, d = 0;
    if (e.top < u.top + mn(r, "top") ? d = -(u.top - e.top + mn(i, "top")) : e.bottom > u.bottom - mn(r, "bottom") && (d = e.bottom - e.top > u.bottom - u.top ? e.top + mn(i, "top") - u.top : e.bottom - u.bottom + mn(i, "bottom")), e.left < u.left + mn(r, "left") ? c = -(u.left - e.left + mn(i, "left")) : e.right > u.right - mn(r, "right") && (c = e.right - u.right + mn(i, "right")), c || d)
      if (a)
        s.defaultView.scrollBy(c, d);
      else {
        let h = l.scrollLeft, p = l.scrollTop;
        d && (l.scrollTop += d), c && (l.scrollLeft += c);
        let g = l.scrollLeft - h, _ = l.scrollTop - p;
        e = { left: e.left - g, top: e.top - _, right: e.right - g, bottom: e.bottom - _ };
      }
    let f = a ? "fixed" : getComputedStyle(o).position;
    if (/^(fixed|sticky)$/.test(f))
      break;
    o = f == "absolute" ? o.offsetParent : qr(o);
  }
}
function kb(n) {
  let e = n.dom.getBoundingClientRect(), t = Math.max(0, e.top), r, i;
  for (let s = (e.left + e.right) / 2, o = t + 1; o < Math.min(innerHeight, e.bottom); o += 5) {
    let l = n.root.elementFromPoint(s, o);
    if (!l || l == n.dom || !n.dom.contains(l))
      continue;
    let a = l.getBoundingClientRect();
    if (a.top >= t - 20) {
      r = l, i = a.top;
      break;
    }
  }
  return { refDOM: r, refTop: i, stack: tp(n.dom) };
}
function tp(n) {
  let e = [], t = n.ownerDocument;
  for (let r = n; r && (e.push({ dom: r, top: r.scrollTop, left: r.scrollLeft }), n != t); r = qr(r))
    ;
  return e;
}
function vb({ refDOM: n, refTop: e, stack: t }) {
  let r = n ? n.getBoundingClientRect().top : 0;
  np(t, r == 0 ? 0 : r - e);
}
function np(n, e) {
  for (let t = 0; t < n.length; t++) {
    let { dom: r, top: i, left: s } = n[t];
    r.scrollTop != i + e && (r.scrollTop = i + e), r.scrollLeft != s && (r.scrollLeft = s);
  }
}
let Tr = null;
function wb(n) {
  if (n.setActive)
    return n.setActive();
  if (Tr)
    return n.focus(Tr);
  let e = tp(n);
  n.focus(Tr == null ? {
    get preventScroll() {
      return Tr = { preventScroll: !0 }, !0;
    }
  } : void 0), Tr || (Tr = !1, np(e, 0));
}
function rp(n, e) {
  let t, r = 2e8, i, s = 0, o = e.top, l = e.top, a, u;
  for (let c = n.firstChild, d = 0; c; c = c.nextSibling, d++) {
    let f;
    if (c.nodeType == 1)
      f = c.getClientRects();
    else if (c.nodeType == 3)
      f = vn(c).getClientRects();
    else
      continue;
    for (let h = 0; h < f.length; h++) {
      let p = f[h];
      if (p.top <= o && p.bottom >= l) {
        o = Math.max(p.bottom, o), l = Math.min(p.top, l);
        let g = p.left > e.left ? p.left - e.left : p.right < e.left ? e.left - p.right : 0;
        if (g < r) {
          t = c, r = g, i = g && t.nodeType == 3 ? {
            left: p.right < e.left ? p.right : p.left,
            top: e.top
          } : e, c.nodeType == 1 && g && (s = d + (e.left >= (p.left + p.right) / 2 ? 1 : 0));
          continue;
        }
      } else p.top > e.top && !a && p.left <= e.left && p.right >= e.left && (a = c, u = { left: Math.max(p.left, Math.min(p.right, e.left)), top: p.top });
      !t && (e.left >= p.right && e.top >= p.top || e.left >= p.left && e.top >= p.bottom) && (s = d + 1);
    }
  }
  return !t && a && (t = a, i = u, r = 0), t && t.nodeType == 3 ? Eb(t, i) : !t || r && t.nodeType == 1 ? { node: n, offset: s } : rp(t, i);
}
function Eb(n, e) {
  let t = n.nodeValue.length, r = document.createRange();
  for (let i = 0; i < t; i++) {
    r.setEnd(n, i + 1), r.setStart(n, i);
    let s = Fn(r, 1);
    if (s.top != s.bottom && La(e, s))
      return { node: n, offset: i + (e.left >= (s.left + s.right) / 2 ? 1 : 0) };
  }
  return { node: n, offset: 0 };
}
function La(n, e) {
  return n.left >= e.left - 1 && n.left <= e.right + 1 && n.top >= e.top - 1 && n.top <= e.bottom + 1;
}
function Sb(n, e) {
  let t = n.parentNode;
  return t && /^li$/i.test(t.nodeName) && e.left < n.getBoundingClientRect().left ? t : n;
}
function Cb(n, e, t) {
  let { node: r, offset: i } = rp(e, t), s = -1;
  if (r.nodeType == 1 && !r.firstChild) {
    let o = r.getBoundingClientRect();
    s = o.left != o.right && t.left > (o.left + o.right) / 2 ? 1 : -1;
  }
  return n.docView.posFromDOM(r, i, s);
}
function Db(n, e, t, r) {
  let i = -1;
  for (let s = e, o = !1; s != n.dom; ) {
    let l = n.docView.nearestDesc(s, !0), a;
    if (!l)
      return null;
    if (l.dom.nodeType == 1 && (l.node.isBlock && l.parent || !l.contentDOM) && // Ignore elements with zero-size bounding rectangles
    ((a = l.dom.getBoundingClientRect()).width || a.height) && (l.node.isBlock && l.parent && !/^T(R|BODY|HEAD|FOOT)$/.test(l.dom.nodeName) && (!o && a.left > r.left || a.top > r.top ? i = l.posBefore : (!o && a.right < r.left || a.bottom < r.top) && (i = l.posAfter), o = !0), !l.contentDOM && i < 0 && !l.node.isText))
      return (l.node.isBlock ? r.top < (a.top + a.bottom) / 2 : r.left < (a.left + a.right) / 2) ? l.posBefore : l.posAfter;
    s = l.dom.parentNode;
  }
  return i > -1 ? i : n.docView.posFromDOM(e, t, -1);
}
function ip(n, e, t) {
  let r = n.childNodes.length;
  if (r && t.top < t.bottom)
    for (let i = Math.max(0, Math.min(r - 1, Math.floor(r * (e.top - t.top) / (t.bottom - t.top)) - 2)), s = i; ; ) {
      let o = n.childNodes[s];
      if (o.nodeType == 1) {
        let l = o.getClientRects();
        for (let a = 0; a < l.length; a++) {
          let u = l[a];
          if (La(e, u))
            return ip(o, e, u);
        }
      }
      if ((s = (s + 1) % r) == i)
        break;
    }
  return n;
}
function Ab(n, e) {
  let t = n.dom.ownerDocument, r, i = 0, s = mb(t, e.left, e.top);
  s && ({ node: r, offset: i } = s);
  let o = (n.root.elementFromPoint ? n.root : t).elementFromPoint(e.left, e.top), l;
  if (!o || !n.dom.contains(o.nodeType != 1 ? o.parentNode : o)) {
    let u = n.dom.getBoundingClientRect();
    if (!La(e, u) || (o = ip(n.dom, e, u), !o))
      return null;
  }
  if (st)
    for (let u = o; r && u; u = qr(u))
      u.draggable && (r = void 0);
  if (o = Sb(o, e), r) {
    if (Ut && r.nodeType == 1 && (i = Math.min(i, r.childNodes.length), i < r.childNodes.length)) {
      let c = r.childNodes[i], d;
      c.nodeName == "IMG" && (d = c.getBoundingClientRect()).right <= e.left && d.bottom > e.top && i++;
    }
    let u;
    Wi && i && r.nodeType == 1 && (u = r.childNodes[i - 1]).nodeType == 1 && u.contentEditable == "false" && u.getBoundingClientRect().top >= e.top && i--, r == n.dom && i == r.childNodes.length - 1 && r.lastChild.nodeType == 1 && e.top > r.lastChild.getBoundingClientRect().bottom ? l = n.state.doc.content.size : (i == 0 || r.nodeType != 1 || r.childNodes[i - 1].nodeName != "BR") && (l = Db(n, r, i, e));
  }
  l == null && (l = Cb(n, o, e));
  let a = n.docView.nearestDesc(o, !0);
  return { pos: l, inside: a ? a.posAtStart - a.border : -1 };
}
function fd(n) {
  return n.top < n.bottom || n.left < n.right;
}
function Fn(n, e) {
  let t = n.getClientRects();
  if (t.length) {
    let r = t[e < 0 ? 0 : t.length - 1];
    if (fd(r))
      return r;
  }
  return Array.prototype.find.call(t, fd) || n.getBoundingClientRect();
}
const Tb = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/;
function sp(n, e, t) {
  let { node: r, offset: i, atom: s } = n.docView.domFromPos(e, t < 0 ? -1 : 1), o = Wi || Ut;
  if (r.nodeType == 3)
    if (o && (Tb.test(r.nodeValue) || (t < 0 ? !i : i == r.nodeValue.length))) {
      let a = Fn(vn(r, i, i), t);
      if (Ut && i && /\s/.test(r.nodeValue[i - 1]) && i < r.nodeValue.length) {
        let u = Fn(vn(r, i - 1, i - 1), -1);
        if (u.top == a.top) {
          let c = Fn(vn(r, i, i + 1), -1);
          if (c.top != a.top)
            return li(c, c.left < u.left);
        }
      }
      return a;
    } else {
      let a = i, u = i, c = t < 0 ? 1 : -1;
      return t < 0 && !i ? (u++, c = -1) : t >= 0 && i == r.nodeValue.length ? (a--, c = 1) : t < 0 ? a-- : u++, li(Fn(vn(r, a, u), c), c < 0);
    }
  if (!n.state.doc.resolve(e - (s || 0)).parent.inlineContent) {
    if (s == null && i && (t < 0 || i == Ct(r))) {
      let a = r.childNodes[i - 1];
      if (a.nodeType == 1)
        return _l(a.getBoundingClientRect(), !1);
    }
    if (s == null && i < Ct(r)) {
      let a = r.childNodes[i];
      if (a.nodeType == 1)
        return _l(a.getBoundingClientRect(), !0);
    }
    return _l(r.getBoundingClientRect(), t >= 0);
  }
  if (s == null && i && (t < 0 || i == Ct(r))) {
    let a = r.childNodes[i - 1], u = a.nodeType == 3 ? vn(a, Ct(a) - (o ? 0 : 1)) : a.nodeType == 1 && (a.nodeName != "BR" || !a.nextSibling) ? a : null;
    if (u)
      return li(Fn(u, 1), !1);
  }
  if (s == null && i < Ct(r)) {
    let a = r.childNodes[i];
    for (; a.pmViewDesc && a.pmViewDesc.ignoreForCoords; )
      a = a.nextSibling;
    let u = a ? a.nodeType == 3 ? vn(a, 0, o ? 0 : 1) : a.nodeType == 1 ? a : null : null;
    if (u)
      return li(Fn(u, -1), !0);
  }
  return li(Fn(r.nodeType == 3 ? vn(r) : r, -t), t >= 0);
}
function li(n, e) {
  if (n.width == 0)
    return n;
  let t = e ? n.left : n.right;
  return { top: n.top, bottom: n.bottom, left: t, right: t };
}
function _l(n, e) {
  if (n.height == 0)
    return n;
  let t = e ? n.top : n.bottom;
  return { top: t, bottom: t, left: n.left, right: n.right };
}
function op(n, e, t) {
  let r = n.state, i = n.root.activeElement;
  r != e && n.updateState(e), i != n.dom && n.focus();
  try {
    return t();
  } finally {
    r != e && n.updateState(r), i != n.dom && i && i.focus();
  }
}
function xb(n, e, t) {
  let r = e.selection, i = t == "up" ? r.$from : r.$to;
  return op(n, e, () => {
    let { node: s } = n.docView.domFromPos(i.pos, t == "up" ? -1 : 1);
    for (; ; ) {
      let l = n.docView.nearestDesc(s, !0);
      if (!l)
        break;
      if (l.node.isBlock) {
        s = l.contentDOM || l.dom;
        break;
      }
      s = l.dom.parentNode;
    }
    let o = sp(n, i.pos, 1);
    for (let l = s.firstChild; l; l = l.nextSibling) {
      let a;
      if (l.nodeType == 1)
        a = l.getClientRects();
      else if (l.nodeType == 3)
        a = vn(l, 0, l.nodeValue.length).getClientRects();
      else
        continue;
      for (let u = 0; u < a.length; u++) {
        let c = a[u];
        if (c.bottom > c.top + 1 && (t == "up" ? o.top - c.top > (c.bottom - o.top) * 2 : c.bottom - o.bottom > (o.bottom - c.top) * 2))
          return !1;
      }
    }
    return !0;
  });
}
const Mb = /[\u0590-\u08ac]/;
function $b(n, e, t) {
  let { $head: r } = e.selection;
  if (!r.parent.isTextblock)
    return !1;
  let i = r.parentOffset, s = !i, o = i == r.parent.content.size, l = n.domSelection();
  return l ? !Mb.test(r.parent.textContent) || !l.modify ? t == "left" || t == "backward" ? s : o : op(n, e, () => {
    let { focusNode: a, focusOffset: u, anchorNode: c, anchorOffset: d } = n.domSelectionRange(), f = l.caretBidiLevel;
    l.modify("move", t, "character");
    let h = r.depth ? n.docView.domAfterPos(r.before()) : n.dom, { focusNode: p, focusOffset: g } = n.domSelectionRange(), _ = p && !h.contains(p.nodeType == 1 ? p : p.parentNode) || a == p && u == g;
    try {
      l.collapse(c, d), a && (a != c || u != d) && l.extend && l.extend(a, u);
    } catch {
    }
    return f != null && (l.caretBidiLevel = f), _;
  }) : r.pos == r.start() || r.pos == r.end();
}
let hd = null, pd = null, md = !1;
function Fb(n, e, t) {
  return hd == e && pd == t ? md : (hd = e, pd = t, md = t == "up" || t == "down" ? xb(n, e, t) : $b(n, e, t));
}
const Tt = 0, gd = 1, nr = 2, un = 3;
class Ki {
  constructor(e, t, r, i) {
    this.parent = e, this.children = t, this.dom = r, this.contentDOM = i, this.dirty = Tt, r.pmViewDesc = this;
  }
  // Used to check whether a given description corresponds to a
  // widget/mark/node.
  matchesWidget(e) {
    return !1;
  }
  matchesMark(e) {
    return !1;
  }
  matchesNode(e, t, r) {
    return !1;
  }
  matchesHack(e) {
    return !1;
  }
  // When parsing in-editor content (in domchange.js), we allow
  // descriptions to determine the parse rules that should be used to
  // parse them.
  parseRule() {
    return null;
  }
  // Used by the editor's event handler to ignore events that come
  // from certain descs.
  stopEvent(e) {
    return !1;
  }
  // The size of the content represented by this desc.
  get size() {
    let e = 0;
    for (let t = 0; t < this.children.length; t++)
      e += this.children[t].size;
    return e;
  }
  // For block nodes, this represents the space taken up by their
  // start/end tokens.
  get border() {
    return 0;
  }
  destroy() {
    this.parent = void 0, this.dom.pmViewDesc == this && (this.dom.pmViewDesc = void 0);
    for (let e = 0; e < this.children.length; e++)
      this.children[e].destroy();
  }
  posBeforeChild(e) {
    for (let t = 0, r = this.posAtStart; ; t++) {
      let i = this.children[t];
      if (i == e)
        return r;
      r += i.size;
    }
  }
  get posBefore() {
    return this.parent.posBeforeChild(this);
  }
  get posAtStart() {
    return this.parent ? this.parent.posBeforeChild(this) + this.border : 0;
  }
  get posAfter() {
    return this.posBefore + this.size;
  }
  get posAtEnd() {
    return this.posAtStart + this.size - 2 * this.border;
  }
  localPosFromDOM(e, t, r) {
    if (this.contentDOM && this.contentDOM.contains(e.nodeType == 1 ? e : e.parentNode))
      if (r < 0) {
        let s, o;
        if (e == this.contentDOM)
          s = e.childNodes[t - 1];
        else {
          for (; e.parentNode != this.contentDOM; )
            e = e.parentNode;
          s = e.previousSibling;
        }
        for (; s && !((o = s.pmViewDesc) && o.parent == this); )
          s = s.previousSibling;
        return s ? this.posBeforeChild(o) + o.size : this.posAtStart;
      } else {
        let s, o;
        if (e == this.contentDOM)
          s = e.childNodes[t];
        else {
          for (; e.parentNode != this.contentDOM; )
            e = e.parentNode;
          s = e.nextSibling;
        }
        for (; s && !((o = s.pmViewDesc) && o.parent == this); )
          s = s.nextSibling;
        return s ? this.posBeforeChild(o) : this.posAtEnd;
      }
    let i;
    if (e == this.dom && this.contentDOM)
      i = t > Ve(this.contentDOM);
    else if (this.contentDOM && this.contentDOM != this.dom && this.dom.contains(this.contentDOM))
      i = e.compareDocumentPosition(this.contentDOM) & 2;
    else if (this.dom.firstChild) {
      if (t == 0)
        for (let s = e; ; s = s.parentNode) {
          if (s == this.dom) {
            i = !1;
            break;
          }
          if (s.previousSibling)
            break;
        }
      if (i == null && t == e.childNodes.length)
        for (let s = e; ; s = s.parentNode) {
          if (s == this.dom) {
            i = !0;
            break;
          }
          if (s.nextSibling)
            break;
        }
    }
    return i ?? r > 0 ? this.posAtEnd : this.posAtStart;
  }
  nearestDesc(e, t = !1) {
    for (let r = !0, i = e; i; i = i.parentNode) {
      let s = this.getDesc(i), o;
      if (s && (!t || s.node))
        if (r && (o = s.nodeDOM) && !(o.nodeType == 1 ? o.contains(e.nodeType == 1 ? e : e.parentNode) : o == e))
          r = !1;
        else
          return s;
    }
  }
  getDesc(e) {
    let t = e.pmViewDesc;
    for (let r = t; r; r = r.parent)
      if (r == this)
        return t;
  }
  posFromDOM(e, t, r) {
    for (let i = e; i; i = i.parentNode) {
      let s = this.getDesc(i);
      if (s)
        return s.localPosFromDOM(e, t, r);
    }
    return -1;
  }
  // Find the desc for the node after the given pos, if any. (When a
  // parent node overrode rendering, there might not be one.)
  descAt(e) {
    for (let t = 0, r = 0; t < this.children.length; t++) {
      let i = this.children[t], s = r + i.size;
      if (r == e && s != r) {
        for (; !i.border && i.children.length; )
          for (let o = 0; o < i.children.length; o++) {
            let l = i.children[o];
            if (l.size) {
              i = l;
              break;
            }
          }
        return i;
      }
      if (e < s)
        return i.descAt(e - r - i.border);
      r = s;
    }
  }
  domFromPos(e, t) {
    if (!this.contentDOM)
      return { node: this.dom, offset: 0, atom: e + 1 };
    let r = 0, i = 0;
    for (let s = 0; r < this.children.length; r++) {
      let o = this.children[r], l = s + o.size;
      if (l > e || o instanceof ap) {
        i = e - s;
        break;
      }
      s = l;
    }
    if (i)
      return this.children[r].domFromPos(i - this.children[r].border, t);
    for (let s; r && !(s = this.children[r - 1]).size && s instanceof lp && s.side >= 0; r--)
      ;
    if (t <= 0) {
      let s, o = !0;
      for (; s = r ? this.children[r - 1] : null, !(!s || s.dom.parentNode == this.contentDOM); r--, o = !1)
        ;
      return s && t && o && !s.border && !s.domAtom ? s.domFromPos(s.size, t) : { node: this.contentDOM, offset: s ? Ve(s.dom) + 1 : 0 };
    } else {
      let s, o = !0;
      for (; s = r < this.children.length ? this.children[r] : null, !(!s || s.dom.parentNode == this.contentDOM); r++, o = !1)
        ;
      return s && o && !s.border && !s.domAtom ? s.domFromPos(0, t) : { node: this.contentDOM, offset: s ? Ve(s.dom) : this.contentDOM.childNodes.length };
    }
  }
  // Used to find a DOM range in a single parent for a given changed
  // range.
  parseRange(e, t, r = 0) {
    if (this.children.length == 0)
      return { node: this.contentDOM, from: e, to: t, fromOffset: 0, toOffset: this.contentDOM.childNodes.length };
    let i = -1, s = -1;
    for (let o = r, l = 0; ; l++) {
      let a = this.children[l], u = o + a.size;
      if (i == -1 && e <= u) {
        let c = o + a.border;
        if (e >= c && t <= u - a.border && a.node && a.contentDOM && this.contentDOM.contains(a.contentDOM))
          return a.parseRange(e, t, c);
        e = o;
        for (let d = l; d > 0; d--) {
          let f = this.children[d - 1];
          if (f.size && f.dom.parentNode == this.contentDOM && !f.emptyChildAt(1)) {
            i = Ve(f.dom) + 1;
            break;
          }
          e -= f.size;
        }
        i == -1 && (i = 0);
      }
      if (i > -1 && (u > t || l == this.children.length - 1)) {
        t = u;
        for (let c = l + 1; c < this.children.length; c++) {
          let d = this.children[c];
          if (d.size && d.dom.parentNode == this.contentDOM && !d.emptyChildAt(-1)) {
            s = Ve(d.dom);
            break;
          }
          t += d.size;
        }
        s == -1 && (s = this.contentDOM.childNodes.length);
        break;
      }
      o = u;
    }
    return { node: this.contentDOM, from: e, to: t, fromOffset: i, toOffset: s };
  }
  emptyChildAt(e) {
    if (this.border || !this.contentDOM || !this.children.length)
      return !1;
    let t = this.children[e < 0 ? 0 : this.children.length - 1];
    return t.size == 0 || t.emptyChildAt(e);
  }
  domAfterPos(e) {
    let { node: t, offset: r } = this.domFromPos(e, 0);
    if (t.nodeType != 1 || r == t.childNodes.length)
      throw new RangeError("No node after pos " + e);
    return t.childNodes[r];
  }
  // View descs are responsible for setting any selection that falls
  // entirely inside of them, so that custom implementations can do
  // custom things with the selection. Note that this falls apart when
  // a selection starts in such a node and ends in another, in which
  // case we just use whatever domFromPos produces as a best effort.
  setSelection(e, t, r, i = !1) {
    let s = Math.min(e, t), o = Math.max(e, t);
    for (let h = 0, p = 0; h < this.children.length; h++) {
      let g = this.children[h], _ = p + g.size;
      if (s > p && o < _)
        return g.setSelection(e - p - g.border, t - p - g.border, r, i);
      p = _;
    }
    let l = this.domFromPos(e, e ? -1 : 1), a = t == e ? l : this.domFromPos(t, t ? -1 : 1), u = r.root.getSelection(), c = r.domSelectionRange(), d = !1;
    if ((Ut || st) && e == t) {
      let { node: h, offset: p } = l;
      if (h.nodeType == 3) {
        if (d = !!(p && h.nodeValue[p - 1] == `
`), d && p == h.nodeValue.length)
          for (let g = h, _; g; g = g.parentNode) {
            if (_ = g.nextSibling) {
              _.nodeName == "BR" && (l = a = { node: _.parentNode, offset: Ve(_) + 1 });
              break;
            }
            let k = g.pmViewDesc;
            if (k && k.node && k.node.isBlock)
              break;
          }
      } else {
        let g = h.childNodes[p - 1];
        d = g && (g.nodeName == "BR" || g.contentEditable == "false");
      }
    }
    if (Ut && c.focusNode && c.focusNode != a.node && c.focusNode.nodeType == 1) {
      let h = c.focusNode.childNodes[c.focusOffset];
      h && h.contentEditable == "false" && (i = !0);
    }
    if (!(i || d && st) && pr(l.node, l.offset, c.anchorNode, c.anchorOffset) && pr(a.node, a.offset, c.focusNode, c.focusOffset))
      return;
    let f = !1;
    if ((u.extend || e == t) && !d) {
      u.collapse(l.node, l.offset);
      try {
        e != t && u.extend(a.node, a.offset), f = !0;
      } catch {
      }
    }
    if (!f) {
      if (e > t) {
        let p = l;
        l = a, a = p;
      }
      let h = document.createRange();
      h.setEnd(a.node, a.offset), h.setStart(l.node, l.offset), u.removeAllRanges(), u.addRange(h);
    }
  }
  ignoreMutation(e) {
    return !this.contentDOM && e.type != "selection";
  }
  get contentLost() {
    return this.contentDOM && this.contentDOM != this.dom && !this.dom.contains(this.contentDOM);
  }
  // Remove a subtree of the element tree that has been touched
  // by a DOM change, so that the next update will redraw it.
  markDirty(e, t) {
    for (let r = 0, i = 0; i < this.children.length; i++) {
      let s = this.children[i], o = r + s.size;
      if (r == o ? e <= o && t >= r : e < o && t > r) {
        let l = r + s.border, a = o - s.border;
        if (e >= l && t <= a) {
          this.dirty = e == r || t == o ? nr : gd, e == l && t == a && (s.contentLost || s.dom.parentNode != this.contentDOM) ? s.dirty = un : s.markDirty(e - l, t - l);
          return;
        } else
          s.dirty = s.dom == s.contentDOM && s.dom.parentNode == this.contentDOM && !s.children.length ? nr : un;
      }
      r = o;
    }
    this.dirty = nr;
  }
  markParentsDirty() {
    let e = 1;
    for (let t = this.parent; t; t = t.parent, e++) {
      let r = e == 1 ? nr : gd;
      t.dirty < r && (t.dirty = r);
    }
  }
  get domAtom() {
    return !1;
  }
  get ignoreForCoords() {
    return !1;
  }
  get ignoreForSelection() {
    return !1;
  }
  isText(e) {
    return !1;
  }
}
class lp extends Ki {
  constructor(e, t, r, i) {
    let s, o = t.type.toDOM;
    if (typeof o == "function" && (o = o(r, () => {
      if (!s)
        return i;
      if (s.parent)
        return s.parent.posBeforeChild(s);
    })), !t.type.spec.raw) {
      if (o.nodeType != 1) {
        let l = document.createElement("span");
        l.appendChild(o), o = l;
      }
      o.contentEditable = "false", o.classList.add("ProseMirror-widget");
    }
    super(e, [], o, null), this.widget = t, this.widget = t, s = this;
  }
  matchesWidget(e) {
    return this.dirty == Tt && e.type.eq(this.widget.type);
  }
  parseRule() {
    return { ignore: !0 };
  }
  stopEvent(e) {
    let t = this.widget.spec.stopEvent;
    return t ? t(e) : !1;
  }
  ignoreMutation(e) {
    return e.type != "selection" || this.widget.spec.ignoreSelection;
  }
  destroy() {
    this.widget.type.destroy(this.dom), super.destroy();
  }
  get domAtom() {
    return !0;
  }
  get ignoreForSelection() {
    return !!this.widget.type.spec.relaxedSide;
  }
  get side() {
    return this.widget.type.side;
  }
}
class Ob extends Ki {
  constructor(e, t, r, i) {
    super(e, [], t, null), this.textDOM = r, this.text = i;
  }
  get size() {
    return this.text.length;
  }
  localPosFromDOM(e, t) {
    return e != this.textDOM ? this.posAtStart + (t ? this.size : 0) : this.posAtStart + t;
  }
  domFromPos(e) {
    return { node: this.textDOM, offset: e };
  }
  ignoreMutation(e) {
    return e.type === "characterData" && e.target.nodeValue == e.oldValue;
  }
}
class mr extends Ki {
  constructor(e, t, r, i, s) {
    super(e, [], r, i), this.mark = t, this.spec = s;
  }
  static create(e, t, r, i) {
    let s = i.nodeViews[t.type.name], o = s && s(t, i, r);
    return (!o || !o.dom) && (o = br.renderSpec(document, t.type.spec.toDOM(t, r), null, t.attrs)), new mr(e, t, o.dom, o.contentDOM || o.dom, o);
  }
  parseRule() {
    return this.dirty & un || this.mark.type.spec.reparseInView ? null : { mark: this.mark.type.name, attrs: this.mark.attrs, contentElement: this.contentDOM };
  }
  matchesMark(e) {
    return this.dirty != un && this.mark.eq(e);
  }
  markDirty(e, t) {
    if (super.markDirty(e, t), this.dirty != Tt) {
      let r = this.parent;
      for (; !r.node; )
        r = r.parent;
      r.dirty < this.dirty && (r.dirty = this.dirty), this.dirty = Tt;
    }
  }
  slice(e, t, r) {
    let i = mr.create(this.parent, this.mark, !0, r), s = this.children, o = this.size;
    t < o && (s = oa(s, t, o, r)), e > 0 && (s = oa(s, 0, e, r));
    for (let l = 0; l < s.length; l++)
      s[l].parent = i;
    return i.children = s, i;
  }
  ignoreMutation(e) {
    return this.spec.ignoreMutation ? this.spec.ignoreMutation(e) : super.ignoreMutation(e);
  }
  destroy() {
    this.spec.destroy && this.spec.destroy(), super.destroy();
  }
}
class jn extends Ki {
  constructor(e, t, r, i, s, o, l, a, u) {
    super(e, [], s, o), this.node = t, this.outerDeco = r, this.innerDeco = i, this.nodeDOM = l;
  }
  // By default, a node is rendered using the `toDOM` method from the
  // node type spec. But client code can use the `nodeViews` spec to
  // supply a custom node view, which can influence various aspects of
  // the way the node works.
  //
  // (Using subclassing for this was intentionally decided against,
  // since it'd require exposing a whole slew of finicky
  // implementation details to the user code that they probably will
  // never need.)
  static create(e, t, r, i, s, o) {
    let l = s.nodeViews[t.type.name], a, u = l && l(t, s, () => {
      if (!a)
        return o;
      if (a.parent)
        return a.parent.posBeforeChild(a);
    }, r, i), c = u && u.dom, d = u && u.contentDOM;
    if (t.isText) {
      if (!c)
        c = document.createTextNode(t.text);
      else if (c.nodeType != 3)
        throw new RangeError("Text must be rendered as a DOM text node");
    } else c || ({ dom: c, contentDOM: d } = br.renderSpec(document, t.type.spec.toDOM(t), null, t.attrs));
    !d && !t.isText && c.nodeName != "BR" && (c.hasAttribute("contenteditable") || (c.contentEditable = "false"), t.type.spec.draggable && (c.draggable = !0));
    let f = c;
    return c = dp(c, r, t), u ? a = new Nb(e, t, r, i, c, d || null, f, u, s, o + 1) : t.isText ? new Ro(e, t, r, i, c, f, s) : new jn(e, t, r, i, c, d || null, f, s, o + 1);
  }
  parseRule() {
    if (this.node.type.spec.reparseInView)
      return null;
    let e = { node: this.node.type.name, attrs: this.node.attrs };
    if (this.node.type.whitespace == "pre" && (e.preserveWhitespace = "full"), !this.contentDOM)
      e.getContent = () => this.node.content;
    else if (!this.contentLost)
      e.contentElement = this.contentDOM;
    else {
      for (let t = this.children.length - 1; t >= 0; t--) {
        let r = this.children[t];
        if (this.dom.contains(r.dom.parentNode)) {
          e.contentElement = r.dom.parentNode;
          break;
        }
      }
      e.contentElement || (e.getContent = () => F.empty);
    }
    return e;
  }
  matchesNode(e, t, r) {
    return this.dirty == Tt && e.eq(this.node) && Us(t, this.outerDeco) && r.eq(this.innerDeco);
  }
  get size() {
    return this.node.nodeSize;
  }
  get border() {
    return this.node.isLeaf ? 0 : 1;
  }
  // Syncs `this.children` to match `this.node.content` and the local
  // decorations, possibly introducing nesting for marks. Then, in a
  // separate step, syncs the DOM inside `this.contentDOM` to
  // `this.children`.
  updateChildren(e, t) {
    let r = this.node.inlineContent, i = t, s = e.composing ? this.localCompositionInfo(e, t) : null, o = s && s.pos > -1 ? s : null, l = s && s.pos < 0, a = new Ib(this, o && o.node, e);
    Bb(this.node, this.innerDeco, (u, c, d) => {
      u.spec.marks ? a.syncToMarks(u.spec.marks, r, e) : u.type.side >= 0 && !d && a.syncToMarks(c == this.node.childCount ? be.none : this.node.child(c).marks, r, e), a.placeWidget(u, e, i);
    }, (u, c, d, f) => {
      a.syncToMarks(u.marks, r, e);
      let h;
      a.findNodeMatch(u, c, d, f) || l && e.state.selection.from > i && e.state.selection.to < i + u.nodeSize && (h = a.findIndexWithChild(s.node)) > -1 && a.updateNodeAt(u, c, d, h, e) || a.updateNextNode(u, c, d, e, f, i) || a.addNode(u, c, d, e, i), i += u.nodeSize;
    }), a.syncToMarks([], r, e), this.node.isTextblock && a.addTextblockHacks(), a.destroyRest(), (a.changed || this.dirty == nr) && (o && this.protectLocalComposition(e, o), up(this.contentDOM, this.children, e), jr && zb(this.dom));
  }
  localCompositionInfo(e, t) {
    let { from: r, to: i } = e.state.selection;
    if (!(e.state.selection instanceof Z) || r < t || i > t + this.node.content.size)
      return null;
    let s = e.input.compositionNode;
    if (!s || !this.dom.contains(s.parentNode))
      return null;
    if (this.node.inlineContent) {
      let o = s.nodeValue, l = Hb(this.node.content, o, r - t, i - t);
      return l < 0 ? null : { node: s, pos: l, text: o };
    } else
      return { node: s, pos: -1, text: "" };
  }
  protectLocalComposition(e, { node: t, pos: r, text: i }) {
    if (this.getDesc(t))
      return;
    let s = t;
    for (; s.parentNode != this.contentDOM; s = s.parentNode) {
      for (; s.previousSibling; )
        s.parentNode.removeChild(s.previousSibling);
      for (; s.nextSibling; )
        s.parentNode.removeChild(s.nextSibling);
      s.pmViewDesc && (s.pmViewDesc = void 0);
    }
    let o = new Ob(this, s, t, i);
    e.input.compositionNodes.push(o), this.children = oa(this.children, r, r + i.length, e, o);
  }
  // If this desc must be updated to match the given node decoration,
  // do so and return true.
  update(e, t, r, i) {
    return this.dirty == un || !e.sameMarkup(this.node) ? !1 : (this.updateInner(e, t, r, i), !0);
  }
  updateInner(e, t, r, i) {
    this.updateOuterDeco(t), this.node = e, this.innerDeco = r, this.contentDOM && this.updateChildren(i, this.posAtStart), this.dirty = Tt;
  }
  updateOuterDeco(e) {
    if (Us(e, this.outerDeco))
      return;
    let t = this.nodeDOM.nodeType != 1, r = this.dom;
    this.dom = cp(this.dom, this.nodeDOM, sa(this.outerDeco, this.node, t), sa(e, this.node, t)), this.dom != r && (r.pmViewDesc = void 0, this.dom.pmViewDesc = this), this.outerDeco = e;
  }
  // Mark this node as being the selected node.
  selectNode() {
    this.nodeDOM.nodeType == 1 && this.nodeDOM.classList.add("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && (this.dom.draggable = !0);
  }
  // Remove selected node marking from this node.
  deselectNode() {
    this.nodeDOM.nodeType == 1 && (this.nodeDOM.classList.remove("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && this.dom.removeAttribute("draggable"));
  }
  get domAtom() {
    return this.node.isAtom;
  }
}
function _d(n, e, t, r, i) {
  dp(r, e, n);
  let s = new jn(void 0, n, e, t, r, r, r, i, 0);
  return s.contentDOM && s.updateChildren(i, 0), s;
}
class Ro extends jn {
  constructor(e, t, r, i, s, o, l) {
    super(e, t, r, i, s, null, o, l, 0);
  }
  parseRule() {
    let e = this.nodeDOM.parentNode;
    for (; e && e != this.dom && !e.pmIsDeco; )
      e = e.parentNode;
    return { skip: e || !0 };
  }
  update(e, t, r, i) {
    return this.dirty == un || this.dirty != Tt && !this.inParent() || !e.sameMarkup(this.node) ? !1 : (this.updateOuterDeco(t), (this.dirty != Tt || e.text != this.node.text) && e.text != this.nodeDOM.nodeValue && (this.nodeDOM.nodeValue = e.text, i.trackWrites == this.nodeDOM && (i.trackWrites = null)), this.node = e, this.dirty = Tt, !0);
  }
  inParent() {
    let e = this.parent.contentDOM;
    for (let t = this.nodeDOM; t; t = t.parentNode)
      if (t == e)
        return !0;
    return !1;
  }
  domFromPos(e) {
    return { node: this.nodeDOM, offset: e };
  }
  localPosFromDOM(e, t, r) {
    return e == this.nodeDOM ? this.posAtStart + Math.min(t, this.node.text.length) : super.localPosFromDOM(e, t, r);
  }
  ignoreMutation(e) {
    return e.type != "characterData" && e.type != "selection";
  }
  slice(e, t, r) {
    let i = this.node.cut(e, t), s = document.createTextNode(i.text);
    return new Ro(this.parent, i, this.outerDeco, this.innerDeco, s, s, r);
  }
  markDirty(e, t) {
    super.markDirty(e, t), this.dom != this.nodeDOM && (e == 0 || t == this.nodeDOM.nodeValue.length) && (this.dirty = un);
  }
  get domAtom() {
    return !1;
  }
  isText(e) {
    return this.node.text == e;
  }
}
class ap extends Ki {
  parseRule() {
    return { ignore: !0 };
  }
  matchesHack(e) {
    return this.dirty == Tt && this.dom.nodeName == e;
  }
  get domAtom() {
    return !0;
  }
  get ignoreForCoords() {
    return this.dom.nodeName == "IMG";
  }
}
class Nb extends jn {
  constructor(e, t, r, i, s, o, l, a, u, c) {
    super(e, t, r, i, s, o, l, u, c), this.spec = a;
  }
  // A custom `update` method gets to decide whether the update goes
  // through. If it does, and there's a `contentDOM` node, our logic
  // updates the children.
  update(e, t, r, i) {
    if (this.dirty == un)
      return !1;
    if (this.spec.update && (this.node.type == e.type || this.spec.multiType)) {
      let s = this.spec.update(e, t, r);
      return s && this.updateInner(e, t, r, i), s;
    } else return !this.contentDOM && !e.isLeaf ? !1 : super.update(e, t, r, i);
  }
  selectNode() {
    this.spec.selectNode ? this.spec.selectNode() : super.selectNode();
  }
  deselectNode() {
    this.spec.deselectNode ? this.spec.deselectNode() : super.deselectNode();
  }
  setSelection(e, t, r, i) {
    this.spec.setSelection ? this.spec.setSelection(e, t, r.root) : super.setSelection(e, t, r, i);
  }
  destroy() {
    this.spec.destroy && this.spec.destroy(), super.destroy();
  }
  stopEvent(e) {
    return this.spec.stopEvent ? this.spec.stopEvent(e) : !1;
  }
  ignoreMutation(e) {
    return this.spec.ignoreMutation ? this.spec.ignoreMutation(e) : super.ignoreMutation(e);
  }
}
function up(n, e, t) {
  let r = n.firstChild, i = !1;
  for (let s = 0; s < e.length; s++) {
    let o = e[s], l = o.dom;
    if (l.parentNode == n) {
      for (; l != r; )
        r = yd(r), i = !0;
      r = r.nextSibling;
    } else
      i = !0, n.insertBefore(l, r);
    if (o instanceof mr) {
      let a = r ? r.previousSibling : n.lastChild;
      up(o.contentDOM, o.children, t), r = a ? a.nextSibling : n.firstChild;
    }
  }
  for (; r; )
    r = yd(r), i = !0;
  i && t.trackWrites == n && (t.trackWrites = null);
}
const Ei = function(n) {
  n && (this.nodeName = n);
};
Ei.prototype = /* @__PURE__ */ Object.create(null);
const rr = [new Ei()];
function sa(n, e, t) {
  if (n.length == 0)
    return rr;
  let r = t ? rr[0] : new Ei(), i = [r];
  for (let s = 0; s < n.length; s++) {
    let o = n[s].type.attrs;
    if (o) {
      o.nodeName && i.push(r = new Ei(o.nodeName));
      for (let l in o) {
        let a = o[l];
        a != null && (t && i.length == 1 && i.push(r = new Ei(e.isInline ? "span" : "div")), l == "class" ? r.class = (r.class ? r.class + " " : "") + a : l == "style" ? r.style = (r.style ? r.style + ";" : "") + a : l != "nodeName" && (r[l] = a));
      }
    }
  }
  return i;
}
function cp(n, e, t, r) {
  if (t == rr && r == rr)
    return e;
  let i = e;
  for (let s = 0; s < r.length; s++) {
    let o = r[s], l = t[s];
    if (s) {
      let a;
      l && l.nodeName == o.nodeName && i != n && (a = i.parentNode) && a.nodeName.toLowerCase() == o.nodeName || (a = document.createElement(o.nodeName), a.pmIsDeco = !0, a.appendChild(i), l = rr[0]), i = a;
    }
    Rb(i, l || rr[0], o);
  }
  return i;
}
function Rb(n, e, t) {
  for (let r in e)
    r != "class" && r != "style" && r != "nodeName" && !(r in t) && n.removeAttribute(r);
  for (let r in t)
    r != "class" && r != "style" && r != "nodeName" && t[r] != e[r] && n.setAttribute(r, t[r]);
  if (e.class != t.class) {
    let r = e.class ? e.class.split(" ").filter(Boolean) : [], i = t.class ? t.class.split(" ").filter(Boolean) : [];
    for (let s = 0; s < r.length; s++)
      i.indexOf(r[s]) == -1 && n.classList.remove(r[s]);
    for (let s = 0; s < i.length; s++)
      r.indexOf(i[s]) == -1 && n.classList.add(i[s]);
    n.classList.length == 0 && n.removeAttribute("class");
  }
  if (e.style != t.style) {
    if (e.style) {
      let r = /\s*([\w\-\xa1-\uffff]+)\s*:(?:"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\(.*?\)|[^;])*/g, i;
      for (; i = r.exec(e.style); )
        n.style.removeProperty(i[1]);
    }
    t.style && (n.style.cssText += t.style);
  }
}
function dp(n, e, t) {
  return cp(n, n, rr, sa(e, t, n.nodeType != 1));
}
function Us(n, e) {
  if (n.length != e.length)
    return !1;
  for (let t = 0; t < n.length; t++)
    if (!n[t].type.eq(e[t].type))
      return !1;
  return !0;
}
function yd(n) {
  let e = n.nextSibling;
  return n.parentNode.removeChild(n), e;
}
class Ib {
  constructor(e, t, r) {
    this.lock = t, this.view = r, this.index = 0, this.stack = [], this.changed = !1, this.top = e, this.preMatch = Lb(e.node.content, e);
  }
  // Destroy and remove the children between the given indices in
  // `this.top`.
  destroyBetween(e, t) {
    if (e != t) {
      for (let r = e; r < t; r++)
        this.top.children[r].destroy();
      this.top.children.splice(e, t - e), this.changed = !0;
    }
  }
  // Destroy all remaining children in `this.top`.
  destroyRest() {
    this.destroyBetween(this.index, this.top.children.length);
  }
  // Sync the current stack of mark descs with the given array of
  // marks, reusing existing mark descs when possible.
  syncToMarks(e, t, r) {
    let i = 0, s = this.stack.length >> 1, o = Math.min(s, e.length);
    for (; i < o && (i == s - 1 ? this.top : this.stack[i + 1 << 1]).matchesMark(e[i]) && e[i].type.spec.spanning !== !1; )
      i++;
    for (; i < s; )
      this.destroyRest(), this.top.dirty = Tt, this.index = this.stack.pop(), this.top = this.stack.pop(), s--;
    for (; s < e.length; ) {
      this.stack.push(this.top, this.index + 1);
      let l = -1;
      for (let a = this.index; a < Math.min(this.index + 3, this.top.children.length); a++) {
        let u = this.top.children[a];
        if (u.matchesMark(e[s]) && !this.isLocked(u.dom)) {
          l = a;
          break;
        }
      }
      if (l > -1)
        l > this.index && (this.changed = !0, this.destroyBetween(this.index, l)), this.top = this.top.children[this.index];
      else {
        let a = mr.create(this.top, e[s], t, r);
        this.top.children.splice(this.index, 0, a), this.top = a, this.changed = !0;
      }
      this.index = 0, s++;
    }
  }
  // Try to find a node desc matching the given data. Skip over it and
  // return true when successful.
  findNodeMatch(e, t, r, i) {
    let s = -1, o;
    if (i >= this.preMatch.index && (o = this.preMatch.matches[i - this.preMatch.index]).parent == this.top && o.matchesNode(e, t, r))
      s = this.top.children.indexOf(o, this.index);
    else
      for (let l = this.index, a = Math.min(this.top.children.length, l + 5); l < a; l++) {
        let u = this.top.children[l];
        if (u.matchesNode(e, t, r) && !this.preMatch.matched.has(u)) {
          s = l;
          break;
        }
      }
    return s < 0 ? !1 : (this.destroyBetween(this.index, s), this.index++, !0);
  }
  updateNodeAt(e, t, r, i, s) {
    let o = this.top.children[i];
    return o.dirty == un && o.dom == o.contentDOM && (o.dirty = nr), o.update(e, t, r, s) ? (this.destroyBetween(this.index, i), this.index++, !0) : !1;
  }
  findIndexWithChild(e) {
    for (; ; ) {
      let t = e.parentNode;
      if (!t)
        return -1;
      if (t == this.top.contentDOM) {
        let r = e.pmViewDesc;
        if (r) {
          for (let i = this.index; i < this.top.children.length; i++)
            if (this.top.children[i] == r)
              return i;
        }
        return -1;
      }
      e = t;
    }
  }
  // Try to update the next node, if any, to the given data. Checks
  // pre-matches to avoid overwriting nodes that could still be used.
  updateNextNode(e, t, r, i, s, o) {
    for (let l = this.index; l < this.top.children.length; l++) {
      let a = this.top.children[l];
      if (a instanceof jn) {
        let u = this.preMatch.matched.get(a);
        if (u != null && u != s)
          return !1;
        let c = a.dom, d, f = this.isLocked(c) && !(e.isText && a.node && a.node.isText && a.nodeDOM.nodeValue == e.text && a.dirty != un && Us(t, a.outerDeco));
        if (!f && a.update(e, t, r, i))
          return this.destroyBetween(this.index, l), a.dom != c && (this.changed = !0), this.index++, !0;
        if (!f && (d = this.recreateWrapper(a, e, t, r, i, o)))
          return this.destroyBetween(this.index, l), this.top.children[this.index] = d, d.contentDOM && (d.dirty = nr, d.updateChildren(i, o + 1), d.dirty = Tt), this.changed = !0, this.index++, !0;
        break;
      }
    }
    return !1;
  }
  // When a node with content is replaced by a different node with
  // identical content, move over its children.
  recreateWrapper(e, t, r, i, s, o) {
    if (e.dirty || t.isAtom || !e.children.length || !e.node.content.eq(t.content) || !Us(r, e.outerDeco) || !i.eq(e.innerDeco))
      return null;
    let l = jn.create(this.top, t, r, i, s, o);
    if (l.contentDOM) {
      l.children = e.children, e.children = [];
      for (let a of l.children)
        a.parent = l;
    }
    return e.destroy(), l;
  }
  // Insert the node as a newly created node desc.
  addNode(e, t, r, i, s) {
    let o = jn.create(this.top, e, t, r, i, s);
    o.contentDOM && o.updateChildren(i, s + 1), this.top.children.splice(this.index++, 0, o), this.changed = !0;
  }
  placeWidget(e, t, r) {
    let i = this.index < this.top.children.length ? this.top.children[this.index] : null;
    if (i && i.matchesWidget(e) && (e == i.widget || !i.widget.type.toDOM.parentNode))
      this.index++;
    else {
      let s = new lp(this.top, e, t, r);
      this.top.children.splice(this.index++, 0, s), this.changed = !0;
    }
  }
  // Make sure a textblock looks and behaves correctly in
  // contentEditable.
  addTextblockHacks() {
    let e = this.top.children[this.index - 1], t = this.top;
    for (; e instanceof mr; )
      t = e, e = t.children[t.children.length - 1];
    (!e || // Empty textblock
    !(e instanceof Ro) || /\n$/.test(e.node.text) || this.view.requiresGeckoHackNode && /\s$/.test(e.node.text)) && ((st || Ze) && e && e.dom.contentEditable == "false" && this.addHackNode("IMG", t), this.addHackNode("BR", this.top));
  }
  addHackNode(e, t) {
    if (t == this.top && this.index < t.children.length && t.children[this.index].matchesHack(e))
      this.index++;
    else {
      let r = document.createElement(e);
      e == "IMG" && (r.className = "ProseMirror-separator", r.alt = ""), e == "BR" && (r.className = "ProseMirror-trailingBreak");
      let i = new ap(this.top, [], r, null);
      t != this.top ? t.children.push(i) : t.children.splice(this.index++, 0, i), this.changed = !0;
    }
  }
  isLocked(e) {
    return this.lock && (e == this.lock || e.nodeType == 1 && e.contains(this.lock.parentNode));
  }
}
function Lb(n, e) {
  let t = e, r = t.children.length, i = n.childCount, s = /* @__PURE__ */ new Map(), o = [];
  e: for (; i > 0; ) {
    let l;
    for (; ; )
      if (r) {
        let u = t.children[r - 1];
        if (u instanceof mr)
          t = u, r = u.children.length;
        else {
          l = u, r--;
          break;
        }
      } else {
        if (t == e)
          break e;
        r = t.parent.children.indexOf(t), t = t.parent;
      }
    let a = l.node;
    if (a) {
      if (a != n.child(i - 1))
        break;
      --i, s.set(l, i), o.push(l);
    }
  }
  return { index: i, matched: s, matches: o.reverse() };
}
function Pb(n, e) {
  return n.type.side - e.type.side;
}
function Bb(n, e, t, r) {
  let i = e.locals(n), s = 0;
  if (i.length == 0) {
    for (let u = 0; u < n.childCount; u++) {
      let c = n.child(u);
      r(c, i, e.forChild(s, c), u), s += c.nodeSize;
    }
    return;
  }
  let o = 0, l = [], a = null;
  for (let u = 0; ; ) {
    let c, d;
    for (; o < i.length && i[o].to == s; ) {
      let _ = i[o++];
      _.widget && (c ? (d || (d = [c])).push(_) : c = _);
    }
    if (c)
      if (d) {
        d.sort(Pb);
        for (let _ = 0; _ < d.length; _++)
          t(d[_], u, !!a);
      } else
        t(c, u, !!a);
    let f, h;
    if (a)
      h = -1, f = a, a = null;
    else if (u < n.childCount)
      h = u, f = n.child(u++);
    else
      break;
    for (let _ = 0; _ < l.length; _++)
      l[_].to <= s && l.splice(_--, 1);
    for (; o < i.length && i[o].from <= s && i[o].to > s; )
      l.push(i[o++]);
    let p = s + f.nodeSize;
    if (f.isText) {
      let _ = p;
      o < i.length && i[o].from < _ && (_ = i[o].from);
      for (let k = 0; k < l.length; k++)
        l[k].to < _ && (_ = l[k].to);
      _ < p && (a = f.cut(_ - s), f = f.cut(0, _ - s), p = _, h = -1);
    } else
      for (; o < i.length && i[o].to < p; )
        o++;
    let g = f.isInline && !f.isLeaf ? l.filter((_) => !_.inline) : l.slice();
    r(f, g, e.forChild(s, f), h), s = p;
  }
}
function zb(n) {
  if (n.nodeName == "UL" || n.nodeName == "OL") {
    let e = n.style.cssText;
    n.style.cssText = e + "; list-style: square !important", window.getComputedStyle(n).listStyle, n.style.cssText = e;
  }
}
function Hb(n, e, t, r) {
  for (let i = 0, s = 0; i < n.childCount && s <= r; ) {
    let o = n.child(i++), l = s;
    if (s += o.nodeSize, !o.isText)
      continue;
    let a = o.text;
    for (; i < n.childCount; ) {
      let u = n.child(i++);
      if (s += u.nodeSize, !u.isText)
        break;
      a += u.text;
    }
    if (s >= t) {
      if (s >= r && a.slice(r - e.length - l, r - l) == e)
        return r - e.length;
      let u = l < r ? a.lastIndexOf(e, r - l - 1) : -1;
      if (u >= 0 && u + e.length + l >= t)
        return l + u;
      if (t == r && a.length >= r + e.length - l && a.slice(r - l, r - l + e.length) == e)
        return r;
    }
  }
  return -1;
}
function oa(n, e, t, r, i) {
  let s = [];
  for (let o = 0, l = 0; o < n.length; o++) {
    let a = n[o], u = l, c = l += a.size;
    u >= t || c <= e ? s.push(a) : (u < e && s.push(a.slice(0, e - u, r)), i && (s.push(i), i = void 0), c > t && s.push(a.slice(t - u, a.size, r)));
  }
  return s;
}
function Pa(n, e = null) {
  let t = n.domSelectionRange(), r = n.state.doc;
  if (!t.focusNode)
    return null;
  let i = n.docView.nearestDesc(t.focusNode), s = i && i.size == 0, o = n.docView.posFromDOM(t.focusNode, t.focusOffset, 1);
  if (o < 0)
    return null;
  let l = r.resolve(o), a, u;
  if (No(t)) {
    for (a = o; i && !i.node; )
      i = i.parent;
    let d = i.node;
    if (i && d.isAtom && G.isSelectable(d) && i.parent && !(d.isInline && hb(t.focusNode, t.focusOffset, i.dom))) {
      let f = i.posBefore;
      u = new G(o == f ? l : r.resolve(f));
    }
  } else {
    if (t instanceof n.dom.ownerDocument.defaultView.Selection && t.rangeCount > 1) {
      let d = o, f = o;
      for (let h = 0; h < t.rangeCount; h++) {
        let p = t.getRangeAt(h);
        d = Math.min(d, n.docView.posFromDOM(p.startContainer, p.startOffset, 1)), f = Math.max(f, n.docView.posFromDOM(p.endContainer, p.endOffset, -1));
      }
      if (d < 0)
        return null;
      [a, o] = f == n.state.selection.anchor ? [f, d] : [d, f], l = r.resolve(o);
    } else
      a = n.docView.posFromDOM(t.anchorNode, t.anchorOffset, 1);
    if (a < 0)
      return null;
  }
  let c = r.resolve(a);
  if (!u) {
    let d = e == "pointer" || n.state.selection.head < l.pos && !s ? 1 : -1;
    u = Ba(n, c, l, d);
  }
  return u;
}
function fp(n) {
  return n.editable ? n.hasFocus() : pp(n) && document.activeElement && document.activeElement.contains(n.dom);
}
function Sn(n, e = !1) {
  let t = n.state.selection;
  if (hp(n, t), !!fp(n)) {
    if (!e && n.input.mouseDown && n.input.mouseDown.allowDefault && Ze) {
      let r = n.domSelectionRange(), i = n.domObserver.currentSelection;
      if (r.anchorNode && i.anchorNode && pr(r.anchorNode, r.anchorOffset, i.anchorNode, i.anchorOffset)) {
        n.input.mouseDown.delayedSelectionSync = !0, n.domObserver.setCurSelection();
        return;
      }
    }
    if (n.domObserver.disconnectSelection(), n.cursorWrapper)
      jb(n);
    else {
      let { anchor: r, head: i } = t, s, o;
      bd && !(t instanceof Z) && (t.$from.parent.inlineContent || (s = kd(n, t.from)), !t.empty && !t.$from.parent.inlineContent && (o = kd(n, t.to))), n.docView.setSelection(r, i, n, e), bd && (s && vd(s), o && vd(o)), t.visible ? n.dom.classList.remove("ProseMirror-hideselection") : (n.dom.classList.add("ProseMirror-hideselection"), "onselectionchange" in document && qb(n));
    }
    n.domObserver.setCurSelection(), n.domObserver.connectSelection();
  }
}
const bd = st || Ze && ep < 63;
function kd(n, e) {
  let { node: t, offset: r } = n.docView.domFromPos(e, 0), i = r < t.childNodes.length ? t.childNodes[r] : null, s = r ? t.childNodes[r - 1] : null;
  if (st && i && i.contentEditable == "false")
    return yl(i);
  if ((!i || i.contentEditable == "false") && (!s || s.contentEditable == "false")) {
    if (i)
      return yl(i);
    if (s)
      return yl(s);
  }
}
function yl(n) {
  return n.contentEditable = "true", st && n.draggable && (n.draggable = !1, n.wasDraggable = !0), n;
}
function vd(n) {
  n.contentEditable = "false", n.wasDraggable && (n.draggable = !0, n.wasDraggable = null);
}
function qb(n) {
  let e = n.dom.ownerDocument;
  e.removeEventListener("selectionchange", n.input.hideSelectionGuard);
  let t = n.domSelectionRange(), r = t.anchorNode, i = t.anchorOffset;
  e.addEventListener("selectionchange", n.input.hideSelectionGuard = () => {
    (t.anchorNode != r || t.anchorOffset != i) && (e.removeEventListener("selectionchange", n.input.hideSelectionGuard), setTimeout(() => {
      (!fp(n) || n.state.selection.visible) && n.dom.classList.remove("ProseMirror-hideselection");
    }, 20));
  });
}
function jb(n) {
  let e = n.domSelection(), t = document.createRange();
  if (!e)
    return;
  let r = n.cursorWrapper.dom, i = r.nodeName == "IMG";
  i ? t.setStart(r.parentNode, Ve(r) + 1) : t.setStart(r, 0), t.collapse(!0), e.removeAllRanges(), e.addRange(t), !i && !n.state.selection.visible && dt && qn <= 11 && (r.disabled = !0, r.disabled = !1);
}
function hp(n, e) {
  if (e instanceof G) {
    let t = n.docView.descAt(e.from);
    t != n.lastSelectedViewDesc && (wd(n), t && t.selectNode(), n.lastSelectedViewDesc = t);
  } else
    wd(n);
}
function wd(n) {
  n.lastSelectedViewDesc && (n.lastSelectedViewDesc.parent && n.lastSelectedViewDesc.deselectNode(), n.lastSelectedViewDesc = void 0);
}
function Ba(n, e, t, r) {
  return n.someProp("createSelectionBetween", (i) => i(n, e, t)) || Z.between(e, t, r);
}
function Ed(n) {
  return n.editable && !n.hasFocus() ? !1 : pp(n);
}
function pp(n) {
  let e = n.domSelectionRange();
  if (!e.anchorNode)
    return !1;
  try {
    return n.dom.contains(e.anchorNode.nodeType == 3 ? e.anchorNode.parentNode : e.anchorNode) && (n.editable || n.dom.contains(e.focusNode.nodeType == 3 ? e.focusNode.parentNode : e.focusNode));
  } catch {
    return !1;
  }
}
function Vb(n) {
  let e = n.docView.domFromPos(n.state.selection.anchor, 0), t = n.domSelectionRange();
  return pr(e.node, e.offset, t.anchorNode, t.anchorOffset);
}
function la(n, e) {
  let { $anchor: t, $head: r } = n.selection, i = e > 0 ? t.max(r) : t.min(r), s = i.parent.inlineContent ? i.depth ? n.doc.resolve(e > 0 ? i.after() : i.before()) : null : i;
  return s && re.findFrom(s, e);
}
function On(n, e) {
  return n.dispatch(n.state.tr.setSelection(e).scrollIntoView()), !0;
}
function Sd(n, e, t) {
  let r = n.state.selection;
  if (r instanceof Z)
    if (t.indexOf("s") > -1) {
      let { $head: i } = r, s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter;
      if (!s || s.isText || !s.isLeaf)
        return !1;
      let o = n.state.doc.resolve(i.pos + s.nodeSize * (e < 0 ? -1 : 1));
      return On(n, new Z(r.$anchor, o));
    } else if (r.empty) {
      if (n.endOfTextblock(e > 0 ? "forward" : "backward")) {
        let i = la(n.state, e);
        return i && i instanceof G ? On(n, i) : !1;
      } else if (!(St && t.indexOf("m") > -1)) {
        let i = r.$head, s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter, o;
        if (!s || s.isText)
          return !1;
        let l = e < 0 ? i.pos - s.nodeSize : i.pos;
        return s.isAtom || (o = n.docView.descAt(l)) && !o.contentDOM ? G.isSelectable(s) ? On(n, new G(e < 0 ? n.state.doc.resolve(i.pos - s.nodeSize) : i)) : Wi ? On(n, new Z(n.state.doc.resolve(e < 0 ? l : l + s.nodeSize))) : !1 : !1;
      }
    } else return !1;
  else {
    if (r instanceof G && r.node.isInline)
      return On(n, new Z(e > 0 ? r.$to : r.$from));
    {
      let i = la(n.state, e);
      return i ? On(n, i) : !1;
    }
  }
}
function Ws(n) {
  return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length;
}
function Si(n, e) {
  let t = n.pmViewDesc;
  return t && t.size == 0 && (e < 0 || n.nextSibling || n.nodeName != "BR");
}
function xr(n, e) {
  return e < 0 ? Ub(n) : Wb(n);
}
function Ub(n) {
  let e = n.domSelectionRange(), t = e.focusNode, r = e.focusOffset;
  if (!t)
    return;
  let i, s, o = !1;
  for (Ut && t.nodeType == 1 && r < Ws(t) && Si(t.childNodes[r], -1) && (o = !0); ; )
    if (r > 0) {
      if (t.nodeType != 1)
        break;
      {
        let l = t.childNodes[r - 1];
        if (Si(l, -1))
          i = t, s = --r;
        else if (l.nodeType == 3)
          t = l, r = t.nodeValue.length;
        else
          break;
      }
    } else {
      if (mp(t))
        break;
      {
        let l = t.previousSibling;
        for (; l && Si(l, -1); )
          i = t.parentNode, s = Ve(l), l = l.previousSibling;
        if (l)
          t = l, r = Ws(t);
        else {
          if (t = t.parentNode, t == n.dom)
            break;
          r = 0;
        }
      }
    }
  o ? aa(n, t, r) : i && aa(n, i, s);
}
function Wb(n) {
  let e = n.domSelectionRange(), t = e.focusNode, r = e.focusOffset;
  if (!t)
    return;
  let i = Ws(t), s, o;
  for (; ; )
    if (r < i) {
      if (t.nodeType != 1)
        break;
      let l = t.childNodes[r];
      if (Si(l, 1))
        s = t, o = ++r;
      else
        break;
    } else {
      if (mp(t))
        break;
      {
        let l = t.nextSibling;
        for (; l && Si(l, 1); )
          s = l.parentNode, o = Ve(l) + 1, l = l.nextSibling;
        if (l)
          t = l, r = 0, i = Ws(t);
        else {
          if (t = t.parentNode, t == n.dom)
            break;
          r = i = 0;
        }
      }
    }
  s && aa(n, s, o);
}
function mp(n) {
  let e = n.pmViewDesc;
  return e && e.node && e.node.isBlock;
}
function Kb(n, e) {
  for (; n && e == n.childNodes.length && !Ui(n); )
    e = Ve(n) + 1, n = n.parentNode;
  for (; n && e < n.childNodes.length; ) {
    let t = n.childNodes[e];
    if (t.nodeType == 3)
      return t;
    if (t.nodeType == 1 && t.contentEditable == "false")
      break;
    n = t, e = 0;
  }
}
function Gb(n, e) {
  for (; n && !e && !Ui(n); )
    e = Ve(n), n = n.parentNode;
  for (; n && e; ) {
    let t = n.childNodes[e - 1];
    if (t.nodeType == 3)
      return t;
    if (t.nodeType == 1 && t.contentEditable == "false")
      break;
    n = t, e = n.childNodes.length;
  }
}
function aa(n, e, t) {
  if (e.nodeType != 3) {
    let s, o;
    (o = Kb(e, t)) ? (e = o, t = 0) : (s = Gb(e, t)) && (e = s, t = s.nodeValue.length);
  }
  let r = n.domSelection();
  if (!r)
    return;
  if (No(r)) {
    let s = document.createRange();
    s.setEnd(e, t), s.setStart(e, t), r.removeAllRanges(), r.addRange(s);
  } else r.extend && r.extend(e, t);
  n.domObserver.setCurSelection();
  let { state: i } = n;
  setTimeout(() => {
    n.state == i && Sn(n);
  }, 50);
}
function Cd(n, e) {
  let t = n.state.doc.resolve(e);
  if (!(Ze || gb) && t.parent.inlineContent) {
    let i = n.coordsAtPos(e);
    if (e > t.start()) {
      let s = n.coordsAtPos(e - 1), o = (s.top + s.bottom) / 2;
      if (o > i.top && o < i.bottom && Math.abs(s.left - i.left) > 1)
        return s.left < i.left ? "ltr" : "rtl";
    }
    if (e < t.end()) {
      let s = n.coordsAtPos(e + 1), o = (s.top + s.bottom) / 2;
      if (o > i.top && o < i.bottom && Math.abs(s.left - i.left) > 1)
        return s.left > i.left ? "ltr" : "rtl";
    }
  }
  return getComputedStyle(n.dom).direction == "rtl" ? "rtl" : "ltr";
}
function Dd(n, e, t) {
  let r = n.state.selection;
  if (r instanceof Z && !r.empty || t.indexOf("s") > -1 || St && t.indexOf("m") > -1)
    return !1;
  let { $from: i, $to: s } = r;
  if (!i.parent.inlineContent || n.endOfTextblock(e < 0 ? "up" : "down")) {
    let o = la(n.state, e);
    if (o && o instanceof G)
      return On(n, o);
  }
  if (!i.parent.inlineContent) {
    let o = e < 0 ? i : s, l = r instanceof yt ? re.near(o, e) : re.findFrom(o, e);
    return l ? On(n, l) : !1;
  }
  return !1;
}
function Ad(n, e) {
  if (!(n.state.selection instanceof Z))
    return !0;
  let { $head: t, $anchor: r, empty: i } = n.state.selection;
  if (!t.sameParent(r))
    return !0;
  if (!i)
    return !1;
  if (n.endOfTextblock(e > 0 ? "forward" : "backward"))
    return !0;
  let s = !t.textOffset && (e < 0 ? t.nodeBefore : t.nodeAfter);
  if (s && !s.isText) {
    let o = n.state.tr;
    return e < 0 ? o.delete(t.pos - s.nodeSize, t.pos) : o.delete(t.pos, t.pos + s.nodeSize), n.dispatch(o), !0;
  }
  return !1;
}
function Td(n, e, t) {
  n.domObserver.stop(), e.contentEditable = t, n.domObserver.start();
}
function Jb(n) {
  if (!st || n.state.selection.$head.parentOffset > 0)
    return !1;
  let { focusNode: e, focusOffset: t } = n.domSelectionRange();
  if (e && e.nodeType == 1 && t == 0 && e.firstChild && e.firstChild.contentEditable == "false") {
    let r = e.firstChild;
    Td(n, r, "true"), setTimeout(() => Td(n, r, "false"), 20);
  }
  return !1;
}
function Yb(n) {
  let e = "";
  return n.ctrlKey && (e += "c"), n.metaKey && (e += "m"), n.altKey && (e += "a"), n.shiftKey && (e += "s"), e;
}
function Xb(n, e) {
  let t = e.keyCode, r = Yb(e);
  if (t == 8 || St && t == 72 && r == "c")
    return Ad(n, -1) || xr(n, -1);
  if (t == 46 && !e.shiftKey || St && t == 68 && r == "c")
    return Ad(n, 1) || xr(n, 1);
  if (t == 13 || t == 27)
    return !0;
  if (t == 37 || St && t == 66 && r == "c") {
    let i = t == 37 ? Cd(n, n.state.selection.from) == "ltr" ? -1 : 1 : -1;
    return Sd(n, i, r) || xr(n, i);
  } else if (t == 39 || St && t == 70 && r == "c") {
    let i = t == 39 ? Cd(n, n.state.selection.from) == "ltr" ? 1 : -1 : 1;
    return Sd(n, i, r) || xr(n, i);
  } else {
    if (t == 38 || St && t == 80 && r == "c")
      return Dd(n, -1, r) || xr(n, -1);
    if (t == 40 || St && t == 78 && r == "c")
      return Jb(n) || Dd(n, 1, r) || xr(n, 1);
    if (r == (St ? "m" : "c") && (t == 66 || t == 73 || t == 89 || t == 90))
      return !0;
  }
  return !1;
}
function za(n, e) {
  n.someProp("transformCopied", (h) => {
    e = h(e, n);
  });
  let t = [], { content: r, openStart: i, openEnd: s } = e;
  for (; i > 1 && s > 1 && r.childCount == 1 && r.firstChild.childCount == 1; ) {
    i--, s--;
    let h = r.firstChild;
    t.push(h.type.name, h.attrs != h.type.defaultAttrs ? h.attrs : null), r = h.content;
  }
  let o = n.someProp("clipboardSerializer") || br.fromSchema(n.state.schema), l = vp(), a = l.createElement("div");
  a.appendChild(o.serializeFragment(r, { document: l }));
  let u = a.firstChild, c, d = 0;
  for (; u && u.nodeType == 1 && (c = kp[u.nodeName.toLowerCase()]); ) {
    for (let h = c.length - 1; h >= 0; h--) {
      let p = l.createElement(c[h]);
      for (; a.firstChild; )
        p.appendChild(a.firstChild);
      a.appendChild(p), d++;
    }
    u = a.firstChild;
  }
  u && u.nodeType == 1 && u.setAttribute("data-pm-slice", `${i} ${s}${d ? ` -${d}` : ""} ${JSON.stringify(t)}`);
  let f = n.someProp("clipboardTextSerializer", (h) => h(e, n)) || e.content.textBetween(0, e.content.size, `

`);
  return { dom: a, text: f, slice: e };
}
function gp(n, e, t, r, i) {
  let s = i.parent.type.spec.code, o, l;
  if (!t && !e)
    return null;
  let a = e && (r || s || !t);
  if (a) {
    if (n.someProp("transformPastedText", (f) => {
      e = f(e, s || r, n);
    }), s)
      return e ? new z(F.from(n.state.schema.text(e.replace(/\r\n?/g, `
`))), 0, 0) : z.empty;
    let d = n.someProp("clipboardTextParser", (f) => f(e, i, r, n));
    if (d)
      l = d;
    else {
      let f = i.marks(), { schema: h } = n.state, p = br.fromSchema(h);
      o = document.createElement("div"), e.split(/(?:\r\n?|\n)+/).forEach((g) => {
        let _ = o.appendChild(document.createElement("p"));
        g && _.appendChild(p.serializeNode(h.text(g, f)));
      });
    }
  } else
    n.someProp("transformPastedHTML", (d) => {
      t = d(t, n);
    }), o = tk(t), Wi && nk(o);
  let u = o && o.querySelector("[data-pm-slice]"), c = u && /^(\d+) (\d+)(?: -(\d+))? (.*)/.exec(u.getAttribute("data-pm-slice") || "");
  if (c && c[3])
    for (let d = +c[3]; d > 0; d--) {
      let f = o.firstChild;
      for (; f && f.nodeType != 1; )
        f = f.nextSibling;
      if (!f)
        break;
      o = f;
    }
  if (l || (l = (n.someProp("clipboardParser") || n.someProp("domParser") || vi.fromSchema(n.state.schema)).parseSlice(o, {
    preserveWhitespace: !!(a || c),
    context: i,
    ruleFromNode(f) {
      return f.nodeName == "BR" && !f.nextSibling && f.parentNode && !Zb.test(f.parentNode.nodeName) ? { ignore: !0 } : null;
    }
  })), c)
    l = rk(xd(l, +c[1], +c[2]), c[4]);
  else if (l = z.maxOpen(Qb(l.content, i), !0), l.openStart || l.openEnd) {
    let d = 0, f = 0;
    for (let h = l.content.firstChild; d < l.openStart && !h.type.spec.isolating; d++, h = h.firstChild)
      ;
    for (let h = l.content.lastChild; f < l.openEnd && !h.type.spec.isolating; f++, h = h.lastChild)
      ;
    l = xd(l, d, f);
  }
  return n.someProp("transformPasted", (d) => {
    l = d(l, n);
  }), l;
}
const Zb = /^(a|abbr|acronym|b|cite|code|del|em|i|ins|kbd|label|output|q|ruby|s|samp|span|strong|sub|sup|time|u|tt|var)$/i;
function Qb(n, e) {
  if (n.childCount < 2)
    return n;
  for (let t = e.depth; t >= 0; t--) {
    let i = e.node(t).contentMatchAt(e.index(t)), s, o = [];
    if (n.forEach((l) => {
      if (!o)
        return;
      let a = i.findWrapping(l.type), u;
      if (!a)
        return o = null;
      if (u = o.length && s.length && yp(a, s, l, o[o.length - 1], 0))
        o[o.length - 1] = u;
      else {
        o.length && (o[o.length - 1] = bp(o[o.length - 1], s.length));
        let c = _p(l, a);
        o.push(c), i = i.matchType(c.type), s = a;
      }
    }), o)
      return F.from(o);
  }
  return n;
}
function _p(n, e, t = 0) {
  for (let r = e.length - 1; r >= t; r--)
    n = e[r].create(null, F.from(n));
  return n;
}
function yp(n, e, t, r, i) {
  if (i < n.length && i < e.length && n[i] == e[i]) {
    let s = yp(n, e, t, r.lastChild, i + 1);
    if (s)
      return r.copy(r.content.replaceChild(r.childCount - 1, s));
    if (r.contentMatchAt(r.childCount).matchType(i == n.length - 1 ? t.type : n[i + 1]))
      return r.copy(r.content.append(F.from(_p(t, n, i + 1))));
  }
}
function bp(n, e) {
  if (e == 0)
    return n;
  let t = n.content.replaceChild(n.childCount - 1, bp(n.lastChild, e - 1)), r = n.contentMatchAt(n.childCount).fillBefore(F.empty, !0);
  return n.copy(t.append(r));
}
function ua(n, e, t, r, i, s) {
  let o = e < 0 ? n.firstChild : n.lastChild, l = o.content;
  return n.childCount > 1 && (s = 0), i < r - 1 && (l = ua(l, e, t, r, i + 1, s)), i >= t && (l = e < 0 ? o.contentMatchAt(0).fillBefore(l, s <= i).append(l) : l.append(o.contentMatchAt(o.childCount).fillBefore(F.empty, !0))), n.replaceChild(e < 0 ? 0 : n.childCount - 1, o.copy(l));
}
function xd(n, e, t) {
  return e < n.openStart && (n = new z(ua(n.content, -1, e, n.openStart, 0, n.openEnd), e, n.openEnd)), t < n.openEnd && (n = new z(ua(n.content, 1, t, n.openEnd, 0, 0), n.openStart, t)), n;
}
const kp = {
  thead: ["table"],
  tbody: ["table"],
  tfoot: ["table"],
  caption: ["table"],
  colgroup: ["table"],
  col: ["table", "colgroup"],
  tr: ["table", "tbody"],
  td: ["table", "tbody", "tr"],
  th: ["table", "tbody", "tr"]
};
let Md = null;
function vp() {
  return Md || (Md = document.implementation.createHTMLDocument("title"));
}
let bl = null;
function ek(n) {
  let e = window.trustedTypes;
  return e ? (bl || (bl = e.defaultPolicy || e.createPolicy("ProseMirrorClipboard", { createHTML: (t) => t })), bl.createHTML(n)) : n;
}
function tk(n) {
  let e = /^(\s*<meta [^>]*>)*/.exec(n);
  e && (n = n.slice(e[0].length));
  let t = vp().createElement("div"), r = /<([a-z][^>\s]+)/i.exec(n), i;
  if ((i = r && kp[r[1].toLowerCase()]) && (n = i.map((s) => "<" + s + ">").join("") + n + i.map((s) => "</" + s + ">").reverse().join("")), t.innerHTML = ek(n), i)
    for (let s = 0; s < i.length; s++)
      t = t.querySelector(i[s]) || t;
  return t;
}
function nk(n) {
  let e = n.querySelectorAll(Ze ? "span:not([class]):not([style])" : "span.Apple-converted-space");
  for (let t = 0; t < e.length; t++) {
    let r = e[t];
    r.childNodes.length == 1 && r.textContent == " " && r.parentNode && r.parentNode.replaceChild(n.ownerDocument.createTextNode(" "), r);
  }
}
function rk(n, e) {
  if (!n.size)
    return n;
  let t = n.content.firstChild.type.schema, r;
  try {
    r = JSON.parse(e);
  } catch {
    return n;
  }
  let { content: i, openStart: s, openEnd: o } = n;
  for (let l = r.length - 2; l >= 0; l -= 2) {
    let a = t.nodes[r[l]];
    if (!a || a.hasRequiredAttrs())
      break;
    i = F.from(a.create(r[l + 1], i)), s++, o++;
  }
  return new z(i, s, o);
}
const ot = {}, lt = {}, ik = { touchstart: !0, touchmove: !0 };
class sk {
  constructor() {
    this.shiftKey = !1, this.mouseDown = null, this.lastKeyCode = null, this.lastKeyCodeTime = 0, this.lastClick = { time: 0, x: 0, y: 0, type: "", button: 0 }, this.lastSelectionOrigin = null, this.lastSelectionTime = 0, this.lastIOSEnter = 0, this.lastIOSEnterFallbackTimeout = -1, this.lastFocus = 0, this.lastTouch = 0, this.lastChromeDelete = 0, this.composing = !1, this.compositionNode = null, this.composingTimeout = -1, this.compositionNodes = [], this.compositionEndedAt = -2e8, this.compositionID = 1, this.compositionPendingChanges = 0, this.domChangeCount = 0, this.eventHandlers = /* @__PURE__ */ Object.create(null), this.hideSelectionGuard = null;
  }
}
function ok(n) {
  for (let e in ot) {
    let t = ot[e];
    n.dom.addEventListener(e, n.input.eventHandlers[e] = (r) => {
      ak(n, r) && !Ha(n, r) && (n.editable || !(r.type in lt)) && t(n, r);
    }, ik[e] ? { passive: !0 } : void 0);
  }
  st && n.dom.addEventListener("input", () => null), ca(n);
}
function Hn(n, e) {
  n.input.lastSelectionOrigin = e, n.input.lastSelectionTime = Date.now();
}
function lk(n) {
  n.domObserver.stop();
  for (let e in n.input.eventHandlers)
    n.dom.removeEventListener(e, n.input.eventHandlers[e]);
  clearTimeout(n.input.composingTimeout), clearTimeout(n.input.lastIOSEnterFallbackTimeout);
}
function ca(n) {
  n.someProp("handleDOMEvents", (e) => {
    for (let t in e)
      n.input.eventHandlers[t] || n.dom.addEventListener(t, n.input.eventHandlers[t] = (r) => Ha(n, r));
  });
}
function Ha(n, e) {
  return n.someProp("handleDOMEvents", (t) => {
    let r = t[e.type];
    return r ? r(n, e) || e.defaultPrevented : !1;
  });
}
function ak(n, e) {
  if (!e.bubbles)
    return !0;
  if (e.defaultPrevented)
    return !1;
  for (let t = e.target; t != n.dom; t = t.parentNode)
    if (!t || t.nodeType == 11 || t.pmViewDesc && t.pmViewDesc.stopEvent(e))
      return !1;
  return !0;
}
function uk(n, e) {
  !Ha(n, e) && ot[e.type] && (n.editable || !(e.type in lt)) && ot[e.type](n, e);
}
lt.keydown = (n, e) => {
  let t = e;
  if (n.input.shiftKey = t.keyCode == 16 || t.shiftKey, !Ep(n, t) && (n.input.lastKeyCode = t.keyCode, n.input.lastKeyCodeTime = Date.now(), !(wn && Ze && t.keyCode == 13)))
    if (t.keyCode != 229 && n.domObserver.forceFlush(), jr && t.keyCode == 13 && !t.ctrlKey && !t.altKey && !t.metaKey) {
      let r = Date.now();
      n.input.lastIOSEnter = r, n.input.lastIOSEnterFallbackTimeout = setTimeout(() => {
        n.input.lastIOSEnter == r && (n.someProp("handleKeyDown", (i) => i(n, er(13, "Enter"))), n.input.lastIOSEnter = 0);
      }, 200);
    } else n.someProp("handleKeyDown", (r) => r(n, t)) || Xb(n, t) ? t.preventDefault() : Hn(n, "key");
};
lt.keyup = (n, e) => {
  e.keyCode == 16 && (n.input.shiftKey = !1);
};
lt.keypress = (n, e) => {
  let t = e;
  if (Ep(n, t) || !t.charCode || t.ctrlKey && !t.altKey || St && t.metaKey)
    return;
  if (n.someProp("handleKeyPress", (i) => i(n, t))) {
    t.preventDefault();
    return;
  }
  let r = n.state.selection;
  if (!(r instanceof Z) || !r.$from.sameParent(r.$to)) {
    let i = String.fromCharCode(t.charCode), s = () => n.state.tr.insertText(i).scrollIntoView();
    !/[\r\n]/.test(i) && !n.someProp("handleTextInput", (o) => o(n, r.$from.pos, r.$to.pos, i, s)) && n.dispatch(s()), t.preventDefault();
  }
};
function Io(n) {
  return { left: n.clientX, top: n.clientY };
}
function ck(n, e) {
  let t = e.x - n.clientX, r = e.y - n.clientY;
  return t * t + r * r < 100;
}
function qa(n, e, t, r, i) {
  if (r == -1)
    return !1;
  let s = n.state.doc.resolve(r);
  for (let o = s.depth + 1; o > 0; o--)
    if (n.someProp(e, (l) => o > s.depth ? l(n, t, s.nodeAfter, s.before(o), i, !0) : l(n, t, s.node(o), s.before(o), i, !1)))
      return !0;
  return !1;
}
function zr(n, e, t) {
  if (n.focused || n.focus(), n.state.selection.eq(e))
    return;
  let r = n.state.tr.setSelection(e);
  r.setMeta("pointer", !0), n.dispatch(r);
}
function dk(n, e) {
  if (e == -1)
    return !1;
  let t = n.state.doc.resolve(e), r = t.nodeAfter;
  return r && r.isAtom && G.isSelectable(r) ? (zr(n, new G(t)), !0) : !1;
}
function fk(n, e) {
  if (e == -1)
    return !1;
  let t = n.state.selection, r, i;
  t instanceof G && (r = t.node);
  let s = n.state.doc.resolve(e);
  for (let o = s.depth + 1; o > 0; o--) {
    let l = o > s.depth ? s.nodeAfter : s.node(o);
    if (G.isSelectable(l)) {
      r && t.$from.depth > 0 && o >= t.$from.depth && s.before(t.$from.depth + 1) == t.$from.pos ? i = s.before(t.$from.depth) : i = s.before(o);
      break;
    }
  }
  return i != null ? (zr(n, G.create(n.state.doc, i)), !0) : !1;
}
function hk(n, e, t, r, i) {
  return qa(n, "handleClickOn", e, t, r) || n.someProp("handleClick", (s) => s(n, e, r)) || (i ? fk(n, t) : dk(n, t));
}
function pk(n, e, t, r) {
  return qa(n, "handleDoubleClickOn", e, t, r) || n.someProp("handleDoubleClick", (i) => i(n, e, r));
}
function mk(n, e, t, r) {
  return qa(n, "handleTripleClickOn", e, t, r) || n.someProp("handleTripleClick", (i) => i(n, e, r)) || gk(n, t, r);
}
function gk(n, e, t) {
  if (t.button != 0)
    return !1;
  let r = n.state.doc;
  if (e == -1)
    return r.inlineContent ? (zr(n, Z.create(r, 0, r.content.size)), !0) : !1;
  let i = r.resolve(e);
  for (let s = i.depth + 1; s > 0; s--) {
    let o = s > i.depth ? i.nodeAfter : i.node(s), l = i.before(s);
    if (o.inlineContent)
      zr(n, Z.create(r, l + 1, l + 1 + o.content.size));
    else if (G.isSelectable(o))
      zr(n, G.create(r, l));
    else
      continue;
    return !0;
  }
}
function ja(n) {
  return Ks(n);
}
const wp = St ? "metaKey" : "ctrlKey";
ot.mousedown = (n, e) => {
  let t = e;
  n.input.shiftKey = t.shiftKey;
  let r = ja(n), i = Date.now(), s = "singleClick";
  i - n.input.lastClick.time < 500 && ck(t, n.input.lastClick) && !t[wp] && n.input.lastClick.button == t.button && (n.input.lastClick.type == "singleClick" ? s = "doubleClick" : n.input.lastClick.type == "doubleClick" && (s = "tripleClick")), n.input.lastClick = { time: i, x: t.clientX, y: t.clientY, type: s, button: t.button };
  let o = n.posAtCoords(Io(t));
  o && (s == "singleClick" ? (n.input.mouseDown && n.input.mouseDown.done(), n.input.mouseDown = new _k(n, o, t, !!r)) : (s == "doubleClick" ? pk : mk)(n, o.pos, o.inside, t) ? t.preventDefault() : Hn(n, "pointer"));
};
class _k {
  constructor(e, t, r, i) {
    this.view = e, this.pos = t, this.event = r, this.flushed = i, this.delayedSelectionSync = !1, this.mightDrag = null, this.startDoc = e.state.doc, this.selectNode = !!r[wp], this.allowDefault = r.shiftKey;
    let s, o;
    if (t.inside > -1)
      s = e.state.doc.nodeAt(t.inside), o = t.inside;
    else {
      let c = e.state.doc.resolve(t.pos);
      s = c.parent, o = c.depth ? c.before() : 0;
    }
    const l = i ? null : r.target, a = l ? e.docView.nearestDesc(l, !0) : null;
    this.target = a && a.dom.nodeType == 1 ? a.dom : null;
    let { selection: u } = e.state;
    (r.button == 0 && s.type.spec.draggable && s.type.spec.selectable !== !1 || u instanceof G && u.from <= o && u.to > o) && (this.mightDrag = {
      node: s,
      pos: o,
      addAttr: !!(this.target && !this.target.draggable),
      setUneditable: !!(this.target && Ut && !this.target.hasAttribute("contentEditable"))
    }), this.target && this.mightDrag && (this.mightDrag.addAttr || this.mightDrag.setUneditable) && (this.view.domObserver.stop(), this.mightDrag.addAttr && (this.target.draggable = !0), this.mightDrag.setUneditable && setTimeout(() => {
      this.view.input.mouseDown == this && this.target.setAttribute("contentEditable", "false");
    }, 20), this.view.domObserver.start()), e.root.addEventListener("mouseup", this.up = this.up.bind(this)), e.root.addEventListener("mousemove", this.move = this.move.bind(this)), Hn(e, "pointer");
  }
  done() {
    this.view.root.removeEventListener("mouseup", this.up), this.view.root.removeEventListener("mousemove", this.move), this.mightDrag && this.target && (this.view.domObserver.stop(), this.mightDrag.addAttr && this.target.removeAttribute("draggable"), this.mightDrag.setUneditable && this.target.removeAttribute("contentEditable"), this.view.domObserver.start()), this.delayedSelectionSync && setTimeout(() => Sn(this.view)), this.view.input.mouseDown = null;
  }
  up(e) {
    if (this.done(), !this.view.dom.contains(e.target))
      return;
    let t = this.pos;
    this.view.state.doc != this.startDoc && (t = this.view.posAtCoords(Io(e))), this.updateAllowDefault(e), this.allowDefault || !t ? Hn(this.view, "pointer") : hk(this.view, t.pos, t.inside, e, this.selectNode) ? e.preventDefault() : e.button == 0 && (this.flushed || // Safari ignores clicks on draggable elements
    st && this.mightDrag && !this.mightDrag.node.isAtom || // Chrome will sometimes treat a node selection as a
    // cursor, but still report that the node is selected
    // when asked through getSelection. You'll then get a
    // situation where clicking at the point where that
    // (hidden) cursor is doesn't change the selection, and
    // thus doesn't get a reaction from ProseMirror. This
    // works around that.
    Ze && !this.view.state.selection.visible && Math.min(Math.abs(t.pos - this.view.state.selection.from), Math.abs(t.pos - this.view.state.selection.to)) <= 2) ? (zr(this.view, re.near(this.view.state.doc.resolve(t.pos))), e.preventDefault()) : Hn(this.view, "pointer");
  }
  move(e) {
    this.updateAllowDefault(e), Hn(this.view, "pointer"), e.buttons == 0 && this.done();
  }
  updateAllowDefault(e) {
    !this.allowDefault && (Math.abs(this.event.x - e.clientX) > 4 || Math.abs(this.event.y - e.clientY) > 4) && (this.allowDefault = !0);
  }
}
ot.touchstart = (n) => {
  n.input.lastTouch = Date.now(), ja(n), Hn(n, "pointer");
};
ot.touchmove = (n) => {
  n.input.lastTouch = Date.now(), Hn(n, "pointer");
};
ot.contextmenu = (n) => ja(n);
function Ep(n, e) {
  return n.composing ? !0 : st && Math.abs(e.timeStamp - n.input.compositionEndedAt) < 500 ? (n.input.compositionEndedAt = -2e8, !0) : !1;
}
const yk = wn ? 5e3 : -1;
lt.compositionstart = lt.compositionupdate = (n) => {
  if (!n.composing) {
    n.domObserver.flush();
    let { state: e } = n, t = e.selection.$to;
    if (e.selection instanceof Z && (e.storedMarks || !t.textOffset && t.parentOffset && t.nodeBefore.marks.some((r) => r.type.spec.inclusive === !1)))
      n.markCursor = n.state.storedMarks || t.marks(), Ks(n, !0), n.markCursor = null;
    else if (Ks(n, !e.selection.empty), Ut && e.selection.empty && t.parentOffset && !t.textOffset && t.nodeBefore.marks.length) {
      let r = n.domSelectionRange();
      for (let i = r.focusNode, s = r.focusOffset; i && i.nodeType == 1 && s != 0; ) {
        let o = s < 0 ? i.lastChild : i.childNodes[s - 1];
        if (!o)
          break;
        if (o.nodeType == 3) {
          let l = n.domSelection();
          l && l.collapse(o, o.nodeValue.length);
          break;
        } else
          i = o, s = -1;
      }
    }
    n.input.composing = !0;
  }
  Sp(n, yk);
};
lt.compositionend = (n, e) => {
  n.composing && (n.input.composing = !1, n.input.compositionEndedAt = e.timeStamp, n.input.compositionPendingChanges = n.domObserver.pendingRecords().length ? n.input.compositionID : 0, n.input.compositionNode = null, n.input.compositionPendingChanges && Promise.resolve().then(() => n.domObserver.flush()), n.input.compositionID++, Sp(n, 20));
};
function Sp(n, e) {
  clearTimeout(n.input.composingTimeout), e > -1 && (n.input.composingTimeout = setTimeout(() => Ks(n), e));
}
function Cp(n) {
  for (n.composing && (n.input.composing = !1, n.input.compositionEndedAt = kk()); n.input.compositionNodes.length > 0; )
    n.input.compositionNodes.pop().markParentsDirty();
}
function bk(n) {
  let e = n.domSelectionRange();
  if (!e.focusNode)
    return null;
  let t = db(e.focusNode, e.focusOffset), r = fb(e.focusNode, e.focusOffset);
  if (t && r && t != r) {
    let i = r.pmViewDesc, s = n.domObserver.lastChangedTextNode;
    if (t == s || r == s)
      return s;
    if (!i || !i.isText(r.nodeValue))
      return r;
    if (n.input.compositionNode == r) {
      let o = t.pmViewDesc;
      if (!(!o || !o.isText(t.nodeValue)))
        return r;
    }
  }
  return t || r;
}
function kk() {
  let n = document.createEvent("Event");
  return n.initEvent("event", !0, !0), n.timeStamp;
}
function Ks(n, e = !1) {
  if (!(wn && n.domObserver.flushingSoon >= 0)) {
    if (n.domObserver.forceFlush(), Cp(n), e || n.docView && n.docView.dirty) {
      let t = Pa(n), r = n.state.selection;
      return t && !t.eq(r) ? n.dispatch(n.state.tr.setSelection(t)) : (n.markCursor || e) && !r.$from.node(r.$from.sharedDepth(r.to)).inlineContent ? n.dispatch(n.state.tr.deleteSelection()) : n.updateState(n.state), !0;
    }
    return !1;
  }
}
function vk(n, e) {
  if (!n.dom.parentNode)
    return;
  let t = n.dom.parentNode.appendChild(document.createElement("div"));
  t.appendChild(e), t.style.cssText = "position: fixed; left: -10000px; top: 10px";
  let r = getSelection(), i = document.createRange();
  i.selectNodeContents(e), n.dom.blur(), r.removeAllRanges(), r.addRange(i), setTimeout(() => {
    t.parentNode && t.parentNode.removeChild(t), n.focus();
  }, 50);
}
const Li = dt && qn < 15 || jr && _b < 604;
ot.copy = lt.cut = (n, e) => {
  let t = e, r = n.state.selection, i = t.type == "cut";
  if (r.empty)
    return;
  let s = Li ? null : t.clipboardData, o = r.content(), { dom: l, text: a } = za(n, o);
  s ? (t.preventDefault(), s.clearData(), s.setData("text/html", l.innerHTML), s.setData("text/plain", a)) : vk(n, l), i && n.dispatch(n.state.tr.deleteSelection().scrollIntoView().setMeta("uiEvent", "cut"));
};
function wk(n) {
  return n.openStart == 0 && n.openEnd == 0 && n.content.childCount == 1 ? n.content.firstChild : null;
}
function Ek(n, e) {
  if (!n.dom.parentNode)
    return;
  let t = n.input.shiftKey || n.state.selection.$from.parent.type.spec.code, r = n.dom.parentNode.appendChild(document.createElement(t ? "textarea" : "div"));
  t || (r.contentEditable = "true"), r.style.cssText = "position: fixed; left: -10000px; top: 10px", r.focus();
  let i = n.input.shiftKey && n.input.lastKeyCode != 45;
  setTimeout(() => {
    n.focus(), r.parentNode && r.parentNode.removeChild(r), t ? Pi(n, r.value, null, i, e) : Pi(n, r.textContent, r.innerHTML, i, e);
  }, 50);
}
function Pi(n, e, t, r, i) {
  let s = gp(n, e, t, r, n.state.selection.$from);
  if (n.someProp("handlePaste", (a) => a(n, i, s || z.empty)))
    return !0;
  if (!s)
    return !1;
  let o = wk(s), l = o ? n.state.tr.replaceSelectionWith(o, r) : n.state.tr.replaceSelection(s);
  return n.dispatch(l.scrollIntoView().setMeta("paste", !0).setMeta("uiEvent", "paste")), !0;
}
function Dp(n) {
  let e = n.getData("text/plain") || n.getData("Text");
  if (e)
    return e;
  let t = n.getData("text/uri-list");
  return t ? t.replace(/\r?\n/g, " ") : "";
}
lt.paste = (n, e) => {
  let t = e;
  if (n.composing && !wn)
    return;
  let r = Li ? null : t.clipboardData, i = n.input.shiftKey && n.input.lastKeyCode != 45;
  r && Pi(n, Dp(r), r.getData("text/html"), i, t) ? t.preventDefault() : Ek(n, t);
};
class Ap {
  constructor(e, t, r) {
    this.slice = e, this.move = t, this.node = r;
  }
}
const Sk = St ? "altKey" : "ctrlKey";
function Tp(n, e) {
  let t = n.someProp("dragCopies", (r) => !r(e));
  return t ?? !e[Sk];
}
ot.dragstart = (n, e) => {
  let t = e, r = n.input.mouseDown;
  if (r && r.done(), !t.dataTransfer)
    return;
  let i = n.state.selection, s = i.empty ? null : n.posAtCoords(Io(t)), o;
  if (!(s && s.pos >= i.from && s.pos <= (i instanceof G ? i.to - 1 : i.to))) {
    if (r && r.mightDrag)
      o = G.create(n.state.doc, r.mightDrag.pos);
    else if (t.target && t.target.nodeType == 1) {
      let d = n.docView.nearestDesc(t.target, !0);
      d && d.node.type.spec.draggable && d != n.docView && (o = G.create(n.state.doc, d.posBefore));
    }
  }
  let l = (o || n.state.selection).content(), { dom: a, text: u, slice: c } = za(n, l);
  (!t.dataTransfer.files.length || !Ze || ep > 120) && t.dataTransfer.clearData(), t.dataTransfer.setData(Li ? "Text" : "text/html", a.innerHTML), t.dataTransfer.effectAllowed = "copyMove", Li || t.dataTransfer.setData("text/plain", u), n.dragging = new Ap(c, Tp(n, t), o);
};
ot.dragend = (n) => {
  let e = n.dragging;
  window.setTimeout(() => {
    n.dragging == e && (n.dragging = null);
  }, 50);
};
lt.dragover = lt.dragenter = (n, e) => e.preventDefault();
lt.drop = (n, e) => {
  let t = e, r = n.dragging;
  if (n.dragging = null, !t.dataTransfer)
    return;
  let i = n.posAtCoords(Io(t));
  if (!i)
    return;
  let s = n.state.doc.resolve(i.pos), o = r && r.slice;
  o ? n.someProp("transformPasted", (p) => {
    o = p(o, n);
  }) : o = gp(n, Dp(t.dataTransfer), Li ? null : t.dataTransfer.getData("text/html"), !1, s);
  let l = !!(r && Tp(n, t));
  if (n.someProp("handleDrop", (p) => p(n, t, o || z.empty, l))) {
    t.preventDefault();
    return;
  }
  if (!o)
    return;
  t.preventDefault();
  let a = o ? Uh(n.state.doc, s.pos, o) : s.pos;
  a == null && (a = s.pos);
  let u = n.state.tr;
  if (l) {
    let { node: p } = r;
    p ? p.replace(u) : u.deleteSelection();
  }
  let c = u.mapping.map(a), d = o.openStart == 0 && o.openEnd == 0 && o.content.childCount == 1, f = u.doc;
  if (d ? u.replaceRangeWith(c, c, o.content.firstChild) : u.replaceRange(c, c, o), u.doc.eq(f))
    return;
  let h = u.doc.resolve(c);
  if (d && G.isSelectable(o.content.firstChild) && h.nodeAfter && h.nodeAfter.sameMarkup(o.content.firstChild))
    u.setSelection(new G(h));
  else {
    let p = u.mapping.map(a);
    u.mapping.maps[u.mapping.maps.length - 1].forEach((g, _, k, b) => p = b), u.setSelection(Ba(n, h, u.doc.resolve(p)));
  }
  n.focus(), n.dispatch(u.setMeta("uiEvent", "drop"));
};
ot.focus = (n) => {
  n.input.lastFocus = Date.now(), n.focused || (n.domObserver.stop(), n.dom.classList.add("ProseMirror-focused"), n.domObserver.start(), n.focused = !0, setTimeout(() => {
    n.docView && n.hasFocus() && !n.domObserver.currentSelection.eq(n.domSelectionRange()) && Sn(n);
  }, 20));
};
ot.blur = (n, e) => {
  let t = e;
  n.focused && (n.domObserver.stop(), n.dom.classList.remove("ProseMirror-focused"), n.domObserver.start(), t.relatedTarget && n.dom.contains(t.relatedTarget) && n.domObserver.currentSelection.clear(), n.focused = !1);
};
ot.beforeinput = (n, e) => {
  if (Ze && wn && e.inputType == "deleteContentBackward") {
    n.domObserver.flushSoon();
    let { domChangeCount: r } = n.input;
    setTimeout(() => {
      if (n.input.domChangeCount != r || (n.dom.blur(), n.focus(), n.someProp("handleKeyDown", (s) => s(n, er(8, "Backspace")))))
        return;
      let { $cursor: i } = n.state.selection;
      i && i.pos > 0 && n.dispatch(n.state.tr.delete(i.pos - 1, i.pos).scrollIntoView());
    }, 50);
  }
};
for (let n in lt)
  ot[n] = lt[n];
function Bi(n, e) {
  if (n == e)
    return !0;
  for (let t in n)
    if (n[t] !== e[t])
      return !1;
  for (let t in e)
    if (!(t in n))
      return !1;
  return !0;
}
class Gs {
  constructor(e, t) {
    this.toDOM = e, this.spec = t || ar, this.side = this.spec.side || 0;
  }
  map(e, t, r, i) {
    let { pos: s, deleted: o } = e.mapResult(t.from + i, this.side < 0 ? -1 : 1);
    return o ? null : new nt(s - r, s - r, this);
  }
  valid() {
    return !0;
  }
  eq(e) {
    return this == e || e instanceof Gs && (this.spec.key && this.spec.key == e.spec.key || this.toDOM == e.toDOM && Bi(this.spec, e.spec));
  }
  destroy(e) {
    this.spec.destroy && this.spec.destroy(e);
  }
}
class Vn {
  constructor(e, t) {
    this.attrs = e, this.spec = t || ar;
  }
  map(e, t, r, i) {
    let s = e.map(t.from + i, this.spec.inclusiveStart ? -1 : 1) - r, o = e.map(t.to + i, this.spec.inclusiveEnd ? 1 : -1) - r;
    return s >= o ? null : new nt(s, o, this);
  }
  valid(e, t) {
    return t.from < t.to;
  }
  eq(e) {
    return this == e || e instanceof Vn && Bi(this.attrs, e.attrs) && Bi(this.spec, e.spec);
  }
  static is(e) {
    return e.type instanceof Vn;
  }
  destroy() {
  }
}
class Va {
  constructor(e, t) {
    this.attrs = e, this.spec = t || ar;
  }
  map(e, t, r, i) {
    let s = e.mapResult(t.from + i, 1);
    if (s.deleted)
      return null;
    let o = e.mapResult(t.to + i, -1);
    return o.deleted || o.pos <= s.pos ? null : new nt(s.pos - r, o.pos - r, this);
  }
  valid(e, t) {
    let { index: r, offset: i } = e.content.findIndex(t.from), s;
    return i == t.from && !(s = e.child(r)).isText && i + s.nodeSize == t.to;
  }
  eq(e) {
    return this == e || e instanceof Va && Bi(this.attrs, e.attrs) && Bi(this.spec, e.spec);
  }
  destroy() {
  }
}
class nt {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.from = e, this.to = t, this.type = r;
  }
  /**
  @internal
  */
  copy(e, t) {
    return new nt(e, t, this.type);
  }
  /**
  @internal
  */
  eq(e, t = 0) {
    return this.type.eq(e.type) && this.from + t == e.from && this.to + t == e.to;
  }
  /**
  @internal
  */
  map(e, t, r) {
    return this.type.map(e, this, t, r);
  }
  /**
  Creates a widget decoration, which is a DOM node that's shown in
  the document at the given position. It is recommended that you
  delay rendering the widget by passing a function that will be
  called when the widget is actually drawn in a view, but you can
  also directly pass a DOM node. `getPos` can be used to find the
  widget's current document position.
  */
  static widget(e, t, r) {
    return new nt(e, e, new Gs(t, r));
  }
  /**
  Creates an inline decoration, which adds the given attributes to
  each inline node between `from` and `to`.
  */
  static inline(e, t, r, i) {
    return new nt(e, t, new Vn(r, i));
  }
  /**
  Creates a node decoration. `from` and `to` should point precisely
  before and after a node in the document. That node, and only that
  node, will receive the given attributes.
  */
  static node(e, t, r, i) {
    return new nt(e, t, new Va(r, i));
  }
  /**
  The spec provided when creating this decoration. Can be useful
  if you've stored extra information in that object.
  */
  get spec() {
    return this.type.spec;
  }
  /**
  @internal
  */
  get inline() {
    return this.type instanceof Vn;
  }
  /**
  @internal
  */
  get widget() {
    return this.type instanceof Gs;
  }
}
const $r = [], ar = {};
class Ce {
  /**
  @internal
  */
  constructor(e, t) {
    this.local = e.length ? e : $r, this.children = t.length ? t : $r;
  }
  /**
  Create a set of decorations, using the structure of the given
  document. This will consume (modify) the `decorations` array, so
  you must make a copy if you want need to preserve that.
  */
  static create(e, t) {
    return t.length ? Js(t, e, 0, ar) : Xe;
  }
  /**
  Find all decorations in this set which touch the given range
  (including decorations that start or end directly at the
  boundaries) and match the given predicate on their spec. When
  `start` and `end` are omitted, all decorations in the set are
  considered. When `predicate` isn't given, all decorations are
  assumed to match.
  */
  find(e, t, r) {
    let i = [];
    return this.findInner(e ?? 0, t ?? 1e9, i, 0, r), i;
  }
  findInner(e, t, r, i, s) {
    for (let o = 0; o < this.local.length; o++) {
      let l = this.local[o];
      l.from <= t && l.to >= e && (!s || s(l.spec)) && r.push(l.copy(l.from + i, l.to + i));
    }
    for (let o = 0; o < this.children.length; o += 3)
      if (this.children[o] < t && this.children[o + 1] > e) {
        let l = this.children[o] + 1;
        this.children[o + 2].findInner(e - l, t - l, r, i + l, s);
      }
  }
  /**
  Map the set of decorations in response to a change in the
  document.
  */
  map(e, t, r) {
    return this == Xe || e.maps.length == 0 ? this : this.mapInner(e, t, 0, 0, r || ar);
  }
  /**
  @internal
  */
  mapInner(e, t, r, i, s) {
    let o;
    for (let l = 0; l < this.local.length; l++) {
      let a = this.local[l].map(e, r, i);
      a && a.type.valid(t, a) ? (o || (o = [])).push(a) : s.onRemove && s.onRemove(this.local[l].spec);
    }
    return this.children.length ? Ck(this.children, o || [], e, t, r, i, s) : o ? new Ce(o.sort(ur), $r) : Xe;
  }
  /**
  Add the given array of decorations to the ones in the set,
  producing a new set. Consumes the `decorations` array. Needs
  access to the current document to create the appropriate tree
  structure.
  */
  add(e, t) {
    return t.length ? this == Xe ? Ce.create(e, t) : this.addInner(e, t, 0) : this;
  }
  addInner(e, t, r) {
    let i, s = 0;
    e.forEach((l, a) => {
      let u = a + r, c;
      if (c = Mp(t, l, u)) {
        for (i || (i = this.children.slice()); s < i.length && i[s] < a; )
          s += 3;
        i[s] == a ? i[s + 2] = i[s + 2].addInner(l, c, u + 1) : i.splice(s, 0, a, a + l.nodeSize, Js(c, l, u + 1, ar)), s += 3;
      }
    });
    let o = xp(s ? $p(t) : t, -r);
    for (let l = 0; l < o.length; l++)
      o[l].type.valid(e, o[l]) || o.splice(l--, 1);
    return new Ce(o.length ? this.local.concat(o).sort(ur) : this.local, i || this.children);
  }
  /**
  Create a new set that contains the decorations in this set, minus
  the ones in the given array.
  */
  remove(e) {
    return e.length == 0 || this == Xe ? this : this.removeInner(e, 0);
  }
  removeInner(e, t) {
    let r = this.children, i = this.local;
    for (let s = 0; s < r.length; s += 3) {
      let o, l = r[s] + t, a = r[s + 1] + t;
      for (let c = 0, d; c < e.length; c++)
        (d = e[c]) && d.from > l && d.to < a && (e[c] = null, (o || (o = [])).push(d));
      if (!o)
        continue;
      r == this.children && (r = this.children.slice());
      let u = r[s + 2].removeInner(o, l + 1);
      u != Xe ? r[s + 2] = u : (r.splice(s, 3), s -= 3);
    }
    if (i.length) {
      for (let s = 0, o; s < e.length; s++)
        if (o = e[s])
          for (let l = 0; l < i.length; l++)
            i[l].eq(o, t) && (i == this.local && (i = this.local.slice()), i.splice(l--, 1));
    }
    return r == this.children && i == this.local ? this : i.length || r.length ? new Ce(i, r) : Xe;
  }
  forChild(e, t) {
    if (this == Xe)
      return this;
    if (t.isLeaf)
      return Ce.empty;
    let r, i;
    for (let l = 0; l < this.children.length; l += 3)
      if (this.children[l] >= e) {
        this.children[l] == e && (r = this.children[l + 2]);
        break;
      }
    let s = e + 1, o = s + t.content.size;
    for (let l = 0; l < this.local.length; l++) {
      let a = this.local[l];
      if (a.from < o && a.to > s && a.type instanceof Vn) {
        let u = Math.max(s, a.from) - s, c = Math.min(o, a.to) - s;
        u < c && (i || (i = [])).push(a.copy(u, c));
      }
    }
    if (i) {
      let l = new Ce(i.sort(ur), $r);
      return r ? new In([l, r]) : l;
    }
    return r || Xe;
  }
  /**
  @internal
  */
  eq(e) {
    if (this == e)
      return !0;
    if (!(e instanceof Ce) || this.local.length != e.local.length || this.children.length != e.children.length)
      return !1;
    for (let t = 0; t < this.local.length; t++)
      if (!this.local[t].eq(e.local[t]))
        return !1;
    for (let t = 0; t < this.children.length; t += 3)
      if (this.children[t] != e.children[t] || this.children[t + 1] != e.children[t + 1] || !this.children[t + 2].eq(e.children[t + 2]))
        return !1;
    return !0;
  }
  /**
  @internal
  */
  locals(e) {
    return Ua(this.localsInner(e));
  }
  /**
  @internal
  */
  localsInner(e) {
    if (this == Xe)
      return $r;
    if (e.inlineContent || !this.local.some(Vn.is))
      return this.local;
    let t = [];
    for (let r = 0; r < this.local.length; r++)
      this.local[r].type instanceof Vn || t.push(this.local[r]);
    return t;
  }
  forEachSet(e) {
    e(this);
  }
}
Ce.empty = new Ce([], []);
Ce.removeOverlap = Ua;
const Xe = Ce.empty;
class In {
  constructor(e) {
    this.members = e;
  }
  map(e, t) {
    const r = this.members.map((i) => i.map(e, t, ar));
    return In.from(r);
  }
  forChild(e, t) {
    if (t.isLeaf)
      return Ce.empty;
    let r = [];
    for (let i = 0; i < this.members.length; i++) {
      let s = this.members[i].forChild(e, t);
      s != Xe && (s instanceof In ? r = r.concat(s.members) : r.push(s));
    }
    return In.from(r);
  }
  eq(e) {
    if (!(e instanceof In) || e.members.length != this.members.length)
      return !1;
    for (let t = 0; t < this.members.length; t++)
      if (!this.members[t].eq(e.members[t]))
        return !1;
    return !0;
  }
  locals(e) {
    let t, r = !0;
    for (let i = 0; i < this.members.length; i++) {
      let s = this.members[i].localsInner(e);
      if (s.length)
        if (!t)
          t = s;
        else {
          r && (t = t.slice(), r = !1);
          for (let o = 0; o < s.length; o++)
            t.push(s[o]);
        }
    }
    return t ? Ua(r ? t : t.sort(ur)) : $r;
  }
  // Create a group for the given array of decoration sets, or return
  // a single set when possible.
  static from(e) {
    switch (e.length) {
      case 0:
        return Xe;
      case 1:
        return e[0];
      default:
        return new In(e.every((t) => t instanceof Ce) ? e : e.reduce((t, r) => t.concat(r instanceof Ce ? r : r.members), []));
    }
  }
  forEachSet(e) {
    for (let t = 0; t < this.members.length; t++)
      this.members[t].forEachSet(e);
  }
}
function Ck(n, e, t, r, i, s, o) {
  let l = n.slice();
  for (let u = 0, c = s; u < t.maps.length; u++) {
    let d = 0;
    t.maps[u].forEach((f, h, p, g) => {
      let _ = g - p - (h - f);
      for (let k = 0; k < l.length; k += 3) {
        let b = l[k + 1];
        if (b < 0 || f > b + c - d)
          continue;
        let y = l[k] + c - d;
        h >= y ? l[k + 1] = f <= y ? -2 : -1 : f >= c && _ && (l[k] += _, l[k + 1] += _);
      }
      d += _;
    }), c = t.maps[u].map(c, -1);
  }
  let a = !1;
  for (let u = 0; u < l.length; u += 3)
    if (l[u + 1] < 0) {
      if (l[u + 1] == -2) {
        a = !0, l[u + 1] = -1;
        continue;
      }
      let c = t.map(n[u] + s), d = c - i;
      if (d < 0 || d >= r.content.size) {
        a = !0;
        continue;
      }
      let f = t.map(n[u + 1] + s, -1), h = f - i, { index: p, offset: g } = r.content.findIndex(d), _ = r.maybeChild(p);
      if (_ && g == d && g + _.nodeSize == h) {
        let k = l[u + 2].mapInner(t, _, c + 1, n[u] + s + 1, o);
        k != Xe ? (l[u] = d, l[u + 1] = h, l[u + 2] = k) : (l[u + 1] = -2, a = !0);
      } else
        a = !0;
    }
  if (a) {
    let u = Dk(l, n, e, t, i, s, o), c = Js(u, r, 0, o);
    e = c.local;
    for (let d = 0; d < l.length; d += 3)
      l[d + 1] < 0 && (l.splice(d, 3), d -= 3);
    for (let d = 0, f = 0; d < c.children.length; d += 3) {
      let h = c.children[d];
      for (; f < l.length && l[f] < h; )
        f += 3;
      l.splice(f, 0, c.children[d], c.children[d + 1], c.children[d + 2]);
    }
  }
  return new Ce(e.sort(ur), l);
}
function xp(n, e) {
  if (!e || !n.length)
    return n;
  let t = [];
  for (let r = 0; r < n.length; r++) {
    let i = n[r];
    t.push(new nt(i.from + e, i.to + e, i.type));
  }
  return t;
}
function Dk(n, e, t, r, i, s, o) {
  function l(a, u) {
    for (let c = 0; c < a.local.length; c++) {
      let d = a.local[c].map(r, i, u);
      d ? t.push(d) : o.onRemove && o.onRemove(a.local[c].spec);
    }
    for (let c = 0; c < a.children.length; c += 3)
      l(a.children[c + 2], a.children[c] + u + 1);
  }
  for (let a = 0; a < n.length; a += 3)
    n[a + 1] == -1 && l(n[a + 2], e[a] + s + 1);
  return t;
}
function Mp(n, e, t) {
  if (e.isLeaf)
    return null;
  let r = t + e.nodeSize, i = null;
  for (let s = 0, o; s < n.length; s++)
    (o = n[s]) && o.from > t && o.to < r && ((i || (i = [])).push(o), n[s] = null);
  return i;
}
function $p(n) {
  let e = [];
  for (let t = 0; t < n.length; t++)
    n[t] != null && e.push(n[t]);
  return e;
}
function Js(n, e, t, r) {
  let i = [], s = !1;
  e.forEach((l, a) => {
    let u = Mp(n, l, a + t);
    if (u) {
      s = !0;
      let c = Js(u, l, t + a + 1, r);
      c != Xe && i.push(a, a + l.nodeSize, c);
    }
  });
  let o = xp(s ? $p(n) : n, -t).sort(ur);
  for (let l = 0; l < o.length; l++)
    o[l].type.valid(e, o[l]) || (r.onRemove && r.onRemove(o[l].spec), o.splice(l--, 1));
  return o.length || i.length ? new Ce(o, i) : Xe;
}
function ur(n, e) {
  return n.from - e.from || n.to - e.to;
}
function Ua(n) {
  let e = n;
  for (let t = 0; t < e.length - 1; t++) {
    let r = e[t];
    if (r.from != r.to)
      for (let i = t + 1; i < e.length; i++) {
        let s = e[i];
        if (s.from == r.from) {
          s.to != r.to && (e == n && (e = n.slice()), e[i] = s.copy(s.from, r.to), $d(e, i + 1, s.copy(r.to, s.to)));
          continue;
        } else {
          s.from < r.to && (e == n && (e = n.slice()), e[t] = r.copy(r.from, s.from), $d(e, i, r.copy(s.from, r.to)));
          break;
        }
      }
  }
  return e;
}
function $d(n, e, t) {
  for (; e < n.length && ur(t, n[e]) > 0; )
    e++;
  n.splice(e, 0, t);
}
function kl(n) {
  let e = [];
  return n.someProp("decorations", (t) => {
    let r = t(n.state);
    r && r != Xe && e.push(r);
  }), n.cursorWrapper && e.push(Ce.create(n.state.doc, [n.cursorWrapper.deco])), In.from(e);
}
const Ak = {
  childList: !0,
  characterData: !0,
  characterDataOldValue: !0,
  attributes: !0,
  attributeOldValue: !0,
  subtree: !0
}, Tk = dt && qn <= 11;
class xk {
  constructor() {
    this.anchorNode = null, this.anchorOffset = 0, this.focusNode = null, this.focusOffset = 0;
  }
  set(e) {
    this.anchorNode = e.anchorNode, this.anchorOffset = e.anchorOffset, this.focusNode = e.focusNode, this.focusOffset = e.focusOffset;
  }
  clear() {
    this.anchorNode = this.focusNode = null;
  }
  eq(e) {
    return e.anchorNode == this.anchorNode && e.anchorOffset == this.anchorOffset && e.focusNode == this.focusNode && e.focusOffset == this.focusOffset;
  }
}
class Mk {
  constructor(e, t) {
    this.view = e, this.handleDOMChange = t, this.queue = [], this.flushingSoon = -1, this.observer = null, this.currentSelection = new xk(), this.onCharData = null, this.suppressingSelectionUpdates = !1, this.lastChangedTextNode = null, this.observer = window.MutationObserver && new window.MutationObserver((r) => {
      for (let i = 0; i < r.length; i++)
        this.queue.push(r[i]);
      dt && qn <= 11 && r.some((i) => i.type == "childList" && i.removedNodes.length || i.type == "characterData" && i.oldValue.length > i.target.nodeValue.length) ? this.flushSoon() : this.flush();
    }), Tk && (this.onCharData = (r) => {
      this.queue.push({ target: r.target, type: "characterData", oldValue: r.prevValue }), this.flushSoon();
    }), this.onSelectionChange = this.onSelectionChange.bind(this);
  }
  flushSoon() {
    this.flushingSoon < 0 && (this.flushingSoon = window.setTimeout(() => {
      this.flushingSoon = -1, this.flush();
    }, 20));
  }
  forceFlush() {
    this.flushingSoon > -1 && (window.clearTimeout(this.flushingSoon), this.flushingSoon = -1, this.flush());
  }
  start() {
    this.observer && (this.observer.takeRecords(), this.observer.observe(this.view.dom, Ak)), this.onCharData && this.view.dom.addEventListener("DOMCharacterDataModified", this.onCharData), this.connectSelection();
  }
  stop() {
    if (this.observer) {
      let e = this.observer.takeRecords();
      if (e.length) {
        for (let t = 0; t < e.length; t++)
          this.queue.push(e[t]);
        window.setTimeout(() => this.flush(), 20);
      }
      this.observer.disconnect();
    }
    this.onCharData && this.view.dom.removeEventListener("DOMCharacterDataModified", this.onCharData), this.disconnectSelection();
  }
  connectSelection() {
    this.view.dom.ownerDocument.addEventListener("selectionchange", this.onSelectionChange);
  }
  disconnectSelection() {
    this.view.dom.ownerDocument.removeEventListener("selectionchange", this.onSelectionChange);
  }
  suppressSelectionUpdates() {
    this.suppressingSelectionUpdates = !0, setTimeout(() => this.suppressingSelectionUpdates = !1, 50);
  }
  onSelectionChange() {
    if (Ed(this.view)) {
      if (this.suppressingSelectionUpdates)
        return Sn(this.view);
      if (dt && qn <= 11 && !this.view.state.selection.empty) {
        let e = this.view.domSelectionRange();
        if (e.focusNode && pr(e.focusNode, e.focusOffset, e.anchorNode, e.anchorOffset))
          return this.flushSoon();
      }
      this.flush();
    }
  }
  setCurSelection() {
    this.currentSelection.set(this.view.domSelectionRange());
  }
  ignoreSelectionChange(e) {
    if (!e.focusNode)
      return !0;
    let t = /* @__PURE__ */ new Set(), r;
    for (let s = e.focusNode; s; s = qr(s))
      t.add(s);
    for (let s = e.anchorNode; s; s = qr(s))
      if (t.has(s)) {
        r = s;
        break;
      }
    let i = r && this.view.docView.nearestDesc(r);
    if (i && i.ignoreMutation({
      type: "selection",
      target: r.nodeType == 3 ? r.parentNode : r
    }))
      return this.setCurSelection(), !0;
  }
  pendingRecords() {
    if (this.observer)
      for (let e of this.observer.takeRecords())
        this.queue.push(e);
    return this.queue;
  }
  flush() {
    let { view: e } = this;
    if (!e.docView || this.flushingSoon > -1)
      return;
    let t = this.pendingRecords();
    t.length && (this.queue = []);
    let r = e.domSelectionRange(), i = !this.suppressingSelectionUpdates && !this.currentSelection.eq(r) && Ed(e) && !this.ignoreSelectionChange(r), s = -1, o = -1, l = !1, a = [];
    if (e.editable)
      for (let c = 0; c < t.length; c++) {
        let d = this.registerMutation(t[c], a);
        d && (s = s < 0 ? d.from : Math.min(d.from, s), o = o < 0 ? d.to : Math.max(d.to, o), d.typeOver && (l = !0));
      }
    if (Ut && a.length) {
      let c = a.filter((d) => d.nodeName == "BR");
      if (c.length == 2) {
        let [d, f] = c;
        d.parentNode && d.parentNode.parentNode == f.parentNode ? f.remove() : d.remove();
      } else {
        let { focusNode: d } = this.currentSelection;
        for (let f of c) {
          let h = f.parentNode;
          h && h.nodeName == "LI" && (!d || Ok(e, d) != h) && f.remove();
        }
      }
    }
    let u = null;
    s < 0 && i && e.input.lastFocus > Date.now() - 200 && Math.max(e.input.lastTouch, e.input.lastClick.time) < Date.now() - 300 && No(r) && (u = Pa(e)) && u.eq(re.near(e.state.doc.resolve(0), 1)) ? (e.input.lastFocus = 0, Sn(e), this.currentSelection.set(r), e.scrollToSelection()) : (s > -1 || i) && (s > -1 && (e.docView.markDirty(s, o), $k(e)), this.handleDOMChange(s, o, l, a), e.docView && e.docView.dirty ? e.updateState(e.state) : this.currentSelection.eq(r) || Sn(e), this.currentSelection.set(r));
  }
  registerMutation(e, t) {
    if (t.indexOf(e.target) > -1)
      return null;
    let r = this.view.docView.nearestDesc(e.target);
    if (e.type == "attributes" && (r == this.view.docView || e.attributeName == "contenteditable" || // Firefox sometimes fires spurious events for null/empty styles
    e.attributeName == "style" && !e.oldValue && !e.target.getAttribute("style")) || !r || r.ignoreMutation(e))
      return null;
    if (e.type == "childList") {
      for (let c = 0; c < e.addedNodes.length; c++) {
        let d = e.addedNodes[c];
        t.push(d), d.nodeType == 3 && (this.lastChangedTextNode = d);
      }
      if (r.contentDOM && r.contentDOM != r.dom && !r.contentDOM.contains(e.target))
        return { from: r.posBefore, to: r.posAfter };
      let i = e.previousSibling, s = e.nextSibling;
      if (dt && qn <= 11 && e.addedNodes.length)
        for (let c = 0; c < e.addedNodes.length; c++) {
          let { previousSibling: d, nextSibling: f } = e.addedNodes[c];
          (!d || Array.prototype.indexOf.call(e.addedNodes, d) < 0) && (i = d), (!f || Array.prototype.indexOf.call(e.addedNodes, f) < 0) && (s = f);
        }
      let o = i && i.parentNode == e.target ? Ve(i) + 1 : 0, l = r.localPosFromDOM(e.target, o, -1), a = s && s.parentNode == e.target ? Ve(s) : e.target.childNodes.length, u = r.localPosFromDOM(e.target, a, 1);
      return { from: l, to: u };
    } else return e.type == "attributes" ? { from: r.posAtStart - r.border, to: r.posAtEnd + r.border } : (this.lastChangedTextNode = e.target, {
      from: r.posAtStart,
      to: r.posAtEnd,
      // An event was generated for a text change that didn't change
      // any text. Mark the dom change to fall back to assuming the
      // selection was typed over with an identical value if it can't
      // find another change.
      typeOver: e.target.nodeValue == e.oldValue
    });
  }
}
let Fd = /* @__PURE__ */ new WeakMap(), Od = !1;
function $k(n) {
  if (!Fd.has(n) && (Fd.set(n, null), ["normal", "nowrap", "pre-line"].indexOf(getComputedStyle(n.dom).whiteSpace) !== -1)) {
    if (n.requiresGeckoHackNode = Ut, Od)
      return;
    console.warn("ProseMirror expects the CSS white-space property to be set, preferably to 'pre-wrap'. It is recommended to load style/prosemirror.css from the prosemirror-view package."), Od = !0;
  }
}
function Nd(n, e) {
  let t = e.startContainer, r = e.startOffset, i = e.endContainer, s = e.endOffset, o = n.domAtPos(n.state.selection.anchor);
  return pr(o.node, o.offset, i, s) && ([t, r, i, s] = [i, s, t, r]), { anchorNode: t, anchorOffset: r, focusNode: i, focusOffset: s };
}
function Fk(n, e) {
  if (e.getComposedRanges) {
    let i = e.getComposedRanges(n.root)[0];
    if (i)
      return Nd(n, i);
  }
  let t;
  function r(i) {
    i.preventDefault(), i.stopImmediatePropagation(), t = i.getTargetRanges()[0];
  }
  return n.dom.addEventListener("beforeinput", r, !0), document.execCommand("indent"), n.dom.removeEventListener("beforeinput", r, !0), t ? Nd(n, t) : null;
}
function Ok(n, e) {
  for (let t = e.parentNode; t && t != n.dom; t = t.parentNode) {
    let r = n.docView.nearestDesc(t, !0);
    if (r && r.node.isBlock)
      return t;
  }
  return null;
}
function Nk(n, e, t) {
  let { node: r, fromOffset: i, toOffset: s, from: o, to: l } = n.docView.parseRange(e, t), a = n.domSelectionRange(), u, c = a.anchorNode;
  if (c && n.dom.contains(c.nodeType == 1 ? c : c.parentNode) && (u = [{ node: c, offset: a.anchorOffset }], No(a) || u.push({ node: a.focusNode, offset: a.focusOffset })), Ze && n.input.lastKeyCode === 8)
    for (let _ = s; _ > i; _--) {
      let k = r.childNodes[_ - 1], b = k.pmViewDesc;
      if (k.nodeName == "BR" && !b) {
        s = _;
        break;
      }
      if (!b || b.size)
        break;
    }
  let d = n.state.doc, f = n.someProp("domParser") || vi.fromSchema(n.state.schema), h = d.resolve(o), p = null, g = f.parse(r, {
    topNode: h.parent,
    topMatch: h.parent.contentMatchAt(h.index()),
    topOpen: !0,
    from: i,
    to: s,
    preserveWhitespace: h.parent.type.whitespace == "pre" ? "full" : !0,
    findPositions: u,
    ruleFromNode: Rk,
    context: h
  });
  if (u && u[0].pos != null) {
    let _ = u[0].pos, k = u[1] && u[1].pos;
    k == null && (k = _), p = { anchor: _ + o, head: k + o };
  }
  return { doc: g, sel: p, from: o, to: l };
}
function Rk(n) {
  let e = n.pmViewDesc;
  if (e)
    return e.parseRule();
  if (n.nodeName == "BR" && n.parentNode) {
    if (st && /^(ul|ol)$/i.test(n.parentNode.nodeName)) {
      let t = document.createElement("div");
      return t.appendChild(document.createElement("li")), { skip: t };
    } else if (n.parentNode.lastChild == n || st && /^(tr|table)$/i.test(n.parentNode.nodeName))
      return { ignore: !0 };
  } else if (n.nodeName == "IMG" && n.getAttribute("mark-placeholder"))
    return { ignore: !0 };
  return null;
}
const Ik = /^(a|abbr|acronym|b|bd[io]|big|br|button|cite|code|data(list)?|del|dfn|em|i|img|ins|kbd|label|map|mark|meter|output|q|ruby|s|samp|small|span|strong|su[bp]|time|u|tt|var)$/i;
function Lk(n, e, t, r, i) {
  let s = n.input.compositionPendingChanges || (n.composing ? n.input.compositionID : 0);
  if (n.input.compositionPendingChanges = 0, e < 0) {
    let x = n.input.lastSelectionTime > Date.now() - 50 ? n.input.lastSelectionOrigin : null, M = Pa(n, x);
    if (M && !n.state.selection.eq(M)) {
      if (Ze && wn && n.input.lastKeyCode === 13 && Date.now() - 100 < n.input.lastKeyCodeTime && n.someProp("handleKeyDown", (R) => R(n, er(13, "Enter"))))
        return;
      let L = n.state.tr.setSelection(M);
      x == "pointer" ? L.setMeta("pointer", !0) : x == "key" && L.scrollIntoView(), s && L.setMeta("composition", s), n.dispatch(L);
    }
    return;
  }
  let o = n.state.doc.resolve(e), l = o.sharedDepth(t);
  e = o.before(l + 1), t = n.state.doc.resolve(t).after(l + 1);
  let a = n.state.selection, u = Nk(n, e, t), c = n.state.doc, d = c.slice(u.from, u.to), f, h;
  n.input.lastKeyCode === 8 && Date.now() - 100 < n.input.lastKeyCodeTime ? (f = n.state.selection.to, h = "end") : (f = n.state.selection.from, h = "start"), n.input.lastKeyCode = null;
  let p = zk(d.content, u.doc.content, u.from, f, h);
  if (p && n.input.domChangeCount++, (jr && n.input.lastIOSEnter > Date.now() - 225 || wn) && i.some((x) => x.nodeType == 1 && !Ik.test(x.nodeName)) && (!p || p.endA >= p.endB) && n.someProp("handleKeyDown", (x) => x(n, er(13, "Enter")))) {
    n.input.lastIOSEnter = 0;
    return;
  }
  if (!p)
    if (r && a instanceof Z && !a.empty && a.$head.sameParent(a.$anchor) && !n.composing && !(u.sel && u.sel.anchor != u.sel.head))
      p = { start: a.from, endA: a.to, endB: a.to };
    else {
      if (u.sel) {
        let x = Rd(n, n.state.doc, u.sel);
        if (x && !x.eq(n.state.selection)) {
          let M = n.state.tr.setSelection(x);
          s && M.setMeta("composition", s), n.dispatch(M);
        }
      }
      return;
    }
  n.state.selection.from < n.state.selection.to && p.start == p.endB && n.state.selection instanceof Z && (p.start > n.state.selection.from && p.start <= n.state.selection.from + 2 && n.state.selection.from >= u.from ? p.start = n.state.selection.from : p.endA < n.state.selection.to && p.endA >= n.state.selection.to - 2 && n.state.selection.to <= u.to && (p.endB += n.state.selection.to - p.endA, p.endA = n.state.selection.to)), dt && qn <= 11 && p.endB == p.start + 1 && p.endA == p.start && p.start > u.from && u.doc.textBetween(p.start - u.from - 1, p.start - u.from + 1) == "  " && (p.start--, p.endA--, p.endB--);
  let g = u.doc.resolveNoCache(p.start - u.from), _ = u.doc.resolveNoCache(p.endB - u.from), k = c.resolve(p.start), b = g.sameParent(_) && g.parent.inlineContent && k.end() >= p.endA, y;
  if ((jr && n.input.lastIOSEnter > Date.now() - 225 && (!b || i.some((x) => x.nodeName == "DIV" || x.nodeName == "P")) || !b && g.pos < u.doc.content.size && (!g.sameParent(_) || !g.parent.inlineContent) && !/\S/.test(u.doc.textBetween(g.pos, _.pos, "", "")) && (y = re.findFrom(u.doc.resolve(g.pos + 1), 1, !0)) && y.head > g.pos) && n.someProp("handleKeyDown", (x) => x(n, er(13, "Enter")))) {
    n.input.lastIOSEnter = 0;
    return;
  }
  if (n.state.selection.anchor > p.start && Bk(c, p.start, p.endA, g, _) && n.someProp("handleKeyDown", (x) => x(n, er(8, "Backspace")))) {
    wn && Ze && n.domObserver.suppressSelectionUpdates();
    return;
  }
  Ze && p.endB == p.start && (n.input.lastChromeDelete = Date.now()), wn && !b && g.start() != _.start() && _.parentOffset == 0 && g.depth == _.depth && u.sel && u.sel.anchor == u.sel.head && u.sel.head == p.endA && (p.endB -= 2, _ = u.doc.resolveNoCache(p.endB - u.from), setTimeout(() => {
    n.someProp("handleKeyDown", function(x) {
      return x(n, er(13, "Enter"));
    });
  }, 20));
  let v = p.start, S = p.endA, D = (x) => {
    let M = x || n.state.tr.replace(v, S, u.doc.slice(p.start - u.from, p.endB - u.from));
    if (u.sel) {
      let L = Rd(n, M.doc, u.sel);
      L && !(Ze && n.composing && L.empty && (p.start != p.endB || n.input.lastChromeDelete < Date.now() - 100) && (L.head == v || L.head == M.mapping.map(S) - 1) || dt && L.empty && L.head == v) && M.setSelection(L);
    }
    return s && M.setMeta("composition", s), M.scrollIntoView();
  }, T;
  if (b) {
    if (g.pos == _.pos) {
      dt && qn <= 11 && g.parentOffset == 0 && (n.domObserver.suppressSelectionUpdates(), setTimeout(() => Sn(n), 20));
      let x = D(n.state.tr.delete(v, S)), M = c.resolve(p.start).marksAcross(c.resolve(p.endA));
      M && x.ensureMarks(M), n.dispatch(x);
    } else if (
      // Adding or removing a mark
      p.endA == p.endB && (T = Pk(g.parent.content.cut(g.parentOffset, _.parentOffset), k.parent.content.cut(k.parentOffset, p.endA - k.start())))
    ) {
      let x = D(n.state.tr);
      T.type == "add" ? x.addMark(v, S, T.mark) : x.removeMark(v, S, T.mark), n.dispatch(x);
    } else if (g.parent.child(g.index()).isText && g.index() == _.index() - (_.textOffset ? 0 : 1)) {
      let x = g.parent.textBetween(g.parentOffset, _.parentOffset), M = () => D(n.state.tr.insertText(x, v, S));
      n.someProp("handleTextInput", (L) => L(n, v, S, x, M)) || n.dispatch(M());
    }
  } else
    n.dispatch(D());
}
function Rd(n, e, t) {
  return Math.max(t.anchor, t.head) > e.content.size ? null : Ba(n, e.resolve(t.anchor), e.resolve(t.head));
}
function Pk(n, e) {
  let t = n.firstChild.marks, r = e.firstChild.marks, i = t, s = r, o, l, a;
  for (let c = 0; c < r.length; c++)
    i = r[c].removeFromSet(i);
  for (let c = 0; c < t.length; c++)
    s = t[c].removeFromSet(s);
  if (i.length == 1 && s.length == 0)
    l = i[0], o = "add", a = (c) => c.mark(l.addToSet(c.marks));
  else if (i.length == 0 && s.length == 1)
    l = s[0], o = "remove", a = (c) => c.mark(l.removeFromSet(c.marks));
  else
    return null;
  let u = [];
  for (let c = 0; c < e.childCount; c++)
    u.push(a(e.child(c)));
  if (F.from(u).eq(n))
    return { mark: l, type: o };
}
function Bk(n, e, t, r, i) {
  if (
    // The content must have shrunk
    t - e <= i.pos - r.pos || // newEnd must point directly at or after the end of the block that newStart points into
    vl(r, !0, !1) < i.pos
  )
    return !1;
  let s = n.resolve(e);
  if (!r.parent.isTextblock) {
    let l = s.nodeAfter;
    return l != null && t == e + l.nodeSize;
  }
  if (s.parentOffset < s.parent.content.size || !s.parent.isTextblock)
    return !1;
  let o = n.resolve(vl(s, !0, !0));
  return !o.parent.isTextblock || o.pos > t || vl(o, !0, !1) < t ? !1 : r.parent.content.cut(r.parentOffset).eq(o.parent.content);
}
function vl(n, e, t) {
  let r = n.depth, i = e ? n.end() : n.pos;
  for (; r > 0 && (e || n.indexAfter(r) == n.node(r).childCount); )
    r--, i++, e = !1;
  if (t) {
    let s = n.node(r).maybeChild(n.indexAfter(r));
    for (; s && !s.isLeaf; )
      s = s.firstChild, i++;
  }
  return i;
}
function zk(n, e, t, r, i) {
  let s = n.findDiffStart(e, t);
  if (s == null)
    return null;
  let { a: o, b: l } = n.findDiffEnd(e, t + n.size, t + e.size);
  if (i == "end") {
    let a = Math.max(0, s - Math.min(o, l));
    r -= o + a - s;
  }
  if (o < s && n.size < e.size) {
    let a = r <= s && r >= o ? s - r : 0;
    s -= a, s && s < e.size && Id(e.textBetween(s - 1, s + 1)) && (s += a ? 1 : -1), l = s + (l - o), o = s;
  } else if (l < s) {
    let a = r <= s && r >= l ? s - r : 0;
    s -= a, s && s < n.size && Id(n.textBetween(s - 1, s + 1)) && (s += a ? 1 : -1), o = s + (o - l), l = s;
  }
  return { start: s, endA: o, endB: l };
}
function Id(n) {
  if (n.length != 2)
    return !1;
  let e = n.charCodeAt(0), t = n.charCodeAt(1);
  return e >= 56320 && e <= 57343 && t >= 55296 && t <= 56319;
}
class Fp {
  /**
  Create a view. `place` may be a DOM node that the editor should
  be appended to, a function that will place it into the document,
  or an object whose `mount` property holds the node to use as the
  document container. If it is `null`, the editor will not be
  added to the document.
  */
  constructor(e, t) {
    this._root = null, this.focused = !1, this.trackWrites = null, this.mounted = !1, this.markCursor = null, this.cursorWrapper = null, this.lastSelectedViewDesc = void 0, this.input = new sk(), this.prevDirectPlugins = [], this.pluginViews = [], this.requiresGeckoHackNode = !1, this.dragging = null, this._props = t, this.state = t.state, this.directPlugins = t.plugins || [], this.directPlugins.forEach(Hd), this.dispatch = this.dispatch.bind(this), this.dom = e && e.mount || document.createElement("div"), e && (e.appendChild ? e.appendChild(this.dom) : typeof e == "function" ? e(this.dom) : e.mount && (this.mounted = !0)), this.editable = Bd(this), Pd(this), this.nodeViews = zd(this), this.docView = _d(this.state.doc, Ld(this), kl(this), this.dom, this), this.domObserver = new Mk(this, (r, i, s, o) => Lk(this, r, i, s, o)), this.domObserver.start(), ok(this), this.updatePluginViews();
  }
  /**
  Holds `true` when a
  [composition](https://w3c.github.io/uievents/#events-compositionevents)
  is active.
  */
  get composing() {
    return this.input.composing;
  }
  /**
  The view's current [props](https://prosemirror.net/docs/ref/#view.EditorProps).
  */
  get props() {
    if (this._props.state != this.state) {
      let e = this._props;
      this._props = {};
      for (let t in e)
        this._props[t] = e[t];
      this._props.state = this.state;
    }
    return this._props;
  }
  /**
  Update the view's props. Will immediately cause an update to
  the DOM.
  */
  update(e) {
    e.handleDOMEvents != this._props.handleDOMEvents && ca(this);
    let t = this._props;
    this._props = e, e.plugins && (e.plugins.forEach(Hd), this.directPlugins = e.plugins), this.updateStateInner(e.state, t);
  }
  /**
  Update the view by updating existing props object with the object
  given as argument. Equivalent to `view.update(Object.assign({},
  view.props, props))`.
  */
  setProps(e) {
    let t = {};
    for (let r in this._props)
      t[r] = this._props[r];
    t.state = this.state;
    for (let r in e)
      t[r] = e[r];
    this.update(t);
  }
  /**
  Update the editor's `state` prop, without touching any of the
  other props.
  */
  updateState(e) {
    this.updateStateInner(e, this._props);
  }
  updateStateInner(e, t) {
    var r;
    let i = this.state, s = !1, o = !1;
    e.storedMarks && this.composing && (Cp(this), o = !0), this.state = e;
    let l = i.plugins != e.plugins || this._props.plugins != t.plugins;
    if (l || this._props.plugins != t.plugins || this._props.nodeViews != t.nodeViews) {
      let h = zd(this);
      qk(h, this.nodeViews) && (this.nodeViews = h, s = !0);
    }
    (l || t.handleDOMEvents != this._props.handleDOMEvents) && ca(this), this.editable = Bd(this), Pd(this);
    let a = kl(this), u = Ld(this), c = i.plugins != e.plugins && !i.doc.eq(e.doc) ? "reset" : e.scrollToSelection > i.scrollToSelection ? "to selection" : "preserve", d = s || !this.docView.matchesNode(e.doc, u, a);
    (d || !e.selection.eq(i.selection)) && (o = !0);
    let f = c == "preserve" && o && this.dom.style.overflowAnchor == null && kb(this);
    if (o) {
      this.domObserver.stop();
      let h = d && (dt || Ze) && !this.composing && !i.selection.empty && !e.selection.empty && Hk(i.selection, e.selection);
      if (d) {
        let p = Ze ? this.trackWrites = this.domSelectionRange().focusNode : null;
        this.composing && (this.input.compositionNode = bk(this)), (s || !this.docView.update(e.doc, u, a, this)) && (this.docView.updateOuterDeco(u), this.docView.destroy(), this.docView = _d(e.doc, u, a, this.dom, this)), p && !this.trackWrites && (h = !0);
      }
      h || !(this.input.mouseDown && this.domObserver.currentSelection.eq(this.domSelectionRange()) && Vb(this)) ? Sn(this, h) : (hp(this, e.selection), this.domObserver.setCurSelection()), this.domObserver.start();
    }
    this.updatePluginViews(i), !((r = this.dragging) === null || r === void 0) && r.node && !i.doc.eq(e.doc) && this.updateDraggedNode(this.dragging, i), c == "reset" ? this.dom.scrollTop = 0 : c == "to selection" ? this.scrollToSelection() : f && vb(f);
  }
  /**
  @internal
  */
  scrollToSelection() {
    let e = this.domSelectionRange().focusNode;
    if (!(!e || !this.dom.contains(e.nodeType == 1 ? e : e.parentNode))) {
      if (!this.someProp("handleScrollToSelection", (t) => t(this))) if (this.state.selection instanceof G) {
        let t = this.docView.domAfterPos(this.state.selection.from);
        t.nodeType == 1 && dd(this, t.getBoundingClientRect(), e);
      } else
        dd(this, this.coordsAtPos(this.state.selection.head, 1), e);
    }
  }
  destroyPluginViews() {
    let e;
    for (; e = this.pluginViews.pop(); )
      e.destroy && e.destroy();
  }
  updatePluginViews(e) {
    if (!e || e.plugins != this.state.plugins || this.directPlugins != this.prevDirectPlugins) {
      this.prevDirectPlugins = this.directPlugins, this.destroyPluginViews();
      for (let t = 0; t < this.directPlugins.length; t++) {
        let r = this.directPlugins[t];
        r.spec.view && this.pluginViews.push(r.spec.view(this));
      }
      for (let t = 0; t < this.state.plugins.length; t++) {
        let r = this.state.plugins[t];
        r.spec.view && this.pluginViews.push(r.spec.view(this));
      }
    } else
      for (let t = 0; t < this.pluginViews.length; t++) {
        let r = this.pluginViews[t];
        r.update && r.update(this, e);
      }
  }
  updateDraggedNode(e, t) {
    let r = e.node, i = -1;
    if (this.state.doc.nodeAt(r.from) == r.node)
      i = r.from;
    else {
      let s = r.from + (this.state.doc.content.size - t.doc.content.size);
      (s > 0 && this.state.doc.nodeAt(s)) == r.node && (i = s);
    }
    this.dragging = new Ap(e.slice, e.move, i < 0 ? void 0 : G.create(this.state.doc, i));
  }
  someProp(e, t) {
    let r = this._props && this._props[e], i;
    if (r != null && (i = t ? t(r) : r))
      return i;
    for (let o = 0; o < this.directPlugins.length; o++) {
      let l = this.directPlugins[o].props[e];
      if (l != null && (i = t ? t(l) : l))
        return i;
    }
    let s = this.state.plugins;
    if (s)
      for (let o = 0; o < s.length; o++) {
        let l = s[o].props[e];
        if (l != null && (i = t ? t(l) : l))
          return i;
      }
  }
  /**
  Query whether the view has focus.
  */
  hasFocus() {
    if (dt) {
      let e = this.root.activeElement;
      if (e == this.dom)
        return !0;
      if (!e || !this.dom.contains(e))
        return !1;
      for (; e && this.dom != e && this.dom.contains(e); ) {
        if (e.contentEditable == "false")
          return !1;
        e = e.parentElement;
      }
      return !0;
    }
    return this.root.activeElement == this.dom;
  }
  /**
  Focus the editor.
  */
  focus() {
    this.domObserver.stop(), this.editable && wb(this.dom), Sn(this), this.domObserver.start();
  }
  /**
  Get the document root in which the editor exists. This will
  usually be the top-level `document`, but might be a [shadow
  DOM](https://developer.mozilla.org/en-US/docs/Web/Web_Components/Shadow_DOM)
  root if the editor is inside one.
  */
  get root() {
    let e = this._root;
    if (e == null) {
      for (let t = this.dom.parentNode; t; t = t.parentNode)
        if (t.nodeType == 9 || t.nodeType == 11 && t.host)
          return t.getSelection || (Object.getPrototypeOf(t).getSelection = () => t.ownerDocument.getSelection()), this._root = t;
    }
    return e || document;
  }
  /**
  When an existing editor view is moved to a new document or
  shadow tree, call this to make it recompute its root.
  */
  updateRoot() {
    this._root = null;
  }
  /**
  Given a pair of viewport coordinates, return the document
  position that corresponds to them. May return null if the given
  coordinates aren't inside of the editor. When an object is
  returned, its `pos` property is the position nearest to the
  coordinates, and its `inside` property holds the position of the
  inner node that the position falls inside of, or -1 if it is at
  the top level, not in any node.
  */
  posAtCoords(e) {
    return Ab(this, e);
  }
  /**
  Returns the viewport rectangle at a given document position.
  `left` and `right` will be the same number, as this returns a
  flat cursor-ish rectangle. If the position is between two things
  that aren't directly adjacent, `side` determines which element
  is used. When < 0, the element before the position is used,
  otherwise the element after.
  */
  coordsAtPos(e, t = 1) {
    return sp(this, e, t);
  }
  /**
  Find the DOM position that corresponds to the given document
  position. When `side` is negative, find the position as close as
  possible to the content before the position. When positive,
  prefer positions close to the content after the position. When
  zero, prefer as shallow a position as possible.
  
  Note that you should **not** mutate the editor's internal DOM,
  only inspect it (and even that is usually not necessary).
  */
  domAtPos(e, t = 0) {
    return this.docView.domFromPos(e, t);
  }
  /**
  Find the DOM node that represents the document node after the
  given position. May return `null` when the position doesn't point
  in front of a node or if the node is inside an opaque node view.
  
  This is intended to be able to call things like
  `getBoundingClientRect` on that DOM node. Do **not** mutate the
  editor DOM directly, or add styling this way, since that will be
  immediately overriden by the editor as it redraws the node.
  */
  nodeDOM(e) {
    let t = this.docView.descAt(e);
    return t ? t.nodeDOM : null;
  }
  /**
  Find the document position that corresponds to a given DOM
  position. (Whenever possible, it is preferable to inspect the
  document structure directly, rather than poking around in the
  DOM, but sometimes—for example when interpreting an event
  target—you don't have a choice.)
  
  The `bias` parameter can be used to influence which side of a DOM
  node to use when the position is inside a leaf node.
  */
  posAtDOM(e, t, r = -1) {
    let i = this.docView.posFromDOM(e, t, r);
    if (i == null)
      throw new RangeError("DOM position not inside the editor");
    return i;
  }
  /**
  Find out whether the selection is at the end of a textblock when
  moving in a given direction. When, for example, given `"left"`,
  it will return true if moving left from the current cursor
  position would leave that position's parent textblock. Will apply
  to the view's current state by default, but it is possible to
  pass a different state.
  */
  endOfTextblock(e, t) {
    return Fb(this, t || this.state, e);
  }
  /**
  Run the editor's paste logic with the given HTML string. The
  `event`, if given, will be passed to the
  [`handlePaste`](https://prosemirror.net/docs/ref/#view.EditorProps.handlePaste) hook.
  */
  pasteHTML(e, t) {
    return Pi(this, "", e, !1, t || new ClipboardEvent("paste"));
  }
  /**
  Run the editor's paste logic with the given plain-text input.
  */
  pasteText(e, t) {
    return Pi(this, e, null, !0, t || new ClipboardEvent("paste"));
  }
  /**
  Serialize the given slice as it would be if it was copied from
  this editor. Returns a DOM element that contains a
  representation of the slice as its children, a textual
  representation, and the transformed slice (which can be
  different from the given input due to hooks like
  [`transformCopied`](https://prosemirror.net/docs/ref/#view.EditorProps.transformCopied)).
  */
  serializeForClipboard(e) {
    return za(this, e);
  }
  /**
  Removes the editor from the DOM and destroys all [node
  views](https://prosemirror.net/docs/ref/#view.NodeView).
  */
  destroy() {
    this.docView && (lk(this), this.destroyPluginViews(), this.mounted ? (this.docView.update(this.state.doc, [], kl(this), this), this.dom.textContent = "") : this.dom.parentNode && this.dom.parentNode.removeChild(this.dom), this.docView.destroy(), this.docView = null, ub());
  }
  /**
  This is true when the view has been
  [destroyed](https://prosemirror.net/docs/ref/#view.EditorView.destroy) (and thus should not be
  used anymore).
  */
  get isDestroyed() {
    return this.docView == null;
  }
  /**
  Used for testing.
  */
  dispatchEvent(e) {
    return uk(this, e);
  }
  /**
  @internal
  */
  domSelectionRange() {
    let e = this.domSelection();
    return e ? st && this.root.nodeType === 11 && pb(this.dom.ownerDocument) == this.dom && Fk(this, e) || e : { focusNode: null, focusOffset: 0, anchorNode: null, anchorOffset: 0 };
  }
  /**
  @internal
  */
  domSelection() {
    return this.root.getSelection();
  }
}
Fp.prototype.dispatch = function(n) {
  let e = this._props.dispatchTransaction;
  e ? e.call(this, n) : this.updateState(this.state.apply(n));
};
function Ld(n) {
  let e = /* @__PURE__ */ Object.create(null);
  return e.class = "ProseMirror", e.contenteditable = String(n.editable), n.someProp("attributes", (t) => {
    if (typeof t == "function" && (t = t(n.state)), t)
      for (let r in t)
        r == "class" ? e.class += " " + t[r] : r == "style" ? e.style = (e.style ? e.style + ";" : "") + t[r] : !e[r] && r != "contenteditable" && r != "nodeName" && (e[r] = String(t[r]));
  }), e.translate || (e.translate = "no"), [nt.node(0, n.state.doc.content.size, e)];
}
function Pd(n) {
  if (n.markCursor) {
    let e = document.createElement("img");
    e.className = "ProseMirror-separator", e.setAttribute("mark-placeholder", "true"), e.setAttribute("alt", ""), n.cursorWrapper = { dom: e, deco: nt.widget(n.state.selection.from, e, { raw: !0, marks: n.markCursor }) };
  } else
    n.cursorWrapper = null;
}
function Bd(n) {
  return !n.someProp("editable", (e) => e(n.state) === !1);
}
function Hk(n, e) {
  let t = Math.min(n.$anchor.sharedDepth(n.head), e.$anchor.sharedDepth(e.head));
  return n.$anchor.start(t) != e.$anchor.start(t);
}
function zd(n) {
  let e = /* @__PURE__ */ Object.create(null);
  function t(r) {
    for (let i in r)
      Object.prototype.hasOwnProperty.call(e, i) || (e[i] = r[i]);
  }
  return n.someProp("nodeViews", t), n.someProp("markViews", t), e;
}
function qk(n, e) {
  let t = 0, r = 0;
  for (let i in n) {
    if (n[i] != e[i])
      return !0;
    t++;
  }
  for (let i in e)
    r++;
  return t != r;
}
function Hd(n) {
  if (n.spec.state || n.spec.filterTransaction || n.spec.appendTransaction)
    throw new RangeError("Plugins passed directly to the view must not have a state component");
}
var Un = {
  8: "Backspace",
  9: "Tab",
  10: "Enter",
  12: "NumLock",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  44: "PrintScreen",
  45: "Insert",
  46: "Delete",
  59: ";",
  61: "=",
  91: "Meta",
  92: "Meta",
  106: "*",
  107: "+",
  108: ",",
  109: "-",
  110: ".",
  111: "/",
  144: "NumLock",
  145: "ScrollLock",
  160: "Shift",
  161: "Shift",
  162: "Control",
  163: "Control",
  164: "Alt",
  165: "Alt",
  173: "-",
  186: ";",
  187: "=",
  188: ",",
  189: "-",
  190: ".",
  191: "/",
  192: "`",
  219: "[",
  220: "\\",
  221: "]",
  222: "'"
}, Ys = {
  48: ")",
  49: "!",
  50: "@",
  51: "#",
  52: "$",
  53: "%",
  54: "^",
  55: "&",
  56: "*",
  57: "(",
  59: ":",
  61: "+",
  173: "_",
  186: ":",
  187: "+",
  188: "<",
  189: "_",
  190: ">",
  191: "?",
  192: "~",
  219: "{",
  220: "|",
  221: "}",
  222: '"'
}, jk = typeof navigator < "u" && /Mac/.test(navigator.platform), Vk = typeof navigator < "u" && /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent);
for (var Ue = 0; Ue < 10; Ue++) Un[48 + Ue] = Un[96 + Ue] = String(Ue);
for (var Ue = 1; Ue <= 24; Ue++) Un[Ue + 111] = "F" + Ue;
for (var Ue = 65; Ue <= 90; Ue++)
  Un[Ue] = String.fromCharCode(Ue + 32), Ys[Ue] = String.fromCharCode(Ue);
for (var wl in Un) Ys.hasOwnProperty(wl) || (Ys[wl] = Un[wl]);
function Uk(n) {
  var e = jk && n.metaKey && n.shiftKey && !n.ctrlKey && !n.altKey || Vk && n.shiftKey && n.key && n.key.length == 1 || n.key == "Unidentified", t = !e && n.key || (n.shiftKey ? Ys : Un)[n.keyCode] || n.key || "Unidentified";
  return t == "Esc" && (t = "Escape"), t == "Del" && (t = "Delete"), t == "Left" && (t = "ArrowLeft"), t == "Up" && (t = "ArrowUp"), t == "Right" && (t = "ArrowRight"), t == "Down" && (t = "ArrowDown"), t;
}
const Wk = typeof navigator < "u" && /Mac|iP(hone|[oa]d)/.test(navigator.platform), Kk = typeof navigator < "u" && /Win/.test(navigator.platform);
function Gk(n) {
  let e = n.split(/-(?!$)/), t = e[e.length - 1];
  t == "Space" && (t = " ");
  let r, i, s, o;
  for (let l = 0; l < e.length - 1; l++) {
    let a = e[l];
    if (/^(cmd|meta|m)$/i.test(a))
      o = !0;
    else if (/^a(lt)?$/i.test(a))
      r = !0;
    else if (/^(c|ctrl|control)$/i.test(a))
      i = !0;
    else if (/^s(hift)?$/i.test(a))
      s = !0;
    else if (/^mod$/i.test(a))
      Wk ? o = !0 : i = !0;
    else
      throw new Error("Unrecognized modifier name: " + a);
  }
  return r && (t = "Alt-" + t), i && (t = "Ctrl-" + t), o && (t = "Meta-" + t), s && (t = "Shift-" + t), t;
}
function Jk(n) {
  let e = /* @__PURE__ */ Object.create(null);
  for (let t in n)
    e[Gk(t)] = n[t];
  return e;
}
function El(n, e, t = !0) {
  return e.altKey && (n = "Alt-" + n), e.ctrlKey && (n = "Ctrl-" + n), e.metaKey && (n = "Meta-" + n), t && e.shiftKey && (n = "Shift-" + n), n;
}
function Yk(n) {
  return new Te({ props: { handleKeyDown: Op(n) } });
}
function Op(n) {
  let e = Jk(n);
  return function(t, r) {
    let i = Uk(r), s, o = e[El(i, r)];
    if (o && o(t.state, t.dispatch, t))
      return !0;
    if (i.length == 1 && i != " ") {
      if (r.shiftKey) {
        let l = e[El(i, r, !1)];
        if (l && l(t.state, t.dispatch, t))
          return !0;
      }
      if ((r.altKey || r.metaKey || r.ctrlKey) && // Ctrl-Alt may be used for AltGr on Windows
      !(Kk && r.ctrlKey && r.altKey) && (s = Un[r.keyCode]) && s != i) {
        let l = e[El(s, r)];
        if (l && l(t.state, t.dispatch, t))
          return !0;
      }
    }
    return !1;
  };
}
const Wa = (n, e) => n.selection.empty ? !1 : (e && e(n.tr.deleteSelection().scrollIntoView()), !0);
function Np(n, e) {
  let { $cursor: t } = n.selection;
  return !t || (e ? !e.endOfTextblock("backward", n) : t.parentOffset > 0) ? null : t;
}
const Rp = (n, e, t) => {
  let r = Np(n, t);
  if (!r)
    return !1;
  let i = Ka(r);
  if (!i) {
    let o = r.blockRange(), l = o && Gr(o);
    return l == null ? !1 : (e && e(n.tr.lift(o, l).scrollIntoView()), !0);
  }
  let s = i.nodeBefore;
  if (Vp(n, i, e, -1))
    return !0;
  if (r.parent.content.size == 0 && (Vr(s, "end") || G.isSelectable(s)))
    for (let o = r.depth; ; o--) {
      let l = Fo(n.doc, r.before(o), r.after(o), z.empty);
      if (l && l.slice.size < l.to - l.from) {
        if (e) {
          let a = n.tr.step(l);
          a.setSelection(Vr(s, "end") ? re.findFrom(a.doc.resolve(a.mapping.map(i.pos, -1)), -1) : G.create(a.doc, i.pos - s.nodeSize)), e(a.scrollIntoView());
        }
        return !0;
      }
      if (o == 1 || r.node(o - 1).childCount > 1)
        break;
    }
  return s.isAtom && i.depth == r.depth - 1 ? (e && e(n.tr.delete(i.pos - s.nodeSize, i.pos).scrollIntoView()), !0) : !1;
}, Xk = (n, e, t) => {
  let r = Np(n, t);
  if (!r)
    return !1;
  let i = Ka(r);
  return i ? Ip(n, i, e) : !1;
}, Zk = (n, e, t) => {
  let r = Pp(n, t);
  if (!r)
    return !1;
  let i = Ga(r);
  return i ? Ip(n, i, e) : !1;
};
function Ip(n, e, t) {
  let r = e.nodeBefore, i = r, s = e.pos - 1;
  for (; !i.isTextblock; s--) {
    if (i.type.spec.isolating)
      return !1;
    let c = i.lastChild;
    if (!c)
      return !1;
    i = c;
  }
  let o = e.nodeAfter, l = o, a = e.pos + 1;
  for (; !l.isTextblock; a++) {
    if (l.type.spec.isolating)
      return !1;
    let c = l.firstChild;
    if (!c)
      return !1;
    l = c;
  }
  let u = Fo(n.doc, s, a, z.empty);
  if (!u || u.from != s || u instanceof ze && u.slice.size >= a - s)
    return !1;
  if (t) {
    let c = n.tr.step(u);
    c.setSelection(Z.create(c.doc, s)), t(c.scrollIntoView());
  }
  return !0;
}
function Vr(n, e, t = !1) {
  for (let r = n; r; r = e == "start" ? r.firstChild : r.lastChild) {
    if (r.isTextblock)
      return !0;
    if (t && r.childCount != 1)
      return !1;
  }
  return !1;
}
const Lp = (n, e, t) => {
  let { $head: r, empty: i } = n.selection, s = r;
  if (!i)
    return !1;
  if (r.parent.isTextblock) {
    if (t ? !t.endOfTextblock("backward", n) : r.parentOffset > 0)
      return !1;
    s = Ka(r);
  }
  let o = s && s.nodeBefore;
  return !o || !G.isSelectable(o) ? !1 : (e && e(n.tr.setSelection(G.create(n.doc, s.pos - o.nodeSize)).scrollIntoView()), !0);
};
function Ka(n) {
  if (!n.parent.type.spec.isolating)
    for (let e = n.depth - 1; e >= 0; e--) {
      if (n.index(e) > 0)
        return n.doc.resolve(n.before(e + 1));
      if (n.node(e).type.spec.isolating)
        break;
    }
  return null;
}
function Pp(n, e) {
  let { $cursor: t } = n.selection;
  return !t || (e ? !e.endOfTextblock("forward", n) : t.parentOffset < t.parent.content.size) ? null : t;
}
const Bp = (n, e, t) => {
  let r = Pp(n, t);
  if (!r)
    return !1;
  let i = Ga(r);
  if (!i)
    return !1;
  let s = i.nodeAfter;
  if (Vp(n, i, e, 1))
    return !0;
  if (r.parent.content.size == 0 && (Vr(s, "start") || G.isSelectable(s))) {
    let o = Fo(n.doc, r.before(), r.after(), z.empty);
    if (o && o.slice.size < o.to - o.from) {
      if (e) {
        let l = n.tr.step(o);
        l.setSelection(Vr(s, "start") ? re.findFrom(l.doc.resolve(l.mapping.map(i.pos)), 1) : G.create(l.doc, l.mapping.map(i.pos))), e(l.scrollIntoView());
      }
      return !0;
    }
  }
  return s.isAtom && i.depth == r.depth - 1 ? (e && e(n.tr.delete(i.pos, i.pos + s.nodeSize).scrollIntoView()), !0) : !1;
}, zp = (n, e, t) => {
  let { $head: r, empty: i } = n.selection, s = r;
  if (!i)
    return !1;
  if (r.parent.isTextblock) {
    if (t ? !t.endOfTextblock("forward", n) : r.parentOffset < r.parent.content.size)
      return !1;
    s = Ga(r);
  }
  let o = s && s.nodeAfter;
  return !o || !G.isSelectable(o) ? !1 : (e && e(n.tr.setSelection(G.create(n.doc, s.pos)).scrollIntoView()), !0);
};
function Ga(n) {
  if (!n.parent.type.spec.isolating)
    for (let e = n.depth - 1; e >= 0; e--) {
      let t = n.node(e);
      if (n.index(e) + 1 < t.childCount)
        return n.doc.resolve(n.after(e + 1));
      if (t.type.spec.isolating)
        break;
    }
  return null;
}
const Qk = (n, e) => {
  let t = n.selection, r = t instanceof G, i;
  if (r) {
    if (t.node.isTextblock || !Kn(n.doc, t.from))
      return !1;
    i = t.from;
  } else if (i = $o(n.doc, t.from, -1), i == null)
    return !1;
  if (e) {
    let s = n.tr.join(i);
    r && s.setSelection(G.create(s.doc, i - n.doc.resolve(i).nodeBefore.nodeSize)), e(s.scrollIntoView());
  }
  return !0;
}, ev = (n, e) => {
  let t = n.selection, r;
  if (t instanceof G) {
    if (t.node.isTextblock || !Kn(n.doc, t.to))
      return !1;
    r = t.to;
  } else if (r = $o(n.doc, t.to, 1), r == null)
    return !1;
  return e && e(n.tr.join(r).scrollIntoView()), !0;
}, tv = (n, e) => {
  let { $from: t, $to: r } = n.selection, i = t.blockRange(r), s = i && Gr(i);
  return s == null ? !1 : (e && e(n.tr.lift(i, s).scrollIntoView()), !0);
}, Hp = (n, e) => {
  let { $head: t, $anchor: r } = n.selection;
  return !t.parent.type.spec.code || !t.sameParent(r) ? !1 : (e && e(n.tr.insertText(`
`).scrollIntoView()), !0);
};
function Ja(n) {
  for (let e = 0; e < n.edgeCount; e++) {
    let { type: t } = n.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
const nv = (n, e) => {
  let { $head: t, $anchor: r } = n.selection;
  if (!t.parent.type.spec.code || !t.sameParent(r))
    return !1;
  let i = t.node(-1), s = t.indexAfter(-1), o = Ja(i.contentMatchAt(s));
  if (!o || !i.canReplaceWith(s, s, o))
    return !1;
  if (e) {
    let l = t.after(), a = n.tr.replaceWith(l, l, o.createAndFill());
    a.setSelection(re.near(a.doc.resolve(l), 1)), e(a.scrollIntoView());
  }
  return !0;
}, qp = (n, e) => {
  let t = n.selection, { $from: r, $to: i } = t;
  if (t instanceof yt || r.parent.inlineContent || i.parent.inlineContent)
    return !1;
  let s = Ja(i.parent.contentMatchAt(i.indexAfter()));
  if (!s || !s.isTextblock)
    return !1;
  if (e) {
    let o = (!r.parentOffset && i.index() < i.parent.childCount ? r : i).pos, l = n.tr.insert(o, s.createAndFill());
    l.setSelection(Z.create(l.doc, o + 1)), e(l.scrollIntoView());
  }
  return !0;
}, jp = (n, e) => {
  let { $cursor: t } = n.selection;
  if (!t || t.parent.content.size)
    return !1;
  if (t.depth > 1 && t.after() != t.end(-1)) {
    let s = t.before();
    if (En(n.doc, s))
      return e && e(n.tr.split(s).scrollIntoView()), !0;
  }
  let r = t.blockRange(), i = r && Gr(r);
  return i == null ? !1 : (e && e(n.tr.lift(r, i).scrollIntoView()), !0);
};
function rv(n) {
  return (e, t) => {
    let { $from: r, $to: i } = e.selection;
    if (e.selection instanceof G && e.selection.node.isBlock)
      return !r.parentOffset || !En(e.doc, r.pos) ? !1 : (t && t(e.tr.split(r.pos).scrollIntoView()), !0);
    if (!r.depth)
      return !1;
    let s = [], o, l, a = !1, u = !1;
    for (let h = r.depth; ; h--)
      if (r.node(h).isBlock) {
        a = r.end(h) == r.pos + (r.depth - h), u = r.start(h) == r.pos - (r.depth - h), l = Ja(r.node(h - 1).contentMatchAt(r.indexAfter(h - 1))), s.unshift(a && l ? { type: l } : null), o = h;
        break;
      } else {
        if (h == 1)
          return !1;
        s.unshift(null);
      }
    let c = e.tr;
    (e.selection instanceof Z || e.selection instanceof yt) && c.deleteSelection();
    let d = c.mapping.map(r.pos), f = En(c.doc, d, s.length, s);
    if (f || (s[0] = l ? { type: l } : null, f = En(c.doc, d, s.length, s)), !f)
      return !1;
    if (c.split(d, s.length, s), !a && u && r.node(o).type != l) {
      let h = c.mapping.map(r.before(o)), p = c.doc.resolve(h);
      l && r.node(o - 1).canReplaceWith(p.index(), p.index() + 1, l) && c.setNodeMarkup(c.mapping.map(r.before(o)), l);
    }
    return t && t(c.scrollIntoView()), !0;
  };
}
const iv = rv(), sv = (n, e) => {
  let { $from: t, to: r } = n.selection, i, s = t.sharedDepth(r);
  return s == 0 ? !1 : (i = t.before(s), e && e(n.tr.setSelection(G.create(n.doc, i))), !0);
};
function ov(n, e, t) {
  let r = e.nodeBefore, i = e.nodeAfter, s = e.index();
  return !r || !i || !r.type.compatibleContent(i.type) ? !1 : !r.content.size && e.parent.canReplace(s - 1, s) ? (t && t(n.tr.delete(e.pos - r.nodeSize, e.pos).scrollIntoView()), !0) : !e.parent.canReplace(s, s + 1) || !(i.isTextblock || Kn(n.doc, e.pos)) ? !1 : (t && t(n.tr.join(e.pos).scrollIntoView()), !0);
}
function Vp(n, e, t, r) {
  let i = e.nodeBefore, s = e.nodeAfter, o, l, a = i.type.spec.isolating || s.type.spec.isolating;
  if (!a && ov(n, e, t))
    return !0;
  let u = !a && e.parent.canReplace(e.index(), e.index() + 1);
  if (u && (o = (l = i.contentMatchAt(i.childCount)).findWrapping(s.type)) && l.matchType(o[0] || s.type).validEnd) {
    if (t) {
      let h = e.pos + s.nodeSize, p = F.empty;
      for (let k = o.length - 1; k >= 0; k--)
        p = F.from(o[k].create(null, p));
      p = F.from(i.copy(p));
      let g = n.tr.step(new He(e.pos - 1, h, e.pos, h, new z(p, 1, 0), o.length, !0)), _ = g.doc.resolve(h + 2 * o.length);
      _.nodeAfter && _.nodeAfter.type == i.type && Kn(g.doc, _.pos) && g.join(_.pos), t(g.scrollIntoView());
    }
    return !0;
  }
  let c = s.type.spec.isolating || r > 0 && a ? null : re.findFrom(e, 1), d = c && c.$from.blockRange(c.$to), f = d && Gr(d);
  if (f != null && f >= e.depth)
    return t && t(n.tr.lift(d, f).scrollIntoView()), !0;
  if (u && Vr(s, "start", !0) && Vr(i, "end")) {
    let h = i, p = [];
    for (; p.push(h), !h.isTextblock; )
      h = h.lastChild;
    let g = s, _ = 1;
    for (; !g.isTextblock; g = g.firstChild)
      _++;
    if (h.canReplace(h.childCount, h.childCount, g.content)) {
      if (t) {
        let k = F.empty;
        for (let y = p.length - 1; y >= 0; y--)
          k = F.from(p[y].copy(k));
        let b = n.tr.step(new He(e.pos - p.length, e.pos + s.nodeSize, e.pos + _, e.pos + s.nodeSize - _, new z(k, p.length, 0), 0, !0));
        t(b.scrollIntoView());
      }
      return !0;
    }
  }
  return !1;
}
function Up(n) {
  return function(e, t) {
    let r = e.selection, i = n < 0 ? r.$from : r.$to, s = i.depth;
    for (; i.node(s).isInline; ) {
      if (!s)
        return !1;
      s--;
    }
    return i.node(s).isTextblock ? (t && t(e.tr.setSelection(Z.create(e.doc, n < 0 ? i.start(s) : i.end(s)))), !0) : !1;
  };
}
const lv = Up(-1), av = Up(1);
function uv(n, e = null) {
  return function(t, r) {
    let { $from: i, $to: s } = t.selection, o = i.blockRange(s), l = o && Ra(o, n, e);
    return l ? (r && r(t.tr.wrap(o, l).scrollIntoView()), !0) : !1;
  };
}
function qd(n, e = null) {
  return function(t, r) {
    let i = !1;
    for (let s = 0; s < t.selection.ranges.length && !i; s++) {
      let { $from: { pos: o }, $to: { pos: l } } = t.selection.ranges[s];
      t.doc.nodesBetween(o, l, (a, u) => {
        if (i)
          return !1;
        if (!(!a.isTextblock || a.hasMarkup(n, e)))
          if (a.type == n)
            i = !0;
          else {
            let c = t.doc.resolve(u), d = c.index();
            i = c.parent.canReplaceWith(d, d + 1, n);
          }
      });
    }
    if (!i)
      return !1;
    if (r) {
      let s = t.tr;
      for (let o = 0; o < t.selection.ranges.length; o++) {
        let { $from: { pos: l }, $to: { pos: a } } = t.selection.ranges[o];
        s.setBlockType(l, a, n, e);
      }
      r(s.scrollIntoView());
    }
    return !0;
  };
}
function Ya(...n) {
  return function(e, t, r) {
    for (let i = 0; i < n.length; i++)
      if (n[i](e, t, r))
        return !0;
    return !1;
  };
}
Ya(Wa, Rp, Lp);
Ya(Wa, Bp, zp);
Ya(Hp, qp, jp, iv);
typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : typeof os < "u" && os.platform && os.platform() == "darwin";
function cv(n, e = null) {
  return function(t, r) {
    let { $from: i, $to: s } = t.selection, o = i.blockRange(s);
    if (!o)
      return !1;
    let l = r ? t.tr : null;
    return dv(l, o, n, e) ? (r && r(l.scrollIntoView()), !0) : !1;
  };
}
function dv(n, e, t, r = null) {
  let i = !1, s = e, o = e.$from.doc;
  if (e.depth >= 2 && e.$from.node(e.depth - 1).type.compatibleContent(t) && e.startIndex == 0) {
    if (e.$from.index(e.depth - 1) == 0)
      return !1;
    let a = o.resolve(e.start - 2);
    s = new js(a, a, e.depth), e.endIndex < e.parent.childCount && (e = new js(e.$from, o.resolve(e.$to.end(e.depth)), e.depth)), i = !0;
  }
  let l = Ra(s, t, r, e);
  return l ? (n && fv(n, e, l, i, t), !0) : !1;
}
function fv(n, e, t, r, i) {
  let s = F.empty;
  for (let c = t.length - 1; c >= 0; c--)
    s = F.from(t[c].type.create(t[c].attrs, s));
  n.step(new He(e.start - (r ? 2 : 0), e.end, e.start, e.end, new z(s, 0, 0), t.length, !0));
  let o = 0;
  for (let c = 0; c < t.length; c++)
    t[c].type == i && (o = c + 1);
  let l = t.length - o, a = e.start + t.length - (r ? 2 : 0), u = e.parent;
  for (let c = e.startIndex, d = e.endIndex, f = !0; c < d; c++, f = !1)
    !f && En(n.doc, a, l) && (n.split(a, l), a += 2 * l), a += u.child(c).nodeSize;
  return n;
}
function hv(n) {
  return function(e, t) {
    let { $from: r, $to: i } = e.selection, s = r.blockRange(i, (o) => o.childCount > 0 && o.firstChild.type == n);
    return s ? t ? r.node(s.depth - 1).type == n ? pv(e, t, n, s) : mv(e, t, s) : !0 : !1;
  };
}
function pv(n, e, t, r) {
  let i = n.tr, s = r.end, o = r.$to.end(r.depth);
  s < o && (i.step(new He(s - 1, o, s, o, new z(F.from(t.create(null, r.parent.copy())), 1, 0), 1, !0)), r = new js(i.doc.resolve(r.$from.pos), i.doc.resolve(o), r.depth));
  const l = Gr(r);
  if (l == null)
    return !1;
  i.lift(r, l);
  let a = i.doc.resolve(i.mapping.map(s, -1) - 1);
  return Kn(i.doc, a.pos) && a.nodeBefore.type == a.nodeAfter.type && i.join(a.pos), e(i.scrollIntoView()), !0;
}
function mv(n, e, t) {
  let r = n.tr, i = t.parent;
  for (let h = t.end, p = t.endIndex - 1, g = t.startIndex; p > g; p--)
    h -= i.child(p).nodeSize, r.delete(h - 1, h + 1);
  let s = r.doc.resolve(t.start), o = s.nodeAfter;
  if (r.mapping.map(t.end) != t.start + s.nodeAfter.nodeSize)
    return !1;
  let l = t.startIndex == 0, a = t.endIndex == i.childCount, u = s.node(-1), c = s.index(-1);
  if (!u.canReplace(c + (l ? 0 : 1), c + 1, o.content.append(a ? F.empty : F.from(i))))
    return !1;
  let d = s.pos, f = d + o.nodeSize;
  return r.step(new He(d - (l ? 1 : 0), f + (a ? 1 : 0), d + 1, f - 1, new z((l ? F.empty : F.from(i.copy(F.empty))).append(a ? F.empty : F.from(i.copy(F.empty))), l ? 0 : 1, a ? 0 : 1), l ? 0 : 1)), e(r.scrollIntoView()), !0;
}
function gv(n) {
  return function(e, t) {
    let { $from: r, $to: i } = e.selection, s = r.blockRange(i, (u) => u.childCount > 0 && u.firstChild.type == n);
    if (!s)
      return !1;
    let o = s.startIndex;
    if (o == 0)
      return !1;
    let l = s.parent, a = l.child(o - 1);
    if (a.type != n)
      return !1;
    if (t) {
      let u = a.lastChild && a.lastChild.type == l.type, c = F.from(u ? n.create() : null), d = new z(F.from(n.create(null, F.from(l.type.create(null, c)))), u ? 3 : 1, 0), f = s.start, h = s.end;
      t(e.tr.step(new He(f - (u ? 3 : 1), h, f, h, d, 1, !0)).scrollIntoView());
    }
    return !0;
  };
}
var _v = Object.defineProperty, Wp = (n, e) => {
  for (var t in e)
    _v(n, t, { get: e[t], enumerable: !0 });
};
function Lo(n) {
  const { state: e, transaction: t } = n;
  let { selection: r } = t, { doc: i } = t, { storedMarks: s } = t;
  return {
    ...e,
    apply: e.apply.bind(e),
    applyTransaction: e.applyTransaction.bind(e),
    plugins: e.plugins,
    schema: e.schema,
    reconfigure: e.reconfigure.bind(e),
    toJSON: e.toJSON.bind(e),
    get storedMarks() {
      return s;
    },
    get selection() {
      return r;
    },
    get doc() {
      return i;
    },
    get tr() {
      return r = t.selection, i = t.doc, s = t.storedMarks, t;
    }
  };
}
var Po = class {
  constructor(n) {
    this.editor = n.editor, this.rawCommands = this.editor.extensionManager.commands, this.customState = n.state;
  }
  get hasCustomState() {
    return !!this.customState;
  }
  get state() {
    return this.customState || this.editor.state;
  }
  get commands() {
    const { rawCommands: n, editor: e, state: t } = this, { view: r } = e, { tr: i } = t, s = this.buildProps(i);
    return Object.fromEntries(
      Object.entries(n).map(([o, l]) => [o, (...u) => {
        const c = l(...u)(s);
        return !i.getMeta("preventDispatch") && !this.hasCustomState && r.dispatch(i), c;
      }])
    );
  }
  get chain() {
    return () => this.createChain();
  }
  get can() {
    return () => this.createCan();
  }
  createChain(n, e = !0) {
    const { rawCommands: t, editor: r, state: i } = this, { view: s } = r, o = [], l = !!n, a = n || i.tr, u = () => (!l && e && !a.getMeta("preventDispatch") && !this.hasCustomState && s.dispatch(a), o.every((d) => d === !0)), c = {
      ...Object.fromEntries(
        Object.entries(t).map(([d, f]) => [d, (...p) => {
          const g = this.buildProps(a, e), _ = f(...p)(g);
          return o.push(_), c;
        }])
      ),
      run: u
    };
    return c;
  }
  createCan(n) {
    const { rawCommands: e, state: t } = this, r = !1, i = n || t.tr, s = this.buildProps(i, r);
    return {
      ...Object.fromEntries(
        Object.entries(e).map(([l, a]) => [l, (...u) => a(...u)({ ...s, dispatch: void 0 })])
      ),
      chain: () => this.createChain(i, r)
    };
  }
  buildProps(n, e = !0) {
    const { rawCommands: t, editor: r, state: i } = this, { view: s } = r, o = {
      tr: n,
      editor: r,
      view: s,
      state: Lo({
        state: i,
        transaction: n
      }),
      dispatch: e ? () => {
      } : void 0,
      chain: () => this.createChain(n, e),
      can: () => this.createCan(n),
      get commands() {
        return Object.fromEntries(
          Object.entries(t).map(([l, a]) => [l, (...u) => a(...u)(o)])
        );
      }
    };
    return o;
  }
}, yv = class {
  constructor() {
    this.callbacks = {};
  }
  on(n, e) {
    return this.callbacks[n] || (this.callbacks[n] = []), this.callbacks[n].push(e), this;
  }
  emit(n, ...e) {
    const t = this.callbacks[n];
    return t && t.forEach((r) => r.apply(this, e)), this;
  }
  off(n, e) {
    const t = this.callbacks[n];
    return t && (e ? this.callbacks[n] = t.filter((r) => r !== e) : delete this.callbacks[n]), this;
  }
  once(n, e) {
    const t = (...r) => {
      this.off(n, t), e.apply(this, r);
    };
    return this.on(n, t);
  }
  removeAllListeners() {
    this.callbacks = {};
  }
};
function Kp(n, e) {
  const t = new Yh(n);
  return e.forEach((r) => {
    r.steps.forEach((i) => {
      t.step(i);
    });
  }), t;
}
var Gp = (n) => {
  const e = n.childNodes;
  for (let t = e.length - 1; t >= 0; t -= 1) {
    const r = e[t];
    r.nodeType === 3 && r.nodeValue && /^(\n\s\s|\n)$/.test(r.nodeValue) ? n.removeChild(r) : r.nodeType === 1 && Gp(r);
  }
  return n;
};
function _s(n) {
  if (typeof window > "u")
    throw new Error("[tiptap error]: there is no window object available, so this function cannot be used");
  const e = `<body>${n}</body>`, t = new window.DOMParser().parseFromString(e, "text/html").body;
  return Gp(t);
}
function zi(n, e, t) {
  if (n instanceof _t || n instanceof F)
    return n;
  t = {
    slice: !0,
    parseOptions: {},
    ...t
  };
  const r = typeof n == "object" && n !== null, i = typeof n == "string";
  if (r)
    try {
      if (Array.isArray(n) && n.length > 0)
        return F.fromArray(n.map((l) => e.nodeFromJSON(l)));
      const o = e.nodeFromJSON(n);
      return t.errorOnInvalidContent && o.check(), o;
    } catch (s) {
      if (t.errorOnInvalidContent)
        throw new Error("[tiptap error]: Invalid JSON content", { cause: s });
      return console.warn("[tiptap warn]: Invalid content.", "Passed value:", n, "Error:", s), zi("", e, t);
    }
  if (i) {
    if (t.errorOnInvalidContent) {
      let o = !1, l = "";
      const a = new Nh({
        topNode: e.spec.topNode,
        marks: e.spec.marks,
        // Prosemirror's schemas are executed such that: the last to execute, matches last
        // This means that we can add a catch-all node at the end of the schema to catch any content that we don't know how to handle
        nodes: e.spec.nodes.append({
          __tiptap__private__unknown__catch__all__node: {
            content: "inline*",
            group: "block",
            parseDOM: [
              {
                tag: "*",
                getAttrs: (u) => (o = !0, l = typeof u == "string" ? u : u.outerHTML, null)
              }
            ]
          }
        })
      });
      if (t.slice ? vi.fromSchema(a).parseSlice(_s(n), t.parseOptions) : vi.fromSchema(a).parse(_s(n), t.parseOptions), t.errorOnInvalidContent && o)
        throw new Error("[tiptap error]: Invalid HTML content", {
          cause: new Error(`Invalid element found: ${l}`)
        });
    }
    const s = vi.fromSchema(e);
    return t.slice ? s.parseSlice(_s(n), t.parseOptions).content : s.parse(_s(n), t.parseOptions);
  }
  return zi("", e, t);
}
function da(n, e, t = {}, r = {}) {
  return zi(n, e, {
    slice: !1,
    parseOptions: t,
    errorOnInvalidContent: r.errorOnInvalidContent
  });
}
function bv(n) {
  for (let e = 0; e < n.edgeCount; e += 1) {
    const { type: t } = n.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
function kv(n, e, t) {
  const r = [];
  return n.nodesBetween(e.from, e.to, (i, s) => {
    t(i) && r.push({
      node: i,
      pos: s
    });
  }), r;
}
function vv(n, e) {
  for (let t = n.depth; t > 0; t -= 1) {
    const r = n.node(t);
    if (e(r))
      return {
        pos: t > 0 ? n.before(t) : 0,
        start: n.start(t),
        depth: t,
        node: r
      };
  }
}
function Bo(n) {
  return (e) => vv(e.$from, n);
}
function j(n, e, t) {
  return n.config[e] === void 0 && n.parent ? j(n.parent, e, t) : typeof n.config[e] == "function" ? n.config[e].bind({
    ...t,
    parent: n.parent ? j(n.parent, e, t) : null
  }) : n.config[e];
}
function Xa(n) {
  return n.map((e) => {
    const t = {
      name: e.name,
      options: e.options,
      storage: e.storage
    }, r = j(e, "addExtensions", t);
    return r ? [e, ...Xa(r())] : e;
  }).flat(10);
}
function Za(n, e) {
  const t = br.fromSchema(e).serializeFragment(n), i = document.implementation.createHTMLDocument().createElement("div");
  return i.appendChild(t), i.innerHTML;
}
function Jp(n) {
  return typeof n == "function";
}
function me(n, e = void 0, ...t) {
  return Jp(n) ? e ? n.bind(e)(...t) : n(...t) : n;
}
function wv(n = {}) {
  return Object.keys(n).length === 0 && n.constructor === Object;
}
function Ur(n) {
  const e = n.filter((i) => i.type === "extension"), t = n.filter((i) => i.type === "node"), r = n.filter((i) => i.type === "mark");
  return {
    baseExtensions: e,
    nodeExtensions: t,
    markExtensions: r
  };
}
function Qa(n) {
  const e = [], { nodeExtensions: t, markExtensions: r } = Ur(n), i = [...t, ...r], s = {
    default: null,
    validate: void 0,
    rendered: !0,
    renderHTML: null,
    parseHTML: null,
    keepOnSplit: !0,
    isRequired: !1
  };
  return n.forEach((o) => {
    const l = {
      name: o.name,
      options: o.options,
      storage: o.storage,
      extensions: i
    }, a = j(
      o,
      "addGlobalAttributes",
      l
    );
    if (!a)
      return;
    a().forEach((c) => {
      c.types.forEach((d) => {
        Object.entries(c.attributes).forEach(([f, h]) => {
          e.push({
            type: d,
            name: f,
            attribute: {
              ...s,
              ...h
            }
          });
        });
      });
    });
  }), i.forEach((o) => {
    const l = {
      name: o.name,
      options: o.options,
      storage: o.storage
    }, a = j(
      o,
      "addAttributes",
      l
    );
    if (!a)
      return;
    const u = a();
    Object.entries(u).forEach(([c, d]) => {
      const f = {
        ...s,
        ...d
      };
      typeof (f == null ? void 0 : f.default) == "function" && (f.default = f.default()), f != null && f.isRequired && (f == null ? void 0 : f.default) === void 0 && delete f.default, e.push({
        type: o.name,
        name: c,
        attribute: f
      });
    });
  }), e;
}
function Fe(...n) {
  return n.filter((e) => !!e).reduce((e, t) => {
    const r = { ...e };
    return Object.entries(t).forEach(([i, s]) => {
      if (!r[i]) {
        r[i] = s;
        return;
      }
      if (i === "class") {
        const l = s ? String(s).split(" ") : [], a = r[i] ? r[i].split(" ") : [], u = l.filter((c) => !a.includes(c));
        r[i] = [...a, ...u].join(" ");
      } else if (i === "style") {
        const l = s ? s.split(";").map((c) => c.trim()).filter(Boolean) : [], a = r[i] ? r[i].split(";").map((c) => c.trim()).filter(Boolean) : [], u = /* @__PURE__ */ new Map();
        a.forEach((c) => {
          const [d, f] = c.split(":").map((h) => h.trim());
          u.set(d, f);
        }), l.forEach((c) => {
          const [d, f] = c.split(":").map((h) => h.trim());
          u.set(d, f);
        }), r[i] = Array.from(u.entries()).map(([c, d]) => `${c}: ${d}`).join("; ");
      } else
        r[i] = s;
    }), r;
  }, {});
}
function Xs(n, e) {
  return e.filter((t) => t.type === n.type.name).filter((t) => t.attribute.rendered).map((t) => t.attribute.renderHTML ? t.attribute.renderHTML(n.attrs) || {} : {
    [t.name]: n.attrs[t.name]
  }).reduce((t, r) => Fe(t, r), {});
}
function Ev(n) {
  return typeof n != "string" ? n : n.match(/^[+-]?(?:\d*\.)?\d+$/) ? Number(n) : n === "true" ? !0 : n === "false" ? !1 : n;
}
function jd(n, e) {
  return "style" in n ? n : {
    ...n,
    getAttrs: (t) => {
      const r = n.getAttrs ? n.getAttrs(t) : n.attrs;
      if (r === !1)
        return !1;
      const i = e.reduce((s, o) => {
        const l = o.attribute.parseHTML ? o.attribute.parseHTML(t) : Ev(t.getAttribute(o.name));
        return l == null ? s : {
          ...s,
          [o.name]: l
        };
      }, {});
      return { ...r, ...i };
    }
  };
}
function Vd(n) {
  return Object.fromEntries(
    // @ts-ignore
    Object.entries(n).filter(([e, t]) => e === "attrs" && wv(t) ? !1 : t != null)
  );
}
function Yp(n, e) {
  var t;
  const r = Qa(n), { nodeExtensions: i, markExtensions: s } = Ur(n), o = (t = i.find((u) => j(u, "topNode"))) == null ? void 0 : t.name, l = Object.fromEntries(
    i.map((u) => {
      const c = r.filter((k) => k.type === u.name), d = {
        name: u.name,
        options: u.options,
        storage: u.storage,
        editor: e
      }, f = n.reduce((k, b) => {
        const y = j(b, "extendNodeSchema", d);
        return {
          ...k,
          ...y ? y(u) : {}
        };
      }, {}), h = Vd({
        ...f,
        content: me(j(u, "content", d)),
        marks: me(j(u, "marks", d)),
        group: me(j(u, "group", d)),
        inline: me(j(u, "inline", d)),
        atom: me(j(u, "atom", d)),
        selectable: me(j(u, "selectable", d)),
        draggable: me(j(u, "draggable", d)),
        code: me(j(u, "code", d)),
        whitespace: me(j(u, "whitespace", d)),
        linebreakReplacement: me(
          j(u, "linebreakReplacement", d)
        ),
        defining: me(j(u, "defining", d)),
        isolating: me(j(u, "isolating", d)),
        attrs: Object.fromEntries(
          c.map((k) => {
            var b, y;
            return [
              k.name,
              { default: (b = k == null ? void 0 : k.attribute) == null ? void 0 : b.default, validate: (y = k == null ? void 0 : k.attribute) == null ? void 0 : y.validate }
            ];
          })
        )
      }), p = me(j(u, "parseHTML", d));
      p && (h.parseDOM = p.map(
        (k) => jd(k, c)
      ));
      const g = j(u, "renderHTML", d);
      g && (h.toDOM = (k) => g({
        node: k,
        HTMLAttributes: Xs(k, c)
      }));
      const _ = j(u, "renderText", d);
      return _ && (h.toText = _), [u.name, h];
    })
  ), a = Object.fromEntries(
    s.map((u) => {
      const c = r.filter((_) => _.type === u.name), d = {
        name: u.name,
        options: u.options,
        storage: u.storage,
        editor: e
      }, f = n.reduce((_, k) => {
        const b = j(k, "extendMarkSchema", d);
        return {
          ..._,
          ...b ? b(u) : {}
        };
      }, {}), h = Vd({
        ...f,
        inclusive: me(j(u, "inclusive", d)),
        excludes: me(j(u, "excludes", d)),
        group: me(j(u, "group", d)),
        spanning: me(j(u, "spanning", d)),
        code: me(j(u, "code", d)),
        attrs: Object.fromEntries(
          c.map((_) => {
            var k, b;
            return [
              _.name,
              { default: (k = _ == null ? void 0 : _.attribute) == null ? void 0 : k.default, validate: (b = _ == null ? void 0 : _.attribute) == null ? void 0 : b.validate }
            ];
          })
        )
      }), p = me(j(u, "parseHTML", d));
      p && (h.parseDOM = p.map(
        (_) => jd(_, c)
      ));
      const g = j(u, "renderHTML", d);
      return g && (h.toDOM = (_) => g({
        mark: _,
        HTMLAttributes: Xs(_, c)
      })), [u.name, h];
    })
  );
  return new Nh({
    topNode: o,
    nodes: l,
    marks: a
  });
}
function Sv(n) {
  const e = n.filter((t, r) => n.indexOf(t) !== r);
  return Array.from(new Set(e));
}
function eu(n) {
  return n.sort((t, r) => {
    const i = j(t, "priority") || 100, s = j(r, "priority") || 100;
    return i > s ? -1 : i < s ? 1 : 0;
  });
}
function tu(n) {
  const e = eu(Xa(n)), t = Sv(e.map((r) => r.name));
  return t.length && console.warn(
    `[tiptap warn]: Duplicate extension names found: [${t.map((r) => `'${r}'`).join(", ")}]. This can lead to issues.`
  ), e;
}
function Xp(n, e, t) {
  const { from: r, to: i } = e, { blockSeparator: s = `

`, textSerializers: o = {} } = t || {};
  let l = "";
  return n.nodesBetween(r, i, (a, u, c, d) => {
    var f;
    a.isBlock && u > r && (l += s);
    const h = o == null ? void 0 : o[a.type.name];
    if (h)
      return c && (l += h({
        node: a,
        pos: u,
        parent: c,
        index: d,
        range: e
      })), !1;
    a.isText && (l += (f = a == null ? void 0 : a.text) == null ? void 0 : f.slice(Math.max(r, u) - u, i - u));
  }), l;
}
function Cv(n, e) {
  const t = {
    from: 0,
    to: n.content.size
  };
  return Xp(n, t, e);
}
function Zp(n) {
  return Object.fromEntries(
    Object.entries(n.nodes).filter(([, e]) => e.spec.toText).map(([e, t]) => [e, t.spec.toText])
  );
}
function Cn(n, e) {
  if (typeof n == "string") {
    if (!e.marks[n])
      throw Error(`There is no mark type named '${n}'. Maybe you forgot to add the extension?`);
    return e.marks[n];
  }
  return n;
}
function Qp(n, e) {
  const t = Cn(e, n.schema), { from: r, to: i, empty: s } = n.selection, o = [];
  s ? (n.storedMarks && o.push(...n.storedMarks), o.push(...n.selection.$head.marks())) : n.doc.nodesBetween(r, i, (a) => {
    o.push(...a.marks);
  });
  const l = o.find((a) => a.type.name === t.name);
  return l ? { ...l.attrs } : {};
}
function Re(n, e) {
  if (typeof n == "string") {
    if (!e.nodes[n])
      throw Error(`There is no node type named '${n}'. Maybe you forgot to add the extension?`);
    return e.nodes[n];
  }
  return n;
}
function Dv(n, e) {
  const t = Re(e, n.schema), { from: r, to: i } = n.selection, s = [];
  n.doc.nodesBetween(r, i, (l) => {
    s.push(l);
  });
  const o = s.reverse().find((l) => l.type.name === t.name);
  return o ? { ...o.attrs } : {};
}
function zo(n, e) {
  return e.nodes[n] ? "node" : e.marks[n] ? "mark" : null;
}
function em(n, e) {
  const t = zo(
    typeof e == "string" ? e : e.name,
    n.schema
  );
  return t === "node" ? Dv(n, e) : t === "mark" ? Qp(n, e) : {};
}
function Av(n, e = JSON.stringify) {
  const t = {};
  return n.filter((r) => {
    const i = e(r);
    return Object.prototype.hasOwnProperty.call(t, i) ? !1 : t[i] = !0;
  });
}
function Tv(n) {
  const e = Av(n);
  return e.length === 1 ? e : e.filter((t, r) => !e.filter((s, o) => o !== r).some((s) => t.oldRange.from >= s.oldRange.from && t.oldRange.to <= s.oldRange.to && t.newRange.from >= s.newRange.from && t.newRange.to <= s.newRange.to));
}
function tm(n) {
  const { mapping: e, steps: t } = n, r = [];
  return e.maps.forEach((i, s) => {
    const o = [];
    if (i.ranges.length)
      i.forEach((l, a) => {
        o.push({ from: l, to: a });
      });
    else {
      const { from: l, to: a } = t[s];
      if (l === void 0 || a === void 0)
        return;
      o.push({ from: l, to: a });
    }
    o.forEach(({ from: l, to: a }) => {
      const u = e.slice(s).map(l, -1), c = e.slice(s).map(a), d = e.invert().map(u, -1), f = e.invert().map(c);
      r.push({
        oldRange: {
          from: d,
          to: f
        },
        newRange: {
          from: u,
          to: c
        }
      });
    });
  }), Tv(r);
}
function nu(n) {
  return Object.prototype.toString.call(n) === "[object RegExp]";
}
function Zs(n, e, t = { strict: !0 }) {
  const r = Object.keys(e);
  return r.length ? r.every((i) => t.strict ? e[i] === n[i] : nu(e[i]) ? e[i].test(n[i]) : e[i] === n[i]) : !0;
}
function nm(n, e, t = {}) {
  return n.find((r) => r.type === e && Zs(
    // Only check equality for the attributes that are provided
    Object.fromEntries(Object.keys(t).map((i) => [i, r.attrs[i]])),
    t
  ));
}
function Ud(n, e, t = {}) {
  return !!nm(n, e, t);
}
function ru(n, e, t) {
  var r;
  if (!n || !e)
    return;
  let i = n.parent.childAfter(n.parentOffset);
  if ((!i.node || !i.node.marks.some((c) => c.type === e)) && (i = n.parent.childBefore(n.parentOffset)), !i.node || !i.node.marks.some((c) => c.type === e) || (t = t || ((r = i.node.marks[0]) == null ? void 0 : r.attrs), !nm([...i.node.marks], e, t)))
    return;
  let o = i.index, l = n.start() + i.offset, a = o + 1, u = l + i.node.nodeSize;
  for (; o > 0 && Ud([...n.parent.child(o - 1).marks], e, t); )
    o -= 1, l -= n.parent.child(o).nodeSize;
  for (; a < n.parent.childCount && Ud([...n.parent.child(a).marks], e, t); )
    u += n.parent.child(a).nodeSize, a += 1;
  return {
    from: l,
    to: u
  };
}
function iu(n, e, t) {
  const r = [];
  return n === e ? t.resolve(n).marks().forEach((i) => {
    const s = t.resolve(n), o = ru(s, i.type);
    o && r.push({
      mark: i,
      ...o
    });
  }) : t.nodesBetween(n, e, (i, s) => {
    !i || (i == null ? void 0 : i.nodeSize) === void 0 || r.push(
      ...i.marks.map((o) => ({
        from: s,
        to: s + i.nodeSize,
        mark: o
      }))
    );
  }), r;
}
var xv = (n, e, t, r = 20) => {
  const i = n.doc.resolve(t);
  let s = r, o = null;
  for (; s > 0 && o === null; ) {
    const l = i.node(s);
    (l == null ? void 0 : l.type.name) === e ? o = l : s -= 1;
  }
  return [o, s];
};
function Sl(n, e) {
  return e.nodes[n] || e.marks[n] || null;
}
function Os(n, e, t) {
  return Object.fromEntries(
    Object.entries(t).filter(([r]) => {
      const i = n.find((s) => s.type === e && s.name === r);
      return i ? i.attribute.keepOnSplit : !1;
    })
  );
}
var Mv = (n, e = 500) => {
  let t = "";
  const r = n.parentOffset;
  return n.parent.nodesBetween(Math.max(0, r - e), r, (i, s, o, l) => {
    var a, u;
    const c = ((u = (a = i.type.spec).toText) == null ? void 0 : u.call(a, {
      node: i,
      pos: s,
      parent: o,
      index: l
    })) || i.textContent || "%leaf%";
    t += i.isAtom && !i.isText ? c : c.slice(0, Math.max(0, r - s));
  }), t;
};
function fa(n, e, t = {}) {
  const { empty: r, ranges: i } = n.selection, s = e ? Cn(e, n.schema) : null;
  if (r)
    return !!(n.storedMarks || n.selection.$from.marks()).filter((d) => s ? s.name === d.type.name : !0).find((d) => Zs(d.attrs, t, { strict: !1 }));
  let o = 0;
  const l = [];
  if (i.forEach(({ $from: d, $to: f }) => {
    const h = d.pos, p = f.pos;
    n.doc.nodesBetween(h, p, (g, _) => {
      if (!g.isText && !g.marks.length)
        return;
      const k = Math.max(h, _), b = Math.min(p, _ + g.nodeSize), y = b - k;
      o += y, l.push(
        ...g.marks.map((v) => ({
          mark: v,
          from: k,
          to: b
        }))
      );
    });
  }), o === 0)
    return !1;
  const a = l.filter((d) => s ? s.name === d.mark.type.name : !0).filter((d) => Zs(d.mark.attrs, t, { strict: !1 })).reduce((d, f) => d + f.to - f.from, 0), u = l.filter((d) => s ? d.mark.type !== s && d.mark.type.excludes(s) : !0).reduce((d, f) => d + f.to - f.from, 0);
  return (a > 0 ? a + u : a) >= o;
}
function Wn(n, e, t = {}) {
  const { from: r, to: i, empty: s } = n.selection, o = e ? Re(e, n.schema) : null, l = [];
  n.doc.nodesBetween(r, i, (d, f) => {
    if (d.isText)
      return;
    const h = Math.max(r, f), p = Math.min(i, f + d.nodeSize);
    l.push({
      node: d,
      from: h,
      to: p
    });
  });
  const a = i - r, u = l.filter((d) => o ? o.name === d.node.type.name : !0).filter((d) => Zs(d.node.attrs, t, { strict: !1 }));
  return s ? !!u.length : u.reduce((d, f) => d + f.to - f.from, 0) >= a;
}
function $v(n, e, t = {}) {
  if (!e)
    return Wn(n, null, t) || fa(n, null, t);
  const r = zo(e, n.schema);
  return r === "node" ? Wn(n, e, t) : r === "mark" ? fa(n, e, t) : !1;
}
var Fv = (n, e) => {
  const { $from: t, $to: r, $anchor: i } = n.selection;
  if (e) {
    const s = Bo((l) => l.type.name === e)(n.selection);
    if (!s)
      return !1;
    const o = n.doc.resolve(s.pos + 1);
    return i.pos + 1 === o.end();
  }
  return !(r.parentOffset < r.parent.nodeSize - 2 || t.pos !== r.pos);
}, Ov = (n) => {
  const { $from: e, $to: t } = n.selection;
  return !(e.parentOffset > 0 || e.pos !== t.pos);
};
function Wd(n, e) {
  return Array.isArray(e) ? e.some((t) => (typeof t == "string" ? t : t.name) === n.name) : e;
}
function Kd(n, e) {
  const { nodeExtensions: t } = Ur(e), r = t.find((o) => o.name === n);
  if (!r)
    return !1;
  const i = {
    name: r.name,
    options: r.options,
    storage: r.storage
  }, s = me(j(r, "group", i));
  return typeof s != "string" ? !1 : s.split(" ").includes("list");
}
function Ho(n, {
  checkChildren: e = !0,
  ignoreWhitespace: t = !1
} = {}) {
  var r;
  if (t) {
    if (n.type.name === "hardBreak")
      return !0;
    if (n.isText)
      return /^\s*$/m.test((r = n.text) != null ? r : "");
  }
  if (n.isText)
    return !n.text;
  if (n.isAtom || n.isLeaf)
    return !1;
  if (n.content.childCount === 0)
    return !0;
  if (e) {
    let i = !0;
    return n.content.forEach((s) => {
      i !== !1 && (Ho(s, { ignoreWhitespace: t, checkChildren: e }) || (i = !1));
    }), i;
  }
  return !1;
}
function rm(n) {
  return n instanceof G;
}
function im(n) {
  return n instanceof Z;
}
function ir(n = 0, e = 0, t = 0) {
  return Math.min(Math.max(n, e), t);
}
function sm(n, e = null) {
  if (!e)
    return null;
  const t = re.atStart(n), r = re.atEnd(n);
  if (e === "start" || e === !0)
    return t;
  if (e === "end")
    return r;
  const i = t.from, s = r.to;
  return e === "all" ? Z.create(n, ir(0, i, s), ir(n.content.size, i, s)) : Z.create(n, ir(e, i, s), ir(e, i, s));
}
function Nv(n, e, t) {
  const r = n.steps.length - 1;
  if (r < e)
    return;
  const i = n.steps[r];
  if (!(i instanceof ze || i instanceof He))
    return;
  const s = n.mapping.maps[r];
  let o = 0;
  s.forEach((l, a, u, c) => {
    o === 0 && (o = c);
  }), n.setSelection(re.near(n.doc.resolve(o), t));
}
var qo = class {
  constructor(n) {
    this.find = n.find, this.handler = n.handler;
  }
}, Rv = (n, e) => {
  if (nu(e))
    return e.exec(n);
  const t = e(n);
  if (!t)
    return null;
  const r = [t.text];
  return r.index = t.index, r.input = n, r.data = t.data, t.replaceWith && (t.text.includes(t.replaceWith) || console.warn('[tiptap warn]: "inputRuleMatch.replaceWith" must be part of "inputRuleMatch.text".'), r.push(t.replaceWith)), r;
};
function ys(n) {
  var e;
  const { editor: t, from: r, to: i, text: s, rules: o, plugin: l } = n, { view: a } = t;
  if (a.composing)
    return !1;
  const u = a.state.doc.resolve(r);
  if (
    // check for code node
    u.parent.type.spec.code || (e = u.nodeBefore || u.nodeAfter) != null && e.marks.find((f) => f.type.spec.code)
  )
    return !1;
  let c = !1;
  const d = Mv(u) + s;
  return o.forEach((f) => {
    if (c)
      return;
    const h = Rv(d, f.find);
    if (!h)
      return;
    const p = a.state.tr, g = Lo({
      state: a.state,
      transaction: p
    }), _ = {
      from: r - (h[0].length - s.length),
      to: i
    }, { commands: k, chain: b, can: y } = new Po({
      editor: t,
      state: g
    });
    f.handler({
      state: g,
      range: _,
      match: h,
      commands: k,
      chain: b,
      can: y
    }) === null || !p.steps.length || (p.setMeta(l, {
      transform: p,
      from: r,
      to: i,
      text: s
    }), a.dispatch(p), c = !0);
  }), c;
}
function Iv(n) {
  const { editor: e, rules: t } = n, r = new Te({
    state: {
      init() {
        return null;
      },
      apply(i, s, o) {
        const l = i.getMeta(r);
        if (l)
          return l;
        const a = i.getMeta("applyInputRules");
        return !!a && setTimeout(() => {
          let { text: c } = a;
          typeof c == "string" ? c = c : c = Za(F.from(c), o.schema);
          const { from: d } = a, f = d + c.length;
          ys({
            editor: e,
            from: d,
            to: f,
            text: c,
            rules: t,
            plugin: r
          });
        }), i.selectionSet || i.docChanged ? null : s;
      }
    },
    props: {
      handleTextInput(i, s, o, l) {
        return ys({
          editor: e,
          from: s,
          to: o,
          text: l,
          rules: t,
          plugin: r
        });
      },
      handleDOMEvents: {
        compositionend: (i) => (setTimeout(() => {
          const { $cursor: s } = i.state.selection;
          s && ys({
            editor: e,
            from: s.pos,
            to: s.pos,
            text: "",
            rules: t,
            plugin: r
          });
        }), !1)
      },
      // add support for input rules to trigger on enter
      // this is useful for example for code blocks
      handleKeyDown(i, s) {
        if (s.key !== "Enter")
          return !1;
        const { $cursor: o } = i.state.selection;
        return o ? ys({
          editor: e,
          from: o.pos,
          to: o.pos,
          text: `
`,
          rules: t,
          plugin: r
        }) : !1;
      }
    },
    // @ts-ignore
    isInputRules: !0
  });
  return r;
}
function Lv(n) {
  return Object.prototype.toString.call(n).slice(8, -1);
}
function bs(n) {
  return Lv(n) !== "Object" ? !1 : n.constructor === Object && Object.getPrototypeOf(n) === Object.prototype;
}
function om(n, e) {
  const t = { ...n };
  return bs(n) && bs(e) && Object.keys(e).forEach((r) => {
    bs(e[r]) && bs(n[r]) ? t[r] = om(n[r], e[r]) : t[r] = e[r];
  }), t;
}
var su = class {
  constructor(n = {}) {
    this.type = "extendable", this.parent = null, this.child = null, this.name = "", this.config = {
      name: this.name
    }, this.config = {
      ...this.config,
      ...n
    }, this.name = this.config.name;
  }
  get options() {
    return {
      ...me(
        j(this, "addOptions", {
          name: this.name
        })
      ) || {}
    };
  }
  get storage() {
    return {
      ...me(
        j(this, "addStorage", {
          name: this.name,
          options: this.options
        })
      ) || {}
    };
  }
  configure(n = {}) {
    const e = this.extend({
      ...this.config,
      addOptions: () => om(this.options, n)
    });
    return e.name = this.name, e.parent = this.parent, e;
  }
  extend(n = {}) {
    const e = new this.constructor({ ...this.config, ...n });
    return e.parent = this, this.child = e, e.name = "name" in n ? n.name : e.parent.name, e;
  }
}, kr = class lm extends su {
  constructor() {
    super(...arguments), this.type = "mark";
  }
  /**
   * Create a new Mark instance
   * @param config - Mark configuration object or a function that returns a configuration object
   */
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new lm(t);
  }
  static handleExit({ editor: e, mark: t }) {
    const { tr: r } = e.state, i = e.state.selection.$from;
    if (i.pos === i.end()) {
      const o = i.marks();
      if (!!!o.find((u) => (u == null ? void 0 : u.type.name) === t.name))
        return !1;
      const a = o.find((u) => (u == null ? void 0 : u.type.name) === t.name);
      return a && r.removeStoredMark(a), r.insertText(" ", i.pos), e.view.dispatch(r), !0;
    }
    return !1;
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
};
function Pv(n) {
  return typeof n == "number";
}
var Bv = class {
  constructor(n) {
    this.find = n.find, this.handler = n.handler;
  }
}, zv = (n, e, t) => {
  if (nu(e))
    return [...n.matchAll(e)];
  const r = e(n, t);
  return r ? r.map((i) => {
    const s = [i.text];
    return s.index = i.index, s.input = n, s.data = i.data, i.replaceWith && (i.text.includes(i.replaceWith) || console.warn('[tiptap warn]: "pasteRuleMatch.replaceWith" must be part of "pasteRuleMatch.text".'), s.push(i.replaceWith)), s;
  }) : [];
};
function Hv(n) {
  const { editor: e, state: t, from: r, to: i, rule: s, pasteEvent: o, dropEvent: l } = n, { commands: a, chain: u, can: c } = new Po({
    editor: e,
    state: t
  }), d = [];
  return t.doc.nodesBetween(r, i, (h, p) => {
    if (!h.isTextblock || h.type.spec.code)
      return;
    const g = Math.max(r, p), _ = Math.min(i, p + h.content.size), k = h.textBetween(g - p, _ - p, void 0, "￼");
    zv(k, s.find, o).forEach((y) => {
      if (y.index === void 0)
        return;
      const v = g + y.index + 1, S = v + y[0].length, D = {
        from: t.tr.mapping.map(v),
        to: t.tr.mapping.map(S)
      }, T = s.handler({
        state: t,
        range: D,
        match: y,
        commands: a,
        chain: u,
        can: c,
        pasteEvent: o,
        dropEvent: l
      });
      d.push(T);
    });
  }), d.every((h) => h !== null);
}
var ks = null, qv = (n) => {
  var e;
  const t = new ClipboardEvent("paste", {
    clipboardData: new DataTransfer()
  });
  return (e = t.clipboardData) == null || e.setData("text/html", n), t;
};
function jv(n) {
  const { editor: e, rules: t } = n;
  let r = null, i = !1, s = !1, o = typeof ClipboardEvent < "u" ? new ClipboardEvent("paste") : null, l;
  try {
    l = typeof DragEvent < "u" ? new DragEvent("drop") : null;
  } catch {
    l = null;
  }
  const a = ({
    state: c,
    from: d,
    to: f,
    rule: h,
    pasteEvt: p
  }) => {
    const g = c.tr, _ = Lo({
      state: c,
      transaction: g
    });
    if (!(!Hv({
      editor: e,
      state: _,
      from: Math.max(d - 1, 0),
      to: f.b - 1,
      rule: h,
      pasteEvent: p,
      dropEvent: l
    }) || !g.steps.length)) {
      try {
        l = typeof DragEvent < "u" ? new DragEvent("drop") : null;
      } catch {
        l = null;
      }
      return o = typeof ClipboardEvent < "u" ? new ClipboardEvent("paste") : null, g;
    }
  };
  return t.map((c) => new Te({
    // we register a global drag handler to track the current drag source element
    view(d) {
      const f = (p) => {
        var g;
        r = (g = d.dom.parentElement) != null && g.contains(p.target) ? d.dom.parentElement : null, r && (ks = e);
      }, h = () => {
        ks && (ks = null);
      };
      return window.addEventListener("dragstart", f), window.addEventListener("dragend", h), {
        destroy() {
          window.removeEventListener("dragstart", f), window.removeEventListener("dragend", h);
        }
      };
    },
    props: {
      handleDOMEvents: {
        drop: (d, f) => {
          if (s = r === d.dom.parentElement, l = f, !s) {
            const h = ks;
            h != null && h.isEditable && setTimeout(() => {
              const p = h.state.selection;
              p && h.commands.deleteRange({ from: p.from, to: p.to });
            }, 10);
          }
          return !1;
        },
        paste: (d, f) => {
          var h;
          const p = (h = f.clipboardData) == null ? void 0 : h.getData("text/html");
          return o = f, i = !!(p != null && p.includes("data-pm-slice")), !1;
        }
      }
    },
    appendTransaction: (d, f, h) => {
      const p = d[0], g = p.getMeta("uiEvent") === "paste" && !i, _ = p.getMeta("uiEvent") === "drop" && !s, k = p.getMeta("applyPasteRules"), b = !!k;
      if (!g && !_ && !b)
        return;
      if (b) {
        let { text: S } = k;
        typeof S == "string" ? S = S : S = Za(F.from(S), h.schema);
        const { from: D } = k, T = D + S.length, x = qv(S);
        return a({
          rule: c,
          state: h,
          from: D,
          to: { b: T },
          pasteEvt: x
        });
      }
      const y = f.doc.content.findDiffStart(h.doc.content), v = f.doc.content.findDiffEnd(h.doc.content);
      if (!(!Pv(y) || !v || y === v.b))
        return a({
          rule: c,
          state: h,
          from: y,
          to: v,
          pasteEvt: o
        });
    }
  }));
}
var jo = class {
  constructor(n, e) {
    this.splittableMarks = [], this.editor = e, this.extensions = tu(n), this.schema = Yp(this.extensions, e), this.setupExtensions();
  }
  /**
   * Get all commands from the extensions.
   * @returns An object with all commands where the key is the command name and the value is the command function
   */
  get commands() {
    return this.extensions.reduce((n, e) => {
      const t = {
        name: e.name,
        options: e.options,
        storage: this.editor.extensionStorage[e.name],
        editor: this.editor,
        type: Sl(e.name, this.schema)
      }, r = j(e, "addCommands", t);
      return r ? {
        ...n,
        ...r()
      } : n;
    }, {});
  }
  /**
   * Get all registered Prosemirror plugins from the extensions.
   * @returns An array of Prosemirror plugins
   */
  get plugins() {
    const { editor: n } = this, e = eu([...this.extensions].reverse()), t = [], r = [], i = e.map((s) => {
      const o = {
        name: s.name,
        options: s.options,
        storage: this.editor.extensionStorage[s.name],
        editor: n,
        type: Sl(s.name, this.schema)
      }, l = [], a = j(
        s,
        "addKeyboardShortcuts",
        o
      );
      let u = {};
      if (s.type === "mark" && j(s, "exitable", o) && (u.ArrowRight = () => kr.handleExit({ editor: n, mark: s })), a) {
        const p = Object.fromEntries(
          Object.entries(a()).map(([g, _]) => [g, () => _({ editor: n })])
        );
        u = { ...u, ...p };
      }
      const c = Yk(u);
      l.push(c);
      const d = j(s, "addInputRules", o);
      Wd(s, n.options.enableInputRules) && d && t.push(...d());
      const f = j(s, "addPasteRules", o);
      Wd(s, n.options.enablePasteRules) && f && r.push(...f());
      const h = j(
        s,
        "addProseMirrorPlugins",
        o
      );
      if (h) {
        const p = h();
        l.push(...p);
      }
      return l;
    }).flat();
    return [
      Iv({
        editor: n,
        rules: t
      }),
      ...jv({
        editor: n,
        rules: r
      }),
      ...i
    ];
  }
  /**
   * Get all attributes from the extensions.
   * @returns An array of attributes
   */
  get attributes() {
    return Qa(this.extensions);
  }
  /**
   * Get all node views from the extensions.
   * @returns An object with all node views where the key is the node name and the value is the node view function
   */
  get nodeViews() {
    const { editor: n } = this, { nodeExtensions: e } = Ur(this.extensions);
    return Object.fromEntries(
      e.filter((t) => !!j(t, "addNodeView")).map((t) => {
        const r = this.attributes.filter((l) => l.type === t.name), i = {
          name: t.name,
          options: t.options,
          storage: this.editor.extensionStorage[t.name],
          editor: n,
          type: Re(t.name, this.schema)
        }, s = j(t, "addNodeView", i);
        if (!s)
          return [];
        const o = (l, a, u, c, d) => {
          const f = Xs(l, r);
          return s()({
            // pass-through
            node: l,
            view: a,
            getPos: u,
            decorations: c,
            innerDecorations: d,
            // tiptap-specific
            editor: n,
            extension: t,
            HTMLAttributes: f
          });
        };
        return [t.name, o];
      })
    );
  }
  get markViews() {
    const { editor: n } = this, { markExtensions: e } = Ur(this.extensions);
    return Object.fromEntries(
      e.filter((t) => !!j(t, "addMarkView")).map((t) => {
        const r = this.attributes.filter((l) => l.type === t.name), i = {
          name: t.name,
          options: t.options,
          storage: this.editor.extensionStorage[t.name],
          editor: n,
          type: Cn(t.name, this.schema)
        }, s = j(t, "addMarkView", i);
        if (!s)
          return [];
        const o = (l, a, u) => {
          const c = Xs(l, r);
          return s()({
            // pass-through
            mark: l,
            view: a,
            inline: u,
            // tiptap-specific
            editor: n,
            extension: t,
            HTMLAttributes: c,
            updateAttributes: (d) => {
              iE(l, n, d);
            }
          });
        };
        return [t.name, o];
      })
    );
  }
  /**
   * Go through all extensions, create extension storages & setup marks
   * & bind editor event listener.
   */
  setupExtensions() {
    const n = this.extensions;
    this.editor.extensionStorage = Object.fromEntries(
      n.map((e) => [e.name, e.storage])
    ), n.forEach((e) => {
      var t;
      const r = {
        name: e.name,
        options: e.options,
        storage: this.editor.extensionStorage[e.name],
        editor: this.editor,
        type: Sl(e.name, this.schema)
      };
      e.type === "mark" && ((t = me(j(e, "keepOnSplit", r))) == null || t) && this.splittableMarks.push(e.name);
      const i = j(e, "onBeforeCreate", r), s = j(e, "onCreate", r), o = j(e, "onUpdate", r), l = j(
        e,
        "onSelectionUpdate",
        r
      ), a = j(e, "onTransaction", r), u = j(e, "onFocus", r), c = j(e, "onBlur", r), d = j(e, "onDestroy", r);
      i && this.editor.on("beforeCreate", i), s && this.editor.on("create", s), o && this.editor.on("update", o), l && this.editor.on("selectionUpdate", l), a && this.editor.on("transaction", a), u && this.editor.on("focus", u), c && this.editor.on("blur", c), d && this.editor.on("destroy", d);
    });
  }
};
jo.resolve = tu;
jo.sort = eu;
jo.flatten = Xa;
var Vv = {};
Wp(Vv, {
  ClipboardTextSerializer: () => um,
  Commands: () => fm,
  Delete: () => hm,
  Drop: () => pm,
  Editable: () => mm,
  FocusEvents: () => _m,
  Keymap: () => ym,
  Paste: () => bm,
  Tabindex: () => km,
  focusEventsPluginKey: () => gm
});
var Oe = class am extends su {
  constructor() {
    super(...arguments), this.type = "extension";
  }
  /**
   * Create a new Extension instance
   * @param config - Extension configuration object or a function that returns a configuration object
   */
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new am(t);
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
}, um = Oe.create({
  name: "clipboardTextSerializer",
  addOptions() {
    return {
      blockSeparator: void 0
    };
  },
  addProseMirrorPlugins() {
    return [
      new Te({
        key: new Ie("clipboardTextSerializer"),
        props: {
          clipboardTextSerializer: () => {
            const { editor: n } = this, { state: e, schema: t } = n, { doc: r, selection: i } = e, { ranges: s } = i, o = Math.min(...s.map((c) => c.$from.pos)), l = Math.max(...s.map((c) => c.$to.pos)), a = Zp(t);
            return Xp(r, { from: o, to: l }, {
              ...this.options.blockSeparator !== void 0 ? { blockSeparator: this.options.blockSeparator } : {},
              textSerializers: a
            });
          }
        }
      })
    ];
  }
}), cm = {};
Wp(cm, {
  blur: () => Uv,
  clearContent: () => Wv,
  clearNodes: () => Kv,
  command: () => Gv,
  createParagraphNear: () => Jv,
  cut: () => Yv,
  deleteCurrentNode: () => Xv,
  deleteNode: () => Zv,
  deleteRange: () => Qv,
  deleteSelection: () => ew,
  enter: () => tw,
  exitCode: () => nw,
  extendMarkRange: () => rw,
  first: () => iw,
  focus: () => ow,
  forEach: () => lw,
  insertContent: () => aw,
  insertContentAt: () => cw,
  joinBackward: () => hw,
  joinDown: () => fw,
  joinForward: () => pw,
  joinItemBackward: () => mw,
  joinItemForward: () => gw,
  joinTextblockBackward: () => _w,
  joinTextblockForward: () => yw,
  joinUp: () => dw,
  keyboardShortcut: () => kw,
  lift: () => vw,
  liftEmptyBlock: () => ww,
  liftListItem: () => Ew,
  newlineInCode: () => Sw,
  resetAttributes: () => Cw,
  scrollIntoView: () => Dw,
  selectAll: () => Aw,
  selectNodeBackward: () => Tw,
  selectNodeForward: () => xw,
  selectParentNode: () => Mw,
  selectTextblockEnd: () => $w,
  selectTextblockStart: () => Fw,
  setContent: () => Ow,
  setMark: () => Rw,
  setMeta: () => Iw,
  setNode: () => Lw,
  setNodeSelection: () => Pw,
  setTextSelection: () => Bw,
  sinkListItem: () => zw,
  splitBlock: () => Hw,
  splitListItem: () => qw,
  toggleList: () => jw,
  toggleMark: () => Vw,
  toggleNode: () => Uw,
  toggleWrap: () => Ww,
  undoInputRule: () => Kw,
  unsetAllMarks: () => Gw,
  unsetMark: () => Jw,
  updateAttributes: () => Yw,
  wrapIn: () => Xw,
  wrapInList: () => Zw
});
var Uv = () => ({ editor: n, view: e }) => (requestAnimationFrame(() => {
  var t;
  n.isDestroyed || (e.dom.blur(), (t = window == null ? void 0 : window.getSelection()) == null || t.removeAllRanges());
}), !0), Wv = (n = !0) => ({ commands: e }) => e.setContent("", { emitUpdate: n }), Kv = () => ({ state: n, tr: e, dispatch: t }) => {
  const { selection: r } = e, { ranges: i } = r;
  return t && i.forEach(({ $from: s, $to: o }) => {
    n.doc.nodesBetween(s.pos, o.pos, (l, a) => {
      if (l.type.isText)
        return;
      const { doc: u, mapping: c } = e, d = u.resolve(c.map(a)), f = u.resolve(c.map(a + l.nodeSize)), h = d.blockRange(f);
      if (!h)
        return;
      const p = Gr(h);
      if (l.type.isTextblock) {
        const { defaultType: g } = d.parent.contentMatchAt(d.index());
        e.setNodeMarkup(h.start, g);
      }
      (p || p === 0) && e.lift(h, p);
    });
  }), !0;
}, Gv = (n) => (e) => n(e), Jv = () => ({ state: n, dispatch: e }) => qp(n, e), Yv = (n, e) => ({ editor: t, tr: r }) => {
  const { state: i } = t, s = i.doc.slice(n.from, n.to);
  r.deleteRange(n.from, n.to);
  const o = r.mapping.map(e);
  return r.insert(o, s.content), r.setSelection(new Z(r.doc.resolve(Math.max(o - 1, 0)))), !0;
}, Xv = () => ({ tr: n, dispatch: e }) => {
  const { selection: t } = n, r = t.$anchor.node();
  if (r.content.size > 0)
    return !1;
  const i = n.selection.$anchor;
  for (let s = i.depth; s > 0; s -= 1)
    if (i.node(s).type === r.type) {
      if (e) {
        const l = i.before(s), a = i.after(s);
        n.delete(l, a).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, Zv = (n) => ({ tr: e, state: t, dispatch: r }) => {
  const i = Re(n, t.schema), s = e.selection.$anchor;
  for (let o = s.depth; o > 0; o -= 1)
    if (s.node(o).type === i) {
      if (r) {
        const a = s.before(o), u = s.after(o);
        e.delete(a, u).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, Qv = (n) => ({ tr: e, dispatch: t }) => {
  const { from: r, to: i } = n;
  return t && e.delete(r, i), !0;
}, ew = () => ({ state: n, dispatch: e }) => Wa(n, e), tw = () => ({ commands: n }) => n.keyboardShortcut("Enter"), nw = () => ({ state: n, dispatch: e }) => nv(n, e), rw = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  const s = Cn(n, r.schema), { doc: o, selection: l } = t, { $from: a, from: u, to: c } = l;
  if (i) {
    const d = ru(a, s, e);
    if (d && d.from <= u && d.to >= c) {
      const f = Z.create(o, d.from, d.to);
      t.setSelection(f);
    }
  }
  return !0;
}, iw = (n) => (e) => {
  const t = typeof n == "function" ? n(e) : n;
  for (let r = 0; r < t.length; r += 1)
    if (t[r](e))
      return !0;
  return !1;
};
function sw() {
  return navigator.platform === "Android" || /android/i.test(navigator.userAgent);
}
function ou() {
  return ["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"].includes(navigator.platform) || // iPad on iOS 13 detection
  navigator.userAgent.includes("Mac") && "ontouchend" in document;
}
var ow = (n = null, e = {}) => ({ editor: t, view: r, tr: i, dispatch: s }) => {
  e = {
    scrollIntoView: !0,
    ...e
  };
  const o = () => {
    (ou() || sw()) && r.dom.focus(), requestAnimationFrame(() => {
      t.isDestroyed || (r.focus(), e != null && e.scrollIntoView && t.commands.scrollIntoView());
    });
  };
  if (r.hasFocus() && n === null || n === !1)
    return !0;
  if (s && n === null && !im(t.state.selection))
    return o(), !0;
  const l = sm(i.doc, n) || t.state.selection, a = t.state.selection.eq(l);
  return s && (a || i.setSelection(l), a && i.storedMarks && i.setStoredMarks(i.storedMarks), o()), !0;
}, lw = (n, e) => (t) => n.every((r, i) => e(r, { ...t, index: i })), aw = (n, e) => ({ tr: t, commands: r }) => r.insertContentAt({ from: t.selection.from, to: t.selection.to }, n, e), uw = (n) => !("type" in n), cw = (n, e, t) => ({ tr: r, dispatch: i, editor: s }) => {
  var o;
  if (i) {
    t = {
      parseOptions: s.options.parseOptions,
      updateSelection: !0,
      applyInputRules: !1,
      applyPasteRules: !1,
      ...t
    };
    let l;
    const { selection: a } = s.state, u = (k) => {
      s.emit("contentError", {
        editor: s,
        error: k,
        disableCollaboration: () => {
          "collaboration" in s.storage && typeof s.storage.collaboration == "object" && s.storage.collaboration && (s.storage.collaboration.isDisabled = !0);
        }
      });
    }, c = {
      preserveWhitespace: "full",
      ...t.parseOptions
    };
    if (!t.errorOnInvalidContent && !s.options.enableContentCheck && s.options.emitContentError)
      try {
        zi(e, s.schema, {
          parseOptions: c,
          errorOnInvalidContent: !0
        });
      } catch (k) {
        u(k);
      }
    try {
      l = zi(e, s.schema, {
        parseOptions: c,
        errorOnInvalidContent: (o = t.errorOnInvalidContent) != null ? o : s.options.enableContentCheck
      });
    } catch (k) {
      return u(k), !1;
    }
    let { from: d, to: f } = typeof n == "number" ? { from: n, to: n } : { from: n.from, to: n.to }, h = !0, p = !0;
    if ((uw(l) ? l : [l]).forEach((k) => {
      k.check(), h = h ? k.isText && k.marks.length === 0 : !1, p = p ? k.isBlock : !1;
    }), d === f && p) {
      const { parent: k } = r.doc.resolve(d);
      k.isTextblock && !k.type.spec.code && !k.childCount && (d -= 1, f += 1);
    }
    let _;
    if (h) {
      if (Array.isArray(e))
        _ = e.map((k) => k.text || "").join("");
      else if (e instanceof F) {
        let k = "";
        e.forEach((b) => {
          b.text && (k += b.text);
        }), _ = k;
      } else typeof e == "object" && e && e.text ? _ = e.text : _ = e;
      r.insertText(_, d, f);
    } else {
      _ = l;
      const k = a.$from.parentOffset === 0, b = a.$from.node().isText || a.$from.node().isTextblock, y = a.$from.node().content.size > 0;
      k && b && y && (d = Math.max(0, d - 1)), r.replaceWith(d, f, _);
    }
    t.updateSelection && Nv(r, r.steps.length - 1, -1), t.applyInputRules && r.setMeta("applyInputRules", { from: d, text: _ }), t.applyPasteRules && r.setMeta("applyPasteRules", { from: d, text: _ });
  }
  return !0;
}, dw = () => ({ state: n, dispatch: e }) => Qk(n, e), fw = () => ({ state: n, dispatch: e }) => ev(n, e), hw = () => ({ state: n, dispatch: e }) => Rp(n, e), pw = () => ({ state: n, dispatch: e }) => Bp(n, e), mw = () => ({ state: n, dispatch: e, tr: t }) => {
  try {
    const r = $o(n.doc, n.selection.$from.pos, -1);
    return r == null ? !1 : (t.join(r, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, gw = () => ({ state: n, dispatch: e, tr: t }) => {
  try {
    const r = $o(n.doc, n.selection.$from.pos, 1);
    return r == null ? !1 : (t.join(r, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, _w = () => ({ state: n, dispatch: e }) => Xk(n, e), yw = () => ({ state: n, dispatch: e }) => Zk(n, e);
function dm() {
  return typeof navigator < "u" ? /Mac/.test(navigator.platform) : !1;
}
function bw(n) {
  const e = n.split(/-(?!$)/);
  let t = e[e.length - 1];
  t === "Space" && (t = " ");
  let r, i, s, o;
  for (let l = 0; l < e.length - 1; l += 1) {
    const a = e[l];
    if (/^(cmd|meta|m)$/i.test(a))
      o = !0;
    else if (/^a(lt)?$/i.test(a))
      r = !0;
    else if (/^(c|ctrl|control)$/i.test(a))
      i = !0;
    else if (/^s(hift)?$/i.test(a))
      s = !0;
    else if (/^mod$/i.test(a))
      ou() || dm() ? o = !0 : i = !0;
    else
      throw new Error(`Unrecognized modifier name: ${a}`);
  }
  return r && (t = `Alt-${t}`), i && (t = `Ctrl-${t}`), o && (t = `Meta-${t}`), s && (t = `Shift-${t}`), t;
}
var kw = (n) => ({ editor: e, view: t, tr: r, dispatch: i }) => {
  const s = bw(n).split(/-(?!$)/), o = s.find((u) => !["Alt", "Ctrl", "Meta", "Shift"].includes(u)), l = new KeyboardEvent("keydown", {
    key: o === "Space" ? " " : o,
    altKey: s.includes("Alt"),
    ctrlKey: s.includes("Ctrl"),
    metaKey: s.includes("Meta"),
    shiftKey: s.includes("Shift"),
    bubbles: !0,
    cancelable: !0
  }), a = e.captureTransaction(() => {
    t.someProp("handleKeyDown", (u) => u(t, l));
  });
  return a == null || a.steps.forEach((u) => {
    const c = u.map(r.mapping);
    c && i && r.maybeStep(c);
  }), !0;
}, vw = (n, e = {}) => ({ state: t, dispatch: r }) => {
  const i = Re(n, t.schema);
  return Wn(t, i, e) ? tv(t, r) : !1;
}, ww = () => ({ state: n, dispatch: e }) => jp(n, e), Ew = (n) => ({ state: e, dispatch: t }) => {
  const r = Re(n, e.schema);
  return hv(r)(e, t);
}, Sw = () => ({ state: n, dispatch: e }) => Hp(n, e);
function Gd(n, e) {
  const t = typeof e == "string" ? [e] : e;
  return Object.keys(n).reduce((r, i) => (t.includes(i) || (r[i] = n[i]), r), {});
}
var Cw = (n, e) => ({ tr: t, state: r, dispatch: i }) => {
  let s = null, o = null;
  const l = zo(
    typeof n == "string" ? n : n.name,
    r.schema
  );
  return l ? (l === "node" && (s = Re(n, r.schema)), l === "mark" && (o = Cn(n, r.schema)), i && t.selection.ranges.forEach((a) => {
    r.doc.nodesBetween(a.$from.pos, a.$to.pos, (u, c) => {
      s && s === u.type && t.setNodeMarkup(c, void 0, Gd(u.attrs, e)), o && u.marks.length && u.marks.forEach((d) => {
        o === d.type && t.addMark(c, c + u.nodeSize, o.create(Gd(d.attrs, e)));
      });
    });
  }), !0) : !1;
}, Dw = () => ({ tr: n, dispatch: e }) => (e && n.scrollIntoView(), !0), Aw = () => ({ tr: n, dispatch: e }) => {
  if (e) {
    const t = new yt(n.doc);
    n.setSelection(t);
  }
  return !0;
}, Tw = () => ({ state: n, dispatch: e }) => Lp(n, e), xw = () => ({ state: n, dispatch: e }) => zp(n, e), Mw = () => ({ state: n, dispatch: e }) => sv(n, e), $w = () => ({ state: n, dispatch: e }) => av(n, e), Fw = () => ({ state: n, dispatch: e }) => lv(n, e), Ow = (n, { errorOnInvalidContent: e, emitUpdate: t = !0, parseOptions: r = {} } = {}) => ({ editor: i, tr: s, dispatch: o, commands: l }) => {
  const { doc: a } = s;
  if (r.preserveWhitespace !== "full") {
    const u = da(n, i.schema, r, {
      errorOnInvalidContent: e ?? i.options.enableContentCheck
    });
    return o && s.replaceWith(0, a.content.size, u).setMeta("preventUpdate", !t), !0;
  }
  return o && s.setMeta("preventUpdate", !t), l.insertContentAt({ from: 0, to: a.content.size }, n, {
    parseOptions: r,
    errorOnInvalidContent: e ?? i.options.enableContentCheck
  });
};
function Nw(n, e, t) {
  var r;
  const { selection: i } = e;
  let s = null;
  if (im(i) && (s = i.$cursor), s) {
    const l = (r = n.storedMarks) != null ? r : s.marks();
    return !!t.isInSet(l) || !l.some((a) => a.type.excludes(t));
  }
  const { ranges: o } = i;
  return o.some(({ $from: l, $to: a }) => {
    let u = l.depth === 0 ? n.doc.inlineContent && n.doc.type.allowsMarkType(t) : !1;
    return n.doc.nodesBetween(l.pos, a.pos, (c, d, f) => {
      if (u)
        return !1;
      if (c.isInline) {
        const h = !f || f.type.allowsMarkType(t), p = !!t.isInSet(c.marks) || !c.marks.some((g) => g.type.excludes(t));
        u = h && p;
      }
      return !u;
    }), u;
  });
}
var Rw = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  const { selection: s } = t, { empty: o, ranges: l } = s, a = Cn(n, r.schema);
  if (i)
    if (o) {
      const u = Qp(r, a);
      t.addStoredMark(
        a.create({
          ...u,
          ...e
        })
      );
    } else
      l.forEach((u) => {
        const c = u.$from.pos, d = u.$to.pos;
        r.doc.nodesBetween(c, d, (f, h) => {
          const p = Math.max(h, c), g = Math.min(h + f.nodeSize, d);
          f.marks.find((k) => k.type === a) ? f.marks.forEach((k) => {
            a === k.type && t.addMark(
              p,
              g,
              a.create({
                ...k.attrs,
                ...e
              })
            );
          }) : t.addMark(p, g, a.create(e));
        });
      });
  return Nw(r, t, a);
}, Iw = (n, e) => ({ tr: t }) => (t.setMeta(n, e), !0), Lw = (n, e = {}) => ({ state: t, dispatch: r, chain: i }) => {
  const s = Re(n, t.schema);
  let o;
  return t.selection.$anchor.sameParent(t.selection.$head) && (o = t.selection.$anchor.parent.attrs), s.isTextblock ? i().command(({ commands: l }) => qd(s, { ...o, ...e })(t) ? !0 : l.clearNodes()).command(({ state: l }) => qd(s, { ...o, ...e })(l, r)).run() : (console.warn('[tiptap warn]: Currently "setNode()" only supports text block nodes.'), !1);
}, Pw = (n) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: r } = e, i = ir(n, 0, r.content.size), s = G.create(r, i);
    e.setSelection(s);
  }
  return !0;
}, Bw = (n) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: r } = e, { from: i, to: s } = typeof n == "number" ? { from: n, to: n } : n, o = Z.atStart(r).from, l = Z.atEnd(r).to, a = ir(i, o, l), u = ir(s, o, l), c = Z.create(r, a, u);
    e.setSelection(c);
  }
  return !0;
}, zw = (n) => ({ state: e, dispatch: t }) => {
  const r = Re(n, e.schema);
  return gv(r)(e, t);
};
function Jd(n, e) {
  const t = n.storedMarks || n.selection.$to.parentOffset && n.selection.$from.marks();
  if (t) {
    const r = t.filter((i) => e == null ? void 0 : e.includes(i.type.name));
    n.tr.ensureMarks(r);
  }
}
var Hw = ({ keepMarks: n = !0 } = {}) => ({ tr: e, state: t, dispatch: r, editor: i }) => {
  const { selection: s, doc: o } = e, { $from: l, $to: a } = s, u = i.extensionManager.attributes, c = Os(u, l.node().type.name, l.node().attrs);
  if (s instanceof G && s.node.isBlock)
    return !l.parentOffset || !En(o, l.pos) ? !1 : (r && (n && Jd(t, i.extensionManager.splittableMarks), e.split(l.pos).scrollIntoView()), !0);
  if (!l.parent.isBlock)
    return !1;
  const d = a.parentOffset === a.parent.content.size, f = l.depth === 0 ? void 0 : bv(l.node(-1).contentMatchAt(l.indexAfter(-1)));
  let h = d && f ? [
    {
      type: f,
      attrs: c
    }
  ] : void 0, p = En(e.doc, e.mapping.map(l.pos), 1, h);
  if (!h && !p && En(e.doc, e.mapping.map(l.pos), 1, f ? [{ type: f }] : void 0) && (p = !0, h = f ? [
    {
      type: f,
      attrs: c
    }
  ] : void 0), r) {
    if (p && (s instanceof Z && e.deleteSelection(), e.split(e.mapping.map(l.pos), 1, h), f && !d && !l.parentOffset && l.parent.type !== f)) {
      const g = e.mapping.map(l.before()), _ = e.doc.resolve(g);
      l.node(-1).canReplaceWith(_.index(), _.index() + 1, f) && e.setNodeMarkup(e.mapping.map(l.before()), f);
    }
    n && Jd(t, i.extensionManager.splittableMarks), e.scrollIntoView();
  }
  return p;
}, qw = (n, e = {}) => ({ tr: t, state: r, dispatch: i, editor: s }) => {
  var o;
  const l = Re(n, r.schema), { $from: a, $to: u } = r.selection, c = r.selection.node;
  if (c && c.isBlock || a.depth < 2 || !a.sameParent(u))
    return !1;
  const d = a.node(-1);
  if (d.type !== l)
    return !1;
  const f = s.extensionManager.attributes;
  if (a.parent.content.size === 0 && a.node(-1).childCount === a.indexAfter(-1)) {
    if (a.depth === 2 || a.node(-3).type !== l || a.index(-2) !== a.node(-2).childCount - 1)
      return !1;
    if (i) {
      let k = F.empty;
      const b = a.index(-1) ? 1 : a.index(-2) ? 2 : 3;
      for (let x = a.depth - b; x >= a.depth - 3; x -= 1)
        k = F.from(a.node(x).copy(k));
      const y = (
        // eslint-disable-next-line no-nested-ternary
        a.indexAfter(-1) < a.node(-2).childCount ? 1 : a.indexAfter(-2) < a.node(-3).childCount ? 2 : 3
      ), v = {
        ...Os(f, a.node().type.name, a.node().attrs),
        ...e
      }, S = ((o = l.contentMatch.defaultType) == null ? void 0 : o.createAndFill(v)) || void 0;
      k = k.append(F.from(l.createAndFill(null, S) || void 0));
      const D = a.before(a.depth - (b - 1));
      t.replace(D, a.after(-y), new z(k, 4 - b, 0));
      let T = -1;
      t.doc.nodesBetween(D, t.doc.content.size, (x, M) => {
        if (T > -1)
          return !1;
        x.isTextblock && x.content.size === 0 && (T = M + 1);
      }), T > -1 && t.setSelection(Z.near(t.doc.resolve(T))), t.scrollIntoView();
    }
    return !0;
  }
  const h = u.pos === a.end() ? d.contentMatchAt(0).defaultType : null, p = {
    ...Os(f, d.type.name, d.attrs),
    ...e
  }, g = {
    ...Os(f, a.node().type.name, a.node().attrs),
    ...e
  };
  t.delete(a.pos, u.pos);
  const _ = h ? [
    { type: l, attrs: p },
    { type: h, attrs: g }
  ] : [{ type: l, attrs: p }];
  if (!En(t.doc, a.pos, 2))
    return !1;
  if (i) {
    const { selection: k, storedMarks: b } = r, { splittableMarks: y } = s.extensionManager, v = b || k.$to.parentOffset && k.$from.marks();
    if (t.split(a.pos, 2, _).scrollIntoView(), !v || !i)
      return !0;
    const S = v.filter((D) => y.includes(D.type.name));
    t.ensureMarks(S);
  }
  return !0;
}, Cl = (n, e) => {
  const t = Bo((o) => o.type === e)(n.selection);
  if (!t)
    return !0;
  const r = n.doc.resolve(Math.max(0, t.pos - 1)).before(t.depth);
  if (r === void 0)
    return !0;
  const i = n.doc.nodeAt(r);
  return t.node.type === (i == null ? void 0 : i.type) && Kn(n.doc, t.pos) && n.join(t.pos), !0;
}, Dl = (n, e) => {
  const t = Bo((o) => o.type === e)(n.selection);
  if (!t)
    return !0;
  const r = n.doc.resolve(t.start).after(t.depth);
  if (r === void 0)
    return !0;
  const i = n.doc.nodeAt(r);
  return t.node.type === (i == null ? void 0 : i.type) && Kn(n.doc, r) && n.join(r), !0;
}, jw = (n, e, t, r = {}) => ({ editor: i, tr: s, state: o, dispatch: l, chain: a, commands: u, can: c }) => {
  const { extensions: d, splittableMarks: f } = i.extensionManager, h = Re(n, o.schema), p = Re(e, o.schema), { selection: g, storedMarks: _ } = o, { $from: k, $to: b } = g, y = k.blockRange(b), v = _ || g.$to.parentOffset && g.$from.marks();
  if (!y)
    return !1;
  const S = Bo((D) => Kd(D.type.name, d))(g);
  if (y.depth >= 1 && S && y.depth - S.depth <= 1) {
    if (S.node.type === h)
      return u.liftListItem(p);
    if (Kd(S.node.type.name, d) && h.validContent(S.node.content) && l)
      return a().command(() => (s.setNodeMarkup(S.pos, h), !0)).command(() => Cl(s, h)).command(() => Dl(s, h)).run();
  }
  return !t || !v || !l ? a().command(() => c().wrapInList(h, r) ? !0 : u.clearNodes()).wrapInList(h, r).command(() => Cl(s, h)).command(() => Dl(s, h)).run() : a().command(() => {
    const D = c().wrapInList(h, r), T = v.filter((x) => f.includes(x.type.name));
    return s.ensureMarks(T), D ? !0 : u.clearNodes();
  }).wrapInList(h, r).command(() => Cl(s, h)).command(() => Dl(s, h)).run();
}, Vw = (n, e = {}, t = {}) => ({ state: r, commands: i }) => {
  const { extendEmptyMarkRange: s = !1 } = t, o = Cn(n, r.schema);
  return fa(r, o, e) ? i.unsetMark(o, { extendEmptyMarkRange: s }) : i.setMark(o, e);
}, Uw = (n, e, t = {}) => ({ state: r, commands: i }) => {
  const s = Re(n, r.schema), o = Re(e, r.schema), l = Wn(r, s, t);
  let a;
  return r.selection.$anchor.sameParent(r.selection.$head) && (a = r.selection.$anchor.parent.attrs), l ? i.setNode(o, a) : i.setNode(s, { ...a, ...t });
}, Ww = (n, e = {}) => ({ state: t, commands: r }) => {
  const i = Re(n, t.schema);
  return Wn(t, i, e) ? r.lift(i) : r.wrapIn(i, e);
}, Kw = () => ({ state: n, dispatch: e }) => {
  const t = n.plugins;
  for (let r = 0; r < t.length; r += 1) {
    const i = t[r];
    let s;
    if (i.spec.isInputRules && (s = i.getState(n))) {
      if (e) {
        const o = n.tr, l = s.transform;
        for (let a = l.steps.length - 1; a >= 0; a -= 1)
          o.step(l.steps[a].invert(l.docs[a]));
        if (s.text) {
          const a = o.doc.resolve(s.from).marks();
          o.replaceWith(s.from, s.to, n.schema.text(s.text, a));
        } else
          o.delete(s.from, s.to);
      }
      return !0;
    }
  }
  return !1;
}, Gw = () => ({ tr: n, dispatch: e }) => {
  const { selection: t } = n, { empty: r, ranges: i } = t;
  return r || e && i.forEach((s) => {
    n.removeMark(s.$from.pos, s.$to.pos);
  }), !0;
}, Jw = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  var s;
  const { extendEmptyMarkRange: o = !1 } = e, { selection: l } = t, a = Cn(n, r.schema), { $from: u, empty: c, ranges: d } = l;
  if (!i)
    return !0;
  if (c && o) {
    let { from: f, to: h } = l;
    const p = (s = u.marks().find((_) => _.type === a)) == null ? void 0 : s.attrs, g = ru(u, a, p);
    g && (f = g.from, h = g.to), t.removeMark(f, h, a);
  } else
    d.forEach((f) => {
      t.removeMark(f.$from.pos, f.$to.pos, a);
    });
  return t.removeStoredMark(a), !0;
}, Yw = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  let s = null, o = null;
  const l = zo(
    typeof n == "string" ? n : n.name,
    r.schema
  );
  return l ? (l === "node" && (s = Re(n, r.schema)), l === "mark" && (o = Cn(n, r.schema)), i && t.selection.ranges.forEach((a) => {
    const u = a.$from.pos, c = a.$to.pos;
    let d, f, h, p;
    t.selection.empty ? r.doc.nodesBetween(u, c, (g, _) => {
      s && s === g.type && (h = Math.max(_, u), p = Math.min(_ + g.nodeSize, c), d = _, f = g);
    }) : r.doc.nodesBetween(u, c, (g, _) => {
      _ < u && s && s === g.type && (h = Math.max(_, u), p = Math.min(_ + g.nodeSize, c), d = _, f = g), _ >= u && _ <= c && (s && s === g.type && t.setNodeMarkup(_, void 0, {
        ...g.attrs,
        ...e
      }), o && g.marks.length && g.marks.forEach((k) => {
        if (o === k.type) {
          const b = Math.max(_, u), y = Math.min(_ + g.nodeSize, c);
          t.addMark(
            b,
            y,
            o.create({
              ...k.attrs,
              ...e
            })
          );
        }
      }));
    }), f && (d !== void 0 && t.setNodeMarkup(d, void 0, {
      ...f.attrs,
      ...e
    }), o && f.marks.length && f.marks.forEach((g) => {
      o === g.type && t.addMark(
        h,
        p,
        o.create({
          ...g.attrs,
          ...e
        })
      );
    }));
  }), !0) : !1;
}, Xw = (n, e = {}) => ({ state: t, dispatch: r }) => {
  const i = Re(n, t.schema);
  return uv(i, e)(t, r);
}, Zw = (n, e = {}) => ({ state: t, dispatch: r }) => {
  const i = Re(n, t.schema);
  return cv(i, e)(t, r);
}, fm = Oe.create({
  name: "commands",
  addCommands() {
    return {
      ...cm
    };
  }
}), hm = Oe.create({
  name: "delete",
  onUpdate({ transaction: n, appendedTransactions: e }) {
    var t, r, i;
    const s = () => {
      var o, l, a, u;
      if ((u = (a = (l = (o = this.editor.options.coreExtensionOptions) == null ? void 0 : o.delete) == null ? void 0 : l.filterTransaction) == null ? void 0 : a.call(l, n)) != null ? u : n.getMeta("y-sync$"))
        return;
      const c = Kp(n.before, [n, ...e]);
      tm(c).forEach((h) => {
        c.mapping.mapResult(h.oldRange.from).deletedAfter && c.mapping.mapResult(h.oldRange.to).deletedBefore && c.before.nodesBetween(h.oldRange.from, h.oldRange.to, (p, g) => {
          const _ = g + p.nodeSize - 2, k = h.oldRange.from <= g && _ <= h.oldRange.to;
          this.editor.emit("delete", {
            type: "node",
            node: p,
            from: g,
            to: _,
            newFrom: c.mapping.map(g),
            newTo: c.mapping.map(_),
            deletedRange: h.oldRange,
            newRange: h.newRange,
            partial: !k,
            editor: this.editor,
            transaction: n,
            combinedTransform: c
          });
        });
      });
      const f = c.mapping;
      c.steps.forEach((h, p) => {
        var g, _;
        if (h instanceof jt) {
          const k = f.slice(p).map(h.from, -1), b = f.slice(p).map(h.to), y = f.invert().map(k, -1), v = f.invert().map(b), S = (g = c.doc.nodeAt(k - 1)) == null ? void 0 : g.marks.some((T) => T.eq(h.mark)), D = (_ = c.doc.nodeAt(b)) == null ? void 0 : _.marks.some((T) => T.eq(h.mark));
          this.editor.emit("delete", {
            type: "mark",
            mark: h.mark,
            from: h.from,
            to: h.to,
            deletedRange: {
              from: y,
              to: v
            },
            newRange: {
              from: k,
              to: b
            },
            partial: !!(D || S),
            editor: this.editor,
            transaction: n,
            combinedTransform: c
          });
        }
      });
    };
    (i = (r = (t = this.editor.options.coreExtensionOptions) == null ? void 0 : t.delete) == null ? void 0 : r.async) == null || i ? setTimeout(s, 0) : s();
  }
}), pm = Oe.create({
  name: "drop",
  addProseMirrorPlugins() {
    return [
      new Te({
        key: new Ie("tiptapDrop"),
        props: {
          handleDrop: (n, e, t, r) => {
            this.editor.emit("drop", {
              editor: this.editor,
              event: e,
              slice: t,
              moved: r
            });
          }
        }
      })
    ];
  }
}), mm = Oe.create({
  name: "editable",
  addProseMirrorPlugins() {
    return [
      new Te({
        key: new Ie("editable"),
        props: {
          editable: () => this.editor.options.editable
        }
      })
    ];
  }
}), gm = new Ie("focusEvents"), _m = Oe.create({
  name: "focusEvents",
  addProseMirrorPlugins() {
    const { editor: n } = this;
    return [
      new Te({
        key: gm,
        props: {
          handleDOMEvents: {
            focus: (e, t) => {
              n.isFocused = !0;
              const r = n.state.tr.setMeta("focus", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(r), !1;
            },
            blur: (e, t) => {
              n.isFocused = !1;
              const r = n.state.tr.setMeta("blur", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(r), !1;
            }
          }
        }
      })
    ];
  }
}), ym = Oe.create({
  name: "keymap",
  addKeyboardShortcuts() {
    const n = () => this.editor.commands.first(({ commands: o }) => [
      () => o.undoInputRule(),
      // maybe convert first text block node to default node
      () => o.command(({ tr: l }) => {
        const { selection: a, doc: u } = l, { empty: c, $anchor: d } = a, { pos: f, parent: h } = d, p = d.parent.isTextblock && f > 0 ? l.doc.resolve(f - 1) : d, g = p.parent.type.spec.isolating, _ = d.pos - d.parentOffset, k = g && p.parent.childCount === 1 ? _ === d.pos : re.atStart(u).from === f;
        return !c || !h.type.isTextblock || h.textContent.length || !k || k && d.parent.type.name === "paragraph" ? !1 : o.clearNodes();
      }),
      () => o.deleteSelection(),
      () => o.joinBackward(),
      () => o.selectNodeBackward()
    ]), e = () => this.editor.commands.first(({ commands: o }) => [
      () => o.deleteSelection(),
      () => o.deleteCurrentNode(),
      () => o.joinForward(),
      () => o.selectNodeForward()
    ]), r = {
      Enter: () => this.editor.commands.first(({ commands: o }) => [
        () => o.newlineInCode(),
        () => o.createParagraphNear(),
        () => o.liftEmptyBlock(),
        () => o.splitBlock()
      ]),
      "Mod-Enter": () => this.editor.commands.exitCode(),
      Backspace: n,
      "Mod-Backspace": n,
      "Shift-Backspace": n,
      Delete: e,
      "Mod-Delete": e,
      "Mod-a": () => this.editor.commands.selectAll()
    }, i = {
      ...r
    }, s = {
      ...r,
      "Ctrl-h": n,
      "Alt-Backspace": n,
      "Ctrl-d": e,
      "Ctrl-Alt-Backspace": e,
      "Alt-Delete": e,
      "Alt-d": e,
      "Ctrl-a": () => this.editor.commands.selectTextblockStart(),
      "Ctrl-e": () => this.editor.commands.selectTextblockEnd()
    };
    return ou() || dm() ? s : i;
  },
  addProseMirrorPlugins() {
    return [
      // With this plugin we check if the whole document was selected and deleted.
      // In this case we will additionally call `clearNodes()` to convert e.g. a heading
      // to a paragraph if necessary.
      // This is an alternative to ProseMirror's `AllSelection`, which doesn’t work well
      // with many other commands.
      new Te({
        key: new Ie("clearDocument"),
        appendTransaction: (n, e, t) => {
          if (n.some((g) => g.getMeta("composition")))
            return;
          const r = n.some((g) => g.docChanged) && !e.doc.eq(t.doc), i = n.some((g) => g.getMeta("preventClearDocument"));
          if (!r || i)
            return;
          const { empty: s, from: o, to: l } = e.selection, a = re.atStart(e.doc).from, u = re.atEnd(e.doc).to;
          if (s || !(o === a && l === u) || !Ho(t.doc))
            return;
          const f = t.tr, h = Lo({
            state: t,
            transaction: f
          }), { commands: p } = new Po({
            editor: this.editor,
            state: h
          });
          if (p.clearNodes(), !!f.steps.length)
            return f;
        }
      })
    ];
  }
}), bm = Oe.create({
  name: "paste",
  addProseMirrorPlugins() {
    return [
      new Te({
        key: new Ie("tiptapPaste"),
        props: {
          handlePaste: (n, e, t) => {
            this.editor.emit("paste", {
              editor: this.editor,
              event: e,
              slice: t
            });
          }
        }
      })
    ];
  }
}), km = Oe.create({
  name: "tabindex",
  addProseMirrorPlugins() {
    return [
      new Te({
        key: new Ie("tabindex"),
        props: {
          attributes: () => this.editor.isEditable ? { tabindex: "0" } : {}
        }
      })
    ];
  }
}), Qw = class Fr {
  constructor(e, t, r = !1, i = null) {
    this.currentNode = null, this.actualDepth = null, this.isBlock = r, this.resolvedPos = e, this.editor = t, this.currentNode = i;
  }
  get name() {
    return this.node.type.name;
  }
  get node() {
    return this.currentNode || this.resolvedPos.node();
  }
  get element() {
    return this.editor.view.domAtPos(this.pos).node;
  }
  get depth() {
    var e;
    return (e = this.actualDepth) != null ? e : this.resolvedPos.depth;
  }
  get pos() {
    return this.resolvedPos.pos;
  }
  get content() {
    return this.node.content;
  }
  set content(e) {
    let t = this.from, r = this.to;
    if (this.isBlock) {
      if (this.content.size === 0) {
        console.error(`You can’t set content on a block node. Tried to set content on ${this.name} at ${this.pos}`);
        return;
      }
      t = this.from + 1, r = this.to - 1;
    }
    this.editor.commands.insertContentAt({ from: t, to: r }, e);
  }
  get attributes() {
    return this.node.attrs;
  }
  get textContent() {
    return this.node.textContent;
  }
  get size() {
    return this.node.nodeSize;
  }
  get from() {
    return this.isBlock ? this.pos : this.resolvedPos.start(this.resolvedPos.depth);
  }
  get range() {
    return {
      from: this.from,
      to: this.to
    };
  }
  get to() {
    return this.isBlock ? this.pos + this.size : this.resolvedPos.end(this.resolvedPos.depth) + (this.node.isText ? 0 : 1);
  }
  get parent() {
    if (this.depth === 0)
      return null;
    const e = this.resolvedPos.start(this.resolvedPos.depth - 1), t = this.resolvedPos.doc.resolve(e);
    return new Fr(t, this.editor);
  }
  get before() {
    let e = this.resolvedPos.doc.resolve(this.from - (this.isBlock ? 1 : 2));
    return e.depth !== this.depth && (e = this.resolvedPos.doc.resolve(this.from - 3)), new Fr(e, this.editor);
  }
  get after() {
    let e = this.resolvedPos.doc.resolve(this.to + (this.isBlock ? 2 : 1));
    return e.depth !== this.depth && (e = this.resolvedPos.doc.resolve(this.to + 3)), new Fr(e, this.editor);
  }
  get children() {
    const e = [];
    return this.node.content.forEach((t, r) => {
      const i = t.isBlock && !t.isTextblock, s = t.isAtom && !t.isText, o = this.pos + r + (s ? 0 : 1);
      if (o < 0 || o > this.resolvedPos.doc.nodeSize - 2)
        return;
      const l = this.resolvedPos.doc.resolve(o);
      if (!i && l.depth <= this.depth)
        return;
      const a = new Fr(l, this.editor, i, i ? t : null);
      i && (a.actualDepth = this.depth + 1), e.push(new Fr(l, this.editor, i, i ? t : null));
    }), e;
  }
  get firstChild() {
    return this.children[0] || null;
  }
  get lastChild() {
    const e = this.children;
    return e[e.length - 1] || null;
  }
  closest(e, t = {}) {
    let r = null, i = this.parent;
    for (; i && !r; ) {
      if (i.node.type.name === e)
        if (Object.keys(t).length > 0) {
          const s = i.node.attrs, o = Object.keys(t);
          for (let l = 0; l < o.length; l += 1) {
            const a = o[l];
            if (s[a] !== t[a])
              break;
          }
        } else
          r = i;
      i = i.parent;
    }
    return r;
  }
  querySelector(e, t = {}) {
    return this.querySelectorAll(e, t, !0)[0] || null;
  }
  querySelectorAll(e, t = {}, r = !1) {
    let i = [];
    if (!this.children || this.children.length === 0)
      return i;
    const s = Object.keys(t);
    return this.children.forEach((o) => {
      r && i.length > 0 || (o.node.type.name === e && s.every((a) => t[a] === o.node.attrs[a]) && i.push(o), !(r && i.length > 0) && (i = i.concat(o.querySelectorAll(e, t, r))));
    }), i;
  }
  setAttribute(e) {
    const { tr: t } = this.editor.state;
    t.setNodeMarkup(this.from, void 0, {
      ...this.node.attrs,
      ...e
    }), this.editor.view.dispatch(t);
  }
}, eE = `.ProseMirror {
  position: relative;
}

.ProseMirror {
  word-wrap: break-word;
  white-space: pre-wrap;
  white-space: break-spaces;
  -webkit-font-variant-ligatures: none;
  font-variant-ligatures: none;
  font-feature-settings: "liga" 0; /* the above doesn't seem to work in Edge */
}

.ProseMirror [contenteditable="false"] {
  white-space: normal;
}

.ProseMirror [contenteditable="false"] [contenteditable="true"] {
  white-space: pre-wrap;
}

.ProseMirror pre {
  white-space: pre-wrap;
}

img.ProseMirror-separator {
  display: inline !important;
  border: none !important;
  margin: 0 !important;
  width: 0 !important;
  height: 0 !important;
}

.ProseMirror-gapcursor {
  display: none;
  pointer-events: none;
  position: absolute;
  margin: 0;
}

.ProseMirror-gapcursor:after {
  content: "";
  display: block;
  position: absolute;
  top: -2px;
  width: 20px;
  border-top: 1px solid black;
  animation: ProseMirror-cursor-blink 1.1s steps(2, start) infinite;
}

@keyframes ProseMirror-cursor-blink {
  to {
    visibility: hidden;
  }
}

.ProseMirror-hideselection *::selection {
  background: transparent;
}

.ProseMirror-hideselection *::-moz-selection {
  background: transparent;
}

.ProseMirror-hideselection * {
  caret-color: transparent;
}

.ProseMirror-focused .ProseMirror-gapcursor {
  display: block;
}`;
function tE(n, e, t) {
  const r = document.querySelector("style[data-tiptap-style]");
  if (r !== null)
    return r;
  const i = document.createElement("style");
  return e && i.setAttribute("nonce", e), i.setAttribute("data-tiptap-style", ""), i.innerHTML = n, document.getElementsByTagName("head")[0].appendChild(i), i;
}
var nE = class extends yv {
  constructor(n = {}) {
    super(), this.css = null, this.editorView = null, this.isFocused = !1, this.isInitialized = !1, this.extensionStorage = {}, this.instanceId = Math.random().toString(36).slice(2, 9), this.options = {
      element: typeof document < "u" ? document.createElement("div") : null,
      content: "",
      injectCSS: !0,
      injectNonce: void 0,
      extensions: [],
      autofocus: !1,
      editable: !0,
      editorProps: {},
      parseOptions: {},
      coreExtensionOptions: {},
      enableInputRules: !0,
      enablePasteRules: !0,
      enableCoreExtensions: !0,
      enableContentCheck: !1,
      emitContentError: !1,
      onBeforeCreate: () => null,
      onCreate: () => null,
      onUpdate: () => null,
      onSelectionUpdate: () => null,
      onTransaction: () => null,
      onFocus: () => null,
      onBlur: () => null,
      onDestroy: () => null,
      onContentError: ({ error: r }) => {
        throw r;
      },
      onPaste: () => null,
      onDrop: () => null,
      onDelete: () => null
    }, this.isCapturingTransaction = !1, this.capturedTransaction = null, this.setOptions(n), this.createExtensionManager(), this.createCommandManager(), this.createSchema(), this.on("beforeCreate", this.options.onBeforeCreate), this.emit("beforeCreate", { editor: this }), this.on("contentError", this.options.onContentError), this.on("create", this.options.onCreate), this.on("update", this.options.onUpdate), this.on("selectionUpdate", this.options.onSelectionUpdate), this.on("transaction", this.options.onTransaction), this.on("focus", this.options.onFocus), this.on("blur", this.options.onBlur), this.on("destroy", this.options.onDestroy), this.on("drop", ({ event: r, slice: i, moved: s }) => this.options.onDrop(r, i, s)), this.on("paste", ({ event: r, slice: i }) => this.options.onPaste(r, i)), this.on("delete", this.options.onDelete);
    const e = this.createDoc(), t = sm(e, this.options.autofocus);
    this.editorState = Ir.create({
      doc: e,
      schema: this.schema,
      selection: t || void 0
    }), this.options.element && this.mount(this.options.element);
  }
  /**
   * Attach the editor to the DOM, creating a new editor view.
   */
  mount(n) {
    if (typeof document > "u")
      throw new Error(
        "[tiptap error]: The editor cannot be mounted because there is no 'document' defined in this environment."
      );
    this.createView(n), window.setTimeout(() => {
      this.isDestroyed || (this.commands.focus(this.options.autofocus), this.emit("create", { editor: this }), this.isInitialized = !0);
    }, 0);
  }
  /**
   * Remove the editor from the DOM, but still allow remounting at a different point in time
   */
  unmount() {
    var n;
    if (this.editorView) {
      const e = this.editorView.dom;
      e != null && e.editor && delete e.editor, this.editorView.destroy();
    }
    this.editorView = null, this.isInitialized = !1, (n = this.css) == null || n.remove(), this.css = null;
  }
  /**
   * Returns the editor storage.
   */
  get storage() {
    return this.extensionStorage;
  }
  /**
   * An object of all registered commands.
   */
  get commands() {
    return this.commandManager.commands;
  }
  /**
   * Create a command chain to call multiple commands at once.
   */
  chain() {
    return this.commandManager.chain();
  }
  /**
   * Check if a command or a command chain can be executed. Without executing it.
   */
  can() {
    return this.commandManager.can();
  }
  /**
   * Inject CSS styles.
   */
  injectCSS() {
    this.options.injectCSS && typeof document < "u" && (this.css = tE(eE, this.options.injectNonce));
  }
  /**
   * Update editor options.
   *
   * @param options A list of options
   */
  setOptions(n = {}) {
    this.options = {
      ...this.options,
      ...n
    }, !(!this.editorView || !this.state || this.isDestroyed) && (this.options.editorProps && this.view.setProps(this.options.editorProps), this.view.updateState(this.state));
  }
  /**
   * Update editable state of the editor.
   */
  setEditable(n, e = !0) {
    this.setOptions({ editable: n }), e && this.emit("update", { editor: this, transaction: this.state.tr, appendedTransactions: [] });
  }
  /**
   * Returns whether the editor is editable.
   */
  get isEditable() {
    return this.options.editable && this.view && this.view.editable;
  }
  /**
   * Returns the editor state.
   */
  get view() {
    return this.editorView ? this.editorView : new Proxy(
      {
        state: this.editorState,
        updateState: (n) => {
          this.editorState = n;
        },
        dispatch: (n) => {
          this.editorState = this.state.apply(n);
        },
        // Stub some commonly accessed properties to prevent errors
        composing: !1,
        dragging: null,
        editable: !0,
        isDestroyed: !1
      },
      {
        get: (n, e) => {
          if (e === "state")
            return this.editorState;
          if (e in n)
            return Reflect.get(n, e);
          throw new Error(
            `[tiptap error]: The editor view is not available. Cannot access view['${e}']. The editor may not be mounted yet.`
          );
        }
      }
    );
  }
  /**
   * Returns the editor state.
   */
  get state() {
    return this.editorView && (this.editorState = this.view.state), this.editorState;
  }
  /**
   * Register a ProseMirror plugin.
   *
   * @param plugin A ProseMirror plugin
   * @param handlePlugins Control how to merge the plugin into the existing plugins.
   * @returns The new editor state
   */
  registerPlugin(n, e) {
    const t = Jp(e) ? e(n, [...this.state.plugins]) : [...this.state.plugins, n], r = this.state.reconfigure({ plugins: t });
    return this.view.updateState(r), r;
  }
  /**
   * Unregister a ProseMirror plugin.
   *
   * @param nameOrPluginKeyToRemove The plugins name
   * @returns The new editor state or undefined if the editor is destroyed
   */
  unregisterPlugin(n) {
    if (this.isDestroyed)
      return;
    const e = this.state.plugins;
    let t = e;
    if ([].concat(n).forEach((i) => {
      const s = typeof i == "string" ? `${i}$` : i.key;
      t = t.filter((o) => !o.key.startsWith(s));
    }), e.length === t.length)
      return;
    const r = this.state.reconfigure({
      plugins: t
    });
    return this.view.updateState(r), r;
  }
  /**
   * Creates an extension manager.
   */
  createExtensionManager() {
    var n, e;
    const r = [...this.options.enableCoreExtensions ? [
      mm,
      um.configure({
        blockSeparator: (e = (n = this.options.coreExtensionOptions) == null ? void 0 : n.clipboardTextSerializer) == null ? void 0 : e.blockSeparator
      }),
      fm,
      _m,
      ym,
      km,
      pm,
      bm,
      hm
    ].filter((i) => typeof this.options.enableCoreExtensions == "object" ? this.options.enableCoreExtensions[i.name] !== !1 : !0) : [], ...this.options.extensions].filter((i) => ["extension", "node", "mark"].includes(i == null ? void 0 : i.type));
    this.extensionManager = new jo(r, this);
  }
  /**
   * Creates an command manager.
   */
  createCommandManager() {
    this.commandManager = new Po({
      editor: this
    });
  }
  /**
   * Creates a ProseMirror schema.
   */
  createSchema() {
    this.schema = this.extensionManager.schema;
  }
  /**
   * Creates the initial document.
   */
  createDoc() {
    let n;
    try {
      n = da(this.options.content, this.schema, this.options.parseOptions, {
        errorOnInvalidContent: this.options.enableContentCheck
      });
    } catch (e) {
      if (!(e instanceof Error) || !["[tiptap error]: Invalid JSON content", "[tiptap error]: Invalid HTML content"].includes(e.message))
        throw e;
      this.emit("contentError", {
        editor: this,
        error: e,
        disableCollaboration: () => {
          "collaboration" in this.storage && typeof this.storage.collaboration == "object" && this.storage.collaboration && (this.storage.collaboration.isDisabled = !0), this.options.extensions = this.options.extensions.filter((t) => t.name !== "collaboration"), this.createExtensionManager();
        }
      }), n = da(this.options.content, this.schema, this.options.parseOptions, {
        errorOnInvalidContent: !1
      });
    }
    return n;
  }
  /**
   * Creates a ProseMirror view.
   */
  createView(n) {
    var e;
    this.editorView = new Fp(n, {
      ...this.options.editorProps,
      attributes: {
        // add `role="textbox"` to the editor element
        role: "textbox",
        ...(e = this.options.editorProps) == null ? void 0 : e.attributes
      },
      dispatchTransaction: this.dispatchTransaction.bind(this),
      state: this.editorState
    });
    const t = this.state.reconfigure({
      plugins: this.extensionManager.plugins
    });
    this.view.updateState(t), this.createNodeViews(), this.prependClass(), this.injectCSS();
    const r = this.view.dom;
    r.editor = this;
  }
  /**
   * Creates all node and mark views.
   */
  createNodeViews() {
    this.view.isDestroyed || this.view.setProps({
      markViews: this.extensionManager.markViews,
      nodeViews: this.extensionManager.nodeViews
    });
  }
  /**
   * Prepend class name to element.
   */
  prependClass() {
    this.view.dom.className = `tiptap ${this.view.dom.className}`;
  }
  captureTransaction(n) {
    this.isCapturingTransaction = !0, n(), this.isCapturingTransaction = !1;
    const e = this.capturedTransaction;
    return this.capturedTransaction = null, e;
  }
  /**
   * The callback over which to send transactions (state updates) produced by the view.
   *
   * @param transaction An editor state transaction
   */
  dispatchTransaction(n) {
    if (this.view.isDestroyed)
      return;
    if (this.isCapturingTransaction) {
      if (!this.capturedTransaction) {
        this.capturedTransaction = n;
        return;
      }
      n.steps.forEach((u) => {
        var c;
        return (c = this.capturedTransaction) == null ? void 0 : c.step(u);
      });
      return;
    }
    const { state: e, transactions: t } = this.state.applyTransaction(n), r = !this.state.selection.eq(e.selection), i = t.includes(n), s = this.state;
    if (this.emit("beforeTransaction", {
      editor: this,
      transaction: n,
      nextState: e
    }), !i)
      return;
    this.view.updateState(e), this.emit("transaction", {
      editor: this,
      transaction: n,
      appendedTransactions: t.slice(1)
    }), r && this.emit("selectionUpdate", {
      editor: this,
      transaction: n
    });
    const o = t.findLast((u) => u.getMeta("focus") || u.getMeta("blur")), l = o == null ? void 0 : o.getMeta("focus"), a = o == null ? void 0 : o.getMeta("blur");
    l && this.emit("focus", {
      editor: this,
      event: l.event,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      transaction: o
    }), a && this.emit("blur", {
      editor: this,
      event: a.event,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      transaction: o
    }), !(n.getMeta("preventUpdate") || !t.some((u) => u.docChanged) || s.doc.eq(e.doc)) && this.emit("update", {
      editor: this,
      transaction: n,
      appendedTransactions: t.slice(1)
    });
  }
  /**
   * Get attributes of the currently selected node or mark.
   */
  getAttributes(n) {
    return em(this.state, n);
  }
  isActive(n, e) {
    const t = typeof n == "string" ? n : null, r = typeof n == "string" ? e : n;
    return $v(this.state, t, r);
  }
  /**
   * Get the document as JSON.
   */
  getJSON() {
    return this.state.doc.toJSON();
  }
  /**
   * Get the document as HTML.
   */
  getHTML() {
    return Za(this.state.doc.content, this.schema);
  }
  /**
   * Get the document as text.
   */
  getText(n) {
    const { blockSeparator: e = `

`, textSerializers: t = {} } = n || {};
    return Cv(this.state.doc, {
      blockSeparator: e,
      textSerializers: {
        ...Zp(this.schema),
        ...t
      }
    });
  }
  /**
   * Check if there is no content.
   */
  get isEmpty() {
    return Ho(this.state.doc);
  }
  /**
   * Destroy the editor.
   */
  destroy() {
    this.emit("destroy"), this.unmount(), this.removeAllListeners();
  }
  /**
   * Check if the editor is already destroyed.
   */
  get isDestroyed() {
    var n, e;
    return (e = (n = this.editorView) == null ? void 0 : n.isDestroyed) != null ? e : !0;
  }
  $node(n, e) {
    var t;
    return ((t = this.$doc) == null ? void 0 : t.querySelector(n, e)) || null;
  }
  $nodes(n, e) {
    var t;
    return ((t = this.$doc) == null ? void 0 : t.querySelectorAll(n, e)) || null;
  }
  $pos(n) {
    const e = this.state.doc.resolve(n);
    return new Qw(e, this);
  }
  get $doc() {
    return this.$pos(0);
  }
};
function Wr(n) {
  return new qo({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = me(n.getAttributes, void 0, r);
      if (i === !1 || i === null)
        return null;
      const { tr: s } = e, o = r[r.length - 1], l = r[0];
      if (o) {
        const a = l.search(/\S/), u = t.from + l.indexOf(o), c = u + o.length;
        if (iu(t.from, t.to, e.doc).filter((h) => h.mark.type.excluded.find((g) => g === n.type && g !== h.mark.type)).filter((h) => h.to > u).length)
          return null;
        c < t.to && s.delete(c, t.to), u > t.from && s.delete(t.from + a, u);
        const f = t.from + a + o.length;
        s.addMark(t.from + a, f, n.type.create(i || {})), s.removeStoredMark(n.type);
      }
    }
  });
}
function vm(n) {
  return new qo({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = me(n.getAttributes, void 0, r) || {}, { tr: s } = e, o = t.from;
      let l = t.to;
      const a = n.type.create(i);
      if (r[1]) {
        const u = r[0].lastIndexOf(r[1]);
        let c = o + u;
        c > l ? c = l : l = c + r[1].length;
        const d = r[0][r[0].length - 1];
        s.insertText(d, o + r[0].length - 1), s.replaceWith(c, l, a);
      } else if (r[0]) {
        const u = n.type.isInline ? o : o - 1;
        s.insert(u, n.type.create(i)).delete(s.mapping.map(o), s.mapping.map(l));
      }
      s.scrollIntoView();
    }
  });
}
function ha(n) {
  return new qo({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = e.doc.resolve(t.from), s = me(n.getAttributes, void 0, r) || {};
      if (!i.node(-1).canReplaceWith(i.index(-1), i.indexAfter(-1), n.type))
        return null;
      e.tr.delete(t.from, t.to).setBlockType(t.from, t.from, n.type, s);
    }
  });
}
function Kr(n) {
  return new qo({
    find: n.find,
    handler: ({ state: e, range: t, match: r, chain: i }) => {
      const s = me(n.getAttributes, void 0, r) || {}, o = e.tr.delete(t.from, t.to), a = o.doc.resolve(t.from).blockRange(), u = a && Ra(a, n.type, s);
      if (!u)
        return null;
      if (o.wrap(a, u), n.keepMarks && n.editor) {
        const { selection: d, storedMarks: f } = e, { splittableMarks: h } = n.editor.extensionManager, p = f || d.$to.parentOffset && d.$from.marks();
        if (p) {
          const g = p.filter((_) => h.includes(_.type.name));
          o.ensureMarks(g);
        }
      }
      if (n.keepAttributes) {
        const d = n.type.name === "bulletList" || n.type.name === "orderedList" ? "listItem" : "taskList";
        i().updateAttributes(d, s).run();
      }
      const c = o.doc.resolve(t.from - 1).nodeBefore;
      c && c.type === n.type && Kn(o.doc, t.from - 1) && (!n.joinPredicate || n.joinPredicate(r, c)) && o.join(t.from - 1);
    }
  });
}
function rE(n, e) {
  const { selection: t } = n, { $from: r } = t;
  if (t instanceof G) {
    const s = r.index();
    return r.parent.canReplaceWith(s, s + 1, e);
  }
  let i = r.depth;
  for (; i >= 0; ) {
    const s = r.index(i);
    if (r.node(i).contentMatchAt(s).matchType(e))
      return !0;
    i -= 1;
  }
  return !1;
}
function iE(n, e, t = {}) {
  const { state: r } = e, { doc: i, tr: s } = r, o = n;
  i.descendants((l, a) => {
    const u = s.mapping.map(a), c = s.mapping.map(a) + l.nodeSize;
    let d = null;
    if (l.marks.forEach((h) => {
      if (h !== o)
        return !1;
      d = h;
    }), !d)
      return;
    let f = !1;
    if (Object.keys(t).forEach((h) => {
      t[h] !== d.attrs[h] && (f = !0);
    }), f) {
      const h = n.type.create({
        ...n.attrs,
        ...t
      });
      s.removeMark(u, c, n.type), s.addMark(u, c, h);
    }
  }), s.docChanged && e.view.dispatch(s);
}
var ft = class wm extends su {
  constructor() {
    super(...arguments), this.type = "node";
  }
  /**
   * Create a new Node instance
   * @param config - Node configuration object or a function that returns a configuration object
   */
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new wm(t);
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
};
function gr(n) {
  return new Bv({
    find: n.find,
    handler: ({ state: e, range: t, match: r, pasteEvent: i }) => {
      const s = me(n.getAttributes, void 0, r, i);
      if (s === !1 || s === null)
        return null;
      const { tr: o } = e, l = r[r.length - 1], a = r[0];
      let u = t.to;
      if (l) {
        const c = a.search(/\S/), d = t.from + a.indexOf(l), f = d + l.length;
        if (iu(t.from, t.to, e.doc).filter((p) => p.mark.type.excluded.find((_) => _ === n.type && _ !== p.mark.type)).filter((p) => p.to > d).length)
          return null;
        f < t.to && o.delete(f, t.to), d > t.from && o.delete(t.from + c, d), u = t.from + c + l.length, o.addMark(t.from + c, u, n.type.create(s || {})), o.removeStoredMark(n.type);
      }
    }
  });
}
var ne = {};
/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Yd;
function sE() {
  if (Yd) return ne;
  Yd = 1;
  var n = Symbol.for("react.transitional.element"), e = Symbol.for("react.portal"), t = Symbol.for("react.fragment"), r = Symbol.for("react.strict_mode"), i = Symbol.for("react.profiler"), s = Symbol.for("react.consumer"), o = Symbol.for("react.context"), l = Symbol.for("react.forward_ref"), a = Symbol.for("react.suspense"), u = Symbol.for("react.memo"), c = Symbol.for("react.lazy"), d = Symbol.iterator;
  function f(w) {
    return w === null || typeof w != "object" ? null : (w = d && w[d] || w["@@iterator"], typeof w == "function" ? w : null);
  }
  var h = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, p = Object.assign, g = {};
  function _(w, C, H) {
    this.props = w, this.context = C, this.refs = g, this.updater = H || h;
  }
  _.prototype.isReactComponent = {}, _.prototype.setState = function(w, C) {
    if (typeof w != "object" && typeof w != "function" && w != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, w, C, "setState");
  }, _.prototype.forceUpdate = function(w) {
    this.updater.enqueueForceUpdate(this, w, "forceUpdate");
  };
  function k() {
  }
  k.prototype = _.prototype;
  function b(w, C, H) {
    this.props = w, this.context = C, this.refs = g, this.updater = H || h;
  }
  var y = b.prototype = new k();
  y.constructor = b, p(y, _.prototype), y.isPureReactComponent = !0;
  var v = Array.isArray, S = { H: null, A: null, T: null, S: null, V: null }, D = Object.prototype.hasOwnProperty;
  function T(w, C, H, B, J, $) {
    return H = $.ref, {
      $$typeof: n,
      type: w,
      key: C,
      ref: H !== void 0 ? H : null,
      props: $
    };
  }
  function x(w, C) {
    return T(
      w.type,
      C,
      void 0,
      void 0,
      void 0,
      w.props
    );
  }
  function M(w) {
    return typeof w == "object" && w !== null && w.$$typeof === n;
  }
  function L(w) {
    var C = { "=": "=0", ":": "=2" };
    return "$" + w.replace(/[=:]/g, function(H) {
      return C[H];
    });
  }
  var R = /\/+/g;
  function X(w, C) {
    return typeof w == "object" && w !== null && w.key != null ? L("" + w.key) : C.toString(36);
  }
  function ke() {
  }
  function ue(w) {
    switch (w.status) {
      case "fulfilled":
        return w.value;
      case "rejected":
        throw w.reason;
      default:
        switch (typeof w.status == "string" ? w.then(ke, ke) : (w.status = "pending", w.then(
          function(C) {
            w.status === "pending" && (w.status = "fulfilled", w.value = C);
          },
          function(C) {
            w.status === "pending" && (w.status = "rejected", w.reason = C);
          }
        )), w.status) {
          case "fulfilled":
            return w.value;
          case "rejected":
            throw w.reason;
        }
    }
    throw w;
  }
  function ae(w, C, H, B, J) {
    var $ = typeof w;
    ($ === "undefined" || $ === "boolean") && (w = null);
    var Y = !1;
    if (w === null) Y = !0;
    else
      switch ($) {
        case "bigint":
        case "string":
        case "number":
          Y = !0;
          break;
        case "object":
          switch (w.$$typeof) {
            case n:
            case e:
              Y = !0;
              break;
            case c:
              return Y = w._init, ae(
                Y(w._payload),
                C,
                H,
                B,
                J
              );
          }
      }
    if (Y)
      return J = J(w), Y = B === "" ? "." + X(w, 0) : B, v(J) ? (H = "", Y != null && (H = Y.replace(R, "$&/") + "/"), ae(J, C, H, "", function(ht) {
        return ht;
      })) : J != null && (M(J) && (J = x(
        J,
        H + (J.key == null || w && w.key === J.key ? "" : ("" + J.key).replace(
          R,
          "$&/"
        ) + "/") + Y
      )), C.push(J)), 1;
    Y = 0;
    var Le = B === "" ? "." : B + ":";
    if (v(w))
      for (var he = 0; he < w.length; he++)
        B = w[he], $ = Le + X(B, he), Y += ae(
          B,
          C,
          H,
          $,
          J
        );
    else if (he = f(w), typeof he == "function")
      for (w = he.call(w), he = 0; !(B = w.next()).done; )
        B = B.value, $ = Le + X(B, he++), Y += ae(
          B,
          C,
          H,
          $,
          J
        );
    else if ($ === "object") {
      if (typeof w.then == "function")
        return ae(
          ue(w),
          C,
          H,
          B,
          J
        );
      throw C = String(w), Error(
        "Objects are not valid as a React child (found: " + (C === "[object Object]" ? "object with keys {" + Object.keys(w).join(", ") + "}" : C) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return Y;
  }
  function ie(w, C, H) {
    if (w == null) return w;
    var B = [], J = 0;
    return ae(w, B, "", "", function($) {
      return C.call(H, $, J++);
    }), B;
  }
  function ve(w) {
    if (w._status === -1) {
      var C = w._result;
      C = C(), C.then(
        function(H) {
          (w._status === 0 || w._status === -1) && (w._status = 1, w._result = H);
        },
        function(H) {
          (w._status === 0 || w._status === -1) && (w._status = 2, w._result = H);
        }
      ), w._status === -1 && (w._status = 0, w._result = C);
    }
    if (w._status === 1) return w._result.default;
    throw w._result;
  }
  var fe = typeof reportError == "function" ? reportError : function(w) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var C = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof w == "object" && w !== null && typeof w.message == "string" ? String(w.message) : String(w),
        error: w
      });
      if (!window.dispatchEvent(C)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", w);
      return;
    }
    console.error(w);
  };
  function xe() {
  }
  return ne.Children = {
    map: ie,
    forEach: function(w, C, H) {
      ie(
        w,
        function() {
          C.apply(this, arguments);
        },
        H
      );
    },
    count: function(w) {
      var C = 0;
      return ie(w, function() {
        C++;
      }), C;
    },
    toArray: function(w) {
      return ie(w, function(C) {
        return C;
      }) || [];
    },
    only: function(w) {
      if (!M(w))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return w;
    }
  }, ne.Component = _, ne.Fragment = t, ne.Profiler = i, ne.PureComponent = b, ne.StrictMode = r, ne.Suspense = a, ne.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = S, ne.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(w) {
      return S.H.useMemoCache(w);
    }
  }, ne.cache = function(w) {
    return function() {
      return w.apply(null, arguments);
    };
  }, ne.cloneElement = function(w, C, H) {
    if (w == null)
      throw Error(
        "The argument must be a React element, but you passed " + w + "."
      );
    var B = p({}, w.props), J = w.key, $ = void 0;
    if (C != null)
      for (Y in C.ref !== void 0 && ($ = void 0), C.key !== void 0 && (J = "" + C.key), C)
        !D.call(C, Y) || Y === "key" || Y === "__self" || Y === "__source" || Y === "ref" && C.ref === void 0 || (B[Y] = C[Y]);
    var Y = arguments.length - 2;
    if (Y === 1) B.children = H;
    else if (1 < Y) {
      for (var Le = Array(Y), he = 0; he < Y; he++)
        Le[he] = arguments[he + 2];
      B.children = Le;
    }
    return T(w.type, J, void 0, void 0, $, B);
  }, ne.createContext = function(w) {
    return w = {
      $$typeof: o,
      _currentValue: w,
      _currentValue2: w,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, w.Provider = w, w.Consumer = {
      $$typeof: s,
      _context: w
    }, w;
  }, ne.createElement = function(w, C, H) {
    var B, J = {}, $ = null;
    if (C != null)
      for (B in C.key !== void 0 && ($ = "" + C.key), C)
        D.call(C, B) && B !== "key" && B !== "__self" && B !== "__source" && (J[B] = C[B]);
    var Y = arguments.length - 2;
    if (Y === 1) J.children = H;
    else if (1 < Y) {
      for (var Le = Array(Y), he = 0; he < Y; he++)
        Le[he] = arguments[he + 2];
      J.children = Le;
    }
    if (w && w.defaultProps)
      for (B in Y = w.defaultProps, Y)
        J[B] === void 0 && (J[B] = Y[B]);
    return T(w, $, void 0, void 0, null, J);
  }, ne.createRef = function() {
    return { current: null };
  }, ne.forwardRef = function(w) {
    return { $$typeof: l, render: w };
  }, ne.isValidElement = M, ne.lazy = function(w) {
    return {
      $$typeof: c,
      _payload: { _status: -1, _result: w },
      _init: ve
    };
  }, ne.memo = function(w, C) {
    return {
      $$typeof: u,
      type: w,
      compare: C === void 0 ? null : C
    };
  }, ne.startTransition = function(w) {
    var C = S.T, H = {};
    S.T = H;
    try {
      var B = w(), J = S.S;
      J !== null && J(H, B), typeof B == "object" && B !== null && typeof B.then == "function" && B.then(xe, fe);
    } catch ($) {
      fe($);
    } finally {
      S.T = C;
    }
  }, ne.unstable_useCacheRefresh = function() {
    return S.H.useCacheRefresh();
  }, ne.use = function(w) {
    return S.H.use(w);
  }, ne.useActionState = function(w, C, H) {
    return S.H.useActionState(w, C, H);
  }, ne.useCallback = function(w, C) {
    return S.H.useCallback(w, C);
  }, ne.useContext = function(w) {
    return S.H.useContext(w);
  }, ne.useDebugValue = function() {
  }, ne.useDeferredValue = function(w, C) {
    return S.H.useDeferredValue(w, C);
  }, ne.useEffect = function(w, C, H) {
    var B = S.H;
    if (typeof H == "function")
      throw Error(
        "useEffect CRUD overload is not enabled in this build of React."
      );
    return B.useEffect(w, C);
  }, ne.useId = function() {
    return S.H.useId();
  }, ne.useImperativeHandle = function(w, C, H) {
    return S.H.useImperativeHandle(w, C, H);
  }, ne.useInsertionEffect = function(w, C) {
    return S.H.useInsertionEffect(w, C);
  }, ne.useLayoutEffect = function(w, C) {
    return S.H.useLayoutEffect(w, C);
  }, ne.useMemo = function(w, C) {
    return S.H.useMemo(w, C);
  }, ne.useOptimistic = function(w, C) {
    return S.H.useOptimistic(w, C);
  }, ne.useReducer = function(w, C, H) {
    return S.H.useReducer(w, C, H);
  }, ne.useRef = function(w) {
    return S.H.useRef(w);
  }, ne.useState = function(w) {
    return S.H.useState(w);
  }, ne.useSyncExternalStore = function(w, C, H) {
    return S.H.useSyncExternalStore(
      w,
      C,
      H
    );
  }, ne.useTransition = function() {
    return S.H.useTransition();
  }, ne.version = "19.1.1", ne;
}
var hi = { exports: {} };
/**
 * @license React
 * react.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
hi.exports;
var Xd;
function oE() {
  return Xd || (Xd = 1, function(n, e) {
    process.env.NODE_ENV !== "production" && function() {
      function t(m, A) {
        Object.defineProperty(s.prototype, m, {
          get: function() {
            console.warn(
              "%s(...) is deprecated in plain JavaScript React classes. %s",
              A[0],
              A[1]
            );
          }
        });
      }
      function r(m) {
        return m === null || typeof m != "object" ? null : (m = Wt && m[Wt] || m["@@iterator"], typeof m == "function" ? m : null);
      }
      function i(m, A) {
        m = (m = m.constructor) && (m.displayName || m.name) || "ReactClass";
        var I = m + "." + A;
        Ft[I] || (console.error(
          "Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.",
          A,
          m
        ), Ft[I] = !0);
      }
      function s(m, A, I) {
        this.props = m, this.context = A, this.refs = Jn, this.updater = I || Ot;
      }
      function o() {
      }
      function l(m, A, I) {
        this.props = m, this.context = A, this.refs = Jn, this.updater = I || Ot;
      }
      function a(m) {
        return "" + m;
      }
      function u(m) {
        try {
          a(m);
          var A = !1;
        } catch {
          A = !0;
        }
        if (A) {
          A = console;
          var I = A.error, P = typeof Symbol == "function" && Symbol.toStringTag && m[Symbol.toStringTag] || m.constructor.name || "Object";
          return I.call(
            A,
            "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",
            P
          ), a(m);
        }
      }
      function c(m) {
        if (m == null) return null;
        if (typeof m == "function")
          return m.$$typeof === vr ? null : m.displayName || m.name || null;
        if (typeof m == "string") return m;
        switch (m) {
          case w:
            return "Fragment";
          case H:
            return "Profiler";
          case C:
            return "StrictMode";
          case Y:
            return "Suspense";
          case Le:
            return "SuspenseList";
          case Dn:
            return "Activity";
        }
        if (typeof m == "object")
          switch (typeof m.tag == "number" && console.error(
            "Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."
          ), m.$$typeof) {
            case xe:
              return "Portal";
            case J:
              return (m.displayName || "Context") + ".Provider";
            case B:
              return (m._context.displayName || "Context") + ".Consumer";
            case $:
              var A = m.render;
              return m = m.displayName, m || (m = A.displayName || A.name || "", m = m !== "" ? "ForwardRef(" + m + ")" : "ForwardRef"), m;
            case he:
              return A = m.displayName || null, A !== null ? A : c(m.type) || "Memo";
            case ht:
              A = m._payload, m = m._init;
              try {
                return c(m(A));
              } catch {
              }
          }
        return null;
      }
      function d(m) {
        if (m === w) return "<>";
        if (typeof m == "object" && m !== null && m.$$typeof === ht)
          return "<...>";
        try {
          var A = c(m);
          return A ? "<" + A + ">" : "<...>";
        } catch {
          return "<...>";
        }
      }
      function f() {
        var m = oe.A;
        return m === null ? null : m.getOwner();
      }
      function h() {
        return Error("react-stack-top-frame");
      }
      function p(m) {
        if (Xn.call(m, "key")) {
          var A = Object.getOwnPropertyDescriptor(m, "key").get;
          if (A && A.isReactWarning) return !1;
        }
        return m.key !== void 0;
      }
      function g(m, A) {
        function I() {
          wr || (wr = !0, console.error(
            "%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",
            A
          ));
        }
        I.isReactWarning = !0, Object.defineProperty(m, "key", {
          get: I,
          configurable: !0
        });
      }
      function _() {
        var m = c(this.type);
        return cn[m] || (cn[m] = !0, console.error(
          "Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."
        )), m = this.props.ref, m !== void 0 ? m : null;
      }
      function k(m, A, I, P, V, ee, te, de) {
        return I = ee.ref, m = {
          $$typeof: fe,
          type: m,
          key: A,
          props: ee,
          _owner: V
        }, (I !== void 0 ? I : null) !== null ? Object.defineProperty(m, "ref", {
          enumerable: !1,
          get: _
        }) : Object.defineProperty(m, "ref", { enumerable: !1, value: null }), m._store = {}, Object.defineProperty(m._store, "validated", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: 0
        }), Object.defineProperty(m, "_debugInfo", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: null
        }), Object.defineProperty(m, "_debugStack", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: te
        }), Object.defineProperty(m, "_debugTask", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: de
        }), Object.freeze && (Object.freeze(m.props), Object.freeze(m)), m;
      }
      function b(m, A) {
        return A = k(
          m.type,
          A,
          void 0,
          void 0,
          m._owner,
          m.props,
          m._debugStack,
          m._debugTask
        ), m._store && (A._store.validated = m._store.validated), A;
      }
      function y(m) {
        return typeof m == "object" && m !== null && m.$$typeof === fe;
      }
      function v(m) {
        var A = { "=": "=0", ":": "=2" };
        return "$" + m.replace(/[=:]/g, function(I) {
          return A[I];
        });
      }
      function S(m, A) {
        return typeof m == "object" && m !== null && m.key != null ? (u(m.key), v("" + m.key)) : A.toString(36);
      }
      function D() {
      }
      function T(m) {
        switch (m.status) {
          case "fulfilled":
            return m.value;
          case "rejected":
            throw m.reason;
          default:
            switch (typeof m.status == "string" ? m.then(D, D) : (m.status = "pending", m.then(
              function(A) {
                m.status === "pending" && (m.status = "fulfilled", m.value = A);
              },
              function(A) {
                m.status === "pending" && (m.status = "rejected", m.reason = A);
              }
            )), m.status) {
              case "fulfilled":
                return m.value;
              case "rejected":
                throw m.reason;
            }
        }
        throw m;
      }
      function x(m, A, I, P, V) {
        var ee = typeof m;
        (ee === "undefined" || ee === "boolean") && (m = null);
        var te = !1;
        if (m === null) te = !0;
        else
          switch (ee) {
            case "bigint":
            case "string":
            case "number":
              te = !0;
              break;
            case "object":
              switch (m.$$typeof) {
                case fe:
                case xe:
                  te = !0;
                  break;
                case ht:
                  return te = m._init, x(
                    te(m._payload),
                    A,
                    I,
                    P,
                    V
                  );
              }
          }
        if (te) {
          te = m, V = V(te);
          var de = P === "" ? "." + S(te, 0) : P;
          return Yn(V) ? (I = "", de != null && (I = de.replace(Yr, "$&/") + "/"), x(V, A, I, "", function(et) {
            return et;
          })) : V != null && (y(V) && (V.key != null && (te && te.key === V.key || u(V.key)), I = b(
            V,
            I + (V.key == null || te && te.key === V.key ? "" : ("" + V.key).replace(
              Yr,
              "$&/"
            ) + "/") + de
          ), P !== "" && te != null && y(te) && te.key == null && te._store && !te._store.validated && (I._store.validated = 2), V = I), A.push(V)), 1;
        }
        if (te = 0, de = P === "" ? "." : P + ":", Yn(m))
          for (var U = 0; U < m.length; U++)
            P = m[U], ee = de + S(P, U), te += x(
              P,
              A,
              I,
              ee,
              V
            );
        else if (U = r(m), typeof U == "function")
          for (U === m.entries && (Jr || console.warn(
            "Using Maps as children is not supported. Use an array of keyed ReactElements instead."
          ), Jr = !0), m = U.call(m), U = 0; !(P = m.next()).done; )
            P = P.value, ee = de + S(P, U++), te += x(
              P,
              A,
              I,
              ee,
              V
            );
        else if (ee === "object") {
          if (typeof m.then == "function")
            return x(
              T(m),
              A,
              I,
              P,
              V
            );
          throw A = String(m), Error(
            "Objects are not valid as a React child (found: " + (A === "[object Object]" ? "object with keys {" + Object.keys(m).join(", ") + "}" : A) + "). If you meant to render a collection of children, use an array instead."
          );
        }
        return te;
      }
      function M(m, A, I) {
        if (m == null) return m;
        var P = [], V = 0;
        return x(m, P, "", "", function(ee) {
          return A.call(I, ee, V++);
        }), P;
      }
      function L(m) {
        if (m._status === -1) {
          var A = m._result;
          A = A(), A.then(
            function(I) {
              (m._status === 0 || m._status === -1) && (m._status = 1, m._result = I);
            },
            function(I) {
              (m._status === 0 || m._status === -1) && (m._status = 2, m._result = I);
            }
          ), m._status === -1 && (m._status = 0, m._result = A);
        }
        if (m._status === 1)
          return A = m._result, A === void 0 && console.error(
            `lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`,
            A
          ), "default" in A || console.error(
            `lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`,
            A
          ), A.default;
        throw m._result;
      }
      function R() {
        var m = oe.H;
        return m === null && console.error(
          `Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`
        ), m;
      }
      function X() {
      }
      function ke(m) {
        if (dn === null)
          try {
            var A = ("require" + Math.random()).slice(0, 7);
            dn = (n && n[A]).call(
              n,
              "timers"
            ).setImmediate;
          } catch {
            dn = function(P) {
              Xr === !1 && (Xr = !0, typeof MessageChannel > "u" && console.error(
                "This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."
              ));
              var V = new MessageChannel();
              V.port1.onmessage = P, V.port2.postMessage(void 0);
            };
          }
        return dn(m);
      }
      function ue(m) {
        return 1 < m.length && typeof AggregateError == "function" ? new AggregateError(m) : m[0];
      }
      function ae(m, A) {
        A !== fn - 1 && console.error(
          "You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "
        ), fn = A;
      }
      function ie(m, A, I) {
        var P = oe.actQueue;
        if (P !== null)
          if (P.length !== 0)
            try {
              ve(P), ke(function() {
                return ie(m, A, I);
              });
              return;
            } catch (V) {
              oe.thrownErrors.push(V);
            }
          else oe.actQueue = null;
        0 < oe.thrownErrors.length ? (P = ue(oe.thrownErrors), oe.thrownErrors.length = 0, I(P)) : A(m);
      }
      function ve(m) {
        if (!Gt) {
          Gt = !0;
          var A = 0;
          try {
            for (; A < m.length; A++) {
              var I = m[A];
              do {
                oe.didUsePromise = !1;
                var P = I(!1);
                if (P !== null) {
                  if (oe.didUsePromise) {
                    m[A] = I, m.splice(0, A);
                    return;
                  }
                  I = P;
                } else break;
              } while (!0);
            }
            m.length = 0;
          } catch (V) {
            m.splice(0, A + 1), oe.thrownErrors.push(V);
          } finally {
            Gt = !1;
          }
        }
      }
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var fe = Symbol.for("react.transitional.element"), xe = Symbol.for("react.portal"), w = Symbol.for("react.fragment"), C = Symbol.for("react.strict_mode"), H = Symbol.for("react.profiler"), B = Symbol.for("react.consumer"), J = Symbol.for("react.context"), $ = Symbol.for("react.forward_ref"), Y = Symbol.for("react.suspense"), Le = Symbol.for("react.suspense_list"), he = Symbol.for("react.memo"), ht = Symbol.for("react.lazy"), Dn = Symbol.for("react.activity"), Wt = Symbol.iterator, Ft = {}, Ot = {
        isMounted: function() {
          return !1;
        },
        enqueueForceUpdate: function(m) {
          i(m, "forceUpdate");
        },
        enqueueReplaceState: function(m) {
          i(m, "replaceState");
        },
        enqueueSetState: function(m) {
          i(m, "setState");
        }
      }, Kt = Object.assign, Jn = {};
      Object.freeze(Jn), s.prototype.isReactComponent = {}, s.prototype.setState = function(m, A) {
        if (typeof m != "object" && typeof m != "function" && m != null)
          throw Error(
            "takes an object of state variables to update or a function which returns an object of state variables."
          );
        this.updater.enqueueSetState(this, m, A, "setState");
      }, s.prototype.forceUpdate = function(m) {
        this.updater.enqueueForceUpdate(this, m, "forceUpdate");
      };
      var We = {
        isMounted: [
          "isMounted",
          "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."
        ],
        replaceState: [
          "replaceState",
          "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."
        ]
      }, Nt;
      for (Nt in We)
        We.hasOwnProperty(Nt) && t(Nt, We[Nt]);
      o.prototype = s.prototype, We = l.prototype = new o(), We.constructor = l, Kt(We, s.prototype), We.isPureReactComponent = !0;
      var Yn = Array.isArray, vr = Symbol.for("react.client.reference"), oe = {
        H: null,
        A: null,
        T: null,
        S: null,
        V: null,
        actQueue: null,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      }, Xn = Object.prototype.hasOwnProperty, Ji = console.createTask ? console.createTask : function() {
        return null;
      };
      We = {
        react_stack_bottom_frame: function(m) {
          return m();
        }
      };
      var wr, An, cn = {}, Tn = We.react_stack_bottom_frame.bind(
        We,
        h
      )(), Yi = Ji(d(h)), Jr = !1, Yr = /\/+/g, Er = typeof reportError == "function" ? reportError : function(m) {
        if (typeof window == "object" && typeof window.ErrorEvent == "function") {
          var A = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: typeof m == "object" && m !== null && typeof m.message == "string" ? String(m.message) : String(m),
            error: m
          });
          if (!window.dispatchEvent(A)) return;
        } else if (typeof process == "object" && typeof process.emit == "function") {
          process.emit("uncaughtException", m);
          return;
        }
        console.error(m);
      }, Xr = !1, dn = null, fn = 0, at = !1, Gt = !1, Sr = typeof queueMicrotask == "function" ? function(m) {
        queueMicrotask(function() {
          return queueMicrotask(m);
        });
      } : ke;
      We = Object.freeze({
        __proto__: null,
        c: function(m) {
          return R().useMemoCache(m);
        }
      }), e.Children = {
        map: M,
        forEach: function(m, A, I) {
          M(
            m,
            function() {
              A.apply(this, arguments);
            },
            I
          );
        },
        count: function(m) {
          var A = 0;
          return M(m, function() {
            A++;
          }), A;
        },
        toArray: function(m) {
          return M(m, function(A) {
            return A;
          }) || [];
        },
        only: function(m) {
          if (!y(m))
            throw Error(
              "React.Children.only expected to receive a single React element child."
            );
          return m;
        }
      }, e.Component = s, e.Fragment = w, e.Profiler = H, e.PureComponent = l, e.StrictMode = C, e.Suspense = Y, e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = oe, e.__COMPILER_RUNTIME = We, e.act = function(m) {
        var A = oe.actQueue, I = fn;
        fn++;
        var P = oe.actQueue = A !== null ? A : [], V = !1;
        try {
          var ee = m();
        } catch (U) {
          oe.thrownErrors.push(U);
        }
        if (0 < oe.thrownErrors.length)
          throw ae(A, I), m = ue(oe.thrownErrors), oe.thrownErrors.length = 0, m;
        if (ee !== null && typeof ee == "object" && typeof ee.then == "function") {
          var te = ee;
          return Sr(function() {
            V || at || (at = !0, console.error(
              "You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"
            ));
          }), {
            then: function(U, et) {
              V = !0, te.then(
                function(xn) {
                  if (ae(A, I), I === 0) {
                    try {
                      ve(P), ke(function() {
                        return ie(
                          xn,
                          U,
                          et
                        );
                      });
                    } catch (Zr) {
                      oe.thrownErrors.push(Zr);
                    }
                    if (0 < oe.thrownErrors.length) {
                      var Xi = ue(
                        oe.thrownErrors
                      );
                      oe.thrownErrors.length = 0, et(Xi);
                    }
                  } else U(xn);
                },
                function(xn) {
                  ae(A, I), 0 < oe.thrownErrors.length && (xn = ue(
                    oe.thrownErrors
                  ), oe.thrownErrors.length = 0), et(xn);
                }
              );
            }
          };
        }
        var de = ee;
        if (ae(A, I), I === 0 && (ve(P), P.length !== 0 && Sr(function() {
          V || at || (at = !0, console.error(
            "A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"
          ));
        }), oe.actQueue = null), 0 < oe.thrownErrors.length)
          throw m = ue(oe.thrownErrors), oe.thrownErrors.length = 0, m;
        return {
          then: function(U, et) {
            V = !0, I === 0 ? (oe.actQueue = P, ke(function() {
              return ie(
                de,
                U,
                et
              );
            })) : U(de);
          }
        };
      }, e.cache = function(m) {
        return function() {
          return m.apply(null, arguments);
        };
      }, e.captureOwnerStack = function() {
        var m = oe.getCurrentStack;
        return m === null ? null : m();
      }, e.cloneElement = function(m, A, I) {
        if (m == null)
          throw Error(
            "The argument must be a React element, but you passed " + m + "."
          );
        var P = Kt({}, m.props), V = m.key, ee = m._owner;
        if (A != null) {
          var te;
          e: {
            if (Xn.call(A, "ref") && (te = Object.getOwnPropertyDescriptor(
              A,
              "ref"
            ).get) && te.isReactWarning) {
              te = !1;
              break e;
            }
            te = A.ref !== void 0;
          }
          te && (ee = f()), p(A) && (u(A.key), V = "" + A.key);
          for (de in A)
            !Xn.call(A, de) || de === "key" || de === "__self" || de === "__source" || de === "ref" && A.ref === void 0 || (P[de] = A[de]);
        }
        var de = arguments.length - 2;
        if (de === 1) P.children = I;
        else if (1 < de) {
          te = Array(de);
          for (var U = 0; U < de; U++)
            te[U] = arguments[U + 2];
          P.children = te;
        }
        for (P = k(
          m.type,
          V,
          void 0,
          void 0,
          ee,
          P,
          m._debugStack,
          m._debugTask
        ), V = 2; V < arguments.length; V++)
          ee = arguments[V], y(ee) && ee._store && (ee._store.validated = 1);
        return P;
      }, e.createContext = function(m) {
        return m = {
          $$typeof: J,
          _currentValue: m,
          _currentValue2: m,
          _threadCount: 0,
          Provider: null,
          Consumer: null
        }, m.Provider = m, m.Consumer = {
          $$typeof: B,
          _context: m
        }, m._currentRenderer = null, m._currentRenderer2 = null, m;
      }, e.createElement = function(m, A, I) {
        for (var P = 2; P < arguments.length; P++) {
          var V = arguments[P];
          y(V) && V._store && (V._store.validated = 1);
        }
        if (P = {}, V = null, A != null)
          for (U in An || !("__self" in A) || "key" in A || (An = !0, console.warn(
            "Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform"
          )), p(A) && (u(A.key), V = "" + A.key), A)
            Xn.call(A, U) && U !== "key" && U !== "__self" && U !== "__source" && (P[U] = A[U]);
        var ee = arguments.length - 2;
        if (ee === 1) P.children = I;
        else if (1 < ee) {
          for (var te = Array(ee), de = 0; de < ee; de++)
            te[de] = arguments[de + 2];
          Object.freeze && Object.freeze(te), P.children = te;
        }
        if (m && m.defaultProps)
          for (U in ee = m.defaultProps, ee)
            P[U] === void 0 && (P[U] = ee[U]);
        V && g(
          P,
          typeof m == "function" ? m.displayName || m.name || "Unknown" : m
        );
        var U = 1e4 > oe.recentlyCreatedOwnerStacks++;
        return k(
          m,
          V,
          void 0,
          void 0,
          f(),
          P,
          U ? Error("react-stack-top-frame") : Tn,
          U ? Ji(d(m)) : Yi
        );
      }, e.createRef = function() {
        var m = { current: null };
        return Object.seal(m), m;
      }, e.forwardRef = function(m) {
        m != null && m.$$typeof === he ? console.error(
          "forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...))."
        ) : typeof m != "function" ? console.error(
          "forwardRef requires a render function but was given %s.",
          m === null ? "null" : typeof m
        ) : m.length !== 0 && m.length !== 2 && console.error(
          "forwardRef render functions accept exactly two parameters: props and ref. %s",
          m.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."
        ), m != null && m.defaultProps != null && console.error(
          "forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?"
        );
        var A = { $$typeof: $, render: m }, I;
        return Object.defineProperty(A, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return I;
          },
          set: function(P) {
            I = P, m.name || m.displayName || (Object.defineProperty(m, "name", { value: P }), m.displayName = P);
          }
        }), A;
      }, e.isValidElement = y, e.lazy = function(m) {
        return {
          $$typeof: ht,
          _payload: { _status: -1, _result: m },
          _init: L
        };
      }, e.memo = function(m, A) {
        m == null && console.error(
          "memo: The first argument must be a component. Instead received: %s",
          m === null ? "null" : typeof m
        ), A = {
          $$typeof: he,
          type: m,
          compare: A === void 0 ? null : A
        };
        var I;
        return Object.defineProperty(A, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return I;
          },
          set: function(P) {
            I = P, m.name || m.displayName || (Object.defineProperty(m, "name", { value: P }), m.displayName = P);
          }
        }), A;
      }, e.startTransition = function(m) {
        var A = oe.T, I = {};
        oe.T = I, I._updatedFibers = /* @__PURE__ */ new Set();
        try {
          var P = m(), V = oe.S;
          V !== null && V(I, P), typeof P == "object" && P !== null && typeof P.then == "function" && P.then(X, Er);
        } catch (ee) {
          Er(ee);
        } finally {
          A === null && I._updatedFibers && (m = I._updatedFibers.size, I._updatedFibers.clear(), 10 < m && console.warn(
            "Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."
          )), oe.T = A;
        }
      }, e.unstable_useCacheRefresh = function() {
        return R().useCacheRefresh();
      }, e.use = function(m) {
        return R().use(m);
      }, e.useActionState = function(m, A, I) {
        return R().useActionState(
          m,
          A,
          I
        );
      }, e.useCallback = function(m, A) {
        return R().useCallback(m, A);
      }, e.useContext = function(m) {
        var A = R();
        return m.$$typeof === B && console.error(
          "Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?"
        ), A.useContext(m);
      }, e.useDebugValue = function(m, A) {
        return R().useDebugValue(m, A);
      }, e.useDeferredValue = function(m, A) {
        return R().useDeferredValue(m, A);
      }, e.useEffect = function(m, A, I) {
        m == null && console.warn(
          "React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        );
        var P = R();
        if (typeof I == "function")
          throw Error(
            "useEffect CRUD overload is not enabled in this build of React."
          );
        return P.useEffect(m, A);
      }, e.useId = function() {
        return R().useId();
      }, e.useImperativeHandle = function(m, A, I) {
        return R().useImperativeHandle(m, A, I);
      }, e.useInsertionEffect = function(m, A) {
        return m == null && console.warn(
          "React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), R().useInsertionEffect(m, A);
      }, e.useLayoutEffect = function(m, A) {
        return m == null && console.warn(
          "React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), R().useLayoutEffect(m, A);
      }, e.useMemo = function(m, A) {
        return R().useMemo(m, A);
      }, e.useOptimistic = function(m, A) {
        return R().useOptimistic(m, A);
      }, e.useReducer = function(m, A, I) {
        return R().useReducer(m, A, I);
      }, e.useRef = function(m) {
        return R().useRef(m);
      }, e.useState = function(m) {
        return R().useState(m);
      }, e.useSyncExternalStore = function(m, A, I) {
        return R().useSyncExternalStore(
          m,
          A,
          I
        );
      }, e.useTransition = function() {
        return R().useTransition();
      }, e.version = "19.1.1", typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    }();
  }(hi, hi.exports)), hi.exports;
}
process.env.NODE_ENV === "production" ? sE() : oE();
function lE(n, e, t) {
  const r = n.attrs;
  return r ? e.filter((i) => i.type !== (typeof n.type == "string" ? n.type : n.type.name) ? !1 : i.attribute.rendered).map((i) => i.attribute.renderHTML ? i.attribute.renderHTML(r) || {
    [i.name]: i.name in r ? r[i.name] : i.attribute.default
  } : {
    [i.name]: i.name in r ? r[i.name] : i.attribute.default
  }).reduce((i, s) => Fe(i, s), {}) : {};
}
function Em(n, e) {
  return lE(n, e);
}
function aE(n, {
  nodeMapping: e,
  markMapping: t,
  unhandledNode: r,
  unhandledMark: i
}) {
  return function s({
    content: o,
    parent: l
  }) {
    var a;
    const u = typeof o.type == "string" ? o.type : o.type.name, c = (a = e[u]) != null ? a : r;
    if (!c)
      throw new Error(`missing handler for node type ${u}`);
    const d = n({
      component: c,
      props: {
        node: o,
        parent: l,
        renderElement: s,
        // Lazily compute the children to avoid unnecessary recursion
        get children() {
          const h = [];
          return o.content && o.content.forEach((p) => {
            h.push(
              s({
                content: p,
                parent: o
              })
            );
          }), h;
        }
      }
    });
    return o.marks ? o.marks.reduce((h, p) => {
      var g;
      const _ = typeof p.type == "string" ? p.type : p.type.name, k = (g = t[_]) != null ? g : i;
      if (!k)
        throw new Error(`missing handler for mark type ${_}`);
      return n({
        component: k,
        props: {
          mark: p,
          parent: l,
          node: o,
          children: h
        }
      });
    }, d) : d;
  };
}
function uE(n) {
  return aE((e) => e.component(e.props), n);
}
function Al(n) {
  const e = Object.entries(n || {}).map(([t, r]) => `${t.split(" ").at(-1)}=${JSON.stringify(r)}`).join(" ");
  return e ? ` ${e}` : "";
}
function ye(n) {
  return [].concat(n || "").filter(Boolean).join("");
}
function cE(n, e, t, r) {
  const i = {
    name: e.name,
    options: e.options,
    storage: e.storage,
    parent: e.parent
  }, s = j(e, "renderHTML", i);
  return s ? [
    e.name,
    ({ node: o, children: l }) => {
      try {
        return n(
          s({
            node: o,
            HTMLAttributes: Em(o, t)
          })
        )(l);
      } catch (a) {
        throw new Error(
          `[tiptap error]: Node ${e.name} cannot be rendered, it's "renderToHTML" method threw an error: ${a.message}`,
          { cause: a }
        );
      }
    }
  ] : r != null && r.unhandledNode ? [e.name, r.unhandledNode] : [
    e.name,
    () => {
      throw new Error(
        `[tiptap error]: Node ${e.name} cannot be rendered, it is missing a "renderToHTML" method, please implement it or override the corresponding "nodeMapping" method to have a custom rendering`
      );
    }
  ];
}
function dE(n, e, t, r) {
  const i = {
    name: e.name,
    options: e.options,
    storage: e.storage,
    parent: e.parent
  }, s = j(e, "renderHTML", i);
  return s ? [
    e.name,
    ({ mark: o, children: l }) => {
      try {
        return n(
          s({
            mark: o,
            HTMLAttributes: Em(o, t)
          })
        )(l);
      } catch (a) {
        throw new Error(
          `[tiptap error]: Mark ${e.name} cannot be rendered, it's "renderToHTML" method threw an error: ${a.message}`,
          { cause: a }
        );
      }
    }
  ] : r != null && r.unhandledMark ? [e.name, r.unhandledMark] : [
    e.name,
    () => {
      throw new Error(`Node ${e.name} cannot be rendered, it is missing a "renderToHTML" method`);
    }
  ];
}
function fE({
  renderer: n,
  domOutputSpecToElement: e,
  mapDefinedTypes: t,
  content: r,
  extensions: i,
  options: s
}) {
  i = tu(i);
  const o = Qa(i), { nodeExtensions: l, markExtensions: a } = Ur(i);
  return r instanceof _t || (r = _t.fromJSON(Yp(i), r)), n({
    ...s,
    nodeMapping: {
      ...Object.fromEntries(
        l.filter((u) => u.name in t ? !1 : s != null && s.nodeMapping ? !(u.name in s.nodeMapping) : !0).map(
          (u) => cE(e, u, o, s)
        )
      ),
      ...t,
      ...s == null ? void 0 : s.nodeMapping
    },
    markMapping: {
      ...Object.fromEntries(
        a.filter((u) => s != null && s.markMapping ? !(u.name in s.markMapping) : !0).map((u) => dE(e, u, o, s))
      ),
      ...s == null ? void 0 : s.markMapping
    }
  })({ content: r });
}
function Or(n) {
  if (typeof n == "string")
    return () => n;
  if (typeof n == "object" && "length" in n) {
    const [e, t, r, ...i] = n;
    let s = e;
    const o = s.split(" ");
    if (o.length > 1 && (s = `${o[1]} xmlns="${o[0]}"`), t === void 0)
      return () => `<${s}/>`;
    if (t === 0)
      return (l) => `<${s}>${ye(l)}</${s}>`;
    if (typeof t == "object")
      return Array.isArray(t) ? r === void 0 ? (l) => `<${s}>${Or(t)(l)}</${s}>` : r === 0 ? (l) => `<${s}>${Or(t)(l)}</${s}>` : (l) => `<${s}>${Or(t)(l)}${[r].concat(i).map((a) => Or(a)(l))}</${s}>` : r === void 0 ? () => `<${s}${Al(t)}/>` : r === 0 ? (l) => `<${s}${Al(t)}>${ye(l)}</${s}>` : (l) => `<${s}${Al(t)}>${[r].concat(i).map((a) => Or(a)(l)).join("")}</${s}>`;
  }
  throw new Error(
    "[tiptap error]: Unsupported DomOutputSpec type, check the `renderHTML` method output or implement a node mapping",
    {
      cause: n
    }
  );
}
function hE({
  content: n,
  extensions: e,
  options: t
}) {
  return fE({
    renderer: uE,
    domOutputSpecToElement: Or,
    mapDefinedTypes: {
      // Map a doc node to concatenated children
      doc: ({ children: r }) => ye(r),
      // Map a text node to its text content
      text: ({ node: r }) => {
        var i;
        return (i = r.text) != null ? i : "";
      }
    },
    content: n,
    extensions: e,
    options: t
  });
}
function Zd({
  content: n,
  extensions: e,
  options: t
}) {
  return hE({
    content: n,
    extensions: e,
    options: {
      nodeMapping: {
        bulletList({ children: r }) {
          return `
${ye(r)}`;
        },
        orderedList({ children: r }) {
          return `
${ye(r)}`;
        },
        listItem({ node: r, children: i, parent: s }) {
          if ((s == null ? void 0 : s.type.name) === "bulletList")
            return `- ${ye(i).trim()}
`;
          if ((s == null ? void 0 : s.type.name) === "orderedList") {
            let o = s.attrs.start || 1;
            return s.forEach((l, a, u) => {
              r === l && (o = u + 1);
            }), `${o}. ${ye(i).trim()}
`;
          }
          return ye(i);
        },
        paragraph({ children: r }) {
          return `
${ye(r)}
`;
        },
        heading({ node: r, children: i }) {
          const s = r.attrs.level;
          return `${new Array(s).fill("#").join("")} ${i}
`;
        },
        codeBlock({ node: r, children: i }) {
          return `
\`\`\`${r.attrs.language}
${ye(i)}
\`\`\`
`;
        },
        blockquote({ children: r }) {
          return `
${ye(r).trim().split(`
`).map((i) => `> ${i}`).join(`
`)}`;
        },
        image({ node: r }) {
          return `![${r.attrs.alt}](${r.attrs.src})`;
        },
        hardBreak() {
          return `
`;
        },
        horizontalRule() {
          return `
---
`;
        },
        table({ children: r, node: i }) {
          return Array.isArray(r) ? `
${ye(r[0])}| ${new Array(i.childCount - 2).fill("---").join(" | ")} |
${ye(r.slice(1))}
` : `
${ye(r)}
`;
        },
        tableRow({ children: r }) {
          return Array.isArray(r) ? `| ${r.join(" | ")} |
` : `${ye(r)}
`;
        },
        tableHeader({ children: r }) {
          return ye(r).trim();
        },
        tableCell({ children: r }) {
          return ye(r).trim();
        },
        ...t == null ? void 0 : t.nodeMapping
      },
      markMapping: {
        bold({ children: r }) {
          return `**${ye(r)}**`;
        },
        italic({ children: r, node: i }) {
          let s = !1;
          return i != null && i.marks.some((o) => o.type.name === "bold") && (s = !0), s ? `*${ye(r)}*` : `_${ye(r)}_`;
        },
        code({ children: r }) {
          return `\`${ye(r)}\``;
        },
        strike({ children: r }) {
          return `~~${ye(r)}~~`;
        },
        underline({ children: r }) {
          return `<u>${ye(r)}</u>`;
        },
        subscript({ children: r }) {
          return `<sub>${ye(r)}</sub>`;
        },
        superscript({ children: r }) {
          return `<sup>${ye(r)}</sup>`;
        },
        link({ node: r, children: i }) {
          return `[${ye(i)}](${r.attrs.href})`;
        },
        highlight({ children: r }) {
          return `==${ye(r)}==`;
        },
        ...t == null ? void 0 : t.markMapping
      },
      ...t
    }
  });
}
var Qs = (n, e) => {
  if (n === "slot")
    return 0;
  if (n instanceof Function)
    return n(e);
  const { children: t, ...r } = e ?? {};
  if (n === "svg")
    throw new Error("SVG elements are not supported in the JSX syntax, use the array syntax instead");
  return [n, r, t];
}, pE = /^\s*>\s$/, mE = ft.create({
  name: "blockquote",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  content: "block+",
  group: "block",
  defining: !0,
  parseHTML() {
    return [{ tag: "blockquote" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return /* @__PURE__ */ Qs("blockquote", { ...Fe(this.options.HTMLAttributes, n), children: /* @__PURE__ */ Qs("slot", {}) });
  },
  addCommands() {
    return {
      setBlockquote: () => ({ commands: n }) => n.wrapIn(this.name),
      toggleBlockquote: () => ({ commands: n }) => n.toggleWrap(this.name),
      unsetBlockquote: () => ({ commands: n }) => n.lift(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-b": () => this.editor.commands.toggleBlockquote()
    };
  },
  addInputRules() {
    return [
      Kr({
        find: pE,
        type: this.type
      })
    ];
  }
}), gE = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))$/, _E = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))/g, yE = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))$/, bE = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))/g, kE = kr.create({
  name: "bold",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "strong"
      },
      {
        tag: "b",
        getAttrs: (n) => n.style.fontWeight !== "normal" && null
      },
      {
        style: "font-weight=400",
        clearMark: (n) => n.type.name === this.name
      },
      {
        style: "font-weight",
        getAttrs: (n) => /^(bold(er)?|[5-9]\d{2,})$/.test(n) && null
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return /* @__PURE__ */ Qs("strong", { ...Fe(this.options.HTMLAttributes, n), children: /* @__PURE__ */ Qs("slot", {}) });
  },
  addCommands() {
    return {
      setBold: () => ({ commands: n }) => n.setMark(this.name),
      toggleBold: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetBold: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-b": () => this.editor.commands.toggleBold(),
      "Mod-B": () => this.editor.commands.toggleBold()
    };
  },
  addInputRules() {
    return [
      Wr({
        find: gE,
        type: this.type
      }),
      Wr({
        find: yE,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      gr({
        find: _E,
        type: this.type
      }),
      gr({
        find: bE,
        type: this.type
      })
    ];
  }
}), vE = /(^|[^`])`([^`]+)`(?!`)/, wE = /(^|[^`])`([^`]+)`(?!`)/g, EE = kr.create({
  name: "code",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  excludes: "_",
  code: !0,
  exitable: !0,
  parseHTML() {
    return [{ tag: "code" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["code", Fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setCode: () => ({ commands: n }) => n.setMark(this.name),
      toggleCode: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetCode: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-e": () => this.editor.commands.toggleCode()
    };
  },
  addInputRules() {
    return [
      Wr({
        find: vE,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      gr({
        find: wE,
        type: this.type
      })
    ];
  }
}), SE = /^```([a-z]+)?[\s\n]$/, CE = /^~~~([a-z]+)?[\s\n]$/, DE = ft.create({
  name: "codeBlock",
  addOptions() {
    return {
      languageClassPrefix: "language-",
      exitOnTripleEnter: !0,
      exitOnArrowDown: !0,
      defaultLanguage: null,
      HTMLAttributes: {}
    };
  },
  content: "text*",
  marks: "",
  group: "block",
  code: !0,
  defining: !0,
  addAttributes() {
    return {
      language: {
        default: this.options.defaultLanguage,
        parseHTML: (n) => {
          var e;
          const { languageClassPrefix: t } = this.options, s = [...((e = n.firstElementChild) == null ? void 0 : e.classList) || []].filter((o) => o.startsWith(t)).map((o) => o.replace(t, ""))[0];
          return s || null;
        },
        rendered: !1
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "pre",
        preserveWhitespace: "full"
      }
    ];
  },
  renderHTML({ node: n, HTMLAttributes: e }) {
    return [
      "pre",
      Fe(this.options.HTMLAttributes, e),
      [
        "code",
        {
          class: n.attrs.language ? this.options.languageClassPrefix + n.attrs.language : null
        },
        0
      ]
    ];
  },
  addCommands() {
    return {
      setCodeBlock: (n) => ({ commands: e }) => e.setNode(this.name, n),
      toggleCodeBlock: (n) => ({ commands: e }) => e.toggleNode(this.name, "paragraph", n)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Alt-c": () => this.editor.commands.toggleCodeBlock(),
      // remove code block when at start of document or code block is empty
      Backspace: () => {
        const { empty: n, $anchor: e } = this.editor.state.selection, t = e.pos === 1;
        return !n || e.parent.type.name !== this.name ? !1 : t || !e.parent.textContent.length ? this.editor.commands.clearNodes() : !1;
      },
      // exit node on triple enter
      Enter: ({ editor: n }) => {
        if (!this.options.exitOnTripleEnter)
          return !1;
        const { state: e } = n, { selection: t } = e, { $from: r, empty: i } = t;
        if (!i || r.parent.type !== this.type)
          return !1;
        const s = r.parentOffset === r.parent.nodeSize - 2, o = r.parent.textContent.endsWith(`

`);
        return !s || !o ? !1 : n.chain().command(({ tr: l }) => (l.delete(r.pos - 2, r.pos), !0)).exitCode().run();
      },
      // exit node on arrow down
      ArrowDown: ({ editor: n }) => {
        if (!this.options.exitOnArrowDown)
          return !1;
        const { state: e } = n, { selection: t, doc: r } = e, { $from: i, empty: s } = t;
        if (!s || i.parent.type !== this.type || !(i.parentOffset === i.parent.nodeSize - 2))
          return !1;
        const l = i.after();
        return l === void 0 ? !1 : r.nodeAt(l) ? n.commands.command(({ tr: u }) => (u.setSelection(re.near(r.resolve(l))), !0)) : n.commands.exitCode();
      }
    };
  },
  addInputRules() {
    return [
      ha({
        find: SE,
        type: this.type,
        getAttributes: (n) => ({
          language: n[1]
        })
      }),
      ha({
        find: CE,
        type: this.type,
        getAttributes: (n) => ({
          language: n[1]
        })
      })
    ];
  },
  addProseMirrorPlugins() {
    return [
      // this plugin creates a code block for pasted content from VS Code
      // we can also detect the copied code language
      new Te({
        key: new Ie("codeBlockVSCodeHandler"),
        props: {
          handlePaste: (n, e) => {
            if (!e.clipboardData || this.editor.isActive(this.type.name))
              return !1;
            const t = e.clipboardData.getData("text/plain"), r = e.clipboardData.getData("vscode-editor-data"), i = r ? JSON.parse(r) : void 0, s = i == null ? void 0 : i.mode;
            if (!t || !s)
              return !1;
            const { tr: o, schema: l } = n.state, a = l.text(t.replace(/\r\n?/g, `
`));
            return o.replaceSelectionWith(this.type.create({ language: s }, a)), o.selection.$from.parent.type !== this.type && o.setSelection(Z.near(o.doc.resolve(Math.max(0, o.selection.from - 2)))), o.setMeta("paste", !0), n.dispatch(o), !0;
          }
        }
      })
    ];
  }
}), AE = ft.create({
  name: "doc",
  topNode: !0,
  content: "block+"
}), TE = ft.create({
  name: "hardBreak",
  addOptions() {
    return {
      keepMarks: !0,
      HTMLAttributes: {}
    };
  },
  inline: !0,
  group: "inline",
  selectable: !1,
  linebreakReplacement: !0,
  parseHTML() {
    return [{ tag: "br" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["br", Fe(this.options.HTMLAttributes, n)];
  },
  renderText() {
    return `
`;
  },
  addCommands() {
    return {
      setHardBreak: () => ({ commands: n, chain: e, state: t, editor: r }) => n.first([
        () => n.exitCode(),
        () => n.command(() => {
          const { selection: i, storedMarks: s } = t;
          if (i.$from.parent.type.spec.isolating)
            return !1;
          const { keepMarks: o } = this.options, { splittableMarks: l } = r.extensionManager, a = s || i.$to.parentOffset && i.$from.marks();
          return e().insertContent({ type: this.name }).command(({ tr: u, dispatch: c }) => {
            if (c && a && o) {
              const d = a.filter((f) => l.includes(f.type.name));
              u.ensureMarks(d);
            }
            return !0;
          }).run();
        })
      ])
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Enter": () => this.editor.commands.setHardBreak(),
      "Shift-Enter": () => this.editor.commands.setHardBreak()
    };
  }
}), xE = ft.create({
  name: "heading",
  addOptions() {
    return {
      levels: [1, 2, 3, 4, 5, 6],
      HTMLAttributes: {}
    };
  },
  content: "inline*",
  group: "block",
  defining: !0,
  addAttributes() {
    return {
      level: {
        default: 1,
        rendered: !1
      }
    };
  },
  parseHTML() {
    return this.options.levels.map((n) => ({
      tag: `h${n}`,
      attrs: { level: n }
    }));
  },
  renderHTML({ node: n, HTMLAttributes: e }) {
    return [`h${this.options.levels.includes(n.attrs.level) ? n.attrs.level : this.options.levels[0]}`, Fe(this.options.HTMLAttributes, e), 0];
  },
  addCommands() {
    return {
      setHeading: (n) => ({ commands: e }) => this.options.levels.includes(n.level) ? e.setNode(this.name, n) : !1,
      toggleHeading: (n) => ({ commands: e }) => this.options.levels.includes(n.level) ? e.toggleNode(this.name, "paragraph", n) : !1
    };
  },
  addKeyboardShortcuts() {
    return this.options.levels.reduce(
      (n, e) => ({
        ...n,
        [`Mod-Alt-${e}`]: () => this.editor.commands.toggleHeading({ level: e })
      }),
      {}
    );
  },
  addInputRules() {
    return this.options.levels.map((n) => ha({
      find: new RegExp(`^(#{${Math.min(...this.options.levels)},${n}})\\s$`),
      type: this.type,
      getAttributes: {
        level: n
      }
    }));
  }
}), ME = ft.create({
  name: "horizontalRule",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  group: "block",
  parseHTML() {
    return [{ tag: "hr" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["hr", Fe(this.options.HTMLAttributes, n)];
  },
  addCommands() {
    return {
      setHorizontalRule: () => ({ chain: n, state: e }) => {
        if (!rE(e, e.schema.nodes[this.name]))
          return !1;
        const { selection: t } = e, { $to: r } = t, i = n();
        return rm(t) ? i.insertContentAt(r.pos, {
          type: this.name
        }) : i.insertContent({ type: this.name }), i.command(({ tr: s, dispatch: o }) => {
          var l;
          if (o) {
            const { $to: a } = s.selection, u = a.end();
            if (a.nodeAfter)
              a.nodeAfter.isTextblock ? s.setSelection(Z.create(s.doc, a.pos + 1)) : a.nodeAfter.isBlock ? s.setSelection(G.create(s.doc, a.pos)) : s.setSelection(Z.create(s.doc, a.pos));
            else {
              const c = (l = a.parent.type.contentMatch.defaultType) == null ? void 0 : l.create();
              c && (s.insert(u, c), s.setSelection(Z.create(s.doc, u + 1)));
            }
            s.scrollIntoView();
          }
          return !0;
        }).run();
      }
    };
  },
  addInputRules() {
    return [
      vm({
        find: /^(?:---|—-|___\s|\*\*\*\s)$/,
        type: this.type
      })
    ];
  }
}), $E = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))$/, FE = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))/g, OE = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))$/, NE = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))/g, RE = kr.create({
  name: "italic",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "em"
      },
      {
        tag: "i",
        getAttrs: (n) => n.style.fontStyle !== "normal" && null
      },
      {
        style: "font-style=normal",
        clearMark: (n) => n.type.name === this.name
      },
      {
        style: "font-style=italic"
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["em", Fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setItalic: () => ({ commands: n }) => n.setMark(this.name),
      toggleItalic: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetItalic: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-i": () => this.editor.commands.toggleItalic(),
      "Mod-I": () => this.editor.commands.toggleItalic()
    };
  },
  addInputRules() {
    return [
      Wr({
        find: $E,
        type: this.type
      }),
      Wr({
        find: OE,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      gr({
        find: FE,
        type: this.type
      }),
      gr({
        find: NE,
        type: this.type
      })
    ];
  }
});
const IE = "aaa1rp3bb0ott3vie4c1le2ogado5udhabi7c0ademy5centure6ountant0s9o1tor4d0s1ult4e0g1ro2tna4f0l1rica5g0akhan5ency5i0g1rbus3force5tel5kdn3l0ibaba4pay4lfinanz6state5y2sace3tom5m0azon4ericanexpress7family11x2fam3ica3sterdam8nalytics7droid5quan4z2o0l2partments8p0le4q0uarelle8r0ab1mco4chi3my2pa2t0e3s0da2ia2sociates9t0hleta5torney7u0ction5di0ble3o3spost5thor3o0s4w0s2x0a2z0ure5ba0by2idu3namex4d1k2r0celona5laycard4s5efoot5gains6seball5ketball8uhaus5yern5b0c1t1va3cg1n2d1e0ats2uty4er2rlin4st0buy5t2f1g1h0arti5i0ble3d1ke2ng0o3o1z2j1lack0friday9ockbuster8g1omberg7ue3m0s1w2n0pparibas9o0ats3ehringer8fa2m1nd2o0k0ing5sch2tik2on4t1utique6x2r0adesco6idgestone9oadway5ker3ther5ussels7s1t1uild0ers6siness6y1zz3v1w1y1z0h3ca0b1fe2l0l1vinklein9m0era3p2non3petown5ital0one8r0avan4ds2e0er0s4s2sa1e1h1ino4t0ering5holic7ba1n1re3c1d1enter4o1rn3f0a1d2g1h0anel2nel4rity4se2t2eap3intai5ristmas6ome4urch5i0priani6rcle4sco3tadel4i0c2y3k1l0aims4eaning6ick2nic1que6othing5ud3ub0med6m1n1o0ach3des3ffee4llege4ogne5m0mbank4unity6pany2re3uter5sec4ndos3struction8ulting7tact3ractors9oking4l1p2rsica5untry4pon0s4rses6pa2r0edit0card4union9icket5own3s1uise0s6u0isinella9v1w1x1y0mru3ou3z2dad1nce3ta1e1ing3sun4y2clk3ds2e0al0er2s3gree4livery5l1oitte5ta3mocrat6ntal2ist5si0gn4v2hl2iamonds6et2gital5rect0ory7scount3ver5h2y2j1k1m1np2o0cs1tor4g1mains5t1wnload7rive4tv2ubai3nlop4pont4rban5vag2r2z2earth3t2c0o2deka3u0cation8e1g1mail3erck5nergy4gineer0ing9terprises10pson4quipment8r0icsson6ni3s0q1tate5t1u0rovision8s2vents5xchange6pert3osed4ress5traspace10fage2il1rwinds6th3mily4n0s2rm0ers5shion4t3edex3edback6rrari3ero6i0delity5o2lm2nal1nce1ial7re0stone6mdale6sh0ing5t0ness6j1k1lickr3ghts4r2orist4wers5y2m1o0o0d1tball6rd1ex2sale4um3undation8x2r0ee1senius7l1ogans4ntier7tr2ujitsu5n0d2rniture7tbol5yi3ga0l0lery3o1up4me0s3p1rden4y2b0iz3d0n2e0a1nt0ing5orge5f1g0ee3h1i0ft0s3ves2ing5l0ass3e1obal2o4m0ail3bh2o1x2n1odaddy5ld0point6f2o0dyear5g0le4p1t1v2p1q1r0ainger5phics5tis4een3ipe3ocery4up4s1t1u0cci3ge2ide2tars5ru3w1y2hair2mburg5ngout5us3bo2dfc0bank7ealth0care8lp1sinki6re1mes5iphop4samitsu7tachi5v2k0t2m1n1ockey4ldings5iday5medepot5goods5s0ense7nda3rse3spital5t0ing5t0els3mail5use3w2r1sbc3t1u0ghes5yatt3undai7ibm2cbc2e1u2d1e0ee3fm2kano4l1m0amat4db2mo0bilien9n0c1dustries8finiti5o2g1k1stitute6urance4e4t0ernational10uit4vestments10o1piranga7q1r0ish4s0maili5t0anbul7t0au2v3jaguar4va3cb2e0ep2tzt3welry6io2ll2m0p2nj2o0bs1urg4t1y2p0morgan6rs3uegos4niper7kaufen5ddi3e0rryhotels6properties14fh2g1h1i0a1ds2m1ndle4tchen5wi3m1n1oeln3matsu5sher5p0mg2n2r0d1ed3uokgroup8w1y0oto4z2la0caixa5mborghini8er3nd0rover6xess5salle5t0ino3robe5w0yer5b1c1ds2ease3clerc5frak4gal2o2xus4gbt3i0dl2fe0insurance9style7ghting6ke2lly3mited4o2ncoln4k2ve1ing5k1lc1p2oan0s3cker3us3l1ndon4tte1o3ve3pl0financial11r1s1t0d0a3u0ndbeck6xe1ury5v1y2ma0drid4if1son4keup4n0agement7go3p1rket0ing3s4riott5shalls7ttel5ba2c0kinsey7d1e0d0ia3et2lbourne7me1orial6n0u2rckmsd7g1h1iami3crosoft7l1ni1t2t0subishi9k1l0b1s2m0a2n1o0bi0le4da2e1i1m1nash3ey2ster5rmon3tgage6scow4to0rcycles9v0ie4p1q1r1s0d2t0n1r2u0seum3ic4v1w1x1y1z2na0b1goya4me2vy3ba2c1e0c1t0bank4flix4work5ustar5w0s2xt0direct7us4f0l2g0o2hk2i0co2ke1on3nja3ssan1y5l1o0kia3rton4w0ruz3tv4p1r0a1w2tt2u1yc2z2obi1server7ffice5kinawa6layan0group9lo3m0ega4ne1g1l0ine5oo2pen3racle3nge4g0anic5igins6saka4tsuka4t2vh3pa0ge2nasonic7ris2s1tners4s1y3y2ccw3e0t2f0izer5g1h0armacy6d1ilips5one2to0graphy6s4ysio5ics1tet2ures6d1n0g1k2oneer5zza4k1l0ace2y0station9umbing5s3m1n0c2ohl2ker3litie5rn2st3r0axi3ess3ime3o0d0uctions8f1gressive8mo2perties3y5tection8u0dential9s1t1ub2w0c2y2qa1pon3uebec3st5racing4dio4e0ad1lestate6tor2y4cipes5d0stone5umbrella9hab3ise0n3t2liance6n0t0als5pair3ort3ublican8st0aurant8view0s5xroth6ich0ardli6oh3l1o1p2o0cks3deo3gers4om3s0vp3u0gby3hr2n2w0e2yukyu6sa0arland6fe0ty4kura4le1on3msclub4ung5ndvik0coromant12ofi4p1rl2s1ve2xo3b0i1s2c0b1haeffler7midt4olarships8ol3ule3warz5ience5ot3d1e0arch3t2cure1ity6ek2lect4ner3rvices6ven3w1x0y3fr2g1h0angrila6rp3ell3ia1ksha5oes2p0ping5uji3w3i0lk2na1gles5te3j1k0i0n2y0pe4l0ing4m0art3ile4n0cf3o0ccer3ial4ftbank4ware6hu2lar2utions7ng1y2y2pa0ce3ort2t3r0l2s1t0ada2ples4r1tebank4farm7c0group6ockholm6rage3e3ream4udio2y3yle4u0cks3pplies3y2ort5rf1gery5zuki5v1watch4iss4x1y0dney4stems6z2tab1ipei4lk2obao4rget4tamotors6r2too4x0i3c0i2d0k2eam2ch0nology8l1masek5nnis4va3f1g1h0d1eater2re6iaa2ckets5enda4ps2res2ol4j0maxx4x2k0maxx5l1m0all4n1o0day3kyo3ols3p1ray3shiba5tal3urs3wn2yota3s3r0ade1ing4ining5vel0ers0insurance16ust3v2t1ube2i1nes3shu4v0s2w1z2ua1bank3s2g1k1nicom3versity8o2ol2ps2s1y1z2va0cations7na1guard7c1e0gas3ntures6risign5mögensberater2ung14sicherung10t2g1i0ajes4deo3g1king4llas4n1p1rgin4sa1ion4va1o3laanderen9n1odka3lvo3te1ing3o2yage5u2wales2mart4ter4ng0gou5tch0es6eather0channel12bcam3er2site5d0ding5ibo2r3f1hoswho6ien2ki2lliamhill9n0dows4e1ners6me2olterskluwer11odside6rk0s2ld3w2s1tc1f3xbox3erox4ihuan4n2xx2yz3yachts4hoo3maxun5ndex5e1odobashi7ga2kohama6u0tube6t1un3za0ppos4ra3ero3ip2m1one3uerich6w2", LE = "ελ1υ2бг1ел3дети4ею2католик6ом3мкд2он1сква6онлайн5рг3рус2ф2сайт3рб3укр3қаз3հայ3ישראל5קום3ابوظبي5رامكو5لاردن4بحرين5جزائر5سعودية6عليان5مغرب5مارات5یران5بارت2زار4يتك3ھارت5تونس4سودان3رية5شبكة4عراق2ب2مان4فلسطين6قطر3كاثوليك6وم3مصر2ليسيا5وريتانيا7قع4همراه5پاکستان7ڀارت4कॉम3नेट3भारत0म्3ोत5संगठन5বাংলা5ভারত2ৰত4ਭਾਰਤ4ભારત4ଭାରତ4இந்தியா6லங்கை6சிங்கப்பூர்11భారత్5ಭಾರತ4ഭാരതം5ලංකා4คอม3ไทย3ລາວ3გე2みんな3アマゾン4クラウド4グーグル4コム2ストア3セール3ファッション6ポイント4世界2中信1国1國1文网3亚马逊3企业2佛山2信息2健康2八卦2公司1益2台湾1灣2商城1店1标2嘉里0大酒店5在线2大拿2天主教3娱乐2家電2广东2微博2慈善2我爱你3手机2招聘2政务1府2新加坡2闻2时尚2書籍2机构2淡马锡3游戏2澳門2点看2移动2组织机构4网址1店1站1络2联通2谷歌2购物2通販2集团2電訊盈科4飞利浦3食品2餐厅2香格里拉3港2닷넷1컴2삼성2한국2", pa = "numeric", ma = "ascii", ga = "alpha", Ci = "asciinumeric", pi = "alphanumeric", _a = "domain", Sm = "emoji", PE = "scheme", BE = "slashscheme", Tl = "whitespace";
function zE(n, e) {
  return n in e || (e[n] = []), e[n];
}
function sr(n, e, t) {
  e[pa] && (e[Ci] = !0, e[pi] = !0), e[ma] && (e[Ci] = !0, e[ga] = !0), e[Ci] && (e[pi] = !0), e[ga] && (e[pi] = !0), e[pi] && (e[_a] = !0), e[Sm] && (e[_a] = !0);
  for (const r in e) {
    const i = zE(r, t);
    i.indexOf(n) < 0 && i.push(n);
  }
}
function HE(n, e) {
  const t = {};
  for (const r in e)
    e[r].indexOf(n) >= 0 && (t[r] = !0);
  return t;
}
function ct(n = null) {
  this.j = {}, this.jr = [], this.jd = null, this.t = n;
}
ct.groups = {};
ct.prototype = {
  accepts() {
    return !!this.t;
  },
  /**
   * Follow an existing transition from the given input to the next state.
   * Does not mutate.
   * @param {string} input character or token type to transition on
   * @returns {?State<T>} the next state, if any
   */
  go(n) {
    const e = this, t = e.j[n];
    if (t)
      return t;
    for (let r = 0; r < e.jr.length; r++) {
      const i = e.jr[r][0], s = e.jr[r][1];
      if (s && i.test(n))
        return s;
    }
    return e.jd;
  },
  /**
   * Whether the state has a transition for the given input. Set the second
   * argument to true to only look for an exact match (and not a default or
   * regular-expression-based transition)
   * @param {string} input
   * @param {boolean} exactOnly
   */
  has(n, e = !1) {
    return e ? n in this.j : !!this.go(n);
  },
  /**
   * Short for "transition all"; create a transition from the array of items
   * in the given list to the same final resulting state.
   * @param {string | string[]} inputs Group of inputs to transition on
   * @param {Transition<T> | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of token groups
   */
  ta(n, e, t, r) {
    for (let i = 0; i < n.length; i++)
      this.tt(n[i], e, t, r);
  },
  /**
   * Short for "take regexp transition"; defines a transition for this state
   * when it encounters a token which matches the given regular expression
   * @param {RegExp} regexp Regular expression transition (populate first)
   * @param {T | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of token groups
   * @returns {State<T>} taken after the given input
   */
  tr(n, e, t, r) {
    r = r || ct.groups;
    let i;
    return e && e.j ? i = e : (i = new ct(e), t && r && sr(e, t, r)), this.jr.push([n, i]), i;
  },
  /**
   * Short for "take transitions", will take as many sequential transitions as
   * the length of the given input and returns the
   * resulting final state.
   * @param {string | string[]} input
   * @param {T | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of token groups
   * @returns {State<T>} taken after the given input
   */
  ts(n, e, t, r) {
    let i = this;
    const s = n.length;
    if (!s)
      return i;
    for (let o = 0; o < s - 1; o++)
      i = i.tt(n[o]);
    return i.tt(n[s - 1], e, t, r);
  },
  /**
   * Short for "take transition", this is a method for building/working with
   * state machines.
   *
   * If a state already exists for the given input, returns it.
   *
   * If a token is specified, that state will emit that token when reached by
   * the linkify engine.
   *
   * If no state exists, it will be initialized with some default transitions
   * that resemble existing default transitions.
   *
   * If a state is given for the second argument, that state will be
   * transitioned to on the given input regardless of what that input
   * previously did.
   *
   * Specify a token group flags to define groups that this token belongs to.
   * The token will be added to corresponding entires in the given groups
   * object.
   *
   * @param {string} input character, token type to transition on
   * @param {T | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of groups
   * @returns {State<T>} taken after the given input
   */
  tt(n, e, t, r) {
    r = r || ct.groups;
    const i = this;
    if (e && e.j)
      return i.j[n] = e, e;
    const s = e;
    let o, l = i.go(n);
    if (l ? (o = new ct(), Object.assign(o.j, l.j), o.jr.push.apply(o.jr, l.jr), o.jd = l.jd, o.t = l.t) : o = new ct(), s) {
      if (r)
        if (o.t && typeof o.t == "string") {
          const a = Object.assign(HE(o.t, r), t);
          sr(s, a, r);
        } else t && sr(s, t, r);
      o.t = s;
    }
    return i.j[n] = o, o;
  }
};
const se = (n, e, t, r, i) => n.ta(e, t, r, i), Me = (n, e, t, r, i) => n.tr(e, t, r, i), Qd = (n, e, t, r, i) => n.ts(e, t, r, i), O = (n, e, t, r, i) => n.tt(e, t, r, i), kn = "WORD", ya = "UWORD", Cm = "ASCIINUMERICAL", Dm = "ALPHANUMERICAL", Hi = "LOCALHOST", ba = "TLD", ka = "UTLD", Ns = "SCHEME", Nr = "SLASH_SCHEME", lu = "NUM", va = "WS", au = "NL", Di = "OPENBRACE", Ai = "CLOSEBRACE", eo = "OPENBRACKET", to = "CLOSEBRACKET", no = "OPENPAREN", ro = "CLOSEPAREN", io = "OPENANGLEBRACKET", so = "CLOSEANGLEBRACKET", oo = "FULLWIDTHLEFTPAREN", lo = "FULLWIDTHRIGHTPAREN", ao = "LEFTCORNERBRACKET", uo = "RIGHTCORNERBRACKET", co = "LEFTWHITECORNERBRACKET", fo = "RIGHTWHITECORNERBRACKET", ho = "FULLWIDTHLESSTHAN", po = "FULLWIDTHGREATERTHAN", mo = "AMPERSAND", go = "APOSTROPHE", _o = "ASTERISK", Nn = "AT", yo = "BACKSLASH", bo = "BACKTICK", ko = "CARET", Ln = "COLON", uu = "COMMA", vo = "DOLLAR", Xt = "DOT", wo = "EQUALS", cu = "EXCLAMATION", wt = "HYPHEN", Ti = "PERCENT", Eo = "PIPE", So = "PLUS", Co = "POUND", xi = "QUERY", du = "QUOTE", Am = "FULLWIDTHMIDDLEDOT", fu = "SEMI", Zt = "SLASH", Mi = "TILDE", Do = "UNDERSCORE", Tm = "EMOJI", Ao = "SYM";
var xm = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ALPHANUMERICAL: Dm,
  AMPERSAND: mo,
  APOSTROPHE: go,
  ASCIINUMERICAL: Cm,
  ASTERISK: _o,
  AT: Nn,
  BACKSLASH: yo,
  BACKTICK: bo,
  CARET: ko,
  CLOSEANGLEBRACKET: so,
  CLOSEBRACE: Ai,
  CLOSEBRACKET: to,
  CLOSEPAREN: ro,
  COLON: Ln,
  COMMA: uu,
  DOLLAR: vo,
  DOT: Xt,
  EMOJI: Tm,
  EQUALS: wo,
  EXCLAMATION: cu,
  FULLWIDTHGREATERTHAN: po,
  FULLWIDTHLEFTPAREN: oo,
  FULLWIDTHLESSTHAN: ho,
  FULLWIDTHMIDDLEDOT: Am,
  FULLWIDTHRIGHTPAREN: lo,
  HYPHEN: wt,
  LEFTCORNERBRACKET: ao,
  LEFTWHITECORNERBRACKET: co,
  LOCALHOST: Hi,
  NL: au,
  NUM: lu,
  OPENANGLEBRACKET: io,
  OPENBRACE: Di,
  OPENBRACKET: eo,
  OPENPAREN: no,
  PERCENT: Ti,
  PIPE: Eo,
  PLUS: So,
  POUND: Co,
  QUERY: xi,
  QUOTE: du,
  RIGHTCORNERBRACKET: uo,
  RIGHTWHITECORNERBRACKET: fo,
  SCHEME: Ns,
  SEMI: fu,
  SLASH: Zt,
  SLASH_SCHEME: Nr,
  SYM: Ao,
  TILDE: Mi,
  TLD: ba,
  UNDERSCORE: Do,
  UTLD: ka,
  UWORD: ya,
  WORD: kn,
  WS: va
});
const gn = /[a-z]/, ai = new RegExp("\\p{L}", "u"), xl = new RegExp("\\p{Emoji}", "u"), _n = /\d/, Ml = /\s/, ef = "\r", $l = `
`, qE = "️", jE = "‍", Fl = "￼";
let vs = null, ws = null;
function VE(n = []) {
  const e = {};
  ct.groups = e;
  const t = new ct();
  vs == null && (vs = tf(IE)), ws == null && (ws = tf(LE)), O(t, "'", go), O(t, "{", Di), O(t, "}", Ai), O(t, "[", eo), O(t, "]", to), O(t, "(", no), O(t, ")", ro), O(t, "<", io), O(t, ">", so), O(t, "（", oo), O(t, "）", lo), O(t, "「", ao), O(t, "」", uo), O(t, "『", co), O(t, "』", fo), O(t, "＜", ho), O(t, "＞", po), O(t, "&", mo), O(t, "*", _o), O(t, "@", Nn), O(t, "`", bo), O(t, "^", ko), O(t, ":", Ln), O(t, ",", uu), O(t, "$", vo), O(t, ".", Xt), O(t, "=", wo), O(t, "!", cu), O(t, "-", wt), O(t, "%", Ti), O(t, "|", Eo), O(t, "+", So), O(t, "#", Co), O(t, "?", xi), O(t, '"', du), O(t, "/", Zt), O(t, ";", fu), O(t, "~", Mi), O(t, "_", Do), O(t, "\\", yo), O(t, "・", Am);
  const r = Me(t, _n, lu, {
    [pa]: !0
  });
  Me(r, _n, r);
  const i = Me(r, gn, Cm, {
    [Ci]: !0
  }), s = Me(r, ai, Dm, {
    [pi]: !0
  }), o = Me(t, gn, kn, {
    [ma]: !0
  });
  Me(o, _n, i), Me(o, gn, o), Me(i, _n, i), Me(i, gn, i);
  const l = Me(t, ai, ya, {
    [ga]: !0
  });
  Me(l, gn), Me(l, _n, s), Me(l, ai, l), Me(s, _n, s), Me(s, gn), Me(s, ai, s);
  const a = O(t, $l, au, {
    [Tl]: !0
  }), u = O(t, ef, va, {
    [Tl]: !0
  }), c = Me(t, Ml, va, {
    [Tl]: !0
  });
  O(t, Fl, c), O(u, $l, a), O(u, Fl, c), Me(u, Ml, c), O(c, ef), O(c, $l), Me(c, Ml, c), O(c, Fl, c);
  const d = Me(t, xl, Tm, {
    [Sm]: !0
  });
  O(d, "#"), Me(d, xl, d), O(d, qE, d);
  const f = O(d, jE);
  O(f, "#"), Me(f, xl, d);
  const h = [[gn, o], [_n, i]], p = [[gn, null], [ai, l], [_n, s]];
  for (let g = 0; g < vs.length; g++)
    Mn(t, vs[g], ba, kn, h);
  for (let g = 0; g < ws.length; g++)
    Mn(t, ws[g], ka, ya, p);
  sr(ba, {
    tld: !0,
    ascii: !0
  }, e), sr(ka, {
    utld: !0,
    alpha: !0
  }, e), Mn(t, "file", Ns, kn, h), Mn(t, "mailto", Ns, kn, h), Mn(t, "http", Nr, kn, h), Mn(t, "https", Nr, kn, h), Mn(t, "ftp", Nr, kn, h), Mn(t, "ftps", Nr, kn, h), sr(Ns, {
    scheme: !0,
    ascii: !0
  }, e), sr(Nr, {
    slashscheme: !0,
    ascii: !0
  }, e), n = n.sort((g, _) => g[0] > _[0] ? 1 : -1);
  for (let g = 0; g < n.length; g++) {
    const _ = n[g][0], b = n[g][1] ? {
      [PE]: !0
    } : {
      [BE]: !0
    };
    _.indexOf("-") >= 0 ? b[_a] = !0 : gn.test(_) ? _n.test(_) ? b[Ci] = !0 : b[ma] = !0 : b[pa] = !0, Qd(t, _, _, b);
  }
  return Qd(t, "localhost", Hi, {
    ascii: !0
  }), t.jd = new ct(Ao), {
    start: t,
    tokens: Object.assign({
      groups: e
    }, xm)
  };
}
function Mm(n, e) {
  const t = UE(e.replace(/[A-Z]/g, (l) => l.toLowerCase())), r = t.length, i = [];
  let s = 0, o = 0;
  for (; o < r; ) {
    let l = n, a = null, u = 0, c = null, d = -1, f = -1;
    for (; o < r && (a = l.go(t[o])); )
      l = a, l.accepts() ? (d = 0, f = 0, c = l) : d >= 0 && (d += t[o].length, f++), u += t[o].length, s += t[o].length, o++;
    s -= d, o -= f, u -= d, i.push({
      t: c.t,
      // token type/name
      v: e.slice(s - u, s),
      // string value
      s: s - u,
      // start index
      e: s
      // end index (excluding)
    });
  }
  return i;
}
function UE(n) {
  const e = [], t = n.length;
  let r = 0;
  for (; r < t; ) {
    let i = n.charCodeAt(r), s, o = i < 55296 || i > 56319 || r + 1 === t || (s = n.charCodeAt(r + 1)) < 56320 || s > 57343 ? n[r] : n.slice(r, r + 2);
    e.push(o), r += o.length;
  }
  return e;
}
function Mn(n, e, t, r, i) {
  let s;
  const o = e.length;
  for (let l = 0; l < o - 1; l++) {
    const a = e[l];
    n.j[a] ? s = n.j[a] : (s = new ct(r), s.jr = i.slice(), n.j[a] = s), n = s;
  }
  return s = new ct(t), s.jr = i.slice(), n.j[e[o - 1]] = s, s;
}
function tf(n) {
  const e = [], t = [];
  let r = 0, i = "0123456789";
  for (; r < n.length; ) {
    let s = 0;
    for (; i.indexOf(n[r + s]) >= 0; )
      s++;
    if (s > 0) {
      e.push(t.join(""));
      for (let o = parseInt(n.substring(r, r + s), 10); o > 0; o--)
        t.pop();
      r += s;
    } else
      t.push(n[r]), r++;
  }
  return e;
}
const qi = {
  defaultProtocol: "http",
  events: null,
  format: nf,
  formatHref: nf,
  nl2br: !1,
  tagName: "a",
  target: null,
  rel: null,
  validate: !0,
  truncate: 1 / 0,
  className: null,
  attributes: null,
  ignoreTags: [],
  render: null
};
function hu(n, e = null) {
  let t = Object.assign({}, qi);
  n && (t = Object.assign(t, n instanceof hu ? n.o : n));
  const r = t.ignoreTags, i = [];
  for (let s = 0; s < r.length; s++)
    i.push(r[s].toUpperCase());
  this.o = t, e && (this.defaultRender = e), this.ignoreTags = i;
}
hu.prototype = {
  o: qi,
  /**
   * @type string[]
   */
  ignoreTags: [],
  /**
   * @param {IntermediateRepresentation} ir
   * @returns {any}
   */
  defaultRender(n) {
    return n;
  },
  /**
   * Returns true or false based on whether a token should be displayed as a
   * link based on the user options.
   * @param {MultiToken} token
   * @returns {boolean}
   */
  check(n) {
    return this.get("validate", n.toString(), n);
  },
  // Private methods
  /**
   * Resolve an option's value based on the value of the option and the given
   * params. If operator and token are specified and the target option is
   * callable, automatically calls the function with the given argument.
   * @template {keyof Opts} K
   * @param {K} key Name of option to use
   * @param {string} [operator] will be passed to the target option if it's a
   * function. If not specified, RAW function value gets returned
   * @param {MultiToken} [token] The token from linkify.tokenize
   * @returns {Opts[K] | any}
   */
  get(n, e, t) {
    const r = e != null;
    let i = this.o[n];
    return i && (typeof i == "object" ? (i = t.t in i ? i[t.t] : qi[n], typeof i == "function" && r && (i = i(e, t))) : typeof i == "function" && r && (i = i(e, t.t, t)), i);
  },
  /**
   * @template {keyof Opts} L
   * @param {L} key Name of options object to use
   * @param {string} [operator]
   * @param {MultiToken} [token]
   * @returns {Opts[L] | any}
   */
  getObj(n, e, t) {
    let r = this.o[n];
    return typeof r == "function" && e != null && (r = r(e, t.t, t)), r;
  },
  /**
   * Convert the given token to a rendered element that may be added to the
   * calling-interface's DOM
   * @param {MultiToken} token Token to render to an HTML element
   * @returns {any} Render result; e.g., HTML string, DOM element, React
   *   Component, etc.
   */
  render(n) {
    const e = n.render(this);
    return (this.get("render", null, n) || this.defaultRender)(e, n.t, n);
  }
};
function nf(n) {
  return n;
}
function $m(n, e) {
  this.t = "token", this.v = n, this.tk = e;
}
$m.prototype = {
  isLink: !1,
  /**
   * Return the string this token represents.
   * @return {string}
   */
  toString() {
    return this.v;
  },
  /**
   * What should the value for this token be in the `href` HTML attribute?
   * Returns the `.toString` value by default.
   * @param {string} [scheme]
   * @return {string}
   */
  toHref(n) {
    return this.toString();
  },
  /**
   * @param {Options} options Formatting options
   * @returns {string}
   */
  toFormattedString(n) {
    const e = this.toString(), t = n.get("truncate", e, this), r = n.get("format", e, this);
    return t && r.length > t ? r.substring(0, t) + "…" : r;
  },
  /**
   *
   * @param {Options} options
   * @returns {string}
   */
  toFormattedHref(n) {
    return n.get("formatHref", this.toHref(n.get("defaultProtocol")), this);
  },
  /**
   * The start index of this token in the original input string
   * @returns {number}
   */
  startIndex() {
    return this.tk[0].s;
  },
  /**
   * The end index of this token in the original input string (up to this
   * index but not including it)
   * @returns {number}
   */
  endIndex() {
    return this.tk[this.tk.length - 1].e;
  },
  /**
  	Returns an object  of relevant values for this token, which includes keys
  	* type - Kind of token ('url', 'email', etc.)
  	* value - Original text
  	* href - The value that should be added to the anchor tag's href
  		attribute
  		@method toObject
  	@param {string} [protocol] `'http'` by default
  */
  toObject(n = qi.defaultProtocol) {
    return {
      type: this.t,
      value: this.toString(),
      isLink: this.isLink,
      href: this.toHref(n),
      start: this.startIndex(),
      end: this.endIndex()
    };
  },
  /**
   *
   * @param {Options} options Formatting option
   */
  toFormattedObject(n) {
    return {
      type: this.t,
      value: this.toFormattedString(n),
      isLink: this.isLink,
      href: this.toFormattedHref(n),
      start: this.startIndex(),
      end: this.endIndex()
    };
  },
  /**
   * Whether this token should be rendered as a link according to the given options
   * @param {Options} options
   * @returns {boolean}
   */
  validate(n) {
    return n.get("validate", this.toString(), this);
  },
  /**
   * Return an object that represents how this link should be rendered.
   * @param {Options} options Formattinng options
   */
  render(n) {
    const e = this, t = this.toHref(n.get("defaultProtocol")), r = n.get("formatHref", t, this), i = n.get("tagName", t, e), s = this.toFormattedString(n), o = {}, l = n.get("className", t, e), a = n.get("target", t, e), u = n.get("rel", t, e), c = n.getObj("attributes", t, e), d = n.getObj("events", t, e);
    return o.href = r, l && (o.class = l), a && (o.target = a), u && (o.rel = u), c && Object.assign(o, c), {
      tagName: i,
      attributes: o,
      content: s,
      eventListeners: d
    };
  }
};
function Vo(n, e) {
  class t extends $m {
    constructor(i, s) {
      super(i, s), this.t = n;
    }
  }
  for (const r in e)
    t.prototype[r] = e[r];
  return t.t = n, t;
}
const rf = Vo("email", {
  isLink: !0,
  toHref() {
    return "mailto:" + this.toString();
  }
}), sf = Vo("text"), WE = Vo("nl"), Es = Vo("url", {
  isLink: !0,
  /**
  	Lowercases relevant parts of the domain and adds the protocol if
  	required. Note that this will not escape unsafe HTML characters in the
  	URL.
  		@param {string} [scheme] default scheme (e.g., 'https')
  	@return {string} the full href
  */
  toHref(n = qi.defaultProtocol) {
    return this.hasProtocol() ? this.v : `${n}://${this.v}`;
  },
  /**
   * Check whether this URL token has a protocol
   * @return {boolean}
   */
  hasProtocol() {
    const n = this.tk;
    return n.length >= 2 && n[0].t !== Hi && n[1].t === Ln;
  }
}), kt = (n) => new ct(n);
function KE({
  groups: n
}) {
  const e = n.domain.concat([mo, _o, Nn, yo, bo, ko, vo, wo, wt, lu, Ti, Eo, So, Co, Zt, Ao, Mi, Do]), t = [go, Ln, uu, Xt, cu, Ti, xi, du, fu, io, so, Di, Ai, to, eo, no, ro, oo, lo, ao, uo, co, fo, ho, po], r = [mo, go, _o, yo, bo, ko, vo, wo, wt, Di, Ai, Ti, Eo, So, Co, xi, Zt, Ao, Mi, Do], i = kt(), s = O(i, Mi);
  se(s, r, s), se(s, n.domain, s);
  const o = kt(), l = kt(), a = kt();
  se(i, n.domain, o), se(i, n.scheme, l), se(i, n.slashscheme, a), se(o, r, s), se(o, n.domain, o);
  const u = O(o, Nn);
  O(s, Nn, u), O(l, Nn, u), O(a, Nn, u);
  const c = O(s, Xt);
  se(c, r, s), se(c, n.domain, s);
  const d = kt();
  se(u, n.domain, d), se(d, n.domain, d);
  const f = O(d, Xt);
  se(f, n.domain, d);
  const h = kt(rf);
  se(f, n.tld, h), se(f, n.utld, h), O(u, Hi, h);
  const p = O(d, wt);
  O(p, wt, p), se(p, n.domain, d), se(h, n.domain, d), O(h, Xt, f), O(h, wt, p);
  const g = O(h, Ln);
  se(g, n.numeric, rf);
  const _ = O(o, wt), k = O(o, Xt);
  O(_, wt, _), se(_, n.domain, o), se(k, r, s), se(k, n.domain, o);
  const b = kt(Es);
  se(k, n.tld, b), se(k, n.utld, b), se(b, n.domain, o), se(b, r, s), O(b, Xt, k), O(b, wt, _), O(b, Nn, u);
  const y = O(b, Ln), v = kt(Es);
  se(y, n.numeric, v);
  const S = kt(Es), D = kt();
  se(S, e, S), se(S, t, D), se(D, e, S), se(D, t, D), O(b, Zt, S), O(v, Zt, S);
  const T = O(l, Ln), x = O(a, Ln), M = O(x, Zt), L = O(M, Zt);
  se(l, n.domain, o), O(l, Xt, k), O(l, wt, _), se(a, n.domain, o), O(a, Xt, k), O(a, wt, _), se(T, n.domain, S), O(T, Zt, S), O(T, xi, S), se(L, n.domain, S), se(L, e, S), O(L, Zt, S);
  const R = [
    [Di, Ai],
    // {}
    [eo, to],
    // []
    [no, ro],
    // ()
    [io, so],
    // <>
    [oo, lo],
    // （）
    [ao, uo],
    // 「」
    [co, fo],
    // 『』
    [ho, po]
    // ＜＞
  ];
  for (let X = 0; X < R.length; X++) {
    const [ke, ue] = R[X], ae = O(S, ke);
    O(D, ke, ae), O(ae, ue, S);
    const ie = kt(Es);
    se(ae, e, ie);
    const ve = kt();
    se(ae, t), se(ie, e, ie), se(ie, t, ve), se(ve, e, ie), se(ve, t, ve), O(ie, ue, S), O(ve, ue, S);
  }
  return O(i, Hi, b), O(i, au, WE), {
    start: i,
    tokens: xm
  };
}
function GE(n, e, t) {
  let r = t.length, i = 0, s = [], o = [];
  for (; i < r; ) {
    let l = n, a = null, u = null, c = 0, d = null, f = -1;
    for (; i < r && !(a = l.go(t[i].t)); )
      o.push(t[i++]);
    for (; i < r && (u = a || l.go(t[i].t)); )
      a = null, l = u, l.accepts() ? (f = 0, d = l) : f >= 0 && f++, i++, c++;
    if (f < 0)
      i -= c, i < r && (o.push(t[i]), i++);
    else {
      o.length > 0 && (s.push(Ol(sf, e, o)), o = []), i -= f, c -= f;
      const h = d.t, p = t.slice(i - c, i);
      s.push(Ol(h, e, p));
    }
  }
  return o.length > 0 && s.push(Ol(sf, e, o)), s;
}
function Ol(n, e, t) {
  const r = t[0].s, i = t[t.length - 1].e, s = e.slice(r, i);
  return new n(s, t);
}
const JE = typeof console < "u" && console && console.warn || (() => {
}), YE = "until manual call of linkify.init(). Register all schemes and plugins before invoking linkify the first time.", Ee = {
  scanner: null,
  parser: null,
  tokenQueue: [],
  pluginQueue: [],
  customSchemes: [],
  initialized: !1
};
function XE() {
  return ct.groups = {}, Ee.scanner = null, Ee.parser = null, Ee.tokenQueue = [], Ee.pluginQueue = [], Ee.customSchemes = [], Ee.initialized = !1, Ee;
}
function of(n, e = !1) {
  if (Ee.initialized && JE(`linkifyjs: already initialized - will not register custom scheme "${n}" ${YE}`), !/^[0-9a-z]+(-[0-9a-z]+)*$/.test(n))
    throw new Error(`linkifyjs: incorrect scheme format.
1. Must only contain digits, lowercase ASCII letters or "-"
2. Cannot start or end with "-"
3. "-" cannot repeat`);
  Ee.customSchemes.push([n, e]);
}
function ZE() {
  Ee.scanner = VE(Ee.customSchemes);
  for (let n = 0; n < Ee.tokenQueue.length; n++)
    Ee.tokenQueue[n][1]({
      scanner: Ee.scanner
    });
  Ee.parser = KE(Ee.scanner.tokens);
  for (let n = 0; n < Ee.pluginQueue.length; n++)
    Ee.pluginQueue[n][1]({
      scanner: Ee.scanner,
      parser: Ee.parser
    });
  return Ee.initialized = !0, Ee;
}
function pu(n) {
  return Ee.initialized || ZE(), GE(Ee.parser.start, n, Mm(Ee.scanner.start, n));
}
pu.scan = Mm;
function Fm(n, e = null, t = null) {
  if (e && typeof e == "object") {
    if (t)
      throw Error(`linkifyjs: Invalid link type ${e}; must be a string`);
    t = e, e = null;
  }
  const r = new hu(t), i = pu(n), s = [];
  for (let o = 0; o < i.length; o++) {
    const l = i[o];
    l.isLink && (!e || l.t === e) && r.check(l) && s.push(l.toFormattedObject(r));
  }
  return s;
}
var mu = "[\0-   ᠎ -\u2029 　]", QE = new RegExp(mu), eS = new RegExp(`${mu}$`), tS = new RegExp(mu, "g");
function nS(n) {
  return n.length === 1 ? n[0].isLink : n.length === 3 && n[1].isLink ? ["()", "[]"].includes(n[0].value + n[2].value) : !1;
}
function rS(n) {
  return new Te({
    key: new Ie("autolink"),
    appendTransaction: (e, t, r) => {
      const i = e.some((u) => u.docChanged) && !t.doc.eq(r.doc), s = e.some((u) => u.getMeta("preventAutolink"));
      if (!i || s)
        return;
      const { tr: o } = r, l = Kp(t.doc, [...e]);
      if (tm(l).forEach(({ newRange: u }) => {
        const c = kv(r.doc, u, (h) => h.isTextblock);
        let d, f;
        if (c.length > 1)
          d = c[0], f = r.doc.textBetween(
            d.pos,
            d.pos + d.node.nodeSize,
            void 0,
            " "
          );
        else if (c.length) {
          const h = r.doc.textBetween(u.from, u.to, " ", " ");
          if (!eS.test(h))
            return;
          d = c[0], f = r.doc.textBetween(d.pos, u.to, void 0, " ");
        }
        if (d && f) {
          const h = f.split(QE).filter(Boolean);
          if (h.length <= 0)
            return !1;
          const p = h[h.length - 1], g = d.pos + f.lastIndexOf(p);
          if (!p)
            return !1;
          const _ = pu(p).map((k) => k.toObject(n.defaultProtocol));
          if (!nS(_))
            return !1;
          _.filter((k) => k.isLink).map((k) => ({
            ...k,
            from: g + k.start + 1,
            to: g + k.end + 1
          })).filter((k) => r.schema.marks.code ? !r.doc.rangeHasMark(k.from, k.to, r.schema.marks.code) : !0).filter((k) => n.validate(k.value)).filter((k) => n.shouldAutoLink(k.value)).forEach((k) => {
            iu(k.from, k.to, r.doc).some((b) => b.mark.type === n.type) || o.addMark(
              k.from,
              k.to,
              n.type.create({
                href: k.href
              })
            );
          });
        }
      }), !!o.steps.length)
        return o;
    }
  });
}
function iS(n) {
  return new Te({
    key: new Ie("handleClickLink"),
    props: {
      handleClick: (e, t, r) => {
        var i, s;
        if (r.button !== 0 || !e.editable)
          return !1;
        let o = null;
        if (r.target instanceof HTMLAnchorElement)
          o = r.target;
        else {
          let c = r.target;
          const d = [];
          for (; c.nodeName !== "DIV"; )
            d.push(c), c = c.parentNode;
          o = d.find((f) => f.nodeName === "A");
        }
        if (!o)
          return !1;
        const l = em(e.state, n.type.name), a = (i = o == null ? void 0 : o.href) != null ? i : l.href, u = (s = o == null ? void 0 : o.target) != null ? s : l.target;
        return n.enableClickSelection && n.editor.commands.extendMarkRange(n.type.name), o && a ? (window.open(a, u), !0) : !1;
      }
    }
  });
}
function sS(n) {
  return new Te({
    key: new Ie("handlePasteLink"),
    props: {
      handlePaste: (e, t, r) => {
        const { state: i } = e, { selection: s } = i, { empty: o } = s;
        if (o)
          return !1;
        let l = "";
        r.content.forEach((u) => {
          l += u.textContent;
        });
        const a = Fm(l, { defaultProtocol: n.defaultProtocol }).find(
          (u) => u.isLink && u.value === l
        );
        return !l || !a ? !1 : n.editor.commands.setMark(n.type, {
          href: a.href
        });
      }
    }
  });
}
function Qn(n, e) {
  const t = ["http", "https", "ftp", "ftps", "mailto", "tel", "callto", "sms", "cid", "xmpp"];
  return e && e.forEach((r) => {
    const i = typeof r == "string" ? r : r.scheme;
    i && t.push(i);
  }), !n || n.replace(tS, "").match(
    new RegExp(
      // eslint-disable-next-line no-useless-escape
      `^(?:(?:${t.join("|")}):|[^a-z]|[a-z0-9+.-]+(?:[^a-z+.-:]|$))`,
      "i"
    )
  );
}
var Om = kr.create({
  name: "link",
  priority: 1e3,
  keepOnSplit: !1,
  exitable: !0,
  onCreate() {
    this.options.validate && !this.options.shouldAutoLink && (this.options.shouldAutoLink = this.options.validate, console.warn("The `validate` option is deprecated. Rename to the `shouldAutoLink` option instead.")), this.options.protocols.forEach((n) => {
      if (typeof n == "string") {
        of(n);
        return;
      }
      of(n.scheme, n.optionalSlashes);
    });
  },
  onDestroy() {
    XE();
  },
  inclusive() {
    return this.options.autolink;
  },
  addOptions() {
    return {
      openOnClick: !0,
      enableClickSelection: !1,
      linkOnPaste: !0,
      autolink: !0,
      protocols: [],
      defaultProtocol: "http",
      HTMLAttributes: {
        target: "_blank",
        rel: "noopener noreferrer nofollow",
        class: null
      },
      isAllowedUri: (n, e) => !!Qn(n, e.protocols),
      validate: (n) => !!n,
      shouldAutoLink: (n) => !!n
    };
  },
  addAttributes() {
    return {
      href: {
        default: null,
        parseHTML(n) {
          return n.getAttribute("href");
        }
      },
      target: {
        default: this.options.HTMLAttributes.target
      },
      rel: {
        default: this.options.HTMLAttributes.rel
      },
      class: {
        default: this.options.HTMLAttributes.class
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "a[href]",
        getAttrs: (n) => {
          const e = n.getAttribute("href");
          return !e || !this.options.isAllowedUri(e, {
            defaultValidate: (t) => !!Qn(t, this.options.protocols),
            protocols: this.options.protocols,
            defaultProtocol: this.options.defaultProtocol
          }) ? !1 : null;
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return this.options.isAllowedUri(n.href, {
      defaultValidate: (e) => !!Qn(e, this.options.protocols),
      protocols: this.options.protocols,
      defaultProtocol: this.options.defaultProtocol
    }) ? ["a", Fe(this.options.HTMLAttributes, n), 0] : ["a", Fe(this.options.HTMLAttributes, { ...n, href: "" }), 0];
  },
  addCommands() {
    return {
      setLink: (n) => ({ chain: e }) => {
        const { href: t } = n;
        return this.options.isAllowedUri(t, {
          defaultValidate: (r) => !!Qn(r, this.options.protocols),
          protocols: this.options.protocols,
          defaultProtocol: this.options.defaultProtocol
        }) ? e().setMark(this.name, n).setMeta("preventAutolink", !0).run() : !1;
      },
      toggleLink: (n) => ({ chain: e }) => {
        const { href: t } = n || {};
        return t && !this.options.isAllowedUri(t, {
          defaultValidate: (r) => !!Qn(r, this.options.protocols),
          protocols: this.options.protocols,
          defaultProtocol: this.options.defaultProtocol
        }) ? !1 : e().toggleMark(this.name, n, { extendEmptyMarkRange: !0 }).setMeta("preventAutolink", !0).run();
      },
      unsetLink: () => ({ chain: n }) => n().unsetMark(this.name, { extendEmptyMarkRange: !0 }).setMeta("preventAutolink", !0).run()
    };
  },
  addPasteRules() {
    return [
      gr({
        find: (n) => {
          const e = [];
          if (n) {
            const { protocols: t, defaultProtocol: r } = this.options, i = Fm(n).filter(
              (s) => s.isLink && this.options.isAllowedUri(s.value, {
                defaultValidate: (o) => !!Qn(o, t),
                protocols: t,
                defaultProtocol: r
              })
            );
            i.length && i.forEach(
              (s) => e.push({
                text: s.value,
                data: {
                  href: s.href
                },
                index: s.start
              })
            );
          }
          return e;
        },
        type: this.type,
        getAttributes: (n) => {
          var e;
          return {
            href: (e = n.data) == null ? void 0 : e.href
          };
        }
      })
    ];
  },
  addProseMirrorPlugins() {
    const n = [], { protocols: e, defaultProtocol: t } = this.options;
    return this.options.autolink && n.push(
      rS({
        type: this.type,
        defaultProtocol: this.options.defaultProtocol,
        validate: (r) => this.options.isAllowedUri(r, {
          defaultValidate: (i) => !!Qn(i, e),
          protocols: e,
          defaultProtocol: t
        }),
        shouldAutoLink: this.options.shouldAutoLink
      })
    ), this.options.openOnClick === !0 && n.push(
      iS({
        type: this.type,
        editor: this.editor,
        enableClickSelection: this.options.enableClickSelection
      })
    ), this.options.linkOnPaste && n.push(
      sS({
        editor: this.editor,
        defaultProtocol: this.options.defaultProtocol,
        type: this.type
      })
    ), n;
  }
}), oS = Om, lS = Object.defineProperty, aS = (n, e) => {
  for (var t in e)
    lS(n, t, { get: e[t], enumerable: !0 });
}, uS = "listItem", lf = "textStyle", af = /^\s*([-+*])\s$/, Nm = ft.create({
  name: "bulletList",
  addOptions() {
    return {
      itemTypeName: "listItem",
      HTMLAttributes: {},
      keepMarks: !1,
      keepAttributes: !1
    };
  },
  group: "block list",
  content() {
    return `${this.options.itemTypeName}+`;
  },
  parseHTML() {
    return [{ tag: "ul" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["ul", Fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      toggleBulletList: () => ({ commands: n, chain: e }) => this.options.keepAttributes ? e().toggleList(this.name, this.options.itemTypeName, this.options.keepMarks).updateAttributes(uS, this.editor.getAttributes(lf)).run() : n.toggleList(this.name, this.options.itemTypeName, this.options.keepMarks)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-8": () => this.editor.commands.toggleBulletList()
    };
  },
  addInputRules() {
    let n = Kr({
      find: af,
      type: this.type
    });
    return (this.options.keepMarks || this.options.keepAttributes) && (n = Kr({
      find: af,
      type: this.type,
      keepMarks: this.options.keepMarks,
      keepAttributes: this.options.keepAttributes,
      getAttributes: () => this.editor.getAttributes(lf),
      editor: this.editor
    })), [n];
  }
}), Rm = ft.create({
  name: "listItem",
  addOptions() {
    return {
      HTMLAttributes: {},
      bulletListTypeName: "bulletList",
      orderedListTypeName: "orderedList"
    };
  },
  content: "paragraph block*",
  defining: !0,
  parseHTML() {
    return [
      {
        tag: "li"
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["li", Fe(this.options.HTMLAttributes, n), 0];
  },
  addKeyboardShortcuts() {
    return {
      Enter: () => this.editor.commands.splitListItem(this.name),
      Tab: () => this.editor.commands.sinkListItem(this.name),
      "Shift-Tab": () => this.editor.commands.liftListItem(this.name)
    };
  }
}), cS = {};
aS(cS, {
  findListItemPos: () => Gi,
  getNextListDepth: () => gu,
  handleBackspace: () => wa,
  handleDelete: () => Ea,
  hasListBefore: () => Im,
  hasListItemAfter: () => dS,
  hasListItemBefore: () => Lm,
  listItemHasSubList: () => Pm,
  nextListIsDeeper: () => Bm,
  nextListIsHigher: () => zm
});
var Gi = (n, e) => {
  const { $from: t } = e.selection, r = Re(n, e.schema);
  let i = null, s = t.depth, o = t.pos, l = null;
  for (; s > 0 && l === null; )
    i = t.node(s), i.type === r ? l = s : (s -= 1, o -= 1);
  return l === null ? null : { $pos: e.doc.resolve(o), depth: l };
}, gu = (n, e) => {
  const t = Gi(n, e);
  if (!t)
    return !1;
  const [, r] = xv(e, n, t.$pos.pos + 4);
  return r;
}, Im = (n, e, t) => {
  const { $anchor: r } = n.selection, i = Math.max(0, r.pos - 2), s = n.doc.resolve(i).node();
  return !(!s || !t.includes(s.type.name));
}, Lm = (n, e) => {
  var t;
  const { $anchor: r } = e.selection, i = e.doc.resolve(r.pos - 2);
  return !(i.index() === 0 || ((t = i.nodeBefore) == null ? void 0 : t.type.name) !== n);
}, Pm = (n, e, t) => {
  if (!t)
    return !1;
  const r = Re(n, e.schema);
  let i = !1;
  return t.descendants((s) => {
    s.type === r && (i = !0);
  }), i;
}, wa = (n, e, t) => {
  if (n.commands.undoInputRule())
    return !0;
  if (n.state.selection.from !== n.state.selection.to)
    return !1;
  if (!Wn(n.state, e) && Im(n.state, e, t)) {
    const { $anchor: l } = n.state.selection, a = n.state.doc.resolve(l.before() - 1), u = [];
    a.node().descendants((f, h) => {
      f.type.name === e && u.push({ node: f, pos: h });
    });
    const c = u.at(-1);
    if (!c)
      return !1;
    const d = n.state.doc.resolve(a.start() + c.pos + 1);
    return n.chain().cut({ from: l.start() - 1, to: l.end() + 1 }, d.end()).joinForward().run();
  }
  if (!Wn(n.state, e) || !Ov(n.state))
    return !1;
  const r = Gi(e, n.state);
  if (!r)
    return !1;
  const s = n.state.doc.resolve(r.$pos.pos - 2).node(r.depth), o = Pm(e, n.state, s);
  return Lm(e, n.state) && !o ? n.commands.joinItemBackward() : n.chain().liftListItem(e).run();
}, Bm = (n, e) => {
  const t = gu(n, e), r = Gi(n, e);
  return !r || !t ? !1 : t > r.depth;
}, zm = (n, e) => {
  const t = gu(n, e), r = Gi(n, e);
  return !r || !t ? !1 : t < r.depth;
}, Ea = (n, e) => {
  if (!Wn(n.state, e) || !Fv(n.state, e))
    return !1;
  const { selection: t } = n.state, { $from: r, $to: i } = t;
  return !t.empty && r.sameParent(i) ? !1 : Bm(e, n.state) ? n.chain().focus(n.state.selection.from + 4).lift(e).joinBackward().run() : zm(e, n.state) ? n.chain().joinForward().joinBackward().run() : n.commands.joinItemForward();
}, dS = (n, e) => {
  var t;
  const { $anchor: r } = e.selection, i = e.doc.resolve(r.pos - r.parentOffset - 2);
  return !(i.index() === i.parent.childCount - 1 || ((t = i.nodeAfter) == null ? void 0 : t.type.name) !== n);
}, Hm = Oe.create({
  name: "listKeymap",
  addOptions() {
    return {
      listTypes: [
        {
          itemName: "listItem",
          wrapperNames: ["bulletList", "orderedList"]
        },
        {
          itemName: "taskItem",
          wrapperNames: ["taskList"]
        }
      ]
    };
  },
  addKeyboardShortcuts() {
    return {
      Delete: ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t }) => {
          n.state.schema.nodes[t] !== void 0 && Ea(n, t) && (e = !0);
        }), e;
      },
      "Mod-Delete": ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t }) => {
          n.state.schema.nodes[t] !== void 0 && Ea(n, t) && (e = !0);
        }), e;
      },
      Backspace: ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t, wrapperNames: r }) => {
          n.state.schema.nodes[t] !== void 0 && wa(n, t, r) && (e = !0);
        }), e;
      },
      "Mod-Backspace": ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t, wrapperNames: r }) => {
          n.state.schema.nodes[t] !== void 0 && wa(n, t, r) && (e = !0);
        }), e;
      }
    };
  }
}), fS = "listItem", uf = "textStyle", cf = /^(\d+)\.\s$/, qm = ft.create({
  name: "orderedList",
  addOptions() {
    return {
      itemTypeName: "listItem",
      HTMLAttributes: {},
      keepMarks: !1,
      keepAttributes: !1
    };
  },
  group: "block list",
  content() {
    return `${this.options.itemTypeName}+`;
  },
  addAttributes() {
    return {
      start: {
        default: 1,
        parseHTML: (n) => n.hasAttribute("start") ? parseInt(n.getAttribute("start") || "", 10) : 1
      },
      type: {
        default: null,
        parseHTML: (n) => n.getAttribute("type")
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "ol"
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    const { start: e, ...t } = n;
    return e === 1 ? ["ol", Fe(this.options.HTMLAttributes, t), 0] : ["ol", Fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      toggleOrderedList: () => ({ commands: n, chain: e }) => this.options.keepAttributes ? e().toggleList(this.name, this.options.itemTypeName, this.options.keepMarks).updateAttributes(fS, this.editor.getAttributes(uf)).run() : n.toggleList(this.name, this.options.itemTypeName, this.options.keepMarks)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-7": () => this.editor.commands.toggleOrderedList()
    };
  },
  addInputRules() {
    let n = Kr({
      find: cf,
      type: this.type,
      getAttributes: (e) => ({ start: +e[1] }),
      joinPredicate: (e, t) => t.childCount + t.attrs.start === +e[1]
    });
    return (this.options.keepMarks || this.options.keepAttributes) && (n = Kr({
      find: cf,
      type: this.type,
      keepMarks: this.options.keepMarks,
      keepAttributes: this.options.keepAttributes,
      getAttributes: (e) => ({ start: +e[1], ...this.editor.getAttributes(uf) }),
      joinPredicate: (e, t) => t.childCount + t.attrs.start === +e[1],
      editor: this.editor
    })), [n];
  }
}), hS = /^\s*(\[([( |x])?\])\s$/, pS = ft.create({
  name: "taskItem",
  addOptions() {
    return {
      nested: !1,
      HTMLAttributes: {},
      taskListTypeName: "taskList",
      a11y: void 0
    };
  },
  content() {
    return this.options.nested ? "paragraph block*" : "paragraph+";
  },
  defining: !0,
  addAttributes() {
    return {
      checked: {
        default: !1,
        keepOnSplit: !1,
        parseHTML: (n) => {
          const e = n.getAttribute("data-checked");
          return e === "" || e === "true";
        },
        renderHTML: (n) => ({
          "data-checked": n.checked
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: `li[data-type="${this.name}"]`,
        priority: 51
      }
    ];
  },
  renderHTML({ node: n, HTMLAttributes: e }) {
    return [
      "li",
      Fe(this.options.HTMLAttributes, e, {
        "data-type": this.name
      }),
      [
        "label",
        [
          "input",
          {
            type: "checkbox",
            checked: n.attrs.checked ? "checked" : null
          }
        ],
        ["span"]
      ],
      ["div", 0]
    ];
  },
  addKeyboardShortcuts() {
    const n = {
      Enter: () => this.editor.commands.splitListItem(this.name),
      "Shift-Tab": () => this.editor.commands.liftListItem(this.name)
    };
    return this.options.nested ? {
      ...n,
      Tab: () => this.editor.commands.sinkListItem(this.name)
    } : n;
  },
  addNodeView() {
    return ({ node: n, HTMLAttributes: e, getPos: t, editor: r }) => {
      const i = document.createElement("li"), s = document.createElement("label"), o = document.createElement("span"), l = document.createElement("input"), a = document.createElement("div"), u = () => {
        var c, d;
        l.ariaLabel = ((d = (c = this.options.a11y) == null ? void 0 : c.checkboxLabel) == null ? void 0 : d.call(c, n, l.checked)) || `Task item checkbox for ${n.textContent || "empty task item"}`;
      };
      return u(), s.contentEditable = "false", l.type = "checkbox", l.addEventListener("mousedown", (c) => c.preventDefault()), l.addEventListener("change", (c) => {
        if (!r.isEditable && !this.options.onReadOnlyChecked) {
          l.checked = !l.checked;
          return;
        }
        const { checked: d } = c.target;
        r.isEditable && typeof t == "function" && r.chain().focus(void 0, { scrollIntoView: !1 }).command(({ tr: f }) => {
          const h = t();
          if (typeof h != "number")
            return !1;
          const p = f.doc.nodeAt(h);
          return f.setNodeMarkup(h, void 0, {
            ...p == null ? void 0 : p.attrs,
            checked: d
          }), !0;
        }).run(), !r.isEditable && this.options.onReadOnlyChecked && (this.options.onReadOnlyChecked(n, d) || (l.checked = !l.checked));
      }), Object.entries(this.options.HTMLAttributes).forEach(([c, d]) => {
        i.setAttribute(c, d);
      }), i.dataset.checked = n.attrs.checked, l.checked = n.attrs.checked, s.append(l, o), i.append(s, a), Object.entries(e).forEach(([c, d]) => {
        i.setAttribute(c, d);
      }), {
        dom: i,
        contentDOM: a,
        update: (c) => c.type !== this.type ? !1 : (i.dataset.checked = c.attrs.checked, l.checked = c.attrs.checked, u(), !0)
      };
    };
  },
  addInputRules() {
    return [
      Kr({
        find: hS,
        type: this.type,
        getAttributes: (n) => ({
          checked: n[n.length - 1] === "x"
        })
      })
    ];
  }
}), mS = ft.create({
  name: "taskList",
  addOptions() {
    return {
      itemTypeName: "taskItem",
      HTMLAttributes: {}
    };
  },
  group: "block list",
  content() {
    return `${this.options.itemTypeName}+`;
  },
  parseHTML() {
    return [
      {
        tag: `ul[data-type="${this.name}"]`,
        priority: 51
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["ul", Fe(this.options.HTMLAttributes, n, { "data-type": this.name }), 0];
  },
  addCommands() {
    return {
      toggleTaskList: () => ({ commands: n }) => n.toggleList(this.name, this.options.itemTypeName)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-9": () => this.editor.commands.toggleTaskList()
    };
  }
});
Oe.create({
  name: "listKit",
  addExtensions() {
    const n = [];
    return this.options.bulletList !== !1 && n.push(Nm.configure(this.options.bulletList)), this.options.listItem !== !1 && n.push(Rm.configure(this.options.listItem)), this.options.listKeymap !== !1 && n.push(Hm.configure(this.options.listKeymap)), this.options.orderedList !== !1 && n.push(qm.configure(this.options.orderedList)), this.options.taskItem !== !1 && n.push(pS.configure(this.options.taskItem)), this.options.taskList !== !1 && n.push(mS.configure(this.options.taskList)), n;
  }
});
var gS = ft.create({
  name: "paragraph",
  priority: 1e3,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  group: "block",
  content: "inline*",
  parseHTML() {
    return [{ tag: "p" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["p", Fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setParagraph: () => ({ commands: n }) => n.setNode(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Alt-0": () => this.editor.commands.setParagraph()
    };
  }
}), _S = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))$/, yS = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))/g, bS = kr.create({
  name: "strike",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "s"
      },
      {
        tag: "del"
      },
      {
        tag: "strike"
      },
      {
        style: "text-decoration",
        consuming: !1,
        getAttrs: (n) => n.includes("line-through") ? {} : !1
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["s", Fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setStrike: () => ({ commands: n }) => n.setMark(this.name),
      toggleStrike: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetStrike: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-s": () => this.editor.commands.toggleStrike()
    };
  },
  addInputRules() {
    return [
      Wr({
        find: _S,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      gr({
        find: yS,
        type: this.type
      })
    ];
  }
}), kS = ft.create({
  name: "text",
  group: "inline"
}), vS = kr.create({
  name: "underline",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "u"
      },
      {
        style: "text-decoration",
        consuming: !1,
        getAttrs: (n) => n.includes("underline") ? {} : !1
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["u", Fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setUnderline: () => ({ commands: n }) => n.setMark(this.name),
      toggleUnderline: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetUnderline: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-u": () => this.editor.commands.toggleUnderline(),
      "Mod-U": () => this.editor.commands.toggleUnderline()
    };
  }
});
function wS(n = {}) {
  return new Te({
    view(e) {
      return new ES(e, n);
    }
  });
}
class ES {
  constructor(e, t) {
    var r;
    this.editorView = e, this.cursorPos = null, this.element = null, this.timeout = -1, this.width = (r = t.width) !== null && r !== void 0 ? r : 1, this.color = t.color === !1 ? void 0 : t.color || "black", this.class = t.class, this.handlers = ["dragover", "dragend", "drop", "dragleave"].map((i) => {
      let s = (o) => {
        this[i](o);
      };
      return e.dom.addEventListener(i, s), { name: i, handler: s };
    });
  }
  destroy() {
    this.handlers.forEach(({ name: e, handler: t }) => this.editorView.dom.removeEventListener(e, t));
  }
  update(e, t) {
    this.cursorPos != null && t.doc != e.state.doc && (this.cursorPos > e.state.doc.content.size ? this.setCursor(null) : this.updateOverlay());
  }
  setCursor(e) {
    e != this.cursorPos && (this.cursorPos = e, e == null ? (this.element.parentNode.removeChild(this.element), this.element = null) : this.updateOverlay());
  }
  updateOverlay() {
    let e = this.editorView.state.doc.resolve(this.cursorPos), t = !e.parent.inlineContent, r, i = this.editorView.dom, s = i.getBoundingClientRect(), o = s.width / i.offsetWidth, l = s.height / i.offsetHeight;
    if (t) {
      let d = e.nodeBefore, f = e.nodeAfter;
      if (d || f) {
        let h = this.editorView.nodeDOM(this.cursorPos - (d ? d.nodeSize : 0));
        if (h) {
          let p = h.getBoundingClientRect(), g = d ? p.bottom : p.top;
          d && f && (g = (g + this.editorView.nodeDOM(this.cursorPos).getBoundingClientRect().top) / 2);
          let _ = this.width / 2 * l;
          r = { left: p.left, right: p.right, top: g - _, bottom: g + _ };
        }
      }
    }
    if (!r) {
      let d = this.editorView.coordsAtPos(this.cursorPos), f = this.width / 2 * o;
      r = { left: d.left - f, right: d.left + f, top: d.top, bottom: d.bottom };
    }
    let a = this.editorView.dom.offsetParent;
    this.element || (this.element = a.appendChild(document.createElement("div")), this.class && (this.element.className = this.class), this.element.style.cssText = "position: absolute; z-index: 50; pointer-events: none;", this.color && (this.element.style.backgroundColor = this.color)), this.element.classList.toggle("prosemirror-dropcursor-block", t), this.element.classList.toggle("prosemirror-dropcursor-inline", !t);
    let u, c;
    if (!a || a == document.body && getComputedStyle(a).position == "static")
      u = -pageXOffset, c = -pageYOffset;
    else {
      let d = a.getBoundingClientRect(), f = d.width / a.offsetWidth, h = d.height / a.offsetHeight;
      u = d.left - a.scrollLeft * f, c = d.top - a.scrollTop * h;
    }
    this.element.style.left = (r.left - u) / o + "px", this.element.style.top = (r.top - c) / l + "px", this.element.style.width = (r.right - r.left) / o + "px", this.element.style.height = (r.bottom - r.top) / l + "px";
  }
  scheduleRemoval(e) {
    clearTimeout(this.timeout), this.timeout = setTimeout(() => this.setCursor(null), e);
  }
  dragover(e) {
    if (!this.editorView.editable)
      return;
    let t = this.editorView.posAtCoords({ left: e.clientX, top: e.clientY }), r = t && t.inside >= 0 && this.editorView.state.doc.nodeAt(t.inside), i = r && r.type.spec.disableDropCursor, s = typeof i == "function" ? i(this.editorView, t, e) : i;
    if (t && !s) {
      let o = t.pos;
      if (this.editorView.dragging && this.editorView.dragging.slice) {
        let l = Uh(this.editorView.state.doc, o, this.editorView.dragging.slice);
        l != null && (o = l);
      }
      this.setCursor(o), this.scheduleRemoval(5e3);
    }
  }
  dragend() {
    this.scheduleRemoval(20);
  }
  drop() {
    this.scheduleRemoval(20);
  }
  dragleave(e) {
    this.editorView.dom.contains(e.relatedTarget) || this.setCursor(null);
  }
}
class $e extends re {
  /**
  Create a gap cursor.
  */
  constructor(e) {
    super(e, e);
  }
  map(e, t) {
    let r = e.resolve(t.map(this.head));
    return $e.valid(r) ? new $e(r) : re.near(r);
  }
  content() {
    return z.empty;
  }
  eq(e) {
    return e instanceof $e && e.head == this.head;
  }
  toJSON() {
    return { type: "gapcursor", pos: this.head };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for GapCursor.fromJSON");
    return new $e(e.resolve(t.pos));
  }
  /**
  @internal
  */
  getBookmark() {
    return new _u(this.anchor);
  }
  /**
  @internal
  */
  static valid(e) {
    let t = e.parent;
    if (t.isTextblock || !SS(e) || !CS(e))
      return !1;
    let r = t.type.spec.allowGapCursor;
    if (r != null)
      return r;
    let i = t.contentMatchAt(e.index()).defaultType;
    return i && i.isTextblock;
  }
  /**
  @internal
  */
  static findGapCursorFrom(e, t, r = !1) {
    e: for (; ; ) {
      if (!r && $e.valid(e))
        return e;
      let i = e.pos, s = null;
      for (let o = e.depth; ; o--) {
        let l = e.node(o);
        if (t > 0 ? e.indexAfter(o) < l.childCount : e.index(o) > 0) {
          s = l.child(t > 0 ? e.indexAfter(o) : e.index(o) - 1);
          break;
        } else if (o == 0)
          return null;
        i += t;
        let a = e.doc.resolve(i);
        if ($e.valid(a))
          return a;
      }
      for (; ; ) {
        let o = t > 0 ? s.firstChild : s.lastChild;
        if (!o) {
          if (s.isAtom && !s.isText && !G.isSelectable(s)) {
            e = e.doc.resolve(i + s.nodeSize * t), r = !1;
            continue e;
          }
          break;
        }
        s = o, i += t;
        let l = e.doc.resolve(i);
        if ($e.valid(l))
          return l;
      }
      return null;
    }
  }
}
$e.prototype.visible = !1;
$e.findFrom = $e.findGapCursorFrom;
re.jsonID("gapcursor", $e);
class _u {
  constructor(e) {
    this.pos = e;
  }
  map(e) {
    return new _u(e.map(this.pos));
  }
  resolve(e) {
    let t = e.resolve(this.pos);
    return $e.valid(t) ? new $e(t) : re.near(t);
  }
}
function SS(n) {
  for (let e = n.depth; e >= 0; e--) {
    let t = n.index(e), r = n.node(e);
    if (t == 0) {
      if (r.type.spec.isolating)
        return !0;
      continue;
    }
    for (let i = r.child(t - 1); ; i = i.lastChild) {
      if (i.childCount == 0 && !i.inlineContent || i.isAtom || i.type.spec.isolating)
        return !0;
      if (i.inlineContent)
        return !1;
    }
  }
  return !0;
}
function CS(n) {
  for (let e = n.depth; e >= 0; e--) {
    let t = n.indexAfter(e), r = n.node(e);
    if (t == r.childCount) {
      if (r.type.spec.isolating)
        return !0;
      continue;
    }
    for (let i = r.child(t); ; i = i.firstChild) {
      if (i.childCount == 0 && !i.inlineContent || i.isAtom || i.type.spec.isolating)
        return !0;
      if (i.inlineContent)
        return !1;
    }
  }
  return !0;
}
function DS() {
  return new Te({
    props: {
      decorations: MS,
      createSelectionBetween(n, e, t) {
        return e.pos == t.pos && $e.valid(t) ? new $e(t) : null;
      },
      handleClick: TS,
      handleKeyDown: AS,
      handleDOMEvents: { beforeinput: xS }
    }
  });
}
const AS = Op({
  ArrowLeft: Ss("horiz", -1),
  ArrowRight: Ss("horiz", 1),
  ArrowUp: Ss("vert", -1),
  ArrowDown: Ss("vert", 1)
});
function Ss(n, e) {
  const t = n == "vert" ? e > 0 ? "down" : "up" : e > 0 ? "right" : "left";
  return function(r, i, s) {
    let o = r.selection, l = e > 0 ? o.$to : o.$from, a = o.empty;
    if (o instanceof Z) {
      if (!s.endOfTextblock(t) || l.depth == 0)
        return !1;
      a = !1, l = r.doc.resolve(e > 0 ? l.after() : l.before());
    }
    let u = $e.findGapCursorFrom(l, e, a);
    return u ? (i && i(r.tr.setSelection(new $e(u))), !0) : !1;
  };
}
function TS(n, e, t) {
  if (!n || !n.editable)
    return !1;
  let r = n.state.doc.resolve(e);
  if (!$e.valid(r))
    return !1;
  let i = n.posAtCoords({ left: t.clientX, top: t.clientY });
  return i && i.inside > -1 && G.isSelectable(n.state.doc.nodeAt(i.inside)) ? !1 : (n.dispatch(n.state.tr.setSelection(new $e(r))), !0);
}
function xS(n, e) {
  if (e.inputType != "insertCompositionText" || !(n.state.selection instanceof $e))
    return !1;
  let { $from: t } = n.state.selection, r = t.parent.contentMatchAt(t.index()).findWrapping(n.state.schema.nodes.text);
  if (!r)
    return !1;
  let i = F.empty;
  for (let o = r.length - 1; o >= 0; o--)
    i = F.from(r[o].createAndFill(null, i));
  let s = n.state.tr.replace(t.pos, t.pos, new z(i, 0, 0));
  return s.setSelection(Z.near(s.doc.resolve(t.pos + 1))), n.dispatch(s), !1;
}
function MS(n) {
  if (!(n.selection instanceof $e))
    return null;
  let e = document.createElement("div");
  return e.className = "ProseMirror-gapcursor", Ce.create(n.doc, [nt.widget(n.selection.head, e, { key: "gapcursor" })]);
}
var To = 200, qe = function() {
};
qe.prototype.append = function(e) {
  return e.length ? (e = qe.from(e), !this.length && e || e.length < To && this.leafAppend(e) || this.length < To && e.leafPrepend(this) || this.appendInner(e)) : this;
};
qe.prototype.prepend = function(e) {
  return e.length ? qe.from(e).append(this) : this;
};
qe.prototype.appendInner = function(e) {
  return new $S(this, e);
};
qe.prototype.slice = function(e, t) {
  return e === void 0 && (e = 0), t === void 0 && (t = this.length), e >= t ? qe.empty : this.sliceInner(Math.max(0, e), Math.min(this.length, t));
};
qe.prototype.get = function(e) {
  if (!(e < 0 || e >= this.length))
    return this.getInner(e);
};
qe.prototype.forEach = function(e, t, r) {
  t === void 0 && (t = 0), r === void 0 && (r = this.length), t <= r ? this.forEachInner(e, t, r, 0) : this.forEachInvertedInner(e, t, r, 0);
};
qe.prototype.map = function(e, t, r) {
  t === void 0 && (t = 0), r === void 0 && (r = this.length);
  var i = [];
  return this.forEach(function(s, o) {
    return i.push(e(s, o));
  }, t, r), i;
};
qe.from = function(e) {
  return e instanceof qe ? e : e && e.length ? new jm(e) : qe.empty;
};
var jm = /* @__PURE__ */ function(n) {
  function e(r) {
    n.call(this), this.values = r;
  }
  n && (e.__proto__ = n), e.prototype = Object.create(n && n.prototype), e.prototype.constructor = e;
  var t = { length: { configurable: !0 }, depth: { configurable: !0 } };
  return e.prototype.flatten = function() {
    return this.values;
  }, e.prototype.sliceInner = function(i, s) {
    return i == 0 && s == this.length ? this : new e(this.values.slice(i, s));
  }, e.prototype.getInner = function(i) {
    return this.values[i];
  }, e.prototype.forEachInner = function(i, s, o, l) {
    for (var a = s; a < o; a++)
      if (i(this.values[a], l + a) === !1)
        return !1;
  }, e.prototype.forEachInvertedInner = function(i, s, o, l) {
    for (var a = s - 1; a >= o; a--)
      if (i(this.values[a], l + a) === !1)
        return !1;
  }, e.prototype.leafAppend = function(i) {
    if (this.length + i.length <= To)
      return new e(this.values.concat(i.flatten()));
  }, e.prototype.leafPrepend = function(i) {
    if (this.length + i.length <= To)
      return new e(i.flatten().concat(this.values));
  }, t.length.get = function() {
    return this.values.length;
  }, t.depth.get = function() {
    return 0;
  }, Object.defineProperties(e.prototype, t), e;
}(qe);
qe.empty = new jm([]);
var $S = /* @__PURE__ */ function(n) {
  function e(t, r) {
    n.call(this), this.left = t, this.right = r, this.length = t.length + r.length, this.depth = Math.max(t.depth, r.depth) + 1;
  }
  return n && (e.__proto__ = n), e.prototype = Object.create(n && n.prototype), e.prototype.constructor = e, e.prototype.flatten = function() {
    return this.left.flatten().concat(this.right.flatten());
  }, e.prototype.getInner = function(r) {
    return r < this.left.length ? this.left.get(r) : this.right.get(r - this.left.length);
  }, e.prototype.forEachInner = function(r, i, s, o) {
    var l = this.left.length;
    if (i < l && this.left.forEachInner(r, i, Math.min(s, l), o) === !1 || s > l && this.right.forEachInner(r, Math.max(i - l, 0), Math.min(this.length, s) - l, o + l) === !1)
      return !1;
  }, e.prototype.forEachInvertedInner = function(r, i, s, o) {
    var l = this.left.length;
    if (i > l && this.right.forEachInvertedInner(r, i - l, Math.max(s, l) - l, o + l) === !1 || s < l && this.left.forEachInvertedInner(r, Math.min(i, l), s, o) === !1)
      return !1;
  }, e.prototype.sliceInner = function(r, i) {
    if (r == 0 && i == this.length)
      return this;
    var s = this.left.length;
    return i <= s ? this.left.slice(r, i) : r >= s ? this.right.slice(r - s, i - s) : this.left.slice(r, s).append(this.right.slice(0, i - s));
  }, e.prototype.leafAppend = function(r) {
    var i = this.right.leafAppend(r);
    if (i)
      return new e(this.left, i);
  }, e.prototype.leafPrepend = function(r) {
    var i = this.left.leafPrepend(r);
    if (i)
      return new e(i, this.right);
  }, e.prototype.appendInner = function(r) {
    return this.left.depth >= Math.max(this.right.depth, r.depth) + 1 ? new e(this.left, new e(this.right, r)) : new e(this, r);
  }, e;
}(qe);
const FS = 500;
class Ht {
  constructor(e, t) {
    this.items = e, this.eventCount = t;
  }
  // Pop the latest event off the branch's history and apply it
  // to a document transform.
  popEvent(e, t) {
    if (this.eventCount == 0)
      return null;
    let r = this.items.length;
    for (; ; r--)
      if (this.items.get(r - 1).selection) {
        --r;
        break;
      }
    let i, s;
    t && (i = this.remapping(r, this.items.length), s = i.maps.length);
    let o = e.tr, l, a, u = [], c = [];
    return this.items.forEach((d, f) => {
      if (!d.step) {
        i || (i = this.remapping(r, f + 1), s = i.maps.length), s--, c.push(d);
        return;
      }
      if (i) {
        c.push(new Qt(d.map));
        let h = d.step.map(i.slice(s)), p;
        h && o.maybeStep(h).doc && (p = o.mapping.maps[o.mapping.maps.length - 1], u.push(new Qt(p, void 0, void 0, u.length + c.length))), s--, p && i.appendMap(p, s);
      } else
        o.maybeStep(d.step);
      if (d.selection)
        return l = i ? d.selection.map(i.slice(s)) : d.selection, a = new Ht(this.items.slice(0, r).append(c.reverse().concat(u)), this.eventCount - 1), !1;
    }, this.items.length, 0), { remaining: a, transform: o, selection: l };
  }
  // Create a new branch with the given transform added.
  addTransform(e, t, r, i) {
    let s = [], o = this.eventCount, l = this.items, a = !i && l.length ? l.get(l.length - 1) : null;
    for (let c = 0; c < e.steps.length; c++) {
      let d = e.steps[c].invert(e.docs[c]), f = new Qt(e.mapping.maps[c], d, t), h;
      (h = a && a.merge(f)) && (f = h, c ? s.pop() : l = l.slice(0, l.length - 1)), s.push(f), t && (o++, t = void 0), i || (a = f);
    }
    let u = o - r.depth;
    return u > NS && (l = OS(l, u), o -= u), new Ht(l.append(s), o);
  }
  remapping(e, t) {
    let r = new Ri();
    return this.items.forEach((i, s) => {
      let o = i.mirrorOffset != null && s - i.mirrorOffset >= e ? r.maps.length - i.mirrorOffset : void 0;
      r.appendMap(i.map, o);
    }, e, t), r;
  }
  addMaps(e) {
    return this.eventCount == 0 ? this : new Ht(this.items.append(e.map((t) => new Qt(t))), this.eventCount);
  }
  // When the collab module receives remote changes, the history has
  // to know about those, so that it can adjust the steps that were
  // rebased on top of the remote changes, and include the position
  // maps for the remote changes in its array of items.
  rebased(e, t) {
    if (!this.eventCount)
      return this;
    let r = [], i = Math.max(0, this.items.length - t), s = e.mapping, o = e.steps.length, l = this.eventCount;
    this.items.forEach((f) => {
      f.selection && l--;
    }, i);
    let a = t;
    this.items.forEach((f) => {
      let h = s.getMirror(--a);
      if (h == null)
        return;
      o = Math.min(o, h);
      let p = s.maps[h];
      if (f.step) {
        let g = e.steps[h].invert(e.docs[h]), _ = f.selection && f.selection.map(s.slice(a + 1, h));
        _ && l++, r.push(new Qt(p, g, _));
      } else
        r.push(new Qt(p));
    }, i);
    let u = [];
    for (let f = t; f < o; f++)
      u.push(new Qt(s.maps[f]));
    let c = this.items.slice(0, i).append(u).append(r), d = new Ht(c, l);
    return d.emptyItemCount() > FS && (d = d.compress(this.items.length - r.length)), d;
  }
  emptyItemCount() {
    let e = 0;
    return this.items.forEach((t) => {
      t.step || e++;
    }), e;
  }
  // Compressing a branch means rewriting it to push the air (map-only
  // items) out. During collaboration, these naturally accumulate
  // because each remote change adds one. The `upto` argument is used
  // to ensure that only the items below a given level are compressed,
  // because `rebased` relies on a clean, untouched set of items in
  // order to associate old items with rebased steps.
  compress(e = this.items.length) {
    let t = this.remapping(0, e), r = t.maps.length, i = [], s = 0;
    return this.items.forEach((o, l) => {
      if (l >= e)
        i.push(o), o.selection && s++;
      else if (o.step) {
        let a = o.step.map(t.slice(r)), u = a && a.getMap();
        if (r--, u && t.appendMap(u, r), a) {
          let c = o.selection && o.selection.map(t.slice(r));
          c && s++;
          let d = new Qt(u.invert(), a, c), f, h = i.length - 1;
          (f = i.length && i[h].merge(d)) ? i[h] = f : i.push(d);
        }
      } else o.map && r--;
    }, this.items.length, 0), new Ht(qe.from(i.reverse()), s);
  }
}
Ht.empty = new Ht(qe.empty, 0);
function OS(n, e) {
  let t;
  return n.forEach((r, i) => {
    if (r.selection && e-- == 0)
      return t = i, !1;
  }), n.slice(t);
}
class Qt {
  constructor(e, t, r, i) {
    this.map = e, this.step = t, this.selection = r, this.mirrorOffset = i;
  }
  merge(e) {
    if (this.step && e.step && !e.selection) {
      let t = e.step.merge(this.step);
      if (t)
        return new Qt(t.getMap().invert(), t, this.selection);
    }
  }
}
class Rn {
  constructor(e, t, r, i, s) {
    this.done = e, this.undone = t, this.prevRanges = r, this.prevTime = i, this.prevComposition = s;
  }
}
const NS = 20;
function RS(n, e, t, r) {
  let i = t.getMeta(cr), s;
  if (i)
    return i.historyState;
  t.getMeta(PS) && (n = new Rn(n.done, n.undone, null, 0, -1));
  let o = t.getMeta("appendedTransaction");
  if (t.steps.length == 0)
    return n;
  if (o && o.getMeta(cr))
    return o.getMeta(cr).redo ? new Rn(n.done.addTransform(t, void 0, r, Rs(e)), n.undone, df(t.mapping.maps), n.prevTime, n.prevComposition) : new Rn(n.done, n.undone.addTransform(t, void 0, r, Rs(e)), null, n.prevTime, n.prevComposition);
  if (t.getMeta("addToHistory") !== !1 && !(o && o.getMeta("addToHistory") === !1)) {
    let l = t.getMeta("composition"), a = n.prevTime == 0 || !o && n.prevComposition != l && (n.prevTime < (t.time || 0) - r.newGroupDelay || !IS(t, n.prevRanges)), u = o ? Nl(n.prevRanges, t.mapping) : df(t.mapping.maps);
    return new Rn(n.done.addTransform(t, a ? e.selection.getBookmark() : void 0, r, Rs(e)), Ht.empty, u, t.time, l ?? n.prevComposition);
  } else return (s = t.getMeta("rebased")) ? new Rn(n.done.rebased(t, s), n.undone.rebased(t, s), Nl(n.prevRanges, t.mapping), n.prevTime, n.prevComposition) : new Rn(n.done.addMaps(t.mapping.maps), n.undone.addMaps(t.mapping.maps), Nl(n.prevRanges, t.mapping), n.prevTime, n.prevComposition);
}
function IS(n, e) {
  if (!e)
    return !1;
  if (!n.docChanged)
    return !0;
  let t = !1;
  return n.mapping.maps[0].forEach((r, i) => {
    for (let s = 0; s < e.length; s += 2)
      r <= e[s + 1] && i >= e[s] && (t = !0);
  }), t;
}
function df(n) {
  let e = [];
  for (let t = n.length - 1; t >= 0 && e.length == 0; t--)
    n[t].forEach((r, i, s, o) => e.push(s, o));
  return e;
}
function Nl(n, e) {
  if (!n)
    return null;
  let t = [];
  for (let r = 0; r < n.length; r += 2) {
    let i = e.map(n[r], 1), s = e.map(n[r + 1], -1);
    i <= s && t.push(i, s);
  }
  return t;
}
function LS(n, e, t) {
  let r = Rs(e), i = cr.get(e).spec.config, s = (t ? n.undone : n.done).popEvent(e, r);
  if (!s)
    return null;
  let o = s.selection.resolve(s.transform.doc), l = (t ? n.done : n.undone).addTransform(s.transform, e.selection.getBookmark(), i, r), a = new Rn(t ? l : s.remaining, t ? s.remaining : l, null, 0, -1);
  return s.transform.setSelection(o).setMeta(cr, { redo: t, historyState: a });
}
let Rl = !1, ff = null;
function Rs(n) {
  let e = n.plugins;
  if (ff != e) {
    Rl = !1, ff = e;
    for (let t = 0; t < e.length; t++)
      if (e[t].spec.historyPreserveItems) {
        Rl = !0;
        break;
      }
  }
  return Rl;
}
const cr = new Ie("history"), PS = new Ie("closeHistory");
function BS(n = {}) {
  return n = {
    depth: n.depth || 100,
    newGroupDelay: n.newGroupDelay || 500
  }, new Te({
    key: cr,
    state: {
      init() {
        return new Rn(Ht.empty, Ht.empty, null, 0, -1);
      },
      apply(e, t, r) {
        return RS(t, r, e, n);
      }
    },
    config: n,
    props: {
      handleDOMEvents: {
        beforeinput(e, t) {
          let r = t.inputType, i = r == "historyUndo" ? Um : r == "historyRedo" ? Wm : null;
          return i ? (t.preventDefault(), i(e.state, e.dispatch)) : !1;
        }
      }
    }
  });
}
function Vm(n, e) {
  return (t, r) => {
    let i = cr.getState(t);
    if (!i || (n ? i.undone : i.done).eventCount == 0)
      return !1;
    if (r) {
      let s = LS(i, t, n);
      s && r(e ? s.scrollIntoView() : s);
    }
    return !0;
  };
}
const Um = Vm(!1, !0), Wm = Vm(!0, !0);
Oe.create({
  name: "characterCount",
  addOptions() {
    return {
      limit: null,
      mode: "textSize",
      textCounter: (n) => n.length,
      wordCounter: (n) => n.split(" ").filter((e) => e !== "").length
    };
  },
  addStorage() {
    return {
      characters: () => 0,
      words: () => 0
    };
  },
  onBeforeCreate() {
    this.storage.characters = (n) => {
      const e = (n == null ? void 0 : n.node) || this.editor.state.doc;
      if (((n == null ? void 0 : n.mode) || this.options.mode) === "textSize") {
        const r = e.textBetween(0, e.content.size, void 0, " ");
        return this.options.textCounter(r);
      }
      return e.nodeSize;
    }, this.storage.words = (n) => {
      const e = (n == null ? void 0 : n.node) || this.editor.state.doc, t = e.textBetween(0, e.content.size, " ", " ");
      return this.options.wordCounter(t);
    };
  },
  addProseMirrorPlugins() {
    let n = !1;
    return [
      new Te({
        key: new Ie("characterCount"),
        appendTransaction: (e, t, r) => {
          if (n)
            return;
          const i = this.options.limit;
          if (i == null || i === 0) {
            n = !0;
            return;
          }
          const s = this.storage.characters({ node: r.doc });
          if (s > i) {
            const o = s - i, l = 0, a = o;
            console.warn(
              `[CharacterCount] Initial content exceeded limit of ${i} characters. Content was automatically trimmed.`
            );
            const u = r.tr.deleteRange(l, a);
            return n = !0, u;
          }
          n = !0;
        },
        filterTransaction: (e, t) => {
          const r = this.options.limit;
          if (!e.docChanged || r === 0 || r === null || r === void 0)
            return !0;
          const i = this.storage.characters({ node: t.doc }), s = this.storage.characters({ node: e.doc });
          if (s <= r || i > r && s > r && s <= i)
            return !0;
          if (i > r && s > r && s > i || !e.getMeta("paste"))
            return !1;
          const l = e.selection.$head.pos, a = s - r, u = l - a, c = l;
          return e.deleteRange(u, c), !(this.storage.characters({ node: e.doc }) > r);
        }
      })
    ];
  }
});
var zS = Oe.create({
  name: "dropCursor",
  addOptions() {
    return {
      color: "currentColor",
      width: 1,
      class: void 0
    };
  },
  addProseMirrorPlugins() {
    return [wS(this.options)];
  }
});
Oe.create({
  name: "focus",
  addOptions() {
    return {
      className: "has-focus",
      mode: "all"
    };
  },
  addProseMirrorPlugins() {
    return [
      new Te({
        key: new Ie("focus"),
        props: {
          decorations: ({ doc: n, selection: e }) => {
            const { isEditable: t, isFocused: r } = this.editor, { anchor: i } = e, s = [];
            if (!t || !r)
              return Ce.create(n, []);
            let o = 0;
            this.options.mode === "deepest" && n.descendants((a, u) => {
              if (a.isText)
                return;
              if (!(i >= u && i <= u + a.nodeSize - 1))
                return !1;
              o += 1;
            });
            let l = 0;
            return n.descendants((a, u) => {
              if (a.isText || !(i >= u && i <= u + a.nodeSize - 1))
                return !1;
              if (l += 1, this.options.mode === "deepest" && o - l > 0 || this.options.mode === "shallowest" && l > 1)
                return this.options.mode === "deepest";
              s.push(
                nt.node(u, u + a.nodeSize, {
                  class: this.options.className
                })
              );
            }), Ce.create(n, s);
          }
        }
      })
    ];
  }
});
var HS = Oe.create({
  name: "gapCursor",
  addProseMirrorPlugins() {
    return [DS()];
  },
  extendNodeSchema(n) {
    var e;
    const t = {
      name: n.name,
      options: n.options,
      storage: n.storage
    };
    return {
      allowGapCursor: (e = me(j(n, "allowGapCursor", t))) != null ? e : null
    };
  }
});
Oe.create({
  name: "placeholder",
  addOptions() {
    return {
      emptyEditorClass: "is-editor-empty",
      emptyNodeClass: "is-empty",
      placeholder: "Write something …",
      showOnlyWhenEditable: !0,
      showOnlyCurrent: !0,
      includeChildren: !1
    };
  },
  addProseMirrorPlugins() {
    return [
      new Te({
        key: new Ie("placeholder"),
        props: {
          decorations: ({ doc: n, selection: e }) => {
            const t = this.editor.isEditable || !this.options.showOnlyWhenEditable, { anchor: r } = e, i = [];
            if (!t)
              return null;
            const s = this.editor.isEmpty;
            return n.descendants((o, l) => {
              const a = r >= l && r <= l + o.nodeSize, u = !o.isLeaf && Ho(o);
              if ((a || !this.options.showOnlyCurrent) && u) {
                const c = [this.options.emptyNodeClass];
                s && c.push(this.options.emptyEditorClass);
                const d = nt.node(l, l + o.nodeSize, {
                  class: c.join(" "),
                  "data-placeholder": typeof this.options.placeholder == "function" ? this.options.placeholder({
                    editor: this.editor,
                    node: o,
                    pos: l,
                    hasAnchor: a
                  }) : this.options.placeholder
                });
                i.push(d);
              }
              return this.options.includeChildren;
            }), Ce.create(n, i);
          }
        }
      })
    ];
  }
});
Oe.create({
  name: "selection",
  addOptions() {
    return {
      className: "selection"
    };
  },
  addProseMirrorPlugins() {
    const { editor: n, options: e } = this;
    return [
      new Te({
        key: new Ie("selection"),
        props: {
          decorations(t) {
            return t.selection.empty || n.isFocused || !n.isEditable || rm(t.selection) || n.view.dragging ? null : Ce.create(t.doc, [
              nt.inline(t.selection.from, t.selection.to, {
                class: e.className
              })
            ]);
          }
        }
      })
    ];
  }
});
function hf({ types: n, node: e }) {
  return e && Array.isArray(n) && n.includes(e.type) || (e == null ? void 0 : e.type) === n;
}
var qS = Oe.create({
  name: "trailingNode",
  addOptions() {
    return {
      node: "paragraph",
      notAfter: []
    };
  },
  addProseMirrorPlugins() {
    const n = new Ie(this.name), e = Object.entries(this.editor.schema.nodes).map(([, t]) => t).filter((t) => (this.options.notAfter || []).concat(this.options.node).includes(t.name));
    return [
      new Te({
        key: n,
        appendTransaction: (t, r, i) => {
          const { doc: s, tr: o, schema: l } = i, a = n.getState(i), u = s.content.size, c = l.nodes[this.options.node];
          if (a)
            return o.insert(u, c.create());
        },
        state: {
          init: (t, r) => {
            const i = r.tr.doc.lastChild;
            return !hf({ node: i, types: e });
          },
          apply: (t, r) => {
            if (!t.docChanged)
              return r;
            const i = t.doc.lastChild;
            return !hf({ node: i, types: e });
          }
        }
      })
    ];
  }
}), jS = Oe.create({
  name: "undoRedo",
  addOptions() {
    return {
      depth: 100,
      newGroupDelay: 500
    };
  },
  addCommands() {
    return {
      undo: () => ({ state: n, dispatch: e }) => Um(n, e),
      redo: () => ({ state: n, dispatch: e }) => Wm(n, e)
    };
  },
  addProseMirrorPlugins() {
    return [BS(this.options)];
  },
  addKeyboardShortcuts() {
    return {
      "Mod-z": () => this.editor.commands.undo(),
      "Shift-Mod-z": () => this.editor.commands.redo(),
      "Mod-y": () => this.editor.commands.redo(),
      // Russian keyboard layouts
      "Mod-я": () => this.editor.commands.undo(),
      "Shift-Mod-я": () => this.editor.commands.redo()
    };
  }
}), VS = Oe.create({
  name: "starterKit",
  addExtensions() {
    var n, e, t, r;
    const i = [];
    return this.options.bold !== !1 && i.push(kE.configure(this.options.bold)), this.options.blockquote !== !1 && i.push(mE.configure(this.options.blockquote)), this.options.bulletList !== !1 && i.push(Nm.configure(this.options.bulletList)), this.options.code !== !1 && i.push(EE.configure(this.options.code)), this.options.codeBlock !== !1 && i.push(DE.configure(this.options.codeBlock)), this.options.document !== !1 && i.push(AE.configure(this.options.document)), this.options.dropcursor !== !1 && i.push(zS.configure(this.options.dropcursor)), this.options.gapcursor !== !1 && i.push(HS.configure(this.options.gapcursor)), this.options.hardBreak !== !1 && i.push(TE.configure(this.options.hardBreak)), this.options.heading !== !1 && i.push(xE.configure(this.options.heading)), this.options.undoRedo !== !1 && i.push(jS.configure(this.options.undoRedo)), this.options.horizontalRule !== !1 && i.push(ME.configure(this.options.horizontalRule)), this.options.italic !== !1 && i.push(RE.configure(this.options.italic)), this.options.listItem !== !1 && i.push(Rm.configure(this.options.listItem)), this.options.listKeymap !== !1 && i.push(Hm.configure((n = this.options) == null ? void 0 : n.listKeymap)), this.options.link !== !1 && i.push(Om.configure((e = this.options) == null ? void 0 : e.link)), this.options.orderedList !== !1 && i.push(qm.configure(this.options.orderedList)), this.options.paragraph !== !1 && i.push(gS.configure(this.options.paragraph)), this.options.strike !== !1 && i.push(bS.configure(this.options.strike)), this.options.text !== !1 && i.push(kS.configure(this.options.text)), this.options.underline !== !1 && i.push(vS.configure((t = this.options) == null ? void 0 : t.underline)), this.options.trailingNode !== !1 && i.push(qS.configure((r = this.options) == null ? void 0 : r.trailingNode)), i;
  }
}), US = VS, WS = /(?:^|\s)(!\[(.+|:?)]\((\S+)(?:(?:\s+)["'](\S+)["'])?\))$/, KS = ft.create({
  name: "image",
  addOptions() {
    return {
      inline: !1,
      allowBase64: !1,
      HTMLAttributes: {}
    };
  },
  inline() {
    return this.options.inline;
  },
  group() {
    return this.options.inline ? "inline" : "block";
  },
  draggable: !0,
  addAttributes() {
    return {
      src: {
        default: null
      },
      alt: {
        default: null
      },
      title: {
        default: null
      },
      width: {
        default: null
      },
      height: {
        default: null
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: this.options.allowBase64 ? "img[src]" : 'img[src]:not([src^="data:"])'
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["img", Fe(this.options.HTMLAttributes, n)];
  },
  addCommands() {
    return {
      setImage: (n) => ({ commands: e }) => e.insertContent({
        type: this.name,
        attrs: n
      })
    };
  },
  addInputRules() {
    return [
      vm({
        find: WS,
        type: this.type,
        getAttributes: (n) => {
          const [, , e, t, r] = n;
          return { src: t, alt: e, title: r };
        }
      })
    ];
  }
}), GS = KS, JS = ({ key: n, editor: e, onPaste: t, onDrop: r, allowedMimeTypes: i }) => new Te({
  key: n || new Ie("fileHandler"),
  props: {
    handleDrop(s, o) {
      var l;
      if (!r || !((l = o.dataTransfer) != null && l.files.length))
        return !1;
      const a = s.posAtCoords({
        left: o.clientX,
        top: o.clientY
      });
      let u = Array.from(o.dataTransfer.files);
      return i && (u = u.filter((c) => i.includes(c.type))), u.length === 0 ? !1 : (o.preventDefault(), o.stopPropagation(), r(e, u, (a == null ? void 0 : a.pos) || 0), !0);
    },
    handlePaste(s, o) {
      var l;
      if (!t || !((l = o.clipboardData) != null && l.files.length))
        return !1;
      let a = Array.from(o.clipboardData.files);
      const u = o.clipboardData.getData("text/html");
      return i && (a = a.filter((c) => i.includes(c.type))), !(a.length === 0 || (o.preventDefault(), o.stopPropagation(), t(e, a, u), u.length > 0));
    }
  }
}), YS = Oe.create({
  name: "fileHandler",
  addOptions() {
    return {
      onPaste: void 0,
      onDrop: void 0,
      allowedMimeTypes: void 0
    };
  },
  addProseMirrorPlugins() {
    return [
      JS({
        key: new Ie(this.name),
        editor: this.editor,
        allowedMimeTypes: this.options.allowedMimeTypes,
        onDrop: this.options.onDrop,
        onPaste: this.options.onPaste
      })
    ];
  }
}), XS = YS;
const {
  SvelteComponent: ZS,
  append_hydration: pf,
  assign: QS,
  attr: mf,
  binding_callbacks: eC,
  check_outros: tC,
  children: gf,
  claim_component: yu,
  claim_element: _f,
  claim_space: yf,
  claim_text: nC,
  create_component: bu,
  destroy_component: ku,
  detach: mi,
  element: bf,
  flush: vt,
  get_spread_object: rC,
  get_spread_update: iC,
  group_outros: sC,
  init: oC,
  insert_hydration: Sa,
  mount_component: vu,
  safe_not_equal: lC,
  set_data: aC,
  space: kf,
  text: uC,
  transition_in: Lr,
  transition_out: $i
} = window.__gradio__svelte__internal, { onMount: cC, onDestroy: dC } = window.__gradio__svelte__internal;
function vf(n) {
  let e, t;
  const r = [
    { autoscroll: (
      /*gradio*/
      n[0].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      n[0].i18n
    ) },
    /*loading_status*/
    n[8]
  ];
  let i = {};
  for (let s = 0; s < r.length; s += 1)
    i = QS(i, r[s]);
  return e = new Wy({ props: i }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    n[14]
  ), {
    c() {
      bu(e.$$.fragment);
    },
    l(s) {
      yu(e.$$.fragment, s);
    },
    m(s, o) {
      vu(e, s, o), t = !0;
    },
    p(s, o) {
      const l = o & /*gradio, loading_status*/
      257 ? iC(r, [
        o & /*gradio*/
        1 && { autoscroll: (
          /*gradio*/
          s[0].autoscroll
        ) },
        o & /*gradio*/
        1 && { i18n: (
          /*gradio*/
          s[0].i18n
        ) },
        o & /*loading_status*/
        256 && rC(
          /*loading_status*/
          s[8]
        )
      ]) : {};
      e.$set(l);
    },
    i(s) {
      t || (Lr(e.$$.fragment, s), t = !0);
    },
    o(s) {
      $i(e.$$.fragment, s), t = !1;
    },
    d(s) {
      ku(e, s);
    }
  };
}
function fC(n) {
  let e;
  return {
    c() {
      e = uC(
        /*label*/
        n[1]
      );
    },
    l(t) {
      e = nC(
        t,
        /*label*/
        n[1]
      );
    },
    m(t, r) {
      Sa(t, e, r);
    },
    p(t, r) {
      r & /*label*/
      2 && aC(
        e,
        /*label*/
        t[1]
      );
    },
    d(t) {
      t && mi(e);
    }
  };
}
function hC(n) {
  let e, t, r, i, s, o, l = (
    /*loading_status*/
    n[8] && vf(n)
  );
  return r = new B0({
    props: {
      show_label: (
        /*show_label*/
        n[5]
      ),
      info: void 0,
      $$slots: { default: [fC] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      l && l.c(), e = kf(), t = bf("div"), bu(r.$$.fragment), i = kf(), s = bf("div"), this.h();
    },
    l(a) {
      l && l.l(a), e = yf(a), t = _f(a, "DIV", { class: !0 });
      var u = gf(t);
      yu(r.$$.fragment, u), i = yf(u), s = _f(u, "DIV", { class: !0 }), gf(s).forEach(mi), u.forEach(mi), this.h();
    },
    h() {
      mf(s, "class", "editor scroll-hide svelte-112w9nn"), mf(t, "class", "container svelte-112w9nn");
    },
    m(a, u) {
      l && l.m(a, u), Sa(a, e, u), Sa(a, t, u), vu(r, t, null), pf(t, i), pf(t, s), n[15](s), o = !0;
    },
    p(a, u) {
      /*loading_status*/
      a[8] ? l ? (l.p(a, u), u & /*loading_status*/
      256 && Lr(l, 1)) : (l = vf(a), l.c(), Lr(l, 1), l.m(e.parentNode, e)) : l && (sC(), $i(l, 1, 1, () => {
        l = null;
      }), tC());
      const c = {};
      u & /*show_label*/
      32 && (c.show_label = /*show_label*/
      a[5]), u & /*$$scope, label*/
      131074 && (c.$$scope = { dirty: u, ctx: a }), r.$set(c);
    },
    i(a) {
      o || (Lr(l), Lr(r.$$.fragment, a), o = !0);
    },
    o(a) {
      $i(l), $i(r.$$.fragment, a), o = !1;
    },
    d(a) {
      a && (mi(e), mi(t)), l && l.d(a), ku(r), n[15](null);
    }
  };
}
function pC(n) {
  let e, t;
  return e = new hg({
    props: {
      visible: (
        /*visible*/
        n[4]
      ),
      elem_id: (
        /*elem_id*/
        n[2]
      ),
      elem_classes: (
        /*elem_classes*/
        n[3]
      ),
      scale: (
        /*scale*/
        n[6]
      ),
      min_width: (
        /*min_width*/
        n[7]
      ),
      allow_overflow: !1,
      padding: !0,
      $$slots: { default: [hC] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      bu(e.$$.fragment);
    },
    l(r) {
      yu(e.$$.fragment, r);
    },
    m(r, i) {
      vu(e, r, i), t = !0;
    },
    p(r, [i]) {
      const s = {};
      i & /*visible*/
      16 && (s.visible = /*visible*/
      r[4]), i & /*elem_id*/
      4 && (s.elem_id = /*elem_id*/
      r[2]), i & /*elem_classes*/
      8 && (s.elem_classes = /*elem_classes*/
      r[3]), i & /*scale*/
      64 && (s.scale = /*scale*/
      r[6]), i & /*min_width*/
      128 && (s.min_width = /*min_width*/
      r[7]), i & /*$$scope, element, show_label, label, gradio, loading_status*/
      131875 && (s.$$scope = { dirty: i, ctx: r }), e.$set(s);
    },
    i(r) {
      t || (Lr(e.$$.fragment, r), t = !0);
    },
    o(r) {
      $i(e.$$.fragment, r), t = !1;
    },
    d(r) {
      ku(e, r);
    }
  };
}
function mC(n, e, t) {
  let { gradio: r } = e, { label: i = "Textbox" } = e, { elem_id: s = "" } = e, { elem_classes: o = [] } = e, { visible: l = !0 } = e, { value: a = "" } = e, { show_label: u } = e, { scale: c = null } = e, { min_width: d = void 0 } = e, { loading_status: f = void 0 } = e, { value_is_output: h = !1 } = e, { interactive: p } = e, g, _;
  const k = [
    US.configure({
      bulletList: { keepMarks: !0, keepAttributes: !1 },
      orderedList: { keepMarks: !0, keepAttributes: !1 },
      codeBlock: !1,
      link: !1,
      hardBreak: { keepMarks: !1 }
    }),
    GS.extend({
      renderHTML({ HTMLAttributes: v }) {
        return ["div", { class: "resizable-image-container" }, ["img", v]];
      }
    }).configure({ inline: !0, allowBase64: !0 }),
    XS.configure({
      allowedMimeTypes: ["image/*"],
      onDrop(v, S) {
        return S.forEach((D) => {
          const T = new FileReader();
          T.onload = () => v.commands.setImage({ src: T.result, alt: D.name }), T.readAsDataURL(D);
        }), !0;
      }
    }),
    oS.configure({
      openOnClick: !1,
      defaultProtocol: "https"
    }).extend({
      addKeyboardShortcuts() {
        return {
          "Mod-k": () => {
            var v;
            const S = (v = prompt("Enter URL")) !== null && v !== void 0 ? v : "";
            if (S) {
              const D = S.match(/^https?:\/\//) ? S : `https://${S}`;
              this.editor.chain().focus().setLink({ href: D }).setTextSelection(this.editor.state.selection.to).unsetMark("link").run();
            } else
              this.editor.commands.unsetLink();
            return !0;
          }
        };
      }
    })
  ];
  cC(() => {
    t(13, _ = new nE({
      element: g,
      extensions: k,
      content: a,
      editable: p,
      onUpdate: ({ editor: v }) => {
        t(10, a = Zd({ content: v.getJSON(), extensions: k })), r.dispatch("change"), h || r.dispatch("input");
      }
    }));
  }), dC(() => {
    _ && _.destroy();
  });
  const b = () => r.dispatch("clear_status", f);
  function y(v) {
    eC[v ? "unshift" : "push"](() => {
      g = v, t(9, g);
    });
  }
  return n.$$set = (v) => {
    "gradio" in v && t(0, r = v.gradio), "label" in v && t(1, i = v.label), "elem_id" in v && t(2, s = v.elem_id), "elem_classes" in v && t(3, o = v.elem_classes), "visible" in v && t(4, l = v.visible), "value" in v && t(10, a = v.value), "show_label" in v && t(5, u = v.show_label), "scale" in v && t(6, c = v.scale), "min_width" in v && t(7, d = v.min_width), "loading_status" in v && t(8, f = v.loading_status), "value_is_output" in v && t(11, h = v.value_is_output), "interactive" in v && t(12, p = v.interactive);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1024 && a === null && t(10, a = ""), n.$$.dirty & /*editor, value*/
    9216 && _ && a !== Zd({ content: _.getJSON(), extensions: k }) && _.commands.setContent(a), n.$$.dirty & /*editor, interactive*/
    12288 && _ && _.setEditable(p);
  }, [
    r,
    i,
    s,
    o,
    l,
    u,
    c,
    d,
    f,
    g,
    a,
    h,
    p,
    _,
    b,
    y
  ];
}
class B9 extends ZS {
  constructor(e) {
    super(), oC(this, e, mC, pC, lC, {
      gradio: 0,
      label: 1,
      elem_id: 2,
      elem_classes: 3,
      visible: 4,
      value: 10,
      show_label: 5,
      scale: 6,
      min_width: 7,
      loading_status: 8,
      value_is_output: 11,
      interactive: 12
    });
  }
  get gradio() {
    return this.$$.ctx[0];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), vt();
  }
  get label() {
    return this.$$.ctx[1];
  }
  set label(e) {
    this.$$set({ label: e }), vt();
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), vt();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), vt();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), vt();
  }
  get value() {
    return this.$$.ctx[10];
  }
  set value(e) {
    this.$$set({ value: e }), vt();
  }
  get show_label() {
    return this.$$.ctx[5];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), vt();
  }
  get scale() {
    return this.$$.ctx[6];
  }
  set scale(e) {
    this.$$set({ scale: e }), vt();
  }
  get min_width() {
    return this.$$.ctx[7];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), vt();
  }
  get loading_status() {
    return this.$$.ctx[8];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), vt();
  }
  get value_is_output() {
    return this.$$.ctx[11];
  }
  set value_is_output(e) {
    this.$$set({ value_is_output: e }), vt();
  }
  get interactive() {
    return this.$$.ctx[12];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), vt();
  }
}
export {
  B9 as I,
  Gu as c,
  _C as g,
  g5 as p
};
