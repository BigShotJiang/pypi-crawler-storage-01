import { b as r } from "./_baseUniq-CUl4l5hY.js";
var e = 4;
function a(o) {
  return r(o, e);
}
export {
  a as c
};
