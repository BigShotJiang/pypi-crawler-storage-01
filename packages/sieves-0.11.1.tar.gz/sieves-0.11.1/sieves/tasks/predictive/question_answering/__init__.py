"""Classification task."""

from .core import FewshotExample, QuestionAnswering

__all__ = ["QuestionAnswering", "FewshotExample"]
