"""Classification task."""

from .core import Classification, FewshotExampleMultiLabel, FewshotExampleSingleLabel

__all__ = ["Classification", "FewshotExampleMultiLabel", "FewshotExampleSingleLabel"]
