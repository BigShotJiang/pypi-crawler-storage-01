# Marker

::: sieves.tasks.preprocessing.ocr.core