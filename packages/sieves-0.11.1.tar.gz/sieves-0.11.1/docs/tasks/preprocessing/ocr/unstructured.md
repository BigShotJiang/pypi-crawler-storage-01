# unstructured

::: sieves.tasks.preprocessing.ocr.unstructured_