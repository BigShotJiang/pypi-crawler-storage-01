# Marker

::: sieves.tasks.preprocessing.ocr.marker_