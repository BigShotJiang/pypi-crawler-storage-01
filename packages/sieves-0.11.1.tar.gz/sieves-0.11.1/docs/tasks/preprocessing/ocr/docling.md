# Docling

::: sieves.tasks.preprocessing.ocr.docling_