
def main():
    print("--------------------------------")
    print("--                            --")
    print("--  maix test hardware start  --")
    print("--                            --")
    print("--------------------------------")

    print(" TODO: ")

    print("--------------------------------")
    print("--                            --")
    print("--   maix test hardware end   --")
    print("--                            --")
    print("--------------------------------")


if __name__ == "__main__":
    main()


