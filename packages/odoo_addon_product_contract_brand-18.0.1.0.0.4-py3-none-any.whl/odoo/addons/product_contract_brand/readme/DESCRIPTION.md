This addon propagate the brand from sale order to contract.
