import { a as Wn, d as pt, b as mt } from "./index-BKhIZPjl.js";
import { p as G, r as Bn, s as sn, f as O, n as fn, b as wn, c as ft } from "./blank-line-C74Di3OL.js";
import { e as nn, d as v, f as En, g as gt, b as _, h as xt, i as kt, j as Tn, c as w, m as $ } from "./index-Cu1EQZGJ.js";
import { c as Nn } from "./index-zPv55tna.js";
import { s as yn } from "./index-eimp3Ck2.js";
import { t as dt } from "./index-Dzq2w4iB.js";
const Fn = {
  name: "attention",
  resolveAll: bt,
  tokenize: St
};
function bt(n, r) {
  let e = -1, t, a, i, u, s, f, h, m;
  for (; ++e < n.length; )
    if (n[e][0] === "enter" && n[e][1].type === "attentionSequence" && n[e][1]._close) {
      for (t = e; t--; )
        if (n[t][0] === "exit" && n[t][1].type === "attentionSequence" && n[t][1]._open && // If the markers are the same:
        r.sliceSerialize(n[t][1]).charCodeAt(0) === r.sliceSerialize(n[e][1]).charCodeAt(0)) {
          if ((n[t][1]._close || n[e][1]._open) && (n[e][1].end.offset - n[e][1].start.offset) % 3 && !((n[t][1].end.offset - n[t][1].start.offset + n[e][1].end.offset - n[e][1].start.offset) % 3))
            continue;
          f = n[t][1].end.offset - n[t][1].start.offset > 1 && n[e][1].end.offset - n[e][1].start.offset > 1 ? 2 : 1;
          const p = {
            ...n[t][1].end
          }, g = {
            ...n[e][1].start
          };
          Dn(p, -f), Dn(g, f), u = {
            type: f > 1 ? "strongSequence" : "emphasisSequence",
            start: p,
            end: {
              ...n[t][1].end
            }
          }, s = {
            type: f > 1 ? "strongSequence" : "emphasisSequence",
            start: {
              ...n[e][1].start
            },
            end: g
          }, i = {
            type: f > 1 ? "strongText" : "emphasisText",
            start: {
              ...n[t][1].end
            },
            end: {
              ...n[e][1].start
            }
          }, a = {
            type: f > 1 ? "strong" : "emphasis",
            start: {
              ...u.start
            },
            end: {
              ...s.end
            }
          }, n[t][1].end = {
            ...u.start
          }, n[e][1].start = {
            ...s.end
          }, h = [], n[t][1].end.offset - n[t][1].start.offset && (h = G(h, [["enter", n[t][1], r], ["exit", n[t][1], r]])), h = G(h, [["enter", a, r], ["enter", u, r], ["exit", u, r], ["enter", i, r]]), h = G(h, Bn(r.parser.constructs.insideSpan.null, n.slice(t + 1, e), r)), h = G(h, [["exit", i, r], ["enter", s, r], ["exit", s, r], ["exit", a, r]]), n[e][1].end.offset - n[e][1].start.offset ? (m = 2, h = G(h, [["enter", n[e][1], r], ["exit", n[e][1], r]])) : m = 0, sn(n, t - 1, e - t + 3, h), e = t + h.length - m - 2;
          break;
        }
    }
  for (e = -1; ++e < n.length; )
    n[e][1].type === "attentionSequence" && (n[e][1].type = "data");
  return n;
}
function St(n, r) {
  const e = this.parser.constructs.attentionMarkers.null, t = this.previous, a = Nn(t);
  let i;
  return u;
  function u(f) {
    return i = f, n.enter("attentionSequence"), s(f);
  }
  function s(f) {
    if (f === i)
      return n.consume(f), s;
    const h = n.exit("attentionSequence"), m = Nn(f), p = !m || m === 2 && a || e.includes(f), g = !a || a === 2 && m || e.includes(t);
    return h._open = !!(i === 42 ? p : p && (a || !g)), h._close = !!(i === 42 ? g : g && (m || !p)), r(f);
  }
}
function Dn(n, r) {
  n.column += r, n.offset += r, n._bufferIndex += r;
}
const yt = {
  name: "autolink",
  tokenize: It
};
function It(n, r, e) {
  let t = 0;
  return a;
  function a(c) {
    return n.enter("autolink"), n.enter("autolinkMarker"), n.consume(c), n.exit("autolinkMarker"), n.enter("autolinkProtocol"), i;
  }
  function i(c) {
    return nn(c) ? (n.consume(c), u) : c === 64 ? e(c) : h(c);
  }
  function u(c) {
    return c === 43 || c === 45 || c === 46 || v(c) ? (t = 1, s(c)) : h(c);
  }
  function s(c) {
    return c === 58 ? (n.consume(c), t = 0, f) : (c === 43 || c === 45 || c === 46 || v(c)) && t++ < 32 ? (n.consume(c), s) : (t = 0, h(c));
  }
  function f(c) {
    return c === 62 ? (n.exit("autolinkProtocol"), n.enter("autolinkMarker"), n.consume(c), n.exit("autolinkMarker"), n.exit("autolink"), r) : c === null || c === 32 || c === 60 || En(c) ? e(c) : (n.consume(c), f);
  }
  function h(c) {
    return c === 64 ? (n.consume(c), m) : gt(c) ? (n.consume(c), h) : e(c);
  }
  function m(c) {
    return v(c) ? p(c) : e(c);
  }
  function p(c) {
    return c === 46 ? (n.consume(c), t = 0, m) : c === 62 ? (n.exit("autolinkProtocol").type = "autolinkEmail", n.enter("autolinkMarker"), n.consume(c), n.exit("autolinkMarker"), n.exit("autolink"), r) : g(c);
  }
  function g(c) {
    if ((c === 45 || v(c)) && t++ < 63) {
      const T = c === 45 ? g : p;
      return n.consume(c), T;
    }
    return e(c);
  }
}
const Yn = {
  continuation: {
    tokenize: zt
  },
  exit: Ct,
  name: "blockQuote",
  tokenize: wt
};
function wt(n, r, e) {
  const t = this;
  return a;
  function a(u) {
    if (u === 62) {
      const s = t.containerState;
      return s.open || (n.enter("blockQuote", {
        _container: !0
      }), s.open = !0), n.enter("blockQuotePrefix"), n.enter("blockQuoteMarker"), n.consume(u), n.exit("blockQuoteMarker"), i;
    }
    return e(u);
  }
  function i(u) {
    return _(u) ? (n.enter("blockQuotePrefixWhitespace"), n.consume(u), n.exit("blockQuotePrefixWhitespace"), n.exit("blockQuotePrefix"), r) : (n.exit("blockQuotePrefix"), r(u));
  }
}
function zt(n, r, e) {
  const t = this;
  return a;
  function a(u) {
    return _(u) ? O(n, i, "linePrefix", t.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(u) : i(u);
  }
  function i(u) {
    return n.attempt(Yn, r, e)(u);
  }
}
function Ct(n) {
  n.exit("blockQuote");
}
const $n = {
  name: "characterEscape",
  tokenize: Et
};
function Et(n, r, e) {
  return t;
  function t(i) {
    return n.enter("characterEscape"), n.enter("escapeMarker"), n.consume(i), n.exit("escapeMarker"), a;
  }
  function a(i) {
    return xt(i) ? (n.enter("characterEscapeValue"), n.consume(i), n.exit("characterEscapeValue"), n.exit("characterEscape"), r) : e(i);
  }
}
const Gn = {
  name: "characterReference",
  tokenize: Tt
};
function Tt(n, r, e) {
  const t = this;
  let a = 0, i, u;
  return s;
  function s(p) {
    return n.enter("characterReference"), n.enter("characterReferenceMarker"), n.consume(p), n.exit("characterReferenceMarker"), f;
  }
  function f(p) {
    return p === 35 ? (n.enter("characterReferenceMarkerNumeric"), n.consume(p), n.exit("characterReferenceMarkerNumeric"), h) : (n.enter("characterReferenceValue"), i = 31, u = v, m(p));
  }
  function h(p) {
    return p === 88 || p === 120 ? (n.enter("characterReferenceMarkerHexadecimal"), n.consume(p), n.exit("characterReferenceMarkerHexadecimal"), n.enter("characterReferenceValue"), i = 6, u = kt, m) : (n.enter("characterReferenceValue"), i = 7, u = Tn, m(p));
  }
  function m(p) {
    if (p === 59 && a) {
      const g = n.exit("characterReferenceValue");
      return u === v && !Wn(t.sliceSerialize(g)) ? e(p) : (n.enter("characterReferenceMarker"), n.consume(p), n.exit("characterReferenceMarker"), n.exit("characterReference"), r);
    }
    return u(p) && a++ < i ? (n.consume(p), m) : e(p);
  }
}
const qn = {
  partial: !0,
  tokenize: Bt
}, Rn = {
  concrete: !0,
  name: "codeFenced",
  tokenize: Ft
};
function Ft(n, r, e) {
  const t = this, a = {
    partial: !0,
    tokenize: D
  };
  let i = 0, u = 0, s;
  return f;
  function f(k) {
    return h(k);
  }
  function h(k) {
    const B = t.events[t.events.length - 1];
    return i = B && B[1].type === "linePrefix" ? B[2].sliceSerialize(B[1], !0).length : 0, s = k, n.enter("codeFenced"), n.enter("codeFencedFence"), n.enter("codeFencedFenceSequence"), m(k);
  }
  function m(k) {
    return k === s ? (u++, n.consume(k), m) : u < 3 ? e(k) : (n.exit("codeFencedFenceSequence"), _(k) ? O(n, p, "whitespace")(k) : p(k));
  }
  function p(k) {
    return k === null || w(k) ? (n.exit("codeFencedFence"), t.interrupt ? r(k) : n.check(qn, F, M)(k)) : (n.enter("codeFencedFenceInfo"), n.enter("chunkString", {
      contentType: "string"
    }), g(k));
  }
  function g(k) {
    return k === null || w(k) ? (n.exit("chunkString"), n.exit("codeFencedFenceInfo"), p(k)) : _(k) ? (n.exit("chunkString"), n.exit("codeFencedFenceInfo"), O(n, c, "whitespace")(k)) : k === 96 && k === s ? e(k) : (n.consume(k), g);
  }
  function c(k) {
    return k === null || w(k) ? p(k) : (n.enter("codeFencedFenceMeta"), n.enter("chunkString", {
      contentType: "string"
    }), T(k));
  }
  function T(k) {
    return k === null || w(k) ? (n.exit("chunkString"), n.exit("codeFencedFenceMeta"), p(k)) : k === 96 && k === s ? e(k) : (n.consume(k), T);
  }
  function F(k) {
    return n.attempt(a, M, q)(k);
  }
  function q(k) {
    return n.enter("lineEnding"), n.consume(k), n.exit("lineEnding"), b;
  }
  function b(k) {
    return i > 0 && _(k) ? O(n, R, "linePrefix", i + 1)(k) : R(k);
  }
  function R(k) {
    return k === null || w(k) ? n.check(qn, F, M)(k) : (n.enter("codeFlowValue"), S(k));
  }
  function S(k) {
    return k === null || w(k) ? (n.exit("codeFlowValue"), R(k)) : (n.consume(k), S);
  }
  function M(k) {
    return n.exit("codeFenced"), r(k);
  }
  function D(k, B, H) {
    let P = 0;
    return L;
    function L(E) {
      return k.enter("lineEnding"), k.consume(E), k.exit("lineEnding"), I;
    }
    function I(E) {
      return k.enter("codeFencedFence"), _(E) ? O(k, y, "linePrefix", t.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(E) : y(E);
    }
    function y(E) {
      return E === s ? (k.enter("codeFencedFenceSequence"), N(E)) : H(E);
    }
    function N(E) {
      return E === s ? (P++, k.consume(E), N) : P >= u ? (k.exit("codeFencedFenceSequence"), _(E) ? O(k, V, "whitespace")(E) : V(E)) : H(E);
    }
    function V(E) {
      return E === null || w(E) ? (k.exit("codeFencedFence"), B(E)) : H(E);
    }
  }
}
function Bt(n, r, e) {
  const t = this;
  return a;
  function a(u) {
    return u === null ? e(u) : (n.enter("lineEnding"), n.consume(u), n.exit("lineEnding"), i);
  }
  function i(u) {
    return t.parser.lazy[t.now().line] ? e(u) : r(u);
  }
}
const zn = {
  name: "codeIndented",
  tokenize: Pt
}, _t = {
  partial: !0,
  tokenize: At
};
function Pt(n, r, e) {
  const t = this;
  return a;
  function a(h) {
    return n.enter("codeIndented"), O(n, i, "linePrefix", 5)(h);
  }
  function i(h) {
    const m = t.events[t.events.length - 1];
    return m && m[1].type === "linePrefix" && m[2].sliceSerialize(m[1], !0).length >= 4 ? u(h) : e(h);
  }
  function u(h) {
    return h === null ? f(h) : w(h) ? n.attempt(_t, u, f)(h) : (n.enter("codeFlowValue"), s(h));
  }
  function s(h) {
    return h === null || w(h) ? (n.exit("codeFlowValue"), u(h)) : (n.consume(h), s);
  }
  function f(h) {
    return n.exit("codeIndented"), r(h);
  }
}
function At(n, r, e) {
  const t = this;
  return a;
  function a(u) {
    return t.parser.lazy[t.now().line] ? e(u) : w(u) ? (n.enter("lineEnding"), n.consume(u), n.exit("lineEnding"), a) : O(n, i, "linePrefix", 5)(u);
  }
  function i(u) {
    const s = t.events[t.events.length - 1];
    return s && s[1].type === "linePrefix" && s[2].sliceSerialize(s[1], !0).length >= 4 ? r(u) : w(u) ? a(u) : e(u);
  }
}
const Lt = {
  name: "codeText",
  previous: Mt,
  resolve: Ot,
  tokenize: Nt
};
function Ot(n) {
  let r = n.length - 4, e = 3, t, a;
  if ((n[e][1].type === "lineEnding" || n[e][1].type === "space") && (n[r][1].type === "lineEnding" || n[r][1].type === "space")) {
    for (t = e; ++t < r; )
      if (n[t][1].type === "codeTextData") {
        n[e][1].type = "codeTextPadding", n[r][1].type = "codeTextPadding", e += 2, r -= 2;
        break;
      }
  }
  for (t = e - 1, r++; ++t <= r; )
    a === void 0 ? t !== r && n[t][1].type !== "lineEnding" && (a = t) : (t === r || n[t][1].type === "lineEnding") && (n[a][1].type = "codeTextData", t !== a + 2 && (n[a][1].end = n[t - 1][1].end, n.splice(a + 2, t - a - 2), r -= t - a - 2, t = a + 2), a = void 0);
  return n;
}
function Mt(n) {
  return n !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function Nt(n, r, e) {
  let t = 0, a, i;
  return u;
  function u(p) {
    return n.enter("codeText"), n.enter("codeTextSequence"), s(p);
  }
  function s(p) {
    return p === 96 ? (n.consume(p), t++, s) : (n.exit("codeTextSequence"), f(p));
  }
  function f(p) {
    return p === null ? e(p) : p === 32 ? (n.enter("space"), n.consume(p), n.exit("space"), f) : p === 96 ? (i = n.enter("codeTextSequence"), a = 0, m(p)) : w(p) ? (n.enter("lineEnding"), n.consume(p), n.exit("lineEnding"), f) : (n.enter("codeTextData"), h(p));
  }
  function h(p) {
    return p === null || p === 32 || p === 96 || w(p) ? (n.exit("codeTextData"), f(p)) : (n.consume(p), h);
  }
  function m(p) {
    return p === 96 ? (n.consume(p), a++, m) : a === t ? (n.exit("codeTextSequence"), n.exit("codeText"), r(p)) : (i.type = "codeTextData", h(p));
  }
}
class Dt {
  /**
   * @param {ReadonlyArray<T> | null | undefined} [initial]
   *   Initial items (optional).
   * @returns
   *   Splice buffer.
   */
  constructor(r) {
    this.left = r ? [...r] : [], this.right = [];
  }
  /**
   * Array access;
   * does not move the cursor.
   *
   * @param {number} index
   *   Index.
   * @return {T}
   *   Item.
   */
  get(r) {
    if (r < 0 || r >= this.left.length + this.right.length)
      throw new RangeError("Cannot access index `" + r + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
    return r < this.left.length ? this.left[r] : this.right[this.right.length - r + this.left.length - 1];
  }
  /**
   * The length of the splice buffer, one greater than the largest index in the
   * array.
   */
  get length() {
    return this.left.length + this.right.length;
  }
  /**
   * Remove and return `list[0]`;
   * moves the cursor to `0`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  shift() {
    return this.setCursor(0), this.right.pop();
  }
  /**
   * Slice the buffer to get an array;
   * does not move the cursor.
   *
   * @param {number} start
   *   Start.
   * @param {number | null | undefined} [end]
   *   End (optional).
   * @returns {Array<T>}
   *   Array of items.
   */
  slice(r, e) {
    const t = e ?? Number.POSITIVE_INFINITY;
    return t < this.left.length ? this.left.slice(r, t) : r > this.left.length ? this.right.slice(this.right.length - t + this.left.length, this.right.length - r + this.left.length).reverse() : this.left.slice(r).concat(this.right.slice(this.right.length - t + this.left.length).reverse());
  }
  /**
   * Mimics the behavior of Array.prototype.splice() except for the change of
   * interface necessary to avoid segfaults when patching in very large arrays.
   *
   * This operation moves cursor is moved to `start` and results in the cursor
   * placed after any inserted items.
   *
   * @param {number} start
   *   Start;
   *   zero-based index at which to start changing the array;
   *   negative numbers count backwards from the end of the array and values
   *   that are out-of bounds are clamped to the appropriate end of the array.
   * @param {number | null | undefined} [deleteCount=0]
   *   Delete count (default: `0`);
   *   maximum number of elements to delete, starting from start.
   * @param {Array<T> | null | undefined} [items=[]]
   *   Items to include in place of the deleted items (default: `[]`).
   * @return {Array<T>}
   *   Any removed items.
   */
  splice(r, e, t) {
    const a = e || 0;
    this.setCursor(Math.trunc(r));
    const i = this.right.splice(this.right.length - a, Number.POSITIVE_INFINITY);
    return t && dn(this.left, t), i.reverse();
  }
  /**
   * Remove and return the highest-numbered item in the array, so
   * `list[list.length - 1]`;
   * Moves the cursor to `length`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  pop() {
    return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop();
  }
  /**
   * Inserts a single item to the high-numbered side of the array;
   * moves the cursor to `length`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  push(r) {
    this.setCursor(Number.POSITIVE_INFINITY), this.left.push(r);
  }
  /**
   * Inserts many items to the high-numbered side of the array.
   * Moves the cursor to `length`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  pushMany(r) {
    this.setCursor(Number.POSITIVE_INFINITY), dn(this.left, r);
  }
  /**
   * Inserts a single item to the low-numbered side of the array;
   * Moves the cursor to `0`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  unshift(r) {
    this.setCursor(0), this.right.push(r);
  }
  /**
   * Inserts many items to the low-numbered side of the array;
   * moves the cursor to `0`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  unshiftMany(r) {
    this.setCursor(0), dn(this.right, r.reverse());
  }
  /**
   * Move the cursor to a specific position in the array. Requires
   * time proportional to the distance moved.
   *
   * If `n < 0`, the cursor will end up at the beginning.
   * If `n > length`, the cursor will end up at the end.
   *
   * @param {number} n
   *   Position.
   * @return {undefined}
   *   Nothing.
   */
  setCursor(r) {
    if (!(r === this.left.length || r > this.left.length && this.right.length === 0 || r < 0 && this.left.length === 0))
      if (r < this.left.length) {
        const e = this.left.splice(r, Number.POSITIVE_INFINITY);
        dn(this.right, e.reverse());
      } else {
        const e = this.right.splice(this.left.length + this.right.length - r, Number.POSITIVE_INFINITY);
        dn(this.left, e.reverse());
      }
  }
}
function dn(n, r) {
  let e = 0;
  if (r.length < 1e4)
    n.push(...r);
  else
    for (; e < r.length; )
      n.push(...r.slice(e, e + 1e4)), e += 1e4;
}
function Jn(n) {
  const r = {};
  let e = -1, t, a, i, u, s, f, h;
  const m = new Dt(n);
  for (; ++e < m.length; ) {
    for (; e in r; )
      e = r[e];
    if (t = m.get(e), e && t[1].type === "chunkFlow" && m.get(e - 1)[1].type === "listItemPrefix" && (f = t[1]._tokenizer.events, i = 0, i < f.length && f[i][1].type === "lineEndingBlank" && (i += 2), i < f.length && f[i][1].type === "content"))
      for (; ++i < f.length && f[i][1].type !== "content"; )
        f[i][1].type === "chunkText" && (f[i][1]._isInFirstContentOfListItem = !0, i++);
    if (t[0] === "enter")
      t[1].contentType && (Object.assign(r, qt(m, e)), e = r[e], h = !0);
    else if (t[1]._container) {
      for (i = e, a = void 0; i--; )
        if (u = m.get(i), u[1].type === "lineEnding" || u[1].type === "lineEndingBlank")
          u[0] === "enter" && (a && (m.get(a)[1].type = "lineEndingBlank"), u[1].type = "lineEnding", a = i);
        else if (!(u[1].type === "linePrefix" || u[1].type === "listItemIndent")) break;
      a && (t[1].end = {
        ...m.get(a)[1].start
      }, s = m.slice(a, e), s.unshift(t), m.splice(a, e - a + 1, s));
    }
  }
  return sn(n, 0, Number.POSITIVE_INFINITY, m.slice(0)), !h;
}
function qt(n, r) {
  const e = n.get(r)[1], t = n.get(r)[2];
  let a = r - 1;
  const i = [];
  let u = e._tokenizer;
  u || (u = t.parser[e.contentType](e.start), e._contentTypeTextTrailing && (u._contentTypeTextTrailing = !0));
  const s = u.events, f = [], h = {};
  let m, p, g = -1, c = e, T = 0, F = 0;
  const q = [F];
  for (; c; ) {
    for (; n.get(++a)[1] !== c; )
      ;
    i.push(a), c._tokenizer || (m = t.sliceStream(c), c.next || m.push(null), p && u.defineSkip(c.start), c._isInFirstContentOfListItem && (u._gfmTasklistFirstContentOfListItem = !0), u.write(m), c._isInFirstContentOfListItem && (u._gfmTasklistFirstContentOfListItem = void 0)), p = c, c = c.next;
  }
  for (c = e; ++g < s.length; )
    // Find a void token that includes a break.
    s[g][0] === "exit" && s[g - 1][0] === "enter" && s[g][1].type === s[g - 1][1].type && s[g][1].start.line !== s[g][1].end.line && (F = g + 1, q.push(F), c._tokenizer = void 0, c.previous = void 0, c = c.next);
  for (u.events = [], c ? (c._tokenizer = void 0, c.previous = void 0) : q.pop(), g = q.length; g--; ) {
    const b = s.slice(q[g], q[g + 1]), R = i.pop();
    f.push([R, R + b.length - 1]), n.splice(R, 2, b);
  }
  for (f.reverse(), g = -1; ++g < f.length; )
    h[T + f[g][0]] = T + f[g][1], T += f[g][1] - f[g][0] - 1;
  return h;
}
const Rt = {
  resolve: Vt,
  tokenize: Qt
}, Ht = {
  partial: !0,
  tokenize: jt
};
function Vt(n) {
  return Jn(n), n;
}
function Qt(n, r) {
  let e;
  return t;
  function t(s) {
    return n.enter("content"), e = n.enter("chunkContent", {
      contentType: "content"
    }), a(s);
  }
  function a(s) {
    return s === null ? i(s) : w(s) ? n.check(Ht, u, i)(s) : (n.consume(s), a);
  }
  function i(s) {
    return n.exit("chunkContent"), n.exit("content"), r(s);
  }
  function u(s) {
    return n.consume(s), n.exit("chunkContent"), e.next = n.enter("chunkContent", {
      contentType: "content",
      previous: e
    }), e = e.next, a;
  }
}
function jt(n, r, e) {
  const t = this;
  return a;
  function a(u) {
    return n.exit("chunkContent"), n.enter("lineEnding"), n.consume(u), n.exit("lineEnding"), O(n, i, "linePrefix");
  }
  function i(u) {
    if (u === null || w(u))
      return e(u);
    const s = t.events[t.events.length - 1];
    return !t.parser.constructs.disable.null.includes("codeIndented") && s && s[1].type === "linePrefix" && s[2].sliceSerialize(s[1], !0).length >= 4 ? r(u) : n.interrupt(t.parser.constructs.flow, e, r)(u);
  }
}
function Kn(n, r, e, t, a, i, u, s, f) {
  const h = f || Number.POSITIVE_INFINITY;
  let m = 0;
  return p;
  function p(b) {
    return b === 60 ? (n.enter(t), n.enter(a), n.enter(i), n.consume(b), n.exit(i), g) : b === null || b === 32 || b === 41 || En(b) ? e(b) : (n.enter(t), n.enter(u), n.enter(s), n.enter("chunkString", {
      contentType: "string"
    }), F(b));
  }
  function g(b) {
    return b === 62 ? (n.enter(i), n.consume(b), n.exit(i), n.exit(a), n.exit(t), r) : (n.enter(s), n.enter("chunkString", {
      contentType: "string"
    }), c(b));
  }
  function c(b) {
    return b === 62 ? (n.exit("chunkString"), n.exit(s), g(b)) : b === null || b === 60 || w(b) ? e(b) : (n.consume(b), b === 92 ? T : c);
  }
  function T(b) {
    return b === 60 || b === 62 || b === 92 ? (n.consume(b), c) : c(b);
  }
  function F(b) {
    return !m && (b === null || b === 41 || $(b)) ? (n.exit("chunkString"), n.exit(s), n.exit(u), n.exit(t), r(b)) : m < h && b === 40 ? (n.consume(b), m++, F) : b === 41 ? (n.consume(b), m--, F) : b === null || b === 32 || b === 40 || En(b) ? e(b) : (n.consume(b), b === 92 ? q : F);
  }
  function q(b) {
    return b === 40 || b === 41 || b === 92 ? (n.consume(b), F) : F(b);
  }
}
function Xn(n, r, e, t, a, i) {
  const u = this;
  let s = 0, f;
  return h;
  function h(c) {
    return n.enter(t), n.enter(a), n.consume(c), n.exit(a), n.enter(i), m;
  }
  function m(c) {
    return s > 999 || c === null || c === 91 || c === 93 && !f || // To do: remove in the future once we’ve switched from
    // `micromark-extension-footnote` to `micromark-extension-gfm-footnote`,
    // which doesn’t need this.
    // Hidden footnotes hook.
    /* c8 ignore next 3 */
    c === 94 && !s && "_hiddenFootnoteSupport" in u.parser.constructs ? e(c) : c === 93 ? (n.exit(i), n.enter(a), n.consume(c), n.exit(a), n.exit(t), r) : w(c) ? (n.enter("lineEnding"), n.consume(c), n.exit("lineEnding"), m) : (n.enter("chunkString", {
      contentType: "string"
    }), p(c));
  }
  function p(c) {
    return c === null || c === 91 || c === 93 || w(c) || s++ > 999 ? (n.exit("chunkString"), m(c)) : (n.consume(c), f || (f = !_(c)), c === 92 ? g : p);
  }
  function g(c) {
    return c === 91 || c === 92 || c === 93 ? (n.consume(c), s++, p) : p(c);
  }
}
function Zn(n, r, e, t, a, i) {
  let u;
  return s;
  function s(g) {
    return g === 34 || g === 39 || g === 40 ? (n.enter(t), n.enter(a), n.consume(g), n.exit(a), u = g === 40 ? 41 : g, f) : e(g);
  }
  function f(g) {
    return g === u ? (n.enter(a), n.consume(g), n.exit(a), n.exit(t), r) : (n.enter(i), h(g));
  }
  function h(g) {
    return g === u ? (n.exit(i), f(u)) : g === null ? e(g) : w(g) ? (n.enter("lineEnding"), n.consume(g), n.exit("lineEnding"), O(n, h, "linePrefix")) : (n.enter("chunkString", {
      contentType: "string"
    }), m(g));
  }
  function m(g) {
    return g === u || g === null || w(g) ? (n.exit("chunkString"), h(g)) : (n.consume(g), g === 92 ? p : m);
  }
  function p(g) {
    return g === u || g === 92 ? (n.consume(g), m) : m(g);
  }
}
function bn(n, r) {
  let e;
  return t;
  function t(a) {
    return w(a) ? (n.enter("lineEnding"), n.consume(a), n.exit("lineEnding"), e = !0, t) : _(a) ? O(n, t, e ? "linePrefix" : "lineSuffix")(a) : r(a);
  }
}
const Ut = {
  name: "definition",
  tokenize: Yt
}, Wt = {
  partial: !0,
  tokenize: $t
};
function Yt(n, r, e) {
  const t = this;
  let a;
  return i;
  function i(c) {
    return n.enter("definition"), u(c);
  }
  function u(c) {
    return Xn.call(
      t,
      n,
      s,
      // Note: we don’t need to reset the way `markdown-rs` does.
      e,
      "definitionLabel",
      "definitionLabelMarker",
      "definitionLabelString"
    )(c);
  }
  function s(c) {
    return a = fn(t.sliceSerialize(t.events[t.events.length - 1][1]).slice(1, -1)), c === 58 ? (n.enter("definitionMarker"), n.consume(c), n.exit("definitionMarker"), f) : e(c);
  }
  function f(c) {
    return $(c) ? bn(n, h)(c) : h(c);
  }
  function h(c) {
    return Kn(
      n,
      m,
      // Note: we don’t need to reset the way `markdown-rs` does.
      e,
      "definitionDestination",
      "definitionDestinationLiteral",
      "definitionDestinationLiteralMarker",
      "definitionDestinationRaw",
      "definitionDestinationString"
    )(c);
  }
  function m(c) {
    return n.attempt(Wt, p, p)(c);
  }
  function p(c) {
    return _(c) ? O(n, g, "whitespace")(c) : g(c);
  }
  function g(c) {
    return c === null || w(c) ? (n.exit("definition"), t.parser.defined.push(a), r(c)) : e(c);
  }
}
function $t(n, r, e) {
  return t;
  function t(s) {
    return $(s) ? bn(n, a)(s) : e(s);
  }
  function a(s) {
    return Zn(n, i, e, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(s);
  }
  function i(s) {
    return _(s) ? O(n, u, "whitespace")(s) : u(s);
  }
  function u(s) {
    return s === null || w(s) ? r(s) : e(s);
  }
}
const Gt = {
  name: "hardBreakEscape",
  tokenize: Jt
};
function Jt(n, r, e) {
  return t;
  function t(i) {
    return n.enter("hardBreakEscape"), n.consume(i), a;
  }
  function a(i) {
    return w(i) ? (n.exit("hardBreakEscape"), r(i)) : e(i);
  }
}
const Kt = {
  name: "headingAtx",
  resolve: Xt,
  tokenize: Zt
};
function Xt(n, r) {
  let e = n.length - 2, t = 3, a, i;
  return n[t][1].type === "whitespace" && (t += 2), e - 2 > t && n[e][1].type === "whitespace" && (e -= 2), n[e][1].type === "atxHeadingSequence" && (t === e - 1 || e - 4 > t && n[e - 2][1].type === "whitespace") && (e -= t + 1 === e ? 2 : 4), e > t && (a = {
    type: "atxHeadingText",
    start: n[t][1].start,
    end: n[e][1].end
  }, i = {
    type: "chunkText",
    start: n[t][1].start,
    end: n[e][1].end,
    contentType: "text"
  }, sn(n, t, e - t + 1, [["enter", a, r], ["enter", i, r], ["exit", i, r], ["exit", a, r]])), n;
}
function Zt(n, r, e) {
  let t = 0;
  return a;
  function a(m) {
    return n.enter("atxHeading"), i(m);
  }
  function i(m) {
    return n.enter("atxHeadingSequence"), u(m);
  }
  function u(m) {
    return m === 35 && t++ < 6 ? (n.consume(m), u) : m === null || $(m) ? (n.exit("atxHeadingSequence"), s(m)) : e(m);
  }
  function s(m) {
    return m === 35 ? (n.enter("atxHeadingSequence"), f(m)) : m === null || w(m) ? (n.exit("atxHeading"), r(m)) : _(m) ? O(n, s, "whitespace")(m) : (n.enter("atxHeadingText"), h(m));
  }
  function f(m) {
    return m === 35 ? (n.consume(m), f) : (n.exit("atxHeadingSequence"), s(m));
  }
  function h(m) {
    return m === null || m === 35 || $(m) ? (n.exit("atxHeadingText"), s(m)) : (n.consume(m), h);
  }
}
const vt = [
  "address",
  "article",
  "aside",
  "base",
  "basefont",
  "blockquote",
  "body",
  "caption",
  "center",
  "col",
  "colgroup",
  "dd",
  "details",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hr",
  "html",
  "iframe",
  "legend",
  "li",
  "link",
  "main",
  "menu",
  "menuitem",
  "nav",
  "noframes",
  "ol",
  "optgroup",
  "option",
  "p",
  "param",
  "search",
  "section",
  "summary",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "title",
  "tr",
  "track",
  "ul"
], Hn = ["pre", "script", "style", "textarea"], ne = {
  concrete: !0,
  name: "htmlFlow",
  resolveTo: re,
  tokenize: ie
}, te = {
  partial: !0,
  tokenize: ae
}, ee = {
  partial: !0,
  tokenize: ue
};
function re(n) {
  let r = n.length;
  for (; r-- && !(n[r][0] === "enter" && n[r][1].type === "htmlFlow"); )
    ;
  return r > 1 && n[r - 2][1].type === "linePrefix" && (n[r][1].start = n[r - 2][1].start, n[r + 1][1].start = n[r - 2][1].start, n.splice(r - 2, 2)), n;
}
function ie(n, r, e) {
  const t = this;
  let a, i, u, s, f;
  return h;
  function h(o) {
    return m(o);
  }
  function m(o) {
    return n.enter("htmlFlow"), n.enter("htmlFlowData"), n.consume(o), p;
  }
  function p(o) {
    return o === 33 ? (n.consume(o), g) : o === 47 ? (n.consume(o), i = !0, F) : o === 63 ? (n.consume(o), a = 3, t.interrupt ? r : l) : nn(o) ? (n.consume(o), u = String.fromCharCode(o), q) : e(o);
  }
  function g(o) {
    return o === 45 ? (n.consume(o), a = 2, c) : o === 91 ? (n.consume(o), a = 5, s = 0, T) : nn(o) ? (n.consume(o), a = 4, t.interrupt ? r : l) : e(o);
  }
  function c(o) {
    return o === 45 ? (n.consume(o), t.interrupt ? r : l) : e(o);
  }
  function T(o) {
    const X = "CDATA[";
    return o === X.charCodeAt(s++) ? (n.consume(o), s === X.length ? t.interrupt ? r : y : T) : e(o);
  }
  function F(o) {
    return nn(o) ? (n.consume(o), u = String.fromCharCode(o), q) : e(o);
  }
  function q(o) {
    if (o === null || o === 47 || o === 62 || $(o)) {
      const X = o === 47, on = u.toLowerCase();
      return !X && !i && Hn.includes(on) ? (a = 1, t.interrupt ? r(o) : y(o)) : vt.includes(u.toLowerCase()) ? (a = 6, X ? (n.consume(o), b) : t.interrupt ? r(o) : y(o)) : (a = 7, t.interrupt && !t.parser.lazy[t.now().line] ? e(o) : i ? R(o) : S(o));
    }
    return o === 45 || v(o) ? (n.consume(o), u += String.fromCharCode(o), q) : e(o);
  }
  function b(o) {
    return o === 62 ? (n.consume(o), t.interrupt ? r : y) : e(o);
  }
  function R(o) {
    return _(o) ? (n.consume(o), R) : L(o);
  }
  function S(o) {
    return o === 47 ? (n.consume(o), L) : o === 58 || o === 95 || nn(o) ? (n.consume(o), M) : _(o) ? (n.consume(o), S) : L(o);
  }
  function M(o) {
    return o === 45 || o === 46 || o === 58 || o === 95 || v(o) ? (n.consume(o), M) : D(o);
  }
  function D(o) {
    return o === 61 ? (n.consume(o), k) : _(o) ? (n.consume(o), D) : S(o);
  }
  function k(o) {
    return o === null || o === 60 || o === 61 || o === 62 || o === 96 ? e(o) : o === 34 || o === 39 ? (n.consume(o), f = o, B) : _(o) ? (n.consume(o), k) : H(o);
  }
  function B(o) {
    return o === f ? (n.consume(o), f = null, P) : o === null || w(o) ? e(o) : (n.consume(o), B);
  }
  function H(o) {
    return o === null || o === 34 || o === 39 || o === 47 || o === 60 || o === 61 || o === 62 || o === 96 || $(o) ? D(o) : (n.consume(o), H);
  }
  function P(o) {
    return o === 47 || o === 62 || _(o) ? S(o) : e(o);
  }
  function L(o) {
    return o === 62 ? (n.consume(o), I) : e(o);
  }
  function I(o) {
    return o === null || w(o) ? y(o) : _(o) ? (n.consume(o), I) : e(o);
  }
  function y(o) {
    return o === 45 && a === 2 ? (n.consume(o), U) : o === 60 && a === 1 ? (n.consume(o), Q) : o === 62 && a === 4 ? (n.consume(o), K) : o === 63 && a === 3 ? (n.consume(o), l) : o === 93 && a === 5 ? (n.consume(o), tn) : w(o) && (a === 6 || a === 7) ? (n.exit("htmlFlowData"), n.check(te, en, N)(o)) : o === null || w(o) ? (n.exit("htmlFlowData"), N(o)) : (n.consume(o), y);
  }
  function N(o) {
    return n.check(ee, V, en)(o);
  }
  function V(o) {
    return n.enter("lineEnding"), n.consume(o), n.exit("lineEnding"), E;
  }
  function E(o) {
    return o === null || w(o) ? N(o) : (n.enter("htmlFlowData"), y(o));
  }
  function U(o) {
    return o === 45 ? (n.consume(o), l) : y(o);
  }
  function Q(o) {
    return o === 47 ? (n.consume(o), u = "", J) : y(o);
  }
  function J(o) {
    if (o === 62) {
      const X = u.toLowerCase();
      return Hn.includes(X) ? (n.consume(o), K) : y(o);
    }
    return nn(o) && u.length < 8 ? (n.consume(o), u += String.fromCharCode(o), J) : y(o);
  }
  function tn(o) {
    return o === 93 ? (n.consume(o), l) : y(o);
  }
  function l(o) {
    return o === 62 ? (n.consume(o), K) : o === 45 && a === 2 ? (n.consume(o), l) : y(o);
  }
  function K(o) {
    return o === null || w(o) ? (n.exit("htmlFlowData"), en(o)) : (n.consume(o), K);
  }
  function en(o) {
    return n.exit("htmlFlow"), r(o);
  }
}
function ue(n, r, e) {
  const t = this;
  return a;
  function a(u) {
    return w(u) ? (n.enter("lineEnding"), n.consume(u), n.exit("lineEnding"), i) : e(u);
  }
  function i(u) {
    return t.parser.lazy[t.now().line] ? e(u) : r(u);
  }
}
function ae(n, r, e) {
  return t;
  function t(a) {
    return n.enter("lineEnding"), n.consume(a), n.exit("lineEnding"), n.attempt(wn, r, e);
  }
}
const le = {
  name: "htmlText",
  tokenize: se
};
function se(n, r, e) {
  const t = this;
  let a, i, u;
  return s;
  function s(l) {
    return n.enter("htmlText"), n.enter("htmlTextData"), n.consume(l), f;
  }
  function f(l) {
    return l === 33 ? (n.consume(l), h) : l === 47 ? (n.consume(l), D) : l === 63 ? (n.consume(l), S) : nn(l) ? (n.consume(l), H) : e(l);
  }
  function h(l) {
    return l === 45 ? (n.consume(l), m) : l === 91 ? (n.consume(l), i = 0, T) : nn(l) ? (n.consume(l), R) : e(l);
  }
  function m(l) {
    return l === 45 ? (n.consume(l), c) : e(l);
  }
  function p(l) {
    return l === null ? e(l) : l === 45 ? (n.consume(l), g) : w(l) ? (u = p, Q(l)) : (n.consume(l), p);
  }
  function g(l) {
    return l === 45 ? (n.consume(l), c) : p(l);
  }
  function c(l) {
    return l === 62 ? U(l) : l === 45 ? g(l) : p(l);
  }
  function T(l) {
    const K = "CDATA[";
    return l === K.charCodeAt(i++) ? (n.consume(l), i === K.length ? F : T) : e(l);
  }
  function F(l) {
    return l === null ? e(l) : l === 93 ? (n.consume(l), q) : w(l) ? (u = F, Q(l)) : (n.consume(l), F);
  }
  function q(l) {
    return l === 93 ? (n.consume(l), b) : F(l);
  }
  function b(l) {
    return l === 62 ? U(l) : l === 93 ? (n.consume(l), b) : F(l);
  }
  function R(l) {
    return l === null || l === 62 ? U(l) : w(l) ? (u = R, Q(l)) : (n.consume(l), R);
  }
  function S(l) {
    return l === null ? e(l) : l === 63 ? (n.consume(l), M) : w(l) ? (u = S, Q(l)) : (n.consume(l), S);
  }
  function M(l) {
    return l === 62 ? U(l) : S(l);
  }
  function D(l) {
    return nn(l) ? (n.consume(l), k) : e(l);
  }
  function k(l) {
    return l === 45 || v(l) ? (n.consume(l), k) : B(l);
  }
  function B(l) {
    return w(l) ? (u = B, Q(l)) : _(l) ? (n.consume(l), B) : U(l);
  }
  function H(l) {
    return l === 45 || v(l) ? (n.consume(l), H) : l === 47 || l === 62 || $(l) ? P(l) : e(l);
  }
  function P(l) {
    return l === 47 ? (n.consume(l), U) : l === 58 || l === 95 || nn(l) ? (n.consume(l), L) : w(l) ? (u = P, Q(l)) : _(l) ? (n.consume(l), P) : U(l);
  }
  function L(l) {
    return l === 45 || l === 46 || l === 58 || l === 95 || v(l) ? (n.consume(l), L) : I(l);
  }
  function I(l) {
    return l === 61 ? (n.consume(l), y) : w(l) ? (u = I, Q(l)) : _(l) ? (n.consume(l), I) : P(l);
  }
  function y(l) {
    return l === null || l === 60 || l === 61 || l === 62 || l === 96 ? e(l) : l === 34 || l === 39 ? (n.consume(l), a = l, N) : w(l) ? (u = y, Q(l)) : _(l) ? (n.consume(l), y) : (n.consume(l), V);
  }
  function N(l) {
    return l === a ? (n.consume(l), a = void 0, E) : l === null ? e(l) : w(l) ? (u = N, Q(l)) : (n.consume(l), N);
  }
  function V(l) {
    return l === null || l === 34 || l === 39 || l === 60 || l === 61 || l === 96 ? e(l) : l === 47 || l === 62 || $(l) ? P(l) : (n.consume(l), V);
  }
  function E(l) {
    return l === 47 || l === 62 || $(l) ? P(l) : e(l);
  }
  function U(l) {
    return l === 62 ? (n.consume(l), n.exit("htmlTextData"), n.exit("htmlText"), r) : e(l);
  }
  function Q(l) {
    return n.exit("htmlTextData"), n.enter("lineEnding"), n.consume(l), n.exit("lineEnding"), J;
  }
  function J(l) {
    return _(l) ? O(n, tn, "linePrefix", t.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(l) : tn(l);
  }
  function tn(l) {
    return n.enter("htmlTextData"), u(l);
  }
}
const _n = {
  name: "labelEnd",
  resolveAll: pe,
  resolveTo: me,
  tokenize: fe
}, oe = {
  tokenize: ge
}, ce = {
  tokenize: xe
}, he = {
  tokenize: ke
};
function pe(n) {
  let r = -1;
  const e = [];
  for (; ++r < n.length; ) {
    const t = n[r][1];
    if (e.push(n[r]), t.type === "labelImage" || t.type === "labelLink" || t.type === "labelEnd") {
      const a = t.type === "labelImage" ? 4 : 2;
      t.type = "data", r += a;
    }
  }
  return n.length !== e.length && sn(n, 0, n.length, e), n;
}
function me(n, r) {
  let e = n.length, t = 0, a, i, u, s;
  for (; e--; )
    if (a = n[e][1], i) {
      if (a.type === "link" || a.type === "labelLink" && a._inactive)
        break;
      n[e][0] === "enter" && a.type === "labelLink" && (a._inactive = !0);
    } else if (u) {
      if (n[e][0] === "enter" && (a.type === "labelImage" || a.type === "labelLink") && !a._balanced && (i = e, a.type !== "labelLink")) {
        t = 2;
        break;
      }
    } else a.type === "labelEnd" && (u = e);
  const f = {
    type: n[i][1].type === "labelLink" ? "link" : "image",
    start: {
      ...n[i][1].start
    },
    end: {
      ...n[n.length - 1][1].end
    }
  }, h = {
    type: "label",
    start: {
      ...n[i][1].start
    },
    end: {
      ...n[u][1].end
    }
  }, m = {
    type: "labelText",
    start: {
      ...n[i + t + 2][1].end
    },
    end: {
      ...n[u - 2][1].start
    }
  };
  return s = [["enter", f, r], ["enter", h, r]], s = G(s, n.slice(i + 1, i + t + 3)), s = G(s, [["enter", m, r]]), s = G(s, Bn(r.parser.constructs.insideSpan.null, n.slice(i + t + 4, u - 3), r)), s = G(s, [["exit", m, r], n[u - 2], n[u - 1], ["exit", h, r]]), s = G(s, n.slice(u + 1)), s = G(s, [["exit", f, r]]), sn(n, i, n.length, s), n;
}
function fe(n, r, e) {
  const t = this;
  let a = t.events.length, i, u;
  for (; a--; )
    if ((t.events[a][1].type === "labelImage" || t.events[a][1].type === "labelLink") && !t.events[a][1]._balanced) {
      i = t.events[a][1];
      break;
    }
  return s;
  function s(g) {
    return i ? i._inactive ? p(g) : (u = t.parser.defined.includes(fn(t.sliceSerialize({
      start: i.end,
      end: t.now()
    }))), n.enter("labelEnd"), n.enter("labelMarker"), n.consume(g), n.exit("labelMarker"), n.exit("labelEnd"), f) : e(g);
  }
  function f(g) {
    return g === 40 ? n.attempt(oe, m, u ? m : p)(g) : g === 91 ? n.attempt(ce, m, u ? h : p)(g) : u ? m(g) : p(g);
  }
  function h(g) {
    return n.attempt(he, m, p)(g);
  }
  function m(g) {
    return r(g);
  }
  function p(g) {
    return i._balanced = !0, e(g);
  }
}
function ge(n, r, e) {
  return t;
  function t(p) {
    return n.enter("resource"), n.enter("resourceMarker"), n.consume(p), n.exit("resourceMarker"), a;
  }
  function a(p) {
    return $(p) ? bn(n, i)(p) : i(p);
  }
  function i(p) {
    return p === 41 ? m(p) : Kn(n, u, s, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(p);
  }
  function u(p) {
    return $(p) ? bn(n, f)(p) : m(p);
  }
  function s(p) {
    return e(p);
  }
  function f(p) {
    return p === 34 || p === 39 || p === 40 ? Zn(n, h, e, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(p) : m(p);
  }
  function h(p) {
    return $(p) ? bn(n, m)(p) : m(p);
  }
  function m(p) {
    return p === 41 ? (n.enter("resourceMarker"), n.consume(p), n.exit("resourceMarker"), n.exit("resource"), r) : e(p);
  }
}
function xe(n, r, e) {
  const t = this;
  return a;
  function a(s) {
    return Xn.call(t, n, i, u, "reference", "referenceMarker", "referenceString")(s);
  }
  function i(s) {
    return t.parser.defined.includes(fn(t.sliceSerialize(t.events[t.events.length - 1][1]).slice(1, -1))) ? r(s) : e(s);
  }
  function u(s) {
    return e(s);
  }
}
function ke(n, r, e) {
  return t;
  function t(i) {
    return n.enter("reference"), n.enter("referenceMarker"), n.consume(i), n.exit("referenceMarker"), a;
  }
  function a(i) {
    return i === 93 ? (n.enter("referenceMarker"), n.consume(i), n.exit("referenceMarker"), n.exit("reference"), r) : e(i);
  }
}
const de = {
  name: "labelStartImage",
  resolveAll: _n.resolveAll,
  tokenize: be
};
function be(n, r, e) {
  const t = this;
  return a;
  function a(s) {
    return n.enter("labelImage"), n.enter("labelImageMarker"), n.consume(s), n.exit("labelImageMarker"), i;
  }
  function i(s) {
    return s === 91 ? (n.enter("labelMarker"), n.consume(s), n.exit("labelMarker"), n.exit("labelImage"), u) : e(s);
  }
  function u(s) {
    return s === 94 && "_hiddenFootnoteSupport" in t.parser.constructs ? e(s) : r(s);
  }
}
const Se = {
  name: "labelStartLink",
  resolveAll: _n.resolveAll,
  tokenize: ye
};
function ye(n, r, e) {
  const t = this;
  return a;
  function a(u) {
    return n.enter("labelLink"), n.enter("labelMarker"), n.consume(u), n.exit("labelMarker"), n.exit("labelLink"), i;
  }
  function i(u) {
    return u === 94 && "_hiddenFootnoteSupport" in t.parser.constructs ? e(u) : r(u);
  }
}
const Cn = {
  name: "lineEnding",
  tokenize: Ie
};
function Ie(n, r) {
  return e;
  function e(t) {
    return n.enter("lineEnding"), n.consume(t), n.exit("lineEnding"), O(n, r, "linePrefix");
  }
}
const In = {
  name: "thematicBreak",
  tokenize: we
};
function we(n, r, e) {
  let t = 0, a;
  return i;
  function i(h) {
    return n.enter("thematicBreak"), u(h);
  }
  function u(h) {
    return a = h, s(h);
  }
  function s(h) {
    return h === a ? (n.enter("thematicBreakSequence"), f(h)) : t >= 3 && (h === null || w(h)) ? (n.exit("thematicBreak"), r(h)) : e(h);
  }
  function f(h) {
    return h === a ? (n.consume(h), t++, f) : (n.exit("thematicBreakSequence"), _(h) ? O(n, s, "whitespace")(h) : s(h));
  }
}
const W = {
  continuation: {
    tokenize: Te
  },
  exit: Be,
  name: "list",
  tokenize: Ee
}, ze = {
  partial: !0,
  tokenize: _e
}, Ce = {
  partial: !0,
  tokenize: Fe
};
function Ee(n, r, e) {
  const t = this, a = t.events[t.events.length - 1];
  let i = a && a[1].type === "linePrefix" ? a[2].sliceSerialize(a[1], !0).length : 0, u = 0;
  return s;
  function s(c) {
    const T = t.containerState.type || (c === 42 || c === 43 || c === 45 ? "listUnordered" : "listOrdered");
    if (T === "listUnordered" ? !t.containerState.marker || c === t.containerState.marker : Tn(c)) {
      if (t.containerState.type || (t.containerState.type = T, n.enter(T, {
        _container: !0
      })), T === "listUnordered")
        return n.enter("listItemPrefix"), c === 42 || c === 45 ? n.check(In, e, h)(c) : h(c);
      if (!t.interrupt || c === 49)
        return n.enter("listItemPrefix"), n.enter("listItemValue"), f(c);
    }
    return e(c);
  }
  function f(c) {
    return Tn(c) && ++u < 10 ? (n.consume(c), f) : (!t.interrupt || u < 2) && (t.containerState.marker ? c === t.containerState.marker : c === 41 || c === 46) ? (n.exit("listItemValue"), h(c)) : e(c);
  }
  function h(c) {
    return n.enter("listItemMarker"), n.consume(c), n.exit("listItemMarker"), t.containerState.marker = t.containerState.marker || c, n.check(
      wn,
      // Can’t be empty when interrupting.
      t.interrupt ? e : m,
      n.attempt(ze, g, p)
    );
  }
  function m(c) {
    return t.containerState.initialBlankLine = !0, i++, g(c);
  }
  function p(c) {
    return _(c) ? (n.enter("listItemPrefixWhitespace"), n.consume(c), n.exit("listItemPrefixWhitespace"), g) : e(c);
  }
  function g(c) {
    return t.containerState.size = i + t.sliceSerialize(n.exit("listItemPrefix"), !0).length, r(c);
  }
}
function Te(n, r, e) {
  const t = this;
  return t.containerState._closeFlow = void 0, n.check(wn, a, i);
  function a(s) {
    return t.containerState.furtherBlankLines = t.containerState.furtherBlankLines || t.containerState.initialBlankLine, O(n, r, "listItemIndent", t.containerState.size + 1)(s);
  }
  function i(s) {
    return t.containerState.furtherBlankLines || !_(s) ? (t.containerState.furtherBlankLines = void 0, t.containerState.initialBlankLine = void 0, u(s)) : (t.containerState.furtherBlankLines = void 0, t.containerState.initialBlankLine = void 0, n.attempt(Ce, r, u)(s));
  }
  function u(s) {
    return t.containerState._closeFlow = !0, t.interrupt = void 0, O(n, n.attempt(W, r, e), "linePrefix", t.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(s);
  }
}
function Fe(n, r, e) {
  const t = this;
  return O(n, a, "listItemIndent", t.containerState.size + 1);
  function a(i) {
    const u = t.events[t.events.length - 1];
    return u && u[1].type === "listItemIndent" && u[2].sliceSerialize(u[1], !0).length === t.containerState.size ? r(i) : e(i);
  }
}
function Be(n) {
  n.exit(this.containerState.type);
}
function _e(n, r, e) {
  const t = this;
  return O(n, a, "listItemPrefixWhitespace", t.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
  function a(i) {
    const u = t.events[t.events.length - 1];
    return !_(i) && u && u[1].type === "listItemPrefixWhitespace" ? r(i) : e(i);
  }
}
const Vn = {
  name: "setextUnderline",
  resolveTo: Pe,
  tokenize: Ae
};
function Pe(n, r) {
  let e = n.length, t, a, i;
  for (; e--; )
    if (n[e][0] === "enter") {
      if (n[e][1].type === "content") {
        t = e;
        break;
      }
      n[e][1].type === "paragraph" && (a = e);
    } else
      n[e][1].type === "content" && n.splice(e, 1), !i && n[e][1].type === "definition" && (i = e);
  const u = {
    type: "setextHeading",
    start: {
      ...n[t][1].start
    },
    end: {
      ...n[n.length - 1][1].end
    }
  };
  return n[a][1].type = "setextHeadingText", i ? (n.splice(a, 0, ["enter", u, r]), n.splice(i + 1, 0, ["exit", n[t][1], r]), n[t][1].end = {
    ...n[i][1].end
  }) : n[t][1] = u, n.push(["exit", u, r]), n;
}
function Ae(n, r, e) {
  const t = this;
  let a;
  return i;
  function i(h) {
    let m = t.events.length, p;
    for (; m--; )
      if (t.events[m][1].type !== "lineEnding" && t.events[m][1].type !== "linePrefix" && t.events[m][1].type !== "content") {
        p = t.events[m][1].type === "paragraph";
        break;
      }
    return !t.parser.lazy[t.now().line] && (t.interrupt || p) ? (n.enter("setextHeadingLine"), a = h, u(h)) : e(h);
  }
  function u(h) {
    return n.enter("setextHeadingLineSequence"), s(h);
  }
  function s(h) {
    return h === a ? (n.consume(h), s) : (n.exit("setextHeadingLineSequence"), _(h) ? O(n, f, "lineSuffix")(h) : f(h));
  }
  function f(h) {
    return h === null || w(h) ? (n.exit("setextHeadingLine"), r(h)) : e(h);
  }
}
const Le = {
  tokenize: Oe
};
function Oe(n) {
  const r = n.attempt(this.parser.constructs.contentInitial, t, a);
  let e;
  return r;
  function t(s) {
    if (s === null) {
      n.consume(s);
      return;
    }
    return n.enter("lineEnding"), n.consume(s), n.exit("lineEnding"), O(n, r, "linePrefix");
  }
  function a(s) {
    return n.enter("paragraph"), i(s);
  }
  function i(s) {
    const f = n.enter("chunkText", {
      contentType: "text",
      previous: e
    });
    return e && (e.next = f), e = f, u(s);
  }
  function u(s) {
    if (s === null) {
      n.exit("chunkText"), n.exit("paragraph"), n.consume(s);
      return;
    }
    return w(s) ? (n.consume(s), n.exit("chunkText"), i) : (n.consume(s), u);
  }
}
const Me = {
  tokenize: Ne
}, Qn = {
  tokenize: De
};
function Ne(n) {
  const r = this, e = [];
  let t = 0, a, i, u;
  return s;
  function s(S) {
    if (t < e.length) {
      const M = e[t];
      return r.containerState = M[1], n.attempt(M[0].continuation, f, h)(S);
    }
    return h(S);
  }
  function f(S) {
    if (t++, r.containerState._closeFlow) {
      r.containerState._closeFlow = void 0, a && R();
      const M = r.events.length;
      let D = M, k;
      for (; D--; )
        if (r.events[D][0] === "exit" && r.events[D][1].type === "chunkFlow") {
          k = r.events[D][1].end;
          break;
        }
      b(t);
      let B = M;
      for (; B < r.events.length; )
        r.events[B][1].end = {
          ...k
        }, B++;
      return sn(r.events, D + 1, 0, r.events.slice(M)), r.events.length = B, h(S);
    }
    return s(S);
  }
  function h(S) {
    if (t === e.length) {
      if (!a)
        return g(S);
      if (a.currentConstruct && a.currentConstruct.concrete)
        return T(S);
      r.interrupt = !!(a.currentConstruct && !a._gfmTableDynamicInterruptHack);
    }
    return r.containerState = {}, n.check(Qn, m, p)(S);
  }
  function m(S) {
    return a && R(), b(t), g(S);
  }
  function p(S) {
    return r.parser.lazy[r.now().line] = t !== e.length, u = r.now().offset, T(S);
  }
  function g(S) {
    return r.containerState = {}, n.attempt(Qn, c, T)(S);
  }
  function c(S) {
    return t++, e.push([r.currentConstruct, r.containerState]), g(S);
  }
  function T(S) {
    if (S === null) {
      a && R(), b(0), n.consume(S);
      return;
    }
    return a = a || r.parser.flow(r.now()), n.enter("chunkFlow", {
      _tokenizer: a,
      contentType: "flow",
      previous: i
    }), F(S);
  }
  function F(S) {
    if (S === null) {
      q(n.exit("chunkFlow"), !0), b(0), n.consume(S);
      return;
    }
    return w(S) ? (n.consume(S), q(n.exit("chunkFlow")), t = 0, r.interrupt = void 0, s) : (n.consume(S), F);
  }
  function q(S, M) {
    const D = r.sliceStream(S);
    if (M && D.push(null), S.previous = i, i && (i.next = S), i = S, a.defineSkip(S.start), a.write(D), r.parser.lazy[S.start.line]) {
      let k = a.events.length;
      for (; k--; )
        if (
          // The token starts before the line ending…
          a.events[k][1].start.offset < u && // …and either is not ended yet…
          (!a.events[k][1].end || // …or ends after it.
          a.events[k][1].end.offset > u)
        )
          return;
      const B = r.events.length;
      let H = B, P, L;
      for (; H--; )
        if (r.events[H][0] === "exit" && r.events[H][1].type === "chunkFlow") {
          if (P) {
            L = r.events[H][1].end;
            break;
          }
          P = !0;
        }
      for (b(t), k = B; k < r.events.length; )
        r.events[k][1].end = {
          ...L
        }, k++;
      sn(r.events, H + 1, 0, r.events.slice(B)), r.events.length = k;
    }
  }
  function b(S) {
    let M = e.length;
    for (; M-- > S; ) {
      const D = e[M];
      r.containerState = D[1], D[0].exit.call(r, n);
    }
    e.length = S;
  }
  function R() {
    a.write([null]), i = void 0, a = void 0, r.containerState._closeFlow = void 0;
  }
}
function De(n, r, e) {
  return O(n, n.attempt(this.parser.constructs.document, r, e), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
const qe = {
  tokenize: Re
};
function Re(n) {
  const r = this, e = n.attempt(
    // Try to parse a blank line.
    wn,
    t,
    // Try to parse initial flow (essentially, only code).
    n.attempt(this.parser.constructs.flowInitial, a, O(n, n.attempt(this.parser.constructs.flow, a, n.attempt(Rt, a)), "linePrefix"))
  );
  return e;
  function t(i) {
    if (i === null) {
      n.consume(i);
      return;
    }
    return n.enter("lineEndingBlank"), n.consume(i), n.exit("lineEndingBlank"), r.currentConstruct = void 0, e;
  }
  function a(i) {
    if (i === null) {
      n.consume(i);
      return;
    }
    return n.enter("lineEnding"), n.consume(i), n.exit("lineEnding"), r.currentConstruct = void 0, e;
  }
}
const He = {
  resolveAll: nt()
}, Ve = vn("string"), Qe = vn("text");
function vn(n) {
  return {
    resolveAll: nt(n === "text" ? je : void 0),
    tokenize: r
  };
  function r(e) {
    const t = this, a = this.parser.constructs[n], i = e.attempt(a, u, s);
    return u;
    function u(m) {
      return h(m) ? i(m) : s(m);
    }
    function s(m) {
      if (m === null) {
        e.consume(m);
        return;
      }
      return e.enter("data"), e.consume(m), f;
    }
    function f(m) {
      return h(m) ? (e.exit("data"), i(m)) : (e.consume(m), f);
    }
    function h(m) {
      if (m === null)
        return !0;
      const p = a[m];
      let g = -1;
      if (p)
        for (; ++g < p.length; ) {
          const c = p[g];
          if (!c.previous || c.previous.call(t, t.previous))
            return !0;
        }
      return !1;
    }
  }
}
function nt(n) {
  return r;
  function r(e, t) {
    let a = -1, i;
    for (; ++a <= e.length; )
      i === void 0 ? e[a] && e[a][1].type === "data" && (i = a, a++) : (!e[a] || e[a][1].type !== "data") && (a !== i + 2 && (e[i][1].end = e[a - 1][1].end, e.splice(i + 2, a - i - 2), a = i + 2), i = void 0);
    return n ? n(e, t) : e;
  }
}
function je(n, r) {
  let e = 0;
  for (; ++e <= n.length; )
    if ((e === n.length || n[e][1].type === "lineEnding") && n[e - 1][1].type === "data") {
      const t = n[e - 1][1], a = r.sliceStream(t);
      let i = a.length, u = -1, s = 0, f;
      for (; i--; ) {
        const h = a[i];
        if (typeof h == "string") {
          for (u = h.length; h.charCodeAt(u - 1) === 32; )
            s++, u--;
          if (u) break;
          u = -1;
        } else if (h === -2)
          f = !0, s++;
        else if (h !== -1) {
          i++;
          break;
        }
      }
      if (r._contentTypeTextTrailing && e === n.length && (s = 0), s) {
        const h = {
          type: e === n.length || f || s < 2 ? "lineSuffix" : "hardBreakTrailing",
          start: {
            _bufferIndex: i ? u : t.start._bufferIndex + u,
            _index: t.start._index + i,
            line: t.end.line,
            column: t.end.column - s,
            offset: t.end.offset - s
          },
          end: {
            ...t.end
          }
        };
        t.end = {
          ...h.start
        }, t.start.offset === t.end.offset ? Object.assign(t, h) : (n.splice(e, 0, ["enter", h, r], ["exit", h, r]), e += 2);
      }
      e++;
    }
  return n;
}
const Ue = {
  42: W,
  43: W,
  45: W,
  48: W,
  49: W,
  50: W,
  51: W,
  52: W,
  53: W,
  54: W,
  55: W,
  56: W,
  57: W,
  62: Yn
}, We = {
  91: Ut
}, Ye = {
  [-2]: zn,
  [-1]: zn,
  32: zn
}, $e = {
  35: Kt,
  42: In,
  45: [Vn, In],
  60: ne,
  61: Vn,
  95: In,
  96: Rn,
  126: Rn
}, Ge = {
  38: Gn,
  92: $n
}, Je = {
  [-5]: Cn,
  [-4]: Cn,
  [-3]: Cn,
  33: de,
  38: Gn,
  42: Fn,
  60: [yt, le],
  91: Se,
  92: [Gt, $n],
  93: _n,
  95: Fn,
  96: Lt
}, Ke = {
  null: [Fn, He]
}, Xe = {
  null: [42, 95]
}, Ze = {
  null: []
}, ve = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  attentionMarkers: Xe,
  contentInitial: We,
  disable: Ze,
  document: Ue,
  flow: $e,
  flowInitial: Ye,
  insideSpan: Ke,
  string: Ge,
  text: Je
}, Symbol.toStringTag, { value: "Module" }));
function nr(n, r, e) {
  let t = {
    _bufferIndex: -1,
    _index: 0,
    line: e && e.line || 1,
    column: e && e.column || 1,
    offset: e && e.offset || 0
  };
  const a = {}, i = [];
  let u = [], s = [];
  const f = {
    attempt: B(D),
    check: B(k),
    consume: R,
    enter: S,
    exit: M,
    interrupt: B(k, {
      interrupt: !0
    })
  }, h = {
    code: null,
    containerState: {},
    defineSkip: F,
    events: [],
    now: T,
    parser: n,
    previous: null,
    sliceSerialize: g,
    sliceStream: c,
    write: p
  };
  let m = r.tokenize.call(h, f);
  return r.resolveAll && i.push(r), h;
  function p(I) {
    return u = G(u, I), q(), u[u.length - 1] !== null ? [] : (H(r, 0), h.events = Bn(i, h.events, h), h.events);
  }
  function g(I, y) {
    return er(c(I), y);
  }
  function c(I) {
    return tr(u, I);
  }
  function T() {
    const {
      _bufferIndex: I,
      _index: y,
      line: N,
      column: V,
      offset: E
    } = t;
    return {
      _bufferIndex: I,
      _index: y,
      line: N,
      column: V,
      offset: E
    };
  }
  function F(I) {
    a[I.line] = I.column, L();
  }
  function q() {
    let I;
    for (; t._index < u.length; ) {
      const y = u[t._index];
      if (typeof y == "string")
        for (I = t._index, t._bufferIndex < 0 && (t._bufferIndex = 0); t._index === I && t._bufferIndex < y.length; )
          b(y.charCodeAt(t._bufferIndex));
      else
        b(y);
    }
  }
  function b(I) {
    m = m(I);
  }
  function R(I) {
    w(I) ? (t.line++, t.column = 1, t.offset += I === -3 ? 2 : 1, L()) : I !== -1 && (t.column++, t.offset++), t._bufferIndex < 0 ? t._index++ : (t._bufferIndex++, t._bufferIndex === // Points w/ non-negative `_bufferIndex` reference
    // strings.
    /** @type {string} */
    u[t._index].length && (t._bufferIndex = -1, t._index++)), h.previous = I;
  }
  function S(I, y) {
    const N = y || {};
    return N.type = I, N.start = T(), h.events.push(["enter", N, h]), s.push(N), N;
  }
  function M(I) {
    const y = s.pop();
    return y.end = T(), h.events.push(["exit", y, h]), y;
  }
  function D(I, y) {
    H(I, y.from);
  }
  function k(I, y) {
    y.restore();
  }
  function B(I, y) {
    return N;
    function N(V, E, U) {
      let Q, J, tn, l;
      return Array.isArray(V) ? (
        /* c8 ignore next 1 */
        en(V)
      ) : "tokenize" in V ? (
        // Looks like a construct.
        en([
          /** @type {Construct} */
          V
        ])
      ) : K(V);
      function K(j) {
        return gn;
        function gn(an) {
          const hn = an !== null && j[an], pn = an !== null && j.null, Sn = [
            // To do: add more extension tests.
            /* c8 ignore next 2 */
            ...Array.isArray(hn) ? hn : hn ? [hn] : [],
            ...Array.isArray(pn) ? pn : pn ? [pn] : []
          ];
          return en(Sn)(an);
        }
      }
      function en(j) {
        return Q = j, J = 0, j.length === 0 ? U : o(j[J]);
      }
      function o(j) {
        return gn;
        function gn(an) {
          return l = P(), tn = j, j.partial || (h.currentConstruct = j), j.name && h.parser.constructs.disable.null.includes(j.name) ? on() : j.tokenize.call(
            // If we do have fields, create an object w/ `context` as its
            // prototype.
            // This allows a “live binding”, which is needed for `interrupt`.
            y ? Object.assign(Object.create(h), y) : h,
            f,
            X,
            on
          )(an);
        }
      }
      function X(j) {
        return I(tn, l), E;
      }
      function on(j) {
        return l.restore(), ++J < Q.length ? o(Q[J]) : U;
      }
    }
  }
  function H(I, y) {
    I.resolveAll && !i.includes(I) && i.push(I), I.resolve && sn(h.events, y, h.events.length - y, I.resolve(h.events.slice(y), h)), I.resolveTo && (h.events = I.resolveTo(h.events, h));
  }
  function P() {
    const I = T(), y = h.previous, N = h.currentConstruct, V = h.events.length, E = Array.from(s);
    return {
      from: V,
      restore: U
    };
    function U() {
      t = I, h.previous = y, h.currentConstruct = N, h.events.length = V, s = E, L();
    }
  }
  function L() {
    t.line in a && t.column < 2 && (t.column = a[t.line], t.offset += a[t.line] - 1);
  }
}
function tr(n, r) {
  const e = r.start._index, t = r.start._bufferIndex, a = r.end._index, i = r.end._bufferIndex;
  let u;
  if (e === a)
    u = [n[e].slice(t, i)];
  else {
    if (u = n.slice(e, a), t > -1) {
      const s = u[0];
      typeof s == "string" ? u[0] = s.slice(t) : u.shift();
    }
    i > 0 && u.push(n[a].slice(0, i));
  }
  return u;
}
function er(n, r) {
  let e = -1;
  const t = [];
  let a;
  for (; ++e < n.length; ) {
    const i = n[e];
    let u;
    if (typeof i == "string")
      u = i;
    else switch (i) {
      case -5: {
        u = "\r";
        break;
      }
      case -4: {
        u = `
`;
        break;
      }
      case -3: {
        u = `\r
`;
        break;
      }
      case -2: {
        u = r ? " " : "	";
        break;
      }
      case -1: {
        if (!r && a) continue;
        u = " ";
        break;
      }
      default:
        u = String.fromCharCode(i);
    }
    a = i === -2, t.push(u);
  }
  return t.join("");
}
function rr(n) {
  const t = {
    constructs: (
      /** @type {FullNormalizedExtension} */
      ft([ve, ...(n || {}).extensions || []])
    ),
    content: a(Le),
    defined: [],
    document: a(Me),
    flow: a(qe),
    lazy: {},
    string: a(Ve),
    text: a(Qe)
  };
  return t;
  function a(i) {
    return u;
    function u(s) {
      return nr(t, i, s);
    }
  }
}
function ir(n) {
  for (; !Jn(n); )
    ;
  return n;
}
const jn = /[\0\t\n\r]/g;
function ur() {
  let n = 1, r = "", e = !0, t;
  return a;
  function a(i, u, s) {
    const f = [];
    let h, m, p, g, c;
    for (i = r + (typeof i == "string" ? i.toString() : new TextDecoder(u || void 0).decode(i)), p = 0, r = "", e && (i.charCodeAt(0) === 65279 && p++, e = void 0); p < i.length; ) {
      if (jn.lastIndex = p, h = jn.exec(i), g = h && h.index !== void 0 ? h.index : i.length, c = i.charCodeAt(g), !h) {
        r = i.slice(p);
        break;
      }
      if (c === 10 && p === g && t)
        f.push(-3), t = void 0;
      else
        switch (t && (f.push(-5), t = void 0), p < g && (f.push(i.slice(p, g)), n += g - p), c) {
          case 0: {
            f.push(65533), n++;
            break;
          }
          case 9: {
            for (m = Math.ceil(n / 4) * 4, f.push(-2); n++ < m; ) f.push(-1);
            break;
          }
          case 10: {
            f.push(-4), n = 1;
            break;
          }
          default:
            t = !0, n = 1;
        }
      p = g + 1;
    }
    return s && (t && f.push(-5), r && f.push(r), f.push(null)), f;
  }
}
const tt = {}.hasOwnProperty;
function ar(n, r, e) {
  return typeof r != "string" && (e = r, r = void 0), lr(e)(ir(rr(e).document().write(ur()(n, r, !0))));
}
function lr(n) {
  const r = {
    transforms: [],
    canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
    enter: {
      autolink: i(On),
      autolinkProtocol: P,
      autolinkEmail: P,
      atxHeading: i(Pn),
      blockQuote: i(pn),
      characterEscape: P,
      characterReference: P,
      codeFenced: i(Sn),
      codeFencedFenceInfo: u,
      codeFencedFenceMeta: u,
      codeIndented: i(Sn, u),
      codeText: i(rt, u),
      codeTextData: P,
      data: P,
      codeFlowValue: P,
      definition: i(it),
      definitionDestinationString: u,
      definitionLabelString: u,
      definitionTitleString: u,
      emphasis: i(ut),
      hardBreakEscape: i(An),
      hardBreakTrailing: i(An),
      htmlFlow: i(Ln, u),
      htmlFlowData: P,
      htmlText: i(Ln, u),
      htmlTextData: P,
      image: i(at),
      label: u,
      link: i(On),
      listItem: i(lt),
      listItemValue: g,
      listOrdered: i(Mn, p),
      listUnordered: i(Mn),
      paragraph: i(st),
      reference: o,
      referenceString: u,
      resourceDestinationString: u,
      resourceTitleString: u,
      setextHeading: i(Pn),
      strong: i(ot),
      thematicBreak: i(ht)
    },
    exit: {
      atxHeading: f(),
      atxHeadingSequence: D,
      autolink: f(),
      autolinkEmail: hn,
      autolinkProtocol: an,
      blockQuote: f(),
      characterEscapeValue: L,
      characterReferenceMarkerHexadecimal: on,
      characterReferenceMarkerNumeric: on,
      characterReferenceValue: j,
      characterReference: gn,
      codeFenced: f(q),
      codeFencedFence: F,
      codeFencedFenceInfo: c,
      codeFencedFenceMeta: T,
      codeFlowValue: L,
      codeIndented: f(b),
      codeText: f(E),
      codeTextData: L,
      data: L,
      definition: f(),
      definitionDestinationString: M,
      definitionLabelString: R,
      definitionTitleString: S,
      emphasis: f(),
      hardBreakEscape: f(y),
      hardBreakTrailing: f(y),
      htmlFlow: f(N),
      htmlFlowData: L,
      htmlText: f(V),
      htmlTextData: L,
      image: f(Q),
      label: tn,
      labelText: J,
      lineEnding: I,
      link: f(U),
      listItem: f(),
      listOrdered: f(),
      listUnordered: f(),
      paragraph: f(),
      referenceString: X,
      resourceDestinationString: l,
      resourceTitleString: K,
      resource: en,
      setextHeading: f(H),
      setextHeadingLineSequence: B,
      setextHeadingText: k,
      strong: f(),
      thematicBreak: f()
    }
  };
  et(r, (n || {}).mdastExtensions || []);
  const e = {};
  return t;
  function t(x) {
    let d = {
      type: "root",
      children: []
    };
    const z = {
      stack: [d],
      tokenStack: [],
      config: r,
      enter: s,
      exit: h,
      buffer: u,
      resume: m,
      data: e
    }, C = [];
    let A = -1;
    for (; ++A < x.length; )
      if (x[A][1].type === "listOrdered" || x[A][1].type === "listUnordered")
        if (x[A][0] === "enter")
          C.push(A);
        else {
          const Z = C.pop();
          A = a(x, Z, A);
        }
    for (A = -1; ++A < x.length; ) {
      const Z = r[x[A][0]];
      tt.call(Z, x[A][1].type) && Z[x[A][1].type].call(Object.assign({
        sliceSerialize: x[A][2].sliceSerialize
      }, z), x[A][1]);
    }
    if (z.tokenStack.length > 0) {
      const Z = z.tokenStack[z.tokenStack.length - 1];
      (Z[1] || Un).call(z, void 0, Z[0]);
    }
    for (d.position = {
      start: ln(x.length > 0 ? x[0][1].start : {
        line: 1,
        column: 1,
        offset: 0
      }),
      end: ln(x.length > 0 ? x[x.length - 2][1].end : {
        line: 1,
        column: 1,
        offset: 0
      })
    }, A = -1; ++A < r.transforms.length; )
      d = r.transforms[A](d) || d;
    return d;
  }
  function a(x, d, z) {
    let C = d - 1, A = -1, Z = !1, cn, rn, xn, kn;
    for (; ++C <= z; ) {
      const Y = x[C];
      switch (Y[1].type) {
        case "listUnordered":
        case "listOrdered":
        case "blockQuote": {
          Y[0] === "enter" ? A++ : A--, kn = void 0;
          break;
        }
        case "lineEndingBlank": {
          Y[0] === "enter" && (cn && !kn && !A && !xn && (xn = C), kn = void 0);
          break;
        }
        case "linePrefix":
        case "listItemValue":
        case "listItemMarker":
        case "listItemPrefix":
        case "listItemPrefixWhitespace":
          break;
        default:
          kn = void 0;
      }
      if (!A && Y[0] === "enter" && Y[1].type === "listItemPrefix" || A === -1 && Y[0] === "exit" && (Y[1].type === "listUnordered" || Y[1].type === "listOrdered")) {
        if (cn) {
          let mn = C;
          for (rn = void 0; mn--; ) {
            const un = x[mn];
            if (un[1].type === "lineEnding" || un[1].type === "lineEndingBlank") {
              if (un[0] === "exit") continue;
              rn && (x[rn][1].type = "lineEndingBlank", Z = !0), un[1].type = "lineEnding", rn = mn;
            } else if (!(un[1].type === "linePrefix" || un[1].type === "blockQuotePrefix" || un[1].type === "blockQuotePrefixWhitespace" || un[1].type === "blockQuoteMarker" || un[1].type === "listItemIndent")) break;
          }
          xn && (!rn || xn < rn) && (cn._spread = !0), cn.end = Object.assign({}, rn ? x[rn][1].start : Y[1].end), x.splice(rn || C, 0, ["exit", cn, Y[2]]), C++, z++;
        }
        if (Y[1].type === "listItemPrefix") {
          const mn = {
            type: "listItem",
            _spread: !1,
            start: Object.assign({}, Y[1].start),
            // @ts-expect-error: we’ll add `end` in a second.
            end: void 0
          };
          cn = mn, x.splice(C, 0, ["enter", mn, Y[2]]), C++, z++, xn = void 0, kn = !0;
        }
      }
    }
    return x[d][1]._spread = Z, z;
  }
  function i(x, d) {
    return z;
    function z(C) {
      s.call(this, x(C), C), d && d.call(this, C);
    }
  }
  function u() {
    this.stack.push({
      type: "fragment",
      children: []
    });
  }
  function s(x, d, z) {
    this.stack[this.stack.length - 1].children.push(x), this.stack.push(x), this.tokenStack.push([d, z || void 0]), x.position = {
      start: ln(d.start),
      // @ts-expect-error: `end` will be patched later.
      end: void 0
    };
  }
  function f(x) {
    return d;
    function d(z) {
      x && x.call(this, z), h.call(this, z);
    }
  }
  function h(x, d) {
    const z = this.stack.pop(), C = this.tokenStack.pop();
    if (C)
      C[0].type !== x.type && (d ? d.call(this, x, C[0]) : (C[1] || Un).call(this, x, C[0]));
    else throw new Error("Cannot close `" + x.type + "` (" + yn({
      start: x.start,
      end: x.end
    }) + "): it’s not open");
    z.position.end = ln(x.end);
  }
  function m() {
    return dt(this.stack.pop());
  }
  function p() {
    this.data.expectingFirstListItemValue = !0;
  }
  function g(x) {
    if (this.data.expectingFirstListItemValue) {
      const d = this.stack[this.stack.length - 2];
      d.start = Number.parseInt(this.sliceSerialize(x), 10), this.data.expectingFirstListItemValue = void 0;
    }
  }
  function c() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.lang = x;
  }
  function T() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.meta = x;
  }
  function F() {
    this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
  }
  function q() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.value = x.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
  }
  function b() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.value = x.replace(/(\r?\n|\r)$/g, "");
  }
  function R(x) {
    const d = this.resume(), z = this.stack[this.stack.length - 1];
    z.label = d, z.identifier = fn(this.sliceSerialize(x)).toLowerCase();
  }
  function S() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.title = x;
  }
  function M() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.url = x;
  }
  function D(x) {
    const d = this.stack[this.stack.length - 1];
    if (!d.depth) {
      const z = this.sliceSerialize(x).length;
      d.depth = z;
    }
  }
  function k() {
    this.data.setextHeadingSlurpLineEnding = !0;
  }
  function B(x) {
    const d = this.stack[this.stack.length - 1];
    d.depth = this.sliceSerialize(x).codePointAt(0) === 61 ? 1 : 2;
  }
  function H() {
    this.data.setextHeadingSlurpLineEnding = void 0;
  }
  function P(x) {
    const z = this.stack[this.stack.length - 1].children;
    let C = z[z.length - 1];
    (!C || C.type !== "text") && (C = ct(), C.position = {
      start: ln(x.start),
      // @ts-expect-error: we’ll add `end` later.
      end: void 0
    }, z.push(C)), this.stack.push(C);
  }
  function L(x) {
    const d = this.stack.pop();
    d.value += this.sliceSerialize(x), d.position.end = ln(x.end);
  }
  function I(x) {
    const d = this.stack[this.stack.length - 1];
    if (this.data.atHardBreak) {
      const z = d.children[d.children.length - 1];
      z.position.end = ln(x.end), this.data.atHardBreak = void 0;
      return;
    }
    !this.data.setextHeadingSlurpLineEnding && r.canContainEols.includes(d.type) && (P.call(this, x), L.call(this, x));
  }
  function y() {
    this.data.atHardBreak = !0;
  }
  function N() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.value = x;
  }
  function V() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.value = x;
  }
  function E() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.value = x;
  }
  function U() {
    const x = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const d = this.data.referenceType || "shortcut";
      x.type += "Reference", x.referenceType = d, delete x.url, delete x.title;
    } else
      delete x.identifier, delete x.label;
    this.data.referenceType = void 0;
  }
  function Q() {
    const x = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const d = this.data.referenceType || "shortcut";
      x.type += "Reference", x.referenceType = d, delete x.url, delete x.title;
    } else
      delete x.identifier, delete x.label;
    this.data.referenceType = void 0;
  }
  function J(x) {
    const d = this.sliceSerialize(x), z = this.stack[this.stack.length - 2];
    z.label = pt(d), z.identifier = fn(d).toLowerCase();
  }
  function tn() {
    const x = this.stack[this.stack.length - 1], d = this.resume(), z = this.stack[this.stack.length - 1];
    if (this.data.inReference = !0, z.type === "link") {
      const C = x.children;
      z.children = C;
    } else
      z.alt = d;
  }
  function l() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.url = x;
  }
  function K() {
    const x = this.resume(), d = this.stack[this.stack.length - 1];
    d.title = x;
  }
  function en() {
    this.data.inReference = void 0;
  }
  function o() {
    this.data.referenceType = "collapsed";
  }
  function X(x) {
    const d = this.resume(), z = this.stack[this.stack.length - 1];
    z.label = d, z.identifier = fn(this.sliceSerialize(x)).toLowerCase(), this.data.referenceType = "full";
  }
  function on(x) {
    this.data.characterReferenceType = x.type;
  }
  function j(x) {
    const d = this.sliceSerialize(x), z = this.data.characterReferenceType;
    let C;
    z ? (C = mt(d, z === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : C = Wn(d);
    const A = this.stack[this.stack.length - 1];
    A.value += C;
  }
  function gn(x) {
    const d = this.stack.pop();
    d.position.end = ln(x.end);
  }
  function an(x) {
    L.call(this, x);
    const d = this.stack[this.stack.length - 1];
    d.url = this.sliceSerialize(x);
  }
  function hn(x) {
    L.call(this, x);
    const d = this.stack[this.stack.length - 1];
    d.url = "mailto:" + this.sliceSerialize(x);
  }
  function pn() {
    return {
      type: "blockquote",
      children: []
    };
  }
  function Sn() {
    return {
      type: "code",
      lang: null,
      meta: null,
      value: ""
    };
  }
  function rt() {
    return {
      type: "inlineCode",
      value: ""
    };
  }
  function it() {
    return {
      type: "definition",
      identifier: "",
      label: null,
      title: null,
      url: ""
    };
  }
  function ut() {
    return {
      type: "emphasis",
      children: []
    };
  }
  function Pn() {
    return {
      type: "heading",
      // @ts-expect-error `depth` will be set later.
      depth: 0,
      children: []
    };
  }
  function An() {
    return {
      type: "break"
    };
  }
  function Ln() {
    return {
      type: "html",
      value: ""
    };
  }
  function at() {
    return {
      type: "image",
      title: null,
      url: "",
      alt: null
    };
  }
  function On() {
    return {
      type: "link",
      title: null,
      url: "",
      children: []
    };
  }
  function Mn(x) {
    return {
      type: "list",
      ordered: x.type === "listOrdered",
      start: null,
      spread: x._spread,
      children: []
    };
  }
  function lt(x) {
    return {
      type: "listItem",
      spread: x._spread,
      checked: null,
      children: []
    };
  }
  function st() {
    return {
      type: "paragraph",
      children: []
    };
  }
  function ot() {
    return {
      type: "strong",
      children: []
    };
  }
  function ct() {
    return {
      type: "text",
      value: ""
    };
  }
  function ht() {
    return {
      type: "thematicBreak"
    };
  }
}
function ln(n) {
  return {
    line: n.line,
    column: n.column,
    offset: n.offset
  };
}
function et(n, r) {
  let e = -1;
  for (; ++e < r.length; ) {
    const t = r[e];
    Array.isArray(t) ? et(n, t) : sr(n, t);
  }
}
function sr(n, r) {
  let e;
  for (e in r)
    if (tt.call(r, e))
      switch (e) {
        case "canContainEols": {
          const t = r[e];
          t && n[e].push(...t);
          break;
        }
        case "transforms": {
          const t = r[e];
          t && n[e].push(...t);
          break;
        }
        case "enter":
        case "exit": {
          const t = r[e];
          t && Object.assign(n[e], t);
          break;
        }
      }
}
function Un(n, r) {
  throw n ? new Error("Cannot close `" + n.type + "` (" + yn({
    start: n.start,
    end: n.end
  }) + "): a different token (`" + r.type + "`, " + yn({
    start: r.start,
    end: r.end
  }) + ") is open") : new Error("Cannot close document, a token (`" + r.type + "`, " + yn({
    start: r.start,
    end: r.end
  }) + ") is still open");
}
function gr(n) {
  const r = this;
  r.parser = e;
  function e(t) {
    return ar(t, {
      ...r.data("settings"),
      ...n,
      // Note: these options are not in the readme.
      // The goal is for them to be set by plugins on `data` instead of being
      // passed by users.
      extensions: r.data("micromarkExtensions") || [],
      mdastExtensions: r.data("fromMarkdownExtensions") || []
    });
  }
}
export {
  gr as default
};
