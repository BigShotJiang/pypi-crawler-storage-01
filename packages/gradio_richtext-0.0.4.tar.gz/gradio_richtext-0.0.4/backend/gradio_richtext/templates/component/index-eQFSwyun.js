import { V as Ce, a as At } from "./index-DMnw81c_.js";
import { o as It } from "./default-BwQc_qtq.js";
import { s as Fe, h as ye, f as Nt } from "./index-XASQ8rxc.js";
import { w as pt, s as Ct, h as Ot } from "./index-DGhvCri1.js";
function St(e) {
  const t = String(e), a = [];
  return { toOffset: o, toPoint: s };
  function s(E) {
    if (typeof E == "number" && E > -1 && E <= t.length) {
      let h = 0;
      for (; ; ) {
        let f = a[h];
        if (f === void 0) {
          const m = Oe(t, a[h - 1]);
          f = m === -1 ? t.length + 1 : m + 1, a[h] = f;
        }
        if (f > E)
          return {
            line: h + 1,
            column: E - (h > 0 ? a[h - 1] : 0) + 1,
            offset: E
          };
        h++;
      }
    }
  }
  function o(E) {
    if (E && typeof E.line == "number" && typeof E.column == "number" && !Number.isNaN(E.line) && !Number.isNaN(E.column)) {
      for (; a.length < E.line; ) {
        const f = a[a.length - 1], m = Oe(t, f), _ = m === -1 ? t.length + 1 : m + 1;
        if (f === _) break;
        a.push(_);
      }
      const h = (E.line > 1 ? a[E.line - 2] : 0) + E.column - 1;
      if (h < a[E.line - 1]) return h;
    }
  }
}
function Oe(e, t) {
  const a = e.indexOf("\r", t), s = e.indexOf(`
`, t);
  return s === -1 ? a : a === -1 || a + 1 === s ? s : a < s ? a : s;
}
const we = {}.hasOwnProperty, gt = Object.prototype;
function Lt(e, t) {
  const a = t || {};
  return fe(
    {
      file: a.file || void 0,
      location: !1,
      schema: a.space === "svg" ? Fe : ye,
      verbose: a.verbose || !1
    },
    e
  );
}
function fe(e, t) {
  let a;
  switch (t.nodeName) {
    case "#comment": {
      const s = (
        /** @type {DefaultTreeAdapterMap['commentNode']} */
        t
      );
      return a = { type: "comment", value: s.data }, J(e, s, a), a;
    }
    case "#document":
    case "#document-fragment": {
      const s = (
        /** @type {DefaultTreeAdapterMap['document'] | DefaultTreeAdapterMap['documentFragment']} */
        t
      ), o = "mode" in s ? s.mode === "quirks" || s.mode === "limited-quirks" : !1;
      if (a = {
        type: "root",
        children: Ye(e, t.childNodes),
        data: { quirksMode: o }
      }, e.file && e.location) {
        const E = String(e.file), h = St(E), f = h.toPoint(0), m = h.toPoint(E.length);
        a.position = { start: f, end: m };
      }
      return a;
    }
    case "#documentType": {
      const s = (
        /** @type {DefaultTreeAdapterMap['documentType']} */
        t
      );
      return a = { type: "doctype" }, J(e, s, a), a;
    }
    case "#text": {
      const s = (
        /** @type {DefaultTreeAdapterMap['textNode']} */
        t
      );
      return a = { type: "text", value: s.value }, J(e, s, a), a;
    }
    default:
      return a = Rt(
        e,
        /** @type {DefaultTreeAdapterMap['element']} */
        t
      ), a;
  }
}
function Ye(e, t) {
  let a = -1;
  const s = [];
  for (; ++a < t.length; ) {
    const o = (
      /** @type {RootContent} */
      fe(e, t[a])
    );
    s.push(o);
  }
  return s;
}
function Rt(e, t) {
  const a = e.schema;
  e.schema = t.namespaceURI === pt.svg ? Fe : ye;
  let s = -1;
  const o = {};
  for (; ++s < t.attrs.length; ) {
    const f = t.attrs[s], m = (f.prefix ? f.prefix + ":" : "") + f.name;
    we.call(gt, m) || (o[m] = f.value);
  }
  const h = (e.schema.space === "svg" ? Ct : Ot)(t.tagName, o, Ye(e, t.childNodes));
  if (J(e, t, h), h.tagName === "template") {
    const f = (
      /** @type {DefaultTreeAdapterMap['template']} */
      t
    ), m = f.sourceCodeLocation, _ = m && m.startTag && k(m.startTag), g = m && m.endTag && k(m.endTag), y = (
      /** @type {Root} */
      fe(e, f.content)
    );
    _ && g && e.file && (y.position = { start: _.end, end: g.start }), h.content = y;
  }
  return e.schema = a, h;
}
function J(e, t, a) {
  if ("sourceCodeLocation" in t && t.sourceCodeLocation && e.file) {
    const s = Dt(e, a, t.sourceCodeLocation);
    s && (e.location = !0, a.position = s);
  }
}
function Dt(e, t, a) {
  const s = k(a);
  if (t.type === "element") {
    const o = t.children[t.children.length - 1];
    if (s && !a.endTag && o && o.position && o.position.end && (s.end = Object.assign({}, o.position.end)), e.verbose) {
      const E = {};
      let h;
      if (a.attrs)
        for (h in a.attrs)
          we.call(a.attrs, h) && (E[Nt(e.schema, h).property] = k(
            a.attrs[h]
          ));
      It(a.startTag);
      const f = k(a.startTag), m = a.endTag ? k(a.endTag) : void 0, _ = { opening: f };
      m && (_.closing = m), _.properties = E, t.data = { position: _ };
    }
  }
  return s;
}
function k(e) {
  const t = Se({
    line: e.startLine,
    column: e.startCol,
    offset: e.startOffset
  }), a = Se({
    line: e.endLine,
    column: e.endCol,
    offset: e.endOffset
  });
  return t || a ? { start: t, end: a } : void 0;
}
function Se(e) {
  return e.line && e.column ? e : void 0;
}
const Pt = /* @__PURE__ */ new Set([
  65534,
  65535,
  131070,
  131071,
  196606,
  196607,
  262142,
  262143,
  327678,
  327679,
  393214,
  393215,
  458750,
  458751,
  524286,
  524287,
  589822,
  589823,
  655358,
  655359,
  720894,
  720895,
  786430,
  786431,
  851966,
  851967,
  917502,
  917503,
  983038,
  983039,
  1048574,
  1048575,
  1114110,
  1114111
]), A = "�";
var r;
(function(e) {
  e[e.EOF = -1] = "EOF", e[e.NULL = 0] = "NULL", e[e.TABULATION = 9] = "TABULATION", e[e.CARRIAGE_RETURN = 13] = "CARRIAGE_RETURN", e[e.LINE_FEED = 10] = "LINE_FEED", e[e.FORM_FEED = 12] = "FORM_FEED", e[e.SPACE = 32] = "SPACE", e[e.EXCLAMATION_MARK = 33] = "EXCLAMATION_MARK", e[e.QUOTATION_MARK = 34] = "QUOTATION_MARK", e[e.AMPERSAND = 38] = "AMPERSAND", e[e.APOSTROPHE = 39] = "APOSTROPHE", e[e.HYPHEN_MINUS = 45] = "HYPHEN_MINUS", e[e.SOLIDUS = 47] = "SOLIDUS", e[e.DIGIT_0 = 48] = "DIGIT_0", e[e.DIGIT_9 = 57] = "DIGIT_9", e[e.SEMICOLON = 59] = "SEMICOLON", e[e.LESS_THAN_SIGN = 60] = "LESS_THAN_SIGN", e[e.EQUALS_SIGN = 61] = "EQUALS_SIGN", e[e.GREATER_THAN_SIGN = 62] = "GREATER_THAN_SIGN", e[e.QUESTION_MARK = 63] = "QUESTION_MARK", e[e.LATIN_CAPITAL_A = 65] = "LATIN_CAPITAL_A", e[e.LATIN_CAPITAL_Z = 90] = "LATIN_CAPITAL_Z", e[e.RIGHT_SQUARE_BRACKET = 93] = "RIGHT_SQUARE_BRACKET", e[e.GRAVE_ACCENT = 96] = "GRAVE_ACCENT", e[e.LATIN_SMALL_A = 97] = "LATIN_SMALL_A", e[e.LATIN_SMALL_Z = 122] = "LATIN_SMALL_Z";
})(r || (r = {}));
const C = {
  DASH_DASH: "--",
  CDATA_START: "[CDATA[",
  DOCTYPE: "doctype",
  SCRIPT: "script",
  PUBLIC: "public",
  SYSTEM: "system"
};
function ve(e) {
  return e >= 55296 && e <= 57343;
}
function xt(e) {
  return e >= 56320 && e <= 57343;
}
function Mt(e, t) {
  return (e - 55296) * 1024 + 9216 + t;
}
function Qe(e) {
  return e !== 32 && e !== 10 && e !== 13 && e !== 9 && e !== 12 && e >= 1 && e <= 31 || e >= 127 && e <= 159;
}
function We(e) {
  return e >= 64976 && e <= 65007 || Pt.has(e);
}
var d;
(function(e) {
  e.controlCharacterInInputStream = "control-character-in-input-stream", e.noncharacterInInputStream = "noncharacter-in-input-stream", e.surrogateInInputStream = "surrogate-in-input-stream", e.nonVoidHtmlElementStartTagWithTrailingSolidus = "non-void-html-element-start-tag-with-trailing-solidus", e.endTagWithAttributes = "end-tag-with-attributes", e.endTagWithTrailingSolidus = "end-tag-with-trailing-solidus", e.unexpectedSolidusInTag = "unexpected-solidus-in-tag", e.unexpectedNullCharacter = "unexpected-null-character", e.unexpectedQuestionMarkInsteadOfTagName = "unexpected-question-mark-instead-of-tag-name", e.invalidFirstCharacterOfTagName = "invalid-first-character-of-tag-name", e.unexpectedEqualsSignBeforeAttributeName = "unexpected-equals-sign-before-attribute-name", e.missingEndTagName = "missing-end-tag-name", e.unexpectedCharacterInAttributeName = "unexpected-character-in-attribute-name", e.unknownNamedCharacterReference = "unknown-named-character-reference", e.missingSemicolonAfterCharacterReference = "missing-semicolon-after-character-reference", e.unexpectedCharacterAfterDoctypeSystemIdentifier = "unexpected-character-after-doctype-system-identifier", e.unexpectedCharacterInUnquotedAttributeValue = "unexpected-character-in-unquoted-attribute-value", e.eofBeforeTagName = "eof-before-tag-name", e.eofInTag = "eof-in-tag", e.missingAttributeValue = "missing-attribute-value", e.missingWhitespaceBetweenAttributes = "missing-whitespace-between-attributes", e.missingWhitespaceAfterDoctypePublicKeyword = "missing-whitespace-after-doctype-public-keyword", e.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers = "missing-whitespace-between-doctype-public-and-system-identifiers", e.missingWhitespaceAfterDoctypeSystemKeyword = "missing-whitespace-after-doctype-system-keyword", e.missingQuoteBeforeDoctypePublicIdentifier = "missing-quote-before-doctype-public-identifier", e.missingQuoteBeforeDoctypeSystemIdentifier = "missing-quote-before-doctype-system-identifier", e.missingDoctypePublicIdentifier = "missing-doctype-public-identifier", e.missingDoctypeSystemIdentifier = "missing-doctype-system-identifier", e.abruptDoctypePublicIdentifier = "abrupt-doctype-public-identifier", e.abruptDoctypeSystemIdentifier = "abrupt-doctype-system-identifier", e.cdataInHtmlContent = "cdata-in-html-content", e.incorrectlyOpenedComment = "incorrectly-opened-comment", e.eofInScriptHtmlCommentLikeText = "eof-in-script-html-comment-like-text", e.eofInDoctype = "eof-in-doctype", e.nestedComment = "nested-comment", e.abruptClosingOfEmptyComment = "abrupt-closing-of-empty-comment", e.eofInComment = "eof-in-comment", e.incorrectlyClosedComment = "incorrectly-closed-comment", e.eofInCdata = "eof-in-cdata", e.absenceOfDigitsInNumericCharacterReference = "absence-of-digits-in-numeric-character-reference", e.nullCharacterReference = "null-character-reference", e.surrogateCharacterReference = "surrogate-character-reference", e.characterReferenceOutsideUnicodeRange = "character-reference-outside-unicode-range", e.controlCharacterReference = "control-character-reference", e.noncharacterCharacterReference = "noncharacter-character-reference", e.missingWhitespaceBeforeDoctypeName = "missing-whitespace-before-doctype-name", e.missingDoctypeName = "missing-doctype-name", e.invalidCharacterSequenceAfterDoctypeName = "invalid-character-sequence-after-doctype-name", e.duplicateAttribute = "duplicate-attribute", e.nonConformingDoctype = "non-conforming-doctype", e.missingDoctype = "missing-doctype", e.misplacedDoctype = "misplaced-doctype", e.endTagWithoutMatchingOpenElement = "end-tag-without-matching-open-element", e.closingOfElementWithOpenChildElements = "closing-of-element-with-open-child-elements", e.disallowedContentInNoscriptInHead = "disallowed-content-in-noscript-in-head", e.openElementsLeftAfterEof = "open-elements-left-after-eof", e.abandonedHeadElementChild = "abandoned-head-element-child", e.misplacedStartTagForHeadElement = "misplaced-start-tag-for-head-element", e.nestedNoscriptInHead = "nested-noscript-in-head", e.eofInElementThatCanContainOnlyText = "eof-in-element-that-can-contain-only-text";
})(d || (d = {}));
const Bt = 65536;
class Ut {
  constructor(t) {
    this.handler = t, this.html = "", this.pos = -1, this.lastGapPos = -2, this.gapStack = [], this.skipNextNewLine = !1, this.lastChunkWritten = !1, this.endOfChunkHit = !1, this.bufferWaterline = Bt, this.isEol = !1, this.lineStartPos = 0, this.droppedBufferSize = 0, this.line = 1, this.lastErrOffset = -1;
  }
  /** The column on the current line. If we just saw a gap (eg. a surrogate pair), return the index before. */
  get col() {
    return this.pos - this.lineStartPos + +(this.lastGapPos !== this.pos);
  }
  get offset() {
    return this.droppedBufferSize + this.pos;
  }
  getError(t, a) {
    const { line: s, col: o, offset: E } = this, h = o + a, f = E + a;
    return {
      code: t,
      startLine: s,
      endLine: s,
      startCol: h,
      endCol: h,
      startOffset: f,
      endOffset: f
    };
  }
  _err(t) {
    this.handler.onParseError && this.lastErrOffset !== this.offset && (this.lastErrOffset = this.offset, this.handler.onParseError(this.getError(t, 0)));
  }
  _addGap() {
    this.gapStack.push(this.lastGapPos), this.lastGapPos = this.pos;
  }
  _processSurrogate(t) {
    if (this.pos !== this.html.length - 1) {
      const a = this.html.charCodeAt(this.pos + 1);
      if (xt(a))
        return this.pos++, this._addGap(), Mt(t, a);
    } else if (!this.lastChunkWritten)
      return this.endOfChunkHit = !0, r.EOF;
    return this._err(d.surrogateInInputStream), t;
  }
  willDropParsedChunk() {
    return this.pos > this.bufferWaterline;
  }
  dropParsedChunk() {
    this.willDropParsedChunk() && (this.html = this.html.substring(this.pos), this.lineStartPos -= this.pos, this.droppedBufferSize += this.pos, this.pos = 0, this.lastGapPos = -2, this.gapStack.length = 0);
  }
  write(t, a) {
    this.html.length > 0 ? this.html += t : this.html = t, this.endOfChunkHit = !1, this.lastChunkWritten = a;
  }
  insertHtmlAtCurrentPos(t) {
    this.html = this.html.substring(0, this.pos + 1) + t + this.html.substring(this.pos + 1), this.endOfChunkHit = !1;
  }
  startsWith(t, a) {
    if (this.pos + t.length > this.html.length)
      return this.endOfChunkHit = !this.lastChunkWritten, !1;
    if (a)
      return this.html.startsWith(t, this.pos);
    for (let s = 0; s < t.length; s++)
      if ((this.html.charCodeAt(this.pos + s) | 32) !== t.charCodeAt(s))
        return !1;
    return !0;
  }
  peek(t) {
    const a = this.pos + t;
    if (a >= this.html.length)
      return this.endOfChunkHit = !this.lastChunkWritten, r.EOF;
    const s = this.html.charCodeAt(a);
    return s === r.CARRIAGE_RETURN ? r.LINE_FEED : s;
  }
  advance() {
    if (this.pos++, this.isEol && (this.isEol = !1, this.line++, this.lineStartPos = this.pos), this.pos >= this.html.length)
      return this.endOfChunkHit = !this.lastChunkWritten, r.EOF;
    let t = this.html.charCodeAt(this.pos);
    return t === r.CARRIAGE_RETURN ? (this.isEol = !0, this.skipNextNewLine = !0, r.LINE_FEED) : t === r.LINE_FEED && (this.isEol = !0, this.skipNextNewLine) ? (this.line--, this.skipNextNewLine = !1, this._addGap(), this.advance()) : (this.skipNextNewLine = !1, ve(t) && (t = this._processSurrogate(t)), this.handler.onParseError === null || t > 31 && t < 127 || t === r.LINE_FEED || t === r.CARRIAGE_RETURN || t > 159 && t < 64976 || this._checkForProblematicCharacters(t), t);
  }
  _checkForProblematicCharacters(t) {
    Qe(t) ? this._err(d.controlCharacterInInputStream) : We(t) && this._err(d.noncharacterInInputStream);
  }
  retreat(t) {
    for (this.pos -= t; this.pos < this.lastGapPos; )
      this.lastGapPos = this.gapStack.pop(), this.pos--;
    this.isEol = !1;
  }
}
var b;
(function(e) {
  e[e.CHARACTER = 0] = "CHARACTER", e[e.NULL_CHARACTER = 1] = "NULL_CHARACTER", e[e.WHITESPACE_CHARACTER = 2] = "WHITESPACE_CHARACTER", e[e.START_TAG = 3] = "START_TAG", e[e.END_TAG = 4] = "END_TAG", e[e.COMMENT = 5] = "COMMENT", e[e.DOCTYPE = 6] = "DOCTYPE", e[e.EOF = 7] = "EOF", e[e.HIBERNATION = 8] = "HIBERNATION";
})(b || (b = {}));
function qe(e, t) {
  for (let a = e.attrs.length - 1; a >= 0; a--)
    if (e.attrs[a].name === t)
      return e.attrs[a].value;
  return null;
}
const Ht = /* @__PURE__ */ new Uint16Array(
  // prettier-ignore
  /* @__PURE__ */ 'ᵁ<Õıʊҝջאٵ۞ޢߖࠏ੊ઑඡ๭༉༦჊ረዡᐕᒝᓃᓟᔥ\0\0\0\0\0\0ᕫᛍᦍᰒᷝ὾⁠↰⊍⏀⏻⑂⠤⤒ⴈ⹈⿎〖㊺㘹㞬㣾㨨㩱㫠㬮ࠀEMabcfglmnoprstu\\bfms¦³¹ÈÏlig耻Æ䃆P耻&䀦cute耻Á䃁reve;䄂Āiyx}rc耻Â䃂;䐐r;쀀𝔄rave耻À䃀pha;䎑acr;䄀d;橓Āgp¡on;䄄f;쀀𝔸plyFunction;恡ing耻Å䃅Ācs¾Ãr;쀀𝒜ign;扔ilde耻Ã䃃ml耻Ä䃄ЀaceforsuåûþėĜĢħĪĀcrêòkslash;或Ŷöø;櫧ed;挆y;䐑ƀcrtąċĔause;戵noullis;愬a;䎒r;쀀𝔅pf;쀀𝔹eve;䋘còēmpeq;扎܀HOacdefhilorsuōőŖƀƞƢƵƷƺǜȕɳɸɾcy;䐧PY耻©䂩ƀcpyŝŢźute;䄆Ā;iŧŨ拒talDifferentialD;慅leys;愭ȀaeioƉƎƔƘron;䄌dil耻Ç䃇rc;䄈nint;戰ot;䄊ĀdnƧƭilla;䂸terDot;䂷òſi;䎧rcleȀDMPTǇǋǑǖot;抙inus;抖lus;投imes;抗oĀcsǢǸkwiseContourIntegral;戲eCurlyĀDQȃȏoubleQuote;思uote;怙ȀlnpuȞȨɇɕonĀ;eȥȦ户;橴ƀgitȯȶȺruent;扡nt;戯ourIntegral;戮ĀfrɌɎ;愂oduct;成nterClockwiseContourIntegral;戳oss;樯cr;쀀𝒞pĀ;Cʄʅ拓ap;才րDJSZacefiosʠʬʰʴʸˋ˗ˡ˦̳ҍĀ;oŹʥtrahd;椑cy;䐂cy;䐅cy;䐏ƀgrsʿ˄ˇger;怡r;憡hv;櫤Āayː˕ron;䄎;䐔lĀ;t˝˞戇a;䎔r;쀀𝔇Āaf˫̧Ācm˰̢riticalȀADGT̖̜̀̆cute;䂴oŴ̋̍;䋙bleAcute;䋝rave;䁠ilde;䋜ond;拄ferentialD;慆Ѱ̽\0\0\0͔͂\0Ѕf;쀀𝔻ƀ;DE͈͉͍䂨ot;惜qual;扐blèCDLRUVͣͲ΂ϏϢϸontourIntegraìȹoɴ͹\0\0ͻ»͉nArrow;懓Āeo·ΤftƀARTΐΖΡrrow;懐ightArrow;懔eåˊngĀLRΫτeftĀARγιrrow;柸ightArrow;柺ightArrow;柹ightĀATϘϞrrow;懒ee;抨pɁϩ\0\0ϯrrow;懑ownArrow;懕erticalBar;戥ǹABLRTaВЪаўѿͼrrowƀ;BUНОТ憓ar;椓pArrow;懵reve;䌑eft˒к\0ц\0ѐightVector;楐eeVector;楞ectorĀ;Bљњ憽ar;楖ightǔѧ\0ѱeeVector;楟ectorĀ;BѺѻ懁ar;楗eeĀ;A҆҇护rrow;憧ĀctҒҗr;쀀𝒟rok;䄐ࠀNTacdfglmopqstuxҽӀӄӋӞӢӧӮӵԡԯԶՒ՝ՠեG;䅊H耻Ð䃐cute耻É䃉ƀaiyӒӗӜron;䄚rc耻Ê䃊;䐭ot;䄖r;쀀𝔈rave耻È䃈ement;戈ĀapӺӾcr;䄒tyɓԆ\0\0ԒmallSquare;旻erySmallSquare;斫ĀgpԦԪon;䄘f;쀀𝔼silon;䎕uĀaiԼՉlĀ;TՂՃ橵ilde;扂librium;懌Āci՗՚r;愰m;橳a;䎗ml耻Ë䃋Āipժկsts;戃onentialE;慇ʀcfiosօֈ֍ֲ׌y;䐤r;쀀𝔉lledɓ֗\0\0֣mallSquare;旼erySmallSquare;斪Ͱֺ\0ֿ\0\0ׄf;쀀𝔽All;戀riertrf;愱cò׋؀JTabcdfgorstר׬ׯ׺؀ؒؖ؛؝أ٬ٲcy;䐃耻>䀾mmaĀ;d׷׸䎓;䏜reve;䄞ƀeiy؇،ؐdil;䄢rc;䄜;䐓ot;䄠r;쀀𝔊;拙pf;쀀𝔾eater̀EFGLSTصلَٖٛ٦qualĀ;Lؾؿ扥ess;招ullEqual;执reater;檢ess;扷lantEqual;橾ilde;扳cr;쀀𝒢;扫ЀAacfiosuڅڋږڛڞڪھۊRDcy;䐪Āctڐڔek;䋇;䁞irc;䄤r;愌lbertSpace;愋ǰگ\0ڲf;愍izontalLine;攀Āctۃۅòکrok;䄦mpńېۘownHumðįqual;扏܀EJOacdfgmnostuۺ۾܃܇܎ܚܞܡܨ݄ݸދޏޕcy;䐕lig;䄲cy;䐁cute耻Í䃍Āiyܓܘrc耻Î䃎;䐘ot;䄰r;愑rave耻Ì䃌ƀ;apܠܯܿĀcgܴܷr;䄪inaryI;慈lieóϝǴ݉\0ݢĀ;eݍݎ戬Āgrݓݘral;戫section;拂isibleĀCTݬݲomma;恣imes;恢ƀgptݿރވon;䄮f;쀀𝕀a;䎙cr;愐ilde;䄨ǫޚ\0ޞcy;䐆l耻Ï䃏ʀcfosuެ޷޼߂ߐĀiyޱ޵rc;䄴;䐙r;쀀𝔍pf;쀀𝕁ǣ߇\0ߌr;쀀𝒥rcy;䐈kcy;䐄΀HJacfosߤߨ߽߬߱ࠂࠈcy;䐥cy;䐌ppa;䎚Āey߶߻dil;䄶;䐚r;쀀𝔎pf;쀀𝕂cr;쀀𝒦րJTaceflmostࠥࠩࠬࡐࡣ঳সে্਷ੇcy;䐉耻<䀼ʀcmnpr࠷࠼ࡁࡄࡍute;䄹bda;䎛g;柪lacetrf;愒r;憞ƀaeyࡗ࡜ࡡron;䄽dil;䄻;䐛Āfsࡨ॰tԀACDFRTUVarࡾࢩࢱࣦ࣠ࣼयज़ΐ४Ānrࢃ࢏gleBracket;柨rowƀ;BR࢙࢚࢞憐ar;懤ightArrow;懆eiling;挈oǵࢷ\0ࣃbleBracket;柦nǔࣈ\0࣒eeVector;楡ectorĀ;Bࣛࣜ懃ar;楙loor;挊ightĀAV࣯ࣵrrow;憔ector;楎Āerँगeƀ;AVउऊऐ抣rrow;憤ector;楚iangleƀ;BEतथऩ抲ar;槏qual;抴pƀDTVषूौownVector;楑eeVector;楠ectorĀ;Bॖॗ憿ar;楘ectorĀ;B॥०憼ar;楒ightáΜs̀EFGLSTॾঋকঝঢভqualGreater;拚ullEqual;扦reater;扶ess;檡lantEqual;橽ilde;扲r;쀀𝔏Ā;eঽা拘ftarrow;懚idot;䄿ƀnpw৔ਖਛgȀLRlr৞৷ਂਐeftĀAR০৬rrow;柵ightArrow;柷ightArrow;柶eftĀarγਊightáοightáϊf;쀀𝕃erĀLRਢਬeftArrow;憙ightArrow;憘ƀchtਾੀੂòࡌ;憰rok;䅁;扪Ѐacefiosuਗ਼੝੠੷੼અઋ઎p;椅y;䐜Ādl੥੯iumSpace;恟lintrf;愳r;쀀𝔐nusPlus;戓pf;쀀𝕄cò੶;䎜ҀJacefostuણધભીଔଙඑ඗ඞcy;䐊cute;䅃ƀaey઴હાron;䅇dil;䅅;䐝ƀgswે૰଎ativeƀMTV૓૟૨ediumSpace;怋hiĀcn૦૘ë૙eryThiî૙tedĀGL૸ଆreaterGreateòٳessLesóੈLine;䀊r;쀀𝔑ȀBnptଢନଷ଺reak;恠BreakingSpace;䂠f;愕ڀ;CDEGHLNPRSTV୕ୖ୪୼஡௫ఄ౞಄ದ೘ൡඅ櫬Āou୛୤ngruent;扢pCap;扭oubleVerticalBar;戦ƀlqxஃஊ஛ement;戉ualĀ;Tஒஓ扠ilde;쀀≂̸ists;戄reater΀;EFGLSTஶஷ஽௉௓௘௥扯qual;扱ullEqual;쀀≧̸reater;쀀≫̸ess;批lantEqual;쀀⩾̸ilde;扵umpń௲௽ownHump;쀀≎̸qual;쀀≏̸eĀfsఊధtTriangleƀ;BEచఛడ拪ar;쀀⧏̸qual;括s̀;EGLSTవశ఼ౄోౘ扮qual;扰reater;扸ess;쀀≪̸lantEqual;쀀⩽̸ilde;扴estedĀGL౨౹reaterGreater;쀀⪢̸essLess;쀀⪡̸recedesƀ;ESಒಓಛ技qual;쀀⪯̸lantEqual;拠ĀeiಫಹverseElement;戌ghtTriangleƀ;BEೋೌ೒拫ar;쀀⧐̸qual;拭ĀquೝഌuareSuĀbp೨೹setĀ;E೰ೳ쀀⊏̸qual;拢ersetĀ;Eഃആ쀀⊐̸qual;拣ƀbcpഓതൎsetĀ;Eഛഞ쀀⊂⃒qual;抈ceedsȀ;ESTലള഻െ抁qual;쀀⪰̸lantEqual;拡ilde;쀀≿̸ersetĀ;E൘൛쀀⊃⃒qual;抉ildeȀ;EFT൮൯൵ൿ扁qual;扄ullEqual;扇ilde;扉erticalBar;戤cr;쀀𝒩ilde耻Ñ䃑;䎝܀Eacdfgmoprstuvලෂ෉෕ෛ෠෧෼ขภยา฿ไlig;䅒cute耻Ó䃓Āiy෎ීrc耻Ô䃔;䐞blac;䅐r;쀀𝔒rave耻Ò䃒ƀaei෮ෲ෶cr;䅌ga;䎩cron;䎟pf;쀀𝕆enCurlyĀDQฎบoubleQuote;怜uote;怘;橔Āclวฬr;쀀𝒪ash耻Ø䃘iŬื฼de耻Õ䃕es;樷ml耻Ö䃖erĀBP๋๠Āar๐๓r;怾acĀek๚๜;揞et;掴arenthesis;揜Ҁacfhilors๿ງຊຏຒດຝະ໼rtialD;戂y;䐟r;쀀𝔓i;䎦;䎠usMinus;䂱Āipຢອncareplanåڝf;愙Ȁ;eio຺ູ໠໤檻cedesȀ;EST່້໏໚扺qual;檯lantEqual;扼ilde;找me;怳Ādp໩໮uct;戏ortionĀ;aȥ໹l;戝Āci༁༆r;쀀𝒫;䎨ȀUfos༑༖༛༟OT耻"䀢r;쀀𝔔pf;愚cr;쀀𝒬؀BEacefhiorsu༾གྷཇའཱིྦྷྪྭ႖ႩႴႾarr;椐G耻®䂮ƀcnrཎནབute;䅔g;柫rĀ;tཛྷཝ憠l;椖ƀaeyཧཬཱron;䅘dil;䅖;䐠Ā;vླྀཹ愜erseĀEUྂྙĀlq྇ྎement;戋uilibrium;懋pEquilibrium;楯r»ཹo;䎡ghtЀACDFTUVa࿁࿫࿳ဢဨၛႇϘĀnr࿆࿒gleBracket;柩rowƀ;BL࿜࿝࿡憒ar;懥eftArrow;懄eiling;按oǵ࿹\0စbleBracket;柧nǔည\0နeeVector;楝ectorĀ;Bဝသ懂ar;楕loor;挋Āerိ၃eƀ;AVဵံြ抢rrow;憦ector;楛iangleƀ;BEၐၑၕ抳ar;槐qual;抵pƀDTVၣၮၸownVector;楏eeVector;楜ectorĀ;Bႂႃ憾ar;楔ectorĀ;B႑႒懀ar;楓Āpuႛ႞f;愝ndImplies;楰ightarrow;懛ĀchႹႼr;愛;憱leDelayed;槴ڀHOacfhimoqstuფჱჷჽᄙᄞᅑᅖᅡᅧᆵᆻᆿĀCcჩხHcy;䐩y;䐨FTcy;䐬cute;䅚ʀ;aeiyᄈᄉᄎᄓᄗ檼ron;䅠dil;䅞rc;䅜;䐡r;쀀𝔖ortȀDLRUᄪᄴᄾᅉownArrow»ОeftArrow»࢚ightArrow»࿝pArrow;憑gma;䎣allCircle;战pf;쀀𝕊ɲᅭ\0\0ᅰt;戚areȀ;ISUᅻᅼᆉᆯ斡ntersection;抓uĀbpᆏᆞsetĀ;Eᆗᆘ抏qual;抑ersetĀ;Eᆨᆩ抐qual;抒nion;抔cr;쀀𝒮ar;拆ȀbcmpᇈᇛሉላĀ;sᇍᇎ拐etĀ;Eᇍᇕqual;抆ĀchᇠህeedsȀ;ESTᇭᇮᇴᇿ扻qual;檰lantEqual;扽ilde;承Tháྌ;我ƀ;esሒሓሣ拑rsetĀ;Eሜም抃qual;抇et»ሓրHRSacfhiorsሾቄ቉ቕ቞ቱቶኟዂወዑORN耻Þ䃞ADE;愢ĀHc቎ቒcy;䐋y;䐦Ābuቚቜ;䀉;䎤ƀaeyብቪቯron;䅤dil;䅢;䐢r;쀀𝔗Āeiቻ኉ǲኀ\0ኇefore;戴a;䎘Ācn኎ኘkSpace;쀀  Space;怉ldeȀ;EFTካኬኲኼ戼qual;扃ullEqual;扅ilde;扈pf;쀀𝕋ipleDot;惛Āctዖዛr;쀀𝒯rok;䅦ૡዷጎጚጦ\0ጬጱ\0\0\0\0\0ጸጽ፷ᎅ\0᏿ᐄᐊᐐĀcrዻጁute耻Ú䃚rĀ;oጇገ憟cir;楉rǣጓ\0጖y;䐎ve;䅬Āiyጞጣrc耻Û䃛;䐣blac;䅰r;쀀𝔘rave耻Ù䃙acr;䅪Ādiፁ፩erĀBPፈ፝Āarፍፐr;䁟acĀekፗፙ;揟et;掵arenthesis;揝onĀ;P፰፱拃lus;抎Āgp፻፿on;䅲f;쀀𝕌ЀADETadps᎕ᎮᎸᏄϨᏒᏗᏳrrowƀ;BDᅐᎠᎤar;椒ownArrow;懅ownArrow;憕quilibrium;楮eeĀ;AᏋᏌ报rrow;憥ownáϳerĀLRᏞᏨeftArrow;憖ightArrow;憗iĀ;lᏹᏺ䏒on;䎥ing;䅮cr;쀀𝒰ilde;䅨ml耻Ü䃜ҀDbcdefosvᐧᐬᐰᐳᐾᒅᒊᒐᒖash;披ar;櫫y;䐒ashĀ;lᐻᐼ抩;櫦Āerᑃᑅ;拁ƀbtyᑌᑐᑺar;怖Ā;iᑏᑕcalȀBLSTᑡᑥᑪᑴar;戣ine;䁼eparator;杘ilde;所ThinSpace;怊r;쀀𝔙pf;쀀𝕍cr;쀀𝒱dash;抪ʀcefosᒧᒬᒱᒶᒼirc;䅴dge;拀r;쀀𝔚pf;쀀𝕎cr;쀀𝒲Ȁfiosᓋᓐᓒᓘr;쀀𝔛;䎞pf;쀀𝕏cr;쀀𝒳ҀAIUacfosuᓱᓵᓹᓽᔄᔏᔔᔚᔠcy;䐯cy;䐇cy;䐮cute耻Ý䃝Āiyᔉᔍrc;䅶;䐫r;쀀𝔜pf;쀀𝕐cr;쀀𝒴ml;䅸ЀHacdefosᔵᔹᔿᕋᕏᕝᕠᕤcy;䐖cute;䅹Āayᕄᕉron;䅽;䐗ot;䅻ǲᕔ\0ᕛoWidtè૙a;䎖r;愨pf;愤cr;쀀𝒵௡ᖃᖊᖐ\0ᖰᖶᖿ\0\0\0\0ᗆᗛᗫᙟ᙭\0ᚕ᚛ᚲᚹ\0ᚾcute耻á䃡reve;䄃̀;Ediuyᖜᖝᖡᖣᖨᖭ戾;쀀∾̳;房rc耻â䃢te肻´̆;䐰lig耻æ䃦Ā;r²ᖺ;쀀𝔞rave耻à䃠ĀepᗊᗖĀfpᗏᗔsym;愵èᗓha;䎱ĀapᗟcĀclᗤᗧr;䄁g;樿ɤᗰ\0\0ᘊʀ;adsvᗺᗻᗿᘁᘇ戧nd;橕;橜lope;橘;橚΀;elmrszᘘᘙᘛᘞᘿᙏᙙ戠;榤e»ᘙsdĀ;aᘥᘦ戡ѡᘰᘲᘴᘶᘸᘺᘼᘾ;榨;榩;榪;榫;榬;榭;榮;榯tĀ;vᙅᙆ戟bĀ;dᙌᙍ抾;榝Āptᙔᙗh;戢»¹arr;捼Āgpᙣᙧon;䄅f;쀀𝕒΀;Eaeiop዁ᙻᙽᚂᚄᚇᚊ;橰cir;橯;扊d;手s;䀧roxĀ;e዁ᚒñᚃing耻å䃥ƀctyᚡᚦᚨr;쀀𝒶;䀪mpĀ;e዁ᚯñʈilde耻ã䃣ml耻ä䃤Āciᛂᛈoninôɲnt;樑ࠀNabcdefiklnoprsu᛭ᛱᜰ᜼ᝃᝈ᝸᝽០៦ᠹᡐᜍ᤽᥈ᥰot;櫭Ācrᛶ᜞kȀcepsᜀᜅᜍᜓong;扌psilon;䏶rime;怵imĀ;e᜚᜛戽q;拍Ŷᜢᜦee;抽edĀ;gᜬᜭ挅e»ᜭrkĀ;t፜᜷brk;掶Āoyᜁᝁ;䐱quo;怞ʀcmprtᝓ᝛ᝡᝤᝨausĀ;eĊĉptyv;榰séᜌnoõēƀahwᝯ᝱ᝳ;䎲;愶een;扬r;쀀𝔟g΀costuvwឍឝឳេ៕៛៞ƀaiuបពរðݠrc;旯p»፱ƀdptឤឨឭot;樀lus;樁imes;樂ɱឹ\0\0ើcup;樆ar;昅riangleĀdu៍្own;施p;斳plus;樄eåᑄåᒭarow;植ƀako៭ᠦᠵĀcn៲ᠣkƀlst៺֫᠂ozenge;槫riangleȀ;dlr᠒᠓᠘᠝斴own;斾eft;旂ight;斸k;搣Ʊᠫ\0ᠳƲᠯ\0ᠱ;斒;斑4;斓ck;斈ĀeoᠾᡍĀ;qᡃᡆ쀀=⃥uiv;쀀≡⃥t;挐Ȁptwxᡙᡞᡧᡬf;쀀𝕓Ā;tᏋᡣom»Ꮜtie;拈؀DHUVbdhmptuvᢅᢖᢪᢻᣗᣛᣬ᣿ᤅᤊᤐᤡȀLRlrᢎᢐᢒᢔ;敗;敔;敖;敓ʀ;DUduᢡᢢᢤᢦᢨ敐;敦;敩;敤;敧ȀLRlrᢳᢵᢷᢹ;敝;敚;敜;教΀;HLRhlrᣊᣋᣍᣏᣑᣓᣕ救;敬;散;敠;敫;敢;敟ox;槉ȀLRlrᣤᣦᣨᣪ;敕;敒;攐;攌ʀ;DUduڽ᣷᣹᣻᣽;敥;敨;攬;攴inus;抟lus;択imes;抠ȀLRlrᤙᤛᤝ᤟;敛;敘;攘;攔΀;HLRhlrᤰᤱᤳᤵᤷ᤻᤹攂;敪;敡;敞;攼;攤;攜Āevģ᥂bar耻¦䂦Ȁceioᥑᥖᥚᥠr;쀀𝒷mi;恏mĀ;e᜚᜜lƀ;bhᥨᥩᥫ䁜;槅sub;柈Ŭᥴ᥾lĀ;e᥹᥺怢t»᥺pƀ;Eeįᦅᦇ;檮Ā;qۜۛೡᦧ\0᧨ᨑᨕᨲ\0ᨷᩐ\0\0᪴\0\0᫁\0\0ᬡᬮ᭍᭒\0᯽\0ᰌƀcpr᦭ᦲ᧝ute;䄇̀;abcdsᦿᧀᧄ᧊᧕᧙戩nd;橄rcup;橉Āau᧏᧒p;橋p;橇ot;橀;쀀∩︀Āeo᧢᧥t;恁îړȀaeiu᧰᧻ᨁᨅǰ᧵\0᧸s;橍on;䄍dil耻ç䃧rc;䄉psĀ;sᨌᨍ橌m;橐ot;䄋ƀdmnᨛᨠᨦil肻¸ƭptyv;榲t脀¢;eᨭᨮ䂢räƲr;쀀𝔠ƀceiᨽᩀᩍy;䑇ckĀ;mᩇᩈ朓ark»ᩈ;䏇r΀;Ecefms᩟᩠ᩢᩫ᪤᪪᪮旋;槃ƀ;elᩩᩪᩭ䋆q;扗eɡᩴ\0\0᪈rrowĀlr᩼᪁eft;憺ight;憻ʀRSacd᪒᪔᪖᪚᪟»ཇ;擈st;抛irc;抚ash;抝nint;樐id;櫯cir;槂ubsĀ;u᪻᪼晣it»᪼ˬ᫇᫔᫺\0ᬊonĀ;eᫍᫎ䀺Ā;qÇÆɭ᫙\0\0᫢aĀ;t᫞᫟䀬;䁀ƀ;fl᫨᫩᫫戁îᅠeĀmx᫱᫶ent»᫩eóɍǧ᫾\0ᬇĀ;dኻᬂot;橭nôɆƀfryᬐᬔᬗ;쀀𝕔oäɔ脀©;sŕᬝr;愗Āaoᬥᬩrr;憵ss;朗Ācuᬲᬷr;쀀𝒸Ābpᬼ᭄Ā;eᭁᭂ櫏;櫑Ā;eᭉᭊ櫐;櫒dot;拯΀delprvw᭠᭬᭷ᮂᮬᯔ᯹arrĀlr᭨᭪;椸;椵ɰ᭲\0\0᭵r;拞c;拟arrĀ;p᭿ᮀ憶;椽̀;bcdosᮏᮐᮖᮡᮥᮨ截rcap;橈Āauᮛᮞp;橆p;橊ot;抍r;橅;쀀∪︀Ȁalrv᮵ᮿᯞᯣrrĀ;mᮼᮽ憷;椼yƀevwᯇᯔᯘqɰᯎ\0\0ᯒreã᭳uã᭵ee;拎edge;拏en耻¤䂤earrowĀlrᯮ᯳eft»ᮀight»ᮽeäᯝĀciᰁᰇoninôǷnt;戱lcty;挭ঀAHabcdefhijlorstuwz᰸᰻᰿ᱝᱩᱵᲊᲞᲬᲷ᳻᳿ᴍᵻᶑᶫᶻ᷆᷍rò΁ar;楥Ȁglrs᱈ᱍ᱒᱔ger;怠eth;愸òᄳhĀ;vᱚᱛ怐»ऊūᱡᱧarow;椏aã̕Āayᱮᱳron;䄏;䐴ƀ;ao̲ᱼᲄĀgrʿᲁr;懊tseq;橷ƀglmᲑᲔᲘ耻°䂰ta;䎴ptyv;榱ĀirᲣᲨsht;楿;쀀𝔡arĀlrᲳᲵ»ࣜ»သʀaegsv᳂͸᳖᳜᳠mƀ;oș᳊᳔ndĀ;ș᳑uit;晦amma;䏝in;拲ƀ;io᳧᳨᳸䃷de脀÷;o᳧ᳰntimes;拇nø᳷cy;䑒cɯᴆ\0\0ᴊrn;挞op;挍ʀlptuwᴘᴝᴢᵉᵕlar;䀤f;쀀𝕕ʀ;emps̋ᴭᴷᴽᵂqĀ;d͒ᴳot;扑inus;戸lus;戔quare;抡blebarwedgåúnƀadhᄮᵝᵧownarrowóᲃarpoonĀlrᵲᵶefôᲴighôᲶŢᵿᶅkaro÷གɯᶊ\0\0ᶎrn;挟op;挌ƀcotᶘᶣᶦĀryᶝᶡ;쀀𝒹;䑕l;槶rok;䄑Ādrᶰᶴot;拱iĀ;fᶺ᠖斿Āah᷀᷃ròЩaòྦangle;榦Āci᷒ᷕy;䑟grarr;柿ऀDacdefglmnopqrstuxḁḉḙḸոḼṉṡṾấắẽỡἪἷὄ὎὚ĀDoḆᴴoôᲉĀcsḎḔute耻é䃩ter;橮ȀaioyḢḧḱḶron;䄛rĀ;cḭḮ扖耻ê䃪lon;払;䑍ot;䄗ĀDrṁṅot;扒;쀀𝔢ƀ;rsṐṑṗ檚ave耻è䃨Ā;dṜṝ檖ot;檘Ȁ;ilsṪṫṲṴ檙nters;揧;愓Ā;dṹṺ檕ot;檗ƀapsẅẉẗcr;䄓tyƀ;svẒẓẕ戅et»ẓpĀ1;ẝẤĳạả;怄;怅怃ĀgsẪẬ;䅋p;怂ĀgpẴẸon;䄙f;쀀𝕖ƀalsỄỎỒrĀ;sỊị拕l;槣us;橱iƀ;lvỚớở䎵on»ớ;䏵ȀcsuvỪỳἋἣĀioữḱrc»Ḯɩỹ\0\0ỻíՈantĀglἂἆtr»ṝess»Ṻƀaeiἒ἖Ἒls;䀽st;扟vĀ;DȵἠD;橸parsl;槥ĀDaἯἳot;打rr;楱ƀcdiἾὁỸr;愯oô͒ĀahὉὋ;䎷耻ð䃰Āmrὓὗl耻ë䃫o;悬ƀcipὡὤὧl;䀡sôծĀeoὬὴctatioîՙnentialåչৡᾒ\0ᾞ\0ᾡᾧ\0\0ῆῌ\0ΐ\0ῦῪ \0 ⁚llingdotseñṄy;䑄male;晀ƀilrᾭᾳ῁lig;耀ﬃɩᾹ\0\0᾽g;耀ﬀig;耀ﬄ;쀀𝔣lig;耀ﬁlig;쀀fjƀaltῙ῜ῡt;晭ig;耀ﬂns;斱of;䆒ǰ΅\0ῳf;쀀𝕗ĀakֿῷĀ;vῼ´拔;櫙artint;樍Āao‌⁕Ācs‑⁒α‚‰‸⁅⁈\0⁐β•‥‧‪‬\0‮耻½䂽;慓耻¼䂼;慕;慙;慛Ƴ‴\0‶;慔;慖ʴ‾⁁\0\0⁃耻¾䂾;慗;慜5;慘ƶ⁌\0⁎;慚;慝8;慞l;恄wn;挢cr;쀀𝒻ࢀEabcdefgijlnorstv₂₉₟₥₰₴⃰⃵⃺⃿℃ℒℸ̗ℾ⅒↞Ā;lٍ₇;檌ƀcmpₐₕ₝ute;䇵maĀ;dₜ᳚䎳;檆reve;䄟Āiy₪₮rc;䄝;䐳ot;䄡Ȁ;lqsؾق₽⃉ƀ;qsؾٌ⃄lanô٥Ȁ;cdl٥⃒⃥⃕c;檩otĀ;o⃜⃝檀Ā;l⃢⃣檂;檄Ā;e⃪⃭쀀⋛︀s;檔r;쀀𝔤Ā;gٳ؛mel;愷cy;䑓Ȁ;Eajٚℌℎℐ;檒;檥;檤ȀEaesℛℝ℩ℴ;扩pĀ;p℣ℤ檊rox»ℤĀ;q℮ℯ檈Ā;q℮ℛim;拧pf;쀀𝕘Āci⅃ⅆr;愊mƀ;el٫ⅎ⅐;檎;檐茀>;cdlqr׮ⅠⅪⅮⅳⅹĀciⅥⅧ;檧r;橺ot;拗Par;榕uest;橼ʀadelsↄⅪ←ٖ↛ǰ↉\0↎proø₞r;楸qĀlqؿ↖lesó₈ií٫Āen↣↭rtneqq;쀀≩︀Å↪ԀAabcefkosy⇄⇇⇱⇵⇺∘∝∯≨≽ròΠȀilmr⇐⇔⇗⇛rsðᒄf»․ilôکĀdr⇠⇤cy;䑊ƀ;cwࣴ⇫⇯ir;楈;憭ar;意irc;䄥ƀalr∁∎∓rtsĀ;u∉∊晥it»∊lip;怦con;抹r;쀀𝔥sĀew∣∩arow;椥arow;椦ʀamopr∺∾≃≞≣rr;懿tht;戻kĀlr≉≓eftarrow;憩ightarrow;憪f;쀀𝕙bar;怕ƀclt≯≴≸r;쀀𝒽asè⇴rok;䄧Ābp⊂⊇ull;恃hen»ᱛૡ⊣\0⊪\0⊸⋅⋎\0⋕⋳\0\0⋸⌢⍧⍢⍿\0⎆⎪⎴cute耻í䃭ƀ;iyݱ⊰⊵rc耻î䃮;䐸Ācx⊼⊿y;䐵cl耻¡䂡ĀfrΟ⋉;쀀𝔦rave耻ì䃬Ȁ;inoܾ⋝⋩⋮Āin⋢⋦nt;樌t;戭fin;槜ta;愩lig;䄳ƀaop⋾⌚⌝ƀcgt⌅⌈⌗r;䄫ƀelpܟ⌏⌓inåގarôܠh;䄱f;抷ed;䆵ʀ;cfotӴ⌬⌱⌽⍁are;愅inĀ;t⌸⌹戞ie;槝doô⌙ʀ;celpݗ⍌⍐⍛⍡al;抺Āgr⍕⍙eróᕣã⍍arhk;樗rod;樼Ȁcgpt⍯⍲⍶⍻y;䑑on;䄯f;쀀𝕚a;䎹uest耻¿䂿Āci⎊⎏r;쀀𝒾nʀ;EdsvӴ⎛⎝⎡ӳ;拹ot;拵Ā;v⎦⎧拴;拳Ā;iݷ⎮lde;䄩ǫ⎸\0⎼cy;䑖l耻ï䃯̀cfmosu⏌⏗⏜⏡⏧⏵Āiy⏑⏕rc;䄵;䐹r;쀀𝔧ath;䈷pf;쀀𝕛ǣ⏬\0⏱r;쀀𝒿rcy;䑘kcy;䑔Ѐacfghjos␋␖␢␧␭␱␵␻ppaĀ;v␓␔䎺;䏰Āey␛␠dil;䄷;䐺r;쀀𝔨reen;䄸cy;䑅cy;䑜pf;쀀𝕜cr;쀀𝓀஀ABEHabcdefghjlmnoprstuv⑰⒁⒆⒍⒑┎┽╚▀♎♞♥♹♽⚚⚲⛘❝❨➋⟀⠁⠒ƀart⑷⑺⑼rò৆òΕail;椛arr;椎Ā;gঔ⒋;檋ar;楢ॣ⒥\0⒪\0⒱\0\0\0\0\0⒵Ⓔ\0ⓆⓈⓍ\0⓹ute;䄺mptyv;榴raîࡌbda;䎻gƀ;dlࢎⓁⓃ;榑åࢎ;檅uo耻«䂫rЀ;bfhlpst࢙ⓞⓦⓩ⓫⓮⓱⓵Ā;f࢝ⓣs;椟s;椝ë≒p;憫l;椹im;楳l;憢ƀ;ae⓿─┄檫il;椙Ā;s┉┊檭;쀀⪭︀ƀabr┕┙┝rr;椌rk;杲Āak┢┬cĀek┨┪;䁻;䁛Āes┱┳;榋lĀdu┹┻;榏;榍Ȁaeuy╆╋╖╘ron;䄾Ādi═╔il;䄼ìࢰâ┩;䐻Ȁcqrs╣╦╭╽a;椶uoĀ;rนᝆĀdu╲╷har;楧shar;楋h;憲ʀ;fgqs▋▌উ◳◿扤tʀahlrt▘▤▷◂◨rrowĀ;t࢙□aé⓶arpoonĀdu▯▴own»њp»०eftarrows;懇ightƀahs◍◖◞rrowĀ;sࣴࢧarpoonó྘quigarro÷⇰hreetimes;拋ƀ;qs▋ও◺lanôবʀ;cdgsব☊☍☝☨c;檨otĀ;o☔☕橿Ā;r☚☛檁;檃Ā;e☢☥쀀⋚︀s;檓ʀadegs☳☹☽♉♋pproøⓆot;拖qĀgq♃♅ôউgtò⒌ôছiíলƀilr♕࣡♚sht;楼;쀀𝔩Ā;Eজ♣;檑š♩♶rĀdu▲♮Ā;l॥♳;楪lk;斄cy;䑙ʀ;achtੈ⚈⚋⚑⚖rò◁orneòᴈard;楫ri;旺Āio⚟⚤dot;䅀ustĀ;a⚬⚭掰che»⚭ȀEaes⚻⚽⛉⛔;扨pĀ;p⛃⛄檉rox»⛄Ā;q⛎⛏檇Ā;q⛎⚻im;拦Ѐabnoptwz⛩⛴⛷✚✯❁❇❐Ānr⛮⛱g;柬r;懽rëࣁgƀlmr⛿✍✔eftĀar০✇ightá৲apsto;柼ightá৽parrowĀlr✥✩efô⓭ight;憬ƀafl✶✹✽r;榅;쀀𝕝us;樭imes;樴š❋❏st;戗áፎƀ;ef❗❘᠀旊nge»❘arĀ;l❤❥䀨t;榓ʀachmt❳❶❼➅➇ròࢨorneòᶌarĀ;d྘➃;業;怎ri;抿̀achiqt➘➝ੀ➢➮➻quo;怹r;쀀𝓁mƀ;egল➪➬;檍;檏Ābu┪➳oĀ;rฟ➹;怚rok;䅂萀<;cdhilqrࠫ⟒☹⟜⟠⟥⟪⟰Āci⟗⟙;檦r;橹reå◲mes;拉arr;楶uest;橻ĀPi⟵⟹ar;榖ƀ;ef⠀भ᠛旃rĀdu⠇⠍shar;楊har;楦Āen⠗⠡rtneqq;쀀≨︀Å⠞܀Dacdefhilnopsu⡀⡅⢂⢎⢓⢠⢥⢨⣚⣢⣤ઃ⣳⤂Dot;戺Ȁclpr⡎⡒⡣⡽r耻¯䂯Āet⡗⡙;時Ā;e⡞⡟朠se»⡟Ā;sျ⡨toȀ;dluျ⡳⡷⡻owîҌefôएðᏑker;斮Āoy⢇⢌mma;権;䐼ash;怔asuredangle»ᘦr;쀀𝔪o;愧ƀcdn⢯⢴⣉ro耻µ䂵Ȁ;acdᑤ⢽⣀⣄sôᚧir;櫰ot肻·Ƶusƀ;bd⣒ᤃ⣓戒Ā;uᴼ⣘;横ţ⣞⣡p;櫛ò−ðઁĀdp⣩⣮els;抧f;쀀𝕞Āct⣸⣽r;쀀𝓂pos»ᖝƀ;lm⤉⤊⤍䎼timap;抸ఀGLRVabcdefghijlmoprstuvw⥂⥓⥾⦉⦘⧚⧩⨕⨚⩘⩝⪃⪕⪤⪨⬄⬇⭄⭿⮮ⰴⱧⱼ⳩Āgt⥇⥋;쀀⋙̸Ā;v⥐௏쀀≫⃒ƀelt⥚⥲⥶ftĀar⥡⥧rrow;懍ightarrow;懎;쀀⋘̸Ā;v⥻ే쀀≪⃒ightarrow;懏ĀDd⦎⦓ash;抯ash;抮ʀbcnpt⦣⦧⦬⦱⧌la»˞ute;䅄g;쀀∠⃒ʀ;Eiop඄⦼⧀⧅⧈;쀀⩰̸d;쀀≋̸s;䅉roø඄urĀ;a⧓⧔普lĀ;s⧓ସǳ⧟\0⧣p肻 ଷmpĀ;e௹ఀʀaeouy⧴⧾⨃⨐⨓ǰ⧹\0⧻;橃on;䅈dil;䅆ngĀ;dൾ⨊ot;쀀⩭̸p;橂;䐽ash;怓΀;Aadqsxஒ⨩⨭⨻⩁⩅⩐rr;懗rĀhr⨳⨶k;椤Ā;oᏲᏰot;쀀≐̸uiöୣĀei⩊⩎ar;椨í஘istĀ;s஠டr;쀀𝔫ȀEest௅⩦⩹⩼ƀ;qs஼⩭௡ƀ;qs஼௅⩴lanô௢ií௪Ā;rஶ⪁»ஷƀAap⪊⪍⪑rò⥱rr;憮ar;櫲ƀ;svྍ⪜ྌĀ;d⪡⪢拼;拺cy;䑚΀AEadest⪷⪺⪾⫂⫅⫶⫹rò⥦;쀀≦̸rr;憚r;急Ȁ;fqs఻⫎⫣⫯tĀar⫔⫙rro÷⫁ightarro÷⪐ƀ;qs఻⪺⫪lanôౕĀ;sౕ⫴»శiíౝĀ;rవ⫾iĀ;eచథiäඐĀpt⬌⬑f;쀀𝕟膀¬;in⬙⬚⬶䂬nȀ;Edvஉ⬤⬨⬮;쀀⋹̸ot;쀀⋵̸ǡஉ⬳⬵;拷;拶iĀ;vಸ⬼ǡಸ⭁⭃;拾;拽ƀaor⭋⭣⭩rȀ;ast୻⭕⭚⭟lleì୻l;쀀⫽⃥;쀀∂̸lint;樔ƀ;ceಒ⭰⭳uåಥĀ;cಘ⭸Ā;eಒ⭽ñಘȀAait⮈⮋⮝⮧rò⦈rrƀ;cw⮔⮕⮙憛;쀀⤳̸;쀀↝̸ghtarrow»⮕riĀ;eೋೖ΀chimpqu⮽⯍⯙⬄୸⯤⯯Ȁ;cerല⯆ഷ⯉uå൅;쀀𝓃ortɭ⬅\0\0⯖ará⭖mĀ;e൮⯟Ā;q൴൳suĀbp⯫⯭å೸åഋƀbcp⯶ⰑⰙȀ;Ees⯿ⰀഢⰄ抄;쀀⫅̸etĀ;eഛⰋqĀ;qണⰀcĀ;eലⰗñസȀ;EesⰢⰣൟⰧ抅;쀀⫆̸etĀ;e൘ⰮqĀ;qൠⰣȀgilrⰽⰿⱅⱇìௗlde耻ñ䃱çృiangleĀlrⱒⱜeftĀ;eచⱚñదightĀ;eೋⱥñ೗Ā;mⱬⱭ䎽ƀ;esⱴⱵⱹ䀣ro;愖p;怇ҀDHadgilrsⲏⲔⲙⲞⲣⲰⲶⳓⳣash;抭arr;椄p;쀀≍⃒ash;抬ĀetⲨⲬ;쀀≥⃒;쀀>⃒nfin;槞ƀAetⲽⳁⳅrr;椂;쀀≤⃒Ā;rⳊⳍ쀀<⃒ie;쀀⊴⃒ĀAtⳘⳜrr;椃rie;쀀⊵⃒im;쀀∼⃒ƀAan⳰⳴ⴂrr;懖rĀhr⳺⳽k;椣Ā;oᏧᏥear;椧ቓ᪕\0\0\0\0\0\0\0\0\0\0\0\0\0ⴭ\0ⴸⵈⵠⵥ⵲ⶄᬇ\0\0ⶍⶫ\0ⷈⷎ\0ⷜ⸙⸫⸾⹃Ācsⴱ᪗ute耻ó䃳ĀiyⴼⵅrĀ;c᪞ⵂ耻ô䃴;䐾ʀabios᪠ⵒⵗǈⵚlac;䅑v;樸old;榼lig;䅓Ācr⵩⵭ir;榿;쀀𝔬ͯ⵹\0\0⵼\0ⶂn;䋛ave耻ò䃲;槁Ābmⶈ෴ar;榵Ȁacitⶕ⶘ⶥⶨrò᪀Āir⶝ⶠr;榾oss;榻nå๒;槀ƀaeiⶱⶵⶹcr;䅍ga;䏉ƀcdnⷀⷅǍron;䎿;榶pf;쀀𝕠ƀaelⷔ⷗ǒr;榷rp;榹΀;adiosvⷪⷫⷮ⸈⸍⸐⸖戨rò᪆Ȁ;efmⷷⷸ⸂⸅橝rĀ;oⷾⷿ愴f»ⷿ耻ª䂪耻º䂺gof;抶r;橖lope;橗;橛ƀclo⸟⸡⸧ò⸁ash耻ø䃸l;折iŬⸯ⸴de耻õ䃵esĀ;aǛ⸺s;樶ml耻ö䃶bar;挽ૡ⹞\0⹽\0⺀⺝\0⺢⺹\0\0⻋ຜ\0⼓\0\0⼫⾼\0⿈rȀ;astЃ⹧⹲຅脀¶;l⹭⹮䂶leìЃɩ⹸\0\0⹻m;櫳;櫽y;䐿rʀcimpt⺋⺏⺓ᡥ⺗nt;䀥od;䀮il;怰enk;怱r;쀀𝔭ƀimo⺨⺰⺴Ā;v⺭⺮䏆;䏕maô੶ne;明ƀ;tv⺿⻀⻈䏀chfork»´;䏖Āau⻏⻟nĀck⻕⻝kĀ;h⇴⻛;愎ö⇴sҀ;abcdemst⻳⻴ᤈ⻹⻽⼄⼆⼊⼎䀫cir;樣ir;樢Āouᵀ⼂;樥;橲n肻±ຝim;樦wo;樧ƀipu⼙⼠⼥ntint;樕f;쀀𝕡nd耻£䂣Ԁ;Eaceinosu່⼿⽁⽄⽇⾁⾉⾒⽾⾶;檳p;檷uå໙Ā;c໎⽌̀;acens່⽙⽟⽦⽨⽾pproø⽃urlyeñ໙ñ໎ƀaes⽯⽶⽺pprox;檹qq;檵im;拨iíໟmeĀ;s⾈ຮ怲ƀEas⽸⾐⽺ð⽵ƀdfp໬⾙⾯ƀals⾠⾥⾪lar;挮ine;挒urf;挓Ā;t໻⾴ï໻rel;抰Āci⿀⿅r;쀀𝓅;䏈ncsp;怈̀fiopsu⿚⋢⿟⿥⿫⿱r;쀀𝔮pf;쀀𝕢rime;恗cr;쀀𝓆ƀaeo⿸〉〓tĀei⿾々rnionóڰnt;樖stĀ;e【】䀿ñἙô༔઀ABHabcdefhilmnoprstux぀けさすムㄎㄫㅇㅢㅲㆎ㈆㈕㈤㈩㉘㉮㉲㊐㊰㊷ƀartぇおがròႳòϝail;検aròᱥar;楤΀cdenqrtとふへみわゔヌĀeuねぱ;쀀∽̱te;䅕iãᅮmptyv;榳gȀ;del࿑らるろ;榒;榥å࿑uo耻»䂻rր;abcfhlpstw࿜ガクシスゼゾダッデナp;極Ā;f࿠ゴs;椠;椳s;椞ë≝ð✮l;楅im;楴l;憣;憝Āaiパフil;椚oĀ;nホボ戶aló༞ƀabrョリヮrò៥rk;杳ĀakンヽcĀekヹ・;䁽;䁝Āes㄂㄄;榌lĀduㄊㄌ;榎;榐Ȁaeuyㄗㄜㄧㄩron;䅙Ādiㄡㄥil;䅗ì࿲âヺ;䑀Ȁclqsㄴㄷㄽㅄa;椷dhar;楩uoĀ;rȎȍh;憳ƀacgㅎㅟངlȀ;ipsླྀㅘㅛႜnåႻarôྩt;断ƀilrㅩဣㅮsht;楽;쀀𝔯ĀaoㅷㆆrĀduㅽㅿ»ѻĀ;l႑ㆄ;楬Ā;vㆋㆌ䏁;䏱ƀgns㆕ㇹㇼht̀ahlrstㆤㆰ㇂㇘㇤㇮rrowĀ;t࿜ㆭaéトarpoonĀduㆻㆿowîㅾp»႒eftĀah㇊㇐rrowó࿪arpoonóՑightarrows;應quigarro÷ニhreetimes;拌g;䋚ingdotseñἲƀahm㈍㈐㈓rò࿪aòՑ;怏oustĀ;a㈞㈟掱che»㈟mid;櫮Ȁabpt㈲㈽㉀㉒Ānr㈷㈺g;柭r;懾rëဃƀafl㉇㉊㉎r;榆;쀀𝕣us;樮imes;樵Āap㉝㉧rĀ;g㉣㉤䀩t;榔olint;樒arò㇣Ȁachq㉻㊀Ⴜ㊅quo;怺r;쀀𝓇Ābu・㊊oĀ;rȔȓƀhir㊗㊛㊠reåㇸmes;拊iȀ;efl㊪ၙᠡ㊫方tri;槎luhar;楨;愞ൡ㋕㋛㋟㌬㌸㍱\0㍺㎤\0\0㏬㏰\0㐨㑈㑚㒭㒱㓊㓱\0㘖\0\0㘳cute;䅛quï➺Ԁ;Eaceinpsyᇭ㋳㋵㋿㌂㌋㌏㌟㌦㌩;檴ǰ㋺\0㋼;檸on;䅡uåᇾĀ;dᇳ㌇il;䅟rc;䅝ƀEas㌖㌘㌛;檶p;檺im;择olint;樓iíሄ;䑁otƀ;be㌴ᵇ㌵担;橦΀Aacmstx㍆㍊㍗㍛㍞㍣㍭rr;懘rĀhr㍐㍒ë∨Ā;oਸ਼਴t耻§䂧i;䀻war;椩mĀin㍩ðnuóñt;朶rĀ;o㍶⁕쀀𝔰Ȁacoy㎂㎆㎑㎠rp;景Āhy㎋㎏cy;䑉;䑈rtɭ㎙\0\0㎜iäᑤaraì⹯耻­䂭Āgm㎨㎴maƀ;fv㎱㎲㎲䏃;䏂Ѐ;deglnprካ㏅㏉㏎㏖㏞㏡㏦ot;橪Ā;q኱ኰĀ;E㏓㏔檞;檠Ā;E㏛㏜檝;檟e;扆lus;樤arr;楲aròᄽȀaeit㏸㐈㐏㐗Āls㏽㐄lsetmé㍪hp;樳parsl;槤Ādlᑣ㐔e;挣Ā;e㐜㐝檪Ā;s㐢㐣檬;쀀⪬︀ƀflp㐮㐳㑂tcy;䑌Ā;b㐸㐹䀯Ā;a㐾㐿槄r;挿f;쀀𝕤aĀdr㑍ЂesĀ;u㑔㑕晠it»㑕ƀcsu㑠㑹㒟Āau㑥㑯pĀ;sᆈ㑫;쀀⊓︀pĀ;sᆴ㑵;쀀⊔︀uĀbp㑿㒏ƀ;esᆗᆜ㒆etĀ;eᆗ㒍ñᆝƀ;esᆨᆭ㒖etĀ;eᆨ㒝ñᆮƀ;afᅻ㒦ְrť㒫ֱ»ᅼaròᅈȀcemt㒹㒾㓂㓅r;쀀𝓈tmîñiì㐕aræᆾĀar㓎㓕rĀ;f㓔ឿ昆Āan㓚㓭ightĀep㓣㓪psiloîỠhé⺯s»⡒ʀbcmnp㓻㕞ሉ㖋㖎Ҁ;Edemnprs㔎㔏㔑㔕㔞㔣㔬㔱㔶抂;櫅ot;檽Ā;dᇚ㔚ot;櫃ult;櫁ĀEe㔨㔪;櫋;把lus;檿arr;楹ƀeiu㔽㕒㕕tƀ;en㔎㕅㕋qĀ;qᇚ㔏eqĀ;q㔫㔨m;櫇Ābp㕚㕜;櫕;櫓c̀;acensᇭ㕬㕲㕹㕻㌦pproø㋺urlyeñᇾñᇳƀaes㖂㖈㌛pproø㌚qñ㌗g;晪ڀ123;Edehlmnps㖩㖬㖯ሜ㖲㖴㗀㗉㗕㗚㗟㗨㗭耻¹䂹耻²䂲耻³䂳;櫆Āos㖹㖼t;檾ub;櫘Ā;dሢ㗅ot;櫄sĀou㗏㗒l;柉b;櫗arr;楻ult;櫂ĀEe㗤㗦;櫌;抋lus;櫀ƀeiu㗴㘉㘌tƀ;enሜ㗼㘂qĀ;qሢ㖲eqĀ;q㗧㗤m;櫈Ābp㘑㘓;櫔;櫖ƀAan㘜㘠㘭rr;懙rĀhr㘦㘨ë∮Ā;oਫ਩war;椪lig耻ß䃟௡㙑㙝㙠ዎ㙳㙹\0㙾㛂\0\0\0\0\0㛛㜃\0㜉㝬\0\0\0㞇ɲ㙖\0\0㙛get;挖;䏄rë๟ƀaey㙦㙫㙰ron;䅥dil;䅣;䑂lrec;挕r;쀀𝔱Ȁeiko㚆㚝㚵㚼ǲ㚋\0㚑eĀ4fኄኁaƀ;sv㚘㚙㚛䎸ym;䏑Ācn㚢㚲kĀas㚨㚮pproø዁im»ኬsðኞĀas㚺㚮ð዁rn耻þ䃾Ǭ̟㛆⋧es膀×;bd㛏㛐㛘䃗Ā;aᤏ㛕r;樱;樰ƀeps㛡㛣㜀á⩍Ȁ;bcf҆㛬㛰㛴ot;挶ir;櫱Ā;o㛹㛼쀀𝕥rk;櫚á㍢rime;怴ƀaip㜏㜒㝤dåቈ΀adempst㜡㝍㝀㝑㝗㝜㝟ngleʀ;dlqr㜰㜱㜶㝀㝂斵own»ᶻeftĀ;e⠀㜾ñम;扜ightĀ;e㊪㝋ñၚot;旬inus;樺lus;樹b;槍ime;樻ezium;揢ƀcht㝲㝽㞁Āry㝷㝻;쀀𝓉;䑆cy;䑛rok;䅧Āio㞋㞎xô᝷headĀlr㞗㞠eftarro÷ࡏightarrow»ཝऀAHabcdfghlmoprstuw㟐㟓㟗㟤㟰㟼㠎㠜㠣㠴㡑㡝㡫㢩㣌㣒㣪㣶ròϭar;楣Ācr㟜㟢ute耻ú䃺òᅐrǣ㟪\0㟭y;䑞ve;䅭Āiy㟵㟺rc耻û䃻;䑃ƀabh㠃㠆㠋ròᎭlac;䅱aòᏃĀir㠓㠘sht;楾;쀀𝔲rave耻ù䃹š㠧㠱rĀlr㠬㠮»ॗ»ႃlk;斀Āct㠹㡍ɯ㠿\0\0㡊rnĀ;e㡅㡆挜r»㡆op;挏ri;旸Āal㡖㡚cr;䅫肻¨͉Āgp㡢㡦on;䅳f;쀀𝕦̀adhlsuᅋ㡸㡽፲㢑㢠ownáᎳarpoonĀlr㢈㢌efô㠭ighô㠯iƀ;hl㢙㢚㢜䏅»ᏺon»㢚parrows;懈ƀcit㢰㣄㣈ɯ㢶\0\0㣁rnĀ;e㢼㢽挝r»㢽op;挎ng;䅯ri;旹cr;쀀𝓊ƀdir㣙㣝㣢ot;拰lde;䅩iĀ;f㜰㣨»᠓Āam㣯㣲rò㢨l耻ü䃼angle;榧ހABDacdeflnoprsz㤜㤟㤩㤭㦵㦸㦽㧟㧤㧨㧳㧹㧽㨁㨠ròϷarĀ;v㤦㤧櫨;櫩asèϡĀnr㤲㤷grt;榜΀eknprst㓣㥆㥋㥒㥝㥤㦖appá␕othinçẖƀhir㓫⻈㥙opô⾵Ā;hᎷ㥢ïㆍĀiu㥩㥭gmá㎳Ābp㥲㦄setneqĀ;q㥽㦀쀀⊊︀;쀀⫋︀setneqĀ;q㦏㦒쀀⊋︀;쀀⫌︀Āhr㦛㦟etá㚜iangleĀlr㦪㦯eft»थight»ၑy;䐲ash»ံƀelr㧄㧒㧗ƀ;beⷪ㧋㧏ar;抻q;扚lip;拮Ābt㧜ᑨaòᑩr;쀀𝔳tré㦮suĀbp㧯㧱»ജ»൙pf;쀀𝕧roð໻tré㦴Ācu㨆㨋r;쀀𝓋Ābp㨐㨘nĀEe㦀㨖»㥾nĀEe㦒㨞»㦐igzag;榚΀cefoprs㨶㨻㩖㩛㩔㩡㩪irc;䅵Ādi㩀㩑Ābg㩅㩉ar;機eĀ;qᗺ㩏;扙erp;愘r;쀀𝔴pf;쀀𝕨Ā;eᑹ㩦atèᑹcr;쀀𝓌ૣណ㪇\0㪋\0㪐㪛\0\0㪝㪨㪫㪯\0\0㫃㫎\0㫘ៜ៟tré៑r;쀀𝔵ĀAa㪔㪗ròσrò৶;䎾ĀAa㪡㪤ròθrò৫að✓is;拻ƀdptឤ㪵㪾Āfl㪺ឩ;쀀𝕩imåឲĀAa㫇㫊ròώròਁĀcq㫒ីr;쀀𝓍Āpt៖㫜ré។Ѐacefiosu㫰㫽㬈㬌㬑㬕㬛㬡cĀuy㫶㫻te耻ý䃽;䑏Āiy㬂㬆rc;䅷;䑋n耻¥䂥r;쀀𝔶cy;䑗pf;쀀𝕪cr;쀀𝓎Ācm㬦㬩y;䑎l耻ÿ䃿Ԁacdefhiosw㭂㭈㭔㭘㭤㭩㭭㭴㭺㮀cute;䅺Āay㭍㭒ron;䅾;䐷ot;䅼Āet㭝㭡træᕟa;䎶r;쀀𝔷cy;䐶grarr;懝pf;쀀𝕫cr;쀀𝓏Ājn㮅㮇;怍j;怌'.split("").map((e) => e.charCodeAt(0))
), kt = /* @__PURE__ */ new Map([
  [0, 65533],
  // C1 Unicode control character reference replacements
  [128, 8364],
  [130, 8218],
  [131, 402],
  [132, 8222],
  [133, 8230],
  [134, 8224],
  [135, 8225],
  [136, 710],
  [137, 8240],
  [138, 352],
  [139, 8249],
  [140, 338],
  [142, 381],
  [145, 8216],
  [146, 8217],
  [147, 8220],
  [148, 8221],
  [149, 8226],
  [150, 8211],
  [151, 8212],
  [152, 732],
  [153, 8482],
  [154, 353],
  [155, 8250],
  [156, 339],
  [158, 382],
  [159, 376]
]);
function Ft(e) {
  var t;
  return e >= 55296 && e <= 57343 || e > 1114111 ? 65533 : (t = kt.get(e)) !== null && t !== void 0 ? t : e;
}
var N;
(function(e) {
  e[e.NUM = 35] = "NUM", e[e.SEMI = 59] = "SEMI", e[e.EQUALS = 61] = "EQUALS", e[e.ZERO = 48] = "ZERO", e[e.NINE = 57] = "NINE", e[e.LOWER_A = 97] = "LOWER_A", e[e.LOWER_F = 102] = "LOWER_F", e[e.LOWER_X = 120] = "LOWER_X", e[e.LOWER_Z = 122] = "LOWER_Z", e[e.UPPER_A = 65] = "UPPER_A", e[e.UPPER_F = 70] = "UPPER_F", e[e.UPPER_Z = 90] = "UPPER_Z";
})(N || (N = {}));
const yt = 32;
var B;
(function(e) {
  e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH", e[e.BRANCH_LENGTH = 16256] = "BRANCH_LENGTH", e[e.JUMP_TABLE = 127] = "JUMP_TABLE";
})(B || (B = {}));
function Ee(e) {
  return e >= N.ZERO && e <= N.NINE;
}
function wt(e) {
  return e >= N.UPPER_A && e <= N.UPPER_F || e >= N.LOWER_A && e <= N.LOWER_F;
}
function Yt(e) {
  return e >= N.UPPER_A && e <= N.UPPER_Z || e >= N.LOWER_A && e <= N.LOWER_Z || Ee(e);
}
function vt(e) {
  return e === N.EQUALS || Yt(e);
}
var I;
(function(e) {
  e[e.EntityStart = 0] = "EntityStart", e[e.NumericStart = 1] = "NumericStart", e[e.NumericDecimal = 2] = "NumericDecimal", e[e.NumericHex = 3] = "NumericHex", e[e.NamedEntity = 4] = "NamedEntity";
})(I || (I = {}));
var P;
(function(e) {
  e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict", e[e.Attribute = 2] = "Attribute";
})(P || (P = {}));
class Qt {
  constructor(t, a, s) {
    this.decodeTree = t, this.emitCodePoint = a, this.errors = s, this.state = I.EntityStart, this.consumed = 1, this.result = 0, this.treeIndex = 0, this.excess = 1, this.decodeMode = P.Strict;
  }
  /** Resets the instance to make it reusable. */
  startEntity(t) {
    this.decodeMode = t, this.state = I.EntityStart, this.result = 0, this.treeIndex = 0, this.excess = 1, this.consumed = 1;
  }
  /**
   * Write an entity to the decoder. This can be called multiple times with partial entities.
   * If the entity is incomplete, the decoder will return -1.
   *
   * Mirrors the implementation of `getDecoder`, but with the ability to stop decoding if the
   * entity is incomplete, and resume when the next string is written.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The offset at which the entity begins. Should be 0 if this is not the first call.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  write(t, a) {
    switch (this.state) {
      case I.EntityStart:
        return t.charCodeAt(a) === N.NUM ? (this.state = I.NumericStart, this.consumed += 1, this.stateNumericStart(t, a + 1)) : (this.state = I.NamedEntity, this.stateNamedEntity(t, a));
      case I.NumericStart:
        return this.stateNumericStart(t, a);
      case I.NumericDecimal:
        return this.stateNumericDecimal(t, a);
      case I.NumericHex:
        return this.stateNumericHex(t, a);
      case I.NamedEntity:
        return this.stateNamedEntity(t, a);
    }
  }
  /**
   * Switches between the numeric decimal and hexadecimal states.
   *
   * Equivalent to the `Numeric character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNumericStart(t, a) {
    return a >= t.length ? -1 : (t.charCodeAt(a) | yt) === N.LOWER_X ? (this.state = I.NumericHex, this.consumed += 1, this.stateNumericHex(t, a + 1)) : (this.state = I.NumericDecimal, this.stateNumericDecimal(t, a));
  }
  addToNumericResult(t, a, s, o) {
    if (a !== s) {
      const E = s - a;
      this.result = this.result * Math.pow(o, E) + Number.parseInt(t.substr(a, E), o), this.consumed += E;
    }
  }
  /**
   * Parses a hexadecimal numeric entity.
   *
   * Equivalent to the `Hexademical character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNumericHex(t, a) {
    const s = a;
    for (; a < t.length; ) {
      const o = t.charCodeAt(a);
      if (Ee(o) || wt(o))
        a += 1;
      else
        return this.addToNumericResult(t, s, a, 16), this.emitNumericEntity(o, 3);
    }
    return this.addToNumericResult(t, s, a, 16), -1;
  }
  /**
   * Parses a decimal numeric entity.
   *
   * Equivalent to the `Decimal character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNumericDecimal(t, a) {
    const s = a;
    for (; a < t.length; ) {
      const o = t.charCodeAt(a);
      if (Ee(o))
        a += 1;
      else
        return this.addToNumericResult(t, s, a, 10), this.emitNumericEntity(o, 2);
    }
    return this.addToNumericResult(t, s, a, 10), -1;
  }
  /**
   * Validate and emit a numeric entity.
   *
   * Implements the logic from the `Hexademical character reference start
   * state` and `Numeric character reference end state` in the HTML spec.
   *
   * @param lastCp The last code point of the entity. Used to see if the
   *               entity was terminated with a semicolon.
   * @param expectedLength The minimum number of characters that should be
   *                       consumed. Used to validate that at least one digit
   *                       was consumed.
   * @returns The number of characters that were consumed.
   */
  emitNumericEntity(t, a) {
    var s;
    if (this.consumed <= a)
      return (s = this.errors) === null || s === void 0 || s.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
    if (t === N.SEMI)
      this.consumed += 1;
    else if (this.decodeMode === P.Strict)
      return 0;
    return this.emitCodePoint(Ft(this.result), this.consumed), this.errors && (t !== N.SEMI && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed;
  }
  /**
   * Parses a named entity.
   *
   * Equivalent to the `Named character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNamedEntity(t, a) {
    const { decodeTree: s } = this;
    let o = s[this.treeIndex], E = (o & B.VALUE_LENGTH) >> 14;
    for (; a < t.length; a++, this.excess++) {
      const h = t.charCodeAt(a);
      if (this.treeIndex = Wt(s, o, this.treeIndex + Math.max(1, E), h), this.treeIndex < 0)
        return this.result === 0 || // If we are parsing an attribute
        this.decodeMode === P.Attribute && // We shouldn't have consumed any characters after the entity,
        (E === 0 || // And there should be no invalid characters.
        vt(h)) ? 0 : this.emitNotTerminatedNamedEntity();
      if (o = s[this.treeIndex], E = (o & B.VALUE_LENGTH) >> 14, E !== 0) {
        if (h === N.SEMI)
          return this.emitNamedEntityData(this.treeIndex, E, this.consumed + this.excess);
        this.decodeMode !== P.Strict && (this.result = this.treeIndex, this.consumed += this.excess, this.excess = 0);
      }
    }
    return -1;
  }
  /**
   * Emit a named entity that was not terminated with a semicolon.
   *
   * @returns The number of characters consumed.
   */
  emitNotTerminatedNamedEntity() {
    var t;
    const { result: a, decodeTree: s } = this, o = (s[a] & B.VALUE_LENGTH) >> 14;
    return this.emitNamedEntityData(a, o, this.consumed), (t = this.errors) === null || t === void 0 || t.missingSemicolonAfterCharacterReference(), this.consumed;
  }
  /**
   * Emit a named entity.
   *
   * @param result The index of the entity in the decode tree.
   * @param valueLength The number of bytes in the entity.
   * @param consumed The number of characters consumed.
   *
   * @returns The number of characters consumed.
   */
  emitNamedEntityData(t, a, s) {
    const { decodeTree: o } = this;
    return this.emitCodePoint(a === 1 ? o[t] & ~B.VALUE_LENGTH : o[t + 1], s), a === 3 && this.emitCodePoint(o[t + 2], s), s;
  }
  /**
   * Signal to the parser that the end of the input was reached.
   *
   * Remaining data will be emitted and relevant errors will be produced.
   *
   * @returns The number of characters consumed.
   */
  end() {
    var t;
    switch (this.state) {
      case I.NamedEntity:
        return this.result !== 0 && (this.decodeMode !== P.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
      case I.NumericDecimal:
        return this.emitNumericEntity(0, 2);
      case I.NumericHex:
        return this.emitNumericEntity(0, 3);
      case I.NumericStart:
        return (t = this.errors) === null || t === void 0 || t.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
      case I.EntityStart:
        return 0;
    }
  }
}
function Wt(e, t, a, s) {
  const o = (t & B.BRANCH_LENGTH) >> 7, E = t & B.JUMP_TABLE;
  if (o === 0)
    return E !== 0 && s === E ? a : -1;
  if (E) {
    const m = s - E;
    return m < 0 || m >= o ? -1 : e[a + m] - 1;
  }
  let h = a, f = h + o - 1;
  for (; h <= f; ) {
    const m = h + f >>> 1, _ = e[m];
    if (_ < s)
      h = m + 1;
    else if (_ > s)
      f = m - 1;
    else
      return e[m + o];
  }
  return -1;
}
var T;
(function(e) {
  e.HTML = "http://www.w3.org/1999/xhtml", e.MATHML = "http://www.w3.org/1998/Math/MathML", e.SVG = "http://www.w3.org/2000/svg", e.XLINK = "http://www.w3.org/1999/xlink", e.XML = "http://www.w3.org/XML/1998/namespace", e.XMLNS = "http://www.w3.org/2000/xmlns/";
})(T || (T = {}));
var U;
(function(e) {
  e.TYPE = "type", e.ACTION = "action", e.ENCODING = "encoding", e.PROMPT = "prompt", e.NAME = "name", e.COLOR = "color", e.FACE = "face", e.SIZE = "size";
})(U || (U = {}));
var S;
(function(e) {
  e.NO_QUIRKS = "no-quirks", e.QUIRKS = "quirks", e.LIMITED_QUIRKS = "limited-quirks";
})(S || (S = {}));
var c;
(function(e) {
  e.A = "a", e.ADDRESS = "address", e.ANNOTATION_XML = "annotation-xml", e.APPLET = "applet", e.AREA = "area", e.ARTICLE = "article", e.ASIDE = "aside", e.B = "b", e.BASE = "base", e.BASEFONT = "basefont", e.BGSOUND = "bgsound", e.BIG = "big", e.BLOCKQUOTE = "blockquote", e.BODY = "body", e.BR = "br", e.BUTTON = "button", e.CAPTION = "caption", e.CENTER = "center", e.CODE = "code", e.COL = "col", e.COLGROUP = "colgroup", e.DD = "dd", e.DESC = "desc", e.DETAILS = "details", e.DIALOG = "dialog", e.DIR = "dir", e.DIV = "div", e.DL = "dl", e.DT = "dt", e.EM = "em", e.EMBED = "embed", e.FIELDSET = "fieldset", e.FIGCAPTION = "figcaption", e.FIGURE = "figure", e.FONT = "font", e.FOOTER = "footer", e.FOREIGN_OBJECT = "foreignObject", e.FORM = "form", e.FRAME = "frame", e.FRAMESET = "frameset", e.H1 = "h1", e.H2 = "h2", e.H3 = "h3", e.H4 = "h4", e.H5 = "h5", e.H6 = "h6", e.HEAD = "head", e.HEADER = "header", e.HGROUP = "hgroup", e.HR = "hr", e.HTML = "html", e.I = "i", e.IMG = "img", e.IMAGE = "image", e.INPUT = "input", e.IFRAME = "iframe", e.KEYGEN = "keygen", e.LABEL = "label", e.LI = "li", e.LINK = "link", e.LISTING = "listing", e.MAIN = "main", e.MALIGNMARK = "malignmark", e.MARQUEE = "marquee", e.MATH = "math", e.MENU = "menu", e.META = "meta", e.MGLYPH = "mglyph", e.MI = "mi", e.MO = "mo", e.MN = "mn", e.MS = "ms", e.MTEXT = "mtext", e.NAV = "nav", e.NOBR = "nobr", e.NOFRAMES = "noframes", e.NOEMBED = "noembed", e.NOSCRIPT = "noscript", e.OBJECT = "object", e.OL = "ol", e.OPTGROUP = "optgroup", e.OPTION = "option", e.P = "p", e.PARAM = "param", e.PLAINTEXT = "plaintext", e.PRE = "pre", e.RB = "rb", e.RP = "rp", e.RT = "rt", e.RTC = "rtc", e.RUBY = "ruby", e.S = "s", e.SCRIPT = "script", e.SEARCH = "search", e.SECTION = "section", e.SELECT = "select", e.SOURCE = "source", e.SMALL = "small", e.SPAN = "span", e.STRIKE = "strike", e.STRONG = "strong", e.STYLE = "style", e.SUB = "sub", e.SUMMARY = "summary", e.SUP = "sup", e.TABLE = "table", e.TBODY = "tbody", e.TEMPLATE = "template", e.TEXTAREA = "textarea", e.TFOOT = "tfoot", e.TD = "td", e.TH = "th", e.THEAD = "thead", e.TITLE = "title", e.TR = "tr", e.TRACK = "track", e.TT = "tt", e.U = "u", e.UL = "ul", e.SVG = "svg", e.VAR = "var", e.WBR = "wbr", e.XMP = "xmp";
})(c || (c = {}));
var u;
(function(e) {
  e[e.UNKNOWN = 0] = "UNKNOWN", e[e.A = 1] = "A", e[e.ADDRESS = 2] = "ADDRESS", e[e.ANNOTATION_XML = 3] = "ANNOTATION_XML", e[e.APPLET = 4] = "APPLET", e[e.AREA = 5] = "AREA", e[e.ARTICLE = 6] = "ARTICLE", e[e.ASIDE = 7] = "ASIDE", e[e.B = 8] = "B", e[e.BASE = 9] = "BASE", e[e.BASEFONT = 10] = "BASEFONT", e[e.BGSOUND = 11] = "BGSOUND", e[e.BIG = 12] = "BIG", e[e.BLOCKQUOTE = 13] = "BLOCKQUOTE", e[e.BODY = 14] = "BODY", e[e.BR = 15] = "BR", e[e.BUTTON = 16] = "BUTTON", e[e.CAPTION = 17] = "CAPTION", e[e.CENTER = 18] = "CENTER", e[e.CODE = 19] = "CODE", e[e.COL = 20] = "COL", e[e.COLGROUP = 21] = "COLGROUP", e[e.DD = 22] = "DD", e[e.DESC = 23] = "DESC", e[e.DETAILS = 24] = "DETAILS", e[e.DIALOG = 25] = "DIALOG", e[e.DIR = 26] = "DIR", e[e.DIV = 27] = "DIV", e[e.DL = 28] = "DL", e[e.DT = 29] = "DT", e[e.EM = 30] = "EM", e[e.EMBED = 31] = "EMBED", e[e.FIELDSET = 32] = "FIELDSET", e[e.FIGCAPTION = 33] = "FIGCAPTION", e[e.FIGURE = 34] = "FIGURE", e[e.FONT = 35] = "FONT", e[e.FOOTER = 36] = "FOOTER", e[e.FOREIGN_OBJECT = 37] = "FOREIGN_OBJECT", e[e.FORM = 38] = "FORM", e[e.FRAME = 39] = "FRAME", e[e.FRAMESET = 40] = "FRAMESET", e[e.H1 = 41] = "H1", e[e.H2 = 42] = "H2", e[e.H3 = 43] = "H3", e[e.H4 = 44] = "H4", e[e.H5 = 45] = "H5", e[e.H6 = 46] = "H6", e[e.HEAD = 47] = "HEAD", e[e.HEADER = 48] = "HEADER", e[e.HGROUP = 49] = "HGROUP", e[e.HR = 50] = "HR", e[e.HTML = 51] = "HTML", e[e.I = 52] = "I", e[e.IMG = 53] = "IMG", e[e.IMAGE = 54] = "IMAGE", e[e.INPUT = 55] = "INPUT", e[e.IFRAME = 56] = "IFRAME", e[e.KEYGEN = 57] = "KEYGEN", e[e.LABEL = 58] = "LABEL", e[e.LI = 59] = "LI", e[e.LINK = 60] = "LINK", e[e.LISTING = 61] = "LISTING", e[e.MAIN = 62] = "MAIN", e[e.MALIGNMARK = 63] = "MALIGNMARK", e[e.MARQUEE = 64] = "MARQUEE", e[e.MATH = 65] = "MATH", e[e.MENU = 66] = "MENU", e[e.META = 67] = "META", e[e.MGLYPH = 68] = "MGLYPH", e[e.MI = 69] = "MI", e[e.MO = 70] = "MO", e[e.MN = 71] = "MN", e[e.MS = 72] = "MS", e[e.MTEXT = 73] = "MTEXT", e[e.NAV = 74] = "NAV", e[e.NOBR = 75] = "NOBR", e[e.NOFRAMES = 76] = "NOFRAMES", e[e.NOEMBED = 77] = "NOEMBED", e[e.NOSCRIPT = 78] = "NOSCRIPT", e[e.OBJECT = 79] = "OBJECT", e[e.OL = 80] = "OL", e[e.OPTGROUP = 81] = "OPTGROUP", e[e.OPTION = 82] = "OPTION", e[e.P = 83] = "P", e[e.PARAM = 84] = "PARAM", e[e.PLAINTEXT = 85] = "PLAINTEXT", e[e.PRE = 86] = "PRE", e[e.RB = 87] = "RB", e[e.RP = 88] = "RP", e[e.RT = 89] = "RT", e[e.RTC = 90] = "RTC", e[e.RUBY = 91] = "RUBY", e[e.S = 92] = "S", e[e.SCRIPT = 93] = "SCRIPT", e[e.SEARCH = 94] = "SEARCH", e[e.SECTION = 95] = "SECTION", e[e.SELECT = 96] = "SELECT", e[e.SOURCE = 97] = "SOURCE", e[e.SMALL = 98] = "SMALL", e[e.SPAN = 99] = "SPAN", e[e.STRIKE = 100] = "STRIKE", e[e.STRONG = 101] = "STRONG", e[e.STYLE = 102] = "STYLE", e[e.SUB = 103] = "SUB", e[e.SUMMARY = 104] = "SUMMARY", e[e.SUP = 105] = "SUP", e[e.TABLE = 106] = "TABLE", e[e.TBODY = 107] = "TBODY", e[e.TEMPLATE = 108] = "TEMPLATE", e[e.TEXTAREA = 109] = "TEXTAREA", e[e.TFOOT = 110] = "TFOOT", e[e.TD = 111] = "TD", e[e.TH = 112] = "TH", e[e.THEAD = 113] = "THEAD", e[e.TITLE = 114] = "TITLE", e[e.TR = 115] = "TR", e[e.TRACK = 116] = "TRACK", e[e.TT = 117] = "TT", e[e.U = 118] = "U", e[e.UL = 119] = "UL", e[e.SVG = 120] = "SVG", e[e.VAR = 121] = "VAR", e[e.WBR = 122] = "WBR", e[e.XMP = 123] = "XMP";
})(u || (u = {}));
const qt = /* @__PURE__ */ new Map([
  [c.A, u.A],
  [c.ADDRESS, u.ADDRESS],
  [c.ANNOTATION_XML, u.ANNOTATION_XML],
  [c.APPLET, u.APPLET],
  [c.AREA, u.AREA],
  [c.ARTICLE, u.ARTICLE],
  [c.ASIDE, u.ASIDE],
  [c.B, u.B],
  [c.BASE, u.BASE],
  [c.BASEFONT, u.BASEFONT],
  [c.BGSOUND, u.BGSOUND],
  [c.BIG, u.BIG],
  [c.BLOCKQUOTE, u.BLOCKQUOTE],
  [c.BODY, u.BODY],
  [c.BR, u.BR],
  [c.BUTTON, u.BUTTON],
  [c.CAPTION, u.CAPTION],
  [c.CENTER, u.CENTER],
  [c.CODE, u.CODE],
  [c.COL, u.COL],
  [c.COLGROUP, u.COLGROUP],
  [c.DD, u.DD],
  [c.DESC, u.DESC],
  [c.DETAILS, u.DETAILS],
  [c.DIALOG, u.DIALOG],
  [c.DIR, u.DIR],
  [c.DIV, u.DIV],
  [c.DL, u.DL],
  [c.DT, u.DT],
  [c.EM, u.EM],
  [c.EMBED, u.EMBED],
  [c.FIELDSET, u.FIELDSET],
  [c.FIGCAPTION, u.FIGCAPTION],
  [c.FIGURE, u.FIGURE],
  [c.FONT, u.FONT],
  [c.FOOTER, u.FOOTER],
  [c.FOREIGN_OBJECT, u.FOREIGN_OBJECT],
  [c.FORM, u.FORM],
  [c.FRAME, u.FRAME],
  [c.FRAMESET, u.FRAMESET],
  [c.H1, u.H1],
  [c.H2, u.H2],
  [c.H3, u.H3],
  [c.H4, u.H4],
  [c.H5, u.H5],
  [c.H6, u.H6],
  [c.HEAD, u.HEAD],
  [c.HEADER, u.HEADER],
  [c.HGROUP, u.HGROUP],
  [c.HR, u.HR],
  [c.HTML, u.HTML],
  [c.I, u.I],
  [c.IMG, u.IMG],
  [c.IMAGE, u.IMAGE],
  [c.INPUT, u.INPUT],
  [c.IFRAME, u.IFRAME],
  [c.KEYGEN, u.KEYGEN],
  [c.LABEL, u.LABEL],
  [c.LI, u.LI],
  [c.LINK, u.LINK],
  [c.LISTING, u.LISTING],
  [c.MAIN, u.MAIN],
  [c.MALIGNMARK, u.MALIGNMARK],
  [c.MARQUEE, u.MARQUEE],
  [c.MATH, u.MATH],
  [c.MENU, u.MENU],
  [c.META, u.META],
  [c.MGLYPH, u.MGLYPH],
  [c.MI, u.MI],
  [c.MO, u.MO],
  [c.MN, u.MN],
  [c.MS, u.MS],
  [c.MTEXT, u.MTEXT],
  [c.NAV, u.NAV],
  [c.NOBR, u.NOBR],
  [c.NOFRAMES, u.NOFRAMES],
  [c.NOEMBED, u.NOEMBED],
  [c.NOSCRIPT, u.NOSCRIPT],
  [c.OBJECT, u.OBJECT],
  [c.OL, u.OL],
  [c.OPTGROUP, u.OPTGROUP],
  [c.OPTION, u.OPTION],
  [c.P, u.P],
  [c.PARAM, u.PARAM],
  [c.PLAINTEXT, u.PLAINTEXT],
  [c.PRE, u.PRE],
  [c.RB, u.RB],
  [c.RP, u.RP],
  [c.RT, u.RT],
  [c.RTC, u.RTC],
  [c.RUBY, u.RUBY],
  [c.S, u.S],
  [c.SCRIPT, u.SCRIPT],
  [c.SEARCH, u.SEARCH],
  [c.SECTION, u.SECTION],
  [c.SELECT, u.SELECT],
  [c.SOURCE, u.SOURCE],
  [c.SMALL, u.SMALL],
  [c.SPAN, u.SPAN],
  [c.STRIKE, u.STRIKE],
  [c.STRONG, u.STRONG],
  [c.STYLE, u.STYLE],
  [c.SUB, u.SUB],
  [c.SUMMARY, u.SUMMARY],
  [c.SUP, u.SUP],
  [c.TABLE, u.TABLE],
  [c.TBODY, u.TBODY],
  [c.TEMPLATE, u.TEMPLATE],
  [c.TEXTAREA, u.TEXTAREA],
  [c.TFOOT, u.TFOOT],
  [c.TD, u.TD],
  [c.TH, u.TH],
  [c.THEAD, u.THEAD],
  [c.TITLE, u.TITLE],
  [c.TR, u.TR],
  [c.TRACK, u.TRACK],
  [c.TT, u.TT],
  [c.U, u.U],
  [c.UL, u.UL],
  [c.SVG, u.SVG],
  [c.VAR, u.VAR],
  [c.WBR, u.WBR],
  [c.XMP, u.XMP]
]);
function ue(e) {
  var t;
  return (t = qt.get(e)) !== null && t !== void 0 ? t : u.UNKNOWN;
}
const l = u, Gt = {
  [T.HTML]: /* @__PURE__ */ new Set([
    l.ADDRESS,
    l.APPLET,
    l.AREA,
    l.ARTICLE,
    l.ASIDE,
    l.BASE,
    l.BASEFONT,
    l.BGSOUND,
    l.BLOCKQUOTE,
    l.BODY,
    l.BR,
    l.BUTTON,
    l.CAPTION,
    l.CENTER,
    l.COL,
    l.COLGROUP,
    l.DD,
    l.DETAILS,
    l.DIR,
    l.DIV,
    l.DL,
    l.DT,
    l.EMBED,
    l.FIELDSET,
    l.FIGCAPTION,
    l.FIGURE,
    l.FOOTER,
    l.FORM,
    l.FRAME,
    l.FRAMESET,
    l.H1,
    l.H2,
    l.H3,
    l.H4,
    l.H5,
    l.H6,
    l.HEAD,
    l.HEADER,
    l.HGROUP,
    l.HR,
    l.HTML,
    l.IFRAME,
    l.IMG,
    l.INPUT,
    l.LI,
    l.LINK,
    l.LISTING,
    l.MAIN,
    l.MARQUEE,
    l.MENU,
    l.META,
    l.NAV,
    l.NOEMBED,
    l.NOFRAMES,
    l.NOSCRIPT,
    l.OBJECT,
    l.OL,
    l.P,
    l.PARAM,
    l.PLAINTEXT,
    l.PRE,
    l.SCRIPT,
    l.SECTION,
    l.SELECT,
    l.SOURCE,
    l.STYLE,
    l.SUMMARY,
    l.TABLE,
    l.TBODY,
    l.TD,
    l.TEMPLATE,
    l.TEXTAREA,
    l.TFOOT,
    l.TH,
    l.THEAD,
    l.TITLE,
    l.TR,
    l.TRACK,
    l.UL,
    l.WBR,
    l.XMP
  ]),
  [T.MATHML]: /* @__PURE__ */ new Set([l.MI, l.MO, l.MN, l.MS, l.MTEXT, l.ANNOTATION_XML]),
  [T.SVG]: /* @__PURE__ */ new Set([l.TITLE, l.FOREIGN_OBJECT, l.DESC]),
  [T.XLINK]: /* @__PURE__ */ new Set(),
  [T.XML]: /* @__PURE__ */ new Set(),
  [T.XMLNS]: /* @__PURE__ */ new Set()
}, Te = /* @__PURE__ */ new Set([l.H1, l.H2, l.H3, l.H4, l.H5, l.H6]);
c.STYLE, c.SCRIPT, c.XMP, c.IFRAME, c.NOEMBED, c.NOFRAMES, c.PLAINTEXT;
var n;
(function(e) {
  e[e.DATA = 0] = "DATA", e[e.RCDATA = 1] = "RCDATA", e[e.RAWTEXT = 2] = "RAWTEXT", e[e.SCRIPT_DATA = 3] = "SCRIPT_DATA", e[e.PLAINTEXT = 4] = "PLAINTEXT", e[e.TAG_OPEN = 5] = "TAG_OPEN", e[e.END_TAG_OPEN = 6] = "END_TAG_OPEN", e[e.TAG_NAME = 7] = "TAG_NAME", e[e.RCDATA_LESS_THAN_SIGN = 8] = "RCDATA_LESS_THAN_SIGN", e[e.RCDATA_END_TAG_OPEN = 9] = "RCDATA_END_TAG_OPEN", e[e.RCDATA_END_TAG_NAME = 10] = "RCDATA_END_TAG_NAME", e[e.RAWTEXT_LESS_THAN_SIGN = 11] = "RAWTEXT_LESS_THAN_SIGN", e[e.RAWTEXT_END_TAG_OPEN = 12] = "RAWTEXT_END_TAG_OPEN", e[e.RAWTEXT_END_TAG_NAME = 13] = "RAWTEXT_END_TAG_NAME", e[e.SCRIPT_DATA_LESS_THAN_SIGN = 14] = "SCRIPT_DATA_LESS_THAN_SIGN", e[e.SCRIPT_DATA_END_TAG_OPEN = 15] = "SCRIPT_DATA_END_TAG_OPEN", e[e.SCRIPT_DATA_END_TAG_NAME = 16] = "SCRIPT_DATA_END_TAG_NAME", e[e.SCRIPT_DATA_ESCAPE_START = 17] = "SCRIPT_DATA_ESCAPE_START", e[e.SCRIPT_DATA_ESCAPE_START_DASH = 18] = "SCRIPT_DATA_ESCAPE_START_DASH", e[e.SCRIPT_DATA_ESCAPED = 19] = "SCRIPT_DATA_ESCAPED", e[e.SCRIPT_DATA_ESCAPED_DASH = 20] = "SCRIPT_DATA_ESCAPED_DASH", e[e.SCRIPT_DATA_ESCAPED_DASH_DASH = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_OPEN = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_NAME = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_START = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START", e[e.SCRIPT_DATA_DOUBLE_ESCAPED = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_END = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END", e[e.BEFORE_ATTRIBUTE_NAME = 31] = "BEFORE_ATTRIBUTE_NAME", e[e.ATTRIBUTE_NAME = 32] = "ATTRIBUTE_NAME", e[e.AFTER_ATTRIBUTE_NAME = 33] = "AFTER_ATTRIBUTE_NAME", e[e.BEFORE_ATTRIBUTE_VALUE = 34] = "BEFORE_ATTRIBUTE_VALUE", e[e.ATTRIBUTE_VALUE_DOUBLE_QUOTED = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED", e[e.ATTRIBUTE_VALUE_SINGLE_QUOTED = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED", e[e.ATTRIBUTE_VALUE_UNQUOTED = 37] = "ATTRIBUTE_VALUE_UNQUOTED", e[e.AFTER_ATTRIBUTE_VALUE_QUOTED = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED", e[e.SELF_CLOSING_START_TAG = 39] = "SELF_CLOSING_START_TAG", e[e.BOGUS_COMMENT = 40] = "BOGUS_COMMENT", e[e.MARKUP_DECLARATION_OPEN = 41] = "MARKUP_DECLARATION_OPEN", e[e.COMMENT_START = 42] = "COMMENT_START", e[e.COMMENT_START_DASH = 43] = "COMMENT_START_DASH", e[e.COMMENT = 44] = "COMMENT", e[e.COMMENT_LESS_THAN_SIGN = 45] = "COMMENT_LESS_THAN_SIGN", e[e.COMMENT_LESS_THAN_SIGN_BANG = 46] = "COMMENT_LESS_THAN_SIGN_BANG", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH", e[e.COMMENT_END_DASH = 49] = "COMMENT_END_DASH", e[e.COMMENT_END = 50] = "COMMENT_END", e[e.COMMENT_END_BANG = 51] = "COMMENT_END_BANG", e[e.DOCTYPE = 52] = "DOCTYPE", e[e.BEFORE_DOCTYPE_NAME = 53] = "BEFORE_DOCTYPE_NAME", e[e.DOCTYPE_NAME = 54] = "DOCTYPE_NAME", e[e.AFTER_DOCTYPE_NAME = 55] = "AFTER_DOCTYPE_NAME", e[e.AFTER_DOCTYPE_PUBLIC_KEYWORD = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD", e[e.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER", e[e.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_PUBLIC_IDENTIFIER = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER", e[e.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS", e[e.AFTER_DOCTYPE_SYSTEM_KEYWORD = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD", e[e.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER", e[e.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_SYSTEM_IDENTIFIER = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER", e[e.BOGUS_DOCTYPE = 67] = "BOGUS_DOCTYPE", e[e.CDATA_SECTION = 68] = "CDATA_SECTION", e[e.CDATA_SECTION_BRACKET = 69] = "CDATA_SECTION_BRACKET", e[e.CDATA_SECTION_END = 70] = "CDATA_SECTION_END", e[e.CHARACTER_REFERENCE = 71] = "CHARACTER_REFERENCE", e[e.AMBIGUOUS_AMPERSAND = 72] = "AMBIGUOUS_AMPERSAND";
})(n || (n = {}));
const O = {
  DATA: n.DATA,
  RCDATA: n.RCDATA,
  RAWTEXT: n.RAWTEXT,
  SCRIPT_DATA: n.SCRIPT_DATA,
  PLAINTEXT: n.PLAINTEXT,
  CDATA_SECTION: n.CDATA_SECTION
};
function Kt(e) {
  return e >= r.DIGIT_0 && e <= r.DIGIT_9;
}
function Q(e) {
  return e >= r.LATIN_CAPITAL_A && e <= r.LATIN_CAPITAL_Z;
}
function Xt(e) {
  return e >= r.LATIN_SMALL_A && e <= r.LATIN_SMALL_Z;
}
function x(e) {
  return Xt(e) || Q(e);
}
function ge(e) {
  return x(e) || Kt(e);
}
function j(e) {
  return e + 32;
}
function Ge(e) {
  return e === r.SPACE || e === r.LINE_FEED || e === r.TABULATION || e === r.FORM_FEED;
}
function Le(e) {
  return Ge(e) || e === r.SOLIDUS || e === r.GREATER_THAN_SIGN;
}
function Vt(e) {
  return e === r.NULL ? d.nullCharacterReference : e > 1114111 ? d.characterReferenceOutsideUnicodeRange : ve(e) ? d.surrogateCharacterReference : We(e) ? d.noncharacterCharacterReference : Qe(e) || e === r.CARRIAGE_RETURN ? d.controlCharacterReference : null;
}
class zt {
  constructor(t, a) {
    this.options = t, this.handler = a, this.paused = !1, this.inLoop = !1, this.inForeignNode = !1, this.lastStartTagName = "", this.active = !1, this.state = n.DATA, this.returnState = n.DATA, this.entityStartPos = 0, this.consumedAfterSnapshot = -1, this.currentCharacterToken = null, this.currentToken = null, this.currentAttr = { name: "", value: "" }, this.preprocessor = new Ut(a), this.currentLocation = this.getCurrentLocation(-1), this.entityDecoder = new Qt(Ht, (s, o) => {
      this.preprocessor.pos = this.entityStartPos + o - 1, this._flushCodePointConsumedAsCharacterReference(s);
    }, a.onParseError ? {
      missingSemicolonAfterCharacterReference: () => {
        this._err(d.missingSemicolonAfterCharacterReference, 1);
      },
      absenceOfDigitsInNumericCharacterReference: (s) => {
        this._err(d.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + s);
      },
      validateNumericCharacterReference: (s) => {
        const o = Vt(s);
        o && this._err(o, 1);
      }
    } : void 0);
  }
  //Errors
  _err(t, a = 0) {
    var s, o;
    (o = (s = this.handler).onParseError) === null || o === void 0 || o.call(s, this.preprocessor.getError(t, a));
  }
  // NOTE: `offset` may never run across line boundaries.
  getCurrentLocation(t) {
    return this.options.sourceCodeLocationInfo ? {
      startLine: this.preprocessor.line,
      startCol: this.preprocessor.col - t,
      startOffset: this.preprocessor.offset - t,
      endLine: -1,
      endCol: -1,
      endOffset: -1
    } : null;
  }
  _runParsingLoop() {
    if (!this.inLoop) {
      for (this.inLoop = !0; this.active && !this.paused; ) {
        this.consumedAfterSnapshot = 0;
        const t = this._consume();
        this._ensureHibernation() || this._callState(t);
      }
      this.inLoop = !1;
    }
  }
  //API
  pause() {
    this.paused = !0;
  }
  resume(t) {
    if (!this.paused)
      throw new Error("Parser was already resumed");
    this.paused = !1, !this.inLoop && (this._runParsingLoop(), this.paused || t == null || t());
  }
  write(t, a, s) {
    this.active = !0, this.preprocessor.write(t, a), this._runParsingLoop(), this.paused || s == null || s();
  }
  insertHtmlAtCurrentPos(t) {
    this.active = !0, this.preprocessor.insertHtmlAtCurrentPos(t), this._runParsingLoop();
  }
  //Hibernation
  _ensureHibernation() {
    return this.preprocessor.endOfChunkHit ? (this.preprocessor.retreat(this.consumedAfterSnapshot), this.consumedAfterSnapshot = 0, this.active = !1, !0) : !1;
  }
  //Consumption
  _consume() {
    return this.consumedAfterSnapshot++, this.preprocessor.advance();
  }
  _advanceBy(t) {
    this.consumedAfterSnapshot += t;
    for (let a = 0; a < t; a++)
      this.preprocessor.advance();
  }
  _consumeSequenceIfMatch(t, a) {
    return this.preprocessor.startsWith(t, a) ? (this._advanceBy(t.length - 1), !0) : !1;
  }
  //Token creation
  _createStartTagToken() {
    this.currentToken = {
      type: b.START_TAG,
      tagName: "",
      tagID: u.UNKNOWN,
      selfClosing: !1,
      ackSelfClosing: !1,
      attrs: [],
      location: this.getCurrentLocation(1)
    };
  }
  _createEndTagToken() {
    this.currentToken = {
      type: b.END_TAG,
      tagName: "",
      tagID: u.UNKNOWN,
      selfClosing: !1,
      ackSelfClosing: !1,
      attrs: [],
      location: this.getCurrentLocation(2)
    };
  }
  _createCommentToken(t) {
    this.currentToken = {
      type: b.COMMENT,
      data: "",
      location: this.getCurrentLocation(t)
    };
  }
  _createDoctypeToken(t) {
    this.currentToken = {
      type: b.DOCTYPE,
      name: t,
      forceQuirks: !1,
      publicId: null,
      systemId: null,
      location: this.currentLocation
    };
  }
  _createCharacterToken(t, a) {
    this.currentCharacterToken = {
      type: t,
      chars: a,
      location: this.currentLocation
    };
  }
  //Tag attributes
  _createAttr(t) {
    this.currentAttr = {
      name: t,
      value: ""
    }, this.currentLocation = this.getCurrentLocation(0);
  }
  _leaveAttrName() {
    var t, a;
    const s = this.currentToken;
    if (qe(s, this.currentAttr.name) === null) {
      if (s.attrs.push(this.currentAttr), s.location && this.currentLocation) {
        const o = (t = (a = s.location).attrs) !== null && t !== void 0 ? t : a.attrs = /* @__PURE__ */ Object.create(null);
        o[this.currentAttr.name] = this.currentLocation, this._leaveAttrValue();
      }
    } else
      this._err(d.duplicateAttribute);
  }
  _leaveAttrValue() {
    this.currentLocation && (this.currentLocation.endLine = this.preprocessor.line, this.currentLocation.endCol = this.preprocessor.col, this.currentLocation.endOffset = this.preprocessor.offset);
  }
  //Token emission
  prepareToken(t) {
    this._emitCurrentCharacterToken(t.location), this.currentToken = null, t.location && (t.location.endLine = this.preprocessor.line, t.location.endCol = this.preprocessor.col + 1, t.location.endOffset = this.preprocessor.offset + 1), this.currentLocation = this.getCurrentLocation(-1);
  }
  emitCurrentTagToken() {
    const t = this.currentToken;
    this.prepareToken(t), t.tagID = ue(t.tagName), t.type === b.START_TAG ? (this.lastStartTagName = t.tagName, this.handler.onStartTag(t)) : (t.attrs.length > 0 && this._err(d.endTagWithAttributes), t.selfClosing && this._err(d.endTagWithTrailingSolidus), this.handler.onEndTag(t)), this.preprocessor.dropParsedChunk();
  }
  emitCurrentComment(t) {
    this.prepareToken(t), this.handler.onComment(t), this.preprocessor.dropParsedChunk();
  }
  emitCurrentDoctype(t) {
    this.prepareToken(t), this.handler.onDoctype(t), this.preprocessor.dropParsedChunk();
  }
  _emitCurrentCharacterToken(t) {
    if (this.currentCharacterToken) {
      switch (t && this.currentCharacterToken.location && (this.currentCharacterToken.location.endLine = t.startLine, this.currentCharacterToken.location.endCol = t.startCol, this.currentCharacterToken.location.endOffset = t.startOffset), this.currentCharacterToken.type) {
        case b.CHARACTER: {
          this.handler.onCharacter(this.currentCharacterToken);
          break;
        }
        case b.NULL_CHARACTER: {
          this.handler.onNullCharacter(this.currentCharacterToken);
          break;
        }
        case b.WHITESPACE_CHARACTER: {
          this.handler.onWhitespaceCharacter(this.currentCharacterToken);
          break;
        }
      }
      this.currentCharacterToken = null;
    }
  }
  _emitEOFToken() {
    const t = this.getCurrentLocation(0);
    t && (t.endLine = t.startLine, t.endCol = t.startCol, t.endOffset = t.startOffset), this._emitCurrentCharacterToken(t), this.handler.onEof({ type: b.EOF, location: t }), this.active = !1;
  }
  //Characters emission
  //OPTIMIZATION: The specification uses only one type of character token (one token per character).
  //This causes a huge memory overhead and a lot of unnecessary parser loops. parse5 uses 3 groups of characters.
  //If we have a sequence of characters that belong to the same group, the parser can process it
  //as a single solid character token.
  //So, there are 3 types of character tokens in parse5:
  //1)TokenType.NULL_CHARACTER - \u0000-character sequences (e.g. '\u0000\u0000\u0000')
  //2)TokenType.WHITESPACE_CHARACTER - any whitespace/new-line character sequences (e.g. '\n  \r\t   \f')
  //3)TokenType.CHARACTER - any character sequence which don't belong to groups 1 and 2 (e.g. 'abcdef1234@@#$%^')
  _appendCharToCurrentCharacterToken(t, a) {
    if (this.currentCharacterToken)
      if (this.currentCharacterToken.type === t) {
        this.currentCharacterToken.chars += a;
        return;
      } else
        this.currentLocation = this.getCurrentLocation(0), this._emitCurrentCharacterToken(this.currentLocation), this.preprocessor.dropParsedChunk();
    this._createCharacterToken(t, a);
  }
  _emitCodePoint(t) {
    const a = Ge(t) ? b.WHITESPACE_CHARACTER : t === r.NULL ? b.NULL_CHARACTER : b.CHARACTER;
    this._appendCharToCurrentCharacterToken(a, String.fromCodePoint(t));
  }
  //NOTE: used when we emit characters explicitly.
  //This is always for non-whitespace and non-null characters, which allows us to avoid additional checks.
  _emitChars(t) {
    this._appendCharToCurrentCharacterToken(b.CHARACTER, t);
  }
  // Character reference helpers
  _startCharacterReference() {
    this.returnState = this.state, this.state = n.CHARACTER_REFERENCE, this.entityStartPos = this.preprocessor.pos, this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? P.Attribute : P.Legacy);
  }
  _isCharacterReferenceInAttribute() {
    return this.returnState === n.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === n.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === n.ATTRIBUTE_VALUE_UNQUOTED;
  }
  _flushCodePointConsumedAsCharacterReference(t) {
    this._isCharacterReferenceInAttribute() ? this.currentAttr.value += String.fromCodePoint(t) : this._emitCodePoint(t);
  }
  // Calling states this way turns out to be much faster than any other approach.
  _callState(t) {
    switch (this.state) {
      case n.DATA: {
        this._stateData(t);
        break;
      }
      case n.RCDATA: {
        this._stateRcdata(t);
        break;
      }
      case n.RAWTEXT: {
        this._stateRawtext(t);
        break;
      }
      case n.SCRIPT_DATA: {
        this._stateScriptData(t);
        break;
      }
      case n.PLAINTEXT: {
        this._statePlaintext(t);
        break;
      }
      case n.TAG_OPEN: {
        this._stateTagOpen(t);
        break;
      }
      case n.END_TAG_OPEN: {
        this._stateEndTagOpen(t);
        break;
      }
      case n.TAG_NAME: {
        this._stateTagName(t);
        break;
      }
      case n.RCDATA_LESS_THAN_SIGN: {
        this._stateRcdataLessThanSign(t);
        break;
      }
      case n.RCDATA_END_TAG_OPEN: {
        this._stateRcdataEndTagOpen(t);
        break;
      }
      case n.RCDATA_END_TAG_NAME: {
        this._stateRcdataEndTagName(t);
        break;
      }
      case n.RAWTEXT_LESS_THAN_SIGN: {
        this._stateRawtextLessThanSign(t);
        break;
      }
      case n.RAWTEXT_END_TAG_OPEN: {
        this._stateRawtextEndTagOpen(t);
        break;
      }
      case n.RAWTEXT_END_TAG_NAME: {
        this._stateRawtextEndTagName(t);
        break;
      }
      case n.SCRIPT_DATA_LESS_THAN_SIGN: {
        this._stateScriptDataLessThanSign(t);
        break;
      }
      case n.SCRIPT_DATA_END_TAG_OPEN: {
        this._stateScriptDataEndTagOpen(t);
        break;
      }
      case n.SCRIPT_DATA_END_TAG_NAME: {
        this._stateScriptDataEndTagName(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPE_START: {
        this._stateScriptDataEscapeStart(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPE_START_DASH: {
        this._stateScriptDataEscapeStartDash(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED: {
        this._stateScriptDataEscaped(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_DASH: {
        this._stateScriptDataEscapedDash(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_DASH_DASH: {
        this._stateScriptDataEscapedDashDash(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN: {
        this._stateScriptDataEscapedLessThanSign(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_END_TAG_OPEN: {
        this._stateScriptDataEscapedEndTagOpen(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_END_TAG_NAME: {
        this._stateScriptDataEscapedEndTagName(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPE_START: {
        this._stateScriptDataDoubleEscapeStart(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED: {
        this._stateScriptDataDoubleEscaped(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH: {
        this._stateScriptDataDoubleEscapedDash(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH: {
        this._stateScriptDataDoubleEscapedDashDash(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN: {
        this._stateScriptDataDoubleEscapedLessThanSign(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPE_END: {
        this._stateScriptDataDoubleEscapeEnd(t);
        break;
      }
      case n.BEFORE_ATTRIBUTE_NAME: {
        this._stateBeforeAttributeName(t);
        break;
      }
      case n.ATTRIBUTE_NAME: {
        this._stateAttributeName(t);
        break;
      }
      case n.AFTER_ATTRIBUTE_NAME: {
        this._stateAfterAttributeName(t);
        break;
      }
      case n.BEFORE_ATTRIBUTE_VALUE: {
        this._stateBeforeAttributeValue(t);
        break;
      }
      case n.ATTRIBUTE_VALUE_DOUBLE_QUOTED: {
        this._stateAttributeValueDoubleQuoted(t);
        break;
      }
      case n.ATTRIBUTE_VALUE_SINGLE_QUOTED: {
        this._stateAttributeValueSingleQuoted(t);
        break;
      }
      case n.ATTRIBUTE_VALUE_UNQUOTED: {
        this._stateAttributeValueUnquoted(t);
        break;
      }
      case n.AFTER_ATTRIBUTE_VALUE_QUOTED: {
        this._stateAfterAttributeValueQuoted(t);
        break;
      }
      case n.SELF_CLOSING_START_TAG: {
        this._stateSelfClosingStartTag(t);
        break;
      }
      case n.BOGUS_COMMENT: {
        this._stateBogusComment(t);
        break;
      }
      case n.MARKUP_DECLARATION_OPEN: {
        this._stateMarkupDeclarationOpen(t);
        break;
      }
      case n.COMMENT_START: {
        this._stateCommentStart(t);
        break;
      }
      case n.COMMENT_START_DASH: {
        this._stateCommentStartDash(t);
        break;
      }
      case n.COMMENT: {
        this._stateComment(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN: {
        this._stateCommentLessThanSign(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN_BANG: {
        this._stateCommentLessThanSignBang(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN_BANG_DASH: {
        this._stateCommentLessThanSignBangDash(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH: {
        this._stateCommentLessThanSignBangDashDash(t);
        break;
      }
      case n.COMMENT_END_DASH: {
        this._stateCommentEndDash(t);
        break;
      }
      case n.COMMENT_END: {
        this._stateCommentEnd(t);
        break;
      }
      case n.COMMENT_END_BANG: {
        this._stateCommentEndBang(t);
        break;
      }
      case n.DOCTYPE: {
        this._stateDoctype(t);
        break;
      }
      case n.BEFORE_DOCTYPE_NAME: {
        this._stateBeforeDoctypeName(t);
        break;
      }
      case n.DOCTYPE_NAME: {
        this._stateDoctypeName(t);
        break;
      }
      case n.AFTER_DOCTYPE_NAME: {
        this._stateAfterDoctypeName(t);
        break;
      }
      case n.AFTER_DOCTYPE_PUBLIC_KEYWORD: {
        this._stateAfterDoctypePublicKeyword(t);
        break;
      }
      case n.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER: {
        this._stateBeforeDoctypePublicIdentifier(t);
        break;
      }
      case n.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED: {
        this._stateDoctypePublicIdentifierDoubleQuoted(t);
        break;
      }
      case n.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED: {
        this._stateDoctypePublicIdentifierSingleQuoted(t);
        break;
      }
      case n.AFTER_DOCTYPE_PUBLIC_IDENTIFIER: {
        this._stateAfterDoctypePublicIdentifier(t);
        break;
      }
      case n.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS: {
        this._stateBetweenDoctypePublicAndSystemIdentifiers(t);
        break;
      }
      case n.AFTER_DOCTYPE_SYSTEM_KEYWORD: {
        this._stateAfterDoctypeSystemKeyword(t);
        break;
      }
      case n.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER: {
        this._stateBeforeDoctypeSystemIdentifier(t);
        break;
      }
      case n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED: {
        this._stateDoctypeSystemIdentifierDoubleQuoted(t);
        break;
      }
      case n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED: {
        this._stateDoctypeSystemIdentifierSingleQuoted(t);
        break;
      }
      case n.AFTER_DOCTYPE_SYSTEM_IDENTIFIER: {
        this._stateAfterDoctypeSystemIdentifier(t);
        break;
      }
      case n.BOGUS_DOCTYPE: {
        this._stateBogusDoctype(t);
        break;
      }
      case n.CDATA_SECTION: {
        this._stateCdataSection(t);
        break;
      }
      case n.CDATA_SECTION_BRACKET: {
        this._stateCdataSectionBracket(t);
        break;
      }
      case n.CDATA_SECTION_END: {
        this._stateCdataSectionEnd(t);
        break;
      }
      case n.CHARACTER_REFERENCE: {
        this._stateCharacterReference();
        break;
      }
      case n.AMBIGUOUS_AMPERSAND: {
        this._stateAmbiguousAmpersand(t);
        break;
      }
      default:
        throw new Error("Unknown state");
    }
  }
  // State machine
  // Data state
  //------------------------------------------------------------------
  _stateData(t) {
    switch (t) {
      case r.LESS_THAN_SIGN: {
        this.state = n.TAG_OPEN;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this._emitCodePoint(t);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  //  RCDATA state
  //------------------------------------------------------------------
  _stateRcdata(t) {
    switch (t) {
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.RCDATA_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // RAWTEXT state
  //------------------------------------------------------------------
  _stateRawtext(t) {
    switch (t) {
      case r.LESS_THAN_SIGN: {
        this.state = n.RAWTEXT_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Script data state
  //------------------------------------------------------------------
  _stateScriptData(t) {
    switch (t) {
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // PLAINTEXT state
  //------------------------------------------------------------------
  _statePlaintext(t) {
    switch (t) {
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Tag open state
  //------------------------------------------------------------------
  _stateTagOpen(t) {
    if (x(t))
      this._createStartTagToken(), this.state = n.TAG_NAME, this._stateTagName(t);
    else
      switch (t) {
        case r.EXCLAMATION_MARK: {
          this.state = n.MARKUP_DECLARATION_OPEN;
          break;
        }
        case r.SOLIDUS: {
          this.state = n.END_TAG_OPEN;
          break;
        }
        case r.QUESTION_MARK: {
          this._err(d.unexpectedQuestionMarkInsteadOfTagName), this._createCommentToken(1), this.state = n.BOGUS_COMMENT, this._stateBogusComment(t);
          break;
        }
        case r.EOF: {
          this._err(d.eofBeforeTagName), this._emitChars("<"), this._emitEOFToken();
          break;
        }
        default:
          this._err(d.invalidFirstCharacterOfTagName), this._emitChars("<"), this.state = n.DATA, this._stateData(t);
      }
  }
  // End tag open state
  //------------------------------------------------------------------
  _stateEndTagOpen(t) {
    if (x(t))
      this._createEndTagToken(), this.state = n.TAG_NAME, this._stateTagName(t);
    else
      switch (t) {
        case r.GREATER_THAN_SIGN: {
          this._err(d.missingEndTagName), this.state = n.DATA;
          break;
        }
        case r.EOF: {
          this._err(d.eofBeforeTagName), this._emitChars("</"), this._emitEOFToken();
          break;
        }
        default:
          this._err(d.invalidFirstCharacterOfTagName), this._createCommentToken(2), this.state = n.BOGUS_COMMENT, this._stateBogusComment(t);
      }
  }
  // Tag name state
  //------------------------------------------------------------------
  _stateTagName(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_ATTRIBUTE_NAME;
        break;
      }
      case r.SOLIDUS: {
        this.state = n.SELF_CLOSING_START_TAG;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.tagName += A;
        break;
      }
      case r.EOF: {
        this._err(d.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        a.tagName += String.fromCodePoint(Q(t) ? j(t) : t);
    }
  }
  // RCDATA less-than sign state
  //------------------------------------------------------------------
  _stateRcdataLessThanSign(t) {
    t === r.SOLIDUS ? this.state = n.RCDATA_END_TAG_OPEN : (this._emitChars("<"), this.state = n.RCDATA, this._stateRcdata(t));
  }
  // RCDATA end tag open state
  //------------------------------------------------------------------
  _stateRcdataEndTagOpen(t) {
    x(t) ? (this.state = n.RCDATA_END_TAG_NAME, this._stateRcdataEndTagName(t)) : (this._emitChars("</"), this.state = n.RCDATA, this._stateRcdata(t));
  }
  handleSpecialEndTag(t) {
    if (!this.preprocessor.startsWith(this.lastStartTagName, !1))
      return !this._ensureHibernation();
    this._createEndTagToken();
    const a = this.currentToken;
    switch (a.tagName = this.lastStartTagName, this.preprocessor.peek(this.lastStartTagName.length)) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        return this._advanceBy(this.lastStartTagName.length), this.state = n.BEFORE_ATTRIBUTE_NAME, !1;
      case r.SOLIDUS:
        return this._advanceBy(this.lastStartTagName.length), this.state = n.SELF_CLOSING_START_TAG, !1;
      case r.GREATER_THAN_SIGN:
        return this._advanceBy(this.lastStartTagName.length), this.emitCurrentTagToken(), this.state = n.DATA, !1;
      default:
        return !this._ensureHibernation();
    }
  }
  // RCDATA end tag name state
  //------------------------------------------------------------------
  _stateRcdataEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.RCDATA, this._stateRcdata(t));
  }
  // RAWTEXT less-than sign state
  //------------------------------------------------------------------
  _stateRawtextLessThanSign(t) {
    t === r.SOLIDUS ? this.state = n.RAWTEXT_END_TAG_OPEN : (this._emitChars("<"), this.state = n.RAWTEXT, this._stateRawtext(t));
  }
  // RAWTEXT end tag open state
  //------------------------------------------------------------------
  _stateRawtextEndTagOpen(t) {
    x(t) ? (this.state = n.RAWTEXT_END_TAG_NAME, this._stateRawtextEndTagName(t)) : (this._emitChars("</"), this.state = n.RAWTEXT, this._stateRawtext(t));
  }
  // RAWTEXT end tag name state
  //------------------------------------------------------------------
  _stateRawtextEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.RAWTEXT, this._stateRawtext(t));
  }
  // Script data less-than sign state
  //------------------------------------------------------------------
  _stateScriptDataLessThanSign(t) {
    switch (t) {
      case r.SOLIDUS: {
        this.state = n.SCRIPT_DATA_END_TAG_OPEN;
        break;
      }
      case r.EXCLAMATION_MARK: {
        this.state = n.SCRIPT_DATA_ESCAPE_START, this._emitChars("<!");
        break;
      }
      default:
        this._emitChars("<"), this.state = n.SCRIPT_DATA, this._stateScriptData(t);
    }
  }
  // Script data end tag open state
  //------------------------------------------------------------------
  _stateScriptDataEndTagOpen(t) {
    x(t) ? (this.state = n.SCRIPT_DATA_END_TAG_NAME, this._stateScriptDataEndTagName(t)) : (this._emitChars("</"), this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data end tag name state
  //------------------------------------------------------------------
  _stateScriptDataEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data escape start state
  //------------------------------------------------------------------
  _stateScriptDataEscapeStart(t) {
    t === r.HYPHEN_MINUS ? (this.state = n.SCRIPT_DATA_ESCAPE_START_DASH, this._emitChars("-")) : (this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data escape start dash state
  //------------------------------------------------------------------
  _stateScriptDataEscapeStartDash(t) {
    t === r.HYPHEN_MINUS ? (this.state = n.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-")) : (this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data escaped state
  //------------------------------------------------------------------
  _stateScriptDataEscaped(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_ESCAPED_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(d.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Script data escaped dash state
  //------------------------------------------------------------------
  _stateScriptDataEscapedDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(d.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data escaped dash dash state
  //------------------------------------------------------------------
  _stateScriptDataEscapedDashDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.SCRIPT_DATA, this._emitChars(">");
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(d.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data escaped less-than sign state
  //------------------------------------------------------------------
  _stateScriptDataEscapedLessThanSign(t) {
    t === r.SOLIDUS ? this.state = n.SCRIPT_DATA_ESCAPED_END_TAG_OPEN : x(t) ? (this._emitChars("<"), this.state = n.SCRIPT_DATA_DOUBLE_ESCAPE_START, this._stateScriptDataDoubleEscapeStart(t)) : (this._emitChars("<"), this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data escaped end tag open state
  //------------------------------------------------------------------
  _stateScriptDataEscapedEndTagOpen(t) {
    x(t) ? (this.state = n.SCRIPT_DATA_ESCAPED_END_TAG_NAME, this._stateScriptDataEscapedEndTagName(t)) : (this._emitChars("</"), this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data escaped end tag name state
  //------------------------------------------------------------------
  _stateScriptDataEscapedEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data double escape start state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapeStart(t) {
    if (this.preprocessor.startsWith(C.SCRIPT, !1) && Le(this.preprocessor.peek(C.SCRIPT.length))) {
      this._emitCodePoint(t);
      for (let a = 0; a < C.SCRIPT.length; a++)
        this._emitCodePoint(this._consume());
      this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED;
    } else this._ensureHibernation() || (this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data double escaped state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscaped(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(d.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Script data double escaped dash state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapedDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(d.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data double escaped dash dash state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapedDashDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.SCRIPT_DATA, this._emitChars(">");
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(d.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data double escaped less-than sign state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapedLessThanSign(t) {
    t === r.SOLIDUS ? (this.state = n.SCRIPT_DATA_DOUBLE_ESCAPE_END, this._emitChars("/")) : (this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(t));
  }
  // Script data double escape end state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapeEnd(t) {
    if (this.preprocessor.startsWith(C.SCRIPT, !1) && Le(this.preprocessor.peek(C.SCRIPT.length))) {
      this._emitCodePoint(t);
      for (let a = 0; a < C.SCRIPT.length; a++)
        this._emitCodePoint(this._consume());
      this.state = n.SCRIPT_DATA_ESCAPED;
    } else this._ensureHibernation() || (this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(t));
  }
  // Before attribute name state
  //------------------------------------------------------------------
  _stateBeforeAttributeName(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.SOLIDUS:
      case r.GREATER_THAN_SIGN:
      case r.EOF: {
        this.state = n.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(t);
        break;
      }
      case r.EQUALS_SIGN: {
        this._err(d.unexpectedEqualsSignBeforeAttributeName), this._createAttr("="), this.state = n.ATTRIBUTE_NAME;
        break;
      }
      default:
        this._createAttr(""), this.state = n.ATTRIBUTE_NAME, this._stateAttributeName(t);
    }
  }
  // Attribute name state
  //------------------------------------------------------------------
  _stateAttributeName(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
      case r.SOLIDUS:
      case r.GREATER_THAN_SIGN:
      case r.EOF: {
        this._leaveAttrName(), this.state = n.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(t);
        break;
      }
      case r.EQUALS_SIGN: {
        this._leaveAttrName(), this.state = n.BEFORE_ATTRIBUTE_VALUE;
        break;
      }
      case r.QUOTATION_MARK:
      case r.APOSTROPHE:
      case r.LESS_THAN_SIGN: {
        this._err(d.unexpectedCharacterInAttributeName), this.currentAttr.name += String.fromCodePoint(t);
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.currentAttr.name += A;
        break;
      }
      default:
        this.currentAttr.name += String.fromCodePoint(Q(t) ? j(t) : t);
    }
  }
  // After attribute name state
  //------------------------------------------------------------------
  _stateAfterAttributeName(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.SOLIDUS: {
        this.state = n.SELF_CLOSING_START_TAG;
        break;
      }
      case r.EQUALS_SIGN: {
        this.state = n.BEFORE_ATTRIBUTE_VALUE;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.EOF: {
        this._err(d.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this._createAttr(""), this.state = n.ATTRIBUTE_NAME, this._stateAttributeName(t);
    }
  }
  // Before attribute value state
  //------------------------------------------------------------------
  _stateBeforeAttributeValue(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.QUOTATION_MARK: {
        this.state = n.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this.state = n.ATTRIBUTE_VALUE_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.missingAttributeValue), this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      default:
        this.state = n.ATTRIBUTE_VALUE_UNQUOTED, this._stateAttributeValueUnquoted(t);
    }
  }
  // Attribute value (double-quoted) state
  //------------------------------------------------------------------
  _stateAttributeValueDoubleQuoted(t) {
    switch (t) {
      case r.QUOTATION_MARK: {
        this.state = n.AFTER_ATTRIBUTE_VALUE_QUOTED;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.currentAttr.value += A;
        break;
      }
      case r.EOF: {
        this._err(d.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this.currentAttr.value += String.fromCodePoint(t);
    }
  }
  // Attribute value (single-quoted) state
  //------------------------------------------------------------------
  _stateAttributeValueSingleQuoted(t) {
    switch (t) {
      case r.APOSTROPHE: {
        this.state = n.AFTER_ATTRIBUTE_VALUE_QUOTED;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.currentAttr.value += A;
        break;
      }
      case r.EOF: {
        this._err(d.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this.currentAttr.value += String.fromCodePoint(t);
    }
  }
  // Attribute value (unquoted) state
  //------------------------------------------------------------------
  _stateAttributeValueUnquoted(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this._leaveAttrValue(), this.state = n.BEFORE_ATTRIBUTE_NAME;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._leaveAttrValue(), this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), this.currentAttr.value += A;
        break;
      }
      case r.QUOTATION_MARK:
      case r.APOSTROPHE:
      case r.LESS_THAN_SIGN:
      case r.EQUALS_SIGN:
      case r.GRAVE_ACCENT: {
        this._err(d.unexpectedCharacterInUnquotedAttributeValue), this.currentAttr.value += String.fromCodePoint(t);
        break;
      }
      case r.EOF: {
        this._err(d.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this.currentAttr.value += String.fromCodePoint(t);
    }
  }
  // After attribute value (quoted) state
  //------------------------------------------------------------------
  _stateAfterAttributeValueQuoted(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this._leaveAttrValue(), this.state = n.BEFORE_ATTRIBUTE_NAME;
        break;
      }
      case r.SOLIDUS: {
        this._leaveAttrValue(), this.state = n.SELF_CLOSING_START_TAG;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._leaveAttrValue(), this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.EOF: {
        this._err(d.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingWhitespaceBetweenAttributes), this.state = n.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(t);
    }
  }
  // Self-closing start tag state
  //------------------------------------------------------------------
  _stateSelfClosingStartTag(t) {
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        const a = this.currentToken;
        a.selfClosing = !0, this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.EOF: {
        this._err(d.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.unexpectedSolidusInTag), this.state = n.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(t);
    }
  }
  // Bogus comment state
  //------------------------------------------------------------------
  _stateBogusComment(t) {
    const a = this.currentToken;
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EOF: {
        this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.data += A;
        break;
      }
      default:
        a.data += String.fromCodePoint(t);
    }
  }
  // Markup declaration open state
  //------------------------------------------------------------------
  _stateMarkupDeclarationOpen(t) {
    this._consumeSequenceIfMatch(C.DASH_DASH, !0) ? (this._createCommentToken(C.DASH_DASH.length + 1), this.state = n.COMMENT_START) : this._consumeSequenceIfMatch(C.DOCTYPE, !1) ? (this.currentLocation = this.getCurrentLocation(C.DOCTYPE.length + 1), this.state = n.DOCTYPE) : this._consumeSequenceIfMatch(C.CDATA_START, !0) ? this.inForeignNode ? this.state = n.CDATA_SECTION : (this._err(d.cdataInHtmlContent), this._createCommentToken(C.CDATA_START.length + 1), this.currentToken.data = "[CDATA[", this.state = n.BOGUS_COMMENT) : this._ensureHibernation() || (this._err(d.incorrectlyOpenedComment), this._createCommentToken(2), this.state = n.BOGUS_COMMENT, this._stateBogusComment(t));
  }
  // Comment start state
  //------------------------------------------------------------------
  _stateCommentStart(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_START_DASH;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.abruptClosingOfEmptyComment), this.state = n.DATA;
        const a = this.currentToken;
        this.emitCurrentComment(a);
        break;
      }
      default:
        this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment start dash state
  //------------------------------------------------------------------
  _stateCommentStartDash(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_END;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.abruptClosingOfEmptyComment), this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EOF: {
        this._err(d.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "-", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment state
  //------------------------------------------------------------------
  _stateComment(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_END_DASH;
        break;
      }
      case r.LESS_THAN_SIGN: {
        a.data += "<", this.state = n.COMMENT_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.data += A;
        break;
      }
      case r.EOF: {
        this._err(d.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += String.fromCodePoint(t);
    }
  }
  // Comment less-than sign state
  //------------------------------------------------------------------
  _stateCommentLessThanSign(t) {
    const a = this.currentToken;
    switch (t) {
      case r.EXCLAMATION_MARK: {
        a.data += "!", this.state = n.COMMENT_LESS_THAN_SIGN_BANG;
        break;
      }
      case r.LESS_THAN_SIGN: {
        a.data += "<";
        break;
      }
      default:
        this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment less-than sign bang state
  //------------------------------------------------------------------
  _stateCommentLessThanSignBang(t) {
    t === r.HYPHEN_MINUS ? this.state = n.COMMENT_LESS_THAN_SIGN_BANG_DASH : (this.state = n.COMMENT, this._stateComment(t));
  }
  // Comment less-than sign bang dash state
  //------------------------------------------------------------------
  _stateCommentLessThanSignBangDash(t) {
    t === r.HYPHEN_MINUS ? this.state = n.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH : (this.state = n.COMMENT_END_DASH, this._stateCommentEndDash(t));
  }
  // Comment less-than sign bang dash dash state
  //------------------------------------------------------------------
  _stateCommentLessThanSignBangDashDash(t) {
    t !== r.GREATER_THAN_SIGN && t !== r.EOF && this._err(d.nestedComment), this.state = n.COMMENT_END, this._stateCommentEnd(t);
  }
  // Comment end dash state
  //------------------------------------------------------------------
  _stateCommentEndDash(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_END;
        break;
      }
      case r.EOF: {
        this._err(d.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "-", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment end state
  //------------------------------------------------------------------
  _stateCommentEnd(t) {
    const a = this.currentToken;
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EXCLAMATION_MARK: {
        this.state = n.COMMENT_END_BANG;
        break;
      }
      case r.HYPHEN_MINUS: {
        a.data += "-";
        break;
      }
      case r.EOF: {
        this._err(d.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "--", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment end bang state
  //------------------------------------------------------------------
  _stateCommentEndBang(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        a.data += "--!", this.state = n.COMMENT_END_DASH;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.incorrectlyClosedComment), this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EOF: {
        this._err(d.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "--!", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // DOCTYPE state
  //------------------------------------------------------------------
  _stateDoctype(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_DOCTYPE_NAME;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(t);
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), this._createDoctypeToken(null);
        const a = this.currentToken;
        a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingWhitespaceBeforeDoctypeName), this.state = n.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(t);
    }
  }
  // Before DOCTYPE name state
  //------------------------------------------------------------------
  _stateBeforeDoctypeName(t) {
    if (Q(t))
      this._createDoctypeToken(String.fromCharCode(j(t))), this.state = n.DOCTYPE_NAME;
    else
      switch (t) {
        case r.SPACE:
        case r.LINE_FEED:
        case r.TABULATION:
        case r.FORM_FEED:
          break;
        case r.NULL: {
          this._err(d.unexpectedNullCharacter), this._createDoctypeToken(A), this.state = n.DOCTYPE_NAME;
          break;
        }
        case r.GREATER_THAN_SIGN: {
          this._err(d.missingDoctypeName), this._createDoctypeToken(null);
          const a = this.currentToken;
          a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
          break;
        }
        case r.EOF: {
          this._err(d.eofInDoctype), this._createDoctypeToken(null);
          const a = this.currentToken;
          a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
          break;
        }
        default:
          this._createDoctypeToken(String.fromCodePoint(t)), this.state = n.DOCTYPE_NAME;
      }
  }
  // DOCTYPE name state
  //------------------------------------------------------------------
  _stateDoctypeName(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.AFTER_DOCTYPE_NAME;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.name += A;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.name += String.fromCodePoint(Q(t) ? j(t) : t);
    }
  }
  // After DOCTYPE name state
  //------------------------------------------------------------------
  _stateAfterDoctypeName(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._consumeSequenceIfMatch(C.PUBLIC, !1) ? this.state = n.AFTER_DOCTYPE_PUBLIC_KEYWORD : this._consumeSequenceIfMatch(C.SYSTEM, !1) ? this.state = n.AFTER_DOCTYPE_SYSTEM_KEYWORD : this._ensureHibernation() || (this._err(d.invalidCharacterSequenceAfterDoctypeName), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t));
    }
  }
  // After DOCTYPE public keyword state
  //------------------------------------------------------------------
  _stateAfterDoctypePublicKeyword(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
        break;
      }
      case r.QUOTATION_MARK: {
        this._err(d.missingWhitespaceAfterDoctypePublicKeyword), a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this._err(d.missingWhitespaceAfterDoctypePublicKeyword), a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.missingDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingQuoteBeforeDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Before DOCTYPE public identifier state
  //------------------------------------------------------------------
  _stateBeforeDoctypePublicIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.QUOTATION_MARK: {
        a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.missingDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingQuoteBeforeDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // DOCTYPE public identifier (double-quoted) state
  //------------------------------------------------------------------
  _stateDoctypePublicIdentifierDoubleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.QUOTATION_MARK: {
        this.state = n.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.publicId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.abruptDoctypePublicIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.publicId += String.fromCodePoint(t);
    }
  }
  // DOCTYPE public identifier (single-quoted) state
  //------------------------------------------------------------------
  _stateDoctypePublicIdentifierSingleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.APOSTROPHE: {
        this.state = n.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.publicId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.abruptDoctypePublicIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.publicId += String.fromCodePoint(t);
    }
  }
  // After DOCTYPE public identifier state
  //------------------------------------------------------------------
  _stateAfterDoctypePublicIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.QUOTATION_MARK: {
        this._err(d.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this._err(d.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Between DOCTYPE public and system identifiers state
  //------------------------------------------------------------------
  _stateBetweenDoctypePublicAndSystemIdentifiers(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.GREATER_THAN_SIGN: {
        this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.QUOTATION_MARK: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // After DOCTYPE system keyword state
  //------------------------------------------------------------------
  _stateAfterDoctypeSystemKeyword(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
        break;
      }
      case r.QUOTATION_MARK: {
        this._err(d.missingWhitespaceAfterDoctypeSystemKeyword), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this._err(d.missingWhitespaceAfterDoctypeSystemKeyword), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.missingDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Before DOCTYPE system identifier state
  //------------------------------------------------------------------
  _stateBeforeDoctypeSystemIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.QUOTATION_MARK: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.missingDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // DOCTYPE system identifier (double-quoted) state
  //------------------------------------------------------------------
  _stateDoctypeSystemIdentifierDoubleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.QUOTATION_MARK: {
        this.state = n.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.systemId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.abruptDoctypeSystemIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.systemId += String.fromCodePoint(t);
    }
  }
  // DOCTYPE system identifier (single-quoted) state
  //------------------------------------------------------------------
  _stateDoctypeSystemIdentifierSingleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.APOSTROPHE: {
        this.state = n.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter), a.systemId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(d.abruptDoctypeSystemIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.systemId += String.fromCodePoint(t);
    }
  }
  // After DOCTYPE system identifier state
  //------------------------------------------------------------------
  _stateAfterDoctypeSystemIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.GREATER_THAN_SIGN: {
        this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(d.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(d.unexpectedCharacterAfterDoctypeSystemIdentifier), this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Bogus DOCTYPE state
  //------------------------------------------------------------------
  _stateBogusDoctype(t) {
    const a = this.currentToken;
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.NULL: {
        this._err(d.unexpectedNullCharacter);
        break;
      }
      case r.EOF: {
        this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
    }
  }
  // CDATA section state
  //------------------------------------------------------------------
  _stateCdataSection(t) {
    switch (t) {
      case r.RIGHT_SQUARE_BRACKET: {
        this.state = n.CDATA_SECTION_BRACKET;
        break;
      }
      case r.EOF: {
        this._err(d.eofInCdata), this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // CDATA section bracket state
  //------------------------------------------------------------------
  _stateCdataSectionBracket(t) {
    t === r.RIGHT_SQUARE_BRACKET ? this.state = n.CDATA_SECTION_END : (this._emitChars("]"), this.state = n.CDATA_SECTION, this._stateCdataSection(t));
  }
  // CDATA section end state
  //------------------------------------------------------------------
  _stateCdataSectionEnd(t) {
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA;
        break;
      }
      case r.RIGHT_SQUARE_BRACKET: {
        this._emitChars("]");
        break;
      }
      default:
        this._emitChars("]]"), this.state = n.CDATA_SECTION, this._stateCdataSection(t);
    }
  }
  // Character reference state
  //------------------------------------------------------------------
  _stateCharacterReference() {
    let t = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
    if (t < 0)
      if (this.preprocessor.lastChunkWritten)
        t = this.entityDecoder.end();
      else {
        this.active = !1, this.preprocessor.pos = this.preprocessor.html.length - 1, this.consumedAfterSnapshot = 0, this.preprocessor.endOfChunkHit = !0;
        return;
      }
    t === 0 ? (this.preprocessor.pos = this.entityStartPos, this._flushCodePointConsumedAsCharacterReference(r.AMPERSAND), this.state = !this._isCharacterReferenceInAttribute() && ge(this.preprocessor.peek(1)) ? n.AMBIGUOUS_AMPERSAND : this.returnState) : this.state = this.returnState;
  }
  // Ambiguos ampersand state
  //------------------------------------------------------------------
  _stateAmbiguousAmpersand(t) {
    ge(t) ? this._flushCodePointConsumedAsCharacterReference(t) : (t === r.SEMICOLON && this._err(d.unknownNamedCharacterReference), this.state = this.returnState, this._callState(t));
  }
}
const Ke = /* @__PURE__ */ new Set([u.DD, u.DT, u.LI, u.OPTGROUP, u.OPTION, u.P, u.RB, u.RP, u.RT, u.RTC]), Re = /* @__PURE__ */ new Set([
  ...Ke,
  u.CAPTION,
  u.COLGROUP,
  u.TBODY,
  u.TD,
  u.TFOOT,
  u.TH,
  u.THEAD,
  u.TR
]), $ = /* @__PURE__ */ new Set([
  u.APPLET,
  u.CAPTION,
  u.HTML,
  u.MARQUEE,
  u.OBJECT,
  u.TABLE,
  u.TD,
  u.TEMPLATE,
  u.TH
]), jt = /* @__PURE__ */ new Set([...$, u.OL, u.UL]), Jt = /* @__PURE__ */ new Set([...$, u.BUTTON]), De = /* @__PURE__ */ new Set([u.ANNOTATION_XML, u.MI, u.MN, u.MO, u.MS, u.MTEXT]), Pe = /* @__PURE__ */ new Set([u.DESC, u.FOREIGN_OBJECT, u.TITLE]), Zt = /* @__PURE__ */ new Set([u.TR, u.TEMPLATE, u.HTML]), $t = /* @__PURE__ */ new Set([u.TBODY, u.TFOOT, u.THEAD, u.TEMPLATE, u.HTML]), eu = /* @__PURE__ */ new Set([u.TABLE, u.TEMPLATE, u.HTML]), tu = /* @__PURE__ */ new Set([u.TD, u.TH]);
class uu {
  get currentTmplContentOrNode() {
    return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
  }
  constructor(t, a, s) {
    this.treeAdapter = a, this.handler = s, this.items = [], this.tagIDs = [], this.stackTop = -1, this.tmplCount = 0, this.currentTagId = u.UNKNOWN, this.current = t;
  }
  //Index of element
  _indexOf(t) {
    return this.items.lastIndexOf(t, this.stackTop);
  }
  //Update current element
  _isInTemplate() {
    return this.currentTagId === u.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === T.HTML;
  }
  _updateCurrentElement() {
    this.current = this.items[this.stackTop], this.currentTagId = this.tagIDs[this.stackTop];
  }
  //Mutations
  push(t, a) {
    this.stackTop++, this.items[this.stackTop] = t, this.current = t, this.tagIDs[this.stackTop] = a, this.currentTagId = a, this._isInTemplate() && this.tmplCount++, this.handler.onItemPush(t, a, !0);
  }
  pop() {
    const t = this.current;
    this.tmplCount > 0 && this._isInTemplate() && this.tmplCount--, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(t, !0);
  }
  replace(t, a) {
    const s = this._indexOf(t);
    this.items[s] = a, s === this.stackTop && (this.current = a);
  }
  insertAfter(t, a, s) {
    const o = this._indexOf(t) + 1;
    this.items.splice(o, 0, a), this.tagIDs.splice(o, 0, s), this.stackTop++, o === this.stackTop && this._updateCurrentElement(), this.current && this.currentTagId !== void 0 && this.handler.onItemPush(this.current, this.currentTagId, o === this.stackTop);
  }
  popUntilTagNamePopped(t) {
    let a = this.stackTop + 1;
    do
      a = this.tagIDs.lastIndexOf(t, a - 1);
    while (a > 0 && this.treeAdapter.getNamespaceURI(this.items[a]) !== T.HTML);
    this.shortenToLength(Math.max(a, 0));
  }
  shortenToLength(t) {
    for (; this.stackTop >= t; ) {
      const a = this.current;
      this.tmplCount > 0 && this._isInTemplate() && (this.tmplCount -= 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(a, this.stackTop < t);
    }
  }
  popUntilElementPopped(t) {
    const a = this._indexOf(t);
    this.shortenToLength(Math.max(a, 0));
  }
  popUntilPopped(t, a) {
    const s = this._indexOfTagNames(t, a);
    this.shortenToLength(Math.max(s, 0));
  }
  popUntilNumberedHeaderPopped() {
    this.popUntilPopped(Te, T.HTML);
  }
  popUntilTableCellPopped() {
    this.popUntilPopped(tu, T.HTML);
  }
  popAllUpToHtmlElement() {
    this.tmplCount = 0, this.shortenToLength(1);
  }
  _indexOfTagNames(t, a) {
    for (let s = this.stackTop; s >= 0; s--)
      if (t.has(this.tagIDs[s]) && this.treeAdapter.getNamespaceURI(this.items[s]) === a)
        return s;
    return -1;
  }
  clearBackTo(t, a) {
    const s = this._indexOfTagNames(t, a);
    this.shortenToLength(s + 1);
  }
  clearBackToTableContext() {
    this.clearBackTo(eu, T.HTML);
  }
  clearBackToTableBodyContext() {
    this.clearBackTo($t, T.HTML);
  }
  clearBackToTableRowContext() {
    this.clearBackTo(Zt, T.HTML);
  }
  remove(t) {
    const a = this._indexOf(t);
    a >= 0 && (a === this.stackTop ? this.pop() : (this.items.splice(a, 1), this.tagIDs.splice(a, 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(t, !1)));
  }
  //Search
  tryPeekProperlyNestedBodyElement() {
    return this.stackTop >= 1 && this.tagIDs[1] === u.BODY ? this.items[1] : null;
  }
  contains(t) {
    return this._indexOf(t) > -1;
  }
  getCommonAncestor(t) {
    const a = this._indexOf(t) - 1;
    return a >= 0 ? this.items[a] : null;
  }
  isRootHtmlElementCurrent() {
    return this.stackTop === 0 && this.tagIDs[0] === u.HTML;
  }
  //Element in scope
  hasInDynamicScope(t, a) {
    for (let s = this.stackTop; s >= 0; s--) {
      const o = this.tagIDs[s];
      switch (this.treeAdapter.getNamespaceURI(this.items[s])) {
        case T.HTML: {
          if (o === t)
            return !0;
          if (a.has(o))
            return !1;
          break;
        }
        case T.SVG: {
          if (Pe.has(o))
            return !1;
          break;
        }
        case T.MATHML: {
          if (De.has(o))
            return !1;
          break;
        }
      }
    }
    return !0;
  }
  hasInScope(t) {
    return this.hasInDynamicScope(t, $);
  }
  hasInListItemScope(t) {
    return this.hasInDynamicScope(t, jt);
  }
  hasInButtonScope(t) {
    return this.hasInDynamicScope(t, Jt);
  }
  hasNumberedHeaderInScope() {
    for (let t = this.stackTop; t >= 0; t--) {
      const a = this.tagIDs[t];
      switch (this.treeAdapter.getNamespaceURI(this.items[t])) {
        case T.HTML: {
          if (Te.has(a))
            return !0;
          if ($.has(a))
            return !1;
          break;
        }
        case T.SVG: {
          if (Pe.has(a))
            return !1;
          break;
        }
        case T.MATHML: {
          if (De.has(a))
            return !1;
          break;
        }
      }
    }
    return !0;
  }
  hasInTableScope(t) {
    for (let a = this.stackTop; a >= 0; a--)
      if (this.treeAdapter.getNamespaceURI(this.items[a]) === T.HTML)
        switch (this.tagIDs[a]) {
          case t:
            return !0;
          case u.TABLE:
          case u.HTML:
            return !1;
        }
    return !0;
  }
  hasTableBodyContextInTableScope() {
    for (let t = this.stackTop; t >= 0; t--)
      if (this.treeAdapter.getNamespaceURI(this.items[t]) === T.HTML)
        switch (this.tagIDs[t]) {
          case u.TBODY:
          case u.THEAD:
          case u.TFOOT:
            return !0;
          case u.TABLE:
          case u.HTML:
            return !1;
        }
    return !0;
  }
  hasInSelectScope(t) {
    for (let a = this.stackTop; a >= 0; a--)
      if (this.treeAdapter.getNamespaceURI(this.items[a]) === T.HTML)
        switch (this.tagIDs[a]) {
          case t:
            return !0;
          case u.OPTION:
          case u.OPTGROUP:
            break;
          default:
            return !1;
        }
    return !0;
  }
  //Implied end tags
  generateImpliedEndTags() {
    for (; this.currentTagId !== void 0 && Ke.has(this.currentTagId); )
      this.pop();
  }
  generateImpliedEndTagsThoroughly() {
    for (; this.currentTagId !== void 0 && Re.has(this.currentTagId); )
      this.pop();
  }
  generateImpliedEndTagsWithExclusion(t) {
    for (; this.currentTagId !== void 0 && this.currentTagId !== t && Re.has(this.currentTagId); )
      this.pop();
  }
}
const oe = 3;
var R;
(function(e) {
  e[e.Marker = 0] = "Marker", e[e.Element = 1] = "Element";
})(R || (R = {}));
const xe = { type: R.Marker };
class au {
  constructor(t) {
    this.treeAdapter = t, this.entries = [], this.bookmark = null;
  }
  //Noah Ark's condition
  //OPTIMIZATION: at first we try to find possible candidates for exclusion using
  //lightweight heuristics without thorough attributes check.
  _getNoahArkConditionCandidates(t, a) {
    const s = [], o = a.length, E = this.treeAdapter.getTagName(t), h = this.treeAdapter.getNamespaceURI(t);
    for (let f = 0; f < this.entries.length; f++) {
      const m = this.entries[f];
      if (m.type === R.Marker)
        break;
      const { element: _ } = m;
      if (this.treeAdapter.getTagName(_) === E && this.treeAdapter.getNamespaceURI(_) === h) {
        const g = this.treeAdapter.getAttrList(_);
        g.length === o && s.push({ idx: f, attrs: g });
      }
    }
    return s;
  }
  _ensureNoahArkCondition(t) {
    if (this.entries.length < oe)
      return;
    const a = this.treeAdapter.getAttrList(t), s = this._getNoahArkConditionCandidates(t, a);
    if (s.length < oe)
      return;
    const o = new Map(a.map((h) => [h.name, h.value]));
    let E = 0;
    for (let h = 0; h < s.length; h++) {
      const f = s[h];
      f.attrs.every((m) => o.get(m.name) === m.value) && (E += 1, E >= oe && this.entries.splice(f.idx, 1));
    }
  }
  //Mutations
  insertMarker() {
    this.entries.unshift(xe);
  }
  pushElement(t, a) {
    this._ensureNoahArkCondition(t), this.entries.unshift({
      type: R.Element,
      element: t,
      token: a
    });
  }
  insertElementAfterBookmark(t, a) {
    const s = this.entries.indexOf(this.bookmark);
    this.entries.splice(s, 0, {
      type: R.Element,
      element: t,
      token: a
    });
  }
  removeEntry(t) {
    const a = this.entries.indexOf(t);
    a !== -1 && this.entries.splice(a, 1);
  }
  /**
   * Clears the list of formatting elements up to the last marker.
   *
   * @see https://html.spec.whatwg.org/multipage/parsing.html#clear-the-list-of-active-formatting-elements-up-to-the-last-marker
   */
  clearToLastMarker() {
    const t = this.entries.indexOf(xe);
    t === -1 ? this.entries.length = 0 : this.entries.splice(0, t + 1);
  }
  //Search
  getElementEntryInScopeWithTagName(t) {
    const a = this.entries.find((s) => s.type === R.Marker || this.treeAdapter.getTagName(s.element) === t);
    return a && a.type === R.Element ? a : null;
  }
  getElementEntry(t) {
    return this.entries.find((a) => a.type === R.Element && a.element === t);
  }
}
const M = {
  //Node construction
  createDocument() {
    return {
      nodeName: "#document",
      mode: S.NO_QUIRKS,
      childNodes: []
    };
  },
  createDocumentFragment() {
    return {
      nodeName: "#document-fragment",
      childNodes: []
    };
  },
  createElement(e, t, a) {
    return {
      nodeName: e,
      tagName: e,
      attrs: a,
      namespaceURI: t,
      childNodes: [],
      parentNode: null
    };
  },
  createCommentNode(e) {
    return {
      nodeName: "#comment",
      data: e,
      parentNode: null
    };
  },
  createTextNode(e) {
    return {
      nodeName: "#text",
      value: e,
      parentNode: null
    };
  },
  //Tree mutation
  appendChild(e, t) {
    e.childNodes.push(t), t.parentNode = e;
  },
  insertBefore(e, t, a) {
    const s = e.childNodes.indexOf(a);
    e.childNodes.splice(s, 0, t), t.parentNode = e;
  },
  setTemplateContent(e, t) {
    e.content = t;
  },
  getTemplateContent(e) {
    return e.content;
  },
  setDocumentType(e, t, a, s) {
    const o = e.childNodes.find((E) => E.nodeName === "#documentType");
    if (o)
      o.name = t, o.publicId = a, o.systemId = s;
    else {
      const E = {
        nodeName: "#documentType",
        name: t,
        publicId: a,
        systemId: s,
        parentNode: null
      };
      M.appendChild(e, E);
    }
  },
  setDocumentMode(e, t) {
    e.mode = t;
  },
  getDocumentMode(e) {
    return e.mode;
  },
  detachNode(e) {
    if (e.parentNode) {
      const t = e.parentNode.childNodes.indexOf(e);
      e.parentNode.childNodes.splice(t, 1), e.parentNode = null;
    }
  },
  insertText(e, t) {
    if (e.childNodes.length > 0) {
      const a = e.childNodes[e.childNodes.length - 1];
      if (M.isTextNode(a)) {
        a.value += t;
        return;
      }
    }
    M.appendChild(e, M.createTextNode(t));
  },
  insertTextBefore(e, t, a) {
    const s = e.childNodes[e.childNodes.indexOf(a) - 1];
    s && M.isTextNode(s) ? s.value += t : M.insertBefore(e, M.createTextNode(t), a);
  },
  adoptAttributes(e, t) {
    const a = new Set(e.attrs.map((s) => s.name));
    for (let s = 0; s < t.length; s++)
      a.has(t[s].name) || e.attrs.push(t[s]);
  },
  //Tree traversing
  getFirstChild(e) {
    return e.childNodes[0];
  },
  getChildNodes(e) {
    return e.childNodes;
  },
  getParentNode(e) {
    return e.parentNode;
  },
  getAttrList(e) {
    return e.attrs;
  },
  //Node data
  getTagName(e) {
    return e.tagName;
  },
  getNamespaceURI(e) {
    return e.namespaceURI;
  },
  getTextNodeContent(e) {
    return e.value;
  },
  getCommentNodeContent(e) {
    return e.data;
  },
  getDocumentTypeNodeName(e) {
    return e.name;
  },
  getDocumentTypeNodePublicId(e) {
    return e.publicId;
  },
  getDocumentTypeNodeSystemId(e) {
    return e.systemId;
  },
  //Node types
  isTextNode(e) {
    return e.nodeName === "#text";
  },
  isCommentNode(e) {
    return e.nodeName === "#comment";
  },
  isDocumentTypeNode(e) {
    return e.nodeName === "#documentType";
  },
  isElementNode(e) {
    return Object.prototype.hasOwnProperty.call(e, "tagName");
  },
  // Source code location
  setNodeSourceCodeLocation(e, t) {
    e.sourceCodeLocation = t;
  },
  getNodeSourceCodeLocation(e) {
    return e.sourceCodeLocation;
  },
  updateNodeSourceCodeLocation(e, t) {
    e.sourceCodeLocation = { ...e.sourceCodeLocation, ...t };
  }
}, Xe = "html", su = "about:legacy-compat", ru = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd", Ve = [
  "+//silmaril//dtd html pro v0r11 19970101//",
  "-//as//dtd html 3.0 aswedit + extensions//",
  "-//advasoft ltd//dtd html 3.0 aswedit + extensions//",
  "-//ietf//dtd html 2.0 level 1//",
  "-//ietf//dtd html 2.0 level 2//",
  "-//ietf//dtd html 2.0 strict level 1//",
  "-//ietf//dtd html 2.0 strict level 2//",
  "-//ietf//dtd html 2.0 strict//",
  "-//ietf//dtd html 2.0//",
  "-//ietf//dtd html 2.1e//",
  "-//ietf//dtd html 3.0//",
  "-//ietf//dtd html 3.2 final//",
  "-//ietf//dtd html 3.2//",
  "-//ietf//dtd html 3//",
  "-//ietf//dtd html level 0//",
  "-//ietf//dtd html level 1//",
  "-//ietf//dtd html level 2//",
  "-//ietf//dtd html level 3//",
  "-//ietf//dtd html strict level 0//",
  "-//ietf//dtd html strict level 1//",
  "-//ietf//dtd html strict level 2//",
  "-//ietf//dtd html strict level 3//",
  "-//ietf//dtd html strict//",
  "-//ietf//dtd html//",
  "-//metrius//dtd metrius presentational//",
  "-//microsoft//dtd internet explorer 2.0 html strict//",
  "-//microsoft//dtd internet explorer 2.0 html//",
  "-//microsoft//dtd internet explorer 2.0 tables//",
  "-//microsoft//dtd internet explorer 3.0 html strict//",
  "-//microsoft//dtd internet explorer 3.0 html//",
  "-//microsoft//dtd internet explorer 3.0 tables//",
  "-//netscape comm. corp.//dtd html//",
  "-//netscape comm. corp.//dtd strict html//",
  "-//o'reilly and associates//dtd html 2.0//",
  "-//o'reilly and associates//dtd html extended 1.0//",
  "-//o'reilly and associates//dtd html extended relaxed 1.0//",
  "-//sq//dtd html 2.0 hotmetal + extensions//",
  "-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//",
  "-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//",
  "-//spyglass//dtd html 2.0 extended//",
  "-//sun microsystems corp.//dtd hotjava html//",
  "-//sun microsystems corp.//dtd hotjava strict html//",
  "-//w3c//dtd html 3 1995-03-24//",
  "-//w3c//dtd html 3.2 draft//",
  "-//w3c//dtd html 3.2 final//",
  "-//w3c//dtd html 3.2//",
  "-//w3c//dtd html 3.2s draft//",
  "-//w3c//dtd html 4.0 frameset//",
  "-//w3c//dtd html 4.0 transitional//",
  "-//w3c//dtd html experimental 19960712//",
  "-//w3c//dtd html experimental 970421//",
  "-//w3c//dtd w3 html//",
  "-//w3o//dtd w3 html 3.0//",
  "-//webtechs//dtd mozilla html 2.0//",
  "-//webtechs//dtd mozilla html//"
], nu = [
  ...Ve,
  "-//w3c//dtd html 4.01 frameset//",
  "-//w3c//dtd html 4.01 transitional//"
], iu = /* @__PURE__ */ new Set([
  "-//w3o//dtd w3 html strict 3.0//en//",
  "-/w3c/dtd html 4.0 transitional/en",
  "html"
]), ze = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"], cu = [
  ...ze,
  "-//w3c//dtd html 4.01 frameset//",
  "-//w3c//dtd html 4.01 transitional//"
];
function Me(e, t) {
  return t.some((a) => e.startsWith(a));
}
function ou(e) {
  return e.name === Xe && e.publicId === null && (e.systemId === null || e.systemId === su);
}
function du(e) {
  if (e.name !== Xe)
    return S.QUIRKS;
  const { systemId: t } = e;
  if (t && t.toLowerCase() === ru)
    return S.QUIRKS;
  let { publicId: a } = e;
  if (a !== null) {
    if (a = a.toLowerCase(), iu.has(a))
      return S.QUIRKS;
    let s = t === null ? nu : Ve;
    if (Me(a, s))
      return S.QUIRKS;
    if (s = t === null ? ze : cu, Me(a, s))
      return S.LIMITED_QUIRKS;
  }
  return S.NO_QUIRKS;
}
const Be = {
  TEXT_HTML: "text/html",
  APPLICATION_XML: "application/xhtml+xml"
}, Eu = "definitionurl", Tu = "definitionURL", lu = new Map([
  "attributeName",
  "attributeType",
  "baseFrequency",
  "baseProfile",
  "calcMode",
  "clipPathUnits",
  "diffuseConstant",
  "edgeMode",
  "filterUnits",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "kernelMatrix",
  "kernelUnitLength",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "limitingConeAngle",
  "markerHeight",
  "markerUnits",
  "markerWidth",
  "maskContentUnits",
  "maskUnits",
  "numOctaves",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "refX",
  "refY",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "specularConstant",
  "specularExponent",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stitchTiles",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textLength",
  "viewBox",
  "viewTarget",
  "xChannelSelector",
  "yChannelSelector",
  "zoomAndPan"
].map((e) => [e.toLowerCase(), e])), hu = /* @__PURE__ */ new Map([
  ["xlink:actuate", { prefix: "xlink", name: "actuate", namespace: T.XLINK }],
  ["xlink:arcrole", { prefix: "xlink", name: "arcrole", namespace: T.XLINK }],
  ["xlink:href", { prefix: "xlink", name: "href", namespace: T.XLINK }],
  ["xlink:role", { prefix: "xlink", name: "role", namespace: T.XLINK }],
  ["xlink:show", { prefix: "xlink", name: "show", namespace: T.XLINK }],
  ["xlink:title", { prefix: "xlink", name: "title", namespace: T.XLINK }],
  ["xlink:type", { prefix: "xlink", name: "type", namespace: T.XLINK }],
  ["xml:lang", { prefix: "xml", name: "lang", namespace: T.XML }],
  ["xml:space", { prefix: "xml", name: "space", namespace: T.XML }],
  ["xmlns", { prefix: "", name: "xmlns", namespace: T.XMLNS }],
  ["xmlns:xlink", { prefix: "xmlns", name: "xlink", namespace: T.XMLNS }]
]), fu = new Map([
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "textPath"
].map((e) => [e.toLowerCase(), e])), mu = /* @__PURE__ */ new Set([
  u.B,
  u.BIG,
  u.BLOCKQUOTE,
  u.BODY,
  u.BR,
  u.CENTER,
  u.CODE,
  u.DD,
  u.DIV,
  u.DL,
  u.DT,
  u.EM,
  u.EMBED,
  u.H1,
  u.H2,
  u.H3,
  u.H4,
  u.H5,
  u.H6,
  u.HEAD,
  u.HR,
  u.I,
  u.IMG,
  u.LI,
  u.LISTING,
  u.MENU,
  u.META,
  u.NOBR,
  u.OL,
  u.P,
  u.PRE,
  u.RUBY,
  u.S,
  u.SMALL,
  u.SPAN,
  u.STRONG,
  u.STRIKE,
  u.SUB,
  u.SUP,
  u.TABLE,
  u.TT,
  u.U,
  u.UL,
  u.VAR
]);
function bu(e) {
  const t = e.tagID;
  return t === u.FONT && e.attrs.some(({ name: s }) => s === U.COLOR || s === U.SIZE || s === U.FACE) || mu.has(t);
}
function je(e) {
  for (let t = 0; t < e.attrs.length; t++)
    if (e.attrs[t].name === Eu) {
      e.attrs[t].name = Tu;
      break;
    }
}
function Je(e) {
  for (let t = 0; t < e.attrs.length; t++) {
    const a = lu.get(e.attrs[t].name);
    a != null && (e.attrs[t].name = a);
  }
}
function me(e) {
  for (let t = 0; t < e.attrs.length; t++) {
    const a = hu.get(e.attrs[t].name);
    a && (e.attrs[t].prefix = a.prefix, e.attrs[t].name = a.name, e.attrs[t].namespace = a.namespace);
  }
}
function _u(e) {
  const t = fu.get(e.tagName);
  t != null && (e.tagName = t, e.tagID = ue(e.tagName));
}
function Au(e, t) {
  return t === T.MATHML && (e === u.MI || e === u.MO || e === u.MN || e === u.MS || e === u.MTEXT);
}
function Iu(e, t, a) {
  if (t === T.MATHML && e === u.ANNOTATION_XML) {
    for (let s = 0; s < a.length; s++)
      if (a[s].name === U.ENCODING) {
        const o = a[s].value.toLowerCase();
        return o === Be.TEXT_HTML || o === Be.APPLICATION_XML;
      }
  }
  return t === T.SVG && (e === u.FOREIGN_OBJECT || e === u.DESC || e === u.TITLE);
}
function Nu(e, t, a, s) {
  return (!s || s === T.HTML) && Iu(e, t, a) || (!s || s === T.MATHML) && Au(e, t);
}
const pu = "hidden", Cu = 8, Ou = 3;
var i;
(function(e) {
  e[e.INITIAL = 0] = "INITIAL", e[e.BEFORE_HTML = 1] = "BEFORE_HTML", e[e.BEFORE_HEAD = 2] = "BEFORE_HEAD", e[e.IN_HEAD = 3] = "IN_HEAD", e[e.IN_HEAD_NO_SCRIPT = 4] = "IN_HEAD_NO_SCRIPT", e[e.AFTER_HEAD = 5] = "AFTER_HEAD", e[e.IN_BODY = 6] = "IN_BODY", e[e.TEXT = 7] = "TEXT", e[e.IN_TABLE = 8] = "IN_TABLE", e[e.IN_TABLE_TEXT = 9] = "IN_TABLE_TEXT", e[e.IN_CAPTION = 10] = "IN_CAPTION", e[e.IN_COLUMN_GROUP = 11] = "IN_COLUMN_GROUP", e[e.IN_TABLE_BODY = 12] = "IN_TABLE_BODY", e[e.IN_ROW = 13] = "IN_ROW", e[e.IN_CELL = 14] = "IN_CELL", e[e.IN_SELECT = 15] = "IN_SELECT", e[e.IN_SELECT_IN_TABLE = 16] = "IN_SELECT_IN_TABLE", e[e.IN_TEMPLATE = 17] = "IN_TEMPLATE", e[e.AFTER_BODY = 18] = "AFTER_BODY", e[e.IN_FRAMESET = 19] = "IN_FRAMESET", e[e.AFTER_FRAMESET = 20] = "AFTER_FRAMESET", e[e.AFTER_AFTER_BODY = 21] = "AFTER_AFTER_BODY", e[e.AFTER_AFTER_FRAMESET = 22] = "AFTER_AFTER_FRAMESET";
})(i || (i = {}));
const Su = {
  startLine: -1,
  startCol: -1,
  startOffset: -1,
  endLine: -1,
  endCol: -1,
  endOffset: -1
}, Ze = /* @__PURE__ */ new Set([u.TABLE, u.TBODY, u.TFOOT, u.THEAD, u.TR]), Ue = {
  scriptingEnabled: !0,
  sourceCodeLocationInfo: !1,
  treeAdapter: M,
  onParseError: null
};
class $e {
  constructor(t, a, s = null, o = null) {
    this.fragmentContext = s, this.scriptHandler = o, this.currentToken = null, this.stopped = !1, this.insertionMode = i.INITIAL, this.originalInsertionMode = i.INITIAL, this.headElement = null, this.formElement = null, this.currentNotInHTML = !1, this.tmplInsertionModeStack = [], this.pendingCharacterTokens = [], this.hasNonWhitespacePendingCharacterToken = !1, this.framesetOk = !0, this.skipNextNewLine = !1, this.fosterParentingEnabled = !1, this.options = {
      ...Ue,
      ...t
    }, this.treeAdapter = this.options.treeAdapter, this.onParseError = this.options.onParseError, this.onParseError && (this.options.sourceCodeLocationInfo = !0), this.document = a ?? this.treeAdapter.createDocument(), this.tokenizer = new zt(this.options, this), this.activeFormattingElements = new au(this.treeAdapter), this.fragmentContextID = s ? ue(this.treeAdapter.getTagName(s)) : u.UNKNOWN, this._setContextModes(s ?? this.document, this.fragmentContextID), this.openElements = new uu(this.document, this.treeAdapter, this);
  }
  // API
  static parse(t, a) {
    const s = new this(a);
    return s.tokenizer.write(t, !0), s.document;
  }
  static getFragmentParser(t, a) {
    const s = {
      ...Ue,
      ...a
    };
    t ?? (t = s.treeAdapter.createElement(c.TEMPLATE, T.HTML, []));
    const o = s.treeAdapter.createElement("documentmock", T.HTML, []), E = new this(s, o, t);
    return E.fragmentContextID === u.TEMPLATE && E.tmplInsertionModeStack.unshift(i.IN_TEMPLATE), E._initTokenizerForFragmentParsing(), E._insertFakeRootElement(), E._resetInsertionMode(), E._findFormInFragmentContext(), E;
  }
  getFragment() {
    const t = this.treeAdapter.getFirstChild(this.document), a = this.treeAdapter.createDocumentFragment();
    return this._adoptNodes(t, a), a;
  }
  //Errors
  /** @internal */
  _err(t, a, s) {
    var o;
    if (!this.onParseError)
      return;
    const E = (o = t.location) !== null && o !== void 0 ? o : Su, h = {
      code: a,
      startLine: E.startLine,
      startCol: E.startCol,
      startOffset: E.startOffset,
      endLine: s ? E.startLine : E.endLine,
      endCol: s ? E.startCol : E.endCol,
      endOffset: s ? E.startOffset : E.endOffset
    };
    this.onParseError(h);
  }
  //Stack events
  /** @internal */
  onItemPush(t, a, s) {
    var o, E;
    (E = (o = this.treeAdapter).onItemPush) === null || E === void 0 || E.call(o, t), s && this.openElements.stackTop > 0 && this._setContextModes(t, a);
  }
  /** @internal */
  onItemPop(t, a) {
    var s, o;
    if (this.options.sourceCodeLocationInfo && this._setEndLocation(t, this.currentToken), (o = (s = this.treeAdapter).onItemPop) === null || o === void 0 || o.call(s, t, this.openElements.current), a) {
      let E, h;
      this.openElements.stackTop === 0 && this.fragmentContext ? (E = this.fragmentContext, h = this.fragmentContextID) : { current: E, currentTagId: h } = this.openElements, this._setContextModes(E, h);
    }
  }
  _setContextModes(t, a) {
    const s = t === this.document || t && this.treeAdapter.getNamespaceURI(t) === T.HTML;
    this.currentNotInHTML = !s, this.tokenizer.inForeignNode = !s && t !== void 0 && a !== void 0 && !this._isIntegrationPoint(a, t);
  }
  /** @protected */
  _switchToTextParsing(t, a) {
    this._insertElement(t, T.HTML), this.tokenizer.state = a, this.originalInsertionMode = this.insertionMode, this.insertionMode = i.TEXT;
  }
  switchToPlaintextParsing() {
    this.insertionMode = i.TEXT, this.originalInsertionMode = i.IN_BODY, this.tokenizer.state = O.PLAINTEXT;
  }
  //Fragment parsing
  /** @protected */
  _getAdjustedCurrentElement() {
    return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
  }
  /** @protected */
  _findFormInFragmentContext() {
    let t = this.fragmentContext;
    for (; t; ) {
      if (this.treeAdapter.getTagName(t) === c.FORM) {
        this.formElement = t;
        break;
      }
      t = this.treeAdapter.getParentNode(t);
    }
  }
  _initTokenizerForFragmentParsing() {
    if (!(!this.fragmentContext || this.treeAdapter.getNamespaceURI(this.fragmentContext) !== T.HTML))
      switch (this.fragmentContextID) {
        case u.TITLE:
        case u.TEXTAREA: {
          this.tokenizer.state = O.RCDATA;
          break;
        }
        case u.STYLE:
        case u.XMP:
        case u.IFRAME:
        case u.NOEMBED:
        case u.NOFRAMES:
        case u.NOSCRIPT: {
          this.tokenizer.state = O.RAWTEXT;
          break;
        }
        case u.SCRIPT: {
          this.tokenizer.state = O.SCRIPT_DATA;
          break;
        }
        case u.PLAINTEXT: {
          this.tokenizer.state = O.PLAINTEXT;
          break;
        }
      }
  }
  //Tree mutation
  /** @protected */
  _setDocumentType(t) {
    const a = t.name || "", s = t.publicId || "", o = t.systemId || "";
    if (this.treeAdapter.setDocumentType(this.document, a, s, o), t.location) {
      const h = this.treeAdapter.getChildNodes(this.document).find((f) => this.treeAdapter.isDocumentTypeNode(f));
      h && this.treeAdapter.setNodeSourceCodeLocation(h, t.location);
    }
  }
  /** @protected */
  _attachElementToTree(t, a) {
    if (this.options.sourceCodeLocationInfo) {
      const s = a && {
        ...a,
        startTag: a
      };
      this.treeAdapter.setNodeSourceCodeLocation(t, s);
    }
    if (this._shouldFosterParentOnInsertion())
      this._fosterParentElement(t);
    else {
      const s = this.openElements.currentTmplContentOrNode;
      this.treeAdapter.appendChild(s ?? this.document, t);
    }
  }
  /**
   * For self-closing tags. Add an element to the tree, but skip adding it
   * to the stack.
   */
  /** @protected */
  _appendElement(t, a) {
    const s = this.treeAdapter.createElement(t.tagName, a, t.attrs);
    this._attachElementToTree(s, t.location);
  }
  /** @protected */
  _insertElement(t, a) {
    const s = this.treeAdapter.createElement(t.tagName, a, t.attrs);
    this._attachElementToTree(s, t.location), this.openElements.push(s, t.tagID);
  }
  /** @protected */
  _insertFakeElement(t, a) {
    const s = this.treeAdapter.createElement(t, T.HTML, []);
    this._attachElementToTree(s, null), this.openElements.push(s, a);
  }
  /** @protected */
  _insertTemplate(t) {
    const a = this.treeAdapter.createElement(t.tagName, T.HTML, t.attrs), s = this.treeAdapter.createDocumentFragment();
    this.treeAdapter.setTemplateContent(a, s), this._attachElementToTree(a, t.location), this.openElements.push(a, t.tagID), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(s, null);
  }
  /** @protected */
  _insertFakeRootElement() {
    const t = this.treeAdapter.createElement(c.HTML, T.HTML, []);
    this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(t, null), this.treeAdapter.appendChild(this.openElements.current, t), this.openElements.push(t, u.HTML);
  }
  /** @protected */
  _appendCommentNode(t, a) {
    const s = this.treeAdapter.createCommentNode(t.data);
    this.treeAdapter.appendChild(a, s), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(s, t.location);
  }
  /** @protected */
  _insertCharacters(t) {
    let a, s;
    if (this._shouldFosterParentOnInsertion() ? ({ parent: a, beforeElement: s } = this._findFosterParentingLocation(), s ? this.treeAdapter.insertTextBefore(a, t.chars, s) : this.treeAdapter.insertText(a, t.chars)) : (a = this.openElements.currentTmplContentOrNode, this.treeAdapter.insertText(a, t.chars)), !t.location)
      return;
    const o = this.treeAdapter.getChildNodes(a), E = s ? o.lastIndexOf(s) : o.length, h = o[E - 1];
    if (this.treeAdapter.getNodeSourceCodeLocation(h)) {
      const { endLine: m, endCol: _, endOffset: g } = t.location;
      this.treeAdapter.updateNodeSourceCodeLocation(h, { endLine: m, endCol: _, endOffset: g });
    } else this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(h, t.location);
  }
  /** @protected */
  _adoptNodes(t, a) {
    for (let s = this.treeAdapter.getFirstChild(t); s; s = this.treeAdapter.getFirstChild(t))
      this.treeAdapter.detachNode(s), this.treeAdapter.appendChild(a, s);
  }
  /** @protected */
  _setEndLocation(t, a) {
    if (this.treeAdapter.getNodeSourceCodeLocation(t) && a.location) {
      const s = a.location, o = this.treeAdapter.getTagName(t), E = (
        // NOTE: For cases like <p> <p> </p> - First 'p' closes without a closing
        // tag and for cases like <td> <p> </td> - 'p' closes without a closing tag.
        a.type === b.END_TAG && o === a.tagName ? {
          endTag: { ...s },
          endLine: s.endLine,
          endCol: s.endCol,
          endOffset: s.endOffset
        } : {
          endLine: s.startLine,
          endCol: s.startCol,
          endOffset: s.startOffset
        }
      );
      this.treeAdapter.updateNodeSourceCodeLocation(t, E);
    }
  }
  //Token processing
  shouldProcessStartTagTokenInForeignContent(t) {
    if (!this.currentNotInHTML)
      return !1;
    let a, s;
    return this.openElements.stackTop === 0 && this.fragmentContext ? (a = this.fragmentContext, s = this.fragmentContextID) : { current: a, currentTagId: s } = this.openElements, t.tagID === u.SVG && this.treeAdapter.getTagName(a) === c.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(a) === T.MATHML ? !1 : (
      // Check that `current` is not an integration point for HTML or MathML elements.
      this.tokenizer.inForeignNode || // If it _is_ an integration point, then we might have to check that it is not an HTML
      // integration point.
      (t.tagID === u.MGLYPH || t.tagID === u.MALIGNMARK) && s !== void 0 && !this._isIntegrationPoint(s, a, T.HTML)
    );
  }
  /** @protected */
  _processToken(t) {
    switch (t.type) {
      case b.CHARACTER: {
        this.onCharacter(t);
        break;
      }
      case b.NULL_CHARACTER: {
        this.onNullCharacter(t);
        break;
      }
      case b.COMMENT: {
        this.onComment(t);
        break;
      }
      case b.DOCTYPE: {
        this.onDoctype(t);
        break;
      }
      case b.START_TAG: {
        this._processStartTag(t);
        break;
      }
      case b.END_TAG: {
        this.onEndTag(t);
        break;
      }
      case b.EOF: {
        this.onEof(t);
        break;
      }
      case b.WHITESPACE_CHARACTER: {
        this.onWhitespaceCharacter(t);
        break;
      }
    }
  }
  //Integration points
  /** @protected */
  _isIntegrationPoint(t, a, s) {
    const o = this.treeAdapter.getNamespaceURI(a), E = this.treeAdapter.getAttrList(a);
    return Nu(t, o, E, s);
  }
  //Active formatting elements reconstruction
  /** @protected */
  _reconstructActiveFormattingElements() {
    const t = this.activeFormattingElements.entries.length;
    if (t) {
      const a = this.activeFormattingElements.entries.findIndex((o) => o.type === R.Marker || this.openElements.contains(o.element)), s = a === -1 ? t - 1 : a - 1;
      for (let o = s; o >= 0; o--) {
        const E = this.activeFormattingElements.entries[o];
        this._insertElement(E.token, this.treeAdapter.getNamespaceURI(E.element)), E.element = this.openElements.current;
      }
    }
  }
  //Close elements
  /** @protected */
  _closeTableCell() {
    this.openElements.generateImpliedEndTags(), this.openElements.popUntilTableCellPopped(), this.activeFormattingElements.clearToLastMarker(), this.insertionMode = i.IN_ROW;
  }
  /** @protected */
  _closePElement() {
    this.openElements.generateImpliedEndTagsWithExclusion(u.P), this.openElements.popUntilTagNamePopped(u.P);
  }
  //Insertion modes
  /** @protected */
  _resetInsertionMode() {
    for (let t = this.openElements.stackTop; t >= 0; t--)
      switch (t === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[t]) {
        case u.TR: {
          this.insertionMode = i.IN_ROW;
          return;
        }
        case u.TBODY:
        case u.THEAD:
        case u.TFOOT: {
          this.insertionMode = i.IN_TABLE_BODY;
          return;
        }
        case u.CAPTION: {
          this.insertionMode = i.IN_CAPTION;
          return;
        }
        case u.COLGROUP: {
          this.insertionMode = i.IN_COLUMN_GROUP;
          return;
        }
        case u.TABLE: {
          this.insertionMode = i.IN_TABLE;
          return;
        }
        case u.BODY: {
          this.insertionMode = i.IN_BODY;
          return;
        }
        case u.FRAMESET: {
          this.insertionMode = i.IN_FRAMESET;
          return;
        }
        case u.SELECT: {
          this._resetInsertionModeForSelect(t);
          return;
        }
        case u.TEMPLATE: {
          this.insertionMode = this.tmplInsertionModeStack[0];
          return;
        }
        case u.HTML: {
          this.insertionMode = this.headElement ? i.AFTER_HEAD : i.BEFORE_HEAD;
          return;
        }
        case u.TD:
        case u.TH: {
          if (t > 0) {
            this.insertionMode = i.IN_CELL;
            return;
          }
          break;
        }
        case u.HEAD: {
          if (t > 0) {
            this.insertionMode = i.IN_HEAD;
            return;
          }
          break;
        }
      }
    this.insertionMode = i.IN_BODY;
  }
  /** @protected */
  _resetInsertionModeForSelect(t) {
    if (t > 0)
      for (let a = t - 1; a > 0; a--) {
        const s = this.openElements.tagIDs[a];
        if (s === u.TEMPLATE)
          break;
        if (s === u.TABLE) {
          this.insertionMode = i.IN_SELECT_IN_TABLE;
          return;
        }
      }
    this.insertionMode = i.IN_SELECT;
  }
  //Foster parenting
  /** @protected */
  _isElementCausesFosterParenting(t) {
    return Ze.has(t);
  }
  /** @protected */
  _shouldFosterParentOnInsertion() {
    return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
  }
  /** @protected */
  _findFosterParentingLocation() {
    for (let t = this.openElements.stackTop; t >= 0; t--) {
      const a = this.openElements.items[t];
      switch (this.openElements.tagIDs[t]) {
        case u.TEMPLATE: {
          if (this.treeAdapter.getNamespaceURI(a) === T.HTML)
            return { parent: this.treeAdapter.getTemplateContent(a), beforeElement: null };
          break;
        }
        case u.TABLE: {
          const s = this.treeAdapter.getParentNode(a);
          return s ? { parent: s, beforeElement: a } : { parent: this.openElements.items[t - 1], beforeElement: null };
        }
      }
    }
    return { parent: this.openElements.items[0], beforeElement: null };
  }
  /** @protected */
  _fosterParentElement(t) {
    const a = this._findFosterParentingLocation();
    a.beforeElement ? this.treeAdapter.insertBefore(a.parent, t, a.beforeElement) : this.treeAdapter.appendChild(a.parent, t);
  }
  //Special elements
  /** @protected */
  _isSpecialElement(t, a) {
    const s = this.treeAdapter.getNamespaceURI(t);
    return Gt[s].has(a);
  }
  /** @internal */
  onCharacter(t) {
    if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) {
      ts(this, t);
      return;
    }
    switch (this.insertionMode) {
      case i.INITIAL: {
        Y(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        W(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        q(this, t);
        break;
      }
      case i.IN_HEAD: {
        G(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        K(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        X(this, t);
        break;
      }
      case i.IN_BODY:
      case i.IN_CAPTION:
      case i.IN_CELL:
      case i.IN_TEMPLATE: {
        tt(this, t);
        break;
      }
      case i.TEXT:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE: {
        this._insertCharacters(t);
        break;
      }
      case i.IN_TABLE:
      case i.IN_TABLE_BODY:
      case i.IN_ROW: {
        de(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        it(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        ee(this, t);
        break;
      }
      case i.AFTER_BODY: {
        te(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        Z(this, t);
        break;
      }
    }
  }
  /** @internal */
  onNullCharacter(t) {
    if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) {
      es(this, t);
      return;
    }
    switch (this.insertionMode) {
      case i.INITIAL: {
        Y(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        W(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        q(this, t);
        break;
      }
      case i.IN_HEAD: {
        G(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        K(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        X(this, t);
        break;
      }
      case i.TEXT: {
        this._insertCharacters(t);
        break;
      }
      case i.IN_TABLE:
      case i.IN_TABLE_BODY:
      case i.IN_ROW: {
        de(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        ee(this, t);
        break;
      }
      case i.AFTER_BODY: {
        te(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        Z(this, t);
        break;
      }
    }
  }
  /** @internal */
  onComment(t) {
    if (this.skipNextNewLine = !1, this.currentNotInHTML) {
      le(this, t);
      return;
    }
    switch (this.insertionMode) {
      case i.INITIAL:
      case i.BEFORE_HTML:
      case i.BEFORE_HEAD:
      case i.IN_HEAD:
      case i.IN_HEAD_NO_SCRIPT:
      case i.AFTER_HEAD:
      case i.IN_BODY:
      case i.IN_TABLE:
      case i.IN_CAPTION:
      case i.IN_COLUMN_GROUP:
      case i.IN_TABLE_BODY:
      case i.IN_ROW:
      case i.IN_CELL:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE:
      case i.IN_TEMPLATE:
      case i.IN_FRAMESET:
      case i.AFTER_FRAMESET: {
        le(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        v(this, t);
        break;
      }
      case i.AFTER_BODY: {
        Mu(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY:
      case i.AFTER_AFTER_FRAMESET: {
        Bu(this, t);
        break;
      }
    }
  }
  /** @internal */
  onDoctype(t) {
    switch (this.skipNextNewLine = !1, this.insertionMode) {
      case i.INITIAL: {
        Uu(this, t);
        break;
      }
      case i.BEFORE_HEAD:
      case i.IN_HEAD:
      case i.IN_HEAD_NO_SCRIPT:
      case i.AFTER_HEAD: {
        this._err(t, d.misplacedDoctype);
        break;
      }
      case i.IN_TABLE_TEXT: {
        v(this, t);
        break;
      }
    }
  }
  /** @internal */
  onStartTag(t) {
    this.skipNextNewLine = !1, this.currentToken = t, this._processStartTag(t), t.selfClosing && !t.ackSelfClosing && this._err(t, d.nonVoidHtmlElementStartTagWithTrailingSolidus);
  }
  /**
   * Processes a given start tag.
   *
   * `onStartTag` checks if a self-closing tag was recognized. When a token
   * is moved inbetween multiple insertion modes, this check for self-closing
   * could lead to false positives. To avoid this, `_processStartTag` is used
   * for nested calls.
   *
   * @param token The token to process.
   * @protected
   */
  _processStartTag(t) {
    this.shouldProcessStartTagTokenInForeignContent(t) ? us(this, t) : this._startTagOutsideForeignContent(t);
  }
  /** @protected */
  _startTagOutsideForeignContent(t) {
    switch (this.insertionMode) {
      case i.INITIAL: {
        Y(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        Hu(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        Fu(this, t);
        break;
      }
      case i.IN_HEAD: {
        L(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        Yu(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        Qu(this, t);
        break;
      }
      case i.IN_BODY: {
        p(this, t);
        break;
      }
      case i.IN_TABLE: {
        F(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        v(this, t);
        break;
      }
      case i.IN_CAPTION: {
        ya(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        Ae(this, t);
        break;
      }
      case i.IN_TABLE_BODY: {
        re(this, t);
        break;
      }
      case i.IN_ROW: {
        ne(this, t);
        break;
      }
      case i.IN_CELL: {
        va(this, t);
        break;
      }
      case i.IN_SELECT: {
        dt(this, t);
        break;
      }
      case i.IN_SELECT_IN_TABLE: {
        Wa(this, t);
        break;
      }
      case i.IN_TEMPLATE: {
        Ga(this, t);
        break;
      }
      case i.AFTER_BODY: {
        Xa(this, t);
        break;
      }
      case i.IN_FRAMESET: {
        Va(this, t);
        break;
      }
      case i.AFTER_FRAMESET: {
        ja(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        Za(this, t);
        break;
      }
      case i.AFTER_AFTER_FRAMESET: {
        $a(this, t);
        break;
      }
    }
  }
  /** @internal */
  onEndTag(t) {
    this.skipNextNewLine = !1, this.currentToken = t, this.currentNotInHTML ? as(this, t) : this._endTagOutsideForeignContent(t);
  }
  /** @protected */
  _endTagOutsideForeignContent(t) {
    switch (this.insertionMode) {
      case i.INITIAL: {
        Y(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        ku(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        yu(this, t);
        break;
      }
      case i.IN_HEAD: {
        wu(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        vu(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        Wu(this, t);
        break;
      }
      case i.IN_BODY: {
        se(this, t);
        break;
      }
      case i.TEXT: {
        Ra(this, t);
        break;
      }
      case i.IN_TABLE: {
        V(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        v(this, t);
        break;
      }
      case i.IN_CAPTION: {
        wa(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        Ya(this, t);
        break;
      }
      case i.IN_TABLE_BODY: {
        he(this, t);
        break;
      }
      case i.IN_ROW: {
        ot(this, t);
        break;
      }
      case i.IN_CELL: {
        Qa(this, t);
        break;
      }
      case i.IN_SELECT: {
        Et(this, t);
        break;
      }
      case i.IN_SELECT_IN_TABLE: {
        qa(this, t);
        break;
      }
      case i.IN_TEMPLATE: {
        Ka(this, t);
        break;
      }
      case i.AFTER_BODY: {
        lt(this, t);
        break;
      }
      case i.IN_FRAMESET: {
        za(this, t);
        break;
      }
      case i.AFTER_FRAMESET: {
        Ja(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        Z(this, t);
        break;
      }
    }
  }
  /** @internal */
  onEof(t) {
    switch (this.insertionMode) {
      case i.INITIAL: {
        Y(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        W(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        q(this, t);
        break;
      }
      case i.IN_HEAD: {
        G(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        K(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        X(this, t);
        break;
      }
      case i.IN_BODY:
      case i.IN_TABLE:
      case i.IN_CAPTION:
      case i.IN_COLUMN_GROUP:
      case i.IN_TABLE_BODY:
      case i.IN_ROW:
      case i.IN_CELL:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE: {
        rt(this, t);
        break;
      }
      case i.TEXT: {
        Da(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        v(this, t);
        break;
      }
      case i.IN_TEMPLATE: {
        Tt(this, t);
        break;
      }
      case i.AFTER_BODY:
      case i.IN_FRAMESET:
      case i.AFTER_FRAMESET:
      case i.AFTER_AFTER_BODY:
      case i.AFTER_AFTER_FRAMESET: {
        _e(this, t);
        break;
      }
    }
  }
  /** @internal */
  onWhitespaceCharacter(t) {
    if (this.skipNextNewLine && (this.skipNextNewLine = !1, t.chars.charCodeAt(0) === r.LINE_FEED)) {
      if (t.chars.length === 1)
        return;
      t.chars = t.chars.substr(1);
    }
    if (this.tokenizer.inForeignNode) {
      this._insertCharacters(t);
      return;
    }
    switch (this.insertionMode) {
      case i.IN_HEAD:
      case i.IN_HEAD_NO_SCRIPT:
      case i.AFTER_HEAD:
      case i.TEXT:
      case i.IN_COLUMN_GROUP:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE:
      case i.IN_FRAMESET:
      case i.AFTER_FRAMESET: {
        this._insertCharacters(t);
        break;
      }
      case i.IN_BODY:
      case i.IN_CAPTION:
      case i.IN_CELL:
      case i.IN_TEMPLATE:
      case i.AFTER_BODY:
      case i.AFTER_AFTER_BODY:
      case i.AFTER_AFTER_FRAMESET: {
        et(this, t);
        break;
      }
      case i.IN_TABLE:
      case i.IN_TABLE_BODY:
      case i.IN_ROW: {
        de(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        nt(this, t);
        break;
      }
    }
  }
}
function gu(e, t) {
  let a = e.activeFormattingElements.getElementEntryInScopeWithTagName(t.tagName);
  return a ? e.openElements.contains(a.element) ? e.openElements.hasInScope(t.tagID) || (a = null) : (e.activeFormattingElements.removeEntry(a), a = null) : st(e, t), a;
}
function Lu(e, t) {
  let a = null, s = e.openElements.stackTop;
  for (; s >= 0; s--) {
    const o = e.openElements.items[s];
    if (o === t.element)
      break;
    e._isSpecialElement(o, e.openElements.tagIDs[s]) && (a = o);
  }
  return a || (e.openElements.shortenToLength(Math.max(s, 0)), e.activeFormattingElements.removeEntry(t)), a;
}
function Ru(e, t, a) {
  let s = t, o = e.openElements.getCommonAncestor(t);
  for (let E = 0, h = o; h !== a; E++, h = o) {
    o = e.openElements.getCommonAncestor(h);
    const f = e.activeFormattingElements.getElementEntry(h), m = f && E >= Ou;
    !f || m ? (m && e.activeFormattingElements.removeEntry(f), e.openElements.remove(h)) : (h = Du(e, f), s === t && (e.activeFormattingElements.bookmark = f), e.treeAdapter.detachNode(s), e.treeAdapter.appendChild(h, s), s = h);
  }
  return s;
}
function Du(e, t) {
  const a = e.treeAdapter.getNamespaceURI(t.element), s = e.treeAdapter.createElement(t.token.tagName, a, t.token.attrs);
  return e.openElements.replace(t.element, s), t.element = s, s;
}
function Pu(e, t, a) {
  const s = e.treeAdapter.getTagName(t), o = ue(s);
  if (e._isElementCausesFosterParenting(o))
    e._fosterParentElement(a);
  else {
    const E = e.treeAdapter.getNamespaceURI(t);
    o === u.TEMPLATE && E === T.HTML && (t = e.treeAdapter.getTemplateContent(t)), e.treeAdapter.appendChild(t, a);
  }
}
function xu(e, t, a) {
  const s = e.treeAdapter.getNamespaceURI(a.element), { token: o } = a, E = e.treeAdapter.createElement(o.tagName, s, o.attrs);
  e._adoptNodes(t, E), e.treeAdapter.appendChild(t, E), e.activeFormattingElements.insertElementAfterBookmark(E, o), e.activeFormattingElements.removeEntry(a), e.openElements.remove(a.element), e.openElements.insertAfter(t, E, o.tagID);
}
function be(e, t) {
  for (let a = 0; a < Cu; a++) {
    const s = gu(e, t);
    if (!s)
      break;
    const o = Lu(e, s);
    if (!o)
      break;
    e.activeFormattingElements.bookmark = s;
    const E = Ru(e, o, s.element), h = e.openElements.getCommonAncestor(s.element);
    e.treeAdapter.detachNode(E), h && Pu(e, h, E), xu(e, o, s);
  }
}
function le(e, t) {
  e._appendCommentNode(t, e.openElements.currentTmplContentOrNode);
}
function Mu(e, t) {
  e._appendCommentNode(t, e.openElements.items[0]);
}
function Bu(e, t) {
  e._appendCommentNode(t, e.document);
}
function _e(e, t) {
  if (e.stopped = !0, t.location) {
    const a = e.fragmentContext ? 0 : 2;
    for (let s = e.openElements.stackTop; s >= a; s--)
      e._setEndLocation(e.openElements.items[s], t);
    if (!e.fragmentContext && e.openElements.stackTop >= 0) {
      const s = e.openElements.items[0], o = e.treeAdapter.getNodeSourceCodeLocation(s);
      if (o && !o.endTag && (e._setEndLocation(s, t), e.openElements.stackTop >= 1)) {
        const E = e.openElements.items[1], h = e.treeAdapter.getNodeSourceCodeLocation(E);
        h && !h.endTag && e._setEndLocation(E, t);
      }
    }
  }
}
function Uu(e, t) {
  e._setDocumentType(t);
  const a = t.forceQuirks ? S.QUIRKS : du(t);
  ou(t) || e._err(t, d.nonConformingDoctype), e.treeAdapter.setDocumentMode(e.document, a), e.insertionMode = i.BEFORE_HTML;
}
function Y(e, t) {
  e._err(t, d.missingDoctype, !0), e.treeAdapter.setDocumentMode(e.document, S.QUIRKS), e.insertionMode = i.BEFORE_HTML, e._processToken(t);
}
function Hu(e, t) {
  t.tagID === u.HTML ? (e._insertElement(t, T.HTML), e.insertionMode = i.BEFORE_HEAD) : W(e, t);
}
function ku(e, t) {
  const a = t.tagID;
  (a === u.HTML || a === u.HEAD || a === u.BODY || a === u.BR) && W(e, t);
}
function W(e, t) {
  e._insertFakeRootElement(), e.insertionMode = i.BEFORE_HEAD, e._processToken(t);
}
function Fu(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.HEAD: {
      e._insertElement(t, T.HTML), e.headElement = e.openElements.current, e.insertionMode = i.IN_HEAD;
      break;
    }
    default:
      q(e, t);
  }
}
function yu(e, t) {
  const a = t.tagID;
  a === u.HEAD || a === u.BODY || a === u.HTML || a === u.BR ? q(e, t) : e._err(t, d.endTagWithoutMatchingOpenElement);
}
function q(e, t) {
  e._insertFakeElement(c.HEAD, u.HEAD), e.headElement = e.openElements.current, e.insertionMode = i.IN_HEAD, e._processToken(t);
}
function L(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.BASE:
    case u.BASEFONT:
    case u.BGSOUND:
    case u.LINK:
    case u.META: {
      e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.TITLE: {
      e._switchToTextParsing(t, O.RCDATA);
      break;
    }
    case u.NOSCRIPT: {
      e.options.scriptingEnabled ? e._switchToTextParsing(t, O.RAWTEXT) : (e._insertElement(t, T.HTML), e.insertionMode = i.IN_HEAD_NO_SCRIPT);
      break;
    }
    case u.NOFRAMES:
    case u.STYLE: {
      e._switchToTextParsing(t, O.RAWTEXT);
      break;
    }
    case u.SCRIPT: {
      e._switchToTextParsing(t, O.SCRIPT_DATA);
      break;
    }
    case u.TEMPLATE: {
      e._insertTemplate(t), e.activeFormattingElements.insertMarker(), e.framesetOk = !1, e.insertionMode = i.IN_TEMPLATE, e.tmplInsertionModeStack.unshift(i.IN_TEMPLATE);
      break;
    }
    case u.HEAD: {
      e._err(t, d.misplacedStartTagForHeadElement);
      break;
    }
    default:
      G(e, t);
  }
}
function wu(e, t) {
  switch (t.tagID) {
    case u.HEAD: {
      e.openElements.pop(), e.insertionMode = i.AFTER_HEAD;
      break;
    }
    case u.BODY:
    case u.BR:
    case u.HTML: {
      G(e, t);
      break;
    }
    case u.TEMPLATE: {
      H(e, t);
      break;
    }
    default:
      e._err(t, d.endTagWithoutMatchingOpenElement);
  }
}
function H(e, t) {
  e.openElements.tmplCount > 0 ? (e.openElements.generateImpliedEndTagsThoroughly(), e.openElements.currentTagId !== u.TEMPLATE && e._err(t, d.closingOfElementWithOpenChildElements), e.openElements.popUntilTagNamePopped(u.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode()) : e._err(t, d.endTagWithoutMatchingOpenElement);
}
function G(e, t) {
  e.openElements.pop(), e.insertionMode = i.AFTER_HEAD, e._processToken(t);
}
function Yu(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.BASEFONT:
    case u.BGSOUND:
    case u.HEAD:
    case u.LINK:
    case u.META:
    case u.NOFRAMES:
    case u.STYLE: {
      L(e, t);
      break;
    }
    case u.NOSCRIPT: {
      e._err(t, d.nestedNoscriptInHead);
      break;
    }
    default:
      K(e, t);
  }
}
function vu(e, t) {
  switch (t.tagID) {
    case u.NOSCRIPT: {
      e.openElements.pop(), e.insertionMode = i.IN_HEAD;
      break;
    }
    case u.BR: {
      K(e, t);
      break;
    }
    default:
      e._err(t, d.endTagWithoutMatchingOpenElement);
  }
}
function K(e, t) {
  const a = t.type === b.EOF ? d.openElementsLeftAfterEof : d.disallowedContentInNoscriptInHead;
  e._err(t, a), e.openElements.pop(), e.insertionMode = i.IN_HEAD, e._processToken(t);
}
function Qu(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.BODY: {
      e._insertElement(t, T.HTML), e.framesetOk = !1, e.insertionMode = i.IN_BODY;
      break;
    }
    case u.FRAMESET: {
      e._insertElement(t, T.HTML), e.insertionMode = i.IN_FRAMESET;
      break;
    }
    case u.BASE:
    case u.BASEFONT:
    case u.BGSOUND:
    case u.LINK:
    case u.META:
    case u.NOFRAMES:
    case u.SCRIPT:
    case u.STYLE:
    case u.TEMPLATE:
    case u.TITLE: {
      e._err(t, d.abandonedHeadElementChild), e.openElements.push(e.headElement, u.HEAD), L(e, t), e.openElements.remove(e.headElement);
      break;
    }
    case u.HEAD: {
      e._err(t, d.misplacedStartTagForHeadElement);
      break;
    }
    default:
      X(e, t);
  }
}
function Wu(e, t) {
  switch (t.tagID) {
    case u.BODY:
    case u.HTML:
    case u.BR: {
      X(e, t);
      break;
    }
    case u.TEMPLATE: {
      H(e, t);
      break;
    }
    default:
      e._err(t, d.endTagWithoutMatchingOpenElement);
  }
}
function X(e, t) {
  e._insertFakeElement(c.BODY, u.BODY), e.insertionMode = i.IN_BODY, ae(e, t);
}
function ae(e, t) {
  switch (t.type) {
    case b.CHARACTER: {
      tt(e, t);
      break;
    }
    case b.WHITESPACE_CHARACTER: {
      et(e, t);
      break;
    }
    case b.COMMENT: {
      le(e, t);
      break;
    }
    case b.START_TAG: {
      p(e, t);
      break;
    }
    case b.END_TAG: {
      se(e, t);
      break;
    }
    case b.EOF: {
      rt(e, t);
      break;
    }
  }
}
function et(e, t) {
  e._reconstructActiveFormattingElements(), e._insertCharacters(t);
}
function tt(e, t) {
  e._reconstructActiveFormattingElements(), e._insertCharacters(t), e.framesetOk = !1;
}
function qu(e, t) {
  e.openElements.tmplCount === 0 && e.treeAdapter.adoptAttributes(e.openElements.items[0], t.attrs);
}
function Gu(e, t) {
  const a = e.openElements.tryPeekProperlyNestedBodyElement();
  a && e.openElements.tmplCount === 0 && (e.framesetOk = !1, e.treeAdapter.adoptAttributes(a, t.attrs));
}
function Ku(e, t) {
  const a = e.openElements.tryPeekProperlyNestedBodyElement();
  e.framesetOk && a && (e.treeAdapter.detachNode(a), e.openElements.popAllUpToHtmlElement(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_FRAMESET);
}
function Xu(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML);
}
function Vu(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e.openElements.currentTagId !== void 0 && Te.has(e.openElements.currentTagId) && e.openElements.pop(), e._insertElement(t, T.HTML);
}
function zu(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), e.skipNextNewLine = !0, e.framesetOk = !1;
}
function ju(e, t) {
  const a = e.openElements.tmplCount > 0;
  (!e.formElement || a) && (e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), a || (e.formElement = e.openElements.current));
}
function Ju(e, t) {
  e.framesetOk = !1;
  const a = t.tagID;
  for (let s = e.openElements.stackTop; s >= 0; s--) {
    const o = e.openElements.tagIDs[s];
    if (a === u.LI && o === u.LI || (a === u.DD || a === u.DT) && (o === u.DD || o === u.DT)) {
      e.openElements.generateImpliedEndTagsWithExclusion(o), e.openElements.popUntilTagNamePopped(o);
      break;
    }
    if (o !== u.ADDRESS && o !== u.DIV && o !== u.P && e._isSpecialElement(e.openElements.items[s], o))
      break;
  }
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML);
}
function Zu(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), e.tokenizer.state = O.PLAINTEXT;
}
function $u(e, t) {
  e.openElements.hasInScope(u.BUTTON) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(u.BUTTON)), e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.framesetOk = !1;
}
function ea(e, t) {
  const a = e.activeFormattingElements.getElementEntryInScopeWithTagName(c.A);
  a && (be(e, t), e.openElements.remove(a.element), e.activeFormattingElements.removeEntry(a)), e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function ta(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function ua(e, t) {
  e._reconstructActiveFormattingElements(), e.openElements.hasInScope(u.NOBR) && (be(e, t), e._reconstructActiveFormattingElements()), e._insertElement(t, T.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function aa(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.activeFormattingElements.insertMarker(), e.framesetOk = !1;
}
function sa(e, t) {
  e.treeAdapter.getDocumentMode(e.document) !== S.QUIRKS && e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), e.framesetOk = !1, e.insertionMode = i.IN_TABLE;
}
function ut(e, t) {
  e._reconstructActiveFormattingElements(), e._appendElement(t, T.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function at(e) {
  const t = qe(e, U.TYPE);
  return t != null && t.toLowerCase() === pu;
}
function ra(e, t) {
  e._reconstructActiveFormattingElements(), e._appendElement(t, T.HTML), at(t) || (e.framesetOk = !1), t.ackSelfClosing = !0;
}
function na(e, t) {
  e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
}
function ia(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._appendElement(t, T.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function ca(e, t) {
  t.tagName = c.IMG, t.tagID = u.IMG, ut(e, t);
}
function oa(e, t) {
  e._insertElement(t, T.HTML), e.skipNextNewLine = !0, e.tokenizer.state = O.RCDATA, e.originalInsertionMode = e.insertionMode, e.framesetOk = !1, e.insertionMode = i.TEXT;
}
function da(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._reconstructActiveFormattingElements(), e.framesetOk = !1, e._switchToTextParsing(t, O.RAWTEXT);
}
function Ea(e, t) {
  e.framesetOk = !1, e._switchToTextParsing(t, O.RAWTEXT);
}
function He(e, t) {
  e._switchToTextParsing(t, O.RAWTEXT);
}
function Ta(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.framesetOk = !1, e.insertionMode = e.insertionMode === i.IN_TABLE || e.insertionMode === i.IN_CAPTION || e.insertionMode === i.IN_TABLE_BODY || e.insertionMode === i.IN_ROW || e.insertionMode === i.IN_CELL ? i.IN_SELECT_IN_TABLE : i.IN_SELECT;
}
function la(e, t) {
  e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML);
}
function ha(e, t) {
  e.openElements.hasInScope(u.RUBY) && e.openElements.generateImpliedEndTags(), e._insertElement(t, T.HTML);
}
function fa(e, t) {
  e.openElements.hasInScope(u.RUBY) && e.openElements.generateImpliedEndTagsWithExclusion(u.RTC), e._insertElement(t, T.HTML);
}
function ma(e, t) {
  e._reconstructActiveFormattingElements(), je(t), me(t), t.selfClosing ? e._appendElement(t, T.MATHML) : e._insertElement(t, T.MATHML), t.ackSelfClosing = !0;
}
function ba(e, t) {
  e._reconstructActiveFormattingElements(), Je(t), me(t), t.selfClosing ? e._appendElement(t, T.SVG) : e._insertElement(t, T.SVG), t.ackSelfClosing = !0;
}
function ke(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML);
}
function p(e, t) {
  switch (t.tagID) {
    case u.I:
    case u.S:
    case u.B:
    case u.U:
    case u.EM:
    case u.TT:
    case u.BIG:
    case u.CODE:
    case u.FONT:
    case u.SMALL:
    case u.STRIKE:
    case u.STRONG: {
      ta(e, t);
      break;
    }
    case u.A: {
      ea(e, t);
      break;
    }
    case u.H1:
    case u.H2:
    case u.H3:
    case u.H4:
    case u.H5:
    case u.H6: {
      Vu(e, t);
      break;
    }
    case u.P:
    case u.DL:
    case u.OL:
    case u.UL:
    case u.DIV:
    case u.DIR:
    case u.NAV:
    case u.MAIN:
    case u.MENU:
    case u.ASIDE:
    case u.CENTER:
    case u.FIGURE:
    case u.FOOTER:
    case u.HEADER:
    case u.HGROUP:
    case u.DIALOG:
    case u.DETAILS:
    case u.ADDRESS:
    case u.ARTICLE:
    case u.SEARCH:
    case u.SECTION:
    case u.SUMMARY:
    case u.FIELDSET:
    case u.BLOCKQUOTE:
    case u.FIGCAPTION: {
      Xu(e, t);
      break;
    }
    case u.LI:
    case u.DD:
    case u.DT: {
      Ju(e, t);
      break;
    }
    case u.BR:
    case u.IMG:
    case u.WBR:
    case u.AREA:
    case u.EMBED:
    case u.KEYGEN: {
      ut(e, t);
      break;
    }
    case u.HR: {
      ia(e, t);
      break;
    }
    case u.RB:
    case u.RTC: {
      ha(e, t);
      break;
    }
    case u.RT:
    case u.RP: {
      fa(e, t);
      break;
    }
    case u.PRE:
    case u.LISTING: {
      zu(e, t);
      break;
    }
    case u.XMP: {
      da(e, t);
      break;
    }
    case u.SVG: {
      ba(e, t);
      break;
    }
    case u.HTML: {
      qu(e, t);
      break;
    }
    case u.BASE:
    case u.LINK:
    case u.META:
    case u.STYLE:
    case u.TITLE:
    case u.SCRIPT:
    case u.BGSOUND:
    case u.BASEFONT:
    case u.TEMPLATE: {
      L(e, t);
      break;
    }
    case u.BODY: {
      Gu(e, t);
      break;
    }
    case u.FORM: {
      ju(e, t);
      break;
    }
    case u.NOBR: {
      ua(e, t);
      break;
    }
    case u.MATH: {
      ma(e, t);
      break;
    }
    case u.TABLE: {
      sa(e, t);
      break;
    }
    case u.INPUT: {
      ra(e, t);
      break;
    }
    case u.PARAM:
    case u.TRACK:
    case u.SOURCE: {
      na(e, t);
      break;
    }
    case u.IMAGE: {
      ca(e, t);
      break;
    }
    case u.BUTTON: {
      $u(e, t);
      break;
    }
    case u.APPLET:
    case u.OBJECT:
    case u.MARQUEE: {
      aa(e, t);
      break;
    }
    case u.IFRAME: {
      Ea(e, t);
      break;
    }
    case u.SELECT: {
      Ta(e, t);
      break;
    }
    case u.OPTION:
    case u.OPTGROUP: {
      la(e, t);
      break;
    }
    case u.NOEMBED:
    case u.NOFRAMES: {
      He(e, t);
      break;
    }
    case u.FRAMESET: {
      Ku(e, t);
      break;
    }
    case u.TEXTAREA: {
      oa(e, t);
      break;
    }
    case u.NOSCRIPT: {
      e.options.scriptingEnabled ? He(e, t) : ke(e, t);
      break;
    }
    case u.PLAINTEXT: {
      Zu(e, t);
      break;
    }
    case u.COL:
    case u.TH:
    case u.TD:
    case u.TR:
    case u.HEAD:
    case u.FRAME:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD:
    case u.CAPTION:
    case u.COLGROUP:
      break;
    default:
      ke(e, t);
  }
}
function _a(e, t) {
  if (e.openElements.hasInScope(u.BODY) && (e.insertionMode = i.AFTER_BODY, e.options.sourceCodeLocationInfo)) {
    const a = e.openElements.tryPeekProperlyNestedBodyElement();
    a && e._setEndLocation(a, t);
  }
}
function Aa(e, t) {
  e.openElements.hasInScope(u.BODY) && (e.insertionMode = i.AFTER_BODY, lt(e, t));
}
function Ia(e, t) {
  const a = t.tagID;
  e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a));
}
function Na(e) {
  const t = e.openElements.tmplCount > 0, { formElement: a } = e;
  t || (e.formElement = null), (a || t) && e.openElements.hasInScope(u.FORM) && (e.openElements.generateImpliedEndTags(), t ? e.openElements.popUntilTagNamePopped(u.FORM) : a && e.openElements.remove(a));
}
function pa(e) {
  e.openElements.hasInButtonScope(u.P) || e._insertFakeElement(c.P, u.P), e._closePElement();
}
function Ca(e) {
  e.openElements.hasInListItemScope(u.LI) && (e.openElements.generateImpliedEndTagsWithExclusion(u.LI), e.openElements.popUntilTagNamePopped(u.LI));
}
function Oa(e, t) {
  const a = t.tagID;
  e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTagsWithExclusion(a), e.openElements.popUntilTagNamePopped(a));
}
function Sa(e) {
  e.openElements.hasNumberedHeaderInScope() && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilNumberedHeaderPopped());
}
function ga(e, t) {
  const a = t.tagID;
  e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a), e.activeFormattingElements.clearToLastMarker());
}
function La(e) {
  e._reconstructActiveFormattingElements(), e._insertFakeElement(c.BR, u.BR), e.openElements.pop(), e.framesetOk = !1;
}
function st(e, t) {
  const a = t.tagName, s = t.tagID;
  for (let o = e.openElements.stackTop; o > 0; o--) {
    const E = e.openElements.items[o], h = e.openElements.tagIDs[o];
    if (s === h && (s !== u.UNKNOWN || e.treeAdapter.getTagName(E) === a)) {
      e.openElements.generateImpliedEndTagsWithExclusion(s), e.openElements.stackTop >= o && e.openElements.shortenToLength(o);
      break;
    }
    if (e._isSpecialElement(E, h))
      break;
  }
}
function se(e, t) {
  switch (t.tagID) {
    case u.A:
    case u.B:
    case u.I:
    case u.S:
    case u.U:
    case u.EM:
    case u.TT:
    case u.BIG:
    case u.CODE:
    case u.FONT:
    case u.NOBR:
    case u.SMALL:
    case u.STRIKE:
    case u.STRONG: {
      be(e, t);
      break;
    }
    case u.P: {
      pa(e);
      break;
    }
    case u.DL:
    case u.UL:
    case u.OL:
    case u.DIR:
    case u.DIV:
    case u.NAV:
    case u.PRE:
    case u.MAIN:
    case u.MENU:
    case u.ASIDE:
    case u.BUTTON:
    case u.CENTER:
    case u.FIGURE:
    case u.FOOTER:
    case u.HEADER:
    case u.HGROUP:
    case u.DIALOG:
    case u.ADDRESS:
    case u.ARTICLE:
    case u.DETAILS:
    case u.SEARCH:
    case u.SECTION:
    case u.SUMMARY:
    case u.LISTING:
    case u.FIELDSET:
    case u.BLOCKQUOTE:
    case u.FIGCAPTION: {
      Ia(e, t);
      break;
    }
    case u.LI: {
      Ca(e);
      break;
    }
    case u.DD:
    case u.DT: {
      Oa(e, t);
      break;
    }
    case u.H1:
    case u.H2:
    case u.H3:
    case u.H4:
    case u.H5:
    case u.H6: {
      Sa(e);
      break;
    }
    case u.BR: {
      La(e);
      break;
    }
    case u.BODY: {
      _a(e, t);
      break;
    }
    case u.HTML: {
      Aa(e, t);
      break;
    }
    case u.FORM: {
      Na(e);
      break;
    }
    case u.APPLET:
    case u.OBJECT:
    case u.MARQUEE: {
      ga(e, t);
      break;
    }
    case u.TEMPLATE: {
      H(e, t);
      break;
    }
    default:
      st(e, t);
  }
}
function rt(e, t) {
  e.tmplInsertionModeStack.length > 0 ? Tt(e, t) : _e(e, t);
}
function Ra(e, t) {
  var a;
  t.tagID === u.SCRIPT && ((a = e.scriptHandler) === null || a === void 0 || a.call(e, e.openElements.current)), e.openElements.pop(), e.insertionMode = e.originalInsertionMode;
}
function Da(e, t) {
  e._err(t, d.eofInElementThatCanContainOnlyText), e.openElements.pop(), e.insertionMode = e.originalInsertionMode, e.onEof(t);
}
function de(e, t) {
  if (e.openElements.currentTagId !== void 0 && Ze.has(e.openElements.currentTagId))
    switch (e.pendingCharacterTokens.length = 0, e.hasNonWhitespacePendingCharacterToken = !1, e.originalInsertionMode = e.insertionMode, e.insertionMode = i.IN_TABLE_TEXT, t.type) {
      case b.CHARACTER: {
        it(e, t);
        break;
      }
      case b.WHITESPACE_CHARACTER: {
        nt(e, t);
        break;
      }
    }
  else
    z(e, t);
}
function Pa(e, t) {
  e.openElements.clearBackToTableContext(), e.activeFormattingElements.insertMarker(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_CAPTION;
}
function xa(e, t) {
  e.openElements.clearBackToTableContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_COLUMN_GROUP;
}
function Ma(e, t) {
  e.openElements.clearBackToTableContext(), e._insertFakeElement(c.COLGROUP, u.COLGROUP), e.insertionMode = i.IN_COLUMN_GROUP, Ae(e, t);
}
function Ba(e, t) {
  e.openElements.clearBackToTableContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_TABLE_BODY;
}
function Ua(e, t) {
  e.openElements.clearBackToTableContext(), e._insertFakeElement(c.TBODY, u.TBODY), e.insertionMode = i.IN_TABLE_BODY, re(e, t);
}
function Ha(e, t) {
  e.openElements.hasInTableScope(u.TABLE) && (e.openElements.popUntilTagNamePopped(u.TABLE), e._resetInsertionMode(), e._processStartTag(t));
}
function ka(e, t) {
  at(t) ? e._appendElement(t, T.HTML) : z(e, t), t.ackSelfClosing = !0;
}
function Fa(e, t) {
  !e.formElement && e.openElements.tmplCount === 0 && (e._insertElement(t, T.HTML), e.formElement = e.openElements.current, e.openElements.pop());
}
function F(e, t) {
  switch (t.tagID) {
    case u.TD:
    case u.TH:
    case u.TR: {
      Ua(e, t);
      break;
    }
    case u.STYLE:
    case u.SCRIPT:
    case u.TEMPLATE: {
      L(e, t);
      break;
    }
    case u.COL: {
      Ma(e, t);
      break;
    }
    case u.FORM: {
      Fa(e, t);
      break;
    }
    case u.TABLE: {
      Ha(e, t);
      break;
    }
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      Ba(e, t);
      break;
    }
    case u.INPUT: {
      ka(e, t);
      break;
    }
    case u.CAPTION: {
      Pa(e, t);
      break;
    }
    case u.COLGROUP: {
      xa(e, t);
      break;
    }
    default:
      z(e, t);
  }
}
function V(e, t) {
  switch (t.tagID) {
    case u.TABLE: {
      e.openElements.hasInTableScope(u.TABLE) && (e.openElements.popUntilTagNamePopped(u.TABLE), e._resetInsertionMode());
      break;
    }
    case u.TEMPLATE: {
      H(e, t);
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TBODY:
    case u.TD:
    case u.TFOOT:
    case u.TH:
    case u.THEAD:
    case u.TR:
      break;
    default:
      z(e, t);
  }
}
function z(e, t) {
  const a = e.fosterParentingEnabled;
  e.fosterParentingEnabled = !0, ae(e, t), e.fosterParentingEnabled = a;
}
function nt(e, t) {
  e.pendingCharacterTokens.push(t);
}
function it(e, t) {
  e.pendingCharacterTokens.push(t), e.hasNonWhitespacePendingCharacterToken = !0;
}
function v(e, t) {
  let a = 0;
  if (e.hasNonWhitespacePendingCharacterToken)
    for (; a < e.pendingCharacterTokens.length; a++)
      z(e, e.pendingCharacterTokens[a]);
  else
    for (; a < e.pendingCharacterTokens.length; a++)
      e._insertCharacters(e.pendingCharacterTokens[a]);
  e.insertionMode = e.originalInsertionMode, e._processToken(t);
}
const ct = /* @__PURE__ */ new Set([u.CAPTION, u.COL, u.COLGROUP, u.TBODY, u.TD, u.TFOOT, u.TH, u.THEAD, u.TR]);
function ya(e, t) {
  const a = t.tagID;
  ct.has(a) ? e.openElements.hasInTableScope(u.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(u.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = i.IN_TABLE, F(e, t)) : p(e, t);
}
function wa(e, t) {
  const a = t.tagID;
  switch (a) {
    case u.CAPTION:
    case u.TABLE: {
      e.openElements.hasInTableScope(u.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(u.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = i.IN_TABLE, a === u.TABLE && V(e, t));
      break;
    }
    case u.BODY:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TBODY:
    case u.TD:
    case u.TFOOT:
    case u.TH:
    case u.THEAD:
    case u.TR:
      break;
    default:
      se(e, t);
  }
}
function Ae(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.COL: {
      e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.TEMPLATE: {
      L(e, t);
      break;
    }
    default:
      ee(e, t);
  }
}
function Ya(e, t) {
  switch (t.tagID) {
    case u.COLGROUP: {
      e.openElements.currentTagId === u.COLGROUP && (e.openElements.pop(), e.insertionMode = i.IN_TABLE);
      break;
    }
    case u.TEMPLATE: {
      H(e, t);
      break;
    }
    case u.COL:
      break;
    default:
      ee(e, t);
  }
}
function ee(e, t) {
  e.openElements.currentTagId === u.COLGROUP && (e.openElements.pop(), e.insertionMode = i.IN_TABLE, e._processToken(t));
}
function re(e, t) {
  switch (t.tagID) {
    case u.TR: {
      e.openElements.clearBackToTableBodyContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_ROW;
      break;
    }
    case u.TH:
    case u.TD: {
      e.openElements.clearBackToTableBodyContext(), e._insertFakeElement(c.TR, u.TR), e.insertionMode = i.IN_ROW, ne(e, t);
      break;
    }
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE, F(e, t));
      break;
    }
    default:
      F(e, t);
  }
}
function he(e, t) {
  const a = t.tagID;
  switch (t.tagID) {
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      e.openElements.hasInTableScope(a) && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE);
      break;
    }
    case u.TABLE: {
      e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE, V(e, t));
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TD:
    case u.TH:
    case u.TR:
      break;
    default:
      V(e, t);
  }
}
function ne(e, t) {
  switch (t.tagID) {
    case u.TH:
    case u.TD: {
      e.openElements.clearBackToTableRowContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_CELL, e.activeFormattingElements.insertMarker();
      break;
    }
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD:
    case u.TR: {
      e.openElements.hasInTableScope(u.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY, re(e, t));
      break;
    }
    default:
      F(e, t);
  }
}
function ot(e, t) {
  switch (t.tagID) {
    case u.TR: {
      e.openElements.hasInTableScope(u.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY);
      break;
    }
    case u.TABLE: {
      e.openElements.hasInTableScope(u.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY, he(e, t));
      break;
    }
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      (e.openElements.hasInTableScope(t.tagID) || e.openElements.hasInTableScope(u.TR)) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY, he(e, t));
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TD:
    case u.TH:
      break;
    default:
      V(e, t);
  }
}
function va(e, t) {
  const a = t.tagID;
  ct.has(a) ? (e.openElements.hasInTableScope(u.TD) || e.openElements.hasInTableScope(u.TH)) && (e._closeTableCell(), ne(e, t)) : p(e, t);
}
function Qa(e, t) {
  const a = t.tagID;
  switch (a) {
    case u.TD:
    case u.TH: {
      e.openElements.hasInTableScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = i.IN_ROW);
      break;
    }
    case u.TABLE:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD:
    case u.TR: {
      e.openElements.hasInTableScope(a) && (e._closeTableCell(), ot(e, t));
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
      break;
    default:
      se(e, t);
  }
}
function dt(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.OPTION: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e._insertElement(t, T.HTML);
      break;
    }
    case u.OPTGROUP: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e.openElements.currentTagId === u.OPTGROUP && e.openElements.pop(), e._insertElement(t, T.HTML);
      break;
    }
    case u.HR: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e.openElements.currentTagId === u.OPTGROUP && e.openElements.pop(), e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.INPUT:
    case u.KEYGEN:
    case u.TEXTAREA:
    case u.SELECT: {
      e.openElements.hasInSelectScope(u.SELECT) && (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode(), t.tagID !== u.SELECT && e._processStartTag(t));
      break;
    }
    case u.SCRIPT:
    case u.TEMPLATE: {
      L(e, t);
      break;
    }
  }
}
function Et(e, t) {
  switch (t.tagID) {
    case u.OPTGROUP: {
      e.openElements.stackTop > 0 && e.openElements.currentTagId === u.OPTION && e.openElements.tagIDs[e.openElements.stackTop - 1] === u.OPTGROUP && e.openElements.pop(), e.openElements.currentTagId === u.OPTGROUP && e.openElements.pop();
      break;
    }
    case u.OPTION: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop();
      break;
    }
    case u.SELECT: {
      e.openElements.hasInSelectScope(u.SELECT) && (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode());
      break;
    }
    case u.TEMPLATE: {
      H(e, t);
      break;
    }
  }
}
function Wa(e, t) {
  const a = t.tagID;
  a === u.CAPTION || a === u.TABLE || a === u.TBODY || a === u.TFOOT || a === u.THEAD || a === u.TR || a === u.TD || a === u.TH ? (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode(), e._processStartTag(t)) : dt(e, t);
}
function qa(e, t) {
  const a = t.tagID;
  a === u.CAPTION || a === u.TABLE || a === u.TBODY || a === u.TFOOT || a === u.THEAD || a === u.TR || a === u.TD || a === u.TH ? e.openElements.hasInTableScope(a) && (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode(), e.onEndTag(t)) : Et(e, t);
}
function Ga(e, t) {
  switch (t.tagID) {
    case u.BASE:
    case u.BASEFONT:
    case u.BGSOUND:
    case u.LINK:
    case u.META:
    case u.NOFRAMES:
    case u.SCRIPT:
    case u.STYLE:
    case u.TEMPLATE:
    case u.TITLE: {
      L(e, t);
      break;
    }
    case u.CAPTION:
    case u.COLGROUP:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      e.tmplInsertionModeStack[0] = i.IN_TABLE, e.insertionMode = i.IN_TABLE, F(e, t);
      break;
    }
    case u.COL: {
      e.tmplInsertionModeStack[0] = i.IN_COLUMN_GROUP, e.insertionMode = i.IN_COLUMN_GROUP, Ae(e, t);
      break;
    }
    case u.TR: {
      e.tmplInsertionModeStack[0] = i.IN_TABLE_BODY, e.insertionMode = i.IN_TABLE_BODY, re(e, t);
      break;
    }
    case u.TD:
    case u.TH: {
      e.tmplInsertionModeStack[0] = i.IN_ROW, e.insertionMode = i.IN_ROW, ne(e, t);
      break;
    }
    default:
      e.tmplInsertionModeStack[0] = i.IN_BODY, e.insertionMode = i.IN_BODY, p(e, t);
  }
}
function Ka(e, t) {
  t.tagID === u.TEMPLATE && H(e, t);
}
function Tt(e, t) {
  e.openElements.tmplCount > 0 ? (e.openElements.popUntilTagNamePopped(u.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode(), e.onEof(t)) : _e(e, t);
}
function Xa(e, t) {
  t.tagID === u.HTML ? p(e, t) : te(e, t);
}
function lt(e, t) {
  var a;
  if (t.tagID === u.HTML) {
    if (e.fragmentContext || (e.insertionMode = i.AFTER_AFTER_BODY), e.options.sourceCodeLocationInfo && e.openElements.tagIDs[0] === u.HTML) {
      e._setEndLocation(e.openElements.items[0], t);
      const s = e.openElements.items[1];
      s && !(!((a = e.treeAdapter.getNodeSourceCodeLocation(s)) === null || a === void 0) && a.endTag) && e._setEndLocation(s, t);
    }
  } else
    te(e, t);
}
function te(e, t) {
  e.insertionMode = i.IN_BODY, ae(e, t);
}
function Va(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.FRAMESET: {
      e._insertElement(t, T.HTML);
      break;
    }
    case u.FRAME: {
      e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.NOFRAMES: {
      L(e, t);
      break;
    }
  }
}
function za(e, t) {
  t.tagID === u.FRAMESET && !e.openElements.isRootHtmlElementCurrent() && (e.openElements.pop(), !e.fragmentContext && e.openElements.currentTagId !== u.FRAMESET && (e.insertionMode = i.AFTER_FRAMESET));
}
function ja(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.NOFRAMES: {
      L(e, t);
      break;
    }
  }
}
function Ja(e, t) {
  t.tagID === u.HTML && (e.insertionMode = i.AFTER_AFTER_FRAMESET);
}
function Za(e, t) {
  t.tagID === u.HTML ? p(e, t) : Z(e, t);
}
function Z(e, t) {
  e.insertionMode = i.IN_BODY, ae(e, t);
}
function $a(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.NOFRAMES: {
      L(e, t);
      break;
    }
  }
}
function es(e, t) {
  t.chars = A, e._insertCharacters(t);
}
function ts(e, t) {
  e._insertCharacters(t), e.framesetOk = !1;
}
function ht(e) {
  for (; e.treeAdapter.getNamespaceURI(e.openElements.current) !== T.HTML && e.openElements.currentTagId !== void 0 && !e._isIntegrationPoint(e.openElements.currentTagId, e.openElements.current); )
    e.openElements.pop();
}
function us(e, t) {
  if (bu(t))
    ht(e), e._startTagOutsideForeignContent(t);
  else {
    const a = e._getAdjustedCurrentElement(), s = e.treeAdapter.getNamespaceURI(a);
    s === T.MATHML ? je(t) : s === T.SVG && (_u(t), Je(t)), me(t), t.selfClosing ? e._appendElement(t, s) : e._insertElement(t, s), t.ackSelfClosing = !0;
  }
}
function as(e, t) {
  if (t.tagID === u.P || t.tagID === u.BR) {
    ht(e), e._endTagOutsideForeignContent(t);
    return;
  }
  for (let a = e.openElements.stackTop; a > 0; a--) {
    const s = e.openElements.items[a];
    if (e.treeAdapter.getNamespaceURI(s) === T.HTML) {
      e._endTagOutsideForeignContent(t);
      break;
    }
    const o = e.treeAdapter.getTagName(s);
    if (o.toLowerCase() === t.tagName) {
      t.tagName = o, e.openElements.shortenToLength(a);
      break;
    }
  }
}
c.AREA, c.BASE, c.BASEFONT, c.BGSOUND, c.BR, c.COL, c.EMBED, c.FRAME, c.HR, c.IMG, c.INPUT, c.KEYGEN, c.LINK, c.META, c.PARAM, c.SOURCE, c.TRACK, c.WBR;
function ss(e, t) {
  return $e.parse(e, t);
}
function rs(e, t, a) {
  typeof e == "string" && (a = t, t = e, e = null);
  const s = $e.getFragmentParser(e, a);
  return s.tokenizer.write(t, !0), s.getFragment();
}
const ns = {
  /** @type {ErrorInfo} */
  abandonedHeadElementChild: {
    reason: "Unexpected metadata element after head",
    description: "Unexpected element after head. Expected the element before `</head>`",
    url: !1
  },
  /** @type {ErrorInfo} */
  abruptClosingOfEmptyComment: {
    reason: "Unexpected abruptly closed empty comment",
    description: "Unexpected `>` or `->`. Expected `-->` to close comments"
  },
  /** @type {ErrorInfo} */
  abruptDoctypePublicIdentifier: {
    reason: "Unexpected abruptly closed public identifier",
    description: "Unexpected `>`. Expected a closing `\"` or `'` after the public identifier"
  },
  /** @type {ErrorInfo} */
  abruptDoctypeSystemIdentifier: {
    reason: "Unexpected abruptly closed system identifier",
    description: "Unexpected `>`. Expected a closing `\"` or `'` after the identifier identifier"
  },
  /** @type {ErrorInfo} */
  absenceOfDigitsInNumericCharacterReference: {
    reason: "Unexpected non-digit at start of numeric character reference",
    description: "Unexpected `%c`. Expected `[0-9]` for decimal references or `[0-9a-fA-F]` for hexadecimal references"
  },
  /** @type {ErrorInfo} */
  cdataInHtmlContent: {
    reason: "Unexpected CDATA section in HTML",
    description: "Unexpected `<![CDATA[` in HTML. Remove it, use a comment, or encode special characters instead"
  },
  /** @type {ErrorInfo} */
  characterReferenceOutsideUnicodeRange: {
    reason: "Unexpected too big numeric character reference",
    description: "Unexpectedly high character reference. Expected character references to be at most hexadecimal 10ffff (or decimal 1114111)"
  },
  /** @type {ErrorInfo} */
  closingOfElementWithOpenChildElements: {
    reason: "Unexpected closing tag with open child elements",
    description: "Unexpectedly closing tag. Expected other tags to be closed first",
    url: !1
  },
  /** @type {ErrorInfo} */
  controlCharacterInInputStream: {
    reason: "Unexpected control character",
    description: "Unexpected control character `%x`. Expected a non-control code point, 0x00, or ASCII whitespace"
  },
  /** @type {ErrorInfo} */
  controlCharacterReference: {
    reason: "Unexpected control character reference",
    description: "Unexpectedly control character in reference. Expected a non-control code point, 0x00, or ASCII whitespace"
  },
  /** @type {ErrorInfo} */
  disallowedContentInNoscriptInHead: {
    reason: "Disallowed content inside `<noscript>` in `<head>`",
    description: "Unexpected text character `%c`. Only use text in `<noscript>`s in `<body>`",
    url: !1
  },
  /** @type {ErrorInfo} */
  duplicateAttribute: {
    reason: "Unexpected duplicate attribute",
    description: "Unexpectedly double attribute. Expected attributes to occur only once"
  },
  /** @type {ErrorInfo} */
  endTagWithAttributes: {
    reason: "Unexpected attribute on closing tag",
    description: "Unexpected attribute. Expected `>` instead"
  },
  /** @type {ErrorInfo} */
  endTagWithTrailingSolidus: {
    reason: "Unexpected slash at end of closing tag",
    description: "Unexpected `%c-1`. Expected `>` instead"
  },
  /** @type {ErrorInfo} */
  endTagWithoutMatchingOpenElement: {
    reason: "Unexpected unopened end tag",
    description: "Unexpected end tag. Expected no end tag or another end tag",
    url: !1
  },
  /** @type {ErrorInfo} */
  eofBeforeTagName: {
    reason: "Unexpected end of file",
    description: "Unexpected end of file. Expected tag name instead"
  },
  /** @type {ErrorInfo} */
  eofInCdata: {
    reason: "Unexpected end of file in CDATA",
    description: "Unexpected end of file. Expected `]]>` to close the CDATA"
  },
  /** @type {ErrorInfo} */
  eofInComment: {
    reason: "Unexpected end of file in comment",
    description: "Unexpected end of file. Expected `-->` to close the comment"
  },
  /** @type {ErrorInfo} */
  eofInDoctype: {
    reason: "Unexpected end of file in doctype",
    description: "Unexpected end of file. Expected a valid doctype (such as `<!doctype html>`)"
  },
  /** @type {ErrorInfo} */
  eofInElementThatCanContainOnlyText: {
    reason: "Unexpected end of file in element that can only contain text",
    description: "Unexpected end of file. Expected text or a closing tag",
    url: !1
  },
  /** @type {ErrorInfo} */
  eofInScriptHtmlCommentLikeText: {
    reason: "Unexpected end of file in comment inside script",
    description: "Unexpected end of file. Expected `-->` to close the comment"
  },
  /** @type {ErrorInfo} */
  eofInTag: {
    reason: "Unexpected end of file in tag",
    description: "Unexpected end of file. Expected `>` to close the tag"
  },
  /** @type {ErrorInfo} */
  incorrectlyClosedComment: {
    reason: "Incorrectly closed comment",
    description: "Unexpected `%c-1`. Expected `-->` to close the comment"
  },
  /** @type {ErrorInfo} */
  incorrectlyOpenedComment: {
    reason: "Incorrectly opened comment",
    description: "Unexpected `%c`. Expected `<!--` to open the comment"
  },
  /** @type {ErrorInfo} */
  invalidCharacterSequenceAfterDoctypeName: {
    reason: "Invalid sequence after doctype name",
    description: "Unexpected sequence at `%c`. Expected `public` or `system`"
  },
  /** @type {ErrorInfo} */
  invalidFirstCharacterOfTagName: {
    reason: "Invalid first character in tag name",
    description: "Unexpected `%c`. Expected an ASCII letter instead"
  },
  /** @type {ErrorInfo} */
  misplacedDoctype: {
    reason: "Misplaced doctype",
    description: "Unexpected doctype. Expected doctype before head",
    url: !1
  },
  /** @type {ErrorInfo} */
  misplacedStartTagForHeadElement: {
    reason: "Misplaced `<head>` start tag",
    description: "Unexpected start tag `<head>`. Expected `<head>` directly after doctype",
    url: !1
  },
  /** @type {ErrorInfo} */
  missingAttributeValue: {
    reason: "Missing attribute value",
    description: "Unexpected `%c-1`. Expected an attribute value or no `%c-1` instead"
  },
  /** @type {ErrorInfo} */
  missingDoctype: {
    reason: "Missing doctype before other content",
    description: "Expected a `<!doctype html>` before anything else",
    url: !1
  },
  /** @type {ErrorInfo} */
  missingDoctypeName: {
    reason: "Missing doctype name",
    description: "Unexpected doctype end at `%c`. Expected `html` instead"
  },
  /** @type {ErrorInfo} */
  missingDoctypePublicIdentifier: {
    reason: "Missing public identifier in doctype",
    description: "Unexpected `%c`. Expected identifier for `public` instead"
  },
  /** @type {ErrorInfo} */
  missingDoctypeSystemIdentifier: {
    reason: "Missing system identifier in doctype",
    description: 'Unexpected `%c`. Expected identifier for `system` instead (suggested: `"about:legacy-compat"`)'
  },
  /** @type {ErrorInfo} */
  missingEndTagName: {
    reason: "Missing name in end tag",
    description: "Unexpected `%c`. Expected an ASCII letter instead"
  },
  /** @type {ErrorInfo} */
  missingQuoteBeforeDoctypePublicIdentifier: {
    reason: "Missing quote before public identifier in doctype",
    description: "Unexpected `%c`. Expected `\"` or `'` instead"
  },
  /** @type {ErrorInfo} */
  missingQuoteBeforeDoctypeSystemIdentifier: {
    reason: "Missing quote before system identifier in doctype",
    description: "Unexpected `%c`. Expected `\"` or `'` instead"
  },
  /** @type {ErrorInfo} */
  missingSemicolonAfterCharacterReference: {
    reason: "Missing semicolon after character reference",
    description: "Unexpected `%c`. Expected `;` instead"
  },
  /** @type {ErrorInfo} */
  missingWhitespaceAfterDoctypePublicKeyword: {
    reason: "Missing whitespace after public identifier in doctype",
    description: "Unexpected `%c`. Expected ASCII whitespace instead"
  },
  /** @type {ErrorInfo} */
  missingWhitespaceAfterDoctypeSystemKeyword: {
    reason: "Missing whitespace after system identifier in doctype",
    description: "Unexpected `%c`. Expected ASCII whitespace instead"
  },
  /** @type {ErrorInfo} */
  missingWhitespaceBeforeDoctypeName: {
    reason: "Missing whitespace before doctype name",
    description: "Unexpected `%c`. Expected ASCII whitespace instead"
  },
  /** @type {ErrorInfo} */
  missingWhitespaceBetweenAttributes: {
    reason: "Missing whitespace between attributes",
    description: "Unexpected `%c`. Expected ASCII whitespace instead"
  },
  /** @type {ErrorInfo} */
  missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers: {
    reason: "Missing whitespace between public and system identifiers in doctype",
    description: "Unexpected `%c`. Expected ASCII whitespace instead"
  },
  /** @type {ErrorInfo} */
  nestedComment: {
    reason: "Unexpected nested comment",
    description: "Unexpected `<!--`. Expected `-->`"
  },
  /** @type {ErrorInfo} */
  nestedNoscriptInHead: {
    reason: "Unexpected nested `<noscript>` in `<head>`",
    description: "Unexpected `<noscript>`. Expected a closing tag or a meta element",
    url: !1
  },
  /** @type {ErrorInfo} */
  nonConformingDoctype: {
    reason: "Unexpected non-conforming doctype declaration",
    description: 'Expected `<!doctype html>` or `<!doctype html system "about:legacy-compat">`',
    url: !1
  },
  /** @type {ErrorInfo} */
  nonVoidHtmlElementStartTagWithTrailingSolidus: {
    reason: "Unexpected trailing slash on start tag of non-void element",
    description: "Unexpected `/`. Expected `>` instead"
  },
  /** @type {ErrorInfo} */
  noncharacterCharacterReference: {
    reason: "Unexpected noncharacter code point referenced by character reference",
    description: "Unexpected code point. Do not use noncharacters in HTML"
  },
  /** @type {ErrorInfo} */
  noncharacterInInputStream: {
    reason: "Unexpected noncharacter character",
    description: "Unexpected code point `%x`. Do not use noncharacters in HTML"
  },
  /** @type {ErrorInfo} */
  nullCharacterReference: {
    reason: "Unexpected NULL character referenced by character reference",
    description: "Unexpected code point. Do not use NULL characters in HTML"
  },
  /** @type {ErrorInfo} */
  openElementsLeftAfterEof: {
    reason: "Unexpected end of file",
    description: "Unexpected end of file. Expected closing tag instead",
    url: !1
  },
  /** @type {ErrorInfo} */
  surrogateCharacterReference: {
    reason: "Unexpected surrogate character referenced by character reference",
    description: "Unexpected code point. Do not use lone surrogate characters in HTML"
  },
  /** @type {ErrorInfo} */
  surrogateInInputStream: {
    reason: "Unexpected surrogate character",
    description: "Unexpected code point `%x`. Do not use lone surrogate characters in HTML"
  },
  /** @type {ErrorInfo} */
  unexpectedCharacterAfterDoctypeSystemIdentifier: {
    reason: "Invalid character after system identifier in doctype",
    description: "Unexpected character at `%c`. Expected `>`"
  },
  /** @type {ErrorInfo} */
  unexpectedCharacterInAttributeName: {
    reason: "Unexpected character in attribute name",
    description: "Unexpected `%c`. Expected whitespace, `/`, `>`, `=`, or probably an ASCII letter"
  },
  /** @type {ErrorInfo} */
  unexpectedCharacterInUnquotedAttributeValue: {
    reason: "Unexpected character in unquoted attribute value",
    description: "Unexpected `%c`. Quote the attribute value to include it"
  },
  /** @type {ErrorInfo} */
  unexpectedEqualsSignBeforeAttributeName: {
    reason: "Unexpected equals sign before attribute name",
    description: "Unexpected `%c`. Add an attribute name before it"
  },
  /** @type {ErrorInfo} */
  unexpectedNullCharacter: {
    reason: "Unexpected NULL character",
    description: "Unexpected code point `%x`. Do not use NULL characters in HTML"
  },
  /** @type {ErrorInfo} */
  unexpectedQuestionMarkInsteadOfTagName: {
    reason: "Unexpected question mark instead of tag name",
    description: "Unexpected `%c`. Expected an ASCII letter instead"
  },
  /** @type {ErrorInfo} */
  unexpectedSolidusInTag: {
    reason: "Unexpected slash in tag",
    description: "Unexpected `%c-1`. Expected it followed by `>` or in a quoted attribute value"
  },
  /** @type {ErrorInfo} */
  unknownNamedCharacterReference: {
    reason: "Unexpected unknown named character reference",
    description: "Unexpected character reference. Expected known named character references"
  }
}, is = "https://html.spec.whatwg.org/multipage/parsing.html#parse-error-", cs = /-[a-z]/g, os = /%c(?:([-+])(\d+))?/g, ds = /%x/g, Es = { 2: !0, 1: !1, 0: null }, Ts = {};
function ls(e, t) {
  const a = t || Ts, s = a.onerror, o = e instanceof Ce ? e : new Ce(e), E = a.fragment ? rs : ss, h = String(o), f = E(h, {
    sourceCodeLocationInfo: !0,
    // Note `parse5` types currently do not allow `undefined`.
    onParseError: a.onerror ? m : null,
    scriptingEnabled: !1
  });
  return (
    /** @type {Root} */
    Lt(f, {
      file: o,
      space: a.space,
      verbose: a.verbose
    })
  );
  function m(_) {
    const g = _.code, y = hs(g), ie = a[y], ce = ie ?? !0, Ie = typeof ce == "number" ? ce : ce ? 1 : 0;
    if (Ie) {
      const w = ns[y], D = new At(Ne(w.reason), {
        place: {
          start: {
            line: _.startLine,
            column: _.startCol,
            offset: _.startOffset
          },
          end: {
            line: _.endLine,
            column: _.endCol,
            offset: _.endOffset
          }
        },
        ruleId: g,
        source: "hast-util-from-html"
      });
      o.path && (D.file = o.path, D.name = o.path + ":" + D.name), D.fatal = Es[Ie], D.note = Ne(w.description), D.url = w.url === !1 ? void 0 : is + g, s(D);
    }
    function Ne(w) {
      return w.replace(os, D).replace(ds, ft);
      function D(_s, mt, pe) {
        const bt = (pe ? Number.parseInt(pe, 10) : 0) * (mt === "-" ? -1 : 1), _t = h.charAt(_.startOffset + bt);
        return ms(_t);
      }
      function ft() {
        return bs(h.charCodeAt(_.startOffset));
      }
    }
  }
}
function hs(e) {
  return (
    /** @type {ErrorCode} */
    e.replace(cs, fs)
  );
}
function fs(e) {
  return e.charAt(1).toUpperCase();
}
function ms(e) {
  return e === "`" ? "` ` `" : e;
}
function bs(e) {
  return "0x" + e.toString(16).toUpperCase();
}
function Cs(e) {
  const t = this, { emitParseErrors: a, ...s } = { ...t.data("settings"), ...e };
  t.parser = o;
  function o(E, h) {
    return ls(E, {
      ...s,
      onerror: a ? function(f) {
        h.path && (f.name = h.path + ":" + f.name, f.file = h.path), h.messages.push(f);
      } : void 0
    });
  }
}
export {
  Cs as default
};
