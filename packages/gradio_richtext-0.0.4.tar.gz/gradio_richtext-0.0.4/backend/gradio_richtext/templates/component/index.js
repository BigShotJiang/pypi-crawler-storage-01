import { I as f } from "./Index-DJ01M7iV.js";
export {
  f as default
};
