# EXtra-redu

Tools for XFEL data quality estimation and data reduction
