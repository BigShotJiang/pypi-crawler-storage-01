# node_soso

XML enhancements to make a few things easier.

### SmartNode Class

Adds easy node value retrieval.

### dump() function

Allows for easy inspection of the structure of an XML file.
