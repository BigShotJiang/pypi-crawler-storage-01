## Design Docs

This folder contains various documents describing the design of the Python SDK
and its documentation.