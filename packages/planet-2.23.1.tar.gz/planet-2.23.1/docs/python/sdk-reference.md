---
title: Python SDK API Reference
---

## ::: planet.Auth
    rendering:
      show_root_full_path: false

## ::: planet.Session
    rendering:
      show_root_full_path: false

## ::: planet.OrdersClient
    rendering:
      show_root_full_path: false

## ::: planet.order_request
    rendering:
      show_root_full_path: false

## ::: planet.DataClient
    rendering:
      show_root_full_path: false

## ::: planet.data_filter
    rendering:
      show_root_full_path: false

## ::: planet.SubscriptionsClient
    rendering:
      show_root_full_path: false

## ::: planet.subscription_request
    rendering:
      show_root_full_path: false

## ::: planet.reporting
    rendering:
      show_root_full_path: false

## ::: planet.DestinationsClient
    rendering:
        show_root_full_path: false

## ::: planet.FeaturesClient
    rendering:
        show_root_full_path: false

## ::: planet.Planet
    rendering:
      show_root_full_path: false
