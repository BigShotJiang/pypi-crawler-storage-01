"""SDV-Installer main module."""

from sdv_installer import config, constants


__all__ = ('config', 'constants')
__version__ = '0.0.0.dev8'
