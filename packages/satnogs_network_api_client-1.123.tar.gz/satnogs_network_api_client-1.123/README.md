# SatNOGS Network API Client

SatNOGS Network is a web application, implementing a global scheduling and monitoring network for ground station operations.

This is the API client.

## License

[![license](https://img.shields.io/badge/license-AGPL%203.0-6672D8.svg)](LICENSE)
[![Libre Space Foundation](https://img.shields.io/badge/%C2%A9%202014--2020-Libre%20Space%20Foundation-6672D8.svg)](https://librespacefoundation.org/)
