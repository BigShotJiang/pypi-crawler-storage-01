# hatch javascript

Hatch plugin for JavaScript

[![Build Status](https://github.com/python-project-templates/hatch-javascript/actions/workflows/build.yaml/badge.svg?branch=main&event=push)](https://github.com/python-project-templates/hatch-javascript/actions/workflows/build.yaml)
[![codecov](https://codecov.io/gh/python-project-templates/hatch-javascript/branch/main/graph/badge.svg)](https://codecov.io/gh/python-project-templates/hatch-javascript)
[![License](https://img.shields.io/github/license/python-project-templates/hatch-javascript)](https://github.com/python-project-templates/hatch-javascript)
[![PyPI](https://img.shields.io/pypi/v/hatch-javascript.svg)](https://pypi.python.org/pypi/hatch-javascript)

## Overview

Wrapper for [hatch-js](https://github.com/python-project-templates/hatch-js)

> [!NOTE]
> This library was generated using [copier](https://copier.readthedocs.io/en/stable/) from the [Base Python Project Template repository](https://github.com/python-project-templates/base).
