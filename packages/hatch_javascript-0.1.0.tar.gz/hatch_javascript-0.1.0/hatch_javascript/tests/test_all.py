from hatch_javascript import *  # noqa


def test_all():
    assert True
