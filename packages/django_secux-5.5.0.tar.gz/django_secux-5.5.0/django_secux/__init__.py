default_app_config = 'django_secux.apps.DjangoSecuxConfig'
