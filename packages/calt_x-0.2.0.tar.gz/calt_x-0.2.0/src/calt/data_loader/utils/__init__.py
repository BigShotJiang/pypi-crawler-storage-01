from .comparison_vis import parse_poly, load_eval_results, display_with_diff
