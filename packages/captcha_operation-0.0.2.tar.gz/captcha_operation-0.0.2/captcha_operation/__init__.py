# -*- coding: utf-8 -*-
"""
 @Author: xiaoxuan6
 @Date: 2025/8/3 14:38
 @File: __init__.py
 @Description: 
"""

# 版本信息
__version__ = "0.0.2"
__author__ = "xiaoxuan6"
__url__ = "https://github.com/xiaoxuan6/captcha_operation"