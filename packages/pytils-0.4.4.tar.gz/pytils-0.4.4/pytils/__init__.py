"""
Simple processing for russian strings
"""

from pytils import dt, numeral, translit, typo, utils

VERSION = "0.4.0dev"
__all__ = ["dt", "numeral", "translit", "typo", "utils"]
