"""
Example of usage pytils with Django
"""
