"""Core models and utilities for LangGate."""
