"""Utility helpers for langgate packages."""
