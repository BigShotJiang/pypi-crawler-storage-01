#!/bin/bash

pipenv shell

