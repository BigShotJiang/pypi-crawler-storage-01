#!/bin/bash

python3 -m build

