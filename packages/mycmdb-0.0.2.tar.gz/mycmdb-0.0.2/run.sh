#!/bin/bash

python3 example.py

