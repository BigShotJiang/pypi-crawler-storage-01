"""Init for ReadSam."""
from __future__ import absolute_import

from .sequencing_core import process_sequencing
from .seq_utilities import read_methyldackel_bed
from .read_methyldackel import read_methyldackel