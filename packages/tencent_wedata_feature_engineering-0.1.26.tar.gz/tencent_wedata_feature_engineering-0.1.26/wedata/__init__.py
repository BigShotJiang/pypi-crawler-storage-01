"""
WeData Feature Engineering
A toolkit for automated feature engineering
"""

__version__ = "0.1.26"