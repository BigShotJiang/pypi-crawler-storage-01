from .main import parse, FastFeedParserDict

__version__ = "0.1.0"
__all__ = ['parse', 'FastFeedParserDict']
