=================
HelloWorld-Django
=================

This application provides a hello_world endpoint wherever it is mounted using
the Django framework.
