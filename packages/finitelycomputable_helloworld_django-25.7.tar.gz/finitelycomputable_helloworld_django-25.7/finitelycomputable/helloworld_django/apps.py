from django.apps import AppConfig


class HelloworldDjangoConfig(AppConfig):
    name = 'finitelycomputable.helloworld_django'
