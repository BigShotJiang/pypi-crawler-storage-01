
class InterfacePCBS:
    def __init__(self, native_obj) -> None:
        self.native_obj = native_obj

    #TODO: implement