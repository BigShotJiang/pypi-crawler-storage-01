# Welcome to py4cst!

This is a small python library that provides wrappers for CST Studio Suite python library as well as some useful high level tools to setup your projects and to read out the results.

**Be aware the library in it's current state is highly untested and will change a lot even in it's core. Any contributions are welcome!**

# Usage

Check out the *examples* directory in the GitHub repository: https://github.com/Arri0/py4cst/tree/main/examples.