## Example: {eval.example.user_text}
{description}
Tree Distance: {eval.tree_distance}

{diff_explanations}

Expected:

```json
{expected_json}
```

Actual:

```json
{actual_json}
```
