"""Contains code for evaluating natural language geocoding."""
