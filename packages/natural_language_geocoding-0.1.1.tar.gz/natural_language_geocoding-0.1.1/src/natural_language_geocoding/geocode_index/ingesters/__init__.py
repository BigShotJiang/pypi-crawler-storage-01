"""Contains ingesters which pull palce data from external sources and ingest into the index."""
