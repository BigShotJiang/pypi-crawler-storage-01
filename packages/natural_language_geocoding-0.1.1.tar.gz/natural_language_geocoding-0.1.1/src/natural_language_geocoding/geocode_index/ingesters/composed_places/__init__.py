"""Defines places for ingest that are composed of other known locations."""
