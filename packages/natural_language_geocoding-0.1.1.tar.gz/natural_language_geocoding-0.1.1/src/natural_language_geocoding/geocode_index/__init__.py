"""Provides code for working with an index of places in AWS OpenSearch."""
