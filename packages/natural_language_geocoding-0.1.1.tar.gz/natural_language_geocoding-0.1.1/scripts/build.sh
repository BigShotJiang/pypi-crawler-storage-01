#!/bin/bash

set -e -o pipefail

python -m build
