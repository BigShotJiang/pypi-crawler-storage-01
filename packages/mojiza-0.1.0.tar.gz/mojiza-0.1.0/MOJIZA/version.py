"""

MOJIZA V:0.0.1

"""


__VERSION__ = '0.0.1'