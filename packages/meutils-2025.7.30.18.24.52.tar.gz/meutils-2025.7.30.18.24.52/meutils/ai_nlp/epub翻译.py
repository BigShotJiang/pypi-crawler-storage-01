#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : epub翻译
# @Time         : 2023/10/26 09:47
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : https://github.com/zengzzzzz/translate-epub-book-by-openai

from meutils.pipe import *
