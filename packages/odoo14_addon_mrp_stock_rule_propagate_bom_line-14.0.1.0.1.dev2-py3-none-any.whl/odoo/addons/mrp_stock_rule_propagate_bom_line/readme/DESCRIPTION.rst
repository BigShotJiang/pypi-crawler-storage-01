This module adds a `Propagate BOM Line` checkbox on stock rule.

When this checkbox is marked and pull rules are applied for kit products,
it will avoid grouping the stock moves of the same product if these stock
moves are originating from different kits (ie different BOM lines).
