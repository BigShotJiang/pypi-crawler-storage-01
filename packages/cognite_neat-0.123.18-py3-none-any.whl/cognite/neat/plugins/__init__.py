from ._manager import get_plugin_manager

__all__ = ["get_plugin_manager"]
