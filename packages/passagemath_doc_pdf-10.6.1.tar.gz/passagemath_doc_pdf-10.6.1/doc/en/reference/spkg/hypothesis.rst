.. _spkg_hypothesis:

hypothesis: A library for property-based testing
==========================================================

Description
-----------

A library for property-based testing

License
-------

MPL-2.0

Upstream Contact
----------------

https://pypi.org/project/hypothesis/


Type
----

optional


Dependencies
------------

- $(PYTHON)
- $(PYTHON_TOOLCHAIN)
- :ref:`spkg_attrs`

Version Information
-------------------

requirements.txt::

    hypothesis


Equivalent System Packages
--------------------------

(none known)

