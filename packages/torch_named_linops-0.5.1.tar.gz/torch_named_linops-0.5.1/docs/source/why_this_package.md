# Why this package?

## The problem with linops


