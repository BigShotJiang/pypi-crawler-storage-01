# API Reference
abcde


```{eval-rst}
.. autoclass:: torchlinops.NamedLinop
   :members: __init__,
             fn,
             adj_fn,
             normal_fn,
             split_forward,
             split_forward_fn,
             size,
             size_fn,
             dims,
             H,
             N,
```

