#!/usr/bin/env python3
"""
Allow zapgpt to be executable as a module with python -m zapgpt.
"""

from .main import main

if __name__ == "__main__":
    main()
