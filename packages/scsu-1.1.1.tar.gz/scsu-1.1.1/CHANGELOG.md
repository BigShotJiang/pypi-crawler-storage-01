# Changelog

## 1.0 - 2025.02.27
* First stable release.
* Better documentation.
* Small code optimizations.

## 0.3 - 2025.02.25
* Added embedded version information.
* Replaced 'single quotes' with "double quotes".
* Added a command-line interface.

## 0.2 - 2025.02.24
* More optimizations for dynamic window switching in Unicode mode.
* Avoided redefining the Latin-1 supplement window when possible.
* Fixed how encoding exceptions are raised.
* Fixed the incremental codec states.

## 0.1 - 2025.02.23
* Initial release.