## init
from llama_index.tools.azure_translate.base import (
    ENDPOINT_BASE_URL,
    AzureTranslateToolSpec,
)

__all__ = ["AzureTranslateToolSpec", "ENDPOINT_BASE_URL"]
