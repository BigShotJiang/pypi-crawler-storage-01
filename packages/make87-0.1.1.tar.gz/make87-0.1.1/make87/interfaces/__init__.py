from .base import InterfaceBase

__all__ = [
    "InterfaceBase",
]
