"""Version file."""

VERSION = (0, 0, 6)

__version__ = ".".join(map(str, VERSION))
