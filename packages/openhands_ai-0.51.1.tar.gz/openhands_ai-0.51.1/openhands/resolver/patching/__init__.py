# -*- coding: utf-8 -*-

from .apply import apply_diff
from .patch import parse_patch

__all__ = ['parse_patch', 'apply_diff']
