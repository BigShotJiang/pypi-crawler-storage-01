
from .DigitalHuman import  NewDigitalHumanOperation
from .DigitalHumanLoadWait import  DigitalHumanLoadWait

__all__ = ["NewDigitalHumanOperation", "DigitalHumanLoadWait"]












