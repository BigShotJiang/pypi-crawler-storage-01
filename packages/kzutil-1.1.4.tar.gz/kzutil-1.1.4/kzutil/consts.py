'''
Author: Kevin Zhu
The main constants for kzutil
'''

GREEN = '\x1B[1m\033[32m'
YELLOW = '\x1B[1m\033[33m'
WHITE = '\x1B[1m\033[37m'
GREY = '\x1B[1m\033[90m'
RESET = '\x1B[0m\033[0m'