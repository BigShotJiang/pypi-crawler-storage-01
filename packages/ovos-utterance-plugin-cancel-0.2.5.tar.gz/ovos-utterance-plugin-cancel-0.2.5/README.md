# Nevermind

plugin to look at the tail end of the transcribed phrase, ignoring the utterance if it ends with "nevermind that" or "cancel it" or "ignore that". 

This is for use case like: `"Hey Mycroft, can you tell me the...ummm...oh, nevermind that"`


## Credits
- [@penrods](https://github.com/MycroftAI/mycroft-core/pull/1274) - original PR in mycroft-core
- [NeonGecko](https://github.com/NeonGeckoCom/neon-utterance-plugin-cancel) - original plugin
