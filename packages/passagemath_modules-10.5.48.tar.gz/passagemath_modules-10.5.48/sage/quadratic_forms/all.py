# sage_setup: distribution = sagemath-modules

from sage.quadratic_forms.all__sagemath_modules import *
from sage.quadratic_forms.all__sagemath_pari import *
