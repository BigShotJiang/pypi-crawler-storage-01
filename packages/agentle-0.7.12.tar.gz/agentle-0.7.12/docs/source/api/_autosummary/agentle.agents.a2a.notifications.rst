agentle.agents.a2a.notifications
================================

.. automodule:: agentle.agents.a2a.notifications

   
   .. rubric:: Classes

   .. autosummary::
   
      PushNotificationConfig
      TaskPushNotificationConfig
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   push_notification_config
   task_push_notification_config
