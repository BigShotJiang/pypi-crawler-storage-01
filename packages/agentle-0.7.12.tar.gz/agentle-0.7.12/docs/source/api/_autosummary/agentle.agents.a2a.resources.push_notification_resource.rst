agentle.agents.a2a.resources.push\_notification\_resource
=========================================================

.. automodule:: agentle.agents.a2a.resources.push_notification_resource

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      BaseModel
      ConfigDict
      PushNotificationConfig
      PushNotificationResource
      TaskGetResult
      TaskPushNotificationConfig
      TaskQueryParams
      TypeVar
   