agentle.agents.a2a.notifications.push\_notification\_config
===========================================================

.. automodule:: agentle.agents.a2a.notifications.push_notification_config

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      Authentication
      BaseModel
      PushNotificationConfig
   