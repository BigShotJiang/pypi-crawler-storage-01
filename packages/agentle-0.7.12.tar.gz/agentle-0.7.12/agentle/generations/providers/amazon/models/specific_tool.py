from typing import TypedDict


class SpecificTool(TypedDict):
    name: str
