"""Initialize the app"""

__version__ = "0.0.4"
__title__ = "MIL Industry"
