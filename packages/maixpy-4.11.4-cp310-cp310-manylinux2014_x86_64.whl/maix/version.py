
# Versions should comply with PEP440: https://peps.python.org/pep-0440/

version_major = 4
version_minor = 11
version_patch = 4

__version__ = "{}.{}.{}".format(version_major, version_minor, version_patch)
