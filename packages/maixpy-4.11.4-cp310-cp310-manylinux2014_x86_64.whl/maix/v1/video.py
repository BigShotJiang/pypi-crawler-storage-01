def open(path, record=False, interval=100000, quality=50, width=320, height=240, audio=False, sample_rate=44100, channels=1):
    pass

class avi:
    def play():
        pass

    def capture(img):
        pass

    def volume(volume):
        pass

    def record():
        pass

