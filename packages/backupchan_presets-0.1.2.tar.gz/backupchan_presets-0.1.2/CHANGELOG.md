# Backup-chan preset library changelog

See what's changed between versions!

## 0.1.2

* `Presets` length can now be queried using `len(presets)`.

## 0.1.1

* `Presets` is now iterable.

## 0.1.0

* The first stable version
