# max_min_by_sg

A hybrid C++ + Python package to find local maxima, minima, and saddle points of 2-variable polynomial functions.

## Installation

```bash
pip install git+https://github.com/ShaunakG18/max_min_by_sg.git
