# Welcome to MDTerp


[![image](https://img.shields.io/pypi/v/MDTerp.svg)](https://pypi.python.org/pypi/MDTerp)


**A python project for interpreting molecular dynamics trajectory metastable state classifications from machine-learning models**


-   Free software: MIT License
-   Documentation: <https://shams-mehdi.github.io/MDTerp>
    

## Features

-   TODO
