# Usage

To use MDTerp in a project:

```
import MDTerp
```
