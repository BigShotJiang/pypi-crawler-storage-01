# -*- coding: utf-8 -*-
"""
Version of getpycomic.
"""
VERSION = "0.1.2"
