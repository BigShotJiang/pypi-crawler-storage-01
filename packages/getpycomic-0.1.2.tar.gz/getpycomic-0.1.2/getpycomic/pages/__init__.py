# -*- coding: utf-8 -*-
"""
"""

from getpycomic.pages.tmomanga import TmoManga
from getpycomic.pages.zonatmo import ZonaTmo
from getpycomic.pages.novelcool import NovelCool
