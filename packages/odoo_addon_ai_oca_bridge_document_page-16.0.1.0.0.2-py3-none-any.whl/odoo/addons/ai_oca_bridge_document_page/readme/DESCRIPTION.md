This module is intended for allowing users to use OCA's Knowledge app for as
a source of knowledge for AI Agents, although this is not the only usage this module
could have