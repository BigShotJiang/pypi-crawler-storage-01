#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Daniel Baier, Jan-Niclas Hilgert, Joel Eneas Espinoza Bachmann, Jannis Finn Borg-Olivier"
__version__ = "0.0.9.0"