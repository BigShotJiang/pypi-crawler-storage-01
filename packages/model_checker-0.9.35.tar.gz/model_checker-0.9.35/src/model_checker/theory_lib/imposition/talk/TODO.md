# TODO

- [x] Print Imposition Relation
- [x] Change '\\imposition' to '\\boxright'
- [x] Change '\\could' to '\\diamondright'
- [x] In the exclusion/ theory, change '\\unineg' to '\\neg', and change '\\uniwedge' to '\\wedge', etc., obviating the need for a translation dictionary (you can leave it empty)
- [ ] remove `extended_verify` and `extended_falsify` from `imposition/semantic.py`
