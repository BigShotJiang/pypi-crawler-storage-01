## Load season details

 > Peaky Blinders

url : https://moviebox.ng/wefeed-h5-bff/web/subject/play?subjectId=4006958073083480920&se=1&ep=1

HEADERS:

```
Accept	application/json
Accept-Encoding	gzip, deflate, br, zstd
Accept-Language	en-US,en;q=0.5
Alt-Used	moviebox.ng
Connection	keep-alive
Host	moviebox.ng
Referer	https://moviebox.ng/movies/peaky-blinders-Ii0kbUrUZL4?id=4006958073083480920&type=%2Fmovie%2Fdetail&detailSe=1&detailEp=1
Sec-Fetch-Dest	empty
Sec-Fetch-Mode	cors
Sec-Fetch-Site	same-origin
User-Agent	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0
X-Client-Info	{"timezone":"Africa/Nairobi"}
X-Source
```

COOKIES :

```
account	8770072105116414416|0|H5|1752734834|
i18n_lang	en
uuid	7e5f59f8-029a-4a44-8506-c0c5a7257062
```


## Caption*

url :     https://moviebox.ng/wefeed-h5-bff/web/subject/caption?format=MP4&id=8012946208333464168&subjectId=4006958073083480920


## Download button

url : https://moviebox.ng/wefeed-h5-bff/web/subject/download?subjectId=4006958073083480920&se=1&ep=1

HEADERS :

```
Accept	application/json
Accept-Encoding	gzip, deflate, br, zstd
Accept-Language	en-US,en;q=0.5
Alt-Used	moviebox.ng
Connection	keep-alive
Host	moviebox.ng
Referer	https://moviebox.ng/movies/peaky-blinders-Ii0kbUrUZL4?id=4006958073083480920&type=%2Fmovie%2Fdetail&detailSe=1&detailEp=1
Sec-Fetch-Dest	empty
Sec-Fetch-Mode	cors
Sec-Fetch-Site	same-origin
User-Agent	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0
X-Client-Info	{"timezone":"Africa/Nairobi"}
X-Source	
```

COOKIES:

```
account	8770072105116414416|0|H5|1752734834|
i18n_lang	en
uuid	7e5f59f8-029a-4a44-8506-c0c5a7257062
```

