# Semantext
OSS Semantic Layer built for easy llm integration
