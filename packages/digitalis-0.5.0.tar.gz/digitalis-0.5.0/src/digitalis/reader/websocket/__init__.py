"""WebSocket source implementation."""
