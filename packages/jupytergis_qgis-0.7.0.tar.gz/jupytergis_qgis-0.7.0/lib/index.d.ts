declare const _default: import("@jupyterlab/application").JupyterFrontEndPlugin<void>[];
export default _default;
