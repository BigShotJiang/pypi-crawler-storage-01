# LlamaIndex Embeddings Integration: MixedbreadAI
