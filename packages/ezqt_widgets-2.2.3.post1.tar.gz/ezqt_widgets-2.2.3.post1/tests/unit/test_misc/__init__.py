# -*- coding: utf-8 -*-
# ///////////////////////////////////////////////////////////////
"""
Tests unitaires pour les widgets Misc d'EzQt_Widgets.
"""

__version__ = "1.0.0" 