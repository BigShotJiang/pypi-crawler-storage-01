Linkapy
-------

.. image:: imgs/linkapy.png
  :width: 400
  :alt: Image generated with Microsoft copilot

Linkapy - a general framework to work with tri-modal sequencing data.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   content/installation
   content/usage
