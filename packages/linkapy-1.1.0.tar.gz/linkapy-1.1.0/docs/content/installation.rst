installation
------------

As for now, this package can be installed by cloning the github repository, and installing using pip:

.. code-block:: bash

    pip install path/to/repo

The package is also available on testpypi:

.. code-block:: bash

    pip install --index-url https://test.pypi.org/simple/ linkapy