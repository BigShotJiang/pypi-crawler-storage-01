# Changelog

## [1.1.0](https://github.com/WardDeb/linkapy/compare/v1.0.0...v1.1.0) (2025-07-29)


### Features

* automated pypi upload on release ([#10](https://github.com/WardDeb/linkapy/issues/10)) ([d190211](https://github.com/WardDeb/linkapy/commit/d190211286d8d5fb0a1c10f86f16b62fee6acda1))
* versioning, libname, templates ([#7](https://github.com/WardDeb/linkapy/issues/7)) ([da6bc41](https://github.com/WardDeb/linkapy/commit/da6bc41b0845a0ab1116cb52dfa4db701d129a96))

## 1.0.0 (2025-07-26)


### Features

* release please ([da22150](https://github.com/WardDeb/linkapy/commit/da221505a6e27dcd75102640e8a4b201d9e1e862))
