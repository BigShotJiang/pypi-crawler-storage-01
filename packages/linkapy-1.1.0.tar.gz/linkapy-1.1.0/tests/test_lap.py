from linkapy.parsing import Parse_scNMT

def test_Parse():
    _a = Parse_scNMT("./", "./", chromsizes="None")
