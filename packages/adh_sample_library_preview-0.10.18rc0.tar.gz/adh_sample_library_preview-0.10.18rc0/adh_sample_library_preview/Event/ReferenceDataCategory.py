﻿from enum import Enum


class ReferenceDataCategory(Enum):

    ReferenceData = 'ReferenceData'
    ExternalReference = 'ExternalReference'
