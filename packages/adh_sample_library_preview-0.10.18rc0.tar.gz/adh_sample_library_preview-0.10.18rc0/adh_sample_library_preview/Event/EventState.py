from enum import Enum


class EventState(Enum):
    Active = 'ACTIVE'
    Closed = 'CLOSED'
