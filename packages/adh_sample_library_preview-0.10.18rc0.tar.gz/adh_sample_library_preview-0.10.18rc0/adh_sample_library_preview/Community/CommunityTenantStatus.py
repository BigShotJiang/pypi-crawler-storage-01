from enum import Enum


class CommunityTenantStatus(Enum):
    none = 'None'
    Paused = 'Paused'
    Active = 'Active'
