# Empty file to integrate matplotlib styles load facility
