from phis_logging.logging_config import 配置日志

setup_logging = 配置日志

__all__ = ['setup_logging', '配置日志']
