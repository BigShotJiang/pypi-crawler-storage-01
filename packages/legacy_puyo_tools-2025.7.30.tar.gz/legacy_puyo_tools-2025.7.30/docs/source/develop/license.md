# License

`legacy-puyo-tools` is under the MIT License. Based on
[Puyo Text Editor](https://github.com/nickworonekin/puyo-text-editor) which is
also under the MIT License.

```{literalinclude} ../../../LICENSE
    :language: text
```
