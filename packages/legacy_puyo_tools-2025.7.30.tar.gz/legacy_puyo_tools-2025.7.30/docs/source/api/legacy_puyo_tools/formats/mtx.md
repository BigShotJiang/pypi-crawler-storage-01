# {mod}`legacy_puyo_tools.formats.mtx`

````{module} legacy_puyo_tools.formats.mtx

```{autodoc2-docstring} legacy_puyo_tools.formats.mtx
    :allowtitles:
```
````

## Module Contents

### Classes

```{autodoc2-summary}
~legacy_puyo_tools.formats.mtx.Mtx
```

### Data

### API

```{autodoc2-object} legacy_puyo_tools.formats.mtx.Mtx
```
