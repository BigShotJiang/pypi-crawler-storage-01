"""Test creating mtx formats.

SPDX-FileCopyrightText: 2025 Samuel Wu
SPDX-License-Identifier: MIT
"""

# TODO: Implement the test for creating an MTX file once it has been implemented
