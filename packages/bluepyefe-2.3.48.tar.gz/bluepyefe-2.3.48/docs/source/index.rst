
.. include:: ../../README.rst
   :end-before: .. substitutions

.. toctree::
   :hidden:
   :maxdepth: 3

   Home <self>
   api.rst

.. |banner| image:: /logo/BluePyEfeBanner.jpg
