===========
Django-Apps
===========

This application provides a /wsgi_info/ endpoint and uses INSTALLED_APPS to
combine all of the Django modules that it finds in the virtual environment.
