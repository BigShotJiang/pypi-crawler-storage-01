Presentation notes:

Demo 1 - init https://youtu.be/0Bml9c5lUBk
