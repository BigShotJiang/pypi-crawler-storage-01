from .__main__ import main  # noqa: D104, F401
