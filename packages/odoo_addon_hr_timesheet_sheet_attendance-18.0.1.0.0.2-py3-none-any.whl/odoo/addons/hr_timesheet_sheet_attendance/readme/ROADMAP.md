By having Check-in/out button in the timesheet, there could perhaps be a
case where the user does two clicks in a fast way, then the check-in and
check-out times are the same and the attendance gets blocked as there is
an Odoo standard check which verifies that the attendance check-in time
is strictly minor than the check-out time
