- Goto Timesheets \> My Timesheet Sheets and create a timesheet

- Goto tab Attendances on timesheet form  
  - You can see there your current status checkin/checkout
  - You also can create attendance by clicking on button Check In/Check
    Out on right side
  - You can see your attendance that belongs to current timesheet on
    left side in same tab

- 'Total Attendance' is total working time based on your attendance

- 'Difference' is the difference betwwen total attandance time and
  working time (sum(attendace-time) - sum(unit amount in timessheet
  lines))

- Two smart buttons are present on top-right corner of timesheet form  
  - First one(with time icon) will take you list of your timesheets (by
    default filter timesheets related to current timesheet-sheet)
  - Second one(labeled as Attendances) will take you to list of your
    attendances (by default filter ateendances related to current
    timesheet-sheet)

- It prevents to change in any attendance related to timesheet-sheet
  that already has submitted

- It also prevents to submit such a timesheet-sheet not having equal
  number of checkin and checkout
