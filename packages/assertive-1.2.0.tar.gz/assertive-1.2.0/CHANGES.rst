0.0.1
-----
    added assert_that helper
    added first criterias



1.0.0
-----
    Remove assert_that helper and concepts of Assertion from the library, criteria provided all of the value