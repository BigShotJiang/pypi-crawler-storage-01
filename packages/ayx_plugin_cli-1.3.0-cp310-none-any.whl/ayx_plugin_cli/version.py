"""FILE GENERATED FROM SETUP.PY."""
short_version = "1.3.0"
version = "1.3.0"
full_version = "1.3.0"
git_revision = "4d57ccfcc7e8b83741c698b548753f24b5b99f91"
release = True

if not release:
    version = full_version
