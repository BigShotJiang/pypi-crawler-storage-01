# Resources package for GraphShift Discovery
# Contains JAR analyzer and assets