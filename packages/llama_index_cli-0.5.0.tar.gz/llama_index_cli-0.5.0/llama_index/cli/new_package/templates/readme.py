readme_str = """# LlamaIndex {TYPE} Integration: {NAME}
"""
