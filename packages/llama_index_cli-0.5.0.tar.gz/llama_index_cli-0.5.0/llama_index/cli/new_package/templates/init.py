init_str = """from llama_index.{TYPE}.{NAME}.base import <FILL>


__all__ = ["<FILL>"]
"""

init_with_prefix_str = """from llama_index.{PREFIX}.{TYPE}.{NAME}.base import <FILL>


__all__ = ["<FILL>"]
"""
