// Docker build injects the version of swift-json-schema into this file based on the version in Package.resolved
let swiftVersion: String? = nil
let jsonSchemaVersion: String? = nil
