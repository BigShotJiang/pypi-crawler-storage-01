fun main() {
    Runner(stdin(), stdout(), stderr()).run()
}
