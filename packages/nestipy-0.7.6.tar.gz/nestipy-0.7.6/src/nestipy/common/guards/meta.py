class GuardKey:
    Meta: str = "__guards__"
