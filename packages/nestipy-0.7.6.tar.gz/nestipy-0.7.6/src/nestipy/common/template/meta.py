class TemplateKey:
    MetaRender: str = "__template__render__"
    MetaBaseView: str = "__template__base__view__"
    MetaEngine: str = "__template__engine__"
