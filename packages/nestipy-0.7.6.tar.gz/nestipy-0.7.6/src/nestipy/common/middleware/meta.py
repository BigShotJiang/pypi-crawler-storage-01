class MiddlewareKey:
    MetaRoute = "middleware__route__"
    MetaExclude = "middleware_excludes"
