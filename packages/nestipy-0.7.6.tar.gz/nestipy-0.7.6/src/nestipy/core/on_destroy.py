class OnDestroy:
    async def on_shutdown(self):
        pass
