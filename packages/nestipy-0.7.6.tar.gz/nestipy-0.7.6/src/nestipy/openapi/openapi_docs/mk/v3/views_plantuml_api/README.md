# Views to generate PlantUML API schema

This folder contains views to generate a diagram of the API with request
/ response bodies for [PlantUML](https://plantuml.com).
