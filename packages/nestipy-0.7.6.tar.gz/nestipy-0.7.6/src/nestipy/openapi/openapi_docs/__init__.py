__version__ = "1.0.9"
VERSION = __version__
