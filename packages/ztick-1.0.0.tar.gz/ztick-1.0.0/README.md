# ztick

📌 High-precision smart timing library for Python with support down to yoctoseconds (symbolic).  
Built for systems requiring ultra-dense delay mechanisms with real nanosecond accuracy.

## Installation

```bash
pip install ztick
