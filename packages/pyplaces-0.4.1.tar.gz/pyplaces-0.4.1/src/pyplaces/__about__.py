# SPDX-FileCopyrightText: 2025-present Ted <tedbanken@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.4.1"
