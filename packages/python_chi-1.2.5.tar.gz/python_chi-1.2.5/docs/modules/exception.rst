.. exception-module:

=============
chi.exception
=============

The :mod:`chi.exception` module contains exception classes that may be raised by python-chi modules.

.. automodule:: chi.exception
   :members:
