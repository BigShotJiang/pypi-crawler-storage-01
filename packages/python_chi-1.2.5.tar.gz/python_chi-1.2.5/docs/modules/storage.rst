.. _storage-module:

=========
chi.storage
=========

The :mod:`chi.storage` module provides methods for using the shared
filesystem and object store on chameleon.

.. automodule:: chi.storage
   :members:
