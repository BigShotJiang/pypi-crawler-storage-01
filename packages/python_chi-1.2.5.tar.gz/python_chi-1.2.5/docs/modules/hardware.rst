.. _hardware-module:

============
chi.hardware
============

The :mod:`chi.hardware` provides a set of functions and classes for interacting the hardware discovery module of Chameleon.

.. automodule:: chi.hardware
   :members: