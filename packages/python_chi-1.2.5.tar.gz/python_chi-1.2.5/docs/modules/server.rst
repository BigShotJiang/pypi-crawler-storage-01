.. _server-module:

==========
chi.server
==========

The :mod:`chi.server` module is used for interacting with server instances.

.. automodule:: chi.server
   :members:
