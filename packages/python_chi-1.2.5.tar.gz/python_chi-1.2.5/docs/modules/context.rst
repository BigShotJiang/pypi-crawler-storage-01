.. _context-module:

===========
chi.context
===========

The :mod:`chi.context` module exposes a global context object and helpers for generating
clients for interfacing with the various Chameleon services.

.. automodule:: chi.context
   :members:
