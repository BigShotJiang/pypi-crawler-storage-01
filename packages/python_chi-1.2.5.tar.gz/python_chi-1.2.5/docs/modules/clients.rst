.. _clients-module:

=============
chi.clients
=============

The :mod:`chi.clients` module can be used to interface directly with the openstack SDK.
These clients are external libraries. For usage, see the respective documentation pages.

.. automodule:: chi.clients
   :members:
