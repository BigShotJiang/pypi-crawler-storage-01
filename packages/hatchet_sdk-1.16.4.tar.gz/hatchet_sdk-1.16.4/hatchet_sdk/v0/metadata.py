def get_metadata(token: str):
    return [("authorization", "bearer " + token)]
