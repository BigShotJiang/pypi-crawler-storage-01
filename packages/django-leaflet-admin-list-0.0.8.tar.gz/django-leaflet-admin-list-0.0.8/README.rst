Django Leaflet Admin List
=========================

The application introducing geo admin list based on leaflet

See details at the home page: https://github.com/nnseva/django-leaflet-admin-list
