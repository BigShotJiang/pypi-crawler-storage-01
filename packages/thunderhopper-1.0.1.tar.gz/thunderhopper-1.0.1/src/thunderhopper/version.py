__version__='1.0.1'
"""Current version of the thunderhopper package."""

__year__ = '2025'
"""Current year for copyright messages."""

__pdoc__ = {}
__pdoc__['__version__'] = True
__pdoc__['__year__'] = True
