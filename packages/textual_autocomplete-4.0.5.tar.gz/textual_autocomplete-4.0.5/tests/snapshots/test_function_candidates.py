# TODO - Passing a function as candidates should work

from __future__ import annotations
