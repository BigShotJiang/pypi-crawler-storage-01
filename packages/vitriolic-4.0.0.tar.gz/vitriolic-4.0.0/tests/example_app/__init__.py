INSTALL = (
    "TestContextProcessorsSite",
    "TestDateTimeFieldSite",
    "TestGenericViewsSite",
    "TestPaginationSite",
    "TestQueryStringSite",
)
