"""
Should specifically use:

  touchtechnology.common.backends.auth.UserSubclassBackend
  touchtechnology.common.backends.auth.EmailUserSubclassBackend
"""
