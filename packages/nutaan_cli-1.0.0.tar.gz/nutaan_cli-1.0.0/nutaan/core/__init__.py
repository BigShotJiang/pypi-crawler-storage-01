"""
Core package for Nutaan assistant
Made by Tecosys
"""
