
Advanced guide
==============
.. toctree::
   :maxdepth: 2
   :caption: Contents:

   extending-muse
   further-extending-muse
