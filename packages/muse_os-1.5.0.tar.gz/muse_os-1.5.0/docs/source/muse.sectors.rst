muse.sectors package
====================

Submodules
----------

muse.sectors.abstract module
----------------------------

.. automodule:: muse.sectors.abstract
   :members:
   :undoc-members:
   :show-inheritance:

muse.sectors.preset\_sector module
----------------------------------

.. automodule:: muse.sectors.preset_sector
   :members:
   :undoc-members:
   :show-inheritance:

muse.sectors.register module
----------------------------

.. automodule:: muse.sectors.register
   :members:
   :undoc-members:
   :show-inheritance:

muse.sectors.sector module
--------------------------

.. automodule:: muse.sectors.sector
   :members:
   :undoc-members:
   :show-inheritance:

muse.sectors.subsector module
-----------------------------

.. automodule:: muse.sectors.subsector
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: muse.sectors
   :members:
   :undoc-members:
   :show-inheritance:
