Release notes
=============

This is the list of changes to MUSE between each release.

To update to the latest version, run ``pip install --upgrade muse-os``

* :ref:`/release-notes/v1.5.0.md`
* :ref:`/release-notes/v1.4.3.md`
* :ref:`/release-notes/v1.4.2.md`
* :ref:`/release-notes/v1.4.1.md`
* :ref:`/release-notes/v1.4.0.md`
* :ref:`/release-notes/v1.3.3.md`
* :ref:`/release-notes/v1.3.2.md`
* :ref:`/release-notes/v1.3.1.md`
* :ref:`/release-notes/v1.3.0.md`
* :ref:`/release-notes/v1.2.3.md`
* :ref:`/release-notes/v1.2.2.md`
* :ref:`/release-notes/v1.2.1.md`
* :ref:`/release-notes/v1.2.0.md`
