
.. _input-files:

Input Files
===========

In this section we detail each of the files required to run MUSE. We include information based on how these files should be used, as well as the data that populates them.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   toml_primer
   toml
   inputs_csv


Indices and tables
------------------


- :ref:`genindex`
- :ref:`modindex`
- :ref:`search`
