=====================
Simulation Data Files
=====================

This section details the CSV files that are used to populate the simulation data.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   commodities
   projections
   technodata
   technodata_timeslices
   commodities_io
   existing_capacity
   agents
   correlation_files
