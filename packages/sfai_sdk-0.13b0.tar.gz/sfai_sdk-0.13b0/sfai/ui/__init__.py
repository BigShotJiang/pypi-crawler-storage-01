"""UI package for rich formatted displays."""
