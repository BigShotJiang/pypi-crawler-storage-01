from enum import Enum


class CustomAssetType(Enum):
    custom_fides_css = "custom-fides.css"
