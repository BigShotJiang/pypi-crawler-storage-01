"""another upstream merge

Revision ID: 6f98e1bd7e4f
Revises: 6bd93cb0603d, 794e5f5b76ae
Create Date: 2022-09-22 20:46:34.831732

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "6f98e1bd7e4f"
down_revision = ("6bd93cb0603d", "794e5f5b76ae")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
