::: tshu.CommandError
