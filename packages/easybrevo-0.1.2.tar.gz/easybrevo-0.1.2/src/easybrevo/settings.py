BREVO_API_BASE_URL = 'https://api.brevo.com/v3/'
BREVO_SENDER_EMAIL = 'sender@example.com'
BREVO_SENDER_NAME = 'Example Sender'
