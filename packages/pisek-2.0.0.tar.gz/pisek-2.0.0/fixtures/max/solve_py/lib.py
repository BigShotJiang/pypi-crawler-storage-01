def read_ints() -> list[int]:
    return list(map(int, input().split()))
