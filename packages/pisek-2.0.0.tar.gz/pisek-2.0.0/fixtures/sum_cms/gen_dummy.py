#!/usr/bin/env python3
# Do nothing. The tests should fail if nothing is generated.
