__version__ = "2.0.0"


def print_version():
    print(f"Pisek {__version__}")
    return 0
