"""Constraint Exceptions."""


class ConstraintNotMetError(Exception):
    """Error to raise when a constraint is not met."""
