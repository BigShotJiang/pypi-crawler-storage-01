"""Metrics to evaluate the quality of Synthetic Tabular Data.

This subpackage exists only to enable importing sdmetrics as part of sdv.
"""

from sdmetrics.single_table import *  # noqa
