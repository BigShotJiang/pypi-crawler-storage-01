"""Module to compare real and synthetic data."""
