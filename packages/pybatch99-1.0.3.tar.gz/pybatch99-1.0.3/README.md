thanks for using!


# batch syntax in python
idk how i made this
it was funny ngl

# bye