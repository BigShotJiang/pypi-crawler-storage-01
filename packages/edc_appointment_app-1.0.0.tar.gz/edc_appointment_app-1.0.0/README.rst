|pypi| |downloads| |clinicedc|

edc-appointment-app
===================

Test appointment app for clinicedc/edc projects

.. code-block:: bash

    pip install edc-appointment-app

Adverse Event App used for tests in clinicedc/edc projects

.. |pypi| image:: https://img.shields.io/pypi/v/edc-appointment-app.svg
    :target: https://pypi.python.org/pypi/edc-appointment-app

.. |downloads| image:: https://pepy.tech/badge/edc-appointment-app
   :target: https://pepy.tech/project/edc-appointment-app

.. |clinicedc| image:: https://img.shields.io/badge/framework-Clinic_EDC-green
   :alt:Made with clinicedc
   :target: https://github.com/clinicedc
