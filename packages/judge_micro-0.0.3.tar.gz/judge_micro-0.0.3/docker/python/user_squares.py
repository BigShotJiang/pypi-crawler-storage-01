def solve(x: int) -> tuple:
    """
    Square function.
    Calculate x squared.
    """
    result = x * x
    return (result, 0)
