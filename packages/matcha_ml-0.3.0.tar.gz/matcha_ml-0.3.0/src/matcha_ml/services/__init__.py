"""init for the services package."""
from .azure_service import AzureClient

__all__ = ["AzureClient"]
