"""General constants file."""
import os

LOCK_FILE_NAME = "matcha.lock"
MATCHA_STATE_PATH = os.path.join(".matcha", "infrastructure", "matcha.state")
