"""Storage sub-module."""
from .azure_storage import AzureStorage

__all__ = ["AzureStorage"]
