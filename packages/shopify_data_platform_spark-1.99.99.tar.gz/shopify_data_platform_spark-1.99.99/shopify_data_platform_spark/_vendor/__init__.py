# SPDX-License-Identifier: MIT
# Vendored libraries for internal use
