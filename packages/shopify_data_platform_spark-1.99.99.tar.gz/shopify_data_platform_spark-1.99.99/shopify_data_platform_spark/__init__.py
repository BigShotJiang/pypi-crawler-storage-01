"""shopify-data-platform-spark: python utils for spark"""

__version__ = "1.99.99"
