"""
scripts package: contains command-line utilities for gitscaffold.
"""
# package marker