import os
os.environ['NO_ALBUMENTATIONS_UPDATE'] = '1'