from my_simple_pkg import greet
def test_greet():
    assert greet("World") == "Hello, World!"

