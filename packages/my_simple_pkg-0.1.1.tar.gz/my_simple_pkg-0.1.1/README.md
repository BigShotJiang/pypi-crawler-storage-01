# my_simple_pkg
A simple example package to demonstrate Poetry packaging.
