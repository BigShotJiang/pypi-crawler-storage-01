from orbis.report.document.docx import DocxReportGenerator

__all__ = ["DocxReportGenerator"]
