This folder defines a Dockerfile (to run `gbp` on a Mac).
