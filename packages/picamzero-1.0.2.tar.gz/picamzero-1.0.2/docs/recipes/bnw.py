from picamzero import Camera

cam = Camera()
cam.greyscale = True
cam.take_photo("bnw.jpg")
