__version__ = "1.2.1"
__author__ = "Love dazzell"

default_app_config = 'django_dbsync.apps.DjangoDbSyncConfig'