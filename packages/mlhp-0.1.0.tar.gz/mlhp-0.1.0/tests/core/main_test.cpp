// This file is part of the mlhp project. License: See LICENSE

#define CATCH_CONFIG_MAIN
#include "external/catch2/catch.hpp"
