from .infinitywatch import Infinitywatch

__all__ = ["Infinitywatch"]
