
def toUpperFirst(s):
    return s[0].upper() + s[1:]