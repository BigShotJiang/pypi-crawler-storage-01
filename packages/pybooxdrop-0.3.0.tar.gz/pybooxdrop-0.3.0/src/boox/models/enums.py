from enum import StrEnum


class BooxUrl(StrEnum):
    EUR = "https://eur.boox.com"
    PUSH = "https://push.boox.com"
