import helper
from perftests import testmemio  # testbasic,; testbubblesort,

# helper.CompressPayload(True)
helper.test_runall("perf")
