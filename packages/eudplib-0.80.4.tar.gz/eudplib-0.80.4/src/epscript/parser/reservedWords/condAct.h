//
// Created by 박현우 on 2016. 11. 28..
//

#ifndef EPSCRIPT_CONDACT_H
#define EPSCRIPT_CONDACT_H

#include <string>

bool isConditionName(const std::string &name);
bool isActionName(const std::string &name);
bool isActionAllpName(const std::string &name);

#endif // EPSCRIPT_CONDACT_H
