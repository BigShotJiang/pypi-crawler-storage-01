//
// Created by phu54321 on 2016-12-01.
//

#ifndef EPSCRIPT_CONSTPARSER_H
#define EPSCRIPT_CONSTPARSER_H

#include <string>
int parseConstantName(const std::string &name);
void initConstmap();

#endif //EPSCRIPT_CONSTPARSER_H
