## cdf 

### Added

- [alpha] In the `cdf dump data` methods, the user can now stop the
downloading of data.

## templates

No changes.