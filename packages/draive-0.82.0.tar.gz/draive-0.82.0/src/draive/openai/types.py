__all__ = ("OpenAIException",)


class OpenAIException(Exception):
    pass
