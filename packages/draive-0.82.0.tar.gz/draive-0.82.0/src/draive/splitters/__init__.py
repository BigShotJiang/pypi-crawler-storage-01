from draive.splitters.text import split_text

__all__ = ("split_text",)
