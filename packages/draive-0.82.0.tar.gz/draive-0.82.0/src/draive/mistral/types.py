__all__ = ("MistralException",)


class MistralException(Exception):
    pass
