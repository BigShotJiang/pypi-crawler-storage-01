__all__ = ("OllamaException",)


class OllamaException(Exception):
    pass
