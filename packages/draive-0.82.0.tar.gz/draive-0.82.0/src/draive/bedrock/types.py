__all__ = ("BedrockException",)


class BedrockException(Exception):
    pass
