Report a bug
============

In the case you have issues, please report them to the project
bug tracker: https://github.com/svinota/pyroute2/issues

It is important to provide all the required information
with your report:

* Linux kernel version
* Python version
* Specific environment, if used -- gevent, eventlet etc.
