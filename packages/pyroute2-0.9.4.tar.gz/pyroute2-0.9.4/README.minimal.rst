pyroute2.minimal
================

PyRoute2 is a pure Python **netlink** library.

This module provides minimal subset of pyroute2 modules. Only netlink parser,
basic netns management and some netlink protocols implementations.

links
=====

* Home: <https://github.com/svinota/pyroute2/>
* PyPI: <https://pypi.org/project/pyroute2/>
* Usage: <https://github.com/svinota/pyroute2/discussions/796>
