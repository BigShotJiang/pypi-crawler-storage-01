"""Add 'cron_tz' property to node definition."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
