"""Add batch_size, batch_concurrency, and batch_interval to the CUSTOM model kind."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
