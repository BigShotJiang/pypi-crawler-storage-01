"""Fix support for trailing comments in SQL model definitions."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
