MODEL (
  name silver.c
);

SELECT DISTINCT col_a
FROM bronze.a
