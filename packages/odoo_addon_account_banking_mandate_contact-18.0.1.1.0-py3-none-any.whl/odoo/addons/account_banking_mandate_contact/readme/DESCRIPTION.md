This module allows to select a specific banking mandate (and thus, a
specific bank account) at contact level, so that when doing a debit
order, such mandate is used for the invoices issued to that contact.
