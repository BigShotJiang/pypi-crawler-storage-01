For selecting the mandate at contact level:

1.  Go to *Invoicing \> Customers \> Customers*.
2.  Open or create one contact that has a parent.
3.  On the *Sales & Purchase* page, fill *Contact Mandate*.
4.  That mandate will be populated in the debit order.

Then the normal flow will be:

1.  Go to Invoicing \> Customers \> Customer invoices.
2.  Create a new invoice for that contact.
3.  Post the invoice.
4.  Add it to a payment order, by any of the options that you can check
    on the *account_payment_order* module.
5.  The populated mandate will be the one on the contact.
