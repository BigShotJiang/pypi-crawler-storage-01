from opal_common.engine.parsing import get_rego_package
from opal_common.engine.paths import is_data_module, is_policy_module
