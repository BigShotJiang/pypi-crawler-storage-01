# LlamaIndex Embeddings Integration: Adapter
