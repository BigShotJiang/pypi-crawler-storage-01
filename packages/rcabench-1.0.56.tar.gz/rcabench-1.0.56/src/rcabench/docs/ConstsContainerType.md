# ConstsContainerType


## Enum

* `ContainerTypeAlgorithm` (value: `'algorithm'`)

* `ContainerTypeBenchmark` (value: `'benchmark'`)

* `ContainerTypeNamespace` (value: `'namespace'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


