# OBS Switch Controller Integration
# Version 0.0.3

__version__ = '0.0.3'