from .example.urls import urlpatterns

url = urlpatterns  # deprecated. Use path("cap/examples/", include("django_cap.example.urls")),
