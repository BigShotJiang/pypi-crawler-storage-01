# Django template tags for CAP widget
