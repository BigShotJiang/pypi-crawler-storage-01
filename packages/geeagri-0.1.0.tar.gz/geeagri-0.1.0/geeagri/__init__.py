"""Top-level package for geeagri."""

__author__ = """Krishnagopal Halder"""
__email__ = "geonextgis@gmail.com"
__version__ = "0.1.0"

from . import extract
from . import preprocessing
