# Copyright 2024 John Sirois.
# Licensed under the Apache License, Version 2.0 (see LICENSE).

import sys

from dev_cmd.run import main

if __name__ == "__main__":
    sys.exit(main())
