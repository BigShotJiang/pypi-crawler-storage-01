from dragonfly_uwg.cli import uwg

if __name__ == '__main__':
    uwg()
