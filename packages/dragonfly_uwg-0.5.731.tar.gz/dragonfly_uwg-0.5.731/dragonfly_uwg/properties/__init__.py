"""dragonfly-uwg properties."""
