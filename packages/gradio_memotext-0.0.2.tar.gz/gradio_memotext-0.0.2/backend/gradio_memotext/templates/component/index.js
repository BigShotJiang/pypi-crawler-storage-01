import { I as f } from "./Index-kNrOHsC0.js";
export {
  f as default
};
