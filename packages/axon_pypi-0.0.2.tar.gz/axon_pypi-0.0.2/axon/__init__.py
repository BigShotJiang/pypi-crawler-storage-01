from ._core import array, int8, int16, int32, int64, long, float32, float64, double, uint8, uint16, uint32, uint64, boolean
from ._utils import randn, randint, uniform, linspace, fill, zeros, zeros_like, ones, ones_like, arange
from . import linalg

__version__ = '0.0.2'
__author__ = 'Shivendra S'