def get_a_rpc_pb2():
    import passkit_io.single_use_coupons.a_rpc_pb2
    return passkit_io.single_use_coupons.a_rpc_pb2


def get_a_rpc_pb2_grpc():
    import passkit_io.single_use_coupons.a_rpc_pb2_grpc
    return passkit_io.single_use_coupons.a_rpc_pb2_grpc


def get_campaign_pb2():
    import passkit_io.single_use_coupons.campaign_pb2
    return passkit_io.single_use_coupons.campaign_pb2


def get_campaign_pb2_grpc():
    import passkit_io.single_use_coupons.campaign_pb2_grpc
    return passkit_io.single_use_coupons.campaign_pb2_grpc


def get_coupon_pb2():
    import passkit_io.single_use_coupons.coupon_pb2
    return passkit_io.single_use_coupons.coupon_pb2


def get_coupon_pb2_grpc():
    import passkit_io.single_use_coupons.coupon_pb2_grpc
    return passkit_io.single_use_coupons.coupon_pb2_grpc


def get_offer_pb2():
    import passkit_io.single_use_coupons.offer_pb2
    return passkit_io.single_use_coupons.offer_pb2


def get_offer_pb2_grpc():
    import passkit_io.single_use_coupons.offer_pb2_grpc
    return passkit_io.single_use_coupons.offer_pb2_grpc
