def get_image_pb2():
    import passkit_io.image.image_pb2
    return passkit_io.image.image_pb2


def get_image_pb2_grpc():
    import passkit_io.image.image_pb2_grpc
    return passkit_io.image.image_pb2_grpc
