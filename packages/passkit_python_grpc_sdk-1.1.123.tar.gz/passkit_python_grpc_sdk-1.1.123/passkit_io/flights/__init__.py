def get_a_rpc_pb2():
    import passkit_io.flights.a_rpc_pb2
    return passkit_io.flights.a_rpc_pb2


def get_a_rpc_pb2_grpc():
    import passkit_io.flights.a_rpc_pb2_grpc
    return passkit_io.flights.a_rpc_pb2_grpc


def get_airport_pb2():
    import passkit_io.flights.airport_pb2
    return passkit_io.flights.airport_pb2


def get_airport_pb2_grpc():
    import passkit_io.flights.airport_pb2_grpc
    return passkit_io.flights.airport_pb2_grpc


def get_barcode_pb2():
    import passkit_io.flights.barcode_pb2
    return passkit_io.flights.barcode_pb2


def get_barcode_pb2_grpc():
    import passkit_io.flights.barcode_pb2_grpc
    return passkit_io.flights.barcode_pb2_grpc


def get_boarding_pass_pb2():
    import passkit_io.flights.boarding_pass_pb2
    return passkit_io.flights.boarding_pass_pb2


def get_boarding_pass_pb2_grpc():
    import passkit_io.flights.boarding_pass_pb2_grpc
    return passkit_io.flights.boarding_pass_pb2_grpc


def get_cabin_codes():
    import passkit_io.flights.cabin_codes
    return passkit_io.flights.cabin_codes


def get_carrier_pb2():
    import passkit_io.flights.carrier_pb2
    return passkit_io.flights.carrier_pb2


def get_carrier_pb2_grpc():
    import passkit_io.flights.carrier_pb2_grpc
    return passkit_io.flights.carrier_pb2_grpc


def get_flight_designator_pb2():
    import passkit_io.flights.flight_designator_pb2
    return passkit_io.flights.flight_designator_pb2


def get_flight_designator_pb2_grpc():
    import passkit_io.flights.flight_designator_pb2_grpc
    return passkit_io.flights.flight_designator_pb2_grpc


def get_flight_pb2():
    import passkit_io.flights.flight_pb2
    return passkit_io.flights.flight_pb2


def get_flight_pb2_grpc():
    import passkit_io.flights.flight_pb2_grpc
    return passkit_io.flights.flight_pb2_grpc


def get_passenger_pb2():
    import passkit_io.flights.passenger_pb2
    return passkit_io.flights.passenger_pb2


def get_passenger_pb2_grpc():
    import passkit_io.flights.passenger_pb2_grpc
    return passkit_io.flights.passenger_pb2_grpc
