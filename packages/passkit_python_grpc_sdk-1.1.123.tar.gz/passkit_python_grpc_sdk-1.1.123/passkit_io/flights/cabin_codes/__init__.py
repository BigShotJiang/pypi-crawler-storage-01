def get_cabin_codes_pb2():
    import passkit_io.flights.cabin_codes.cabin_codes_pb2
    return passkit_io.flights.cabin_codes.cabin_codes_pb2


def get_cabin_codes_pb2_grpc():
    import passkit_io.flights.cabin_codes.cabin_codes_pb2_grpc
    return passkit_io.flights.cabin_codes.cabin_codes_pb2_grpc
