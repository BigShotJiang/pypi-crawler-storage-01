def get_operation_pb2():
    import passkit_io.common.operation_pb2
    return passkit_io.common.operation_pb2


def get_operation_pb2_grpc():
    import passkit_io.common.operation_pb2_grpc
    return passkit_io.common.operation_pb2_grpc


def get_attributes_pb2():
    import passkit_io.common.attributes_pb2
    return passkit_io.common.attributes_pb2


def get_attributes_pb2_grpc():
    import passkit_io.common.attributes_pb2_grpc
    return passkit_io.common.attributes_pb2_grpc


def get_billing_pb2():
    import passkit_io.common.billing_pb2
    return passkit_io.common.billing_pb2


def get_billing_pb2_grpc():
    import passkit_io.common.billing_pb2_grpc
    return passkit_io.common.billing_pb2_grpc


def get_pagination_pb2():
    import passkit_io.common.pagination_pb2
    return passkit_io.common.pagination_pb2


def get_pagination_pb2_grpc():
    import passkit_io.common.pagination_pb2_grpc
    return passkit_io.common.pagination_pb2_grpc


def get_pass_pb2():
    import passkit_io.common.pass_pb2
    return passkit_io.common.pass_pb2


def get_pass_pb2_grpc():
    import passkit_io.common.pass_pb2_grpc
    return passkit_io.common.pass_pb2_grpc


def get_common_objects_pb2():
    import passkit_io.common.common_objects_pb2
    return passkit_io.common.common_objects_pb2


def get_common_objects_pb2_grpc():
    import passkit_io.common.common_objects_pb2_grpc
    return passkit_io.common.common_objects_pb2_grpc


def get_distribution_pb2():
    import passkit_io.common.distribution_pb2
    return passkit_io.common.distribution_pb2


def get_distribution_pb2_grpc():
    import passkit_io.common.distribution_pb2_grpc
    return passkit_io.common.distribution_pb2_grpc


def get_personal_pb2():
    import passkit_io.common.personal_pb2
    return passkit_io.common.personal_pb2


def get_personal_pb2_grpc():
    import passkit_io.common.personal_pb2_grpc
    return passkit_io.common.personal_pb2_grpc


def get_project_pb2():
    import passkit_io.common.project_pb2
    return passkit_io.common.project_pb2


def get_project_pb2_grpc():
    import passkit_io.common.project_pb2_grpc
    return passkit_io.common.project_pb2_grpc


def get_protocols_pb2():
    import passkit_io.common.protocols_pb2
    return passkit_io.common.protocols_pb2


def get_protocols_pb2_grpc():
    import passkit_io.common.protocols_pb2_grpc
    return passkit_io.common.protocols_pb2_grpc


def get_proximity_pb2():
    import passkit_io.common.proximity_pb2
    return passkit_io.common.proximity_pb2


def get_proximity_pb2_grpc():
    import passkit_io.common.proximity_pb2_grpc
    return passkit_io.common.proximity_pb2_grpc


def get_reporting_pb2():
    import passkit_io.common.reporting_pb2
    return passkit_io.common.reporting_pb2


def get_reporting_pb2_grpc():
    import passkit_io.common.reporting_pb2_grpc
    return passkit_io.common.reporting_pb2_grpc


def get_template_pb2():
    import passkit_io.common.template_pb2
    return passkit_io.common.template_pb2


def get_template_pb2_grpc():
    import passkit_io.common.template_pb2_grpc
    return passkit_io.common.template_pb2_grpc


def get_tracking_pb2():
    import passkit_io.common.tracking_pb2
    return passkit_io.common.tracking_pb2


def get_tracking_pb2_grpc():
    import passkit_io.common.tracking_pb2_grpc
    return passkit_io.common.tracking_pb2_grpc


def get_transaction_pb2():
    import passkit_io.common.transaction_pb2
    return passkit_io.common.transaction_pb2


def get_transaction_pb2_grpc():
    import passkit_io.common.transaction_pb2_grpc
    return passkit_io.common.transaction_pb2_grpc


def get_useragent_pb2():
    import passkit_io.common.useragent_pb2
    return passkit_io.common.useragent_pb2


def get_useragent_pb2_grpc():
    import passkit_io.common.useragent_pb2_grpc
    return passkit_io.common.useragent_pb2_grpc


def get_links_pb2():
    import passkit_io.common.links_pb2
    return passkit_io.common.links_pb2


def get_links_pb2_grpc():
    import passkit_io.common.links_pb2_grpc
    return passkit_io.common.links_pb2_grpc


def get_localization_pb2():
    import passkit_io.common.localization_pb2
    return passkit_io.common.localization_pb2


def get_localization_pb2_grpc():
    import passkit_io.common.localization_pb2_grpc
    return passkit_io.common.localization_pb2_grpc


def get_message_pb2():
    import passkit_io.common.message_pb2
    return passkit_io.common.message_pb2


def get_message_pb2_grpc():
    import passkit_io.common.message_pb2_grpc
    return passkit_io.common.message_pb2_grpc


def get_metrics_pb2():
    import passkit_io.common.metrics_pb2
    return passkit_io.common.metrics_pb2


def get_metrics_pb2_grpc():
    import passkit_io.common.metrics_pb2_grpc
    return passkit_io.common.metrics_pb2_grpc


def get_note_pb2():
    import passkit_io.common.note_pb2
    return passkit_io.common.note_pb2


def get_note_pb2_grpc():
    import passkit_io.common.note_pb2_grpc
    return passkit_io.common.note_pb2_grpc


def get_semantics_pb2():
    import passkit_io.common.semantics_pb2
    return passkit_io.common.semantics_pb2


def get_semantics_pb2_grpc():
    import passkit_io.common.semantics_pb2_grpc
    return passkit_io.common.semantics_pb2_grpc
