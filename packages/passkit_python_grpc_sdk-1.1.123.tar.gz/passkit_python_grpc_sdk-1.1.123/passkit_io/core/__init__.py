def get_a_rpc_messages_pb2():
    import passkit_io.core.a_rpc_messages_pb2
    return passkit_io.core.a_rpc_messages_pb2


def get_a_rpc_messages_pb2_grpc():
    import passkit_io.core.a_rpc_messages_pb2_grpc
    return passkit_io.core.a_rpc_messages_pb2_grpc


def get_a_rpc_certificates_pb2():
    import passkit_io.core.a_rpc_certificates_pb2
    return passkit_io.core.a_rpc_certificates_pb2


def get_a_rpc_certificates_pb2_grpc():
    import passkit_io.core.a_rpc_certificates_pb2_grpc
    return passkit_io.core.a_rpc_certificates_pb2_grpc


def get_a_rpc_others_pb2():
    import passkit_io.core.a_rpc_others_pb2
    return passkit_io.core.a_rpc_others_pb2


def get_a_rpc_others_pb2_grpc():
    import passkit_io.core.a_rpc_others_pb2_grpc
    return passkit_io.core.a_rpc_others_pb2_grpc


def get_a_rpc_distribution_pb2():
    import passkit_io.core.a_rpc_distribution_pb2
    return passkit_io.core.a_rpc_distribution_pb2


def get_a_rpc_distribution_pb2_grpc():
    import passkit_io.core.a_rpc_distribution_pb2_grpc
    return passkit_io.core.a_rpc_distribution_pb2_grpc


def get_a_rpc_templates_pb2():
    import passkit_io.core.a_rpc_templates_pb2
    return passkit_io.core.a_rpc_templates_pb2


def get_a_rpc_templates_pb2_grpc():
    import passkit_io.core.a_rpc_templates_pb2_grpc
    return passkit_io.core.a_rpc_templates_pb2_grpc


def get_a_rpc_images_pb2():
    import passkit_io.core.a_rpc_images_pb2
    return passkit_io.core.a_rpc_images_pb2


def get_a_rpc_images_pb2_grpc():
    import passkit_io.core.a_rpc_images_pb2_grpc
    return passkit_io.core.a_rpc_images_pb2_grpc
