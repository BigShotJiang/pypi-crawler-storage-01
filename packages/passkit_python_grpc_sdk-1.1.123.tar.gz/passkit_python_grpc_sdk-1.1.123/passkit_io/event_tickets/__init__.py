def get_a_rpc_pb2():
    import passkit_io.event_tickets.a_rpc_pb2
    return passkit_io.event_tickets.a_rpc_pb2


def get_a_rpc_pb2_grpc():
    import passkit_io.event_tickets.a_rpc_pb2_grpc
    return passkit_io.event_tickets.a_rpc_pb2_grpc


def get_event_pb2():
    import passkit_io.event_tickets.event_pb2
    return passkit_io.event_tickets.event_pb2


def get_event_pb2_grpc():
    import passkit_io.event_tickets.event_pb2_grpc
    return passkit_io.event_tickets.event_pb2_grpc


def get_production_pb2():
    import passkit_io.event_tickets.production_pb2
    return passkit_io.event_tickets.production_pb2


def get_production_pb2_grpc():
    import passkit_io.event_tickets.production_pb2_grpc
    return passkit_io.event_tickets.production_pb2_grpc


def get_ticket_pb2():
    import passkit_io.event_tickets.ticket_pb2
    return passkit_io.event_tickets.ticket_pb2


def get_ticket_pb2_grpc():
    import passkit_io.event_tickets.ticket_pb2_grpc
    return passkit_io.event_tickets.ticket_pb2_grpc


def get_ticket_type_pb2():
    import passkit_io.event_tickets.ticket_type_pb2
    return passkit_io.event_tickets.ticket_type_pb2


def get_ticket_type_pb2_grpc():
    import passkit_io.event_tickets.ticket_type_pb2_grpc
    return passkit_io.event_tickets.ticket_type_pb2_grpc


def get_venue_pb2():
    import passkit_io.event_tickets.venue_pb2
    return passkit_io.event_tickets.venue_pb2


def get_venue_pb2_grpc():
    import passkit_io.event_tickets.venue_pb2_grpc
    return passkit_io.event_tickets.venue_pb2_grpc
