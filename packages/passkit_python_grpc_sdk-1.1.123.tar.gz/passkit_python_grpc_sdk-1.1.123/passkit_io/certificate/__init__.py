def get_certificate_pb2():
    import passkit_io.certificate.certificate_pb2
    return passkit_io.certificate.certificate_pb2


def get_certificate_pb2_grpc():
    import passkit_io.certificate.certificate_pb2_grpc
    return passkit_io.certificate.certificate_pb2_grpc
