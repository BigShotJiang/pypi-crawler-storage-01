def get_a_rpc_pb2_grpc():
    import passkit_io.member.a_rpc_pb2_grpc
    return passkit_io.member.a_rpc_pb2_grpc


def get_member_pb2():
    import passkit_io.member.member_pb2
    return passkit_io.member.member_pb2


def get_member_pb2_grpc():
    import passkit_io.member.member_pb2_grpc
    return passkit_io.member.member_pb2_grpc


def get_program_pb2():
    import passkit_io.member.program_pb2
    return passkit_io.member.program_pb2


def get_program_pb2_grpc():
    import passkit_io.member.program_pb2_grpc
    return passkit_io.member.program_pb2_grpc


def get_event_pb2():
    import passkit_io.member.event_pb2
    return passkit_io.member.event_pb2


def get_event_pb2_grpc():
    import passkit_io.member.event_pb2_grpc
    return passkit_io.member.event_pb2_grpc


def get_member_events_pb2():
    import passkit_io.member.member_events_pb2
    return passkit_io.member.member_events_pb2


def get_member_events_pb2_grpc():
    import passkit_io.member.member_events_pb2_grpc
    return passkit_io.member.member_events_pb2_grpc


def get_tier_pb2():
    import passkit_io.member.tier_pb2
    return passkit_io.member.tier_pb2


def get_tier_pb2_grpc():
    import passkit_io.member.tier_pb2_grpc
    return passkit_io.member.tier_pb2_grpc
