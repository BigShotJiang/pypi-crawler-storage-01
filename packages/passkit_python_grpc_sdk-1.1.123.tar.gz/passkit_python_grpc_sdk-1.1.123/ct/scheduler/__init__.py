def get_scheduler_pb2_grpc():
    import passkit_io.scheduler.scheduler_pb2_grpc
    return passkit_io.scheduler.scheduler_pb2_grpc


def get_scheduler_pb2():
    import passkit_io.scheduler.scheduler_pb2
    return passkit_io.scheduler.scheduler_pb2
