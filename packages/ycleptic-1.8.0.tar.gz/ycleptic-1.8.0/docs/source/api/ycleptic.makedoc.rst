ycleptic.makedoc module
=======================

.. automodule:: ycleptic.makedoc
   :members:
   :show-inheritance:
   :undoc-members:
