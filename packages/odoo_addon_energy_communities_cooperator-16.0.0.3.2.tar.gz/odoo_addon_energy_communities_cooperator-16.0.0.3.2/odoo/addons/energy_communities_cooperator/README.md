# Energy Communities Cooperator

<add description>

## Changelog

### 2025-05-21

- Added Readme
