During the installation of the module, current working times are split
by start/end dates for having consistent data, and the potential new
composed calendar planning is saved instead on the employee.
