- Add a wizard for generating next year calendar planning based on
  current one in batch.
- Add constraint for avoiding planning lines overlapping.
- Avoid the regeneration of whole private calendars each time a change
  is detected.
