1.  Go to *Employees \> Employees*.
2.  Open or create a new one.
3.  On the "Work Information" tab, fill the section "Working Hours"
    with:
    - Starting date (optional).
    - Ending date (optional).
    - Working time to apply during that date interval.
