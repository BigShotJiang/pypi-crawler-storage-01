This module allows to manage employee working time with profiles by date
intervals.

The profiles are regular working time calendars, but they are treated as
master ones here, allowing you to compose complexes working times by
dates.

Under the hook, a unique working time is created for each employee with
the proper composition for not affecting the rest of the functionality
linked to this model.
