"""
This is a forked copy of wx.lib.ogl.  It contains some patches that I made
to fix problems with dragging and resizing various shapes and lines.

https://github.com/wxWidgets/Phoenix/issues/2739
https://discuss.wxpython.org/t/wx-lib-ogl-errors/40202

The PR I put in with the wxPython team was met with resistance, so I abandoned it.

This is my fork
"""