
from dataclasses import dataclass


@dataclass
class MoveCallbackData:
    currentItem: str = ''
