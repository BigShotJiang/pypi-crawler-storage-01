This module adds a wizard to generate medical examinations for employees
and an action to see them.

The idea is to generate all the examinations using the wizard and then
manage them individually even though the usage of the wizard is not
mandatory.

For generating the medical examinations:

1.  Go to the menu *Employees \> Medical Examinations \> Generate
    Medical Examinations*.
2.  Select a name and the employees and generate it.

To see all the medical examinations:

1.  Go to the menu *Employees \> Medical Examinations \> View Medical
    Examinations*.
