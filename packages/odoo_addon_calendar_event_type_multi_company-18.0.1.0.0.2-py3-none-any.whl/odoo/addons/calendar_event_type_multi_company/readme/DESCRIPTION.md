This module add multi-company management to calendar event type
