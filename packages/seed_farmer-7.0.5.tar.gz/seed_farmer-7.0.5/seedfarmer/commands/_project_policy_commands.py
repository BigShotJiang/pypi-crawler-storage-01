#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

import os
import sys

import yaml

from seedfarmer import CLI_ROOT, DEFAULT_PROJECT_POLICY_PATH


def get_default_project_policy(policy_prefix: str = "/") -> None:
    with open(os.path.join(CLI_ROOT, DEFAULT_PROJECT_POLICY_PATH), "rb") as f:
        policy = yaml.safe_load(f)

        if policy_prefix:
            policy["Resources"]["ProjectPolicy"]["Properties"]["Path"] = policy_prefix

        sys.stdout.write(yaml.dump(policy))
