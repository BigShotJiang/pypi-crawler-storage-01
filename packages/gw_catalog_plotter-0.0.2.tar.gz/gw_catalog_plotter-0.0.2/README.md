# catalog-plotter
Utilities for plotting gravitational wave catalogues
