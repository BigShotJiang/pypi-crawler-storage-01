import './base.css';
import './article.css';
import './slides.css';
import './skeleton.css';
import 'reveal.js/dist/reveal.css';
import 'reveal.js/dist/theme/white.css';