This module depends on the module base_tier_validation. To use this module, you need to:
1. Go to Settings > Technical > Tier Validation > Tier Definition
2. Create a new tier definition with the Referenced Model set to hr.personal.equipment.request
3. Go to Employees > Personal Equipment > Personal Equipment Request
4. Create a new personal equipment request and add a tier validation by clickin "Request Validation" button
