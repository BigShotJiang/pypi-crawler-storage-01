* Creu Blanca
