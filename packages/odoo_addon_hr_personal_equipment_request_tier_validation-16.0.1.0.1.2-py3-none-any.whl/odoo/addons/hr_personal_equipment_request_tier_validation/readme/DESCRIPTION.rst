This addon adds tier validation to the module personal equipment request
