# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-08-03)

### Bug Fixes

- V0.0.1 ?
  ([`6cf4ce0`](https://github.com/PyMoX-fr/GC7/commit/6cf4ce02840a13bac4e2460a121fd84486605e24))


## v0.0.0 (2025-08-03)

- Initial Release
