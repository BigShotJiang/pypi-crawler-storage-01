# CHANGELOG

<!-- version list -->

## v1.0.3 (2025-08-03)


## v1.0.2 (2025-08-03)


## v1.0.1 (2025-08-03)

### Bug Fixes

- Set hello()
  ([`03efc80`](https://github.com/PyMoX-fr/GC7/commit/03efc8032804e20feadba5fd246e07c1bc133b4b))


## v1.0.0 (2025-08-03)

- Initial Release
