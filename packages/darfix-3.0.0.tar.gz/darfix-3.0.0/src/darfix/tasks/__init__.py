"""
Ewoks tasks for the Darfix project.

What is ewoks ?

https://ewoks.esrf.fr/en/latest/

"""
