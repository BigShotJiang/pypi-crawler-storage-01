#!/bin/bash

gio="a"

echo "$gio" | eval