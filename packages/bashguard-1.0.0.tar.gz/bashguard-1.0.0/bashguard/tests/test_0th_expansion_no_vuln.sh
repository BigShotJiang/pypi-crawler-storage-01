foo = "$0"
bar = "$foo"