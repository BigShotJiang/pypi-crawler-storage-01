cygwin="$1"
RESPONSE="$2"
if [[ "$1" -eq 1337 || "$1" = "dog" ]]
if [ "$cygwin" = "false" -a "$darwin" = "false" -a "$nonstop" = "false" ] ; then
var1=1
var2=2
if (( var1 > var2 && CHALLENGE == RESPONSE )) ; then
if [[ "$cygwin" = "false" -a "$darwin" = "false" -a "$nonstop" = "false" ]] ; then
