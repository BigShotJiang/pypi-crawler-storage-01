#!/bin/bash

PROPAGANDA=(
	"enki"
	"benki"
	"siklisa"
)

input="$1"
echo "Your chosen motto: ${PROPAGANDA[$input]}"