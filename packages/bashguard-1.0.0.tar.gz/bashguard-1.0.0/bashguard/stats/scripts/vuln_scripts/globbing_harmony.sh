#!/bin/bash

PATH=/usr/bin
cd /tmp
cat /flag | tr -d [A-Za-z0-9]