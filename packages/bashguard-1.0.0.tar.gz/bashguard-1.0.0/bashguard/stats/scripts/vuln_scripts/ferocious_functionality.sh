#!/bin/bash

unset PATH
did you think you could hack this? It doesnt even exist!