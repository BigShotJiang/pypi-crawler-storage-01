#!/usr/bin/env bash

set -- *

for i; do
	echo "$i"
done
