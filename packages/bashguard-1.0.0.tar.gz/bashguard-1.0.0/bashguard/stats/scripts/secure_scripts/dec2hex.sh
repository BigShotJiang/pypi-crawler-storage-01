#!/usr/bin/env bash
printf "0x%x\n" "$1"
