Official package to use Defisocket api from Python

1- Install from PyPi
2- Make sure DEFISOCKET_URL is stored in your .env file. Default value is https://api.defisocket.com
3- Import LiveStream or HistoricalStream from defisocket
