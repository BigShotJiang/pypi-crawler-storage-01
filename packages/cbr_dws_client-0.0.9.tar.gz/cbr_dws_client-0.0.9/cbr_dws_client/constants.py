from enum import Enum


class CodeMetalEnum(Enum):
    GOLD = 1
    SILVER = 2
    PLATINUM = 3
    PALLADIUM = 4
