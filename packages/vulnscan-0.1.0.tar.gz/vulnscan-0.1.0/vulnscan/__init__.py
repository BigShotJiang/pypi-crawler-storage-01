# vulnscan/__init__.py

__version__ = "0.0.1"
__author__ = "Gokul Kannan"
__email__ = "gokulkannan.dev@gmail.com"

# Optional: expose main interfaces
from .cli import main as cli_main
