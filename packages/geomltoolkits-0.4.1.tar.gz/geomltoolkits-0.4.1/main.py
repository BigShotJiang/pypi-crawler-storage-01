def main():
    print("Hello from geoml-toolkits!")


if __name__ == "__main__":
    main()
