from font_fetcher.repo_1001fonts import Fonts1001Repo

repo_registry = [Fonts1001Repo()]
