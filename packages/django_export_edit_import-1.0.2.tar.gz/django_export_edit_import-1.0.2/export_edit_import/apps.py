from django.apps import AppConfig


class ExportEditImportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'export_edit_import'
