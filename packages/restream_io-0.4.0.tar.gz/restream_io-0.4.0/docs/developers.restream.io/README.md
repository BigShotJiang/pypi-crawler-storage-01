# API documentation

Unfortunately the official documentation is quite hard to get at in a single file. However, it is possible to:

- load it in the browser
- watch the HTTP requests
- copy & paste the markdown that the SPA loads

> [!IMPORTANT]
> This is currently captured manually, we need to create a script to make it easier to refetch the data.
