"""Prompts for MetricFlow MCP tools."""
