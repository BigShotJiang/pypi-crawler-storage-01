"""Configuration module for MetricFlow MCP server."""
