"""Server module for MetricFlow MCP server."""

import importlib.metadata

VERSION = importlib.metadata.version("mcp-metricflow")
