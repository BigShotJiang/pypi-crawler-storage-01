#![allow(unsafe_code, clippy::needless_pass_by_value)]

mod api;
mod error;
mod run_generator;
mod run_program;
