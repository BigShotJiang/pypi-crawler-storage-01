from .GenerateBAM import GenerateCellTypeBAM, bam2cell
from ._utils import clean_bcs


__version__ = '0.1'