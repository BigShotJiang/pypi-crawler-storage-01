__title__ = "lumicks.pylake"
__version__ = "1.7.0"
__summary__ = "Bluelake data analysis tools"
__url__ = "https://github.com/lumicks/pylake"

__author__ = "Lumicks B.V."
__copyright__ = "2025, " + __author__
__email__ = "pylake@lumicks.com"
__license__ = "Apache 2.0"
