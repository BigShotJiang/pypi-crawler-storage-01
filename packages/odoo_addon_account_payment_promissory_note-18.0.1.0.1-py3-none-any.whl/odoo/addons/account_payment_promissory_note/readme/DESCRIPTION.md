This module allows you to set a date due in a payment, as promissory
notes require.
