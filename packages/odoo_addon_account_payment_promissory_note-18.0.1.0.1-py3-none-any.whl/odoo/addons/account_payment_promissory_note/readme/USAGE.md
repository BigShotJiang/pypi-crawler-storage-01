1.  Go to Invoicing \> Customers / Vendors \> Payments.
2.  Create a new one and select the 'Promissory Note' option.
3.  Now you can select a date for the due of the promissory note
    (Automatically will be selected the lastest due date of the invoices
    if any selected).
