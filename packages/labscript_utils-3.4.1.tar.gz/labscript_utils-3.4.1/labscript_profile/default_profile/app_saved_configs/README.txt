This is the default location for labscript suite applications to save their
configurations.