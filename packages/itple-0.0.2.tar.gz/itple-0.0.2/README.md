# itple

> 잇플레이를 비롯한 잇플의 여러 콘텐츠에 사용할 수 있는 모듈입니다.

## 🚀 설치하기

pip를 통해 간단하게 설치할 수 있습니다.

```bash
pip install itple
