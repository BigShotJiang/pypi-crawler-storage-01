from flask_restx import Namespace

ns_conf = Namespace('chatbots', description='API to perform operations on MindsDB Chatbots')
