from flask_restx import Namespace


ns_conf = Namespace('auth', description='Authentification routes')
