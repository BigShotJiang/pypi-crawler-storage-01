#
#
#

# interfaces
from python_byzatic_commons.flattener.dictionary_flattener.DictionaryFlattener import DictionaryFlattener

__all__ = [
    'DictionaryFlattener'
]
