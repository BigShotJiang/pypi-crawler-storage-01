
Inspection
----------------------

.. currentmodule:: flax.linen

.. autofunction:: tabulate
