Model inspection
================

.. toctree::
   :maxdepth: 1

   model_surgery
   extracting_intermediates
