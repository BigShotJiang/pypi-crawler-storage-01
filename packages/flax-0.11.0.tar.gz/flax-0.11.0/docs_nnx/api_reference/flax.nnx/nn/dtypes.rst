Dtypes
------------------------

.. automodule:: flax.nnx.nn.dtypes
.. currentmodule:: flax.nnx.nn.dtypes

.. autofunction:: canonicalize_dtype
.. autofunction:: promote_dtype