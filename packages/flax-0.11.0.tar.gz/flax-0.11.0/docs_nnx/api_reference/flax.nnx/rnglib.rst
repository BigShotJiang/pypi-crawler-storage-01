rnglib
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx

.. autoclass:: Rngs
   :members: __init__
.. autoclass:: RngStream
   :members:
.. autofunction:: reseed
