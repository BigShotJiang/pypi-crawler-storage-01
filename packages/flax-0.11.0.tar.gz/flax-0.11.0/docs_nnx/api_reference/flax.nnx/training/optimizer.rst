Optimizer
------------------------

.. automodule:: flax.nnx.optimizer
.. currentmodule:: flax.nnx.optimizer

.. autoclass:: Optimizer
   :members: __init__, update
