VERSION = "0.1.2"
__version__ = VERSION
APP_NAME = "Magentic-UI"
