import webbrowser

def ネット(URL):
    webbrowser.open(URL)