import enum


class tagVersionRail(enum.Enum):
    VER_V1 = 0
    VER_V2 = 1
