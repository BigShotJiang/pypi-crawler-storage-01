import enum


class TriggerMode(enum.Enum):
    LEVEL = 0
    AD = 1
