import enum


class EMotorIndex(enum.Enum):
    STEPPER1 = 0
    STEPPER2 = 1
