import enum


class RealTimeTrack(enum.Enum):
    NONREALTIME = 0
    REALTIME = 1
