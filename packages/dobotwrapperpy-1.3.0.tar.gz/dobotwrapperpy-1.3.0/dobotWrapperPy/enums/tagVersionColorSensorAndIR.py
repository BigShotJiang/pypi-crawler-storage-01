import enum


class TagVersionColorSensorAndIR(enum.Enum):
    VERSION1 = 0
    VERSION2 = 1
