import enum


class Level(enum.Enum):
    LOW = 0
    HIGH = 1
