import enum


class CPMode(enum.Enum):
    RELATIVE = 0
    ABSOLUTE = 1
