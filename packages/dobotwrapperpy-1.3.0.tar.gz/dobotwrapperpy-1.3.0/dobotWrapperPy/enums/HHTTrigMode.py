import enum


class HHTTrigMode(enum.Enum):
    TriggeredOnKeyRelease = 0x0
    TriggeredOnPeriodicInterval = 0x1
