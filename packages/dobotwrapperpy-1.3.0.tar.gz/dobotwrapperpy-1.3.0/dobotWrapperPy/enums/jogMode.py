import enum


class JogMode(enum.Enum):
    COORDINATE = 0
    JOINT = 1
