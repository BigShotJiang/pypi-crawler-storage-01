#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Staran 使用示例
=============

演示如何使用Staran进行各种日期处理任务。
"""

__all__ = []
