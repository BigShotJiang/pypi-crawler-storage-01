"""icsystemutils

This package is a set of utilties for querying and interacting with system resources,
e.g. cpus, gpus and the network.
"""
