"""Scaffold package initialization."""
__version__ = "0.1.16"
