from ... import verbosity

verbosity(0)
