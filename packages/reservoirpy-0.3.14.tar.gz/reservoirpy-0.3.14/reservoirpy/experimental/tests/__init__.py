from reservoirpy import verbosity

verbosity(0)
