from .scalar import Scalar

__all__ = ["Scalar"]
