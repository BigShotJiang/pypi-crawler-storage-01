"""
The service layer for hippo. Provides access to the database and file storage
layers, which should not be used individually.
"""
