"""
API layer for hippo. This consumes the service layer.
"""
