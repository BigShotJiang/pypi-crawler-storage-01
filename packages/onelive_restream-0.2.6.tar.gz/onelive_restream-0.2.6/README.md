# 🧡 OneLive Retream API Client

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

Copyright © 2025 Yegor Yakubovich
