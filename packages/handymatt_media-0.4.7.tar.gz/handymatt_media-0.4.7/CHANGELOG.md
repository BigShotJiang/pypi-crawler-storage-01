# CHANGELOG

## 0.1.0
- video_analyser working I guess

## 0.2.0
- added generateSeekThumbnails()

## 0.3.0
- added getVideoHash_openCV()  (faster, especially on Windows)


## 0.4.0
- Refactored media_generator, split ffmpeg only generators into own file

## 0.4.1-0.4.4
- Fixing bugs

## 0.4.5-0.4.6
- Fixed misalignment issue with spritesheet gen (seek thumbs)
