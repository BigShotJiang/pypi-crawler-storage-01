""" Functions for viewing and editing metadata for images and videos """
