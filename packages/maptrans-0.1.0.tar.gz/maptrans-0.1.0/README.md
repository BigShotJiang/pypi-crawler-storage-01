# Map Transform tool

copy from <https://epsg.io/>
but API form <https://www.maptiler.com/>

## Sample

use this csv in `sample.csv`

```csv
X,Y,H
20510210.743588,4058386.735392,155.55
20510196.183790,4057723.195846,123.45
```

run

```sh
mt --key <YOUR-KEY> --input sample.csv
```
