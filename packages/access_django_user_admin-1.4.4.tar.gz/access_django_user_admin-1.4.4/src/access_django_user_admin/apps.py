from django.apps import AppConfig

class Access_Django_User_AdminConfig(AppConfig):
    name = 'access_django_user_admin'
    verbose_name = 'ACCESS Django User Admin'
