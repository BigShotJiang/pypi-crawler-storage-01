# LlamaIndex Vector_Stores Integration: Couchbase

> **Note:** `CouchbaseVectorStore` has been deprecated in version 0.4.0. Please use `CouchbaseSearchVectorStore` instead.
