---
name: Question
about: Ask a question.
title: ""
labels: "Type: ⁇ Question"
---

## Prework

- [ ] Read and agree to the [code of conduct](https://www.contributor-covenant.org/version/2/1/code_of_conduct/) and [contributing guidelines](https://github.com/posit-dev/gt-extras/blob/main/.github/CONTRIBUTING.md).
- [ ] If there is [already a relevant issue](https://github.com/posit-dev/gt-extras/issues), whether open or closed, comment on the existing thread instead of posting a new issue.

## Question

What would you like to know?
