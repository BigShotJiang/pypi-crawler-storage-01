from django.apps import AppConfig


class CalendarHj3415Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'calendar_hj3415'
