# Internal diagnostics database.

class InternalDatabase:
    """Internal diagnostics database.

    """

    def __init__(self, dids):
        self.dids = dids
