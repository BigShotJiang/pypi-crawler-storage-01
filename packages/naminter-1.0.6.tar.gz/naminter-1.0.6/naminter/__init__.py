from .core.main import Naminter

__version__ = "1.0.6"
__author__ = "3xp0rt"
__description__ = "WhatsMyName Enumeration Tool"
__license__ = "MIT"
__email__ = "contact@3xp0rt.com"
__url__ = "https://github.com/3xp0rt/Naminter"
__all__ = ['Naminter']