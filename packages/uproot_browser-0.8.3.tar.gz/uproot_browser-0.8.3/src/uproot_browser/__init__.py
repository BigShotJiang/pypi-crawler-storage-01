"""
This is uproot-browser. There is no user accessible API; only a terminal
interface is provided currently.
"""

from __future__ import annotations

from ._version import version as __version__

__all__ = ("__version__",)
