__version__ = '0.0.5'
__author__ = 'Frederik H Gjørup'
__authors__ = ['Frederik H. Gjørup']
__email__ = 'fgjorup@chem.au.dk'
__date__ = '01.08.2025'
__year__ = '2025'