from .variable import ExperimentVariable, multifact
from .design import Design
from .nest import nest, cross
from .unit import Units
from .assignment import assign