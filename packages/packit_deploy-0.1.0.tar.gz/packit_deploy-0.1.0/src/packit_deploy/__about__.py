# SPDX-FileCopyrightText: 2023-present Alex Hill <alex.hill@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.0"
