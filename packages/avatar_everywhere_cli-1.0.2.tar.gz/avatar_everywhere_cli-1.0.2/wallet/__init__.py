"""
Avatar Everywhere CLI - Wallet Module
Handles NFT ownership verification on Polygon network
"""

# Note: This module contains JavaScript files for Node.js integration
# The verify_owner.js file is called via subprocess from the Python CLI 