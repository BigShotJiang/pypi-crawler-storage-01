def test_imports():
    from odio.v1_3 import A, Cell, H, H1, H2, H3, H4, H5, H6, P, Span

    A()
    Cell()
    P()
    H()
    H1()
    H2()
    H3()
    H4()
    H5()
    H6()
    Span()
