# Gitself

The Self-Hosted, Statically Generated, Aggressively Distributed protocol and
tooling for Git.

## Why

If you think that Capitalism Is Bad™ or you just prefer your projects to easily
be able to survive a [nuclear holocaust][boom], or you just want to be able to
completely work on things offline for great periods of time... Gitself is for
you. We stand on the shoulders of giants, or at least build on the efforts of
all those who came before us.

---

Gitself is project management using git, itself. It's a collection of tooling
and protocols to help you accomplish anything that you might want to do from a
self-hosted perspective. All you need is git and some place to host your files.
A pretty good way is using the Caddy webserver, because it will automatically
give you HTTPS. And then other copies of the repo.


# Changelog

Gitself uses [keepachangelog](https://keepachangelog.com/en/1.1.0/) and
[calver](https://calver.org/) of the YY.M.PATCH variety.

Currently Gitself is considered Alpha quality. Expect many things to break,
often. Back up your work before futzing with us.

## 25.8.0 - Unreleased

### Added

- Basically everything.
  - The ability to create new issues
  - HTML dumping #0001
  - Autocommit #0005
  - Create New #0011
  - `close` command.
  - `view` command.

[boom]: https://en.wikipedia.org/wiki/Nuclear_holocaust
