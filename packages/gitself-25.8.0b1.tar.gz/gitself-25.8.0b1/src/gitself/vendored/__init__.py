"""
A collection of vendored modules. Code in here is unlikely to ever
change, but also gitself would be very sad if you couldn't access it,
so we include these libraries with our distributions.
"""
