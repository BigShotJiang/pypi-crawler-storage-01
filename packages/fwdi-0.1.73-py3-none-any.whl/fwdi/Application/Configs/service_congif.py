
class ServiceConfig():
    service_avaible: bool = False
    SECRET_KEY = ""
    ALGORITHM = ""
    ACCESS_TOKEN_EXPIRE_MINUTES = 0