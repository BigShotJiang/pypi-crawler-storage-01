from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.cortex_analyst._generated.api.cortex_analyst_api import CortexAnalystApi

__all__ = [
    "CortexAnalystApi",
]
