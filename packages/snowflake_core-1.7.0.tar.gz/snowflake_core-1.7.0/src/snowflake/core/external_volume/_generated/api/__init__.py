from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.external_volume._generated.api.external_volume_api import ExternalVolumeApi

__all__ = [
    "ExternalVolumeApi",
]
