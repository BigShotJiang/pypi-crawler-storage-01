from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.image_repository._generated.api.image_repository_api import ImageRepositoryApi

__all__ = [
    "ImageRepositoryApi",
]
