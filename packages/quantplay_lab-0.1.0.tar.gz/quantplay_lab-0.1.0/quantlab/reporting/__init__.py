"""Reporting and visualization components"""

from quantlab.reporting.console import ResultsFormatter

__all__ = ["ResultsFormatter"]