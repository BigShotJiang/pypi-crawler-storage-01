"""Indian market specific components"""

from quantlab.market.india.charges import Charges

__all__ = ["Charges"]