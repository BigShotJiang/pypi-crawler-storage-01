"""Constants with hard coded paths"""

TMP_DIR = "/home/proj/production/rare-disease/temp-dir/"
