"""Symbol constants."""

EMPTY_STRING = ""
SPACE = " "
NEW_LINE = "\n"
