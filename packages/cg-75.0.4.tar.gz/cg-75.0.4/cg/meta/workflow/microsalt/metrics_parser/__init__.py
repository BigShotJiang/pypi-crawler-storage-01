from cg.meta.workflow.microsalt.metrics_parser.metrics_parser import MetricsParser
from cg.meta.workflow.microsalt.metrics_parser.models import QualityMetrics, SampleMetrics
