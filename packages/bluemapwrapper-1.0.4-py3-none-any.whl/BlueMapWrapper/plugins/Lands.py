class Lands:
    def __init__(self, name: str, level: str, balance: int, chunks: int, description: str):
        self.name = name
        self.level = level
        self.balance = balance
        self.chunks = chunks
        self.description = description

