# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# NOTE: This is a direct port of the bare minimum needed for BatchEngine functionality from
#       the original Promptflow code. The goal here is expediency, not elegance. As such
#       parts of this code may be a little "quirky", seem incomplete in places, or contain
#       longer TODOs comments than usual. In a future code update, large swaths of this code
#       will be refactored or deleted outright.
