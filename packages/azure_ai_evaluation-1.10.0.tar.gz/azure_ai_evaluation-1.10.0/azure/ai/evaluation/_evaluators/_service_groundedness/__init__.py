# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._service_groundedness import GroundednessProEvaluator

__all__ = [
    "GroundednessProEvaluator",
]
