"""Pacote de testes do SDK Sicoob"""
