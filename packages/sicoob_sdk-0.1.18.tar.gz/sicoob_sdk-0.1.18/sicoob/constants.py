"""Constantes globais para o cliente Sicoob"""

AUTH_URL = (
    'https://auth.sicoob.com.br/auth/realms/cooperado/protocol/openid-connect/token'
)
BASE_URL = 'https://api.sicoob.com.br'
SANDBOX_URL = 'https://sandbox.sicoob.com.br/sicoob/sandbox'
