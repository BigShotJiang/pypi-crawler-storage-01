"""
Cloudreve API client package.
"""

from .client import CloudreveClient

__all__ = ["CloudreveClient"]
