# meshage

Many thanks to the [Connect](https://github.com/pdxlocations/connect) project, without which this wouldn't have been possible. Their work on the the packet encryption method was invaluble.