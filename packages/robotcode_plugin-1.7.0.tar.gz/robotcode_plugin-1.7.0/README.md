# robotcode-plugin

[![PyPI - Version](https://img.shields.io/pypi/v/robotcode-plugin.svg)](https://pypi.org/project/robotcode-plugin)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/robotcode-plugin.svg)](https://pypi.org/project/robotcode-plugin)
[![License](https://img.shields.io/github/license/robotcodedev/robotcode?style=flat&logo=apache)](https://github.com/robotcodedev/robotcode/blob/master/LICENSE.txt)

-----

## Introduction

Some classes for [RobotCode](https://robotcode.io) plugin management

## Installation

```console
pip install robotcode-plugin
```

## License

`robotcode-plugin` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
