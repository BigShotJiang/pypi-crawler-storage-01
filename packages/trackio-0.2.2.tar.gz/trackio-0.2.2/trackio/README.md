---
sdk: gradio
sdk_version: {GRADIO_VERSION}
app_file: ui.py
tags:
 - trackio
---