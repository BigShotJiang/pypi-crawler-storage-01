# App for practicing Japanese

## Known issues:

```
戻[した]の？
Your answer (kanji): 下   
Correct!
```