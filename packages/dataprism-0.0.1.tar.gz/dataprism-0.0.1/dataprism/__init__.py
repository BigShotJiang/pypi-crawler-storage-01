"""
DataPrism - A Python library for exploratory data analysis.

This is a minimal package for name reservation on PyPI.
Full functionality will be implemented in future releases.
"""

__version__ = "0.0.1"
__author__ = "LattIQ Development Team"
__email__ = "dev@lattiq.com"

def hello():
    """A simple hello function for testing the package installation."""
    return "Hello from DataPrism! This package is under development."