## cdf 

### Improved

- When running `cdf build`, you no longer get a `ResourceFormatWarning`
when you have a group with an AgentsAcl.

## templates

No changes.