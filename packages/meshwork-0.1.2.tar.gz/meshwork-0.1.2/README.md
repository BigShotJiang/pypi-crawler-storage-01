Meshwork
===

Library to connect a set of processes in a mesh configuration using
some form of network transparent bus. 

Used to issue automation requests to backend workers and capture their
output.

This library is still very specific to the automation for the
https://api.mythica.gg API backend.
