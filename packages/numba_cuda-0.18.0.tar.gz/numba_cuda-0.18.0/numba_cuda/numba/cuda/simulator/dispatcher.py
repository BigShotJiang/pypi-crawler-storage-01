class CUDADispatcher:
    """
    Dummy class so that consumers that try to import the real CUDADispatcher
    do not get an import failure when running with the simulator.
    """

    ...
