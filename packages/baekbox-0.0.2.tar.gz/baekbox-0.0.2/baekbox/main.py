
def hel():
    print("sel")