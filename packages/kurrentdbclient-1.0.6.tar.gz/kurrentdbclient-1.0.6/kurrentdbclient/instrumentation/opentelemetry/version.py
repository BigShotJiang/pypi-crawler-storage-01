import kurrentdbclient

__version__ = kurrentdbclient.__version__
