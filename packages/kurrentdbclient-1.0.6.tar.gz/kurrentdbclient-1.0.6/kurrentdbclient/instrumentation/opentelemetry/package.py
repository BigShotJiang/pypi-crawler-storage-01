import kurrentdbclient

_instruments = (f"{__name__.split('.')[0]} == {kurrentdbclient.__version__}",)
