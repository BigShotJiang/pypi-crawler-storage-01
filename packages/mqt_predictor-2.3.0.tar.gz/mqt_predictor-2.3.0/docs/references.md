# References

If you use _MQT Predictor_ in your work, we would appreciate if you cited {cite:labelpar}`quetschlich2025mqtpredictor` (which subsumes {cite:labelpar}`quetschlich2023prediction` and {cite:labelpar}`quetschlich2023compileroptimization`).

If you are explicitly referring to the application-aware compilation scheme, please cite {cite:labelpar}`quetschlich2024application_compilation`.

```{bibliography}

```
