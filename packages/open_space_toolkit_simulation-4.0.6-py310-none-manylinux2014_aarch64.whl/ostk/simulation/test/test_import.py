# Apache License 2.0


class TestImport:
    def test_import(self):
        from ostk.simulation import Satellite
