"""RekordBox Bulk Edit - Tools for bulk editing RekordBox database records."""

__version__ = "0.1.0"
__author__ = "James Viall"
__email__ = "jamesviall@pm.me"
