# Teleos library. 

Package under development.
