from .huggingfaceembedding import HuggingFaceEmbedding
from .opencvlbpembedding import OpenCVLBPEmbedding
from .torchembedding import PyTorchEmbedding
from .tensorflowembedding import TensorflowEmbedding