"""
Core module for checking deprecated dependencies.
"""

__version__ = "1.0.0" 