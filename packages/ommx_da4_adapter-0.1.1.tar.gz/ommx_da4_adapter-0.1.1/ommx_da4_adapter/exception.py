class OMMXDA4AdapterError(Exception):
    pass
