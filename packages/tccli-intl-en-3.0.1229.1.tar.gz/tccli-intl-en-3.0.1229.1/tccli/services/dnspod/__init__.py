# -*- coding: utf-8 -*-

from tccli.services.dnspod.dnspod_client import action_caller
    