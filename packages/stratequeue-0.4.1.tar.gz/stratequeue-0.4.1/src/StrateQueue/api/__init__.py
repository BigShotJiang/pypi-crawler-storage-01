"""
StrateQueue API Module

REST API endpoints for web UI integration.
"""

__all__ = ["daemon"] 