"""
This module is deprecated and exists only to re-export members
of `sift_py.rule`. Prefer to use that module.
"""
