"""
INTERNAL MODULE

This module contains implementation details that aren't meant to be used directly.
APIs in this module are garaunteed to not be stable so proceed at your own risk.
"""
