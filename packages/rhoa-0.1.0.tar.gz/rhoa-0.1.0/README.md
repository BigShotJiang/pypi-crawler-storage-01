# Noor

Noor is a Python package providing pandas DataFrame extension accessors for technical analysis.

## License

This project is licensed under the GNU General Public License v3.0 - see the [LICENSE](LICENSE) file for details.

## Installation

```bash
pip install noor
```
