import warnings

warnings.warn(
    "The 'signal' package is deprecated and will be removed in a future release.",
    DeprecationWarning,
    stacklevel=2,
)
