from corneto.extensions._numba import OptionalNumba

numba = OptionalNumba()
