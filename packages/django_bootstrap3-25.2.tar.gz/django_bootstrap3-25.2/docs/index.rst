Welcome to django-bootstrap3's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   templatetags
   settings
   templates
   changelog
