=========
Changelog
=========

All notable changes to this project will be documented in this file.


[0.1.2] - 11 April 2025
=======================

Added
-----

* Added footer text option

* Mark it as paralell safe.

[0.1.0] - 03 August 2023
========================

Added
-----

* Initial code release
