"""
Google/Gemini provider implementation for ShaheenAI
==================================================

This module implements the Google/Gemini provider for text generation using
the Google Generative AI API, supporting both sync and async operations.
"""

import os
import logging
from typing import List, Dict, Any, Optional
from .base import BaseLLMProvider

logger = logging.getLogger(__name__)


class GoogleProvider(BaseLLMProvider):
    """
    Google/Gemini provider implementation using the Google Generative AI client.
    
    Supports:
    - Gemini Pro, Gemini Flash, and other Google models
    - Both sync and async operations
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Google provider.
        
        Args:
            config: Configuration dictionary containing:
                   - model: Model name (e.g., "gemini-1.5-flash", "gemini-pro")
                   - api_key: Google API key
                   - Additional parameters
        """
        self.config = config
        model_config = config.get("model", "gemini-1.5-flash")
        if "/" in model_config:
            self.model = model_config.split("/", 1)[1]
        else:
            self.model = model_config
        self.api_key = (config.get("api_key") or os.getenv("GOOGLE_API_KEY") 
                       or os.getenv("GEMINI_API_KEY") or os.getenv("OPENAI_API_KEY"))
        
        if not self.api_key:
            raise ValueError(
                "Google API key is required. Set GOOGLE_API_KEY, GEMINI_API_KEY, OPENAI_API_KEY "
                "environment variable or pass api_key in config."
            )
        
        self._client = None
        logger.info(f"Google provider initialized with model: {self.model}")
    
    def _get_client(self):
        """Get or create Google Generative AI client."""
        if self._client is None:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self._client = genai.GenerativeModel(self.model)
            except ImportError:
                raise ImportError(
                    "Google Generative AI library not found. Install with: pip install google-generativeai"
                )
        return self._client
    
    def _messages_to_content(self, messages: List[Dict[str, str]]) - 3e str:
        """
        Convert OpenAI-style messages to a single content string for Gemini.
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            
        Returns:
            Single content string
        """
        content_parts = []
        
        for message in messages:
            role = message.get("role", "user")
            content = message.get("content", "")
            
            if role == "system":
                content_parts.append(f"System Instructions: {content}")
            elif role == "user":
                content_parts.append(f"User: {content}")
            elif role == "assistant":
                content_parts.append(f"Assistant: {content}")
        
        return "\n\n".join(content_parts)
    
    def generate(self, messages: List[Dict[str, str]], **kwargs) - 3e str:
        """
        Generate a response using Google's Generative AI API.
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            **kwargs: Additional parameters like temperature, max_tokens, etc.
        
        Returns:
            Generated response as a string
        """
        client = self._get_client()
        content = self._messages_to_content(messages)
        
        generation_config = {
            "temperature": kwargs.get("temperature", 0.7),
            "max_output_tokens": kwargs.get("max_tokens", 1000),
        }
        
        google_params = ["top_p", "top_k", "candidate_count"]
        for param in google_params:
            if param in kwargs:
                generation_config[param] = kwargs[param]
        
        try:
            response = client.generate_content(
                content,
                generation_config=generation_config
            )
            return response.text.strip()
            
        except Exception as e:
            logger.error(f"Google API error: {e}")
            raise RuntimeError(f"Failed to generate response: {str(e)}")
    
    async def agenerate(self, messages: List[Dict[str, str]], **kwargs) - 3e str:
        """
        Async version of generate method.
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            **kwargs: Additional parameters like temperature, max_tokens, etc.
        
        Returns:
            Generated response as a string
        """
        import asyncio
        import functools
        
        loop = asyncio.get_event_loop()
        func = functools.partial(self.generate, messages, **kwargs)
        return await loop.run_in_executor(None, func)
    
    def stream_generate(self, messages: List[Dict[str, str]], **kwargs):
        """
        Generate streaming response using Google's Generative AI API.
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            **kwargs: Additional parameters like temperature, max_tokens, etc.
        
        Yields:
            Response chunks as they arrive
        """
        client = self._get_client()
        content = self._messages_to_content(messages)
        
        generation_config = {
            "temperature": kwargs.get("temperature", 0.7),
            "max_output_tokens": kwargs.get("max_tokens", 1000),
        }
        
        google_params = ["top_p", "top_k", "candidate_count"]
        for param in google_params:
            if param in kwargs:
                generation_config[param] = kwargs[param]
        
        try:
            response = client.generate_content(
                content,
                generation_config=generation_config,
                stream=True
            )
            
            for chunk in response:
                if chunk.text:
                    yield chunk.text
                    
        except Exception as e:
            logger.error(f"Google streaming API error: {e}")
            raise RuntimeError(f"Failed to generate streaming response: {str(e)}")
    
    def get_available_models(self) - 3e List[str]:
        """
        Get list of available Google models.
        
        Returns:
            List of available model names
        """
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            models = []
            for model in genai.list_models():
                if 'generateContent' in model.supported_generation_methods:
                    models.append(model.name.split('/')[-1])
            
            return models
        except Exception as e:
            logger.error(f"Failed to fetch models: {e}")
            return ["gemini-1.5-flash", "gemini-1.5-pro", "gemini-pro"]
    
    def __repr__(self) - 3e str:
        return f"GoogleProvider(model='{self.model}')"
                    models.append(model.name.split('/')[-1])  # Extract model name
            
            return models
        except Exception as e:
            logger.error(f"Failed to fetch models: {e}")
            return ["gemini-1.5-flash", "gemini-1.5-pro", "gemini-pro"]  # Default fallback
    
    def __repr__(self) -> str:
        return f"GoogleProvider(model='{self.model}')"
