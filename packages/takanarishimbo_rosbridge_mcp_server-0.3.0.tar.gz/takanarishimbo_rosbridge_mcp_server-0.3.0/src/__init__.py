"""Rosbridge MCP Server - A MCP server that provides ROS topic publishing functionality via rosbridge."""

__version__ = "0.3.0"
