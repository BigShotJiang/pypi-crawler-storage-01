class Reactor:

    def __init__(self):
        self._reactors = {}
