"""Data models for the Local Talk App."""
