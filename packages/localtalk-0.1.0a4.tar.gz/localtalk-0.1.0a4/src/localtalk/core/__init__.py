"""Core components for the Local Talk App."""
