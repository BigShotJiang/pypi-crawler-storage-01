"""Services for the Local Talk App."""
