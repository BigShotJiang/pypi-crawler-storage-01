DROP INDEX IF EXISTS transaction_updated;
