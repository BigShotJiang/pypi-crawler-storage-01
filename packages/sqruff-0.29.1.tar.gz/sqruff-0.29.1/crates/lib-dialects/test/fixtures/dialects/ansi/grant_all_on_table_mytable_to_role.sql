grant all on table mytable to myrole
