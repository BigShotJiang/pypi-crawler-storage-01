WITH cte as (select a from tbla)
select a from cte
