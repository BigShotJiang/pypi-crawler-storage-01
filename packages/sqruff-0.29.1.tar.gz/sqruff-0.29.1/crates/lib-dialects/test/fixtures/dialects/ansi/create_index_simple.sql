CREATE INDEX transaction_updated ON transaction_master(last_updated);
CREATE UNIQUE INDEX transaction_updated ON transaction_master(last_updated);
