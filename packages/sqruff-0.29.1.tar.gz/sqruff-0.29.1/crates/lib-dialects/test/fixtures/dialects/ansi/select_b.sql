select * from foo JOIN bar ON (foo.a = bar.a)
