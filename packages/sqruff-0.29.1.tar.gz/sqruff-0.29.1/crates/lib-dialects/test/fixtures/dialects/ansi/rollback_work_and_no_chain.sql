rollback work and no chain
