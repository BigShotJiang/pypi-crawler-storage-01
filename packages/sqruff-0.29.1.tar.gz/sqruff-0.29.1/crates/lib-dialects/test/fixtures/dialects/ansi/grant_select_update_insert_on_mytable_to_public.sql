grant select, update, insert on mytable to public
