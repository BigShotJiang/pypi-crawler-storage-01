UPDATE
  my_table AS tttd
SET
  tttd.days=ttu.days
