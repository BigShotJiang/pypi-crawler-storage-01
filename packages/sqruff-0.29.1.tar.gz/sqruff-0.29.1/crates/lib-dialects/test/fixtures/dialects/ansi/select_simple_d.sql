 select 12 -- ends with comment
