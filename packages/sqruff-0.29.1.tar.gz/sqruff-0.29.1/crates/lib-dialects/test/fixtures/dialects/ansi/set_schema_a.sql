set schema my_schema
