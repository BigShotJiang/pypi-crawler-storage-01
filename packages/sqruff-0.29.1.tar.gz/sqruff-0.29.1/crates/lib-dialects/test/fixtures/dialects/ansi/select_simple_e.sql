SELECT
    my_var::date as casted_variable,
    123::bigint as another_casted_number
FROM boo
