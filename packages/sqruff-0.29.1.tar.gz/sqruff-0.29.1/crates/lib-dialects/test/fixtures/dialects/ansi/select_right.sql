SELECT column_name
FROM table1
RIGHT JOIN table2
ON table1.column_name = table2.column_name
