SELECT column_name FROM table_name WHERE period1 OVERLAPS period2;
