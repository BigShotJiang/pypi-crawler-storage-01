grant all privileges on mytable to myrole
