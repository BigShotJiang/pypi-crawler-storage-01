grant all on mytable to public
