create database if not exists my_database
