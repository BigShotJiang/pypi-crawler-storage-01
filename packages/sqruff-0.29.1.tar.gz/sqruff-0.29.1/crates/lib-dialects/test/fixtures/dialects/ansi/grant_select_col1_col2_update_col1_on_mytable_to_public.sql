grant select (col1, col2), update (col1) on mytable to public
