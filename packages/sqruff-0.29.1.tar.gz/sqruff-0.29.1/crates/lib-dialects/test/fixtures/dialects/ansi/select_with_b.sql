WITH blah AS (select x,y,z FROM foo) select z, y, x from blah;
