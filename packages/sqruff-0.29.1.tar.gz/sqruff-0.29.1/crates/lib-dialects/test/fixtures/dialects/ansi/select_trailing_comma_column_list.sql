SELECT
    user_id,
FROM
    table
