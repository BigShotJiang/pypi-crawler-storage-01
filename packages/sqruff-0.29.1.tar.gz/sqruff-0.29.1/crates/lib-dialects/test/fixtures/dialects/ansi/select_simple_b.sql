select * from blah
