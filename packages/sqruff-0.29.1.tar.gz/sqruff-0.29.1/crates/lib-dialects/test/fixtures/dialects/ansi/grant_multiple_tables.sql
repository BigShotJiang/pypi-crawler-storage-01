GRANT INSERT ON my_table, my_table2 TO public;
GRANT INSERT ON my_table, my_table2 TO "public";
GRANT INSERT, UPDATE ON my_table, my_table2 TO public;
GRANT INSERT, UPDATE ON my_table, my_table2 TO "public";
GRANT INSERT, UPDATE, DELETE ON my_table, my_table2 TO public;
GRANT INSERT, UPDATE, DELETE ON my_table, my_table2 TO "public";
GRANT INSERT, UPDATE, DELETE, SELECT ON my_table, my_table2 TO public;
GRANT INSERT, UPDATE, DELETE, SELECT ON my_table, my_table2 TO "public";
