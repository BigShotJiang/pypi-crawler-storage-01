select
    '1'    ::   INT as id1,
    '2'::int as id2
from table_a
