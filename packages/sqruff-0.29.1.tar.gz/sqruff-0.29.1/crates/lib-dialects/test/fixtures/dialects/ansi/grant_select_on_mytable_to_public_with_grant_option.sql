grant select on mytable to public with grant option
