#space before from is non-breaking space
SELECT a,b, c  from sch."blah"
