"""
Utility functions for space package.
"""
