# Usage

Refer to the [service-template-python](https://github.com/VU-ASE/service-template-python) for a complete example on how to use this library.

:::warning[Global Dependencies]

If your service relies on global dependencies (such as `pip` modules), you must make sure that these dependencies are installed on the Rover for the `debix` user. 

:::
