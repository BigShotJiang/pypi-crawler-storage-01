# Core module for FABI+ framework
