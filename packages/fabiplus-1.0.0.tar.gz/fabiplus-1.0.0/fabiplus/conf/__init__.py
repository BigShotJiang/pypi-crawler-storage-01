# Configuration module for FABI+ framework
