"""
CLI module for FABI+ framework
"""

from .main import main

__all__ = ["main"]
