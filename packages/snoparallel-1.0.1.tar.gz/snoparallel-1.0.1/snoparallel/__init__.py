"""
Simplified parallelism with Python.
"""

from snoparallel.managers import Manager
from snoparallel.variables import Variable, VariableType
