"""AI Rulez - CLI tool for managing AI assistant rules."""

__version__ = "1.1.2-rc.1"