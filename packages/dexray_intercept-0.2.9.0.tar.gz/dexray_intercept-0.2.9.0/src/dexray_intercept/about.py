#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Daniel Baier, Jan-Niclas Hilgert"
__version__ = "0.2.9.0"