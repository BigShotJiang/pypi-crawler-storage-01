"""
Django Revolution Scripts

Collection of utility scripts for development, testing, and publishing.
"""

__version__ = "1.0.0" 