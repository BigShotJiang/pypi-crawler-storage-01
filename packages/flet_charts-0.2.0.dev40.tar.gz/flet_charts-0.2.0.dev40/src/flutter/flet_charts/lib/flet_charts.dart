library flet_flashlight;

export 'src/extension.dart' show Extension;
