x ** void y
