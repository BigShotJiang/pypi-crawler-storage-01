class X { f([]) { "use strict" } }
