function *g([]){ "use strict"; }
