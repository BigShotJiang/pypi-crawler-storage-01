function *g(...x) { "use strict"; }
