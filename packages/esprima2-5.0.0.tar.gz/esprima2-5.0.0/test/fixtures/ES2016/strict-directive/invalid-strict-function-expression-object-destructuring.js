(function({x, y}) { "use strict"; })
