for ({x, y} of z);
