for (let [p, q] of r);
