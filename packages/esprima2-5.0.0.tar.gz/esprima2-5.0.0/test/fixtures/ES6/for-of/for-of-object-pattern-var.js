for (var {x, y} of z);
