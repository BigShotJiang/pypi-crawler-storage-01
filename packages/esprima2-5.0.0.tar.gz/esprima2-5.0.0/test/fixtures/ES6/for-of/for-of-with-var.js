for (var x of list);
