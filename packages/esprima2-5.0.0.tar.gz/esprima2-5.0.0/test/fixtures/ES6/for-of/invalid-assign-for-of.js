for (x=0 of y);
