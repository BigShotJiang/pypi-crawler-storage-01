for (var [p, q] of r);
