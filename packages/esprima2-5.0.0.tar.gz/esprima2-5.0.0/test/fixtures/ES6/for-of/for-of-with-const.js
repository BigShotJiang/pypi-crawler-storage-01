for (const y of list);
