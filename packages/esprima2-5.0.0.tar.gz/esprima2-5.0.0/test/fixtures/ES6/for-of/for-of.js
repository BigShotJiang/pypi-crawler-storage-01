for (p of q);
