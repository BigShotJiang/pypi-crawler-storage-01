let {a,b=0,c:d,e:f=0,[g]:[h]}=0
