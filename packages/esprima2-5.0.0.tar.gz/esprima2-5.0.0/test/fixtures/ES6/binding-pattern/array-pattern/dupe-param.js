"use strict";
function a([a,a]){ }
function a([a,...a]){ }
function a([{a},...a]){ }