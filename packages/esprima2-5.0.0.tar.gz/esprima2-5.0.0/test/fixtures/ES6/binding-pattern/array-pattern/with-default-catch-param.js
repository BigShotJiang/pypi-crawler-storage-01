try { } catch ([a = 0]) { }
