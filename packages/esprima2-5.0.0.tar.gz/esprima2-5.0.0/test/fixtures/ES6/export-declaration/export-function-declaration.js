export function foo () {} false
