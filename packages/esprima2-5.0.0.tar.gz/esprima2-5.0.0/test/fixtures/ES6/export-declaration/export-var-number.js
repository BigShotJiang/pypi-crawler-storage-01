export var foo = 1;
