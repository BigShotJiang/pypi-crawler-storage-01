export default { foo: 1 };
