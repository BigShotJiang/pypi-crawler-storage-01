export {foo as default, bar} from "foo";
