export default (1 + 2);
