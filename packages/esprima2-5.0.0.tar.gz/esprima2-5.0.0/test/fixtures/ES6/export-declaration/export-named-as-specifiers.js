export {foo as default, bar};
