export {foo as bar} from "foo";
