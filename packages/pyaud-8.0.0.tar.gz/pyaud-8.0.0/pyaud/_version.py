"""
pyaud._version
==============

Contains the version of this package.

Allows for access to the version internally without cyclic imports
caused by accessing it through __init__.
"""

__version__ = "8.0.0"
