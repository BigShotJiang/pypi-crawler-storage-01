# whatwhatwhat
这是一个Python库，它只是用来测试用的，没有什么用

## 安装

您可以使用以下命令来安装您的库：

```bash
pip install anboredtext
