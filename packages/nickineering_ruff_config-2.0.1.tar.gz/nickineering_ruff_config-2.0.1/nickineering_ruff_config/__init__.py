from nickineering_ruff_config.update import update_ruff_base

__all__ = ["update_ruff_base"]
