"""Setup file for tabpfn-extensions."""

from __future__ import annotations

from setuptools import setup

# Call setup() to install the package
# Configuration is in pyproject.toml
setup()
