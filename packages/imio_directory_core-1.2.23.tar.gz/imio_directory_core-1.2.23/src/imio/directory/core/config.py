PHONE_RE = r"\+\d{7,15}"
URL_RE = r"http[s]?://\S*$"
