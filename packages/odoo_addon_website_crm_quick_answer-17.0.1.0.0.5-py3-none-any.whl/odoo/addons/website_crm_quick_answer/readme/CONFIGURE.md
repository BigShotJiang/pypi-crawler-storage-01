To configure this module, you need to:

1.  Have the action of the submit button on the website contact form configured to
    create a new opportunity.
2.  Go to **Settings \> Technical \> Automation \> Automation Rules \>
    Quick response to website contact form** and edit anything there.

Quicker way to just change the email template (something that most
likely you will want to do):

1.  Go to **Settings \> Technical \> Email \> Templates**
2.  Edit the template called *Quick response to website contact form*.
