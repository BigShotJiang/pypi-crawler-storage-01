To use this module, you need to:

Have an email address in your main company. It will be used as sender
address.

Complete the contact form on the website and send it to us.
