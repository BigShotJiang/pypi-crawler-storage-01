# CHANGELOG

<!-- version list -->

## v1.5.2 (2025-08-02)

### Bug Fixes

- Add info pour reculer version, et rattrapper PyPI
  ([`9b26291`](https://github.com/PyMoX-fr/GC7/commit/9b262919822576c5ec977d6b36c1a3cd6b97f23b))


## v1.5.1 (2025-08-02)

### Bug Fixes

- Nett hello()
  ([`cad06f2`](https://github.com/PyMoX-fr/GC7/commit/cad06f2bb44b88c50a3d5a4bbbd618c006ea6351))


## v1.3.0 (2025-08-02)

### Features

- Add commits semmantic
  ([`18e7f58`](https://github.com/PyMoX-fr/GC7/commit/18e7f5844cb7329dd7641f70a9bad525f3fb877b))


## v1.2.0 (2025-08-02)


## v1.1.29 (2025-08-02)

### Bug Fixes

- Try to get the last tag number
  ([`58bdee2`](https://github.com/PyMoX-fr/GC7/commit/58bdee29e39db5c018d67cf656d072dccf0deb2d))


## v1.1.28 (2025-08-02)


## v1.1.27 (2025-08-02)


## v1.1.26 (2025-08-02)

### Bug Fixes

- New final setting workflow
  ([`72ee466`](https://github.com/PyMoX-fr/GC7/commit/72ee46623e33fd9987efeca4c24340944ef354d0))


## v1.1.25 (2025-08-02)

### Bug Fixes

- Try lunch with py instead twine
  ([`cccb993`](https://github.com/PyMoX-fr/GC7/commit/cccb993b6728f05d2d50e4605ef5bf80b504fde3))


## v1.1.24 (2025-08-02)


## v1.1.23 (2025-08-02)

### Bug Fixes

- Set final good workflow
  ([`b8bc0b3`](https://github.com/PyMoX-fr/GC7/commit/b8bc0b3d5ddfbd9f81ba435a78b01765efcfd73a))


## v1.1.22 (2025-08-02)

### Bug Fixes

- V+1 ([`5d6774b`](https://github.com/PyMoX-fr/GC7/commit/5d6774b5860723d43884f037ed960787c511a20b))


## v1.1.21 (2025-08-02)

### Bug Fixes

- V+ ([`2e78beb`](https://github.com/PyMoX-fr/GC7/commit/2e78bebaa01a7f98202c389b7fc7f0622b64edcd))


## v1.1.20 (2025-08-02)

### Bug Fixes

- Up v
  ([`3dc52f7`](https://github.com/PyMoX-fr/GC7/commit/3dc52f7e269d37945b5b6cc329e3899dc3ceaeab))


## v1.1.19 (2025-08-02)

### Bug Fixes

- Just a chg for PyPI process
  ([`07f15c8`](https://github.com/PyMoX-fr/GC7/commit/07f15c8a9b16b511587f291611d3bc0d56381033))


## v1.1.18 (2025-08-02)

### Bug Fixes

- Deactive_version writing
  ([`a9a2ec3`](https://github.com/PyMoX-fr/GC7/commit/a9a2ec32f1aba2cf772f3c9afa3671c151cd5db1))


## v1.1.17 (2025-08-02)


## v1.1.16 (2025-08-02)

### Bug Fixes

- Add_script to compare GH and local keys
  ([`5679a74`](https://github.com/PyMoX-fr/GC7/commit/5679a74d952d48ba605c1ce20f6c5b0f577943d4))


## v1.1.15 (2025-08-02)

### Bug Fixes

- Add CHANLOG to GI
  ([`d7a920f`](https://github.com/PyMoX-fr/GC7/commit/d7a920f26096710c4a8a8b9dbab07aca92871220))


## v1.1.14 (2025-08-02)


## v1.1.13 (2025-08-02)


## v1.1.12 (2025-08-02)

### Bug Fixes

- Upgrade hello()
  ([`b333205`](https://github.com/PyMoX-fr/GC7/commit/b33320536e5b7f86255e06fa3c0f2809615ffa04))


## v1.1.11 (2025-08-02)

### Bug Fixes

- Better presentation in hello()
  ([`ad588ed`](https://github.com/PyMoX-fr/GC7/commit/ad588ed7e348328fefc2cbbb5ffdf2666868271f))


## v1.1.10 (2025-08-02)

### Bug Fixes

- Set new settings for PyPI
  ([`213e19a`](https://github.com/PyMoX-fr/GC7/commit/213e19a668d2025274eac472e8e707dd866a5718))


## v1.1.9 (2025-08-02)


## v1.1.7 (2025-08-02)

### Bug Fixes

- Remove unused number commit in toml
  ([`0f0d9ef`](https://github.com/PyMoX-fr/GC7/commit/0f0d9efa4de6946e82af32ef0d94db0198e79866))


## v1.1.6 (2025-08-02)

### Bug Fixes

- Try an old semantic version
  ([`fa19f5a`](https://github.com/PyMoX-fr/GC7/commit/fa19f5adf660dc10f8802a99c7fda1e9c38e4103))


## v1.1.5 (2025-08-02)

### Bug Fixes

- Use .env
  ([`5ba4d92`](https://github.com/PyMoX-fr/GC7/commit/5ba4d92ee7de8a043b3ff169820a489ac210247a))


## v1.1.4 (2025-08-02)

### Bug Fixes

- Version number without v for PyPI
  ([`cb38e00`](https://github.com/PyMoX-fr/GC7/commit/cb38e00f826bedf52017c6291b1485886c02d8a3))


## v1.1.3 (2025-08-02)

### Bug Fixes

- Up version number call
  ([`f0578da`](https://github.com/PyMoX-fr/GC7/commit/f0578dad152c4e95a035e49794f9dd1b71da5199))


## v1.1.2 (2025-08-02)

### Bug Fixes

- Nett CHANGELOG
  ([`79d21fa`](https://github.com/PyMoX-fr/GC7/commit/79d21fa632c60d5fce780a56777d0038925d9258))


## v1.1.1 (2025-08-02)
### Bug Fixes

## v1.1.0 (2025-08-02)


## v1.0.0 (2025-08-02)

### Bug Fixes

- Better presentation of version
  ([`8a03512`](https://github.com/PyMoX-fr/GC7/commit/8a035121f7107e61fd2e511bdf4b227b44fcc91a))

- Set toml & yml for creating tag
  ([`03cffe2`](https://github.com/PyMoX-fr/GC7/commit/03cffe28876357bfb5a3c8e93a81abc6adbd9100))


## v0.1.1 (2025-08-02)

### Bug Fixes

- Activate tag
  ([`48a0f68`](https://github.com/PyMoX-fr/GC7/commit/48a0f688e287d994e13233305538906844377bd8))

- DÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©clenchement automatique de la release
  ([`7553e8a`](https://github.com/PyMoX-fr/GC7/commit/7553e8a3105f5e0792d20c922e89e22fbf217838))

- DÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©clenchement de la release 1.0.1
  ([`57079c0`](https://github.com/PyMoX-fr/GC7/commit/57079c039fc962e939208413e1fc6fed0b1c1530))

- For devS
  ([`79a535f`](https://github.com/PyMoX-fr/GC7/commit/79a535f947d2decb3596392b9a79d97c10b36def))

- Nett
  ([`5fca5d0`](https://github.com/PyMoX-fr/GC7/commit/5fca5d0c26f3f772790f17ceda3a6ba8e91e8913))

- Reset CHANGELOG
  ([`79ddd8b`](https://github.com/PyMoX-fr/GC7/commit/79ddd8beda2bd4a6a68e1c452b2468a774e57482))

- Toml
  ([`963ce58`](https://github.com/PyMoX-fr/GC7/commit/963ce58e8ec21832eb94c76f2c87b857651b1396))

- Up toml 2
  ([`7515d5e`](https://github.com/PyMoX-fr/GC7/commit/7515d5e94a851513c9f92e220b60a2db7eeb2d6f))

- Upgrade yaml
  ([`788257b`](https://github.com/PyMoX-fr/GC7/commit/788257bc3743a99e12dfee6d0f89b7388fb3334f))

- Uppercase for gc7
  ([`439f2f6`](https://github.com/PyMoX-fr/GC7/commit/439f2f65947feb1f0bd6bc9ba469dcc4a8b87792))

- Version notation
  ([`5b139b3`](https://github.com/PyMoX-fr/GC7/commit/5b139b323b9eb6b80146d1c53f36f9cb17cf6ff6))

### Chores

- **release**: Version 1.0.0
  ([`5617492`](https://github.com/PyMoX-fr/GC7/commit/561749227baef0f221b3652f55e6140d63e3d169))

- **release**: Version 1.1.0
  ([`59b58e3`](https://github.com/PyMoX-fr/GC7/commit/59b58e3149d7b95b401b270ef790621fa3a71b7c))

### Features

- Add dummy feature for version bump
  ([`783515c`](https://github.com/PyMoX-fr/GC7/commit/783515ca0983143a54acccc2f3736ff6e6b7b9ac))

- Add dummy feature for version bump
  ([`f2a217c`](https://github.com/PyMoX-fr/GC7/commit/f2a217cf1a1b167c5356d3f55a2b24cb041db26f))

- Add dummy feature for version bump
  ([`1752a64`](https://github.com/PyMoX-fr/GC7/commit/1752a64d62018ba0fcfb4038709b3e04089ee0fb))

- First result for version auto
  ([`b4b6eca`](https://github.com/PyMoX-fr/GC7/commit/b4b6eca6de759b252f4887e95547f836e879b306))

- New process for version
  ([`8c3bb4d`](https://github.com/PyMoX-fr/GC7/commit/8c3bb4d9c569ddd77e8d9aa5dffadf848ad735f0))

- Une release avec semantic-release
  ([`5be9b1d`](https://github.com/PyMoX-fr/GC7/commit/5be9b1d90f8b2ac4b8aba3e2d49fc58a762cb76d))

- Upgrade version
  ([`c533da5`](https://github.com/PyMoX-fr/GC7/commit/c533da54b3ee4db9d758b3c1454097d9d2586692))


## v0.1.0 (2025-08-01)

- Initial Release
