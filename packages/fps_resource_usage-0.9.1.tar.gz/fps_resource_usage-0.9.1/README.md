# fps-resource-usage

An FPS plugin for the resource usage API.
