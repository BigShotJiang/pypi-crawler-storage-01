# ypywidgets-textual

Textual widgets for ypywidgets
