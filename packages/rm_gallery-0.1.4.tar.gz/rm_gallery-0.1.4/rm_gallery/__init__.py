from rm_gallery.core.utils.logger import init_logger

from .gallery import *

init_logger()
