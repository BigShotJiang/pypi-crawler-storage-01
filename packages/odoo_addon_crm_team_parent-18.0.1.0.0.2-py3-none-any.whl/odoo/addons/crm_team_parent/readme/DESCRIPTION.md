This module adds a 'Parent Team' field on the Sales Team form. This
field is also displayed in the Sales Teams list. Plus, a constraint
check is performed in order to avoid loops in the hierarchy.
