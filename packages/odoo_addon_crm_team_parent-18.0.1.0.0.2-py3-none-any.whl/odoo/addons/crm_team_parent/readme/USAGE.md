To use this module, you need to:

1.  Go to *CRM \> Configuration \> Sales Teams*.
2.  Create/edit a sales team.
3.  The parent team will be checked for loop in the hierarchy.
