# tenex

The better way to handle ndarray and train model.
