__all__ = ["DType"]


class DType:
    pass
