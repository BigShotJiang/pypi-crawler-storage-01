class TopicNotFound(Exception):
    pass

class EventBusClientNotConnected(Exception):
    pass

class EventHandlerNotFound(Exception):
    pass