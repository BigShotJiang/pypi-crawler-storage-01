from setuptools import setup
 
setup(
    name='get_handling_prompt',
    version='1.0',
    py_modules=['get_handling_prompt',],
    author='0xng',
    author_email='anquan@163.com',
    description='test',
    long_description='test',
    long_description_content_type='text/markdown',
    url='',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)