#!/bin/bash

pytest Test/