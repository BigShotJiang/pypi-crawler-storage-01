Rule
====