# flake8: noqa
from wefe.datasets.datasets import (
    fetch_debias_multiclass,
    fetch_debiaswe,
    fetch_eds,
    fetch_gn_glove,
    load_bingliu,
    load_weat,
)
