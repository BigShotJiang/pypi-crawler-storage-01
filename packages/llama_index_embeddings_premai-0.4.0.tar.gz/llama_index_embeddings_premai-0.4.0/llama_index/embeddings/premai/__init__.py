from llama_index.embeddings.premai.base import PremAIEmbeddings

__all__ = ["PremAIEmbeddings"]
