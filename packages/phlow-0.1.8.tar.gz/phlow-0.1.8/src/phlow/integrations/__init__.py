"""Framework integrations for Phlow authentication."""

# Framework integrations are optional and imported as needed
