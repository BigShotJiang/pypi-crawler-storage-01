This module add default values to contract products for variable
quantity formula.
