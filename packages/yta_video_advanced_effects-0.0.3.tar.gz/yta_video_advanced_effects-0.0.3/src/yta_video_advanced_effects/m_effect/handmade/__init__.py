"""
TODO: These effects are here by now
because I build them by hand, step by
step, and I set the class. Maybe we
can mix them with the other effects
or maybe not, but for now they are
here to know they are 'different'.
"""