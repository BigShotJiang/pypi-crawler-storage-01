"""
Welcome to Youtube Autonomous Advanced
Video Effects Module.
"""
