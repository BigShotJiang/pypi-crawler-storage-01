"""
TODO: By now I'm keeping this 'filters'
module instead of creating a new
'yta_video_advanced_filters' library
because the code we have related to
filters is not huge and its not clear
nor definitive. This is temporary, I
think I will move it to that new
library in a near future.
"""