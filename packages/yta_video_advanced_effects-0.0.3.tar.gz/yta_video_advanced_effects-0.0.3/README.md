# Youtube Autonomous Advanced Video Effects Module

The Youtube Autonomous Advanced Video Effects module.

Please, check the 'pyproject.toml' file to see the dependencies.
