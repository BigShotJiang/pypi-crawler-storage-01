"""Envoy External Processor for LangGate."""
