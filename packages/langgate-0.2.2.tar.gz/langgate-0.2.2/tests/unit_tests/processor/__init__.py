"""Unit tests for processor module."""
