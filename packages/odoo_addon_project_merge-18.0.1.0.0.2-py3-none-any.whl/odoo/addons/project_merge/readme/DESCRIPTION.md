This module adds a wizard to merge project tasks.

A wizard that can be called from tree view of project task.
