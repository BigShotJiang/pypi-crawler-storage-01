MIT License

Copyright (c) 2025 Your Name

Permission is hereby granted, free of charge...