niamoto.core.plugins.widgets package
====================================

Submodules
----------

niamoto.core.plugins.widgets.base module
----------------------------------------

.. automodule:: niamoto.core.plugins.widgets.base
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.widgets.charts module
------------------------------------------

.. automodule:: niamoto.core.plugins.widgets.charts
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: niamoto.core.plugins.widgets
   :members:
   :show-inheritance:
   :undoc-members:
