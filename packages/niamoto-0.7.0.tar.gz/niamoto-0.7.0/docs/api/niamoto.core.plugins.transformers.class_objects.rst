niamoto.core.plugins.transformers.class\_objects package
========================================================

Submodules
----------

niamoto.core.plugins.transformers.class\_objects.binary\_aggregator module
--------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.binary_aggregator
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.class\_objects.categories\_extractor module
-----------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.categories_extractor
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.class\_objects.categories\_mapper module
--------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.categories_mapper
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.class\_objects.field\_aggregator module
-------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.field_aggregator
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.class\_objects.series\_by\_axis\_extractor module
-----------------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.series_by_axis_extractor
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.class\_objects.series\_extractor module
-------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.series_extractor
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.class\_objects.series\_matrix\_extractor module
---------------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.series_matrix_extractor
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.class\_objects.series\_ratio\_aggregator module
---------------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.class_objects.series_ratio_aggregator
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: niamoto.core.plugins.transformers.class_objects
   :members:
   :show-inheritance:
   :undoc-members:
