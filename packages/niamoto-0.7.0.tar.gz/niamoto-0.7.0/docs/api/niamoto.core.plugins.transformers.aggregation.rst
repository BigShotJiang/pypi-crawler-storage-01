niamoto.core.plugins.transformers.aggregation package
=====================================================

Submodules
----------

niamoto.core.plugins.transformers.aggregation.binary\_counter module
--------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.aggregation.binary_counter
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.aggregation.field\_aggregator module
----------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.aggregation.field_aggregator
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.aggregation.statistical\_summary module
-------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.aggregation.statistical_summary
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.aggregation.top\_ranking module
-----------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.aggregation.top_ranking
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: niamoto.core.plugins.transformers.aggregation
   :members:
   :show-inheritance:
   :undoc-members:
