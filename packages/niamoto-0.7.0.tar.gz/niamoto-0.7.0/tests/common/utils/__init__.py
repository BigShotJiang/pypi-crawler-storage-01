"""Tests for common utilities."""
