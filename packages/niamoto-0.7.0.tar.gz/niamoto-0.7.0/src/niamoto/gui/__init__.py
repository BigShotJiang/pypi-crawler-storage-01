"""GUI module for Niamoto - provides a visual configuration interface."""
