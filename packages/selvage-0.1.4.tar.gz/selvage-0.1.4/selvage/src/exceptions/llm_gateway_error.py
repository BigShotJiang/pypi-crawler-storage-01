"""
LLM 게이트웨이 관련 기본 예외 클래스 정의 모듈입니다.
"""


class LLMGatewayError(Exception):
    """LLM 게이트웨이 관련 기본 예외 클래스"""

    pass
