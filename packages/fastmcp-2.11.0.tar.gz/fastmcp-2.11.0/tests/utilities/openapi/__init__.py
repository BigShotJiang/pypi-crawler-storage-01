"""Tests for the OpenAPI utilities."""
