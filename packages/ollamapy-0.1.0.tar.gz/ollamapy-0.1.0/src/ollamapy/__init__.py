__version__ = "0.1.0"

from .main import hello, greet

__all__ = ["hello", "greet"]