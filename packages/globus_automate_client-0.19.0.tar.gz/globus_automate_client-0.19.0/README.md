> [!CAUTION]
> The code in this repository was deprecated January 2024 and is now end-of-life. 
> Please use the [globus-sdk](https://github.com/globus/globus-sdk-python) and the [globus-cli](https://github.com/globus/globus-cli) as replacments. 
> For more information, reference the [migration guide](https://globus-automate-client.readthedocs.io/en/latest/migration.html).
