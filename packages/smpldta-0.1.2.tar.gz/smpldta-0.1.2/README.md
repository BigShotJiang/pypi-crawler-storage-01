# 📦 smpldta — Sample Data Fetcher

**smpldta** is a Python library to fetch and generate real sample data like images, videos, gifs, code, JSON, text files, and PDFs — in any quantity you specify.

It helps developers, testers, and data scientists quickly build test environments, validate pipelines, or create dummy data for demos, machine learning, or automation.

---

## 🚀 Features

- 📸 Download real images from the web with size/dimension constraints
- 🎥 Fetch videos in multiple formats like `mp4`, `mkv`, `flv`, `3gp`
- 🎞️ Get animated GIFs from Giphy
- 📄 Generate PDFs with size limits
- 📁 Create structured JSON files with a schema
- 💬 Generate random text files with word/size limits
- 💻 Generate code files in Python, Java, JavaScript, C, etc.


---
# 📦 smpldta

`smpldta` is a Python-based utility that generates sample data files for testing and prototyping. It supports fetching images, videos, code snippets, text, JSON, and PDFs—organized in a clear directory structure.

---

## 📚 Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
  - [🖼️ fetch_images(config)](#️-fetch_imagesconfig)
  - [🎥 fetch_videos(config)](#-fetch_videosconfig)
  - [🎞️ fetch_gifs(count)](#-fetch_gifscount)
  - [💻 fetch_code(config)](#-fetch_codeconfig)
  - [📝 fetch_text(config)](#-fetch_textconfig)
  - [🧾 fetch_json(config)](#-fetch_jsonconfig)
  - [📄 fetch_pdfs(config)](#-fetch_pdfsconfig)
- [📂 Output Structure](#-output-structure)
- [💡 Why Use smpldta?](#-why-use-smpldta)
- [📄 License](#-license)

---

## 🛠️ Installation

```bash
pip install smpldta
```

---


### 🖼️ fetch_images(config)

```python
config = {
    "jpg": {
        "count": 3,
        "min_size": "5kb",
        "max_size": "500kb",
        "height": 400,
        "width": 400
    },
    "jpeg": {
        "count": 2,
        "min_size": "10kb",
        "max_size": "1mb",
        "height": 600,
        "width": 300
    }
}
fetcher.fetch_images(config, subdir="name_of_the_folder")
```

---

### 🎥 fetch_videos(config)

```python
config = {
    "mp4": {
        "count": 3,
        "max_size": "20mb"
    },
    "3gp": {
        "count": 2,
        "max_size": "10mb"
    }
}
fetcher.fetch_videos(config)
```

---

### 🎞️ fetch_gifs(count)

```python
fetcher.fetch_gifs(count=5)
```

---

### 💻 fetch_code(config)

```python
config = {
    "python": 2,
    "java": 2,
    "c": 1,
    "cpp": 1,
    "javascript": 1,
    "typescript": 1
}
fetcher.fetch_code(config)
```

---

### 📝 fetch_text(config)

```python
config = {
    "count": 4,
    "min_words": 100,
    "max_words": 1000,
    "max_size": "200kb"
}
fetcher.fetch_text(config)
```

---

### 🧾 fetch_json(config)

```python
config = {
    "schema": {
        "id": "uuid",
        "name": "str",
        "email": "email",
        "age": "int",
        "joined": "date",
        "score": "float"
    },
    "min_data_per_file": 5,
    "max_data_per_file": 15,
    "count": 5
}
fetcher.fetch_json(config)
```

---

### 📄 fetch_pdfs(config)

```python
config = {
    "count": 3,
    "min_size": "100kb",
    "max_size": "500kb"
}
fetcher.fetch_pdfs(config)
```

---

## 📂 Output Structure

```
output/
├── images/
├── videos/
├── gifs/
├── code/
├── text/
├── json/
└── pdfs/
```

Each data type is saved in its own subfolder with unique filenames.

To change the names of the folder use this
```
subdir="name_of_the_folder"

Example:
fetcher.fetch_images(config, subdir="name_of_the_folder")
```

---

## 💡 Why Use smpldta?

- Eliminate the need to manually source or generate test data
- Supports a variety of formats and customization options
- Ideal for pipelines, automated tests, and demos

---

## 📄 License

MIT License

Author: Parteek