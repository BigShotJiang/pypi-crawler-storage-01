//! Standalone documentation pages.
//!
//! # Examples
//!
//! Some add
