//! Define a calendar which asserts every possible date as a business day.

pub const WEEKMASK: &[u8] = &[]; // all days are weekdays

// pub const RULES: &[&str] = &[];

pub const HOLIDAYS: &[&str] = &[]; // no specific holidays
