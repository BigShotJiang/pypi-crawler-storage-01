This 'src' directory contains the rust implementation of rateslib. The "rateslibrs" elements.
Some configuration is available from the "cargo.toml" file.

Rust tests are contained in the "tests" subfolder and are executed with >$ cargo test.

This package has a library --lib and a binary called "rateslibrs" defined by toml.
To call otehr files in the bin use --bin scratch, for example,
