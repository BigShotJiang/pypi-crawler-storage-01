This module allows the configuration of the fields "Address", "Port",
"User" and "Password" on Printing Server from server environment.
