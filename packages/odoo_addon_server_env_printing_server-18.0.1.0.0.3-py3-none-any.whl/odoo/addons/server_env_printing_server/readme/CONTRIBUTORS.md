- Patrick Tombez \<<patrick.tombez@camptocamp.com>\>

- [Trobz](https://trobz.com):  
  - nguyenhk \<<nguyenhk@trobz.com>\>
