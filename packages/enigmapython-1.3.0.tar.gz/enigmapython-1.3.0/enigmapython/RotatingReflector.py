from .Rotor import Rotor

class RotatingReflector(Rotor):
    None