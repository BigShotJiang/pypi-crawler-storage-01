.. _examples:

Examples
============

Here is a list of example notebooks to illustrate how to use earthkit.


.. toctree::
    :maxdepth: 1


    polytope_polygon.ipynb
    polytope_polygon_logo.ipynb
    polytope_timeseries.ipynb
    polytope_vertical_profile.ipynb
