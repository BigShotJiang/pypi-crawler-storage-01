from .Prihops import topla, fark

__all__ = ["topla", "fark"]
