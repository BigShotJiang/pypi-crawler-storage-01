def topla(x, y):
    return x + y

def fark(x, y):
    return x - y
