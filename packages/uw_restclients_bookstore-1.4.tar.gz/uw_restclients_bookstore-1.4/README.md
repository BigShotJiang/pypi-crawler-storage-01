# REST client for the UW Bookstore Web Service

[![Build Status](https://github.com/uw-it-aca/uw-restclients-bookstore/workflows/tests/badge.svg)](https://github.com/uw-it-aca/uw-restclients-bookstore/actions)
[![Coverage Status](https://coveralls.io/repos/uw-it-aca/uw-restclients-bookstore/badge.svg?branch=main)](https://coveralls.io/r/uw-it-aca/uw-restclients-bookstore?branch=main)
[![PyPi Version](https://img.shields.io/pypi/v/uw-restclients-bookstore.svg)](https://pypi.python.org/pypi/uw-restclients-bookstore)
![Python versions](https://img.shields.io/pypi/pyversions/uw-restclients-bookstore.svg)

Installation:

    pip install UW-RestClients-Bookstore
