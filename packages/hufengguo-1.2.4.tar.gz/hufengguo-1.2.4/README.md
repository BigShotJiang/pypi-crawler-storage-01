# 扩展库介绍

这是中国传媒大学胡凤国老师上课分享的自定义函数库，其中包含几个常用的文本处理函数。发布本扩展库主要是方便上课学生练习Python程序，顺便分享给其他需要的Pythoner。

刚学会发布扩展库，PyPI很多东西还不熟，如有问题，请多提宝贵意见。


# 安装说明

pip install hufengguo


# 用法说明

具体用法见胡凤国老师的上课教材：《Python程序设计（基于计算思维和新文科建设）》，ISBN：9787121435577，胡凤国，电子工业出版社，2022年6月。

这里举一些简单的例子。


## 产生1到100之内的素数

```
from hufengguo import isprime
x = [i for i in range(101) if isprime(i)]
print(x)
```

## 去掉多行文本中的空白行和每行首尾空白符

```
s = " 12345\t\n  上山打老虎\n \n\n"
t = remove_white_from_text(s)
print("字符串s：", "-"*20, s, "-"*20, "\n字符串t：", "-"*20, t, "-"*20, sep="\n")
```

## 调用jieba扩展库对一个文本文件进行分词和词性标注，自动适应各种编码的文本文件

```
from hufengguo import segtag_by_jieba
segtag_by_jieba(r"in.txt", r"out.txt")
```
如果是分词且词性标注，可以导入 lseg_str_by_jieba 函数。

## 调用jieba扩展库对一个目录及子目录下的文本文件进行分词和词性标注

```
from hufengguo import my_path2path, segtag_by_jieba
my_path2path(r"in", [".txt"], r"out", segtag_by_jieba)
```
