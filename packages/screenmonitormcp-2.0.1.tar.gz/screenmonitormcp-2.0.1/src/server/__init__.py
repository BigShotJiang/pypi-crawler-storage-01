"""Server components for ScreenMonitorMCP v2."""
