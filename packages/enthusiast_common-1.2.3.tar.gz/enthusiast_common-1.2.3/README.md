# Enthusiast Common

This package includes interface definitions for developing plugins for Enthusiast.