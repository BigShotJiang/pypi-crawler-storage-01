# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-08-03)

### Bug Fixes

- V1 ([`4de0247`](https://github.com/PyMoX-fr/GC7/commit/4de0247dfbb30c282ced05bbe336ca893f38618d))

- V1 enfin
  ([`1c9bd40`](https://github.com/PyMoX-fr/GC7/commit/1c9bd40eb1367402bf7eb2f1e4cdbeb5300a4ceb))


## v0.0.0 (2025-08-03)

- Initial Release
