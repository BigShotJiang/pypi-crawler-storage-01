DEFAULT_TEMPERATURE = 0.7
DEFAULT_LLM_MODEL = "gpt-4.1-nano"
DEFAULT_MODE = "simple"  # Default optimization mode
SUPPORTED_LLM_MODELS = ["gpt-4.1-nano", "gpt-4.1-mini", "gpt-4.1"]
