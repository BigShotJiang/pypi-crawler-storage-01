# hwc

This package offers high level interfaces and implementations to simplify 
communication with input output devices. 

