"""Unit tests for template module."""


def test_template():
    """Test nothing - stub for test runner.

    Test should be added in the future.

    """
    assert True
