class Img:
    def __init__(self, src, *, alt="", width=None, height=None):
        self.src = src
        self.alt = alt
        self.width = width
        self.height = height
