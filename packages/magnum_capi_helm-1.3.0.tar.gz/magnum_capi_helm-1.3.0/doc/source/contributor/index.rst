=================
Contributor Guide
=================

DevStack Setup
==============

Did you want to try this driver in DevStack?
Please try the setup script which is included in the repo
`here <https://opendev.org/openstack/magnum-capi-helm/src/branch/master/devstack/contrib/new-devstack.sh>`_.

The above DevStack script will also install k3s on the host and will
install the required components on the k3s cluster for it to act as a
Cluster API management cluster.
