===============================
Magnum CAPI Common
===============================

There are two magnum drivers using Cluster API.
Ideally we would both build on a common shared code,
ideally within the Magnum tree.

Some code and some ideas for these utilities come
from this alternative Apache2 licensed driver:
https://github.com/vexxhost/magnum-cluster-api

This is structured to make it easier for us to
work out how to share some of this code
