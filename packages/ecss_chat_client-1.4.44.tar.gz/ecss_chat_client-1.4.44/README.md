# ECSS Chat Client

Python клиент для работы с ECSS Chat.

## Установка

```bash
pip install ecss-chat-client
```

## GetStarted

```python
from ecss_chat_client import Client
```