# pynuvo
Python3 interface implementation for "simple" Nuvo zone amplifiers
Supports Essentia D, Simplese, and Concerto models

## Notes
This is for use with [Home-Assistant](http://home-assistant.io)

## Usage
```python

```
