"""Contains implementations of portia specific logic for SteelThread."""
