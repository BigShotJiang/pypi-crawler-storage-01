"""Contains implementations of offline evals for SteelThread."""
