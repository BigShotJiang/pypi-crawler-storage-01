"""Contains common implementations for SteelThread."""
