"""Version information for hyperliquid-mcp package."""

__version__ = "0.1.0"