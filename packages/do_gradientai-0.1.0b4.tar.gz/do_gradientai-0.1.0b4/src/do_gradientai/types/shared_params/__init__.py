# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .firewall_rule_target import FirewallRuleTarget as FirewallRuleTarget
