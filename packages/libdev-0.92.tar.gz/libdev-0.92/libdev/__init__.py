"""
Initializing the Python package
"""

__version__ = "0.92"

__all__ = ("__version__",)
