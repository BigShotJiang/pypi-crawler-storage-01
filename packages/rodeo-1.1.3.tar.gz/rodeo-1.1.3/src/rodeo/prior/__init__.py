from rodeo.prior.ibm import ibm_init
from rodeo.prior.indep_init import indep_init
