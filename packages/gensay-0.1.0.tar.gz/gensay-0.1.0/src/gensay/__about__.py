# SPDX-FileCopyrightText: 2025-present Anthony Wu <pls-file-gh-issue@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.0"
