==========================
 Invenio-GitHub v1.0.0a28
==========================

Invenio-GitHub v1.0.0a28 was released on October 24, 2022.

About
-----

Invenio module that adds GitHub integration to the platform.

*This is an experimental developer preview release.*

What's new
----------

- Initial public release.

Installation
------------

   $ pip install invenio-github==v1.0.0a28

Documentation
-------------

   http://invenio-github.readthedocs.io/

Happy hacking and thanks for flying Invenio-GitHub.

| Invenio Development Team
|   Email: info@inveniosoftware.org
|   IRC: #invenio on irc.freenode.net
|   Twitter: http://twitter.com/inveniosoftware
|   GitHub: https://github.com/inveniosoftware/invenio-github
|   URL: http://inveniosoftware.org
