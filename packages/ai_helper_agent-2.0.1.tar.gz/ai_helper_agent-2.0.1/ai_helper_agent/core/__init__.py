"""Core functionality for AI Helper Agent."""
