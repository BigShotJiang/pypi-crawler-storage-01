"""Manager classes for AI Helper Agent."""
