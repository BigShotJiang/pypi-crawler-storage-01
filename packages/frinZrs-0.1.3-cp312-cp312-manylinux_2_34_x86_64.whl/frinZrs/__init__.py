from .frinZrs import *

__doc__ = frinZrs.__doc__
if hasattr(frinZrs, "__all__"):
    __all__ = frinZrs.__all__