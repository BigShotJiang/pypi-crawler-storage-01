"""Modules with base orthoseg functionalities."""
