from .widget import SimpleLabel
from .image import ImageLabel


__all__ = ["SimpleLabel", "ImageLabel"]