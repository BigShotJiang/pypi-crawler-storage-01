from __future__ import annotations


def run():
    print("magic")  # noqa: T201


if __name__ == "__main__":
    run()
