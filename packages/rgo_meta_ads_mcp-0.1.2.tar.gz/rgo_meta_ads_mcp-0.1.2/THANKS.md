# Thanks

Special thanks to **Yves Junqueira** for creating the original version of this project. This fork, rgo-meta-ads-mcp, is based on his excellent work.

- Original Author: Yves Junqueira
- Maintainer & Publisher: Praveen Yadav 