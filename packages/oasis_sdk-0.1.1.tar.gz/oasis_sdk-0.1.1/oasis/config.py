import os

DEFAULT_PROXY_URL = "http://172.16.57.60:30900/oasis/proxy"