sage-setup: Build system of the SageMath library
================================================

This is the build system of the Sage library, based on setuptools.
