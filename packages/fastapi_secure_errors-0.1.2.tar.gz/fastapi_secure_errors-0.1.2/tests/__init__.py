# Tests for fastapi-secure-errors package
