# __main__.py
"""Entry point for running the package as a module with python -m"""

if __name__ == "__main__":
    from .main import main

    main()
