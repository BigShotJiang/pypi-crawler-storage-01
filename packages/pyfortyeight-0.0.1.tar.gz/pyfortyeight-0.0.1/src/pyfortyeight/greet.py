

def welcome():
    print("Welcome to Python")