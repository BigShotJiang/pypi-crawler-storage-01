"""
colbertfinance - Librería de análisis financiero simple
"""
__version__ = "0.1.6"

from .simple import descargar_cierres, calcular_markowitz
