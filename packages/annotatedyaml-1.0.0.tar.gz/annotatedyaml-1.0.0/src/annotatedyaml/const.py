"""Constants."""

SECRET_YAML = "secrets.yaml"  # noqa: S105
