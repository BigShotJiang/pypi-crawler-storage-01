class Transform:
    def __init__(self, mode, source, destination):
        self.mode = mode
        self.source = source
        self.destination = destination

    def get_scripts(self):
        return []
