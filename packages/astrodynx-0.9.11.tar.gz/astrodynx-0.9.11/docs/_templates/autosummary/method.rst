{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}

.. container:: method-footer

   .. rubric:: Method Information

   **Class:** :class:`{{ module }}.{{ class_name }}`

   **Module:** :mod:`{{ module }}`
