{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}

.. autoattribute:: {{ objname }}

.. container:: attribute-footer

   .. rubric:: Attribute Information

   **Module:** :mod:`{{ module }}`
