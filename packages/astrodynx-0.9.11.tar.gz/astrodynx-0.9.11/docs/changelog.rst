.. _changelog:

Changelog
=========

.. meta::
   :http-equiv=refresh: 0;url=https://github.com/adxorg/astrodynx/releases

You will be automatically redirected to the `GitHub Releases <https://github.com/adxorg/astrodynx/releases>`_ page.
