"""Ramifice - Models."""
