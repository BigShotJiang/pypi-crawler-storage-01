# Changelog

## v0.0.2 / 2025-07-30

### Features

- [feature] Publish to PyPi (#16).

### Fixes

- [fix] Project description (#17).

## v0.0.1 / 2025-07-29

- First version, released on an unsuspecting world.
