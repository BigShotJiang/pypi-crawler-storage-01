"""Test suite for LMStrix."""
