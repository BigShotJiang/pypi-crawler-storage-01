# Copyright 2016 - 2023 Ternaris
# SPDX-License-Identifier: Apache-2.0
"""Command line interface definition."""

from __future__ import annotations

from .commands import command

COMMAND = command
