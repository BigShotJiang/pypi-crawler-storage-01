empty
=====
builtin_interfaces
******************
- :py:class:`Duration <rosbags.typesys.stores.empty.builtin_interfaces__msg__Duration>`
- :py:class:`Time <rosbags.typesys.stores.empty.builtin_interfaces__msg__Time>`
