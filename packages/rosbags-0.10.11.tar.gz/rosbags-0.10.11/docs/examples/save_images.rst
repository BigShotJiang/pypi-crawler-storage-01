Save images as rosbag
=====================

The following examples show how to create new ROS bags from images.


Save rosbag1
------------

.. literalinclude:: ./save_images_rosbag1.py


Save rosbag2
------------

.. literalinclude:: ./save_images_rosbag2.py
