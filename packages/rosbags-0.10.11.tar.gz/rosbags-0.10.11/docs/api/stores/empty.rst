rosbags.typesys.stores.empty
============================

.. automodule:: rosbags.typesys.stores.empty
   :members:
   :show-inheritance: