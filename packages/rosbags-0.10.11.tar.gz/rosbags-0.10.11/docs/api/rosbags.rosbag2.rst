rosbags.rosbag2
===============

.. automodule:: rosbags.rosbag2
   :members:
   :show-inheritance:
