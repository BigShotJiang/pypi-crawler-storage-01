rosbags.serde
=============

.. automodule:: rosbags.serde
   :members:
   :show-inheritance: