Thank you for your interest in contributing to Rosbags.

Please note that this repository serves as a publish-only mirror.

For contributing, kindly utilize the primary GitLab project and ensure to review the contribution guide beforehand.

Primary GitLab Project: https://gitlab.com/ternaris/rosbags
Contribution Guide: https://gitlab.com/ternaris/rosbags/-/blob/master/CONTRIBUTING.rst
