from django.apps import AppConfig


class ItemListConfig(AppConfig):
    name = 'itemlist'
