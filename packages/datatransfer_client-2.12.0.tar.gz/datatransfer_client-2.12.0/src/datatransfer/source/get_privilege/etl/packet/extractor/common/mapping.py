# coding: utf-8

from __future__ import absolute_import

from datatransfer.source.common.configuration import get_object


rules = get_object("get_privilege_mapping_rules")
privilege_mapping = get_object("get_privilege_mapping")
