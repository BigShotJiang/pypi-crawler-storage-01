# coding: utf-8

PERSON_TYPE_PERSON = 1
PERSON_TYPE_DECLARATION = 2

# Тип обладателя льготы
CHILD_HOLDER_TYPE = 1