# coding: utf-8

from __future__ import absolute_import

from datatransfer.source.common.configuration import get_object


rules = get_object("enroll_get_data_mapping_rules")
