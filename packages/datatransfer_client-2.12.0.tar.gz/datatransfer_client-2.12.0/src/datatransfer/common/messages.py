# coding: utf-8

CONFIGURATION_NOT_EXISTS = (
    u"Configuration path ({0}) not exist")
