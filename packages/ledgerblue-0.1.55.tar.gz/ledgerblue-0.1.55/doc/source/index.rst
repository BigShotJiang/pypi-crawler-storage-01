BOLOS Python Loader
===================

The BOLOS Python loader is a Python library and collection of scripts for
interfacing with and managing BOLOS devices from a host computer. See the
`Python loader GitHub repository
<https://github.com/LedgerHQ/blue-loader-python>`_ for download and installation
instructions.

.. toctree::
   :maxdepth: 1

   scripts
   script_reference
