﻿# rdvt-s3storage

This is a placeholder package to reserve the name dvt-s3storage and prevent dependency confusion attacks.

Do not install or use this package.
