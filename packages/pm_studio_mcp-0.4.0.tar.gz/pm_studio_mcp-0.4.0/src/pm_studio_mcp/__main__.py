from pm_studio_mcp import main

main()
