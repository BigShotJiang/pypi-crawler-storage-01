Reference
=========

Reference for the YTMusic class.


.. toctree::

   ytmusic
   setup
   search
   browsing
   explore
   watch
   library
   playlists
   podcasts
   uploads
   api/modules
