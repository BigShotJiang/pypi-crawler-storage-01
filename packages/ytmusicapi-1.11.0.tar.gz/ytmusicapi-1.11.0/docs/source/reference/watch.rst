Watch
--------

.. currentmodule:: ytmusicapi
.. automethod:: YTMusic.get_watch_playlist
