
from setuptools import setup

setup(package_data={'RPi-stubs': ['GPIO/__init__.pyi', '__init__.pyi', 'METADATA.toml', 'py.typed']})
