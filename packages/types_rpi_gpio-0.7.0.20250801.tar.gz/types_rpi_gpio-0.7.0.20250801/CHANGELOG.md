## 0.7.0.20250801 (2025-08-01)

Split `tool.stubtest.platforms` metadata key (#13746)

Co-authored-by: Avasam <samuel.06@hotmail.com>
Co-authored-by: pre-commit-ci[bot] <66853113+pre-commit-ci[bot]@users.noreply.github.com>

## 0.7.0.20250318 (2025-03-18)

RPi.GPIO: Fix typo in name of `ChangeFrequency` method (#13634)

## 0.7.0.20240314 (2024-03-14)

[RPi.GPIO] General improvement of stubs. (#11516)

## 0.7.0.20240131 (2024-01-31)

Add stubs for RPi.GPIO (#11345)

