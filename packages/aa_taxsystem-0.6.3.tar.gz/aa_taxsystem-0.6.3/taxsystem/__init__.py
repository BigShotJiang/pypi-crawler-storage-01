"""Initialize the app"""

__version__ = "0.6.3"
__title__ = "Tax System"

__package_name__ = "aa-taxsystem"

__app_name_useragent__ = "AA-TaxSystem"
__github_url__ = f"https://github.com/Geuthur/{__package_name__}"
