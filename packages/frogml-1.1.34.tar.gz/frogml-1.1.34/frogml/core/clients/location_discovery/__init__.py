from .client import LocationDiscoveryClient
