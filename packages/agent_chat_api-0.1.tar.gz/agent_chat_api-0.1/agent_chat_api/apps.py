# package_c/package_c/apps.py
from django.apps import AppConfig

class AgentChatApiConfig(AppConfig):
    name = 'agent_chat_api'