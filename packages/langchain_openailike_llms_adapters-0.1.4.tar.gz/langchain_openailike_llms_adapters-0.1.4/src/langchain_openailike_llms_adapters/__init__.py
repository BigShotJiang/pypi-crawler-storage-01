from .adapters import get_openai_like_llm_instance


__all__ = ["get_openai_like_llm_instance"]

__version__ = "0.1.3"
