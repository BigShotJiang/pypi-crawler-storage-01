class RequestTypes:
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    GET = "GET"

    valid_types = [POST, PUT, PATCH, DELETE, GET]
