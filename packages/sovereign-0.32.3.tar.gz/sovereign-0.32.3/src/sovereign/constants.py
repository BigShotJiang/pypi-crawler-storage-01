TEMPLATE_CTX_PATH = ".sovereign_context.json"
