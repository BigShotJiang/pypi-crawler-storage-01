from setuptools import setup, find_packages

setup(
    name="totallysafe",
    version="2.0.1",
    packages=find_packages(),
    description="Totally safe package",
)