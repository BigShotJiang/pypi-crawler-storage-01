from maths_add.fraction import code
from maths_add.fraction import example_decimal
from maths_add.fraction import mode

hf = code.Hf()
