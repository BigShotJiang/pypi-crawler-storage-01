# DATAria Python Utils
This is a small Python package to distribute tailored functions for computational analyses in the GRACEFUL17 Project (DHI Rome)

Until proper package registration, use `pip install git+https://github.com/ch-sander/dataria-py-utils.git` and `import dataria`

See https://dataria-py-utils.readthedocs.io

Refer to by [![DOI](https://zenodo.org/badge/905857156.svg)](https://doi.org/10.5281/zenodo.15267861)
