from .namedLock import NamedLock as RMLock
from .namedLock import NamedLock as Lock
from .namedLock import NamedLock as RememoryLock

from .sharedBlock import RememoryBlock as RMBlock
from .sharedBlock import RememoryBlock as Block
from .sharedBlock import RememoryBlock
from .sharedBlock import BlockSize

from .sharedBool import RememoryBool as RMBool
from .sharedBool import RememoryBool as bool
from .sharedBool import RememoryBool

from .sharedDict import RememoryDict as RMDict
from .sharedDict import RememoryDict as Dict
from .sharedDict import RememoryDict

from .sharedFloat import RememoryFloat as RMFloat
from .sharedFloat import RememoryFloat as float
from .sharedFloat import RememoryFloat
from .sharedFloat import FloatTypes

from .sharedInt import RememoryInt as RMInt
from .sharedInt import RememoryInt as int
from .sharedInt import RememoryInt
from .sharedInt import IntTypes

from .sharedList import RememoryList as RMList
from .sharedList import RememoryList as List
from .sharedList import RememoryList

from .sharedString import RememoryString as RMString
from .sharedString import RememoryString as str
from .sharedString import RememoryString

