def hello(world):
    print("Hello, " + world)


if __name__ == "__main__":
    hello("world")
