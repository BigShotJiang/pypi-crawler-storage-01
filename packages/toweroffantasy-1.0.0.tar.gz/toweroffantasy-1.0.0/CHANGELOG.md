# Changelog

## 1.0.0 (2025-07-29)

Full Changelog: [v0.0.1-alpha.0...v1.0.0](https://github.com/biellSilva/toweroffantasy.sdk/compare/v0.0.1-alpha.0...v1.0.0)

### Chores

* update SDK settings ([b4e38aa](https://github.com/biellSilva/toweroffantasy.sdk/commit/b4e38aa15121a29fb3db017957449864f107eaeb))
