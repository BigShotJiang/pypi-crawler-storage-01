The files in this directory are appended to the CKAN main.css
(alongside some color modifications) and then combined into one
dcor_main.css file using the script `make_dcor_main_css.py` or
alternatively, using the command `ckan dcor-theme-main-css-branding`.
