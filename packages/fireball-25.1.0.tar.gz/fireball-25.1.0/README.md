# fireball

Built on [typer](https://github.com/fastapi/typer) to make binding & debugging easier.

## Install

```bash
pip install fireball
```

## Usage

Try it out.
