"""Module containing the version information for the project."""  # numpydoc ignore=EX01,ES01

__version__ = "0.5.1"
