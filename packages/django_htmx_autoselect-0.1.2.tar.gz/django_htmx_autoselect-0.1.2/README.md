# Django htmx autocomplete for select fields

A simple reusable Django app for displaying notifications.

## Installation

```bash
pip install django-htmx-autoselect
