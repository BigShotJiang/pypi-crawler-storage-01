# LlamaIndex Vector_Stores Integration: Gel
