import os
from schur import Schur

s = Schur()
s.test()