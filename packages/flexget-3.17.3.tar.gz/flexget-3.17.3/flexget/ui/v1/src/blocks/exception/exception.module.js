/* global angular */
(function () {
  'use strict';

  angular.module('blocks.exception', ['blocks.error']);
})();
