# name = "SimpySql"
# from .DBModel import DBModel
#
# __all__ = [
#     "DBModel",
# ]
