class DataException(Exception):
    pass


class DatatypeException(DataException):
    pass
