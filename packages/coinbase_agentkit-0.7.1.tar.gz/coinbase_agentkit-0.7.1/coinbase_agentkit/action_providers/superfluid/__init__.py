"""Superfluid action provider for streaming payments."""
