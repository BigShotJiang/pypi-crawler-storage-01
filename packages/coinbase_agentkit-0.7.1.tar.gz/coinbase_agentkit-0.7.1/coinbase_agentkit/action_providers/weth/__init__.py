"""WETH action provider for wrapped ETH operations."""
