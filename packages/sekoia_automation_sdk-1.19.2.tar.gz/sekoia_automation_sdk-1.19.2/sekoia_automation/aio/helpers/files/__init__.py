"""
Utilities to work with files and directories.

To use this package you need to install additional libraries:

* aiofiles (https://github.com/Tinche/aiofiles)
* aiocsv (https://github.com/MKuranowski/aiocsv)
"""
