"""Contain the tests for the micoo application."""
