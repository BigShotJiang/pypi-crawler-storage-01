from mcrit.server.application_routes import get_app

app = get_app()
