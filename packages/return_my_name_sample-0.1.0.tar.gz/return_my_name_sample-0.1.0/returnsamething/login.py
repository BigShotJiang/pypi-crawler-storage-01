def return_string(name):
    return name