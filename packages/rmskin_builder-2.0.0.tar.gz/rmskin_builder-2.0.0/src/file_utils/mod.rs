pub mod bitness;
pub mod header_img;
pub mod parse_ini;
pub mod zip;

pub const RMSKIN_INI_NAME: &str = "RMSKIN.ini";
pub const RMSKIN_BMP_NAME: &str = "RMSKIN.bmp";
