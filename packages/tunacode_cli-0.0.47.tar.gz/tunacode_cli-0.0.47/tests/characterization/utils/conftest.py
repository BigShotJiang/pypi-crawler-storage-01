"""Configuration for characterization tests of utils."""

# This file can be left empty or include any shared fixtures if needed
# The genai mocking has been removed since we're no longer using Google GenAI
