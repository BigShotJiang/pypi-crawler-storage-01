import npc_mvr


def test_import_package():
    pass
