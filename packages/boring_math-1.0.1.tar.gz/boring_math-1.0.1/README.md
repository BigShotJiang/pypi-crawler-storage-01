# PyPI boring-math namespace stub project

**WARNING: DO NOT INSTALL THIS PACKAGE**

It is an empty module whose purpose is to claim the boring-math name on PyPI.
This name is used by a family of namespace PyPI packages that make up the
collection of math hobby projects called "Daddy's Boring Math Library."

If this module is installed the rest of the namespace packages will no longer
work.
