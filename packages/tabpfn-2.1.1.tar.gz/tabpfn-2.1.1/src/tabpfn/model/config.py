"""DEPRECATED: Please import tabpfn.architectures.base.config instead."""

from __future__ import annotations

from tabpfn.architectures.base.config import *  # noqa: F403
