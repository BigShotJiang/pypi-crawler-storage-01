from panther.db.models import Model  # noqa: F401
