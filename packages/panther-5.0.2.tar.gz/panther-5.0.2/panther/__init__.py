from panther.main import Panther  # noqa: F401

__version__ = '5.0.2'


def version():
    return __version__
