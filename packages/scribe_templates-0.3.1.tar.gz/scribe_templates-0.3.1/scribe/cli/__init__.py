"""Command line functions for ``scribe``."""
