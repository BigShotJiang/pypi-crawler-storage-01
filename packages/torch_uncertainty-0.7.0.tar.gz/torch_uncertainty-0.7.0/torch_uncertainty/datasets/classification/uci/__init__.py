# ruff: noqa: F401
from .bank_marketing import BankMarketing
from .dota2_games import DOTA2Games
from .htru2 import HTRU2
from .online_shoppers import OnlineShoppers
from .spam_base import SpamBase
