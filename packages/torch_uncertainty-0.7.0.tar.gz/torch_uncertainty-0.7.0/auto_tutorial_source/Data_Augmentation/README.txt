.. _Data_Augmentation_examples:

Data Augmentation
-----------------

Tutorials illustrating data augmentation functionnalities in Torch-Uncertainty.
