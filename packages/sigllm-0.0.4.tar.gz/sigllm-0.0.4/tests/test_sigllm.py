#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `sigllm` package."""

import unittest

# from sigllm import sigllm


class TestSigllm(unittest.TestCase):
    """Tests for `sigllm` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
        self.assertTrue(True)
