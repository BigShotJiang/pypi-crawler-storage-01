
class GrepsrCliError(Exception):
    """Generic errors."""
    pass
