1. Go to Project > Configuration > Time Type
2. Create or edit a Time Type and mark it as Non Billable
3. Go to a project and select a task
4. Add planned hours to the task
5. Create a new timesheet with the Time Type you just created
5. You will see that the time you entered on the timesheet is not discounted on the remaining hours or added in effective hours
6. You can also see project remaining hours are not affected by this non billable time