# Copyright 2025 Miquel Pascual López(APSL-Nagarro)<mpascual@apsl.net>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import project_time_type
from . import account_analytic_line
from . import project_project
from . import project_task
