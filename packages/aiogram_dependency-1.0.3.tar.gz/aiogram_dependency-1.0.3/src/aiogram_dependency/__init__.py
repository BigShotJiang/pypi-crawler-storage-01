from .dependency import Depends, Scope
from .setup import setup_dependency

__all__ = ["Depends", "Scope", "setup_dependency"]
