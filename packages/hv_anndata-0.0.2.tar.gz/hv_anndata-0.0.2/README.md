# hv-anndata

Holoviz Anndata Interface

## Hacking

- Tests: `hatch test`
- Docs: `hatch docs:build`
- Lints: `pre-commit run --all-files` (use `pre-commit install` to install Git hooks)
