"""Basic tests."""

from __future__ import annotations


def test_import() -> None:
    import hv_anndata  # noqa: F401, PLC0415
