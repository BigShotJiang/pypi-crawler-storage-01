package com.example.{KAVIA_TEMPLATE_PROJECT_NAME};

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class {KAVIA_TEMPLATE_PROJECT_NAME}Application {

	public static void main(String[] args) {
		SpringApplication.run({KAVIA_TEMPLATE_PROJECT_NAME}Application.class, args);
	}

}
