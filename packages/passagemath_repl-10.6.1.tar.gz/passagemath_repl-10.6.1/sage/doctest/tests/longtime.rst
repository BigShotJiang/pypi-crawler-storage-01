Test combining various modifiers::

    sage: sys.maxsize  # long time, abs tol 0.001
    2147483646.999            # 32-bit
    9223372036854775806.999   # 64-bit
