from .stringfuncs import string
from .number import number
from .ListFuncs import corrupt_list