
*welcome to shinerainsevenlib*

Useful unadorned utilities for powerful Python programming.
