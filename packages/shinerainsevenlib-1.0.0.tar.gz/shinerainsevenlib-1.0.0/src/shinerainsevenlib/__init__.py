
# shinerainsevenlib (Ben Fisher, moltenform.com)
# Released under the LGPLv2 License

from .core import m6_jslike as jslike
