[![PyPI version](https://badge.fury.io/py/dsp-tools.svg)](https://badge.fury.io/py/dsp-tools)

# Developers Documentation

These pages contain important background information 
for developers of the DSP-TOOLS code repository, 
as well as Architectural Decision Records.

Please read the [README](https://github.com/dasch-swiss/dsp-tools#readme) first.
