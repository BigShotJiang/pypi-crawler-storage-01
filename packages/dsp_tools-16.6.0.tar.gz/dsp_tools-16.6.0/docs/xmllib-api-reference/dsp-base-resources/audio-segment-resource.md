## ::: xmllib.AudioSegmentResource

    options:
        members_order: source
