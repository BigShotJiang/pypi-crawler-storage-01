## ::: xmllib.VideoSegmentResource

    options:
        members_order: source
