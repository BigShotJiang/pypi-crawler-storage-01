from test.unittests.utils.xml_parsing.fixtures_parse_resource import *  # noqa: F403
