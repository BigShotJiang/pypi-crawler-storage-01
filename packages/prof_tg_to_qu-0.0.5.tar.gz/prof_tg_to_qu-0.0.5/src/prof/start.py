from .main import main

def main():
    main()
