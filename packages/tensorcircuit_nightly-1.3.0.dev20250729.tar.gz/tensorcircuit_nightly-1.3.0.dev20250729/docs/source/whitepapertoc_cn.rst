=================================
白皮书教程
=================================

.. toctree::

    whitepaper/3-circuits-gates_cn.ipynb
    whitepaper/4-gradient-optimization_cn.ipynb
    whitepaper/5-density-matrix_cn.ipynb
    whitepaper/6-1-conditional-measurements-post-selection_cn.ipynb
    whitepaper/6-2-pauli-string-expectation_cn.ipynb
    whitepaper/6-3-vmap_cn.ipynb
    whitepaper/6-4-quoperator_cn.ipynb
    whitepaper/6-5-custom-contraction_cn.ipynb
    whitepaper/6-6-advanced-automatic-differentiation_cn.ipynb