# 1.2.12

1. 修复了1.2.11版本中rqalpha无法正常升级的问题；
2. 增加了对numpy版本的限制；
3. 改善了update、install时的命令，具体参考http://jira.ricequant.com/browse/RQSDK-151；
4. 安装命令描述内容修改。

---