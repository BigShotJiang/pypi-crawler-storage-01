"""UniProt reader for LlamaIndex."""

from llama_index.readers.uniprot.base import UniProtReader

__version__ = "0.1.0"
__all__ = ["UniProtReader"]
