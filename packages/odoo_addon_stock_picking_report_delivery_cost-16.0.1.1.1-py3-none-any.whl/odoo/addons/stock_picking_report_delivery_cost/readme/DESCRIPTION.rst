This module shows in the delivery slip and picking operations reports the cost
of the delivery method according the rate computed on the fly according same
conditions as standard `delivery` module would do.
