"""Top-level package for pycmd2."""

__author__ = """gooker_young"""
__email__ = "gooker_young@qq.com"
__version__ = "0.4.24"
__build_date__ = "2025-08-02"
