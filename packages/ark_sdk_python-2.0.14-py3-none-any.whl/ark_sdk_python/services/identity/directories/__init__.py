from ark_sdk_python.services.identity.directories.ark_identity_directories_service import ArkIdentityDirectoriesService

__all__ = ['ArkIdentityDirectoriesService']
