from enum import Enum


class ArkConnectorType(str, Enum):
    SIA_CONNECTOR = 'SIAConnector'
