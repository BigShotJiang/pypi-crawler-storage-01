"""n8n Workflow Builder - A tool for managing n8n workflows."""

__version__ = "0.1.0"
