"""
🦩 VibePrompt CLI Package
Your Words. Their Way.
"""

__version__ = "0.2.4"
__author__ = "Mohammed Aly"
__email__ = "mohammeda.ebrahim22@gmail.com"
