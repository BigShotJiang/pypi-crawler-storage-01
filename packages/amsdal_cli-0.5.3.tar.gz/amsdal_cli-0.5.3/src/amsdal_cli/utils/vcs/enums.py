from enum import Enum


class VCSOptions(str, Enum):
    git = 'git'
