from amsdal_cli.commands.worker.sub_commands.run import run_worker

__all__ = [
    'run_worker',
]
