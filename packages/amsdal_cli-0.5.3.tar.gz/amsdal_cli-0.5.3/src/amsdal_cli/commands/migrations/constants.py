MIGRATIONS_DIR_NAME = 'migrations'
