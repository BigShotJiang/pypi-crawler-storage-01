## [v0.5.3](https://pypi.org/project/amsdal_cli/0.5.3/) - 2025-08-01

### Changed

- Switched to use `uv` package manager
