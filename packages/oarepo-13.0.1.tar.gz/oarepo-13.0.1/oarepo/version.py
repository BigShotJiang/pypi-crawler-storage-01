
# the first 3 numbers of version here must be the same as invenio version in setup.py
# if the version ends with a*, add this to the first 3 numbers
__version__ = "13.0.0"
