## cdf 

### Fixed

- When deploying a workflow trigger, Toolkit no longer deletes and
recreates it. Instead, the trigger is updated.

## templates

No changes.