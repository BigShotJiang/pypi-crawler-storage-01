"""
PoC during import of flatfox-api module.
"""

__version__ = "99.99.99"

def ping():
    return "pong"
