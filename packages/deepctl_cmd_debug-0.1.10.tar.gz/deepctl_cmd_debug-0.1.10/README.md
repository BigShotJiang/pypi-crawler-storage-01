# deepctl-cmd-debug

Debug command group for the Deepgram CLI (deepctl).
