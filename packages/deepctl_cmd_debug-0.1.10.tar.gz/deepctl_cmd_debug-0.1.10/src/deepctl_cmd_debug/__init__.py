"""Debug command group for deepctl."""

from .command import DebugCommand

__all__ = ["DebugCommand"]
