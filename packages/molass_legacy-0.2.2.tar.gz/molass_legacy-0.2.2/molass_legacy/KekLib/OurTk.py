# coding: utf-8
"""

    OurTk.py

    python-tkdnd
    https://libraries.io/pypi/python-tkdnd

    pip install python-tkdnd

    Copyright (c) 2021-2022, Masatsuyo Takahashi, KEK-PF

"""
from tkinter import *
import tkinter.font as font
from tkinterDnD import Tk
