"""
    Baseline.Constants.py

    Copyright (c) 2021-2023, SAXS Team, KEK-PF
"""

SLOPE_SCALE = 1e6       # move from molass_legacy.Optimizer.TheUtils
