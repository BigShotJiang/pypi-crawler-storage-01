Graph Data (JSON) Generator
===========================

[![PyPI][PyPI project badge]][PyPI project url]

[PyPI project badge]: https://img.shields.io/pypi/v/graph-database-loader?logo=pypi&logoColor=white&style=for-the-badge&labelColor=7B99FA&color=53CDD8
[PyPI project url]: https://pypi.org/project/graph-database-loader/

Graph Schema
------------

- Every node is going to have a __label___ field
