from .core import dustmaps3d

__version__ = '2.2.6'
__all__ = ['dustmaps3d']
