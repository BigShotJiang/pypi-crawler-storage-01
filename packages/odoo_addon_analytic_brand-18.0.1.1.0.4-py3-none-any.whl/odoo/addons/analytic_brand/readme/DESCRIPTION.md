This addon associate an analytic distribution to a brand that will be used as
a default value where the brand is used if the analytic accounting is
activated.
