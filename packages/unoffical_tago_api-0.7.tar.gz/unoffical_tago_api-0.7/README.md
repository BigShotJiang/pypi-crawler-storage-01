# TAGOBus-API
[![Upload Python Package](https://github.com/hyuntroll/TAGOBus-API/actions/workflows/python-publish.yml/badge.svg)](https://github.com/hyuntroll/TAGOBus-API/actions/workflows/python-publish.yml)
TAGOAPI는 국가대중교통정보센터(TAGO)에서 제공하는 버스 api를 파이썬에서 사용할 수 있게 만든 비공식 API입니다.

