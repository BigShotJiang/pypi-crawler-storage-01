from .temp_prompt1 import PromptForTestA
from .temp_prompt2 import PromptForTestB

__all__ = ["PromptForTestA", "PromptForTestB"]
