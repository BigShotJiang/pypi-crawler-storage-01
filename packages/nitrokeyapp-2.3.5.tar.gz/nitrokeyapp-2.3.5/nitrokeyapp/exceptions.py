class BasePyNKException(Exception):
    pass
