```
oc apply -f deployment/model_container.yaml
oc apply -f deployment/servingruntime.yaml
oc apply -f deployment/isvc.yaml
```