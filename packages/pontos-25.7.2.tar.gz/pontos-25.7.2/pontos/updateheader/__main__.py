# SPDX-FileCopyrightText: 2021-2023 Greenbone AG
#
# SPDX-License-Identifier: GPL-3.0-or-later
#

# pylint: disable=invalid-name

from pontos import updateheader

if __name__ == "__main__":
    updateheader.main()
