import enum


class Resource(int, enum.Enum):
    # openai_tokens = 1  # noqa
    tokens_cost = 2
