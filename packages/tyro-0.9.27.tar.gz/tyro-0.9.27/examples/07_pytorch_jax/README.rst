PyTorch / JAX
=============

In these examples, we show some patterns for using :func:`tyro.cli` with PyTorch and JAX.
