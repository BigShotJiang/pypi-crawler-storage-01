# DataSince
Some Data Since references using python pandas/numpy
with**OUT DEPENDENCIES**.

## What basics are presented in this repository: 
- Working with csv files(parsing)
- Linear Regression (implementation of algorithm)
- Gradient Descent (implementation of algorithm)
- Logistic regression (implementation of algorithm)
- KNN (k near neigbours) (implementation of algorithm)

## The module
- Easy and usable functions for presenting how the alogithm actually works inside 
- Well commented code 
- Clear structure 
- NO dependensies

## The datasets 
- [Iris dataset link](https://www.kaggle.com/datasets/uciml/iris)
- [Penguins dataset link](https://www.kaggle.com/code/parulpandey/penguin-dataset-the-new-iris)
- Make sure to `pip install -r requirements.txt` to access the kagle-hub library 

