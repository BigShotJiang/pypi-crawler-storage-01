"""SurrealDB MCP Server package."""

from .server import mcp, main

__all__ = ["mcp", "main"]