<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS language="es_ES" version="2.1">
    <context>
        <name>HourlyForecast</name>
        <message>
            <location filename="../HourlyForecast.qml" line="41"/>
            <source>HOURLY</source>
            <translation>CADA HORA</translation>
        </message>
    </context>
</TS>
