<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS language="de_DE" version="2.1">
    <context>
        <name>DailyForecast</name>
        <message>
            <location filename="../DailyForecast.qml" line="41"/>
            <source>DAILY</source>
            <translation>TÄGLICH</translation>
        </message>
    </context>
</TS>
