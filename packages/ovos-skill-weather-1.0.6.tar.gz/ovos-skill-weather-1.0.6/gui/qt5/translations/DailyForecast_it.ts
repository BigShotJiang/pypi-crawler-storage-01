<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS language="it_IT" version="2.1">
    <context>
        <name>DailyForecast</name>
        <message>
            <location filename="../DailyForecast.qml" line="41"/>
            <source>DAILY</source>
            <translation>QUOTIDIANO</translation>
        </message>
    </context>
</TS>
