<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS language="pt_BR" version="2.1">
    <context>
        <name>DailyForecast</name>
        <message>
            <location filename="../DailyForecast.qml" line="41"/>
            <source>DAILY</source>
            <translation>DIÁRIO</translation>
        </message>
    </context>
</TS>
