<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS language="fr_FR" version="2.1">
    <context>
        <name>DailyForecast</name>
        <message>
            <location filename="../DailyForecast.qml" line="41"/>
            <source>DAILY</source>
            <translation>DU QUOTIDIEN</translation>
        </message>
    </context>
</TS>
