__version__ = "0.1.1"
__author__ = "Juntao Zhang, Tingting Shi"
__email__ = "jzhng106@gmail.com"
from .core import actuarial, fraction_to_date_full