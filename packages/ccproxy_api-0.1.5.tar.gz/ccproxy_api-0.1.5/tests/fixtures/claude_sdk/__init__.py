"""Claude SDK testing fixtures.

This module provides fixtures for testing ClaudeSDKService integration through internal mocking.
These mocks use AsyncMock for dependency injection, not HTTP interception.
"""
