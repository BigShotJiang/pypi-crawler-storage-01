"""Storage backends for observability data."""
