from .translational import TransE, TransH, TransR, TransD
from .bilinear import RESCAL, DistMult, ComplEx
from .convolutional import ConvKB