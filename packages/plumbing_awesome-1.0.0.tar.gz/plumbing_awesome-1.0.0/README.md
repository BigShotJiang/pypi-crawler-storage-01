# Plumbing
Pipes!
----------------------
```python
Plumbing(10).pipe(lambda x: x * 10).pipe(str).value # "10"
```
