# LlamaIndex Vector_Stores Integration: Singlestoredb
