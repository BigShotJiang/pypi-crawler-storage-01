from ocp_resources.resource import Resource


class ConsoleCLIDownload(Resource):
    """
    ConsoleCLIDownload object, inherited from Resource.
    """

    api_group = Resource.ApiGroup.CONSOLE_OPENSHIFT_IO
