from ocp_resources.namespace import Namespace


with Namespace(name="myns1") as ns:
    pass
