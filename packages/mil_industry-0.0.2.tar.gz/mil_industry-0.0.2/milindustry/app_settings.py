"""App Settings"""

# Django
from django.conf import settings

# put your app settings here


