from typing import Optional

_config: Optional[dict] = None
