from enum import Enum


class AssaysCreateBodySummarizerType0Type(str, Enum):
    UNIVARIATECONTINUOUS = "UnivariateContinuous"

    def __str__(self) -> str:
        return str(self.value)
