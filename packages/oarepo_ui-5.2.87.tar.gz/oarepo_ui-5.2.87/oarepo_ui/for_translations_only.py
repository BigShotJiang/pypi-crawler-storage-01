from gettext import gettext as _

translated_strings = [
    _("api.draft"),
    _("api.latest"),
    _("api.files"),
    _("api.latest_html"),
    _("api.publish"),
    _("api.record"),
    _("api.self_html"),
    _("api.versions"),
]
