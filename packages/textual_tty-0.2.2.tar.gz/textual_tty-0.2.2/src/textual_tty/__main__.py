"""Allow the package to be run with python -m textual_tty."""

from .demo import main

if __name__ == "__main__":
    main()
