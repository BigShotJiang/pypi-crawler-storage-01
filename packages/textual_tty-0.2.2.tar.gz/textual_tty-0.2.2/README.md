# textual-tty

A terminal emulator for Textual apps, using `bittty`, my pure Python terminal
emulator.

Currently buggy and a bit slow, but it's still somewhat usable.

## Demo

```bash
uvx textual-tty
```

## Usage

1. `TextualTerminal`, a bittty.Terminal subclass for textual.
2. `TerminalApp`, a terminal emulator in a window.

Read the demo code for more info.

## Links

* [🏠 home](https://bitplane.net/dev/python/textual-tty)
* [🐍 pypi](https://pypi.org/project/textual-tty)
* [🐱 github](https://github.com/bitplane/textual-tty)

## License

WTFPL with one additional clause

1. Don't blame me

Do wtf you want, but don't blame me when it rips a hole in your trousers.

