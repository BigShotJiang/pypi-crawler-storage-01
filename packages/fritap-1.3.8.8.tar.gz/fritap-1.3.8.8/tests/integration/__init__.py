"""
Mock integration tests for friTap.

Tests integration between components using mocked dependencies
to avoid requiring real devices, applications, or network connections.
"""