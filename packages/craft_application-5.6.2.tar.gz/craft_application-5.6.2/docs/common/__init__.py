"""Enables the craft_application_docs package to be produced."""
