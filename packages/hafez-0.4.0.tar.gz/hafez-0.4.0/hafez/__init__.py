from hafez.entry import get_poem
from hafez.entry import search
from hafez.entry import omen, fal
from hafez.entry import total_poems
from hafez.entry import download_all_audio
from hafez.entry import download_audio
from hafez.entry import get_audio
