# ServerGit

GitSys is a Python library designed to simplify interaction with GitHub repositories using the GitHub API via [PyGithub]. It allows developers to automate common GitHub operations such as repository creation, file manipulation, and data table management, all while maintaining a detailed log of actions for transparency and debugging.

---

## 🚀 Features

- ✅ Connect to GitHub using a personal access token (PAT)
- 📁 Create, update, read, and delete files/folders in a repository
- 🏗️ Create, edit, and delete GitHub repositories
- 📜 Maintain a log of operations via `NOTA.json`
- 🧾 Manage structured data tables (as JSON files)
- 📊 Convert structured tables into pandas DataFrames
- 🔁 Fully programmatic GitHub automation
- 🧠 Introspective logging of system events
- 📦 Modular structure with internal classes for files, repositories, and server logic

---

## 📦 Requirements

- Python 3.8+
- [PyGithub](https://github.com/PyGithub/PyGithub)
- pandas

Install dependencies:

```bash
pip install PyGithub pandas

GitSys
│
├── REPO           # Create/edit/delete repositories
├── GitFiles       # Create/upload/download/delete files and folders
├── server         # Create/manage classes, tables, and data structures in JSON
└── nota()         # Log actions to NOTA.json


from gitpy import GitSys

gitsys = GitSys(token='your_github_token', full_repo_name='username/repo_name')


🏗️ Repository Operations
repo = gitsys.REPO(master=gitsys, repo_name='my-repo')
repo.create_repo(description='Created via GitSys', private=True)
repo.edit_repo(new_name='updated-repo-name')
repo.delete_repo()

📁 File and Folder Operations
files = gitsys.GitFiles(master=gitsys, repo=gitsys.get())

files.create_folder('my_folder')
files.create_file('my_folder/readme.txt', 'Hello World!')
files.upload_file(local_path='local.txt', repo_path='repo_folder/uploaded.txt')
files.download_file(repo_path='repo_folder/uploaded.txt', local_path='downloaded.txt')
content = files.read_file('my_folder/readme.txt')
files.update_file('my_folder/readme.txt', 'Updated Content')
files.delete_file('my_folder/readme.txt')

📊 Data Table Management
GitSys lets you create and manage structured JSON tables within GitHub repos.

server = gitsys.server(master=gitsys, repo=gitsys.get())

# Create class and table
_class = server.create_class('Students')
table = server.create_table(_class, 'grades')

# Add dictionary (record)
server.create_dict(table, 'Alice')
server.insert_value(table, 'Alice', ['grade', 'A+'])

# Read and update
server.update_value(table, 'Alice', ['grade', 'A'])
record = server.get_value(table, 'Alice')

# Convert to DataFrame
df = server.data_frame_value(table, values=['__name__', 'grade'])
print(df)

📓 Logging Actions
Every major GitHub operation is logged to a NOTA.json file in the repository.

gitsys.nota(save=True, _print=True)

📌 Example Use Cases
Automating classroom or student data storage in GitHub repos

GitHub-based version control for JSON data structures

Creating educational or collaborative repositories on the fly

Remote logging of repository events and changes

✅ Best Practices
Always store your GitHub tokens securely (use .env or secret managers)

Avoid committing NOTA.json manually; let GitSys manage it

Use separate repositories for structured data vs source code

Clean up test repos with delete_repo() to avoid clutter

📄 License
This project is licensed under the MIT License. See the LICENSE file for more information.

🤝 Contributing
Contributions are welcome! Feel free to fork, open issues, or submit pull requests. If you have feature requests or want to integrate GitSys into larger automation pipelines, open a discussion.

📬 Contact
Created by [Your Name] — feel free to reach out for suggestions or collaboration.


Se quiser, posso também gerar o arquivo pronto para download ou incluir instruções de testes unitários/documentação automática. É só avisar!
