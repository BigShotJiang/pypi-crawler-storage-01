import uuid


def generate_swarm_id():
    return str(uuid.uuid4())
