amplfi.train.cli module
-----------------------

.. automodule:: amplfi.train.cli.base
.. automodule:: amplfi.train.cli.flow
.. automodule:: amplfi.train.cli.similarity
