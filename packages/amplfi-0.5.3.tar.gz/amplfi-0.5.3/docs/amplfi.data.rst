amplfi.data module
==================

.. automodule:: amplfi.data.base
.. automodule:: amplfi.data.paths
.. automodule:: amplfi.data.tasks
