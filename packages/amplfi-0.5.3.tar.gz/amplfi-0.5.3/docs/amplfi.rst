API Reference
=============

.. automodule:: amplfi

.. toctree::
    :maxdepth: 2

    amplfi.data
    amplfi.train
    amplfi.tune
