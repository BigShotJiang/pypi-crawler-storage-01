amplfi.train.configs module
===========================

.. automodule:: amplfi.train.configs.flow
.. automodule:: amplfi.train.configs.similarity
