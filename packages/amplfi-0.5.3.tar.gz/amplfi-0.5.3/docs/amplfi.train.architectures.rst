amplfi.train.architectures module
=================================

.. automodule:: amplfi.train.architectures.flows.base
.. automodule:: amplfi.train.architectures.flows.coupling
.. automodule:: amplfi.train.architectures.flows.iaf
