# phis_config
read and parse configuration file for phis-related projects
