"""
Utility functions for the data analysis framework.

This module contains helper functions and utilities used across the framework.
"""

__version__ = "1.0.0" 