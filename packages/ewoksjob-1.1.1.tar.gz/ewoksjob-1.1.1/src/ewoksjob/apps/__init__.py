"""Celery applications"""
