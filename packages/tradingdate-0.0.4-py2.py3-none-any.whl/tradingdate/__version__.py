"""Version file."""

VERSION = (0, 0, 4)

__version__ = ".".join(map(str, VERSION))
