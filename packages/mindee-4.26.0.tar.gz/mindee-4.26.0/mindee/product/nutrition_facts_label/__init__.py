from mindee.product.nutrition_facts_label.nutrition_facts_label_v1 import (
    NutritionFactsLabelV1,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_added_sugar import (
    NutritionFactsLabelV1AddedSugar,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_calorie import (
    NutritionFactsLabelV1Calorie,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_cholesterol import (
    NutritionFactsLabelV1Cholesterol,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_dietary_fiber import (
    NutritionFactsLabelV1DietaryFiber,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_document import (
    NutritionFactsLabelV1Document,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_nutrient import (
    NutritionFactsLabelV1Nutrient,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_protein import (
    NutritionFactsLabelV1Protein,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_saturated_fat import (
    NutritionFactsLabelV1SaturatedFat,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_serving_size import (
    NutritionFactsLabelV1ServingSize,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_sodium import (
    NutritionFactsLabelV1Sodium,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_total_carbohydrate import (
    NutritionFactsLabelV1TotalCarbohydrate,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_total_fat import (
    NutritionFactsLabelV1TotalFat,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_total_sugar import (
    NutritionFactsLabelV1TotalSugar,
)
from mindee.product.nutrition_facts_label.nutrition_facts_label_v1_trans_fat import (
    NutritionFactsLabelV1TransFat,
)
