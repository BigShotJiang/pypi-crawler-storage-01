from mindee.extraction.common.extracted_image import ExtractedImage
from mindee.extraction.common.image_extractor import (
    attach_image_as_new_file,
    extract_multiple_images_from_source,
)
