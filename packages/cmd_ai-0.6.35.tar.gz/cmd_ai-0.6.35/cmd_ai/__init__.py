import sys
sys.path.append(".")         # can find version in . by pytest
sys.path.append("./cmd_ai")  # can find version from Jupyter
#from version import __version__
# try:
#     from cmd_ai.version import __version__
# except:
#    print("")
