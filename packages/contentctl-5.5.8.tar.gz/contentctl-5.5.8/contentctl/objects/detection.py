from __future__ import annotations

from contentctl.objects.abstract_security_content_objects.detection_abstract import (
    Detection_Abstract,
)


class Detection(Detection_Abstract):
    # Customization to the Detection Class go here.
    # You may add fields and/or validations

    # You may also experiment with removing fields
    # and/or validations,  or chagning validation(s).
    # Please be aware that many defaults field(s)
    # or validation(s) are required and removing or
    # them or modifying their behavior may cause
    # undefined issues with the contentctl tooling
    # or output of the tooling.
    pass
    pass
