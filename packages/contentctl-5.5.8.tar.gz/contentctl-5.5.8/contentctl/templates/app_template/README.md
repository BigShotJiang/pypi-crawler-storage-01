# Content Pack built with contentctl

This application was built using the open source [contentctl](https://github.com/splunk/contentctl) tool published by the Splunk Threat Research Team (STRT).

For questions about the tool, please see the repo or contact STRT at research@splunk.com

Feel free to update this file to include your own valuable README information.
