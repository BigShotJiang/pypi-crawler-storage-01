# agentic package initializer
