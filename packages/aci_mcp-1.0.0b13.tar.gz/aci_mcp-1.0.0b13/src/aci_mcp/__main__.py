# __main__.py

from aci_mcp import main

main()
