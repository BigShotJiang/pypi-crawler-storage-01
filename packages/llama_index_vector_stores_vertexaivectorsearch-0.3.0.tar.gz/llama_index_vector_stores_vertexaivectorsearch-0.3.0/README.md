# LlamaIndex Vector_Stores Integration: [Vertex AI Vector Search](https://cloud.google.com/vertex-ai/docs/vector-search/overview)

Please refer to the [notebook](../../../docs/docs/examples/vector_stores/VertexAIVectorSearchDemo.ipynb) for usage of Vertex AI Vector Search as vector store in LlamaIndex.
