from llama_index.vector_stores.vertexaivectorsearch.base import VertexAIVectorStore

__all__ = ["VertexAIVectorStore"]
