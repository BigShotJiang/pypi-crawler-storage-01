# hexseg
Spatial functions for analysing crime by hexagons and street segments
