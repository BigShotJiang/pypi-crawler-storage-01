#!/bin/bash

export CM1="Some thing"
export CM2="Other thing"

