from .shotstars import main_cli
