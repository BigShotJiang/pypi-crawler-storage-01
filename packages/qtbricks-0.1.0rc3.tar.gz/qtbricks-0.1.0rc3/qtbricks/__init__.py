"""qtbricks

Python Qt components: widgets and utils, focussing on scientific GUIs.
"""
