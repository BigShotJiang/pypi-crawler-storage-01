The file `../AutoGitSemVer/AutoGitSemVerSchema.json` is built using https://github.com/davidbrownell/v4-Common_SimpleSchema with the input file `./AutoGitSemVerSchema.SimpleSchema`.

Eventually, this repository will include instructions on how to run this process locally to build this file within this repository, but https://github.com/davidbrownell/v4-Common_SimpleSchema does not yet conform to standard python packaging conventions.
