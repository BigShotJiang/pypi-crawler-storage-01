# llmada
一个方便使用各种LLM api的工具

# 注意vpn

"""
           我的   openai的

没有vpn  √(64)     √
vpn     x         x
    
"""