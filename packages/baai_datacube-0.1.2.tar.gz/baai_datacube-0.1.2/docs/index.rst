wisearch documentation
====================

