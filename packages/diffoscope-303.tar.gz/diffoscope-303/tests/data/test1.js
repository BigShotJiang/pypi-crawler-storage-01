function test(str) { alert(str);prompt(str,"TEST1")}x=1;y=2;z=/.+/;d=[2015,2016]; //comment
