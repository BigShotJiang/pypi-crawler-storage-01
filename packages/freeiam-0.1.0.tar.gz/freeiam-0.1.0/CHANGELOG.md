# CHANGELOG

<!-- version list -->

## v0.1.0 (2025-08-03)

### Documentation

- **ldap**: Add API docs and usage examples
  ([`dfbcbe4`](https://github.com/Free-IAM/freeiam/commit/dfbcbe40fb8ba95828e9dd095e8b88c3dff4a82c))

### Features

- **ldap**: Implement LDAP library
  ([`9413a8b`](https://github.com/Free-IAM/freeiam/commit/9413a8b8b8c339d220449aa5a7a557a0f7060a02))
