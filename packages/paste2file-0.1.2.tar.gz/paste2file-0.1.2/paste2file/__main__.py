"""
Entry point for python -m paste2file
"""
from paste2file.main import main

if __name__ == "__main__":
    main()
