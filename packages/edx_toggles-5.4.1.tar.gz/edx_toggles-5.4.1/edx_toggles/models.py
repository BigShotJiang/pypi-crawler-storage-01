"""
Database models for edx_toggles.
"""
