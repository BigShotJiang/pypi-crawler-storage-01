"""
Waffle classes in the context of edx-platform and other IDAs.

For detailed usage see:
  https://github.com/openedx/edx-toggles/blob/master/docs/how_to/implement_the_right_toggle_type.rst
"""
