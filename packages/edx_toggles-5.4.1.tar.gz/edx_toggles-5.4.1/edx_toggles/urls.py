"""
URLs for edx_toggles.
"""

urlpatterns = []
