# echemdb-converters

Convert raw data into echemdb data packages

## Installation

This package is available on [PiPY](https://pypi.org/project/echemdbconverters/) and can be installed with pip:

```sh .noeval
pip install echemdbconverters
```
