# xproject

#### scripts

#### generate_init_py

~~~shell
poetry run generate_init_py src/xproject
~~~