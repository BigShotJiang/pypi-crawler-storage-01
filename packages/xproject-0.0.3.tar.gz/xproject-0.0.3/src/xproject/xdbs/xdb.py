from xproject.xmixins.xcontext_manager_mixin import ContextManagerMixin


class DB(ContextManagerMixin):
    pass
