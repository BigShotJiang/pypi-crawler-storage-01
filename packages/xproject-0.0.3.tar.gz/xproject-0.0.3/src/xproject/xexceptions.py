class ImportClassTypeError(TypeError):
    pass
