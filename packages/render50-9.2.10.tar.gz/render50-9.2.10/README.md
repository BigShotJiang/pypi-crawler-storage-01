# render50

## Usage

```
pip3 install cli50
cli50
pip3 install -e .
./render50
```
