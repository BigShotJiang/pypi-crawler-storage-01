This package contains code derived from the OpenLLMetry project, which is licensed under the Apache License, Version 2.0.

Original repository: https://github.com/traceloop/openllmetry

Copyright notice from the original project:
Copyright (c) Traceloop (https://traceloop.com)

The Apache 2.0 license can be found in the LICENSE file in this directory.

This code has been modified and adapted for use in the AgentOps project. 