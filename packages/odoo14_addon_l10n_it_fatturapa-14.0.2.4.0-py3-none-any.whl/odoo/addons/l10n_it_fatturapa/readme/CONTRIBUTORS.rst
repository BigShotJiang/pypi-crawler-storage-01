* Davide Corio
* Lorenzo Battistini <https://github.com/eLBati>
* Roberto Onnis
* Alessio Gerace
* Sergio Zanchetta <https://github.com/primes2h>
* Gianluigi Tiesi <https://github.com/sherpya>
* Roberto Fichera <https://github.com/robyf70>
* Marco Colombo <https://github.com/TheMule71>
* Salvo Rapisarda <https://github.com/salvorapi>
* `Ooops <https://www.ooops404.com>`_:

   * Giovanni Serra <giovanni@gslab.it>

* `Aion Tech <https://aiontech.company/>`_:

  * Simone Rubino <simone.rubino@aion-tech.it>

* `Stesi Consulting <https://www.stesi.consulting/>`_:
  * Michele Di Croce <dicroce.m@stesi.consulting>
