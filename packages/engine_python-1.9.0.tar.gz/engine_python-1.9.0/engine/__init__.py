from .services.google import GoogleEngine

__version__ = "1.6.0"