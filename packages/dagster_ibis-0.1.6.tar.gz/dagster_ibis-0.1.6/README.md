# dagster-ibis
Dagster IO manager for ibis dataframes
