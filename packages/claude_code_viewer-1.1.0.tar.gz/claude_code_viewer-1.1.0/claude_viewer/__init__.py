"""Claude Code Viewer - Web interface for Claude Code conversation history."""

__version__ = "1.0.0"
__author__ = "Claude Code Community"
__description__ = "Beautiful web viewer for Claude Code conversation history"