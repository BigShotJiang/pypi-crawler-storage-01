Process variable to (PV) 4-20mA conversion:

    Where,
    X is Process Variable
    LRV is Lower Range Value
    URV is Upper Range Value