#!/usr/bin/env python
"""
Remove auto-generated files
"""
import utils as ut
ut.clean_outputs()