# Starsim examples

This folder contains example diseases and interventions that are used for testing and illustrative purposes, but have not been part of the core Starsim library since version 3.0.