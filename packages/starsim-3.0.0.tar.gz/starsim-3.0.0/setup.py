"""
Legacy support; see pyproject.toml for current information
"""

import setuptools

setuptools.setup()