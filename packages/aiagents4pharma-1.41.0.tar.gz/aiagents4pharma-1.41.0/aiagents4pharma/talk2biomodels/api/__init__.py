'''
This file is used to import the modules in the package.
'''
from . import uniprot
from . import ols
from . import kegg
