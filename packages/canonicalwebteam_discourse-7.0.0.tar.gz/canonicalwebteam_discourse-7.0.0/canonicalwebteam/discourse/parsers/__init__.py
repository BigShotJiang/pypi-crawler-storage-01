from canonicalwebteam.discourse.parsers.docs import (  # noqa
    DocParser,  # noqa
)
from canonicalwebteam.discourse.parsers.tutorials import (  # noqa
    TutorialParser,  # noqa
)
from canonicalwebteam.discourse.parsers.category import (  # noqa
    CategoryParser,  # noqa
)
from canonicalwebteam.discourse.parsers.events import (  # noqa
    EventsParser,  # noqa
)
