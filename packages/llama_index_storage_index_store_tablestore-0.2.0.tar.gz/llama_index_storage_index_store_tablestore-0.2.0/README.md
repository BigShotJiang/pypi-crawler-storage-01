# LlamaIndex Index_Store Integration: Tablestore Index Store
