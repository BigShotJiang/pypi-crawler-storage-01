This directory contains C drivers for specific hardware.  The drivers are
intended to work across multiple ports.
