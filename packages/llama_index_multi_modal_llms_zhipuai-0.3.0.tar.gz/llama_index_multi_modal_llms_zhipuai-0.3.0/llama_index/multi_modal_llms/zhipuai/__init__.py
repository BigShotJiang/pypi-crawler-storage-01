from llama_index.multi_modal_llms.zhipuai.base import ZhipuAIMultiModal

__all__ = ["ZhipuAIMultiModal"]
