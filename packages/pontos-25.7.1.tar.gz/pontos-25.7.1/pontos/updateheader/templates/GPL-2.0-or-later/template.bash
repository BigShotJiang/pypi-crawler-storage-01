#!/bin/bash
# SPDX-FileCopyrightText: <year> <company>
#
# SPDX-License-Identifier: GPL-2.0-or-later
