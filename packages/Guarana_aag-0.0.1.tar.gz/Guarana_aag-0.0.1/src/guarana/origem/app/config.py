# QUAL FOLHA DE ESTILO USAR
_ESTILOS = {
    'padrao': 'css/estilo.css',
    'compacto': 'css/compacto.css'
}
ESTILO = _ESTILOS.get('padrao', 'css/estilo.scss')

TITULO = 'Nome do App'
