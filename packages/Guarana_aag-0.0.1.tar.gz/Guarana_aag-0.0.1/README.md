# Guaraná
Baseado no Front_Alego, gem de Ruby que desenvolvi para a Assembleia Legislativa do Estado de Goiás, esse módulo Python instala um front_end funcional para módulos Flask ou mesmo para HTML estático, que dá a base para trabalhar, sem limitar com um estilo fixo caso decida alterar, mas também permite fazer um site rápido com mudanças mínimas.

[Changelog](changelog.md)