"""
For testing of PyPI publishing.
"""

def echo(say_hi:str) -> str:
    return say_hi

