# Autonomous Business System
Autonomous business system based on paper https://doi.org/10.1109/ACCESS.2025.3583260