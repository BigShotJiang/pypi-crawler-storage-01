from __future__ import annotations

from django.apps import AppConfig


class DjangoSquashConfig(AppConfig):
    """Main app config."""

    name = "django_squash"
