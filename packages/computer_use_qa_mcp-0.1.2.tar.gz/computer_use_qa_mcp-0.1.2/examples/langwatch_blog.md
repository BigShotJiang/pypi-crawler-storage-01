1. Open the browser and go to https://langwatch.ai/
2. Go to the blog page
3. Chose any article
4. Scroll to the bottom of the page until the footer
5. Click on "All services online" to move to the status page
6. Make sure that on the status page, the Collector service is operational