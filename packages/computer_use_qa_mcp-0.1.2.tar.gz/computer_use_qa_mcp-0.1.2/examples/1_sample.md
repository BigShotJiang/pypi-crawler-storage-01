1. Open Chrome and go to https://github.com/rogeriochaves/computer-use-qa-mcp
2. Hit the star button