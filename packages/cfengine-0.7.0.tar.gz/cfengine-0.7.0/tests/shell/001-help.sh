#!/bin/bash

set -e
set -x

cfengine help
cfengine --help
