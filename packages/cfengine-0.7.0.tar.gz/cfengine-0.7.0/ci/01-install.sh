#!/bin/bash

set -e
set -x

pipx install uv
