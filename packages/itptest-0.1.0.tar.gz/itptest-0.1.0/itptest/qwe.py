

class MyTestClass:
    def test_method(self):
        return 10