## JISO-DROID 
        
    This tool helps you:
        1. Generate new keystores for APK signing
        2. Sign APK files with existing keystores
        3. Supports comprehensive configuration including:
           - Custom distinguished names (DN)
           - Multiple cryptographic algorithms (RSA/EC)
           - Flexible validity periods
           - V1/V2/V3/V4 signature schemes