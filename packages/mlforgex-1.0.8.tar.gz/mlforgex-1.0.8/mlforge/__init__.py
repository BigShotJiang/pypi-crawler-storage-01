__version__ = "1.0.8"

from .train import train_model
from .predict import predict
