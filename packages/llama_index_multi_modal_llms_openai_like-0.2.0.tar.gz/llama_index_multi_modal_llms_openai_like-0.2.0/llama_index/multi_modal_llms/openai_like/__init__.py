from llama_index.multi_modal_llms.openai_like.base import OpenAILikeMultiModal

__all__ = ["OpenAILikeMultiModal"]
