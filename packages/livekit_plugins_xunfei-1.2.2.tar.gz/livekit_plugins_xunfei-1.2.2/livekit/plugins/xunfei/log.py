from logging import getLogger

logger = getLogger("livekit.plugins.xunfei")
