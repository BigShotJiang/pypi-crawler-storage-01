function n(){}function o(){}export{n as o,o as u};
