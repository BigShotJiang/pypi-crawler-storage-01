# Copyright 2025 Canonical Ltd.
# See LICENSE file for licensing details.
from setuptools import setup

setup()
