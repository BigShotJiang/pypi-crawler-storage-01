# Reference

Technical reference material including APIs and release notes.

```{toctree}
:maxdepth: 1
:glob:

API <_api/scanspec>
reference/*
genindex
Release Notes <https://github.com/bluesky/scanspec/releases>
```
