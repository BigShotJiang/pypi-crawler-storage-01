from ..file import File


class PythonFile(File): ...
