from __future__ import annotations

from ..statement import BlockStatement, SimpleStatement


class PHPSimpleStatement(SimpleStatement): ...


class PHPBlockStatement(BlockStatement): ...
