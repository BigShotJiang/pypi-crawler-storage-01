from ..file import File


class GoFile(File): ...
