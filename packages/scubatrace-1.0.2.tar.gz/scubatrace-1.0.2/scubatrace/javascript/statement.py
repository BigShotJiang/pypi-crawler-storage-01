from __future__ import annotations

from ..statement import BlockStatement, SimpleStatement


class JavaScriptSimpleStatement(SimpleStatement): ...


class JavaScriptBlockStatement(BlockStatement): ...
