from ..file import File


class RustFile(File): ...