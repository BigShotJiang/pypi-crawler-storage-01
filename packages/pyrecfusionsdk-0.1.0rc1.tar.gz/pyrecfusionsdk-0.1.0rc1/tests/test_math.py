import pytest
# from pyRecFusionSDK import Vec3

class TestVec3:

    def test_init(self):
        # v1 = Vec3(x=0.0, y=1.0, z=2.0)
        # assert v1[0] == 0.0
        # assert v1[1] == 1.0
        # assert v1[2] == 2.0
        # assert v1.data() == [0.0, 1.0, 2.0]
        pass
