LANDS = "me.angeschossen.lands"
WORLDBORDER = "worldborder"
