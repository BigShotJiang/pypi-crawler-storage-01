import multiprocessing as mp
mp.set_start_method('spawn')