def fmt(f, *args, **kwargs):
  return f.format(*args, **kwargs)