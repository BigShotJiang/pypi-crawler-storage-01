import json

def jsonify(v):
  return json.dumps(v)
