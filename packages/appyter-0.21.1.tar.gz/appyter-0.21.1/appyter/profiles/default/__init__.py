''' Bare profile with no styling.
The default profile contains the :mod:`appyter.profiles.default.fields`, :mod:`appyter.profiles.default.filters`, and :mod:`appyter.profiles.default.templates` usable by all other profiles.
'''