canopy.sources
==============

canopy.sources.registry
-----------------------

.. automodule:: canopy.sources.registry
   :members:
   :show-inheritance:
   :undoc-members:

canopy.sources.source\_abc
--------------------------

.. automodule:: canopy.sources.source_abc
   :members:
   :show-inheritance:
   :undoc-members:

canopy.sources.source\_fluxnet2015
----------------------------------

.. automodule:: canopy.sources.source_fluxnet2015
   :members:
   :show-inheritance:
   :undoc-members:

canopy.sources.source\_lpjguess
-------------------------------

.. automodule:: canopy.sources.source_lpjguess
   :members:
   :show-inheritance:
   :undoc-members:
