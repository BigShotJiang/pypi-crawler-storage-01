canopy.readers
==============

canopy.readers.fluxnet2015
--------------------------

.. automodule:: canopy.readers.fluxnet2015
   :members:
   :show-inheritance:
   :undoc-members:

canopy.readers.lpjguess
-----------------------

.. automodule:: canopy.readers.lpjguess
   :members:
   :show-inheritance:
   :undoc-members:

canopy.readers.registry
-----------------------

.. automodule:: canopy.readers.registry
   :members:
   :show-inheritance:
   :undoc-members:
