import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

# 1. Generate synthetic data
np.random.seed(42)
X = np.random.rand(5000, 5) * 10  # 5000 samples, 5 features in [0, 10]

# Nonlinear target function
def f(x):
    a, b, c, d, e = x
    return np.sin(a) + np.log(b + 1) + c**2 - np.sqrt(d) + e**3

y = np.array([f(row) for row in X])

# 2. Train/test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# 3. Define the neural network
model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=(5,)),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(1)  # Output layer
])

model.compile(optimizer='adam', loss='mse', metrics=['mae'])

# 4. Train the model
history = model.fit(X_train, y_train, epochs=100, batch_size=32,
                    validation_data=(X_test, y_test), verbose=0)

# 5. Evaluate model
loss, mae = model.evaluate(X_test, y_test)
print(f"Test MAE: {mae:.2f}")

# 6. Predict on new data
new_inputs = np.array([
    [1, 2, 3, 4, 5],
    [5, 4, 3, 2, 1]
])
predictions = model.predict(new_inputs)
for i, x in enumerate(new_inputs):
    print(f"f({x}) ≈ {predictions[i][0]:.2f}")

# 7. Visualize training loss
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.title('Training History')
plt.legend()
plt.grid(True)
plt.show()
