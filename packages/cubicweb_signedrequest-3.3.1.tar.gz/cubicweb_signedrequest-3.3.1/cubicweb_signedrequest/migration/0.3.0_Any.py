sync_schema_props_perms("token_for_user")
