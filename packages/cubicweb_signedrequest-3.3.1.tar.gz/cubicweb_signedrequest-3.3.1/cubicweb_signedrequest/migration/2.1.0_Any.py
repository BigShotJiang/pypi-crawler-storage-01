add_attribute("AuthToken", "last_time_used")
add_attribute("AuthToken", "expiration_date")
sync_schema_props_perms("token")
