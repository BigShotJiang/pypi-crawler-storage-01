"""Exceptions."""


class AquatlantisOriError(Exception):
    """Base class for all exceptions in AquatlantisOri."""
