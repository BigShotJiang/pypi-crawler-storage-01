"""Constants."""

from typing import Final

SERVER: Final[str] = "8.209.119.184"
