# Double subtitle videos

Download a video plus (auto-generated) subtitles in a target language. Then translate those subtitles to a native language and play the video with both displayed. The native subtitles are togglable.