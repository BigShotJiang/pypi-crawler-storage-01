<?php
return [
    'welcome' => 'Welcome to our application',
    'apples' => 'There are many apples',
];
