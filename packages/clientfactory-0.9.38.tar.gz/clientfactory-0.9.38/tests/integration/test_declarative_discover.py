# ~/clientfactory/tests/integration/test_declarative_discover.py 
