# ~/clientfactory/src/clientfactory/core/metas/__init__.py
"""..."""

from .declarative import DeclarativeMeta
from .protocoled import ProtocoledAbstractMeta
