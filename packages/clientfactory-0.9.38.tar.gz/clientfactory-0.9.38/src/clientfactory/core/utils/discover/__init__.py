# ~/clientfactory/src/clientfactory/core/utils/discover/__init__.py
from .binding import createboundmethod
