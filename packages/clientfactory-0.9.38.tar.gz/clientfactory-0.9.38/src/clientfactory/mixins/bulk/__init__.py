# ~/clientfactory/src/clientfactory/mixins/bulk/__init__.py 
