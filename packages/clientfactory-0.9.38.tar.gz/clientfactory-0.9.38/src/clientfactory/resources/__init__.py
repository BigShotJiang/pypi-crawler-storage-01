# ~/clientfactory/src/clientfactory/resources/__init__.py

from .managed import ManagedResource
from .search import SearchResource
from .view import ViewResource
