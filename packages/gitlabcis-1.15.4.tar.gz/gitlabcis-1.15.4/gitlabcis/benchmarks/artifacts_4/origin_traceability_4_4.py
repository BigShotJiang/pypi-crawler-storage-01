# -------------------------------------------------------------------------


def artifact_origin_info(glEntity, glObject, **kwargs):
    """
    id: 4.4.1
    title: Ensure artifacts contain information about their origin
    """

    # We cannot automatically answer this check, therefore we SKIP:
    return {None: 'This check requires validation'}
