
You should create a new Web Application with OAuth credentials in your Github console:
[settings](https://github.com/settings/developers)


For a detailed tutorial on how to do that, please refer to our dedicated
[documentation](https://docs.toucantoco.com/concepteur/power-apps-with-data/02-connectors.html#set-up-oauth2-credentials-for-your-platform)

For callback, you should specify:

 **{{redirect_uri}}**
