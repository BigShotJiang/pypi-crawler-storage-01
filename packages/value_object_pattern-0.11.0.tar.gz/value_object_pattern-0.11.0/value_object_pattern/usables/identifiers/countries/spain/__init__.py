from .dni_value_object import DniValueObject

__all__ = ('DniValueObject',)
