
## 🎁 Feat

✅ 选网站可直接选kemono，单独窗口供后续脚本集扩展，详情看[📒使用指引](https://jasoneri.github.io/ComicGUISpider/feat/script)  
✅ 自定义背景，[配置key](https://jasoneri.github.io/ComicGUISpider/config/#bg-path)  

## 🐞 Fix

✅ 修复包缺失导致的无法运行、kb缓存时间逻辑、内部重启的 division by zero 报错等
