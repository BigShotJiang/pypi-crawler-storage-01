

# Sample Markdown for Testing

This is a simple Markdown file to test the Marksum CLI tool.

## Introduction

Markdown is a lightweight markup language. It is widely used in documentation and readme files.

## Features

- Easy to read
- Easy to write
- Supported by many platforms

## Conclusion

Markdown helps developers write well-structured content with minimal effort.
