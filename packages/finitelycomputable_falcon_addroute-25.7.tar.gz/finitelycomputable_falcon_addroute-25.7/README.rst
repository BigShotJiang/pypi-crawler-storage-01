===============
Falcon-AddRoute
===============

This application provides a /wsgi_info/ endpoint and uses App.add_route() to
combine all of the Falcon modules that it finds in the virtual environment.
