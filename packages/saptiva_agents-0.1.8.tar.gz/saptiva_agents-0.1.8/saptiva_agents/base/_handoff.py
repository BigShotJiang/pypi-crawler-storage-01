from autogen_agentchat.base import Handoff


class Handoff(Handoff):
    pass