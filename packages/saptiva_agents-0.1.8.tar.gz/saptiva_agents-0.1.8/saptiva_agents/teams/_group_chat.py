from autogen_agentchat.teams import RoundRobinGroupChat, Swarm, SelectorGroupChat


class RoundRobinGroupChat(RoundRobinGroupChat):
    pass


class Swarm(Swarm):
    pass


class SelectorGroupChat(SelectorGroupChat):
    pass
