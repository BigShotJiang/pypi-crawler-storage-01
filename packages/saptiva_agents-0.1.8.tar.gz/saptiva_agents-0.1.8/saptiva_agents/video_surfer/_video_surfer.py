from autogen_ext.agents.video_surfer import VideoSurfer


class VideoSurfer(VideoSurfer):
    pass
