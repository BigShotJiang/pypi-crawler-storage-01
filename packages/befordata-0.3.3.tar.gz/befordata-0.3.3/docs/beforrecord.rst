
BeForRecord
============

.. autoclass:: befordata.BeForRecord
   :members:
   :member-order: bysource
