from gmailsorter.google.mail import GoogleMailBase
from gmailsorter.google.authentication import create_service
