from . import _version
from gmailsorter.local import Gmail, load_client_secrets_file

__version__: str = _version.__version__
