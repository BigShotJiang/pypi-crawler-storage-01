def ui_download():
    print("UI download stub: implement if needed.")

def ui_unzip():
    print("UI unzip stub: implement if needed.")

def ui_run():
    print("UI run stub: implement if needed.")
