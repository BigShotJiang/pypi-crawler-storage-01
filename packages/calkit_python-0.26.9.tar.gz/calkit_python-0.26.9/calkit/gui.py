"""An optional GUI."""
