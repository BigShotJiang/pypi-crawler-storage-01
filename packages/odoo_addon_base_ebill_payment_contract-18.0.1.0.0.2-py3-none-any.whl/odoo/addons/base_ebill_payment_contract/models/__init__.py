from . import res_partner
from . import ebill_payment_contract
