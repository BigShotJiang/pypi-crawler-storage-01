To use this module, you need to:

1.  Install a specific e-billing module (None are ready, yet)
