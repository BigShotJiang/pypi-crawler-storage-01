The goal of this module is to be a common ground for ebilling addons. It
adds an ebill.payment.contract attached to a partner. Alone this module
has no purpose. It needs to be installed with a module that implements a
specific ebilling system. This depending module has to implement his own
'transmit.method'.
