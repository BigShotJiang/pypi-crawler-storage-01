# King code

#### A small project to make something a bit more convenient.

[Documentation](https://kcode.readthedocs.io/)
