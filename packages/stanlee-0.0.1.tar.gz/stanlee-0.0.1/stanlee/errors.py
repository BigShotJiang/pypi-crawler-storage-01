class SystemPromptError(Exception):
    pass
