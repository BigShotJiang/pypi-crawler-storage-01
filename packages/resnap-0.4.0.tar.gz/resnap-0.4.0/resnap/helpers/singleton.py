from abc import ABCMeta
from threading import Lock


class SingletonMeta(type):
    "This is a thread-safe implementation of Singleton."

    _instances: dict = {}

    _lock: Lock = Lock()
    "We now have a lock object that will be used to synchronize threads during first access to the Singleton."

    def __call__(cls, *args, **kwargs):
        with cls._lock:
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance
        return cls._instances[cls]


class SingletonABCMeta(ABCMeta, SingletonMeta):
    "Allows combining the functionalities of both metaclasses without conflict."

    pass
