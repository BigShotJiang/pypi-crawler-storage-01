EXT = ".resnap"
META_EXT = f"{EXT}_meta.json"
SEPARATOR = "/"
