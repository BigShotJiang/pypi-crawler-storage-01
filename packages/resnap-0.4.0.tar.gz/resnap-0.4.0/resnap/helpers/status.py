from enum import Enum


class Status(str, Enum):
    SUCCESS = "SUCCESS"
    FAIL = "FAIL"
