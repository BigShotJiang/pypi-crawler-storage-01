DROP FUNCTION IF EXISTS procrastinate_defer_job_v1;
DROP FUNCTION IF EXISTS procrastinate_defer_periodic_job_v1;
