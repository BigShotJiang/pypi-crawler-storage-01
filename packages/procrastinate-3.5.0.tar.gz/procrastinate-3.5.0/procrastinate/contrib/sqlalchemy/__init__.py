from __future__ import annotations

from procrastinate.contrib.sqlalchemy.psycopg2_connector import (
    SQLAlchemyPsycopg2Connector,
)

__all__ = [
    "SQLAlchemyPsycopg2Connector",
]
