# SQLAlchemy contrib package

This contrib package includes extensions for SQLAlchemy.

Currently it just provides an `SQLAlchemyPsycopg2Connector` that can be used in
synchronous applications that already use SQLAlchemy and Psycopg2 for interacting with
the Postgres database (Flask-SQLAlchemy based applications for example).

See the Procrastinate documentation on https://procrastinate.readthedocs.io/ for more
information.
