from __future__ import annotations

from .psycopg2_connector import Psycopg2Connector

__all__ = ["Psycopg2Connector"]
