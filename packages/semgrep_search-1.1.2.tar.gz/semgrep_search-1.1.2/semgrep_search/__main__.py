import sys

from semgrep_search.main import main

sys.exit(main())
