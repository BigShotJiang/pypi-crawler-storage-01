'''用于编辑/获取mediawiki文本的库'''
from .bot import Bot as Bot