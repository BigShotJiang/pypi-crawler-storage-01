class MockAlgorithm:
    pass