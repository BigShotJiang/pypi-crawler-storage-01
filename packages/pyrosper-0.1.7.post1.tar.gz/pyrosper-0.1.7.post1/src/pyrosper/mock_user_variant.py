from .user_variant import UserVariant

class MockUserVariant(UserVariant):
    pass