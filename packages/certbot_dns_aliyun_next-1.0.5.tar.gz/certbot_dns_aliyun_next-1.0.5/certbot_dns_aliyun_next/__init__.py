"""
阿里云DNS插件，用于Certbot的DNS-01验证
"""

__version__ = "1.0.0"