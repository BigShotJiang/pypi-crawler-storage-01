mex -Iinclude -Isrc src/mex/mex_medianFilter.cpp -output medianFilter
