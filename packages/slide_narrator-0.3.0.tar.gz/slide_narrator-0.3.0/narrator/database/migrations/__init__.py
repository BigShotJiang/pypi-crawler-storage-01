"""
Database migrations for Tyler Stores

This directory will contain future database migrations.
For new installations, the schema is created directly from the models.
""" 