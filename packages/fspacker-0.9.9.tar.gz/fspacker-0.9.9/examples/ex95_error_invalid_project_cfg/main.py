def main():
    print("Hello from ex95-invalid-project-cfg!")


if __name__ == "__main__":
    main()
