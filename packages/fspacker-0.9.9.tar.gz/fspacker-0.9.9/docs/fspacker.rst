fspacker package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   fspacker.models
   fspacker.packers
   fspacker.parsers
   fspacker.utils

Submodules
----------

fspacker.cli module
-------------------

.. automodule:: fspacker.cli
   :members:
   :undoc-members:
   :show-inheritance:

fspacker.exceptions module
--------------------------

.. automodule:: fspacker.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

fspacker.settings module
------------------------

.. automodule:: fspacker.settings
   :members:
   :undoc-members:
   :show-inheritance:

fspacker.simplifiers module
---------------------------

.. automodule:: fspacker.simplifiers
   :members:
   :undoc-members:
   :show-inheritance:

fspacker.trackers module
------------------------

.. automodule:: fspacker.trackers
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: fspacker
   :members:
   :undoc-members:
   :show-inheritance:
