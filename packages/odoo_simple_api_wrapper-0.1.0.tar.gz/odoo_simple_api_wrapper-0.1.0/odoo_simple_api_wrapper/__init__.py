from .api import OdooConnector

__all__ = ['OdooConnector']
