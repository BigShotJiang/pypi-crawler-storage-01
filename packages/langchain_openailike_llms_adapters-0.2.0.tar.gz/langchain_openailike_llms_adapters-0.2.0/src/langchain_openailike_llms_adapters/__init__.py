from .adapters import get_openai_like_llm_instance,get_openai_like_embedding


__all__ = ["get_openai_like_llm_instance","get_openai_like_embedding"]

__version__ = "0.2.0"
