# sage_setup: distribution = sagemath-brial

from .all__sagemath_categories import *
