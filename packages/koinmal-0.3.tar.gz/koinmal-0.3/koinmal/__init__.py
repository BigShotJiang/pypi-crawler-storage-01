class koin:
    def all(x=None,y=None):
        return x+y