import kabaret.app.resources as resources
import logging


resources.add_folder('gifs', __file__)
logging.debug('libreflow.flows: GIFS LOADED')
