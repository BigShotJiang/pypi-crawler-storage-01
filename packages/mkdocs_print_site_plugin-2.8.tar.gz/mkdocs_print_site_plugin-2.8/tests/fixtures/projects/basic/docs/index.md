# Homepage

Link to: 
 
- [page a](a.md)
- [page z](z.md)

An to an anchor on page A [link](a.md#anchor-links)

## Subsection

On the homepage

## An image with lazy loading

See https://github.com/timvink/mkdocs-print-site-plugin/issues/60 

![Image title](https://dummyimage.com/600x400/){ loading=lazy }


