# ignored content

This paragraph is not ignored for printing.

<p class='print-site-plugin-ignore'>this paragraph should not print or show up on HTML print page</p>

This is there again

This paragraph will not be part of the print site page.
{: .print-site-plugin-ignore }

You can also use HTML to hide things from printing:
<span class="print-site-plugin-ignore">hello this should not be visible</span>