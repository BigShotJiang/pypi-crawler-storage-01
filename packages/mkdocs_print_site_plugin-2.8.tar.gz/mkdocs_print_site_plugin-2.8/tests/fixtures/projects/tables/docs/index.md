# Testing tables

This site is meant to test print rendering of tables

## Small test

Let's see how a small table renders:

| model | auc  |
|-------|------|
| xgb   | 0.81 |
| lgb   | 0.91 |