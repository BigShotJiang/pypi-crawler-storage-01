# Chapter 1 - Section 2

## Part 2

![](img/Picture1-2.png)

