# Chapter 2 - Section 2


## Some code

``` C
#include <stdio.h>
int main() {
   // printf() displays the string inside quotation
   printf("Hello, World!");
   return 0;
}
```

![](img/Picture2-2.png)
