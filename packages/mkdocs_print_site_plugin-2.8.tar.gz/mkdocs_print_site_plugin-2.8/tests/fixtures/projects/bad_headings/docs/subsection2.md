# Subsec 2

This is a subsection, see https://www.mkdocs.org/user-guide/writing-your-docs/#configure-pages-and-navigation