# Inserting content

Following this guide:
https://squidfunk.github.io/mkdocs-material/reference/abbreviations/#snippets

## content

--8<-- "includes/content.html"

## more content

--8<-- "includes/bla.md"

## content

--8<-- "includes/content.html"