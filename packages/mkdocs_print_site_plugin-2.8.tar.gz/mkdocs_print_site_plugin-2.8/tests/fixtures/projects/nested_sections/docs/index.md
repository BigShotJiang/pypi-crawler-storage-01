# Homepage

Goal of this site is to show a very nested section navigation.

See [mkdocs-print-site-plugin#27](https://github.com/timvink/mkdocs-print-site-plugin/issues/27)