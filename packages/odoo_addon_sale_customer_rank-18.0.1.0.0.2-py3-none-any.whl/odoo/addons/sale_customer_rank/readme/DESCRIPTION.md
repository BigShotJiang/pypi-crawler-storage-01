This module updates customer_rank for partners when creating sale
orders.
