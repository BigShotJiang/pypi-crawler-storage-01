# robotcode-repl-server

[![PyPI - Version](https://img.shields.io/pypi/v/robotcode-repl.svg)](https://pypi.org/project/robotcode-repl-server)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/robotcode-repl.svg)](https://pypi.org/project/robotcode-repl-server)
[![License](https://img.shields.io/github/license/robotcodedev/robotcode?style=flat&logo=apache)](https://github.com/robotcodedev/robotcode/blob/master/LICENSE.txt)

-----

## Introduction

Some classes for [RobotCode](https://robotcode.io) plugin management

## Installation

```console
pip install robotcode-repl-server
```

## License

`robotcode-repl-server` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
