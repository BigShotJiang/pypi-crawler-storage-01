"""Constants."""

from datetime import timedelta

GTFS_STATIC_CACHE = "gtfs_static_cache"
GTFS_STATIC_CACHE_EXPIRY = timedelta(hours=1)
