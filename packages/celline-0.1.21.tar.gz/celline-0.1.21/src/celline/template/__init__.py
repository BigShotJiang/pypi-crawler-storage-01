from celline.template.manager import TemplateManager
