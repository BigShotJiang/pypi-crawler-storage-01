# Minimal setup.py for backward compatibility
# Primary configuration is now in pyproject.toml

from setuptools import setup

setup()
