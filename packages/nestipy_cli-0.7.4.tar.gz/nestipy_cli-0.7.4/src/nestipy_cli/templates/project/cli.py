from nestipy.commander import CommandFactory

from app_module import AppModule

command = CommandFactory.create(AppModule)
