# Contributing

Please feel to contribute to this project. Adding common functions is the intent and if you have one to add or improve an existing it is greatly appreciated.

### Ways to Contribute!
- Add or improve a function
- Add or improve documentation
- Add or improve Tests
- Report or fix a bug
