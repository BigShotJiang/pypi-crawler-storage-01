__path__ = __import__('pkgutil').extend_path(__path__, __name__)
__version__ = '0.0.102'
__yamlversion__ = '0.0.102'
__packagename__ = 'azureml-designer-datatransform-modules'
