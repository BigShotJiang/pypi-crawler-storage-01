..
    Copyright (C) 2023 CESNET.

    CESNET-OpenID-Remote is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

CESNET OIDC Auth backend for OARepo

- Miroslav Bauer <bauer@cesnet.cz>
- Juraj Trappl <trappl@cesnet.cz>
