"""Hyperliquid MCP Server - A Model Context Protocol server for Hyperliquid trading operations."""

__version__ = "0.1.0"
__author__ = "Minh Doan"
__description__ = "MCP server for Hyperliquid trading operations"
