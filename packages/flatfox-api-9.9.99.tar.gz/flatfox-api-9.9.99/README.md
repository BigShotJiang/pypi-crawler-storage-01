# !!! SECURITY RESEARCH PACKAGE !!!  
This package is part of a proof-of-concept dependency confusion attack.  
**DO NOT USE IN PRODUCTION.** Contact me@viktormares.com for details.
