from __future__ import annotations


def test_sample() -> None:
    assert True
