# ver 0.1.5
- 유사도 검증 extract_sim 함수 수정