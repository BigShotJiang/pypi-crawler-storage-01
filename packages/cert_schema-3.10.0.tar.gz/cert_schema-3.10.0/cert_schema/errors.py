class BlockcertValidationError(Exception):
    pass


class InvalidUrlError(Exception):
    pass
