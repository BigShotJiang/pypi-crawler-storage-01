try:
    from finitelycomputable.tests.test_cherrypy_mount import *
except ImportError:
    pass
