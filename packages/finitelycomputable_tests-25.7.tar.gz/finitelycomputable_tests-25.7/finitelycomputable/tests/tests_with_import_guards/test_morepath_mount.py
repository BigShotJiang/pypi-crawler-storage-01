try:
    from finitelycomputable.tests.test_morepath_mount import *
except ImportError:
    pass
