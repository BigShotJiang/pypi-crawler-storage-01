try:
    from finitelycomputable.helloworld_django.tests import *
except ImportError:
    pass
