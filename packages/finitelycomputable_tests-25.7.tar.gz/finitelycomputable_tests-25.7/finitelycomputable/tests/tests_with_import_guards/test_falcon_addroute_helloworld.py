try:
    from finitelycomputable.tests.test_falcon_addroute_helloworld import *
except ImportError:
    pass
