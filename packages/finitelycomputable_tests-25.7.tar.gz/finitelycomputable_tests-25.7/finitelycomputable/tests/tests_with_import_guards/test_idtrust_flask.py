try:
    from finitelycomputable.tests.test_idtrust_flask import *
except ImportError:
    pass
