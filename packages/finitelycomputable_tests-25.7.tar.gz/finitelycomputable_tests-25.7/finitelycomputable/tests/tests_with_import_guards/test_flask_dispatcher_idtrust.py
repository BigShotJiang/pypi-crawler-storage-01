try:
    from finitelycomputable import idtrust_flask
    from finitelycomputable.tests.test_flask_dispatcher_idtrust import *
except ImportError:
    pass
