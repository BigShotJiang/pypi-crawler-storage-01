try:
    from finitelycomputable.tests.test_helloworld_quart import *
except ImportError:
    pass
