try:
    from finitelycomputable.django_apps.tests import *
except ImportError:
    pass
