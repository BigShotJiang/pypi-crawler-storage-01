try:
    from finitelycomputable import idtrust_flask
    from finitelycomputable.tests.test_flask_blueprints_idtrust import *
except ImportError:
    pass
