try:
    from finitelycomputable.tests.test_helloworld_morepath import *
except ImportError:
    pass
