try:
    from finitelycomputable.tests.test_idtrust_falcon import *
except ImportError:
    pass
