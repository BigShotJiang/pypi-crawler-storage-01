try:
    from finitelycomputable.tests.test_helloworld_falcon import *
except ImportError:
    pass
