try:
    from finitelycomputable.tests.test_cherrypy_mount_helloworld import *
except ImportError:
    pass
