try:
    from finitelycomputable.tests.test_flask_blueprints import *
except ImportError:
    pass
