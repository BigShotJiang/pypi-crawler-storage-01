try:
    from finitelycomputable.tests.test_flask_dispatcher import *
except ImportError:
    pass
