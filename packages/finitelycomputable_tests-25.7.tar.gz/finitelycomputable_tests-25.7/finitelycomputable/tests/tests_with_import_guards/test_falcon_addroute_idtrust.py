try:
    from finitelycomputable import idtrust_falcon
    from finitelycomputable.tests.test_falcon_addroute_idtrust import *
except ImportError:
    pass
