try:
    from finitelycomputable.tests.test_helloworld_flask import *
except ImportError:
    pass
