try:
    from finitelycomputable.idtrust_django.tests import *
except ImportError:
    pass
