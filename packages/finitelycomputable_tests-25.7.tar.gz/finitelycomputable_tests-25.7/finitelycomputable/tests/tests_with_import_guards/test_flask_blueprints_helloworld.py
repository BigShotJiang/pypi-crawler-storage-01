try:
    from finitelycomputable.tests.test_flask_blueprints_helloworld import *
except ImportError:
    pass
