try:
    from finitelycomputable.tests.test_flask_dispatcher_helloworld import *
except ImportError:
    pass
