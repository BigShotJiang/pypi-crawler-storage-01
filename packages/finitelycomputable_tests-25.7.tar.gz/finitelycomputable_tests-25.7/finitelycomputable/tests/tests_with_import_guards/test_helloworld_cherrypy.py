try:
    from finitelycomputable.tests.test_helloworld_cherrypy import *
except ImportError:
    pass
