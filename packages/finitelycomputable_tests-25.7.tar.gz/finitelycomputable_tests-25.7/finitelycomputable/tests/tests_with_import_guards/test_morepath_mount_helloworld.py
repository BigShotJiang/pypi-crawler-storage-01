try:
    from finitelycomputable.tests.test_morepath_mount_helloworld import *
except ImportError:
    pass
