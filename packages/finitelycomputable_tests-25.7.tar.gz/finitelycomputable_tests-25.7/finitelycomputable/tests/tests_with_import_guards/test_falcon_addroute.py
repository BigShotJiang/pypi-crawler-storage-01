try:
    from finitelycomputable.tests.test_falcon_addroute import *
except ValueError:
    pass
