import setuptools

setuptools.setup(
    name="state-moseq",
)
