0.2.3 (2025-07-30)
-------------------
- Fix bug in lightcone data loader (https://github.com/ArgonneCPAC/diffsky/pull/195)


0.2.2 (2025-07-17)
-------------------
- Change little h convention of Monte Carlo halo generators (https://github.com/ArgonneCPAC/diffsky/pull/184)


0.2.1 (2025-06-30)
-------------------
- Incorporate synthetic lightcone into mock production pipeline (https://github.com/ArgonneCPAC/diffsky/pull/165)
- Add pipeline to generate lightcone mocks (https://github.com/ArgonneCPAC/diffsky/pull/154)
- Improve accuracy of young-star contribution stellar age PDF (https://github.com/ArgonneCPAC/diffsky/pull/151)
- Implement synthetic lightcones to extend resolution limits (https://github.com/ArgonneCPAC/diffsky/pull/143)


0.2.0 (2025-03-24)
-------------------
- Update population-level photometry models of dust and burstiness


0.1.2 (2024-10-25)
-------------------
- Update calls to diffmah v0.6.1 and diffstar v0.3.2


0.1.1 (2023-10-04)
-------------------
- Update calls to dsps v0.3.4


0.1.0 (2023-10-03)
-------------------
- First release. Compatible with diffstar v0.2.1 and dsps v0.3.3.