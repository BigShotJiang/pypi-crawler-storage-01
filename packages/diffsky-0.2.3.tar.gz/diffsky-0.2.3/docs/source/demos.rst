Diffsky Code Demos
==================

.. toctree::
   :maxdepth: 1
   :caption: Notebooks:

   demo_diffmahpop_t_peak.ipynb
   demo_mc_lightcones.ipynb
