""" """

# flake8: noqa


def test_load_flat_hdf5_imports_top_level_data_loaders():
    from ...data_loaders import load_flat_hdf5
