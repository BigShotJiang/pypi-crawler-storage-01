The io_utils directory contains code used to load SMDPL simulation data
and precompute a few quantities needed to tabulate the CCSHMF