This directory stores pretabulated CCSHMF values computed from the SMDPL simulation
by the diffsubs/scripts/smdpl_cshmf_measurement_script.py script