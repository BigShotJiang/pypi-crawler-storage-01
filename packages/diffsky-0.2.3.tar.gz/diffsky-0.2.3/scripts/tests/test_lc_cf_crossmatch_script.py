""""""


def test_lc_cf_crossmatch_script_imports():
    from .. import lc_cf_crossmatch_script  # noqa
