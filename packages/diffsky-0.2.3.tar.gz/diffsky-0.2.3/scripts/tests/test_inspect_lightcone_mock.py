""""""


def test_inspect_lightcone_mock():
    from .. import inspect_lightcone_mock  # noqa
