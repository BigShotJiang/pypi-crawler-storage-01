If this module is installed with product_contract, the quantity field of
sale order lines won't be displayed.
