SELECT COLTAB1 + 12 AS coltab2
FROM {{dependent}}
