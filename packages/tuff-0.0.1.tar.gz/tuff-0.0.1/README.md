# Tuff - The Ultimate FFmpeg Frontend

This project is currently in planning phase!