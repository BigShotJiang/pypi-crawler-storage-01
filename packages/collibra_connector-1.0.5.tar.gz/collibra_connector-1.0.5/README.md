# Collibra Python Connector

A simple and standard Python connector for interacting with the Collibra Data Governance Center API.

## Installation

```bash
pip install collibra-connector
```