from .staticSynapse import StaticSynapse
from .hebbianSynapse import HebbianSynapse
from .traceSTDPSynapse import TraceSTDPSynapse
