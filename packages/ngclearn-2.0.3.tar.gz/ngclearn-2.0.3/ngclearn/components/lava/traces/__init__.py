from .gatedTrace import GatedTrace
