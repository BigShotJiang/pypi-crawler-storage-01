## patched synaptic components
from .patchedSynapse import PatchedSynapse
from .staticPatchedSynapse import StaticPatchedSynapse
from .hebbianPatchedSynapse import HebbianPatchedSynapse



