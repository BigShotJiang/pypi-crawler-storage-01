from .hebbianSynapse import HebbianSynapse
from .traceSTDPSynapse import TraceSTDPSynapse
from .expSTDPSynapse import ExpSTDPSynapse
from .eventSTDPSynapse import EventSTDPSynapse
from .BCMSynapse import BCMSynapse

