# python-socketio-stubs

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://badge.fury.io/py/python-socketio-stubs.svg)](https://badge.fury.io/py/joblib-stubs)
[![python version](https://img.shields.io/pypi/pyversions/python-socketio-stubs.svg)](#)

Warning: This library provides type hints only.
If you need the runtime package,
you can find it [`python-socketio`](https://github.com/miguelgrinberg/python-socketio).

## how to install
```shell
$ pip install python-socketio-stubs
```

## TODO
* [ ] remove all `Incomplete`
* [ ] tests?

## License

MIT, see [LICENSE](https://github.com/phi-friday/python-socketio-stubs/blob/main/LICENSE).
