"""Request handlers for MCP server operations."""
