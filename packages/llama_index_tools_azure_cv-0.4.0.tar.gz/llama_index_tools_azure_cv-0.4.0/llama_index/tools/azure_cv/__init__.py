## init
from llama_index.tools.azure_cv.base import (
    CV_URL_TMPL,
    AzureCVToolSpec,
)

__all__ = ["AzureCVToolSpec", "CV_URL_TMPL"]
