class ConfigurationError(Exception): pass


class ProjectNotFoundError(Exception):
    pass
class AgentNotFoundError(Exception):
    pass
