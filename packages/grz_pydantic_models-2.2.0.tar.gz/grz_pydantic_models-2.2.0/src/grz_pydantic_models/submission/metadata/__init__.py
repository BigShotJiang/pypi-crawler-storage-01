from .v1 import *  # noqa: F403


def get_accepted_versions() -> set[str]:
    return {"1.2.1"}
