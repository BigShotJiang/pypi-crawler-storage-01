# sample_generated_20250730_01_repo

## Quick start

```bash
pip install sample_generated_20250730_01_repo
```

```python
from sample_generated_20250730_01_package import ...
```

## Contributing

```bash
# clone the repo
git clone https://github.com/momomozhang/sample_generated_20250730_01_repo.git

# install the dev dependencies
make install

# run the tests
make test
```
