"""
用于鉴权（认证）的信息
"""
from typing import Any

type AuthenticationToken = dict[str, Any]
