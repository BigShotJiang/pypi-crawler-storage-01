class ExtractSpectralSignalConfig:
    def __init__(self):
        self.lmax = 60
        pass
