The main purpose of encrypting and decrypting data is to guarantee the confidentiality of the information and prevent
the third parties from viewing private data.
Pre-shared keys may be used when working with large data sets or to protect the confidentiality of an application’s or a
user’s assets.
However, the usage of a hardcoded key increases the possibility of an attacker to decrypt and recover the data in case
of a stolen device.