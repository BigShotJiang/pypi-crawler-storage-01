List of all Process methods used in the application.
