To ensure the flutter code is fully analyzed, please disable obfuscation and rerun the scan.

You can disable obfuscation by re-compiling the application without `--obfuscate` when running `flutter build`