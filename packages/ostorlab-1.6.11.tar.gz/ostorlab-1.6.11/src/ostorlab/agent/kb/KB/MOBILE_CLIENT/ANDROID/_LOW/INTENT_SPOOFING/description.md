Intent Spoofing consists of sending an intent toward an application components (Exported Activity, Broadcast Receiver,
Content Provider, Service) to achieve unauthorized access.

The access may to different objectives like unauthorized data modification
and information leakage, untrusted input injection, etc.
