Android Network Security Configuration enables a declarative setting of the application network security.

When Android Network Security Configuration is missing or configured in an insecure way, it can leave application vulnerable to MiTM.

