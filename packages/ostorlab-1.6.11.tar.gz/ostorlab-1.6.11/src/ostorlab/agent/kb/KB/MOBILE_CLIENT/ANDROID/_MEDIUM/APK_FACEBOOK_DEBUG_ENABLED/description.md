The application is compiled with Facebook SDK debug mode `FacebookSdk.setIsDebugEnabled` enabled. The debug logs contain detailed requests and JSON responses, which might expose sensitive information.

