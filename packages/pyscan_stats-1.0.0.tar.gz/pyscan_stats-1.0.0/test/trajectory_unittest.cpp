
#include "DiskScan.hpp"
#include "Statistics.hpp"
#include "TrajectoryScan.hpp"
#include "Test_Utilities.hpp"

#include <tuple>
#include <limits>
#include <random>
#include <iostream>

#include "gtest/gtest.h"
//
// Created by mmath on 9/14/18.
//
namespace {
    TEST(TrajectorySimplification, matching) {

    }
}