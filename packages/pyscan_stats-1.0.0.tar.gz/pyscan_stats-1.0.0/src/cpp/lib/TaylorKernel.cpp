/*
 * Created by Michael Matheny on 6/16/19.
 * at the University of Utah
 * email: michaelmathen@gmail.com
 * website: https://mmath.dev/
 */

#include "TaylorKernel.hpp"
