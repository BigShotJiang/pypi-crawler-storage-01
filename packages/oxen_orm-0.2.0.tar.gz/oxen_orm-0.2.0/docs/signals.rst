=======
Signals
=======

There are four signals that defined now, they will be send by models.

.. automodule:: tortoise.signals
    :members:
    :undoc-members:
    :show-inheritance:
