==========
Exceptions
==========


.. automodule:: tortoise.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

