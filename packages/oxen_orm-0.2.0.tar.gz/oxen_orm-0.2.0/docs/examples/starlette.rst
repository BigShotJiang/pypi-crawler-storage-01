.. _example_starlette:

=================
Starlette Example
=================

This is an example of the  :ref:`contrib_starlette`

**Usage:**

.. code-block:: sh

    python3 main.py


models.py
=========
.. literalinclude::  ../../examples/starlette/models.py

main.py
=======
.. literalinclude::  ../../examples/starlette/main.py


