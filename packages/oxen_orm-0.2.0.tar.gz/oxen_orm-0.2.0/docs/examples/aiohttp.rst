.. _example_aiohttp:

===============
AIOHTTP Example
===============

This is an example of the  :ref:`contrib_aiohttp`

**Usage:**

.. code-block:: sh

    python3 main.py


models.py
=========
.. literalinclude::  ../../examples/aiohttp/models.py

main.py
=======
.. literalinclude::  ../../examples/aiohttp/main.py


