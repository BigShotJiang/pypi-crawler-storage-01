🚀 OxenORM: Python ORM with Rust speed!

15× faster than SQLAlchemy
30× faster for image processing
Built-in file handling
Memory safe with Rust

Familiar Django syntax + C++ performance!

pip install oxen-orm
https://github.com/Diman2003/OxenORM

#Python #Rust #ORM #Performance 