Tortoise-ORM Starlette example
==========================

We have a lightweight integration util ``tortoise.contrib.starlette`` which has a single function ``register_tortoise`` which sets up Tortoise-ORM on startup and cleans up on teardown.

Usage
-----

.. code-block:: sh

    python3 main.py
