## MTBS

#### Little lib to interact with Metabase


https://chatgpt.com/c/6851260c-747c-8003-904f-7d33b0d9cbdf
uv pip install --upgrade build twine
uv run python -m build
uv run twine upload dist/*