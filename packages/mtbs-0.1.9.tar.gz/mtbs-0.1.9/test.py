

from mtbs.mtbs import Mtbs


if __name__ == "__main__":
    mm = Mtbs()
    print(mm.databases_list())