"""Geos API Package.

Classes:
    GeosAPI: Represents Signal's Geos API.
"""

from .geos_api import GeosAPI

__all__ = ["GeosAPI"]
