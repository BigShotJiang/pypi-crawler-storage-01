# Storage Class

::: filesizelib.storage.Storage
    options:
      show_root_heading: true
      show_source: false
      show_signature_annotations: true
      members_order: source
      docstring_style: google
      merge_init_into_class: true
      filters:
        - "!^_"