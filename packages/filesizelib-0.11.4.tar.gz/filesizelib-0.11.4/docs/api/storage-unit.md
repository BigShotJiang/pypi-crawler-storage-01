# StorageUnit Enum

::: filesizelib.storage_unit.StorageUnit
    options:
      show_root_heading: true
      show_source: false
      show_signature_annotations: true
      members_order: source
      docstring_style: google
      filters:
        - "!^_"