"""
Test suite for the bytesize library.

This package contains comprehensive tests for all bytesize functionality
including unit tests, integration tests, and platform-specific tests.
"""