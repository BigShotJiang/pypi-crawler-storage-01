"""Initialize the app"""

__version__ = "0.0.5"
__title__ = "MIL Industry"
