from llama_index.readers.pdf_table.base import PDFTableReader

__all__ = ["PDFTableReader"]
