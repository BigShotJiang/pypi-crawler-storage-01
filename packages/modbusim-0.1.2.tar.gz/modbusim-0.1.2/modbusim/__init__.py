"""
ModbusIM - A Modbus device simulator for testing and development.
"""

__version__ = "0.1.0"

from .simulator import ModbusSimulator

__all__ = ["ModbusSimulator"]
