from polars_root.functions import (
    read_root,
    scan_root,
)

__version__ = "0.1.1"

__all__ = [
    "read_root",
    "scan_root",
]
