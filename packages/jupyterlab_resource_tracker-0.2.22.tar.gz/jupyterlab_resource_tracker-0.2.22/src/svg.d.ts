// src/svg.d.ts
declare module '*.svg' {
  const content: string;
  export default content;
}
