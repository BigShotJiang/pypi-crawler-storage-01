# Copyright 2023 ACSONE SA/NV
from . import test_model
