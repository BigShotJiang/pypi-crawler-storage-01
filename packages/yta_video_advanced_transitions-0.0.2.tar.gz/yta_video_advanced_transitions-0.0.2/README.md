# Youtube Autonomous Advanced Video Transitions Module

The Youtube Autonomous Advanced Video Transitions module.

Please, check the 'pyproject.toml' file to see the dependencies.
