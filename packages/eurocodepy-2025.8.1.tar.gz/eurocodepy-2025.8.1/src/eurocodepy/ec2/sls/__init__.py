# Copyright (c) 2024 Paulo Cachim
# SPDX-License-Identifier: MIT

from .shrinkage import shrink_strain
from .creep import creep_coef