=======
Credits
=======

Development Lead
----------------

* Anowar J. Shajib, |mail| ajshajib@gmail.com, |github| `ajshajib <https://github.com/ajshajib/>`_



Co-developers
-------------

* Nafis Sadik Nihal, |github| `pensive-aristocrat <https://github.com/pensive-aristocrat>`_
* Chin Yi Tan, |github| `chinyitan <https://github.com/chinyitan>`_


Contributors
------------

* Vedant Sahu, |github| `Vedant-Sahu <https://github.com/Vedant-Sahu>`_
* Simon Birrer, |github| `sibirrer <https://github.com/sibirrer>`_


.. |mail| image:: https://raw.githubusercontent.com/primer/octicons/refs/heads/main/icons/mail-16.svg?sanitize=true
   :alt: mail

.. |github| image:: https://raw.githubusercontent.com/primer/octicons/refs/heads/main/icons/mark-github-16.svg?sanitize=true
   :alt: github
