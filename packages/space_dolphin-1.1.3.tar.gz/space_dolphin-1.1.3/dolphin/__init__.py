# -*- coding: utf-8 -*-
__author__ = "Anowar J. Shajib"
__email__ = "ajshajib@gmail.com"
__version__ = "1.1.3"
