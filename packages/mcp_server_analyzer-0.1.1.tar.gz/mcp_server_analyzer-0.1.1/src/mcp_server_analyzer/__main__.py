#!/usr/bin/env python3
"""Main entry point for the MCP Python Analyzer server."""

from mcp_server_analyzer.server import main

if __name__ == "__main__":
    main()
