"""MCP Server Analyzer - A Model Context Protocol server for Python code analysis."""

__version__ = "0.1.1"
__author__ = "MCP Python Analyzer Team"
__email__ = "contact@example.com"

__all__ = ["__author__", "__email__", "__version__"]
