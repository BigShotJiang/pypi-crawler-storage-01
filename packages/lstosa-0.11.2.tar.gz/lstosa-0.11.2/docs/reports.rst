.. _reports:

Reports
=======
Functions to report on processing status and managing the history files.

Reference/API
+++++++++++++

.. automodapi:: osa.report