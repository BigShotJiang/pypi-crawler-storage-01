.. _nightsummary:

Night summary
=============
Functions to read the night summary files and extract the run sequences.

Reference/API
+++++++++++++

.. automodapi:: osa.nightsummary.nightsummary
.. automodapi:: osa.nightsummary.extract
