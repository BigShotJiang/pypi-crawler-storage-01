from pygamefwk.event import Event

on_reset = Event()
"""맵이 변경될시 실행"""