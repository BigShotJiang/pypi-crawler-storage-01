#  mscore/__init__.py
#
#  Copyright 2024 liyang <liyang@veronica>
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#
"""
A python library for opening/inspecting/modifying MuseScore3 files.
"""
import os, sys, logging, configparser, glob, io
import xml.etree.ElementTree as et
from zipfile import ZipFile
from pathlib import Path
from copy import deepcopy
from sf2utils.sf2parse import Sf2File
from console_quiet import ConsoleQuiet
from node_soso import SmartNode, dump

__version__ = "1.1.0"

CHANNEL_NAMES = [	'normal', 'open', 'mute', 'arco', 'tremolo', 'crescendo',
					'marcato', 'staccato', 'flageoletti', 'slap', 'pop', 'pizzicato']


# ----------------------------
# MuseScore classes

class Part(SmartNode):

	def instrument(self):
		return Instrument.from_element(self.find('Instrument'))

	def use_instrument(self, instrument):
		if not isinstance(instrument, Instrument):
			raise ValueError('Can only copy Instrument')
		new_instrument_node = deepcopy(instrument.element)
		old_instrument_node = self.find('Instrument')
		self.element.remove(old_instrument_node)
		self.element.insert(len(self.element), new_instrument_node)

	def staffs(self):
		return Staff.from_elements(self.findall('Staff'))

	@property
	def name(self):
		return self.element_text('trackName')

	def __str__(self):
		return f'<Part "{self.name}">'


class Instrument(SmartNode):

	def channels(self):
		return Channel.from_elements(self.findall('Channel'))

	@property
	def name(self):
		name = self.element_text('longName')
		if name is None:
			name = self.element_text('trackName')
		return name

	def musicxml_id(self):
		return self.element_text('instrumentId')

	def clear_synth(self):
		for channel in self.findall('Channel'):
			for node in channel.findall('controller'):
				channel.remove(node)
			for node in channel.findall('program'):
				channel.remove(node)
			for node in channel.findall('synti'):
				channel.remove(node)

	def remove_channel(self, name):
		node = self.find(f'Channel[@name="{name}"]')
		if node:
			self.element.remove(node)

	def add_channel(self, name, midi_port = 0, midi_channel = 0):
		"""
		Returns Channel
		"""
		if self.find(f'Channel[@name="{name}"]'):
			raise RuntimeError(f'Channel "{name}" already exists')
		new_channel_node = et.SubElement(self.element, 'Channel')
		new_channel_node.set('name', name)
		port_node = et.SubElement(new_channel_node, 'midiPort')
		port_node.text = str(int(midi_port) - 1)
		channel_node = et.SubElement(new_channel_node, 'midiChannel')
		channel_node.text = str(int(midi_channel) - 1)

	def __str__(self):
		return f'<Instrument "{self.name}">'


class Channel(SmartNode):

	CC_VOLUME		= 7;
	CC_PAN			= 10;
	CC_BANK_MSB		= 0;
	CC_BANK_LSB		= 32;

	def program(self):
		el = self.find('program')
		return None if el is None else el.attrib['value']

	def bank_msb(self):
		msb = self.controller_value(self.CC_BANK_MSB)
		return -1 if msb is None else msb

	def bank_lsb(self):
		lsb = self.controller_value(self.CC_BANK_LSB)
		return -1 if lsb is None else lsb

	def controller_value(self, ccid):
		el = self.find('controller[@ctrl="%s"]' % ccid)
		return None if el is None else el.attrib['value']

	def idstring(self):
		return '%02d:%02d:%02d' % (
			int(self.bank_msb()),
			int(self.bank_lsb()),
			int(self.program())
		)

	@property
	def name(self):
		return self.attribute_value('name', 'normal')

	@property
	def midi_port(self):
		"""
		Always returns the public (1-based) channel number.
		"""
		text = self.element_text('midiPort')
		return -1 if text is None else int(text) + 1

	@midi_port.setter
	def midi_port(self, value):
		"""
		"value" must be the public (1-based) channel number.
		The actual node value is set to one less.
		"""
		node = self.find('midiPort')
		if node is None:
			node = et.SubElement(self.element, 'midiPort')
		node.text = str(int(value) - 1)

	@property
	def midi_channel(self):
		"""
		Always returns the public (1-based) channel number.
		"""
		text = self.element_text('midiChannel')
		return -1 if text is None else int(text) + 1

	@midi_channel.setter
	def midi_channel(self, value):
		"""
		"value" must be the public (1-based) channel number.
		The actual node value is set to one less.
		"""
		node = self.find('midiChannel')
		if node is None:
			node = et.SubElement(self.element, 'midiChannel')
		node.text = str(int(value) - 1)

	def __str__(self):
		return f'<Channel "{self.name}">'


class Staff(SmartNode):

	@property
	def color(self):
		"""
		Returns a dictionary of RBG values.
		"""
		node = self.find('color')
		return None if node is None else {
			'r'	: node.attrib['r'],
			'g'	: node.attrib['g'],
			'b'	: node.attrib['b'],
			'a'	: node.attrib['a']
		}

	@color.setter
	def color(self, rgba_dict):
		"""
		Set the color of this Staff.
		rgba_dict must be a dict containing "r", "g", "b" and "a" keys, having integer
		values in the range 0 - 255.
		"""
		node = self.child('color')
		node.set('r', str(rgba_dict['r']))
		node.set('g', str(rgba_dict['g']))
		node.set('b', str(rgba_dict['b']))
		node.set('a', str(rgba_dict['a']))

	@property
	def id(self):
		return self.attribute_value('id')

	def __str__(self):
		return f'<Staff "{self.id}">'


class Score():

	__default_sfnames = None
	__user_sfpaths = None
	__sys_sfpaths = None
	__sf2s = {}

	__zip_entries = None
	__zip_mscx_index = None

	USER_SF2 = 0
	SYSTEM_SF2 = 1
	MISSING_SF2 = 3

	def __init__(self, filename):
		self.filename = filename
		self.ext = os.path.splitext(filename)[-1]
		if self.ext == '.mscx':
			self.tree = et.parse(filename)
		elif self.ext == '.mscz':
			with ZipFile(self.filename, 'r') as zipfile:
				self.__zip_entries = [
					{
						'info'	:info,
						'data'	:zipfile.read(info.filename)
					} for info in zipfile.infolist()
				]
			for idx in range(len(self.__zip_entries)):
				if os.path.splitext(self.__zip_entries[idx]['info'].filename)[-1] == '.mscx':
					self.__zip_mscx_index = idx
					break
			if self.__zip_mscx_index is None:
				raise Exception("No mscx entries found in zip file")
			with io.BytesIO(self.__zip_entries[self.__zip_mscx_index]['data']) as bob:
				self.tree = et.parse(bob)
		else:
			raise Exception("Unsupported file extension: " + self.ext)

	def save_as(self, filename):
		self.filename = filename
		self.save()

	def save(self):
		if self.ext == '.mscx':
			self.tree.write(self.filename, xml_declaration=True, encoding='utf-8')
		elif self.ext == '.mscz':
			with io.BytesIO() as bob:
				self.tree.write(bob)
				self.__zip_entries[self.__zip_mscx_index]['data'] = bob.getvalue()
			with ZipFile(self.filename, 'w') as zipfile:
				for entry in self.__zip_entries:
					zipfile.writestr(entry['info'], entry['data'])

	def dump(self):
		dump(self.tree.getroot())

	def find(self, path):
		return self.tree.find(path)

	def findall(self, path):
		return self.tree.findall(path)

	def parts(self):
		return Part.from_elements(self.findall('./Score/Part'))

	def instruments(self):
		return Instrument.from_elements(self.findall('./Score/Part/Instrument'))

	def channels(self):
		return Channel.from_elements(self.findall('./Score/Part/Instrument/Channel'))

	def staffs(self):
		for part in self.parts():
			yield from part.staffs()

	def part(self, name):
		for p in self.parts():
			if p.name == name:
				return p

	def part_names(self):
		return [ p.name for p in self.parts() ]

	def duplicate_part_names(self):
		a = self.part_names()
		return [ name for name in list(set(a)) if a.count(name) > 1]

	def has_duplicate_part_names(self):
		return len(self.duplicate_part_names()) > 0

	def instrument_names(self):
		return [ p.instrument().name for p in self.parts() ]

	def sound_fonts(self):
		return list(set( el.text for el in self.findall('.//Synthesizer/Fluid/val') ))

	@classmethod
	def default_sound_fonts(cls):
		if cls.__default_sfnames is None:
			filename = os.path.join(str(Path.home()), '.local/share/MuseScore/MuseScore3/synthesizer.xml')
			cls.__default_sfnames = [ node.text for node in et.parse(filename).findall('.//Fluid/val') ]
		return cls.__default_sfnames

	@classmethod
	def ini_file(cls):
		"""
		Returns a ConfigParser object.
		May be used like this:

		cp = Score.ini_file()
		for section in cp.sections():
			print(f'Section "{section}"')
			for option in cp.options(section):
				print(f'  Option "{option}"')
		"""
		filename = os.path.join(str(Path.home()), '.config/MuseScore/MuseScore3.ini')
		config = configparser.ConfigParser()
		config.read(filename)
		return config

	@classmethod
	def user_soundfont_dirs(cls):
		return cls.ini_file()['application']['paths\mySoundfonts'].strip('"').split(';')

	@classmethod
	def system_soundfont_dirs(cls):
		return ['/usr/share/sounds/sf2']

	@classmethod
	def _iter_sf_paths(cls, dirs):
		for d in dirs:
			yield from glob.glob(f'{d}/*.sf2')

	@classmethod
	def user_soundfonts(cls):
		return list(cls._iter_sf_paths(cls.user_soundfont_dirs()))

	@classmethod
	def system_soundfonts(cls):
		return list(cls._iter_sf_paths(cls.system_soundfont_dirs()))

	@classmethod
	def sf2(cls, sf_name):
		if cls.__user_sfpaths is None:
			cls.__user_sfpaths = { os.path.basename(path):path for path in cls.user_soundfonts() }
			cls.__sys_sfpaths = { os.path.basename(path):path for path in cls.system_soundfonts() }
		if sf_name not in cls.__sf2s:
			if sf_name in cls.__user_sfpaths:
				logging.debug('Inspecting user soundfont "%s"', sf_name)
				cls.__sf2s[sf_name] = cls._get_parsed_sf2(cls.__user_sfpaths[sf_name])
			elif sf_name in cls.__sys_sfpaths:
				logging.debug('Inspecting user system "%s"', sf_name)
				cls.__sf2s[sf_name] = cls._get_parsed_sf2(cls.__sys_sfpaths[sf_name])
			else:
				raise Exception('SoundFont "%s" not found', sf_name)
		return cls.__sf2s[sf_name]

	@classmethod
	def _get_parsed_sf2(cls, filename):
		with open(filename, 'rb') as file:
			with ConsoleQuiet():
				return Sf2File(file)

	@classmethod
	def is_score(cls, filename):
		return os.path.splitext(filename)[-1] in ['.mscx', '.mscz']

	def __str__(self):
		return f'<Score "{self.filename}">'


#  end mscore/__init__.py
