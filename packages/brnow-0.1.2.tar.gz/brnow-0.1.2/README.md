# BRNOW_PLUGINS

Este pacote fornece uma interface simplificada para uso do TTS via `g-cloud-texttospeech`, encapsulado.

## Instalação

```bash
pip install brnow
