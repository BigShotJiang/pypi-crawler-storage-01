Para instalar esta funcionalidde, simplesmente instale o módulo e faça
as devidas configurações.
