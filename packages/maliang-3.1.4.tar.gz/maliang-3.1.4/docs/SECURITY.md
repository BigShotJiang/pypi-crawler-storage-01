---
icon: material/lock
---

--8<-- "SECURITY.md:3"
