---
comments: true
status: new
---

以下是目前收集到的有关 `maliang` 的第三方扩展包：

### 1. `maliang-extensions`

Extensions for Maliang

GitHub: https://github.com/TempAccountOfMuxue1230/maliang-extensions  
Author: https://github.com/TempAccountOfMuxue1230

![关注](https://img.shields.io/github/watchers/TempAccountOfMuxue1230/maliang-extensions?label=Watchers&logo=github&style=flat "关注")
![复刻](https://img.shields.io/github/forks/TempAccountOfMuxue1230/maliang-extensions?label=Forks&logo=github&style=flat "复刻")
![星标](https://img.shields.io/github/stars/TempAccountOfMuxue1230/maliang-extensions?label=Stars&color=gold&logo=github&style=flat "星标")
![议题](https://img.shields.io/github/issues/TempAccountOfMuxue1230/maliang-extensions?label=Issues&logo=github&style=flat "议题")
![拉取请求](https://img.shields.io/github/issues-pr/TempAccountOfMuxue1230/maliang-extensions?label=Pull%20Requests&logo=github&style=flat "拉取请求")
![讨论](https://img.shields.io/github/discussions/TempAccountOfMuxue1230/maliang-extensions?label=Discussions&logo=github&style=flat "讨论")
