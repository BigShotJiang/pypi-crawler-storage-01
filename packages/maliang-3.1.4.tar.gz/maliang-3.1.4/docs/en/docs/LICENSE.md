---
icon: material/scale-balance
---

--8<-- "docs/LICENSE.md:4"
