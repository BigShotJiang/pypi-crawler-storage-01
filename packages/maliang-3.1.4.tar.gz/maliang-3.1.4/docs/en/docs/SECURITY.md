---
icon: material/lock
---

--8<-- "docs/SECURITY.md:4"
