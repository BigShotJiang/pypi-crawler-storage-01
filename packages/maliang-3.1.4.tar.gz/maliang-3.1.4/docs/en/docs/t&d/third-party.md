---
comments: true
status: new
---

The following are the third-party extensions packs for `maliang` that have been collected so far:

### 1. `maliang-extensions`

Extensions for Maliang

GitHub: https://github.com/TempAccountOfMuxue1230/maliang-extensions  
Author: https://github.com/TempAccountOfMuxue1230

![Watchers](https://img.shields.io/github/watchers/TempAccountOfMuxue1230/maliang-extensions?label=Watchers&logo=github&style=flat "Watchers")
![Forks](https://img.shields.io/github/forks/TempAccountOfMuxue1230/maliang-extensions?label=Forks&logo=github&style=flat "Forks")
![Stars](https://img.shields.io/github/stars/TempAccountOfMuxue1230/maliang-extensions?label=Stars&color=gold&logo=github&style=flat "Stars")
![Issues](https://img.shields.io/github/issues/TempAccountOfMuxue1230/maliang-extensions?label=Issues&logo=github&style=flat "Issues")
![Pull Requests](https://img.shields.io/github/issues-pr/TempAccountOfMuxue1230/maliang-extensions?label=Pull%20Requests&logo=github&style=flat "Pull Requests")
![Discussions](https://img.shields.io/github/discussions/TempAccountOfMuxue1230/maliang-extensions?label=Discussions&logo=github&style=flat "Discussions")
