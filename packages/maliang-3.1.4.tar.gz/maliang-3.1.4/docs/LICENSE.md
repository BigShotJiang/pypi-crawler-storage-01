---
icon: material/scale-balance
---

--8<-- "LICENSE.txt"
