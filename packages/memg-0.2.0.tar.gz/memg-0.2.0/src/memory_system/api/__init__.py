"""API layer for Personal Memory System"""
