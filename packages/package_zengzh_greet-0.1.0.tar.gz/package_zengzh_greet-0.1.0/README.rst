#Example code:  
```python
print("Hello, world!")        # This is a comment