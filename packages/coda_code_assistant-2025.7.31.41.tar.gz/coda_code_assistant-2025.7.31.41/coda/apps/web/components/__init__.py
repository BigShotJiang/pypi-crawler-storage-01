"""Reusable UI components for the web interface."""
