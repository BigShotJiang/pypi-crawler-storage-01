"""Tests for codebase intelligence functionality."""
