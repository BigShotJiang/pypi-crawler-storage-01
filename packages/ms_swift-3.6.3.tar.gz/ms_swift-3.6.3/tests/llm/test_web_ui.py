from swift.llm import WebUIArguments
from swift.ui import webui_main

if __name__ == '__main__':
    webui_main(WebUIArguments())
