# Copyright (c) Alibaba, Inc. and its affiliates.
import os

from swift.llm import sft_main

if __name__ == '__main__':
    sft_main()
