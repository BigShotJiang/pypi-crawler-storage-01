# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.save import Save


class GRPOSave(Save):

    group = 'llm_grpo'
