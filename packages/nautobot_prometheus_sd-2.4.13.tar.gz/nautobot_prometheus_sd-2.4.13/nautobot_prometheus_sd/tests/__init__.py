"""Unit tests for netbox_prometheus_sd plugin."""
