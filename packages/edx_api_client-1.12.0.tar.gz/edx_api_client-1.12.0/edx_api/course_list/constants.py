"""edX api course list constants"""

PAGE_SIZE = 100
BATCH_SIZE = 100
