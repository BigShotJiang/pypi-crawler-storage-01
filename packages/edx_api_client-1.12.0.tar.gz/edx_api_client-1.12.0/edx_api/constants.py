"""edX api client constants"""

ENROLLMENT_MODE_AUDIT = 'audit'
ENROLLMENT_MODE_VERIFIED = 'verified'
