class CourseRunAPIError(Exception):
    """Base class for all course run related exceptions."""

    pass
