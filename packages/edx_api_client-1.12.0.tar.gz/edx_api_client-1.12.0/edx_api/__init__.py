"""
edX python REST API client
"""

__version__ = "1.12.0"
DEFAULT_TIME_OUT = 25
