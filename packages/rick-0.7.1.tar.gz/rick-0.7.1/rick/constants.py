RICK_VERSION = ["0", "7", "1"]


def get_version():
    return ".".join(RICK_VERSION)
