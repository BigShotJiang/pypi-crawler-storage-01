from .cache import CacheInterface, CacheNull
