from rick.base import Di


class Runnable:
    def run(self, di: Di):
        pass
