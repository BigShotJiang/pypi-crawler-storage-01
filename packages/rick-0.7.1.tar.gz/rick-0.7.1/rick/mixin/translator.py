class Translator:
    def t(self, text: str) -> str:
        return text
