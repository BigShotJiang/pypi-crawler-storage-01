from .hasher import HasherInterface
