from rick.mixin.injectable import Injectable


class EventHandler(Injectable):
    pass
