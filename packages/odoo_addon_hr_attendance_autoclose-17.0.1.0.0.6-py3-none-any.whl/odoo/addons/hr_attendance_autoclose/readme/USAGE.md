1.  Go to *Attendances \> Configuration \> Configuration*.
2.  Set the maximum number of hours allowed for an attendance.
3.  Go to *Attendances \> Manage Attendances \> Attendances*.
4.  Attendance are automatically closed if they have remained open for
    longer than specified in the setting.
