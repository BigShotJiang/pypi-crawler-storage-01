- Aaron Henriquez \<<ahforgeflow@forgeflow.com>\>

- Kitti U. \<<kittiu@ecosoft.co.th>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Víctor Martínez

- Foram Shah \<<foram.shah@initos.com>\>
