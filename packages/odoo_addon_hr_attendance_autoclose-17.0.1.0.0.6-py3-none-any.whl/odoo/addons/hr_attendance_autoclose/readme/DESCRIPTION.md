This module close stale attendances automatically. Without this module,
when an employee forgets to check out at the end on the day and the next
day the employee does not realize of that, then the error is propagated
and all the attendances are wrong. With this module only the attendance
with the issue is wrong, and the manager knows the system closes the
attendance, not the employee
