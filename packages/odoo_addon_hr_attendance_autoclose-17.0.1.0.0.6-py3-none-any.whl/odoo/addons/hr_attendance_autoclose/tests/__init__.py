from . import test_hr_attendance_auto_close
