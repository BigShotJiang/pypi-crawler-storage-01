from . import hr_attendance
from . import hr_employee
from . import res_company
from . import res_config_settings
