"""

MOJIZA V:0.1.3

"""


__VERSION__ = '0.1.3'