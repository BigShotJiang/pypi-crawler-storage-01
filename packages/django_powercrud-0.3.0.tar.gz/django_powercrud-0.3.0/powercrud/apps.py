from django.apps import AppConfig

class PowerCRUDConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "powercrud"
    verbose_name = "PowerCRUD"
