---------------------------------------
Publish the latest tag as a new release
---------------------------------------

.. literalinclude:: ../../../templates/project-release/template.yml
   :language: yaml