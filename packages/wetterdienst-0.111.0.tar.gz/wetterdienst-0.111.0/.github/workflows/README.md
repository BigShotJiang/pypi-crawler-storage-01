Check out the guide that was used to create the CI environment including setting up the yaml files:

- https://medium.com/@cjolowicz/hypermodern-python-d44485d9d769
- https://cjolowicz.github.io/posts/hypermodern-python-01-setup/

- https://docs.github.com/en/actions/creating-actions/creating-a-docker-container-action
- https://docs.github.com/en/actions/creating-actions/dockerfile-support-for-github-actions
- https://docs.github.com/en/actions/guides/publishing-docker-images
