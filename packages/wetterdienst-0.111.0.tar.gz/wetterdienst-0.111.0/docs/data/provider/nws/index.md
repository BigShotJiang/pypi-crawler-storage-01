# NWS (National Weather Service)

## Overview

## License

The NOAA NWS Observations cover recent data (last week) of the US. The 
[description](https://www.weather.gov/documentation/services-web-api) page
includes more information on the usage, references, qualities etc.

```{toctree}
:hidden:

observation/index.md
```