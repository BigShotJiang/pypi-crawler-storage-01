# Observation

## Overview

NOAA NWS Observation is a collection of **hourly** weather data from US weather stations. Resolution is fixed on hourly
and data is provided for the last week.

> [!WARNING]
> Currently we use a somewhat not correct list of stations. For some stations no data may be returned, as they 
> actually don't exist in the NWS Observation network!

```{toctree}
:hidden:

hourly.md
```