# IMGW (Instytut Meteorologii i Gospodarki Wodnej)

## Overview

## License

Declaration of availability [here](https://imgw.pl/deklaracja-dostepnosci)

```{toctree}
:hidden:

hydrology/index.md
meteorology/index.md
```