# Machinery

## DWD (German Weather Service)

```{autodoc2-object} wetterdienst.provider.dwd.mosmix.access.KMLReader
render_plugin = "myst"
no_index = true
```