"""
Docker2 plugin for yaapp framework using CustomExposer.
Provides dynamic Docker API exposure with hierarchical paths.
"""