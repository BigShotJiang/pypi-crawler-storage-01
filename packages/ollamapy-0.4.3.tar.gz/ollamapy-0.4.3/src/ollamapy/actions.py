"""Action functions that the AI can choose to execute."""


def yes():
    """Print yes with emoji."""
    print("✅ YES!")


def no():
    """Print no with emoji."""
    print("❌ NO!")