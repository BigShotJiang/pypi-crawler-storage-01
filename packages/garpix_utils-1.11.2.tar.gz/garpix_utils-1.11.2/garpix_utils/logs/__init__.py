import warnings

warnings.warn(
    "Модуль garpix_utils.logs устарел. Используйте garpix_utils.cef_logs вместо него.",
    DeprecationWarning,
    stacklevel=2,
)
