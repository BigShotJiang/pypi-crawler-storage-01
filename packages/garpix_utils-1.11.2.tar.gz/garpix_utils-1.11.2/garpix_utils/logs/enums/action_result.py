from enum import Enum


class ActionResultDefault(Enum):
    success = "Успешно"
    error = "Ошибка"
