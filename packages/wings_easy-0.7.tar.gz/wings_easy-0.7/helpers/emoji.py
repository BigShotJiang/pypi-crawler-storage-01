# 💀 ☠  💥 😤  😡  👻  👽  💩  🤖  ❤  💭  💫  🫰 👆 👇  👈   👉  🫵  👎  👍  👏    👀   🎗  🚫  ⛔  ⚠  ❗ ❓ ❌ ✔
# ⭕  ㊙
from data_struct import Level

if __name__ == "__main__":
    structs = {
        Level.e: [],
        1: [],
        2: [],
        3: [],
    }
    structs[Level.e].append("0")
    structs[3].append("2")
    structs[1].append("2")
    print(structs)

    for t in structs:
        print(t)
