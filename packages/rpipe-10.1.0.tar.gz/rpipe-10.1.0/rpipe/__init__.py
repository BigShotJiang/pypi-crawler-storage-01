__version__: str = "10.1.0"  # Must be "<major>.<minor>.<patch>", all numbers
