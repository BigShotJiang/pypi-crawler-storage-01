from rlite.train.utils.handle_parallel import (
    prepare_parallel_args,
    prepare_parallel_kwargs
)

__all__ = [
    "prepare_parallel_args",
    "prepare_parallel_kwargs",
]
