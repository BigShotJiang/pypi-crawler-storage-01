Resource Management
===================

Specify the Acceptable Node By IP
---------------------------------


Specify Colocation Relationship
-------------------------------


Specify Non-Colocation Relationship
-----------------------------------


Useful Interfaces Provided by Resource Manager
----------------------------------------------
