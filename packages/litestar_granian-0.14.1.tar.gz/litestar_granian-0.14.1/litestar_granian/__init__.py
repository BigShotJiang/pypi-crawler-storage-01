from __future__ import annotations

from litestar_granian.__metadata__ import __project__, __version__
from litestar_granian.plugin import GranianPlugin

__all__ = ("GranianPlugin", "__project__", "__version__")
