# Copyright 2024 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""mindformers init"""
import os
from mindspore import mint, ops
from mindspore.common import dtype as mstype
from mindspore.nn import Adam, SGD
from mindspore.nn.optim.optimizer import Optimizer
from mindspore.experimental.optim.adamw import SpeedAdamW

from mindformers.core.optim import Came
from mindformers.core.optim import AdamW as mf_AdamW
from mindformers.experimental.parallel_core.pynative.register import ModuleType, ModuleRegistry
from mindformers.experimental.parallel_core.pynative.distributed import DistributedDataParallel
from mindformers.parallel_core.inference.parallel_state import get_data_parallel_group
from mindformers.experimental.parallel_core.pynative.dist_checkpointing import get_checkpoint_name
from mindformers.experimental.parallel_core.pynative.optimizer.lr_scheduler import get_learning_rate_scheduler

from mindformers.experimental.parallel_core.pynative.optimizer import zero
from mindformers.experimental.parallel_core.pynative.optimizer import lr_scheduler
from mindformers.experimental.parallel_core.pynative.optimizer.distrib_optimizer import DistributedOptimizer
from mindformers.experimental.parallel_core.pynative.optimizer.optimizer import MixedPrecisionOptimizer
from mindformers.experimental.parallel_core.pynative.optimizer.optimizer import Float16OptimizerWithFloat16Params
from mindformers.experimental.parallel_core.pynative.optimizer.optimizer import get_optimizer_param_scheduler

__all__ = [
    "DistributedOptimizer", "MixedPrecisionOptimizer", "Float16OptimizerWithFloat16Params", \
    "get_optimizer", "get_optimizer_param_scheduler"
]
__all__.extend(zero.__all__)
__all__.extend(lr_scheduler.__all__)


ModuleRegistry.register(mf_AdamW, ModuleType.OPTIMIZER)
ModuleRegistry.register(Adam, ModuleType.OPTIMIZER)
ModuleRegistry.register(SGD, ModuleType.OPTIMIZER)
ModuleRegistry.register(Came, ModuleType.OPTIMIZER)
ModuleRegistry.register(mint.optim.AdamW, ModuleType.OPTIMIZER, item_name='mint.AdamW')
ModuleRegistry.register(SpeedAdamW, ModuleType.OPTIMIZER, item_name='SpeedAdamW')


def get_ditributed_optimizer(optimizer, optimizer_config, training_config, model_chunks):
    " warp non-parallel optimizer with distributed optimizer. "
    if model_chunks is None:
        raise ValueError("When using DistributedOptimizer based on DDP, network instance should be passed "
                         "to get_optimizer method but got None.")
    per_model_buffers = {}
    per_model_ep_buffers = {}
    for model_idx, model_chunk in enumerate(model_chunks):
        if not isinstance(model_chunk, DistributedDataParallel):
            raise TypeError("When using DistribtedOptimizer, the network passed to get_optimizer should be "
                            "wrapped with DistributedDataParallel.")
        per_model_buffers[model_idx] = model_chunk.buffers
        per_model_ep_buffers[model_idx] = model_chunk.expert_parallel_buffers
    grad_scaler = None if not training_config.loss_scale \
        else ops.Tensor(training_config.loss_scale, mstype.float32)
    distributed_optimizer = DistributedOptimizer(
        optimizer=optimizer,
        config=optimizer_config,
        grad_scaler=grad_scaler,
        init_state_fn=None,
        per_model_buffers=per_model_buffers,
        data_parallel_group=get_data_parallel_group(with_context_parallel=True),
    )
    ckpt_file, _ = get_checkpoint_name(os.path.join(training_config.output_dir, 'opt_shard_info'),
                                       format='json', prefix='dist_opt_shard_info', epoch_num=0, step_num=0)

    distributed_optimizer.save_opt_shard_strategy(ckpt_file)

    return distributed_optimizer


def get_non_distributed_mixed_precision_optimizer(optimizer, optimizer_config, training_config):
    " warp non-parallel optimizer with Float16OptimizerWithFloat16Params optimizer. "
    grad_scaler = None if not training_config.loss_scale \
        else ops.Tensor(training_config.loss_scale, mstype.float32)
    optimizer = Float16OptimizerWithFloat16Params(
        optimizer,
        optimizer_config,
        grad_scaler=grad_scaler,
        init_state_fn=None,
        wrap_with_ddp=training_config.wrap_with_ddp,
    )
    return optimizer


def _set_group_lr_and_weight_decay(optimizer_config, params, lr, weight_decay):
    if isinstance(params[0], dict) and not optimizer_config.optimizer_type.startswith("mint") \
        and not optimizer_config.optimizer_type.startswith("Speed"):
        using_group_lr = any("lr" in param for param in params)
        for param in params:
            if "order_params" not in param:
                if "lr" not in param and using_group_lr:
                    param["lr"] = lr
                if "weight_decay" not in param:
                    param["weight_decay"] = weight_decay


def _append_order_param_group(params, network, optimizer_cls):
    """
    Append 'order_params' parameter group to params when a user invokes
    'get_optimizer' with parameter groups and intends to create a
    subclass instance of mindspore.nn.optim.Optimizer.

    NOTE: mindspore.nn.optim.Optimizer assumes that 'order_params' contains
    the original parameter list of network and arranges its parameter list
    following the order of 'order_params'.
    """
    if issubclass(optimizer_cls, Optimizer) and \
        isinstance(params, list) and \
        all(isinstance(t, dict) and "params" in t for t in params):
        if network is None:
            raise ValueError("Network must be provided when using built-in "
                             "mindspore.nn.optim.Optimizer")
        params.append({"order_params": network.trainable_params()})
    return params


def _prepare_optimizer_kwargs(optimizer_config, params, network, optimizer_cls, kwargs):
    ''' prepare optimizer kwargs for optimizer '''
    weight_decay = optimizer_config.weight_decay

    if optimizer_config.learning_rate_scheduler_kwargs is not None:
        learning_rate = get_learning_rate_scheduler(optimizer_config)
    else:
        learning_rate = optimizer_config.learning_rate

    _set_group_lr_and_weight_decay(optimizer_config, params, learning_rate, weight_decay)

    optimizer_kwargs = optimizer_config.get_needed_params_for_class(optimizer_cls)
    if optimizer_config.optimizer_type.startswith("mint") or optimizer_config.optimizer_type.startswith("Speed"):
        optimizer_kwargs["lr"] = learning_rate
        optimizer_kwargs["betas"] = tuple(optimizer_kwargs["betas"])
    else:
        optimizer_kwargs["learning_rate"] = learning_rate
    optimizer_kwargs["weight_decay"] = weight_decay
    optimizer_kwargs["params"] = params
    if "grad_allreduce_op" in kwargs:
        if optimizer_config.zero_without_ddp:
            optimizer_kwargs["grad_allreduce_op"] = kwargs["grad_allreduce_op"]
        kwargs.pop("grad_allreduce_op", None)
    if optimizer_config.zero_without_ddp:
        if network is None:
            raise ValueError("Network must be provided when get ZeRO optimizer instance.")
        optimizer_kwargs["zero_level"] = optimizer_config.parallel_config.zero_level
        optimizer_kwargs["network"] = network
        if optimizer_config.zero_config is not None:
            optimizer_kwargs.update(optimizer_config.zero_config)
    optimizer_kwargs.update(kwargs)
    return optimizer_kwargs


def get_optimizer(optimizer_config, training_config, params=None, network=None, return_instance: bool = True, **kwargs):
    """
    Get an optimizer instance or class based on the provided optimizer configuration.

    Args:
        optimizer_config (OptimizerConfig): The configuration object for the optimizer.
        training_config (TrainingConfig): The configuration object for the training.
        params (list or dict, optional): The parameters to optimize. Default: ``None``.
        network (nn.Cell, optional): The network model, should be provided when use ZeRO optimizer. Default: ``None``.
        return_instance (bool): Whether to return an instance of the optimizer with extra optimizer arguments.
            Default: ``True``.
        **kwargs: Additional keyword arguments to be passed to the optimizer class.

    Returns:
        Optimizer instance, an instance of the optimizer class if `return_instance` is ``True``,
        otherwise the optimizer class itself.

    Raises:
        RuntimeError: If `zero_without_ddp` in `optimizer_config` is ``False`` and `zero_level` in
            `optimizer_config.parallel_config` is ``z3`` and `use_distributed_optimizer` in `training_config` is
            ``Fasle``.
        ValueError: If `return_instance` is ``True`` and `params` is ``None``.
        NotImplementedError: If `return_instance` is ``True`` and `weight_decay_kwargs` in `optimizer_config` is not
            ``None``.

    Examples:
        >>> from mindformers.experimental.parallel_core.pynative.optimizer import get_optimizer
        >>> from mindformers.experimental.parallel_core.pynative.training import get_model
        >>> from mindformers.experimental.parallel_core import get_language_model
        >>> from mindformers.experimental.parallel_core.pynative.training.utils import set_weight_decay
        >>> from mindformers.experimental.parallel_core.pynative.config import init_configs_from_yaml
        >>> def model_provider_func(model_config, pre_process=True, post_process=True):
        ...     network_with_loss, _ = get_language_model(config=model_config, num_tokentypes=0,
        ...         add_pooler=False, encoder_attn_mask_type=None, pre_process=pre_process, post_process=post_process)
        ...     return network_with_loss
        >>> config_file = "/path/to/config/file"
        >>> all_config = init_configs_from_yaml(config_file)
        >>> training_config = all_config.training_config
        >>> optimizer_config = all_config.optimizer_config
        >>> network_with_loss = get_model(model_provider_func, training_config)
        >>> group_params = set_weight_decay(network_with_loss.trainable_params(), optimizer_config.weight_decay)
        >>> optimizer = get_optimizer(optimizer_config, training_config, group_params, network_with_loss,
        >>>                           grad_allreduce_op=training_config.loss_reduction)
    """
    optimizer_config.zero_without_ddp = optimizer_config.parallel_config.zero_level is not None and \
        not training_config.wrap_with_ddp

    optimizer_type = optimizer_config.optimizer_type

    if optimizer_config.zero_without_ddp:
        optimizer_type = optimizer_type + "ZeRO"

    elif optimizer_config.parallel_config.zero_level == 'z3' and not training_config.use_distributed_optimizer:
        raise RuntimeError("For zero3 with DDP, use_distributed_optimizer must be on. Please check the configuration.")

    optimizer_cls = ModuleRegistry.get_item(module_type=ModuleType.OPTIMIZER, item_name=optimizer_type)
    if not return_instance:
        return optimizer_cls

    if params is None:
        raise ValueError("params must be provided when return_instance is True.")

    params = _append_order_param_group(params, network, optimizer_cls)

    if optimizer_config.weight_decay_kwargs is not None:
        raise NotImplementedError("weight_decay_kwargs is not supported yet.")

    optimizer_kwargs = _prepare_optimizer_kwargs(optimizer_config, params, network, optimizer_cls, kwargs)
    return_item = optimizer_cls(**optimizer_kwargs)
    if training_config.wrap_with_ddp and training_config.use_distributed_optimizer:
        return_item = get_ditributed_optimizer(
            return_item,
            optimizer_config,
            training_config,
            network,
        )
    elif training_config.fp16 or training_config.bf16:
        return_item = get_non_distributed_mixed_precision_optimizer(
            return_item,
            optimizer_config,
            training_config,
        )
    return return_item
