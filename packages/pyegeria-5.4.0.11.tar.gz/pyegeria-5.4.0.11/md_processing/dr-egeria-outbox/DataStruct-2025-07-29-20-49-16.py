[
    {
        "Display Name": "",
        "Qualified Name": " [DataStruct::TBDF-Incoming Weekly Measurement Data](#3e4bc9a1-2661-4d24-a753-b26060c61e34) ",
        "Category": "",
        "Description": "This describes the weekly measurement data for each patient for the Teddy Bear drop foot clinical trial."
    }
]