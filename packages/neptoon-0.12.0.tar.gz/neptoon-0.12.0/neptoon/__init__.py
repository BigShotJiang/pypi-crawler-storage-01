from .hub import CRNSDataHub


VERSION = 'v0.12.0'

__version__ = VERSION
