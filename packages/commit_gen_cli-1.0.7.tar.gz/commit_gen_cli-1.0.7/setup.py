#!/usr/bin/env python3
"""
Setup script for Commit-Gen.
"""

from setuptools import setup

if __name__ == "__main__":
    setup() 