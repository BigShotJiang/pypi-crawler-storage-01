from typing import Dict


Metadata = Dict[str, str]
