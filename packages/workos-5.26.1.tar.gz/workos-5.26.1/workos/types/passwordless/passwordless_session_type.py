from typing import Literal

PasswordlessSessionType = Literal["MagicLink"]
