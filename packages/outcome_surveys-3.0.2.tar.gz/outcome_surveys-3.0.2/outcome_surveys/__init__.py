"""
Outcome Surveys.
"""

__version__ = '3.0.2'

default_app_config = 'outcome_surveys.apps.OutcomeSurveysConfig'  # pylint: disable=invalid-name
