"""Scale definition files packaged with AnnaAgent."""
