RED = "\033[31m"  # Red text
WHITE = "\033[37m"  # White text
GREEN = "\033[32m"  # Green text
