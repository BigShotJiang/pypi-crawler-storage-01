from ......Internal.Core import Core
from ......Internal.CommandsGroup import CommandsGroup
from ......Internal import Conversions
from ...... import repcap


# noinspection PyPep8Naming,PyAttributeOutsideInit,SpellCheckingInspection
class PositionCls:
	"""Position commands group definition. 1 total commands, 0 Subgroups, 1 group commands"""

	def __init__(self, core: Core, parent):
		self._core = core
		self._cmd_group = CommandsGroup("position", core, parent)

	def set(self, vertical_pos: float, annotation=repcap.Annotation.Default) -> None:
		"""SCPI: DISPlay:ANNotation:ARRow<*>:VERTical:POSition \n
		Snippet: driver.display.annotation.arrow.vertical.position.set(vertical_pos = 1.0, annotation = repcap.Annotation.Default) \n
		Sets the vertical position of the lower point of the arrow annotation. See also 'Defining the position of the annotation'. \n
			:param vertical_pos: In % of the screen
			:param annotation: optional repeated capability selector. Default value: Ix1 (settable in the interface 'Annotation')
		"""
		param = Conversions.decimal_value_to_str(vertical_pos)
		annotation_cmd_val = self._cmd_group.get_repcap_cmd_value(annotation, repcap.Annotation)
		self._core.io.write(f'DISPlay:ANNotation:ARRow{annotation_cmd_val}:VERTical:POSition {param}')

	def get(self, annotation=repcap.Annotation.Default) -> float:
		"""SCPI: DISPlay:ANNotation:ARRow<*>:VERTical:POSition \n
		Snippet: value: float = driver.display.annotation.arrow.vertical.position.get(annotation = repcap.Annotation.Default) \n
		Sets the vertical position of the lower point of the arrow annotation. See also 'Defining the position of the annotation'. \n
			:param annotation: optional repeated capability selector. Default value: Ix1 (settable in the interface 'Annotation')
			:return: vertical_pos: In % of the screen"""
		annotation_cmd_val = self._cmd_group.get_repcap_cmd_value(annotation, repcap.Annotation)
		response = self._core.io.query_str(f'DISPlay:ANNotation:ARRow{annotation_cmd_val}:VERTical:POSition?')
		return Conversions.str_to_float(response)
