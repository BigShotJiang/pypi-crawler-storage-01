from ....Internal.Core import Core
from ....Internal.CommandsGroup import CommandsGroup
from ....Internal import Conversions
from .... import repcap


# noinspection PyPep8Naming,PyAttributeOutsideInit,SpellCheckingInspection
class FftLengthCls:
	"""FftLength commands group definition. 1 total commands, 0 Subgroups, 1 group commands"""

	def __init__(self, core: Core, parent):
		self._core = core
		self._cmd_group = CommandsGroup("fftLength", core, parent)

	def get(self, spectrum=repcap.Spectrum.Default) -> int:
		"""SCPI: CALCulate:SPECtrum<*>:FFTLength \n
		Snippet: value: int = driver.calculate.spectrum.fftLength.get(spectrum = repcap.Spectrum.Default) \n
		No command help available \n
			:param spectrum: optional repeated capability selector. Default value: Nr1 (settable in the interface 'Spectrum')
			:return: fft_length: No help available"""
		spectrum_cmd_val = self._cmd_group.get_repcap_cmd_value(spectrum, repcap.Spectrum)
		response = self._core.io.query_str(f'CALCulate:SPECtrum{spectrum_cmd_val}:FFTLength?')
		return Conversions.str_to_int(response)
