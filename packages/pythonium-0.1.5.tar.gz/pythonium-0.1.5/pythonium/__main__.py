#!/usr/bin/env python3
"""
Main entry point for Pythonium when run as a module.
"""

from pythonium.main import main

if __name__ == "__main__":
    main()
