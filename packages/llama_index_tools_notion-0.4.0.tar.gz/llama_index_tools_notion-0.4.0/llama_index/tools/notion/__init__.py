"""Notion tool spec."""

from llama_index.tools.notion.base import (
    NotionToolSpec,
)

__all__ = [
    "NotionToolSpec",
]
