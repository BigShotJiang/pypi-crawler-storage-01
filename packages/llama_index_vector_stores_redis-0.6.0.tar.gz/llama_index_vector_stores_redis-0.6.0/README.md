# LlamaIndex Vector_Stores Integration: Redis
