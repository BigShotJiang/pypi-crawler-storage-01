..
    Copyright (C) 2015 CERN.
    Copyright (C) 2025 Ubiquity Press.

    Invenio-Collections is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

=====================
 Invenio-Collections
=====================

.. image:: https://github.com/inveniosoftware/invenio-collections/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-collections/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-collections.svg
        :target: https://github.com/inveniosoftware/invenio-collections/releases

.. image:: https://img.shields.io/pypi/dm/invenio-collections.svg
        :target: https://pypi.python.org/pypi/invenio-collections

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-collections.svg
        :target: https://github.com/inveniosoftware/invenio-collections/blob/master/LICENSE

Invenio module for organizing metadata into collections.

Further documentation is available on
https://invenio-collections.readthedocs.io/
