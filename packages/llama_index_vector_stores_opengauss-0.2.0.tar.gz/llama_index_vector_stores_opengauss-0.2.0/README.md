# LlamaIndex Vector_Stores Integration: openGauss
