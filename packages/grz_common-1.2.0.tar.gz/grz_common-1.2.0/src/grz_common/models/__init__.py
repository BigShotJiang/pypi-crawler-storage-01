"""
Model classes for grz applications.
"""
