IMPORT_ERROR_MESSAGE = (
    "To enable evaluation of language models, the arize module must be installed with "
    "extra dependencies. Run: pip install 'arize[NLP_Metrics]'."
)
