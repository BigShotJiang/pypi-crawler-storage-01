from .views import setup_admin_routes

__all__ = ['setup_admin_routes']