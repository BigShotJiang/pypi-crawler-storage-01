from sonolus.script.runtime import scaled_time


def update_spawn():
    return scaled_time()
