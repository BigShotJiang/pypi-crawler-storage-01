# sonolus.script.archetype

::: sonolus.script.archetype
    options:
        inherited_members: true