### INTENTION and CONTEXT
Fix the steps for Scenario `{Scenario Name}` in `{Feature File}` as described in task `{Task Name}`
