# TODO: logging
# 兼容loguru {}惰性加载
# 时间/大小轮转
# 并发写安全
# 插入trace-id等
