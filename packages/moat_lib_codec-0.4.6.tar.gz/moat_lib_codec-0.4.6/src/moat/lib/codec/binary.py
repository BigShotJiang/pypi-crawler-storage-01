"Alternate name for the no-op codec"

from __future__ import annotations
from .noop import Codec  # noqa:F401
