## 使用方法：
pip install kxy-framework
```python
from kxy.framework import SUtil

# 比较两个列表，返回删除的列表和新增的列表







