// ---------- Declare submodules  ----------

pub mod formula_utils;
pub mod general_utils;
// TBD: Implement a util that holds the predict() function, which can take
// data and a model class(already fitted of course), and return value(s)