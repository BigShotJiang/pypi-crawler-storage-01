Set up extra headers for emails sent by a given Mail Server.
