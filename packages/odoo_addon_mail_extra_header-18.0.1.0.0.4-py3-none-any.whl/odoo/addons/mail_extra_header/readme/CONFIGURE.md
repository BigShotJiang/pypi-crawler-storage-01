There's a new field in the Mail Server model: Extra Headers.

This field takes a Python dictionary expression as value, e.g. `{"MY-HEADER": "test"}`.
