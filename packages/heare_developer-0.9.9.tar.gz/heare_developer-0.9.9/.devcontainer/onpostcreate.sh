#!/usr/bin/env bash
curl -LsSf https://astral.sh/uv/install.sh | sh
uv pip install -e .