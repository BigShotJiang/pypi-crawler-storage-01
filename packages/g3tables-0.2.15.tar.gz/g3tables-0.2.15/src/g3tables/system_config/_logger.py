import logging


logger = logging.getLogger('g3tables.system_config')
