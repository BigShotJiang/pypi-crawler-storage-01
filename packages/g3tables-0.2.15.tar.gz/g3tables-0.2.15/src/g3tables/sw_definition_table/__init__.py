from ._table import SWDefinitionTable
from ._table import SWDefinitionModule as SWDefinitionTableModuleParser


__all__ = ['SWDefinitionTable', 'SWDefinitionTableModuleParser']
