from langchain_anthropic import ChatAnthropic

model = ChatAnthropic(model_name="claude-sonnet-4-20250514", max_tokens=64000)
