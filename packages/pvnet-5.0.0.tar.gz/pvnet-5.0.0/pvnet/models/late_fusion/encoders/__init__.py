"""Submodels to encode satellite and NWP inputs"""
