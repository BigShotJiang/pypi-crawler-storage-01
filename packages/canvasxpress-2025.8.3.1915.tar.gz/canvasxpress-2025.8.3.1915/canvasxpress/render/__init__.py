"""
The render package provides functionality for rendering CanvasXpress objects in
containers or environments
"""
