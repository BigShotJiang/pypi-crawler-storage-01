"""
The js package provides functionality for integrating custom Javascript with
CanvasXpress charts.
"""
