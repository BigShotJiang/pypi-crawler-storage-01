"""
The config package provides functionality for managing or assigning
configuration values associated with CanvasXpress objects.
"""
