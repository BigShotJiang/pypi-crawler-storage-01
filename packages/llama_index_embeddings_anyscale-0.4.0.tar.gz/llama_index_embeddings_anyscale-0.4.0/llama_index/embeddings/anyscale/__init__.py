from llama_index.embeddings.anyscale.base import AnyscaleEmbedding

__all__ = ["AnyscaleEmbedding"]
