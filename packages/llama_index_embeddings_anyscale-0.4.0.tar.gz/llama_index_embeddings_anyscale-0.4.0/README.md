# LlamaIndex Embeddings Integration: Anyscale
