# catchery

Python Error Handler.

## Installation

YouYou can install `catchery` using pip:

```bash
pip install catchery
```

## Usage

Coming soon...

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.
