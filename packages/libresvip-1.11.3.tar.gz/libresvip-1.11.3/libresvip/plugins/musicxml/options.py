from pydantic import BaseModel


class InputOptions(BaseModel):
    pass


class OutputOptions(BaseModel):
    pass
