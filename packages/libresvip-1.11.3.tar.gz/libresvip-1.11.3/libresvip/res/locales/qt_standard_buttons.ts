<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="en_US">
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Yes to All</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>No to All</translation>
    </message>
</context>
</TS>
