import os

__version__ = "1.11.3"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
