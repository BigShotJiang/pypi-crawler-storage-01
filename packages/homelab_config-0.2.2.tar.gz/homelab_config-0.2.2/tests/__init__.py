"""Test package for homelab_config."""
