from django.contrib import admin

# DevTools has no models to register in admin
# This file is maintained for compatibility 