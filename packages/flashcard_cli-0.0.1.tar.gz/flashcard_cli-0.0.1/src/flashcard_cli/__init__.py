# -*- coding: utf-8 -*-
"""
Initialize package flashcard
"""
