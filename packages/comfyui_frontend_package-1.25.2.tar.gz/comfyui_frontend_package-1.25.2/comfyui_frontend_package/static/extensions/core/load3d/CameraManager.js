// Shim for extensions/core/load3d/CameraManager.ts
export const CameraManager = window.comfyAPI.CameraManager.CameraManager;
