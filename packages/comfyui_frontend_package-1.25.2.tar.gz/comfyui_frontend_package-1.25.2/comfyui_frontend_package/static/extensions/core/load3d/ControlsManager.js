// Shim for extensions/core/load3d/ControlsManager.ts
export const ControlsManager = window.comfyAPI.ControlsManager.ControlsManager;
