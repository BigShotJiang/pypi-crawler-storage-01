// Shim for extensions/core/load3d/RecordingManager.ts
export const RecordingManager = window.comfyAPI.RecordingManager.RecordingManager;
