// Shim for scripts/fluxKontextEditNode.ts
export const ensureGraphHasFluxKontextGroupNode = window.comfyAPI.fluxKontextEditNode.ensureGraphHasFluxKontextGroupNode;
export const addFluxKontextGroupNode = window.comfyAPI.fluxKontextEditNode.addFluxKontextGroupNode;
