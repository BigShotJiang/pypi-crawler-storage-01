"""Prompt building module for Browser Copilot"""

from .builder import PromptBuilder

__all__ = ["PromptBuilder"]
