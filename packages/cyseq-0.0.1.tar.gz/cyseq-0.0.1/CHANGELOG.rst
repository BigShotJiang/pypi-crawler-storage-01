Changelog
=========


v0.0.1
------

*2025-07-31* -- Initial release.
