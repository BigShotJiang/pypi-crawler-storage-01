cyseq
=====

This library is a Cython version of scancode-toolkit's ``licensedcode.seq``.
