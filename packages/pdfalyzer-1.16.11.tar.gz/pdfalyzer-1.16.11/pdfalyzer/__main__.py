from pdfalyzer import pdfalyze

pdfalyze()
