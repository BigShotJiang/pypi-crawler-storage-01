from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.abstract_job_result_job_type import AbstractJobResultJobType
from qubicon.api.types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.direct_to_process_import_file_progress import DirectToProcessImportFileProgress


T = TypeVar("T", bound="JobProcessOfflineImportResult")


@_attrs_define
class JobProcessOfflineImportResult:
    """
    Attributes:
        job_type (Union[Unset, AbstractJobResultJobType]):
        result (Union[Unset, DirectToProcessImportFileProgress]):
    """

    job_type: Union[Unset, AbstractJobResultJobType] = UNSET
    result: Union[Unset, "DirectToProcessImportFileProgress"] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        job_type: Union[Unset, str] = UNSET
        if not isinstance(self.job_type, Unset):
            job_type = self.job_type.value

        result: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.result, Unset):
            result = self.result.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if job_type is not UNSET:
            field_dict["jobType"] = job_type
        if result is not UNSET:
            field_dict["result"] = result

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.direct_to_process_import_file_progress import DirectToProcessImportFileProgress

        d = src_dict.copy()
        _job_type = d.pop("jobType", UNSET)
        job_type: Union[Unset, AbstractJobResultJobType]
        if isinstance(_job_type, Unset):
            job_type = UNSET
        else:
            job_type = AbstractJobResultJobType(_job_type)

        _result = d.pop("result", UNSET)
        result: Union[Unset, DirectToProcessImportFileProgress]
        if isinstance(_result, Unset):
            result = UNSET
        else:
            result = DirectToProcessImportFileProgress.from_dict(_result)

        job_process_offline_import_result = cls(
            job_type=job_type,
            result=result,
        )

        job_process_offline_import_result.additional_properties = d
        return job_process_offline_import_result

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
