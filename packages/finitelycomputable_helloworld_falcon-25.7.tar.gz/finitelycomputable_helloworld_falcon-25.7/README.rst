=================
HelloWorld-Falcon
=================

finitelycomputable.helloworld_falcon provides a hello_world endpoint using
the Falcon framework wherever it is mounted.
