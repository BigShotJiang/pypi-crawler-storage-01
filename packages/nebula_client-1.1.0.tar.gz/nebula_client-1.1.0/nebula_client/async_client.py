import json
from typing import Any, AsyncGenerator, Optional

import httpx
from httpx import AsyncClient, ConnectError, RequestError, Response

from .exceptions import NebulaClientException, NebulaException
from .base.base_client import BaseClient


class NebulaAsyncClient(BaseClient):
    """Asynchronous client for the Nebula API."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: float = 300.0,
        custom_client=None,
    ):
        super().__init__(base_url, api_key, timeout)
        self.client = custom_client or AsyncClient(timeout=timeout)

    async def _make_request(self, method: str, endpoint: str, version: str = "v3", **kwargs):
        """Make HTTP request to the API."""
        url = self._get_full_url(endpoint, version)
        request_args = self._prepare_request_args(endpoint, **kwargs)

        try:
            response = await self.client.request(method, url, **request_args)
            await self._handle_response(response)
            
            if "application/json" in response.headers.get("Content-Type", ""):
                return response.json() if response.content else None
            else:
                return response.content

        except ConnectError as e:
            raise NebulaClientException(
                message="Unable to connect to the server. Check your network connection and the server URL."
            ) from e
        except RequestError as e:
            raise NebulaException(
                message=f"Request failed: {str(e)}",
                status_code=500,
            ) from e

    async def _handle_response(self, response: Response) -> None:
        """Handle API response and raise exceptions for errors."""
        if response.status_code >= 400:
            try:
                error_content = response.json()
                if isinstance(error_content, dict):
                    message = (
                        error_content.get("detail", {}).get("message", str(error_content))
                        if isinstance(error_content.get("detail"), dict)
                        else error_content.get("detail", str(error_content))
                    )
                else:
                    message = str(error_content)
            except Exception:
                message = response.text or f"HTTP {response.status_code}"

            raise NebulaException(
                message=message,
                status_code=response.status_code,
            )

    async def close(self):
        """Close the async client."""
        await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    async def get(self, endpoint: str, version: str = "v3", **kwargs):
        """Make a GET request to the API."""
        return await self._make_request("GET", endpoint, version, **kwargs)

    async def post(self, endpoint: str, version: str = "v3", **kwargs):
        """Make a POST request to the API."""
        return await self._make_request("POST", endpoint, version, **kwargs)

    async def put(self, endpoint: str, version: str = "v3", **kwargs):
        """Make a PUT request to the API."""
        return await self._make_request("PUT", endpoint, version, **kwargs)

    async def delete(self, endpoint: str, version: str = "v3", **kwargs):
        """Make a DELETE request to the API."""
        return await self._make_request("DELETE", endpoint, version, **kwargs)

    def set_api_key(self, api_key: str) -> None:
        """Set the API key for authentication."""
        self.api_key = api_key

    def set_base_url(self, base_url: str) -> None:
        """Set the base URL for API requests."""
        self.base_url = base_url
