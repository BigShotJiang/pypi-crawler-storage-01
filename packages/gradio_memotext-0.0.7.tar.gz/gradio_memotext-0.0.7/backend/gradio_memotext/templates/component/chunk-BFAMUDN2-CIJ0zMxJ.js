import { _ as a, d as o } from "./mermaid.core-D9A36DYx.js";
var d = /* @__PURE__ */ a((t, e) => {
  let n;
  return e === "sandbox" && (n = o("#i" + t)), (e === "sandbox" ? o(n.nodes()[0].contentDocument.body) : o("body")).select(`[id="${t}"]`);
}, "getDiagramElement");
export {
  d as g
};
