var Bm = Object.defineProperty;
var kc = (n) => {
  throw TypeError(n);
};
var zm = (n, e, t) => e in n ? Bm(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var ee = (n, e, t) => zm(n, typeof e != "symbol" ? e + "" : e, t), Hm = (n, e, t) => e.has(n) || kc("Cannot " + t);
var wc = (n, e, t) => e.has(n) ? kc("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t);
var xi = (n, e, t) => (Hm(n, e, "access private method"), t);
const {
  SvelteComponent: qm,
  append_hydration: yl,
  assign: Vm,
  attr: Ne,
  binding_callbacks: Um,
  children: qr,
  claim_element: of,
  claim_space: lf,
  claim_svg_element: Mo,
  create_slot: jm,
  detach: Ft,
  element: af,
  empty: vc,
  get_all_dirty_from_scope: Wm,
  get_slot_changes: Km,
  get_spread_update: Gm,
  init: Jm,
  insert_hydration: ii,
  listen: Ym,
  noop: Xm,
  safe_not_equal: Zm,
  set_dynamic_element_data: Ec,
  set_style: G,
  space: cf,
  svg_element: Fo,
  toggle_class: ve,
  transition_in: uf,
  transition_out: df,
  update_slot_base: Qm
} = window.__gradio__svelte__internal;
function Dc(n) {
  let e, t, r, i, s;
  return {
    c() {
      e = Fo("svg"), t = Fo("line"), r = Fo("line"), this.h();
    },
    l(o) {
      e = Mo(o, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var l = qr(e);
      t = Mo(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), qr(t).forEach(Ft), r = Mo(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), qr(r).forEach(Ft), l.forEach(Ft), this.h();
    },
    h() {
      Ne(t, "x1", "1"), Ne(t, "y1", "9"), Ne(t, "x2", "9"), Ne(t, "y2", "1"), Ne(t, "stroke", "gray"), Ne(t, "stroke-width", "0.5"), Ne(r, "x1", "5"), Ne(r, "y1", "9"), Ne(r, "x2", "9"), Ne(r, "y2", "5"), Ne(r, "stroke", "gray"), Ne(r, "stroke-width", "0.5"), Ne(e, "class", "resize-handle svelte-239wnu"), Ne(e, "xmlns", "http://www.w3.org/2000/svg"), Ne(e, "viewBox", "0 0 10 10");
    },
    m(o, l) {
      ii(o, e, l), yl(e, t), yl(e, r), i || (s = Ym(
        e,
        "mousedown",
        /*resize*/
        n[27]
      ), i = !0);
    },
    p: Xm,
    d(o) {
      o && Ft(e), i = !1, s();
    }
  };
}
function eg(n) {
  var d;
  let e, t, r, i, s;
  const o = (
    /*#slots*/
    n[31].default
  ), l = jm(
    o,
    n,
    /*$$scope*/
    n[30],
    null
  );
  let a = (
    /*resizable*/
    n[19] && Dc(n)
  ), c = [
    { "data-testid": (
      /*test_id*/
      n[11]
    ) },
    { id: (
      /*elem_id*/
      n[6]
    ) },
    {
      class: r = "block " + /*elem_classes*/
      (((d = n[7]) == null ? void 0 : d.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      n[20] ? "rtl" : "ltr"
    }
  ], u = {};
  for (let f = 0; f < c.length; f += 1)
    u = Vm(u, c[f]);
  return {
    c() {
      e = af(
        /*tag*/
        n[25]
      ), l && l.c(), t = cf(), a && a.c(), this.h();
    },
    l(f) {
      e = of(
        f,
        /*tag*/
        (n[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = qr(e);
      l && l.l(h), t = lf(h), a && a.l(h), h.forEach(Ft), this.h();
    },
    h() {
      Ec(
        /*tag*/
        n[25]
      )(e, u), ve(
        e,
        "hidden",
        /*visible*/
        n[14] === !1
      ), ve(
        e,
        "padded",
        /*padding*/
        n[10]
      ), ve(
        e,
        "flex",
        /*flex*/
        n[1]
      ), ve(
        e,
        "border_focus",
        /*border_mode*/
        n[9] === "focus"
      ), ve(
        e,
        "border_contrast",
        /*border_mode*/
        n[9] === "contrast"
      ), ve(e, "hide-container", !/*explicit_call*/
      n[12] && !/*container*/
      n[13]), ve(
        e,
        "fullscreen",
        /*fullscreen*/
        n[0]
      ), ve(
        e,
        "animating",
        /*fullscreen*/
        n[0] && /*preexpansionBoundingRect*/
        n[24] !== null
      ), ve(
        e,
        "auto-margin",
        /*scale*/
        n[17] === null
      ), G(
        e,
        "height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*height*/
            n[2]
          )
        )
      ), G(
        e,
        "min-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*min_height*/
            n[3]
          )
        )
      ), G(
        e,
        "max-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*max_height*/
            n[4]
          )
        )
      ), G(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].top}px` : "0px"
      ), G(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].left}px` : "0px"
      ), G(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].width}px` : "0px"
      ), G(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].height}px` : "0px"
      ), G(
        e,
        "width",
        /*fullscreen*/
        n[0] ? void 0 : typeof /*width*/
        n[5] == "number" ? `calc(min(${/*width*/
        n[5]}px, 100%))` : (
          /*get_dimension*/
          n[26](
            /*width*/
            n[5]
          )
        )
      ), G(
        e,
        "border-style",
        /*variant*/
        n[8]
      ), G(
        e,
        "overflow",
        /*allow_overflow*/
        n[15] ? (
          /*overflow_behavior*/
          n[16]
        ) : "hidden"
      ), G(
        e,
        "flex-grow",
        /*scale*/
        n[17]
      ), G(e, "min-width", `calc(min(${/*min_width*/
      n[18]}px, 100%))`), G(e, "border-width", "var(--block-border-width)");
    },
    m(f, h) {
      ii(f, e, h), l && l.m(e, null), yl(e, t), a && a.m(e, null), n[32](e), s = !0;
    },
    p(f, h) {
      var p;
      l && l.p && (!s || h[0] & /*$$scope*/
      1073741824) && Qm(
        l,
        o,
        f,
        /*$$scope*/
        f[30],
        s ? Km(
          o,
          /*$$scope*/
          f[30],
          h,
          null
        ) : Wm(
          /*$$scope*/
          f[30]
        ),
        null
      ), /*resizable*/
      f[19] ? a ? a.p(f, h) : (a = Dc(f), a.c(), a.m(e, null)) : a && (a.d(1), a = null), Ec(
        /*tag*/
        f[25]
      )(e, u = Gm(c, [
        (!s || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          f[11]
        ) },
        (!s || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          f[6]
        ) },
        (!s || h[0] & /*elem_classes*/
        128 && r !== (r = "block " + /*elem_classes*/
        (((p = f[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu")) && { class: r },
        (!s || h[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        f[20] ? "rtl" : "ltr")) && { dir: i }
      ])), ve(
        e,
        "hidden",
        /*visible*/
        f[14] === !1
      ), ve(
        e,
        "padded",
        /*padding*/
        f[10]
      ), ve(
        e,
        "flex",
        /*flex*/
        f[1]
      ), ve(
        e,
        "border_focus",
        /*border_mode*/
        f[9] === "focus"
      ), ve(
        e,
        "border_contrast",
        /*border_mode*/
        f[9] === "contrast"
      ), ve(e, "hide-container", !/*explicit_call*/
      f[12] && !/*container*/
      f[13]), ve(
        e,
        "fullscreen",
        /*fullscreen*/
        f[0]
      ), ve(
        e,
        "animating",
        /*fullscreen*/
        f[0] && /*preexpansionBoundingRect*/
        f[24] !== null
      ), ve(
        e,
        "auto-margin",
        /*scale*/
        f[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && G(
        e,
        "height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*height*/
            f[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && G(
        e,
        "min-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*min_height*/
            f[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && G(
        e,
        "max-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*max_height*/
            f[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && G(
        e,
        "width",
        /*fullscreen*/
        f[0] ? void 0 : typeof /*width*/
        f[5] == "number" ? `calc(min(${/*width*/
        f[5]}px, 100%))` : (
          /*get_dimension*/
          f[26](
            /*width*/
            f[5]
          )
        )
      ), h[0] & /*variant*/
      256 && G(
        e,
        "border-style",
        /*variant*/
        f[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && G(
        e,
        "overflow",
        /*allow_overflow*/
        f[15] ? (
          /*overflow_behavior*/
          f[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && G(
        e,
        "flex-grow",
        /*scale*/
        f[17]
      ), h[0] & /*min_width*/
      262144 && G(e, "min-width", `calc(min(${/*min_width*/
      f[18]}px, 100%))`);
    },
    i(f) {
      s || (uf(l, f), s = !0);
    },
    o(f) {
      df(l, f), s = !1;
    },
    d(f) {
      f && Ft(e), l && l.d(f), a && a.d(), n[32](null);
    }
  };
}
function Sc(n) {
  let e;
  return {
    c() {
      e = af("div"), this.h();
    },
    l(t) {
      e = of(t, "DIV", { class: !0 }), qr(e).forEach(Ft), this.h();
    },
    h() {
      Ne(e, "class", "placeholder svelte-239wnu"), G(
        e,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), G(
        e,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    m(t, r) {
      ii(t, e, r);
    },
    p(t, r) {
      r[0] & /*placeholder_height*/
      4194304 && G(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), r[0] & /*placeholder_width*/
      8388608 && G(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Ft(e);
    }
  };
}
function tg(n) {
  let e, t, r, i = (
    /*tag*/
    n[25] && eg(n)
  ), s = (
    /*fullscreen*/
    n[0] && Sc(n)
  );
  return {
    c() {
      i && i.c(), e = cf(), s && s.c(), t = vc();
    },
    l(o) {
      i && i.l(o), e = lf(o), s && s.l(o), t = vc();
    },
    m(o, l) {
      i && i.m(o, l), ii(o, e, l), s && s.m(o, l), ii(o, t, l), r = !0;
    },
    p(o, l) {
      /*tag*/
      o[25] && i.p(o, l), /*fullscreen*/
      o[0] ? s ? s.p(o, l) : (s = Sc(o), s.c(), s.m(t.parentNode, t)) : s && (s.d(1), s = null);
    },
    i(o) {
      r || (uf(i, o), r = !0);
    },
    o(o) {
      df(i, o), r = !1;
    },
    d(o) {
      o && (Ft(e), Ft(t)), i && i.d(o), s && s.d(o);
    }
  };
}
function ng(n, e, t) {
  let { $$slots: r = {}, $$scope: i } = e, { height: s = void 0 } = e, { min_height: o = void 0 } = e, { max_height: l = void 0 } = e, { width: a = void 0 } = e, { elem_id: c = "" } = e, { elem_classes: u = [] } = e, { variant: d = "solid" } = e, { border_mode: f = "base" } = e, { padding: h = !0 } = e, { type: p = "normal" } = e, { test_id: m = void 0 } = e, { explicit_call: _ = !1 } = e, { container: b = !0 } = e, { visible: y = !0 } = e, { allow_overflow: g = !0 } = e, { overflow_behavior: w = "auto" } = e, { scale: E = null } = e, { min_width: v = 0 } = e, { flex: D = !1 } = e, { resizable: S = !1 } = e, { rtl: C = !1 } = e, { fullscreen: F = !1 } = e, N = F, H, ke = p === "fieldset" ? "fieldset" : "div", Q = 0, ce = 0, K = null;
  function pe(M) {
    F && M.key === "Escape" && t(0, F = !1);
  }
  const ie = (M) => {
    if (M !== void 0) {
      if (typeof M == "number")
        return M + "px";
      if (typeof M == "string")
        return M;
    }
  }, Ce = (M) => {
    let ye = M.clientY;
    const ne = ($) => {
      const et = $.clientY - ye;
      ye = $.clientY, t(21, H.style.height = `${H.offsetHeight + et}px`, H);
    }, Me = () => {
      window.removeEventListener("mousemove", ne), window.removeEventListener("mouseup", Me);
    };
    window.addEventListener("mousemove", ne), window.addEventListener("mouseup", Me);
  };
  function je(M) {
    Um[M ? "unshift" : "push"](() => {
      H = M, t(21, H);
    });
  }
  return n.$$set = (M) => {
    "height" in M && t(2, s = M.height), "min_height" in M && t(3, o = M.min_height), "max_height" in M && t(4, l = M.max_height), "width" in M && t(5, a = M.width), "elem_id" in M && t(6, c = M.elem_id), "elem_classes" in M && t(7, u = M.elem_classes), "variant" in M && t(8, d = M.variant), "border_mode" in M && t(9, f = M.border_mode), "padding" in M && t(10, h = M.padding), "type" in M && t(28, p = M.type), "test_id" in M && t(11, m = M.test_id), "explicit_call" in M && t(12, _ = M.explicit_call), "container" in M && t(13, b = M.container), "visible" in M && t(14, y = M.visible), "allow_overflow" in M && t(15, g = M.allow_overflow), "overflow_behavior" in M && t(16, w = M.overflow_behavior), "scale" in M && t(17, E = M.scale), "min_width" in M && t(18, v = M.min_width), "flex" in M && t(1, D = M.flex), "resizable" in M && t(19, S = M.resizable), "rtl" in M && t(20, C = M.rtl), "fullscreen" in M && t(0, F = M.fullscreen), "$$scope" in M && t(30, i = M.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && F !== N && (t(29, N = F), F ? (t(24, K = H.getBoundingClientRect()), t(22, Q = H.offsetHeight), t(23, ce = H.offsetWidth), window.addEventListener("keydown", pe)) : (t(24, K = null), window.removeEventListener("keydown", pe))), n.$$.dirty[0] & /*visible*/
    16384 && (y || t(1, D = !1));
  }, [
    F,
    D,
    s,
    o,
    l,
    a,
    c,
    u,
    d,
    f,
    h,
    m,
    _,
    b,
    y,
    g,
    w,
    E,
    v,
    S,
    C,
    H,
    Q,
    ce,
    K,
    ke,
    ie,
    Ce,
    p,
    N,
    i,
    r,
    je
  ];
}
class rg extends qm {
  constructor(e) {
    super(), Jm(
      this,
      e,
      ng,
      tg,
      Zm,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function la() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let jn = la();
function ff(n) {
  jn = n;
}
const hf = /[&<>"']/, ig = new RegExp(hf.source, "g"), pf = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, sg = new RegExp(pf.source, "g"), og = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Cc = (n) => og[n];
function Xe(n, e) {
  if (e) {
    if (hf.test(n))
      return n.replace(ig, Cc);
  } else if (pf.test(n))
    return n.replace(sg, Cc);
  return n;
}
const lg = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function ag(n) {
  return n.replace(lg, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const cg = /(^|[^\[])\^/g;
function X(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const r = {
    replace: (i, s) => {
      let o = typeof s == "string" ? s : s.source;
      return o = o.replace(cg, "$1"), t = t.replace(i, o), r;
    },
    getRegex: () => new RegExp(t, e)
  };
  return r;
}
function Ac(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const Vr = { exec: () => null };
function xc(n, e) {
  const t = n.replace(/\|/g, (s, o, l) => {
    let a = !1, c = o;
    for (; --c >= 0 && l[c] === "\\"; )
      a = !a;
    return a ? "|" : " |";
  }), r = t.split(/ \|/);
  let i = 0;
  if (r[0].trim() || r.shift(), r.length > 0 && !r[r.length - 1].trim() && r.pop(), e)
    if (r.length > e)
      r.splice(e);
    else
      for (; r.length < e; )
        r.push("");
  for (; i < r.length; i++)
    r[i] = r[i].trim().replace(/\\\|/g, "|");
  return r;
}
function Ti(n, e, t) {
  const r = n.length;
  if (r === 0)
    return "";
  let i = 0;
  for (; i < r && n.charAt(r - i - 1) === e; )
    i++;
  return n.slice(0, r - i);
}
function ug(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let r = 0; r < n.length; r++)
    if (n[r] === "\\")
      r++;
    else if (n[r] === e[0])
      t++;
    else if (n[r] === e[1] && (t--, t < 0))
      return r;
  return -1;
}
function Tc(n, e, t, r) {
  const i = e.href, s = e.title ? Xe(e.title) : null, o = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    r.state.inLink = !0;
    const l = {
      type: "link",
      raw: t,
      href: i,
      title: s,
      text: o,
      tokens: r.inlineTokens(o)
    };
    return r.state.inLink = !1, l;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: s,
    text: Xe(o)
  };
}
function dg(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const r = t[1];
  return e.split(`
`).map((i) => {
    const s = i.match(/^\s+/);
    if (s === null)
      return i;
    const [o] = s;
    return o.length >= r.length ? i.slice(r.length) : i;
  }).join(`
`);
}
class fs {
  // set by the lexer
  constructor(e) {
    ee(this, "options");
    ee(this, "rules");
    // set by the lexer
    ee(this, "lexer");
    this.options = e || jn;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : Ti(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], i = dg(r, t[3] || "");
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (/#$/.test(r)) {
        const i = Ti(r, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (r = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      r = Ti(r.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const s = this.lexer.blockTokens(r);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: s,
        text: r
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const i = r.length > 1, s = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = i ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = i ? r : "[*+-]");
      const o = new RegExp(`^( {0,3}${r})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let l = "", a = "", c = !1;
      for (; e; ) {
        let u = !1;
        if (!(t = o.exec(e)) || this.rules.block.hr.test(e))
          break;
        l = t[0], e = e.substring(l.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (b) => " ".repeat(3 * b.length)), f = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, a = d.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, a = d.slice(h), h += t[1].length);
        let p = !1;
        if (!d && /^ *$/.test(f) && (l += f + `
`, e = e.substring(f.length + 1), u = !0), !u) {
          const b = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), y = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), g = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), w = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const E = e.split(`
`, 1)[0];
            if (f = E, this.options.pedantic && (f = f.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), g.test(f) || w.test(f) || b.test(f) || y.test(e))
              break;
            if (f.search(/[^ ]/) >= h || !f.trim())
              a += `
` + f.slice(h);
            else {
              if (p || d.search(/[^ ]/) >= 4 || g.test(d) || w.test(d) || y.test(d))
                break;
              a += `
` + f;
            }
            !p && !f.trim() && (p = !0), l += E + `
`, e = e.substring(E.length + 1), d = f.slice(h);
          }
        }
        s.loose || (c ? s.loose = !0 : /\n *\n *$/.test(l) && (c = !0));
        let m = null, _;
        this.options.gfm && (m = /^\[[ xX]\] /.exec(a), m && (_ = m[0] !== "[ ] ", a = a.replace(/^\[[ xX]\] +/, ""))), s.items.push({
          type: "list_item",
          raw: l,
          task: !!m,
          checked: _,
          loose: !1,
          text: a,
          tokens: []
        }), s.raw += l;
      }
      s.items[s.items.length - 1].raw = l.trimEnd(), s.items[s.items.length - 1].text = a.trimEnd(), s.raw = s.raw.trimEnd();
      for (let u = 0; u < s.items.length; u++)
        if (this.lexer.state.top = !1, s.items[u].tokens = this.lexer.blockTokens(s.items[u].text, []), !s.loose) {
          const d = s.items[u].tokens.filter((h) => h.type === "space"), f = d.length > 0 && d.some((h) => /\n.*\n/.test(h.raw));
          s.loose = f;
        }
      if (s.loose)
        for (let u = 0; u < s.items.length; u++)
          s.items[u].loose = !0;
      return s;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", s = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: i,
        title: s
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const r = xc(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), s = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === i.length) {
      for (const l of i)
        /^ *-+: *$/.test(l) ? o.align.push("right") : /^ *:-+: *$/.test(l) ? o.align.push("center") : /^ *:-+ *$/.test(l) ? o.align.push("left") : o.align.push(null);
      for (const l of r)
        o.header.push({
          text: l,
          tokens: this.lexer.inline(l)
        });
      for (const l of s)
        o.rows.push(xc(l, o.header.length).map((a) => ({
          text: a,
          tokens: this.lexer.inline(a)
        })));
      return o;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Xe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && /^</.test(r)) {
        if (!/>$/.test(r))
          return;
        const o = Ti(r.slice(0, -1), "\\");
        if ((r.length - o.length) % 2 === 0)
          return;
      } else {
        const o = ug(t[2], "()");
        if (o > -1) {
          const a = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + o;
          t[2] = t[2].substring(0, o), t[0] = t[0].substring(0, a).trim(), t[3] = "";
        }
      }
      let i = t[2], s = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        o && (i = o[1], s = o[3]);
      } else
        s = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(r) ? i = i.slice(1) : i = i.slice(1, -1)), Tc(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: s && s.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const i = (r[2] || r[1]).replace(/\s+/g, " "), s = t[i.toLowerCase()];
      if (!s) {
        const o = r[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return Tc(r, s, r[0], this.lexer);
    }
  }
  emStrong(e, t, r = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && r.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const o = [...i[0]].length - 1;
      let l, a, c = o, u = 0;
      const d = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + o); (i = d.exec(t)) != null; ) {
        if (l = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !l)
          continue;
        if (a = [...l].length, i[3] || i[4]) {
          c += a;
          continue;
        } else if ((i[5] || i[6]) && o % 3 && !((o + a) % 3)) {
          u += a;
          continue;
        }
        if (c -= a, c > 0)
          continue;
        a = Math.min(a, a + c + u);
        const f = [...i[0]][0].length, h = e.slice(0, o + i.index + f + a);
        if (Math.min(o, a) % 2) {
          const m = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: m,
            tokens: this.lexer.inlineTokens(m)
          };
        }
        const p = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(r), s = /^ /.test(r) && / $/.test(r);
      return i && s && (r = r.substring(1, r.length - 1)), r = Xe(r, !0), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, i;
      return t[2] === "@" ? (r = Xe(t[1]), i = "mailto:" + r) : (r = Xe(t[1]), i = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: i,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, s;
      if (t[2] === "@")
        i = Xe(t[0]), s = "mailto:" + i;
      else {
        let o;
        do
          o = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (o !== t[0]);
        i = Xe(t[0]), t[1] === "www." ? s = "http://" + t[0] : s = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: s,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let r;
      return this.lexer.state.inRawBlock ? r = t[0] : r = Xe(t[0]), {
        type: "text",
        raw: t[0],
        text: r
      };
    }
  }
}
const fg = /^(?: *(?:\n|$))+/, hg = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, pg = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, gi = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, mg = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, mf = /(?:[*+-]|\d{1,9}[.)])/, gf = X(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, mf).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), aa = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, gg = /^[^\n]+/, ca = /(?!\s*\])(?:\\.|[^\[\]\\])+/, _g = X(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", ca).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), yg = X(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, mf).getRegex(), io = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", ua = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, bg = X("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", ua).replace("tag", io).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), _f = X(aa).replace("hr", gi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", io).getRegex(), kg = X(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", _f).getRegex(), da = {
  blockquote: kg,
  code: hg,
  def: _g,
  fences: pg,
  heading: mg,
  hr: gi,
  html: bg,
  lheading: gf,
  list: yg,
  newline: fg,
  paragraph: _f,
  table: Vr,
  text: gg
}, Mc = X("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", gi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", io).getRegex(), wg = {
  ...da,
  table: Mc,
  paragraph: X(aa).replace("hr", gi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Mc).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", io).getRegex()
}, vg = {
  ...da,
  html: X(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", ua).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Vr,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: X(aa).replace("hr", gi).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", gf).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, yf = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Eg = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, bf = /^( {2,}|\\)\n(?!\s*$)/, Dg = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, _i = "\\p{P}\\p{S}", Sg = X(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, _i).getRegex(), Cg = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Ag = X(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, _i).getRegex(), xg = X("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, _i).getRegex(), Tg = X("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, _i).getRegex(), Mg = X(/\\([punct])/, "gu").replace(/punct/g, _i).getRegex(), Fg = X(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), $g = X(ua).replace("(?:-->|$)", "-->").getRegex(), Og = X("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", $g).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), hs = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Ng = X(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", hs).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), kf = X(/^!?\[(label)\]\[(ref)\]/).replace("label", hs).replace("ref", ca).getRegex(), wf = X(/^!?\[(ref)\](?:\[\])?/).replace("ref", ca).getRegex(), Ig = X("reflink|nolink(?!\\()", "g").replace("reflink", kf).replace("nolink", wf).getRegex(), fa = {
  _backpedal: Vr,
  // only used for GFM url
  anyPunctuation: Mg,
  autolink: Fg,
  blockSkip: Cg,
  br: bf,
  code: Eg,
  del: Vr,
  emStrongLDelim: Ag,
  emStrongRDelimAst: xg,
  emStrongRDelimUnd: Tg,
  escape: yf,
  link: Ng,
  nolink: wf,
  punctuation: Sg,
  reflink: kf,
  reflinkSearch: Ig,
  tag: Og,
  text: Dg,
  url: Vr
}, Rg = {
  ...fa,
  link: X(/^!?\[(label)\]\((.*?)\)/).replace("label", hs).getRegex(),
  reflink: X(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", hs).getRegex()
}, bl = {
  ...fa,
  escape: X(yf).replace("])", "~|])").getRegex(),
  url: X(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Lg = {
  ...bl,
  br: X(bf).replace("{2,}", "*").getRegex(),
  text: X(bl.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Mi = {
  normal: da,
  gfm: wg,
  pedantic: vg
}, Ar = {
  normal: fa,
  gfm: bl,
  breaks: Lg,
  pedantic: Rg
};
class $t {
  constructor(e) {
    ee(this, "tokens");
    ee(this, "options");
    ee(this, "state");
    ee(this, "tokenizer");
    ee(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || jn, this.options.tokenizer = this.options.tokenizer || new fs(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Mi.normal,
      inline: Ar.normal
    };
    this.options.pedantic ? (t.block = Mi.pedantic, t.inline = Ar.pedantic) : this.options.gfm && (t.block = Mi.gfm, this.options.breaks ? t.inline = Ar.breaks : t.inline = Ar.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Mi,
      inline: Ar
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new $t(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new $t(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const r = this.inlineQueue[t];
      this.inlineTokens(r.src, r.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (l, a, c) => a + "    ".repeat(c.length));
    let r, i, s, o;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((l) => (r = l.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.space(e)) {
          e = e.substring(r.raw.length), r.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(r);
          continue;
        }
        if (r = this.tokenizer.code(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + r.raw, i.text += `
` + r.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.fences(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.heading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.hr(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.blockquote(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.list(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.html(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.def(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + r.raw, i.text += `
` + r.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = {
            href: r.href,
            title: r.title
          });
          continue;
        }
        if (r = this.tokenizer.table(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.lheading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (s = e, this.options.extensions && this.options.extensions.startBlock) {
          let l = 1 / 0;
          const a = e.slice(1);
          let c;
          this.options.extensions.startBlock.forEach((u) => {
            c = u.call({ lexer: this }, a), typeof c == "number" && c >= 0 && (l = Math.min(l, c));
          }), l < 1 / 0 && l >= 0 && (s = e.substring(0, l + 1));
        }
        if (this.state.top && (r = this.tokenizer.paragraph(s))) {
          i = t[t.length - 1], o && i.type === "paragraph" ? (i.raw += `
` + r.raw, i.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(r), o = s.length !== e.length, e = e.substring(r.raw.length);
          continue;
        }
        if (r = this.tokenizer.text(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + r.raw, i.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(r);
          continue;
        }
        if (e) {
          const l = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(l);
            break;
          } else
            throw new Error(l);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let r, i, s, o = e, l, a, c;
    if (this.tokens.links) {
      const u = Object.keys(this.tokens.links);
      if (u.length > 0)
        for (; (l = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          u.includes(l[0].slice(l[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (l = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (l = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, l.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (a || (c = ""), a = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((u) => (r = u.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.escape(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.tag(e)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && r.type === "text" && i.type === "text" ? (i.raw += r.raw, i.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.link(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(r.raw.length), i = t[t.length - 1], i && r.type === "text" && i.type === "text" ? (i.raw += r.raw, i.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.emStrong(e, o, c)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.codespan(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.br(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.del(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.autolink(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (!this.state.inLink && (r = this.tokenizer.url(e))) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (s = e, this.options.extensions && this.options.extensions.startInline) {
          let u = 1 / 0;
          const d = e.slice(1);
          let f;
          this.options.extensions.startInline.forEach((h) => {
            f = h.call({ lexer: this }, d), typeof f == "number" && f >= 0 && (u = Math.min(u, f));
          }), u < 1 / 0 && u >= 0 && (s = e.substring(0, u + 1));
        }
        if (r = this.tokenizer.inlineText(s)) {
          e = e.substring(r.raw.length), r.raw.slice(-1) !== "_" && (c = r.raw.slice(-1)), a = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += r.raw, i.text += r.text) : t.push(r);
          continue;
        }
        if (e) {
          const u = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(u);
            break;
          } else
            throw new Error(u);
        }
      }
    return t;
  }
}
class ps {
  constructor(e) {
    ee(this, "options");
    this.options = e || jn;
  }
  code(e, t, r) {
    var s;
    const i = (s = (t || "").match(/^\S*/)) == null ? void 0 : s[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + Xe(i) + '">' + (r ? e : Xe(e, !0)) + `</code></pre>
` : "<pre><code>" + (r ? e : Xe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, r) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, r) {
    const i = t ? "ol" : "ul", s = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + i + s + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, r) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const r = t.header ? "th" : "td";
    return (t.align ? `<${r} align="${t.align}">` : `<${r}>`) + e + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, r) {
    const i = Ac(e);
    if (i === null)
      return r;
    e = i;
    let s = '<a href="' + e + '"';
    return t && (s += ' title="' + t + '"'), s += ">" + r + "</a>", s;
  }
  image(e, t, r) {
    const i = Ac(e);
    if (i === null)
      return r;
    e = i;
    let s = `<img src="${e}" alt="${r}"`;
    return t && (s += ` title="${t}"`), s += ">", s;
  }
  text(e) {
    return e;
  }
}
class ha {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, r) {
    return "" + r;
  }
  image(e, t, r) {
    return "" + r;
  }
  br() {
    return "";
  }
}
class Ot {
  constructor(e) {
    ee(this, "options");
    ee(this, "renderer");
    ee(this, "textRenderer");
    this.options = e || jn, this.options.renderer = this.options.renderer || new ps(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new ha();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Ot(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Ot(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let r = "";
    for (let i = 0; i < e.length; i++) {
      const s = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[s.type]) {
        const o = s, l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          r += l || "";
          continue;
        }
      }
      switch (s.type) {
        case "space":
          continue;
        case "hr": {
          r += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = s;
          r += this.renderer.heading(this.parseInline(o.tokens), o.depth, ag(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = s;
          r += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = s;
          let l = "", a = "";
          for (let u = 0; u < o.header.length; u++)
            a += this.renderer.tablecell(this.parseInline(o.header[u].tokens), { header: !0, align: o.align[u] });
          l += this.renderer.tablerow(a);
          let c = "";
          for (let u = 0; u < o.rows.length; u++) {
            const d = o.rows[u];
            a = "";
            for (let f = 0; f < d.length; f++)
              a += this.renderer.tablecell(this.parseInline(d[f].tokens), { header: !1, align: o.align[f] });
            c += this.renderer.tablerow(a);
          }
          r += this.renderer.table(l, c);
          continue;
        }
        case "blockquote": {
          const o = s, l = this.parse(o.tokens);
          r += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          const o = s, l = o.ordered, a = o.start, c = o.loose;
          let u = "";
          for (let d = 0; d < o.items.length; d++) {
            const f = o.items[d], h = f.checked, p = f.task;
            let m = "";
            if (f.task) {
              const _ = this.renderer.checkbox(!!h);
              c ? f.tokens.length > 0 && f.tokens[0].type === "paragraph" ? (f.tokens[0].text = _ + " " + f.tokens[0].text, f.tokens[0].tokens && f.tokens[0].tokens.length > 0 && f.tokens[0].tokens[0].type === "text" && (f.tokens[0].tokens[0].text = _ + " " + f.tokens[0].tokens[0].text)) : f.tokens.unshift({
                type: "text",
                text: _ + " "
              }) : m += _ + " ";
            }
            m += this.parse(f.tokens, c), u += this.renderer.listitem(m, p, !!h);
          }
          r += this.renderer.list(u, l, a);
          continue;
        }
        case "html": {
          const o = s;
          r += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = s;
          r += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = s, l = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            o = e[++i], l += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          r += t ? this.renderer.paragraph(l) : l;
          continue;
        }
        default: {
          const o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return r;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let r = "";
    for (let i = 0; i < e.length; i++) {
      const s = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[s.type]) {
        const o = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          r += o || "";
          continue;
        }
      }
      switch (s.type) {
        case "escape": {
          const o = s;
          r += t.text(o.text);
          break;
        }
        case "html": {
          const o = s;
          r += t.html(o.text);
          break;
        }
        case "link": {
          const o = s;
          r += t.link(o.href, o.title, this.parseInline(o.tokens, t));
          break;
        }
        case "image": {
          const o = s;
          r += t.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = s;
          r += t.strong(this.parseInline(o.tokens, t));
          break;
        }
        case "em": {
          const o = s;
          r += t.em(this.parseInline(o.tokens, t));
          break;
        }
        case "codespan": {
          const o = s;
          r += t.codespan(o.text);
          break;
        }
        case "br": {
          r += t.br();
          break;
        }
        case "del": {
          const o = s;
          r += t.del(this.parseInline(o.tokens, t));
          break;
        }
        case "text": {
          const o = s;
          r += t.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return r;
  }
}
class Ur {
  constructor(e) {
    ee(this, "options");
    this.options = e || jn;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
ee(Ur, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Un, kl, Ef;
class vf {
  constructor(...e) {
    wc(this, Un);
    ee(this, "defaults", la());
    ee(this, "options", this.setOptions);
    ee(this, "parse", xi(this, Un, kl).call(this, $t.lex, Ot.parse));
    ee(this, "parseInline", xi(this, Un, kl).call(this, $t.lexInline, Ot.parseInline));
    ee(this, "Parser", Ot);
    ee(this, "Renderer", ps);
    ee(this, "TextRenderer", ha);
    ee(this, "Lexer", $t);
    ee(this, "Tokenizer", fs);
    ee(this, "Hooks", Ur);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, s;
    let r = [];
    for (const o of e)
      switch (r = r.concat(t.call(this, o)), o.type) {
        case "table": {
          const l = o;
          for (const a of l.header)
            r = r.concat(this.walkTokens(a.tokens, t));
          for (const a of l.rows)
            for (const c of a)
              r = r.concat(this.walkTokens(c.tokens, t));
          break;
        }
        case "list": {
          const l = o;
          r = r.concat(this.walkTokens(l.items, t));
          break;
        }
        default: {
          const l = o;
          (s = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && s[l.type] ? this.defaults.extensions.childTokens[l.type].forEach((a) => {
            const c = l[a].flat(1 / 0);
            r = r.concat(this.walkTokens(c, t));
          }) : l.tokens && (r = r.concat(this.walkTokens(l.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const i = { ...r };
      if (i.async = this.defaults.async || i.async || !1, r.extensions && (r.extensions.forEach((s) => {
        if (!s.name)
          throw new Error("extension name required");
        if ("renderer" in s) {
          const o = t.renderers[s.name];
          o ? t.renderers[s.name] = function(...l) {
            let a = s.renderer.apply(this, l);
            return a === !1 && (a = o.apply(this, l)), a;
          } : t.renderers[s.name] = s.renderer;
        }
        if ("tokenizer" in s) {
          if (!s.level || s.level !== "block" && s.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = t[s.level];
          o ? o.unshift(s.tokenizer) : t[s.level] = [s.tokenizer], s.start && (s.level === "block" ? t.startBlock ? t.startBlock.push(s.start) : t.startBlock = [s.start] : s.level === "inline" && (t.startInline ? t.startInline.push(s.start) : t.startInline = [s.start]));
        }
        "childTokens" in s && s.childTokens && (t.childTokens[s.name] = s.childTokens);
      }), i.extensions = t), r.renderer) {
        const s = this.defaults.renderer || new ps(this.defaults);
        for (const o in r.renderer) {
          if (!(o in s))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const l = o, a = r.renderer[l], c = s[l];
          s[l] = (...u) => {
            let d = a.apply(s, u);
            return d === !1 && (d = c.apply(s, u)), d || "";
          };
        }
        i.renderer = s;
      }
      if (r.tokenizer) {
        const s = this.defaults.tokenizer || new fs(this.defaults);
        for (const o in r.tokenizer) {
          if (!(o in s))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const l = o, a = r.tokenizer[l], c = s[l];
          s[l] = (...u) => {
            let d = a.apply(s, u);
            return d === !1 && (d = c.apply(s, u)), d;
          };
        }
        i.tokenizer = s;
      }
      if (r.hooks) {
        const s = this.defaults.hooks || new Ur();
        for (const o in r.hooks) {
          if (!(o in s))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const l = o, a = r.hooks[l], c = s[l];
          Ur.passThroughHooks.has(o) ? s[l] = (u) => {
            if (this.defaults.async)
              return Promise.resolve(a.call(s, u)).then((f) => c.call(s, f));
            const d = a.call(s, u);
            return c.call(s, d);
          } : s[l] = (...u) => {
            let d = a.apply(s, u);
            return d === !1 && (d = c.apply(s, u)), d;
          };
        }
        i.hooks = s;
      }
      if (r.walkTokens) {
        const s = this.defaults.walkTokens, o = r.walkTokens;
        i.walkTokens = function(l) {
          let a = [];
          return a.push(o.call(this, l)), s && (a = a.concat(s.call(this, l))), a;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return $t.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Ot.parse(e, t ?? this.defaults);
  }
}
Un = new WeakSet(), kl = function(e, t) {
  return (r, i) => {
    const s = { ...i }, o = { ...this.defaults, ...s };
    this.defaults.async === !0 && s.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const l = xi(this, Un, Ef).call(this, !!o.silent, !!o.async);
    if (typeof r > "u" || r === null)
      return l(new Error("marked(): input parameter is undefined or null"));
    if (typeof r != "string")
      return l(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(r) : r).then((a) => e(a, o)).then((a) => o.hooks ? o.hooks.processAllTokens(a) : a).then((a) => o.walkTokens ? Promise.all(this.walkTokens(a, o.walkTokens)).then(() => a) : a).then((a) => t(a, o)).then((a) => o.hooks ? o.hooks.postprocess(a) : a).catch(l);
    try {
      o.hooks && (r = o.hooks.preprocess(r));
      let a = e(r, o);
      o.hooks && (a = o.hooks.processAllTokens(a)), o.walkTokens && this.walkTokens(a, o.walkTokens);
      let c = t(a, o);
      return o.hooks && (c = o.hooks.postprocess(c)), c;
    } catch (a) {
      return l(a);
    }
  };
}, Ef = function(e, t) {
  return (r) => {
    if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + Xe(r.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(r);
    throw r;
  };
};
const Pn = new vf();
function Y(n, e) {
  return Pn.parse(n, e);
}
Y.options = Y.setOptions = function(n) {
  return Pn.setOptions(n), Y.defaults = Pn.defaults, ff(Y.defaults), Y;
};
Y.getDefaults = la;
Y.defaults = jn;
Y.use = function(...n) {
  return Pn.use(...n), Y.defaults = Pn.defaults, ff(Y.defaults), Y;
};
Y.walkTokens = function(n, e) {
  return Pn.walkTokens(n, e);
};
Y.parseInline = Pn.parseInline;
Y.Parser = Ot;
Y.parser = Ot.parse;
Y.Renderer = ps;
Y.TextRenderer = ha;
Y.Lexer = $t;
Y.lexer = $t.lex;
Y.Tokenizer = fs;
Y.Hooks = Ur;
Y.parse = Y;
Y.options;
Y.setOptions;
Y.use;
Y.walkTokens;
Y.parseInline;
Ot.parse;
$t.lex;
function Pg(n) {
  if (typeof n == "function" && (n = {
    highlight: n
  }), !n || typeof n.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof n.langPrefix != "string" && (n.langPrefix = "language-"), typeof n.emptyLangClass != "string" && (n.emptyLangClass = ""), {
    async: !!n.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const t = Fc(e.lang);
      if (n.async)
        return Promise.resolve(n.highlight(e.text, t, e.lang || "")).then($c(e));
      const r = n.highlight(e.text, t, e.lang || "");
      if (r instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      $c(e)(r);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, t, r) {
        typeof e == "object" && (r = e.escaped, t = e.lang, e = e.text);
        const i = Fc(t), s = i ? n.langPrefix + Nc(i) : n.emptyLangClass, o = s ? ` class="${s}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${o}>${r ? e : Nc(e, !0)}
</code></pre>`;
      }
    }
  };
}
function Fc(n) {
  return (n || "").match(/\S*/)[0];
}
function $c(n) {
  return (e) => {
    typeof e == "string" && e !== n.text && (n.escaped = !0, n.text = e);
  };
}
const Df = /[&<>"']/, Bg = new RegExp(Df.source, "g"), Sf = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, zg = new RegExp(Sf.source, "g"), Hg = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Oc = (n) => Hg[n];
function Nc(n, e) {
  if (e) {
    if (Df.test(n))
      return n.replace(Bg, Oc);
  } else if (Sf.test(n))
    return n.replace(zg, Oc);
  return n;
}
const qg = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Vg = Object.hasOwnProperty;
class pa {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const r = this;
    let i = Ug(e, t === !0);
    const s = i;
    for (; Vg.call(r.occurrences, i); )
      r.occurrences[s]++, i = s + "-" + r.occurrences[s];
    return r.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Ug(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(qg, "").replace(/ /g, "-"));
}
let Cf = new pa(), Af = [];
function jg({ prefix: n = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return e || Wg(), t;
      }
    },
    renderer: {
      heading(t, r, i) {
        i = i.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const s = `${n}${Cf.slug(i)}`, o = { level: r, text: t, id: s };
        return Af.push(o), `<h${r} id="${s}">${t}</h${r}>
`;
      }
    }
  };
}
function Wg() {
  Af = [], Cf = new pa();
}
var Ic = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function QD(n) {
  return n && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n;
}
var xf = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(r) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, s = 0, o = {}, l = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: r.Prism && r.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: r.Prism && r.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function y(g) {
          return g instanceof a ? new a(g.type, y(g.content), g.alias) : Array.isArray(g) ? g.map(y) : g.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(y) {
          return Object.prototype.toString.call(y).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(y) {
          return y.__id || Object.defineProperty(y, "__id", { value: ++s }), y.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function y(g, w) {
          w = w || {};
          var E, v;
          switch (l.util.type(g)) {
            case "Object":
              if (v = l.util.objId(g), w[v])
                return w[v];
              E = /** @type {Record<string, any>} */
              {}, w[v] = E;
              for (var D in g)
                g.hasOwnProperty(D) && (E[D] = y(g[D], w));
              return (
                /** @type {any} */
                E
              );
            case "Array":
              return v = l.util.objId(g), w[v] ? w[v] : (E = [], w[v] = E, /** @type {Array} */
              /** @type {any} */
              g.forEach(function(S, C) {
                E[C] = y(S, w);
              }), /** @type {any} */
              E);
            default:
              return g;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(y) {
          for (; y; ) {
            var g = i.exec(y.className);
            if (g)
              return g[1].toLowerCase();
            y = y.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(y, g) {
          y.className = y.className.replace(RegExp(i, "gi"), ""), y.classList.add("language-" + g);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (E) {
            var y = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(E.stack) || [])[1];
            if (y) {
              var g = document.getElementsByTagName("script");
              for (var w in g)
                if (g[w].src == y)
                  return g[w];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(y, g, w) {
          for (var E = "no-" + g; y; ) {
            var v = y.classList;
            if (v.contains(g))
              return !0;
            if (v.contains(E))
              return !1;
            y = y.parentElement;
          }
          return !!w;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(y, g) {
          var w = l.util.clone(l.languages[y]);
          for (var E in g)
            w[E] = g[E];
          return w;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(y, g, w, E) {
          E = E || /** @type {any} */
          l.languages;
          var v = E[y], D = {};
          for (var S in v)
            if (v.hasOwnProperty(S)) {
              if (S == g)
                for (var C in w)
                  w.hasOwnProperty(C) && (D[C] = w[C]);
              w.hasOwnProperty(S) || (D[S] = v[S]);
            }
          var F = E[y];
          return E[y] = D, l.languages.DFS(l.languages, function(N, H) {
            H === F && N != y && (this[N] = D);
          }), D;
        },
        // Traverse a language definition with Depth First Search
        DFS: function y(g, w, E, v) {
          v = v || {};
          var D = l.util.objId;
          for (var S in g)
            if (g.hasOwnProperty(S)) {
              w.call(g, S, g[S], E || S);
              var C = g[S], F = l.util.type(C);
              F === "Object" && !v[D(C)] ? (v[D(C)] = !0, y(C, w, null, v)) : F === "Array" && !v[D(C)] && (v[D(C)] = !0, y(C, w, S, v));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(y, g) {
        l.highlightAllUnder(document, y, g);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(y, g, w) {
        var E = {
          callback: w,
          container: y,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        l.hooks.run("before-highlightall", E), E.elements = Array.prototype.slice.apply(E.container.querySelectorAll(E.selector)), l.hooks.run("before-all-elements-highlight", E);
        for (var v = 0, D; D = E.elements[v++]; )
          l.highlightElement(D, g === !0, E.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(y, g, w) {
        var E = l.util.getLanguage(y), v = l.languages[E];
        l.util.setLanguage(y, E);
        var D = y.parentElement;
        D && D.nodeName.toLowerCase() === "pre" && l.util.setLanguage(D, E);
        var S = y.textContent, C = {
          element: y,
          language: E,
          grammar: v,
          code: S
        };
        function F(H) {
          C.highlightedCode = H, l.hooks.run("before-insert", C), C.element.innerHTML = C.highlightedCode, l.hooks.run("after-highlight", C), l.hooks.run("complete", C), w && w.call(C.element);
        }
        if (l.hooks.run("before-sanity-check", C), D = C.element.parentElement, D && D.nodeName.toLowerCase() === "pre" && !D.hasAttribute("tabindex") && D.setAttribute("tabindex", "0"), !C.code) {
          l.hooks.run("complete", C), w && w.call(C.element);
          return;
        }
        if (l.hooks.run("before-highlight", C), !C.grammar) {
          F(l.util.encode(C.code));
          return;
        }
        if (g && r.Worker) {
          var N = new Worker(l.filename);
          N.onmessage = function(H) {
            F(H.data);
          }, N.postMessage(JSON.stringify({
            language: C.language,
            code: C.code,
            immediateClose: !0
          }));
        } else
          F(l.highlight(C.code, C.grammar, C.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(y, g, w) {
        var E = {
          code: y,
          grammar: g,
          language: w
        };
        if (l.hooks.run("before-tokenize", E), !E.grammar)
          throw new Error('The language "' + E.language + '" has no grammar.');
        return E.tokens = l.tokenize(E.code, E.grammar), l.hooks.run("after-tokenize", E), a.stringify(l.util.encode(E.tokens), E.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(y, g) {
        var w = g.rest;
        if (w) {
          for (var E in w)
            g[E] = w[E];
          delete g.rest;
        }
        var v = new d();
        return f(v, v.head, y), u(y, v, g, v.head, 0), p(v);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(y, g) {
          var w = l.hooks.all;
          w[y] = w[y] || [], w[y].push(g);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(y, g) {
          var w = l.hooks.all[y];
          if (!(!w || !w.length))
            for (var E = 0, v; v = w[E++]; )
              v(g);
        }
      },
      Token: a
    };
    r.Prism = l;
    function a(y, g, w, E) {
      this.type = y, this.content = g, this.alias = w, this.length = (E || "").length | 0;
    }
    a.stringify = function y(g, w) {
      if (typeof g == "string")
        return g;
      if (Array.isArray(g)) {
        var E = "";
        return g.forEach(function(F) {
          E += y(F, w);
        }), E;
      }
      var v = {
        type: g.type,
        content: y(g.content, w),
        tag: "span",
        classes: ["token", g.type],
        attributes: {},
        language: w
      }, D = g.alias;
      D && (Array.isArray(D) ? Array.prototype.push.apply(v.classes, D) : v.classes.push(D)), l.hooks.run("wrap", v);
      var S = "";
      for (var C in v.attributes)
        S += " " + C + '="' + (v.attributes[C] || "").replace(/"/g, "&quot;") + '"';
      return "<" + v.tag + ' class="' + v.classes.join(" ") + '"' + S + ">" + v.content + "</" + v.tag + ">";
    };
    function c(y, g, w, E) {
      y.lastIndex = g;
      var v = y.exec(w);
      if (v && E && v[1]) {
        var D = v[1].length;
        v.index += D, v[0] = v[0].slice(D);
      }
      return v;
    }
    function u(y, g, w, E, v, D) {
      for (var S in w)
        if (!(!w.hasOwnProperty(S) || !w[S])) {
          var C = w[S];
          C = Array.isArray(C) ? C : [C];
          for (var F = 0; F < C.length; ++F) {
            if (D && D.cause == S + "," + F)
              return;
            var N = C[F], H = N.inside, ke = !!N.lookbehind, Q = !!N.greedy, ce = N.alias;
            if (Q && !N.pattern.global) {
              var K = N.pattern.toString().match(/[imsuy]*$/)[0];
              N.pattern = RegExp(N.pattern.source, K + "g");
            }
            for (var pe = N.pattern || N, ie = E.next, Ce = v; ie !== g.tail && !(D && Ce >= D.reach); Ce += ie.value.length, ie = ie.next) {
              var je = ie.value;
              if (g.length > y.length)
                return;
              if (!(je instanceof a)) {
                var M = 1, ye;
                if (Q) {
                  if (ye = c(pe, Ce, y, ke), !ye || ye.index >= y.length)
                    break;
                  var et = ye.index, ne = ye.index + ye[0].length, Me = Ce;
                  for (Me += ie.value.length; et >= Me; )
                    ie = ie.next, Me += ie.value.length;
                  if (Me -= ie.value.length, Ce = Me, ie.value instanceof a)
                    continue;
                  for (var $ = ie; $ !== g.tail && (Me < ne || typeof $.value == "string"); $ = $.next)
                    M++, Me += $.value.length;
                  M--, je = y.slice(Ce, Me), ye.index -= Ce;
                } else if (ye = c(pe, 0, je, ke), !ye)
                  continue;
                var et = ye.index, en = ye[0], Gn = je.slice(0, et), Jn = je.slice(et + en.length), Yn = Ce + je.length;
                D && Yn > D.reach && (D.reach = Yn);
                var En = ie.prev;
                Gn && (En = f(g, En, Gn), Ce += Gn.length), h(g, En, M);
                var tn = new a(S, H ? l.tokenize(en, H) : en, ce, en);
                if (ie = f(g, En, tn), Jn && f(g, ie, Jn), M > 1) {
                  var nn = {
                    cause: S + "," + F,
                    reach: Yn
                  };
                  u(y, g, w, ie.prev, Ce, nn), D && nn.reach > D.reach && (D.reach = nn.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var y = { value: null, prev: null, next: null }, g = { value: null, prev: y, next: null };
      y.next = g, this.head = y, this.tail = g, this.length = 0;
    }
    function f(y, g, w) {
      var E = g.next, v = { value: w, prev: g, next: E };
      return g.next = v, E.prev = v, y.length++, v;
    }
    function h(y, g, w) {
      for (var E = g.next, v = 0; v < w && E !== y.tail; v++)
        E = E.next;
      g.next = E, E.prev = g, y.length -= v;
    }
    function p(y) {
      for (var g = [], w = y.head.next; w !== y.tail; )
        g.push(w.value), w = w.next;
      return g;
    }
    if (!r.document)
      return r.addEventListener && (l.disableWorkerMessageHandler || r.addEventListener("message", function(y) {
        var g = JSON.parse(y.data), w = g.language, E = g.code, v = g.immediateClose;
        r.postMessage(l.highlight(E, l.languages[w], w)), v && r.close();
      }, !1)), l;
    var m = l.util.currentScript();
    m && (l.filename = m.src, m.hasAttribute("data-manual") && (l.manual = !0));
    function _() {
      l.manual || l.highlightAll();
    }
    if (!l.manual) {
      var b = document.readyState;
      b === "loading" || b === "interactive" && m && m.defer ? document.addEventListener("DOMContentLoaded", _) : window.requestAnimationFrame ? window.requestAnimationFrame(_) : window.setTimeout(_, 16);
    }
    return l;
  }(e);
  n.exports && (n.exports = t), typeof Ic < "u" && (Ic.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(r) {
    r.type === "entity" && (r.attributes.title = r.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, s) {
      var o = {};
      o["language-" + s] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[s]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var l = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      l["language-" + s] = {
        pattern: /[\s\S]+/,
        inside: t.languages[s]
      };
      var a = {};
      a[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: l
      }, t.languages.insertBefore("markup", "cdata", a);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(r, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + r + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(r) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    r.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, r.languages.css.atrule.inside.rest = r.languages.css;
    var s = r.languages.markup;
    s && (s.tag.addInlined("style", "css"), s.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var r = "Loading…", i = function(m, _) {
      return "✖ Error " + m + " while fetching file: " + _;
    }, s = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, l = "data-src-status", a = "loading", c = "loaded", u = "failed", d = "pre[data-src]:not([" + l + '="' + c + '"]):not([' + l + '="' + a + '"])';
    function f(m, _, b) {
      var y = new XMLHttpRequest();
      y.open("GET", m, !0), y.onreadystatechange = function() {
        y.readyState == 4 && (y.status < 400 && y.responseText ? _(y.responseText) : y.status >= 400 ? b(i(y.status, y.statusText)) : b(s));
      }, y.send(null);
    }
    function h(m) {
      var _ = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(m || "");
      if (_) {
        var b = Number(_[1]), y = _[2], g = _[3];
        return y ? g ? [b, Number(g)] : [b, void 0] : [b, b];
      }
    }
    t.hooks.add("before-highlightall", function(m) {
      m.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(m) {
      var _ = (
        /** @type {HTMLPreElement} */
        m.element
      );
      if (_.matches(d)) {
        m.code = "", _.setAttribute(l, a);
        var b = _.appendChild(document.createElement("CODE"));
        b.textContent = r;
        var y = _.getAttribute("data-src"), g = m.language;
        if (g === "none") {
          var w = (/\.(\w+)$/.exec(y) || [, "none"])[1];
          g = o[w] || w;
        }
        t.util.setLanguage(b, g), t.util.setLanguage(_, g);
        var E = t.plugins.autoloader;
        E && E.loadLanguages(g), f(
          y,
          function(v) {
            _.setAttribute(l, c);
            var D = h(_.getAttribute("data-range"));
            if (D) {
              var S = v.split(/\r\n?|\n/g), C = D[0], F = D[1] == null ? S.length : D[1];
              C < 0 && (C += S.length), C = Math.max(0, Math.min(C - 1, S.length)), F < 0 && (F += S.length), F = Math.max(0, Math.min(F, S.length)), v = S.slice(C, F).join(`
`), _.hasAttribute("data-start") || _.setAttribute("data-start", String(C + 1));
            }
            b.textContent = v, t.highlightElement(b);
          },
          function(v) {
            _.setAttribute(l, u), b.textContent = v;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(_) {
        for (var b = (_ || document).querySelectorAll(d), y = 0, g; g = b[y++]; )
          t.highlightElement(g);
      }
    };
    var p = !1;
    t.fileHighlight = function() {
      p || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), p = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(xf);
var $o = xf.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, r = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: r.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: r.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], s = r.variable[1].inside, o = 0; o < i.length; o++)
    s[i[o]] = n.languages.bash[i[o]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
const Kg = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', Gg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, Jg = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, Rc = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${Gg}</span>
  <span class="check">${Jg}</span>
</button>`, Tf = /[&<>"']/, Yg = new RegExp(Tf.source, "g"), Mf = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Xg = new RegExp(Mf.source, "g"), Zg = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Lc = (n) => Zg[n] || "";
function Oo(n, e) {
  if (e) {
    if (Tf.test(n))
      return n.replace(Yg, Lc);
  } else if (Mf.test(n))
    return n.replace(Xg, Lc);
  return n;
}
function Qg(n) {
  const e = n.map((t) => ({
    start: new RegExp(t.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(t.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(t) {
      for (const r of e) {
        const i = t.match(r.start);
        if (i)
          return i.index;
      }
      return -1;
    },
    tokenizer(t, r) {
      for (const i of e) {
        const s = new RegExp(
          `${i.start.source}([\\s\\S]+?)${i.end.source}`
        ).exec(t);
        if (s)
          return {
            type: "latex",
            raw: s[0],
            text: s[1].trim()
          };
      }
    },
    renderer(t) {
      return `<div class="latex-block">${t.text}</div>`;
    }
  };
}
function e0() {
  return {
    name: "mermaid",
    level: "block",
    start(n) {
      var e;
      return (e = n.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(n) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(n);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(n) {
      return `<div class="mermaid">${n.text}</div>
`;
    }
  };
}
const t0 = {
  code(n, e, t) {
    var i;
    const r = ((i = (e ?? "").match(/\S*/)) == null ? void 0 : i[0]) ?? "";
    return n = n.replace(/\n$/, "") + `
`, !r || r === "mermaid" ? '<div class="code_wrap">' + Rc + "<pre><code>" + (t ? n : Oo(n, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Rc + '<pre><code class="language-' + Oo(r) + '">' + (t ? n : Oo(n, !0)) + `</code></pre></div>
`;
  }
}, n0 = new pa();
function r0({
  header_links: n,
  line_breaks: e,
  latex_delimiters: t
}) {
  const r = new vf();
  r.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    Pg({
      highlight: (o, l) => {
        var a;
        return (a = $o.languages) != null && a[l] ? $o.highlight(o, $o.languages[l], l) : o;
      }
    }),
    { renderer: t0 }
  ), n && (r.use(jg()), r.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(o) {
          const l = o.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), a = "h" + n0.slug(l), c = o.depth, u = this.parser.parseInline(o.tokens);
          return `<h${c} id="${a}"><a class="md-header-anchor" href="#${a}">${Kg}</a>${u}</h${c}>
`;
        }
      }
    ]
  }));
  const i = e0(), s = Qg(t);
  return r.use({
    extensions: [i, s]
  }), r;
}
const wl = (n) => JSON.parse(JSON.stringify(n)), i0 = (n) => n.nodeType === 1, s0 = (n) => C0.has(n.tagName), o0 = (n) => "action" in n, l0 = (n) => n.tagName === "IFRAME", a0 = (n) => "formAction" in n, c0 = (n) => "protocol" in n, Fi = /* @__PURE__ */ (() => {
  const n = /^(?:\w+script|data):/i;
  return (e) => n.test(e);
})(), u0 = /* @__PURE__ */ (() => {
  const n = /(?:script|data):/i;
  return (e) => n.test(e);
})(), d0 = (n) => {
  const e = {};
  for (let t = 0, r = n.length; t < r; t++) {
    const i = n[t];
    for (const s in i)
      e[s] ? e[s] = e[s].concat(i[s]) : e[s] = i[s];
  }
  return e;
}, Ff = (n, e) => {
  let t = n.firstChild;
  for (; t; ) {
    const r = t.nextSibling;
    i0(t) && (e(t, n), t.parentNode && Ff(t, e)), t = r;
  }
}, f0 = (n, e) => {
  const t = document.createNodeIterator(n, NodeFilter.SHOW_ELEMENT);
  let r;
  for (; r = t.nextNode(); ) {
    const i = r.parentNode;
    i && e(r, i);
  }
}, h0 = (n, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? f0(n, e) : Ff(n, e), $f = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], p0 = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], m0 = /* @__PURE__ */ new Set([
  ...$f,
  ...p0
]), Of = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], g0 = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], _0 = /* @__PURE__ */ new Set([
  ...Of,
  ...g0
]), Nf = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], y0 = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], b0 = /* @__PURE__ */ new Set([
  ...Nf,
  ...y0
]), k0 = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], w0 = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], v0 = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], Et = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, E0 = {
  [Et.HTML]: m0,
  [Et.SVG]: _0,
  [Et.MATH]: b0
}, D0 = {
  [Et.HTML]: "html",
  [Et.SVG]: "svg",
  [Et.MATH]: "math"
}, S0 = {
  [Et.HTML]: "",
  [Et.SVG]: "svg:",
  [Et.MATH]: "math:"
}, C0 = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), If = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...$f,
    ...Of.map((n) => `svg:${n}`),
    ...Nf.map((n) => `math:${n}`)
  ],
  allowAttributes: d0([
    Object.fromEntries(k0.map((n) => [n, ["*"]])),
    Object.fromEntries(w0.map((n) => [n, ["svg:*"]])),
    Object.fromEntries(v0.map((n) => [n, ["math:*"]]))
  ])
};
var No = function(n, e, t, r, i) {
  if (r === "m") throw new TypeError("Private method is not writable");
  if (r === "a" && !i) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? n !== e || !i : !e.has(n)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return r === "a" ? i.call(n, t) : i ? i.value = t : e.set(n, t), t;
}, Sn = function(n, e, t, r) {
  if (t === "a" && !r) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? n !== e || !r : !e.has(n)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? r : t === "a" ? r.call(n) : r ? r.value : e.get(n);
}, sn, es, ts;
class Rf {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    sn.set(this, void 0), es.set(this, void 0), ts.set(this, void 0), this.getConfiguration = () => wl(Sn(this, sn, "f")), this.sanitize = (u) => {
      const d = Sn(this, es, "f"), f = Sn(this, ts, "f");
      return h0(u, (h, p) => {
        const m = h.namespaceURI || Et.HTML, _ = p.namespaceURI || Et.HTML, b = E0[m], y = D0[m], g = S0[m], w = h.tagName.toLowerCase(), E = `${g}${w}`, D = `${g}*`;
        if (!b.has(w) || !d.has(E) || m !== _ && w !== y)
          p.removeChild(h);
        else {
          const S = h.getAttributeNames(), C = S.length;
          if (C) {
            for (let F = 0; F < C; F++) {
              const N = S[F], H = f[N];
              (!H || !H.has(D) && !H.has(E)) && h.removeAttribute(N);
            }
            if (s0(h))
              if (c0(h)) {
                const F = h.getAttribute("href");
                F && u0(F) && Fi(h.protocol) && h.removeAttribute("href");
              } else o0(h) ? Fi(h.action) && h.removeAttribute("action") : a0(h) ? Fi(h.formAction) && h.removeAttribute("formaction") : l0(h) && (Fi(h.src) && h.removeAttribute("formaction"), h.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), u;
    }, this.sanitizeFor = (u, d) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: t, allowCustomElements: r, allowUnknownMarkup: i, blockElements: s, dropElements: o, dropAttributes: l } = e;
    if (t === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (r)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (i)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (s)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (l)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    No(this, sn, wl(If), "f");
    const { allowElements: a, allowAttributes: c } = e;
    a && (Sn(this, sn, "f").allowElements = e.allowElements), c && (Sn(this, sn, "f").allowAttributes = e.allowAttributes), No(this, es, new Set(Sn(this, sn, "f").allowElements), "f"), No(this, ts, Object.fromEntries(Object.entries(Sn(this, sn, "f").allowAttributes || {}).map(([u, d]) => [u, new Set(d)])), "f");
  }
}
sn = /* @__PURE__ */ new WeakMap(), es = /* @__PURE__ */ new WeakMap(), ts = /* @__PURE__ */ new WeakMap();
Rf.getDefaultConfiguration = () => wl(If);
const A0 = (n, e = location.href) => {
  try {
    return !!n && new URL(n).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function Pc(n) {
  const e = new Rf(), t = new DOMParser().parseFromString(n, "text/html");
  return Lf(t.body, "A", (r) => {
    r instanceof HTMLElement && "target" in r && A0(r.getAttribute("href"), location.href) && (r.setAttribute("target", "_blank"), r.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(t).body.innerHTML;
}
function Lf(n, e, t) {
  n && (n.nodeName === e || typeof e == "function") && t(n);
  const r = (n == null ? void 0 : n.childNodes) || [];
  for (let i = 0; i < r.length; i++)
    Lf(r[i], e, t);
}
const Bc = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], x0 = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], T0 = [
  ...Bc,
  ...x0.filter((n) => !Bc.includes(n))
], {
  HtmlTagHydration: M0,
  SvelteComponent: F0,
  attr: $0,
  binding_callbacks: O0,
  children: N0,
  claim_element: I0,
  claim_html_tag: R0,
  detach: zc,
  element: L0,
  init: P0,
  insert_hydration: B0,
  noop: Hc,
  safe_not_equal: z0,
  toggle_class: $i
} = window.__gradio__svelte__internal, { afterUpdate: H0, tick: q0, onMount: eS } = window.__gradio__svelte__internal;
function V0(n) {
  let e, t;
  return {
    c() {
      e = L0("span"), t = new M0(!1), this.h();
    },
    l(r) {
      e = I0(r, "SPAN", { class: !0 });
      var i = N0(e);
      t = R0(i, !1), i.forEach(zc), this.h();
    },
    h() {
      t.a = null, $0(e, "class", "md svelte-1m32c2s"), $i(
        e,
        "chatbot",
        /*chatbot*/
        n[0]
      ), $i(
        e,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    m(r, i) {
      B0(r, e, i), t.m(
        /*html*/
        n[3],
        e
      ), n[11](e);
    },
    p(r, [i]) {
      i & /*html*/
      8 && t.p(
        /*html*/
        r[3]
      ), i & /*chatbot*/
      1 && $i(
        e,
        "chatbot",
        /*chatbot*/
        r[0]
      ), i & /*render_markdown*/
      2 && $i(
        e,
        "prose",
        /*render_markdown*/
        r[1]
      );
    },
    i: Hc,
    o: Hc,
    d(r) {
      r && zc(e), n[11](null);
    }
  };
}
function qc(n) {
  return n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function U0(n, e, t) {
  var r = this && this.__awaiter || function(v, D, S, C) {
    function F(N) {
      return N instanceof S ? N : new S(function(H) {
        H(N);
      });
    }
    return new (S || (S = Promise))(function(N, H) {
      function ke(K) {
        try {
          ce(C.next(K));
        } catch (pe) {
          H(pe);
        }
      }
      function Q(K) {
        try {
          ce(C.throw(K));
        } catch (pe) {
          H(pe);
        }
      }
      function ce(K) {
        K.done ? N(K.value) : F(K.value).then(ke, Q);
      }
      ce((C = C.apply(v, D || [])).next());
    });
  };
  let { chatbot: i = !0 } = e, { message: s } = e, { sanitize_html: o = !0 } = e, { latex_delimiters: l = [] } = e, { render_markdown: a = !0 } = e, { line_breaks: c = !0 } = e, { header_links: u = !1 } = e, { allow_tags: d = !1 } = e, { theme_mode: f = "system" } = e, h, p, m = !1;
  const _ = r0({
    header_links: u,
    line_breaks: c,
    latex_delimiters: l || []
  });
  function b(v) {
    return !l || l.length === 0 ? !1 : l.some((D) => v.includes(D.left) && v.includes(D.right));
  }
  function y(v, D) {
    if (D === !0) {
      const S = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return v.replace(S, (C, F, N) => T0.includes(F.toLowerCase()) ? C : C.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(D)) {
      const S = D.map((F) => ({
        open: new RegExp(`<(${F})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${F})>`, "gi")
      }));
      let C = v;
      return S.forEach((F) => {
        C = C.replace(F.open, (N) => N.replace(/</g, "&lt;").replace(/>/g, "&gt;")), C = C.replace(F.close, (N) => N.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), C;
    }
    return v;
  }
  function g(v) {
    let D = v;
    if (a) {
      const S = [];
      l.forEach((C, F) => {
        const N = qc(C.left), H = qc(C.right), ke = new RegExp(`${N}([\\s\\S]+?)${H}`, "g");
        D = D.replace(ke, (Q, ce) => (S.push(Q), `%%%LATEX_BLOCK_${S.length - 1}%%%`));
      }), D = _.parse(D), D = D.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (C, F) => S[parseInt(F, 10)]);
    }
    return d && (D = y(D, d)), o && Pc && (D = Pc(D)), D;
  }
  function w(v) {
    return r(this, void 0, void 0, function* () {
      if (l.length > 0 && v && b(v))
        if (!m)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-BwaQGe8P.js")
          ]).then(([, { default: D }]) => {
            m = !0, D(h, {
              delimiters: l,
              throwOnError: !1
            });
          });
        else {
          const { default: D } = yield import("./auto-render-BwaQGe8P.js");
          D(h, {
            delimiters: l,
            throwOnError: !1
          });
        }
      if (h) {
        const D = h.querySelectorAll(".mermaid");
        if (D.length > 0) {
          yield q0();
          const { default: S } = yield import("./mermaid.core-D9A36DYx.js").then((C) => C.bB);
          S.initialize({
            startOnLoad: !1,
            theme: f === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield S.run({
            nodes: Array.from(D).map((C) => C)
          });
        }
      }
    });
  }
  H0(() => r(void 0, void 0, void 0, function* () {
    h && document.body.contains(h) ? yield w(s) : console.error("Element is not in the DOM");
  }));
  function E(v) {
    O0[v ? "unshift" : "push"](() => {
      h = v, t(2, h);
    });
  }
  return n.$$set = (v) => {
    "chatbot" in v && t(0, i = v.chatbot), "message" in v && t(4, s = v.message), "sanitize_html" in v && t(5, o = v.sanitize_html), "latex_delimiters" in v && t(6, l = v.latex_delimiters), "render_markdown" in v && t(1, a = v.render_markdown), "line_breaks" in v && t(7, c = v.line_breaks), "header_links" in v && t(8, u = v.header_links), "allow_tags" in v && t(9, d = v.allow_tags), "theme_mode" in v && t(10, f = v.theme_mode);
  }, n.$$.update = () => {
    n.$$.dirty & /*message*/
    16 && (s && s.trim() ? t(3, p = g(s)) : t(3, p = ""));
  }, [
    i,
    a,
    h,
    p,
    s,
    o,
    l,
    c,
    u,
    d,
    f,
    E
  ];
}
class j0 extends F0 {
  constructor(e) {
    super(), P0(this, e, U0, V0, z0, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: W0,
  attr: K0,
  children: G0,
  claim_component: J0,
  claim_element: Y0,
  create_component: X0,
  destroy_component: Z0,
  detach: Vc,
  element: Q0,
  init: e_,
  insert_hydration: t_,
  mount_component: n_,
  safe_not_equal: r_,
  transition_in: i_,
  transition_out: s_
} = window.__gradio__svelte__internal;
function o_(n) {
  let e, t, r;
  return t = new j0({
    props: {
      message: (
        /*info*/
        n[0]
      ),
      sanitize_html: !0
    }
  }), {
    c() {
      e = Q0("div"), X0(t.$$.fragment), this.h();
    },
    l(i) {
      e = Y0(i, "DIV", { class: !0 });
      var s = G0(e);
      J0(t.$$.fragment, s), s.forEach(Vc), this.h();
    },
    h() {
      K0(e, "class", "svelte-17qq50w");
    },
    m(i, s) {
      t_(i, e, s), n_(t, e, null), r = !0;
    },
    p(i, [s]) {
      const o = {};
      s & /*info*/
      1 && (o.message = /*info*/
      i[0]), t.$set(o);
    },
    i(i) {
      r || (i_(t.$$.fragment, i), r = !0);
    },
    o(i) {
      s_(t.$$.fragment, i), r = !1;
    },
    d(i) {
      i && Vc(e), Z0(t);
    }
  };
}
function l_(n, e, t) {
  let { info: r } = e;
  return n.$$set = (i) => {
    "info" in i && t(0, r = i.info);
  }, [r];
}
class a_ extends W0 {
  constructor(e) {
    super(), e_(this, e, l_, o_, r_, { info: 0 });
  }
}
const {
  SvelteComponent: c_,
  attr: Oi,
  check_outros: u_,
  children: d_,
  claim_component: f_,
  claim_element: h_,
  claim_space: p_,
  create_component: m_,
  create_slot: g_,
  destroy_component: __,
  detach: Ni,
  element: y_,
  empty: Uc,
  get_all_dirty_from_scope: b_,
  get_slot_changes: k_,
  group_outros: w_,
  init: v_,
  insert_hydration: Io,
  mount_component: E_,
  safe_not_equal: D_,
  space: S_,
  toggle_class: rr,
  transition_in: Rr,
  transition_out: ns,
  update_slot_base: C_
} = window.__gradio__svelte__internal;
function jc(n) {
  let e, t;
  return e = new a_({ props: { info: (
    /*info*/
    n[1]
  ) } }), {
    c() {
      m_(e.$$.fragment);
    },
    l(r) {
      f_(e.$$.fragment, r);
    },
    m(r, i) {
      E_(e, r, i), t = !0;
    },
    p(r, i) {
      const s = {};
      i & /*info*/
      2 && (s.info = /*info*/
      r[1]), e.$set(s);
    },
    i(r) {
      t || (Rr(e.$$.fragment, r), t = !0);
    },
    o(r) {
      ns(e.$$.fragment, r), t = !1;
    },
    d(r) {
      __(e, r);
    }
  };
}
function A_(n) {
  let e, t, r, i, s;
  const o = (
    /*#slots*/
    n[4].default
  ), l = g_(
    o,
    n,
    /*$$scope*/
    n[3],
    null
  );
  let a = (
    /*info*/
    n[1] && jc(n)
  );
  return {
    c() {
      e = y_("span"), l && l.c(), r = S_(), a && a.c(), i = Uc(), this.h();
    },
    l(c) {
      e = h_(c, "SPAN", {
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var u = d_(e);
      l && l.l(u), u.forEach(Ni), r = p_(c), a && a.l(c), i = Uc(), this.h();
    },
    h() {
      Oi(e, "data-testid", "block-info"), Oi(e, "dir", t = /*rtl*/
      n[2] ? "rtl" : "ltr"), Oi(e, "class", "svelte-zgrq3"), rr(e, "sr-only", !/*show_label*/
      n[0]), rr(e, "hide", !/*show_label*/
      n[0]), rr(
        e,
        "has-info",
        /*info*/
        n[1] != null
      );
    },
    m(c, u) {
      Io(c, e, u), l && l.m(e, null), Io(c, r, u), a && a.m(c, u), Io(c, i, u), s = !0;
    },
    p(c, [u]) {
      l && l.p && (!s || u & /*$$scope*/
      8) && C_(
        l,
        o,
        c,
        /*$$scope*/
        c[3],
        s ? k_(
          o,
          /*$$scope*/
          c[3],
          u,
          null
        ) : b_(
          /*$$scope*/
          c[3]
        ),
        null
      ), (!s || u & /*rtl*/
      4 && t !== (t = /*rtl*/
      c[2] ? "rtl" : "ltr")) && Oi(e, "dir", t), (!s || u & /*show_label*/
      1) && rr(e, "sr-only", !/*show_label*/
      c[0]), (!s || u & /*show_label*/
      1) && rr(e, "hide", !/*show_label*/
      c[0]), (!s || u & /*info*/
      2) && rr(
        e,
        "has-info",
        /*info*/
        c[1] != null
      ), /*info*/
      c[1] ? a ? (a.p(c, u), u & /*info*/
      2 && Rr(a, 1)) : (a = jc(c), a.c(), Rr(a, 1), a.m(i.parentNode, i)) : a && (w_(), ns(a, 1, 1, () => {
        a = null;
      }), u_());
    },
    i(c) {
      s || (Rr(l, c), Rr(a), s = !0);
    },
    o(c) {
      ns(l, c), ns(a), s = !1;
    },
    d(c) {
      c && (Ni(e), Ni(r), Ni(i)), l && l.d(c), a && a.d(c);
    }
  };
}
function x_(n, e, t) {
  let { $$slots: r = {}, $$scope: i } = e, { show_label: s = !0 } = e, { info: o = void 0 } = e, { rtl: l = !1 } = e;
  return n.$$set = (a) => {
    "show_label" in a && t(0, s = a.show_label), "info" in a && t(1, o = a.info), "rtl" in a && t(2, l = a.rtl), "$$scope" in a && t(3, i = a.$$scope);
  }, [s, o, l, i, r];
}
class T_ extends c_ {
  constructor(e) {
    super(), v_(this, e, x_, A_, D_, { show_label: 0, info: 1, rtl: 2 });
  }
}
const {
  SvelteComponent: tS,
  append_hydration: nS,
  attr: rS,
  children: iS,
  claim_component: sS,
  claim_element: oS,
  claim_space: lS,
  claim_text: aS,
  create_component: cS,
  destroy_component: uS,
  detach: dS,
  element: fS,
  init: hS,
  insert_hydration: pS,
  mount_component: mS,
  safe_not_equal: gS,
  set_data: _S,
  space: yS,
  text: bS,
  toggle_class: kS,
  transition_in: wS,
  transition_out: vS
} = window.__gradio__svelte__internal, {
  SvelteComponent: M_,
  append_hydration: rs,
  attr: Wt,
  bubble: F_,
  check_outros: $_,
  children: vl,
  claim_component: O_,
  claim_element: El,
  claim_space: Wc,
  claim_text: N_,
  construct_svelte_component: Kc,
  create_component: Gc,
  create_slot: I_,
  destroy_component: Jc,
  detach: jr,
  element: Dl,
  get_all_dirty_from_scope: R_,
  get_slot_changes: L_,
  group_outros: P_,
  init: B_,
  insert_hydration: Pf,
  listen: z_,
  mount_component: Yc,
  safe_not_equal: H_,
  set_data: q_,
  set_style: Ii,
  space: Xc,
  text: V_,
  toggle_class: Oe,
  transition_in: Ro,
  transition_out: Lo,
  update_slot_base: U_
} = window.__gradio__svelte__internal;
function Zc(n) {
  let e, t;
  return {
    c() {
      e = Dl("span"), t = V_(
        /*label*/
        n[1]
      ), this.h();
    },
    l(r) {
      e = El(r, "SPAN", { class: !0 });
      var i = vl(e);
      t = N_(
        i,
        /*label*/
        n[1]
      ), i.forEach(jr), this.h();
    },
    h() {
      Wt(e, "class", "svelte-qgco6m");
    },
    m(r, i) {
      Pf(r, e, i), rs(e, t);
    },
    p(r, i) {
      i & /*label*/
      2 && q_(
        t,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && jr(e);
    }
  };
}
function j_(n) {
  let e, t, r, i, s, o, l, a, c = (
    /*show_label*/
    n[2] && Zc(n)
  );
  var u = (
    /*Icon*/
    n[0]
  );
  function d(p, m) {
    return {};
  }
  u && (i = Kc(u, d()));
  const f = (
    /*#slots*/
    n[14].default
  ), h = I_(
    f,
    n,
    /*$$scope*/
    n[13],
    null
  );
  return {
    c() {
      e = Dl("button"), c && c.c(), t = Xc(), r = Dl("div"), i && Gc(i.$$.fragment), s = Xc(), h && h.c(), this.h();
    },
    l(p) {
      e = El(p, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var m = vl(e);
      c && c.l(m), t = Wc(m), r = El(m, "DIV", { class: !0 });
      var _ = vl(r);
      i && O_(i.$$.fragment, _), s = Wc(_), h && h.l(_), _.forEach(jr), m.forEach(jr), this.h();
    },
    h() {
      Wt(r, "class", "svelte-qgco6m"), Oe(
        r,
        "x-small",
        /*size*/
        n[4] === "x-small"
      ), Oe(
        r,
        "small",
        /*size*/
        n[4] === "small"
      ), Oe(
        r,
        "large",
        /*size*/
        n[4] === "large"
      ), Oe(
        r,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], Wt(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), Wt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), Wt(
        e,
        "title",
        /*label*/
        n[1]
      ), Wt(e, "class", "svelte-qgco6m"), Oe(
        e,
        "pending",
        /*pending*/
        n[3]
      ), Oe(
        e,
        "padded",
        /*padded*/
        n[5]
      ), Oe(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), Oe(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), Ii(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), Ii(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(p, m) {
      Pf(p, e, m), c && c.m(e, null), rs(e, t), rs(e, r), i && Yc(i, r, null), rs(r, s), h && h.m(r, null), o = !0, l || (a = z_(
        e,
        "click",
        /*click_handler*/
        n[15]
      ), l = !0);
    },
    p(p, [m]) {
      if (/*show_label*/
      p[2] ? c ? c.p(p, m) : (c = Zc(p), c.c(), c.m(e, t)) : c && (c.d(1), c = null), m & /*Icon*/
      1 && u !== (u = /*Icon*/
      p[0])) {
        if (i) {
          P_();
          const _ = i;
          Lo(_.$$.fragment, 1, 0, () => {
            Jc(_, 1);
          }), $_();
        }
        u ? (i = Kc(u, d()), Gc(i.$$.fragment), Ro(i.$$.fragment, 1), Yc(i, r, s)) : i = null;
      }
      h && h.p && (!o || m & /*$$scope*/
      8192) && U_(
        h,
        f,
        p,
        /*$$scope*/
        p[13],
        o ? L_(
          f,
          /*$$scope*/
          p[13],
          m,
          null
        ) : R_(
          /*$$scope*/
          p[13]
        ),
        null
      ), (!o || m & /*size*/
      16) && Oe(
        r,
        "x-small",
        /*size*/
        p[4] === "x-small"
      ), (!o || m & /*size*/
      16) && Oe(
        r,
        "small",
        /*size*/
        p[4] === "small"
      ), (!o || m & /*size*/
      16) && Oe(
        r,
        "large",
        /*size*/
        p[4] === "large"
      ), (!o || m & /*size*/
      16) && Oe(
        r,
        "medium",
        /*size*/
        p[4] === "medium"
      ), (!o || m & /*disabled*/
      128) && (e.disabled = /*disabled*/
      p[7]), (!o || m & /*label*/
      2) && Wt(
        e,
        "aria-label",
        /*label*/
        p[1]
      ), (!o || m & /*hasPopup*/
      256) && Wt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        p[8]
      ), (!o || m & /*label*/
      2) && Wt(
        e,
        "title",
        /*label*/
        p[1]
      ), (!o || m & /*pending*/
      8) && Oe(
        e,
        "pending",
        /*pending*/
        p[3]
      ), (!o || m & /*padded*/
      32) && Oe(
        e,
        "padded",
        /*padded*/
        p[5]
      ), (!o || m & /*highlight*/
      64) && Oe(
        e,
        "highlight",
        /*highlight*/
        p[6]
      ), (!o || m & /*transparent*/
      512) && Oe(
        e,
        "transparent",
        /*transparent*/
        p[9]
      ), m & /*disabled, _color*/
      2176 && Ii(e, "color", !/*disabled*/
      p[7] && /*_color*/
      p[11] ? (
        /*_color*/
        p[11]
      ) : "var(--block-label-text-color)"), m & /*disabled, background*/
      1152 && Ii(e, "--bg-color", /*disabled*/
      p[7] ? "auto" : (
        /*background*/
        p[10]
      ));
    },
    i(p) {
      o || (i && Ro(i.$$.fragment, p), Ro(h, p), o = !0);
    },
    o(p) {
      i && Lo(i.$$.fragment, p), Lo(h, p), o = !1;
    },
    d(p) {
      p && jr(e), c && c.d(), i && Jc(i), h && h.d(p), l = !1, a();
    }
  };
}
function W_(n, e, t) {
  let r, { $$slots: i = {}, $$scope: s } = e, { Icon: o } = e, { label: l = "" } = e, { show_label: a = !1 } = e, { pending: c = !1 } = e, { size: u = "small" } = e, { padded: d = !0 } = e, { highlight: f = !1 } = e, { disabled: h = !1 } = e, { hasPopup: p = !1 } = e, { color: m = "var(--block-label-text-color)" } = e, { transparent: _ = !1 } = e, { background: b = "var(--block-background-fill)" } = e;
  function y(g) {
    F_.call(this, n, g);
  }
  return n.$$set = (g) => {
    "Icon" in g && t(0, o = g.Icon), "label" in g && t(1, l = g.label), "show_label" in g && t(2, a = g.show_label), "pending" in g && t(3, c = g.pending), "size" in g && t(4, u = g.size), "padded" in g && t(5, d = g.padded), "highlight" in g && t(6, f = g.highlight), "disabled" in g && t(7, h = g.disabled), "hasPopup" in g && t(8, p = g.hasPopup), "color" in g && t(12, m = g.color), "transparent" in g && t(9, _ = g.transparent), "background" in g && t(10, b = g.background), "$$scope" in g && t(13, s = g.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, r = f ? "var(--color-accent)" : m);
  }, [
    o,
    l,
    a,
    c,
    u,
    d,
    f,
    h,
    p,
    _,
    b,
    r,
    m,
    s,
    i,
    y
  ];
}
class K_ extends M_ {
  constructor(e) {
    super(), B_(this, e, W_, j_, H_, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: ES,
  append_hydration: DS,
  attr: SS,
  binding_callbacks: CS,
  children: AS,
  claim_element: xS,
  create_slot: TS,
  detach: MS,
  element: FS,
  get_all_dirty_from_scope: $S,
  get_slot_changes: OS,
  init: NS,
  insert_hydration: IS,
  safe_not_equal: RS,
  toggle_class: LS,
  transition_in: PS,
  transition_out: BS,
  update_slot_base: zS
} = window.__gradio__svelte__internal, {
  SvelteComponent: HS,
  append_hydration: qS,
  attr: VS,
  children: US,
  claim_svg_element: jS,
  detach: WS,
  init: KS,
  insert_hydration: GS,
  noop: JS,
  safe_not_equal: YS,
  svg_element: XS
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZS,
  append_hydration: QS,
  attr: eC,
  children: tC,
  claim_svg_element: nC,
  detach: rC,
  init: iC,
  insert_hydration: sC,
  noop: oC,
  safe_not_equal: lC,
  svg_element: aC
} = window.__gradio__svelte__internal, {
  SvelteComponent: cC,
  append_hydration: uC,
  attr: dC,
  children: fC,
  claim_svg_element: hC,
  detach: pC,
  init: mC,
  insert_hydration: gC,
  noop: _C,
  safe_not_equal: yC,
  svg_element: bC
} = window.__gradio__svelte__internal, {
  SvelteComponent: kC,
  append_hydration: wC,
  attr: vC,
  children: EC,
  claim_svg_element: DC,
  detach: SC,
  init: CC,
  insert_hydration: AC,
  noop: xC,
  safe_not_equal: TC,
  svg_element: MC
} = window.__gradio__svelte__internal, {
  SvelteComponent: FC,
  append_hydration: $C,
  attr: OC,
  children: NC,
  claim_svg_element: IC,
  detach: RC,
  init: LC,
  insert_hydration: PC,
  noop: BC,
  safe_not_equal: zC,
  svg_element: HC
} = window.__gradio__svelte__internal, {
  SvelteComponent: qC,
  append_hydration: VC,
  attr: UC,
  children: jC,
  claim_svg_element: WC,
  detach: KC,
  init: GC,
  insert_hydration: JC,
  noop: YC,
  safe_not_equal: XC,
  svg_element: ZC
} = window.__gradio__svelte__internal, {
  SvelteComponent: QC,
  append_hydration: eA,
  attr: tA,
  children: nA,
  claim_svg_element: rA,
  detach: iA,
  init: sA,
  insert_hydration: oA,
  noop: lA,
  safe_not_equal: aA,
  svg_element: cA
} = window.__gradio__svelte__internal, {
  SvelteComponent: uA,
  append_hydration: dA,
  attr: fA,
  children: hA,
  claim_svg_element: pA,
  detach: mA,
  init: gA,
  insert_hydration: _A,
  noop: yA,
  safe_not_equal: bA,
  svg_element: kA
} = window.__gradio__svelte__internal, {
  SvelteComponent: wA,
  append_hydration: vA,
  attr: EA,
  children: DA,
  claim_svg_element: SA,
  detach: CA,
  init: AA,
  insert_hydration: xA,
  noop: TA,
  safe_not_equal: MA,
  svg_element: FA
} = window.__gradio__svelte__internal, {
  SvelteComponent: $A,
  append_hydration: OA,
  attr: NA,
  children: IA,
  claim_svg_element: RA,
  detach: LA,
  init: PA,
  insert_hydration: BA,
  noop: zA,
  safe_not_equal: HA,
  svg_element: qA
} = window.__gradio__svelte__internal, {
  SvelteComponent: VA,
  append_hydration: UA,
  attr: jA,
  children: WA,
  claim_svg_element: KA,
  detach: GA,
  init: JA,
  insert_hydration: YA,
  noop: XA,
  safe_not_equal: ZA,
  svg_element: QA
} = window.__gradio__svelte__internal, {
  SvelteComponent: ex,
  append_hydration: tx,
  attr: nx,
  children: rx,
  claim_svg_element: ix,
  detach: sx,
  init: ox,
  insert_hydration: lx,
  noop: ax,
  safe_not_equal: cx,
  svg_element: ux
} = window.__gradio__svelte__internal, {
  SvelteComponent: G_,
  append_hydration: Po,
  attr: pt,
  children: Ri,
  claim_svg_element: Li,
  detach: xr,
  init: J_,
  insert_hydration: Y_,
  noop: Bo,
  safe_not_equal: X_,
  set_style: At,
  svg_element: Pi
} = window.__gradio__svelte__internal;
function Z_(n) {
  let e, t, r, i;
  return {
    c() {
      e = Pi("svg"), t = Pi("g"), r = Pi("path"), i = Pi("path"), this.h();
    },
    l(s) {
      e = Li(s, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var o = Ri(e);
      t = Li(o, "g", { transform: !0 });
      var l = Ri(t);
      r = Li(l, "path", { d: !0, style: !0 }), Ri(r).forEach(xr), l.forEach(xr), i = Li(o, "path", { d: !0, style: !0 }), Ri(i).forEach(xr), o.forEach(xr), this.h();
    },
    h() {
      pt(r, "d", "M18,6L6.087,17.913"), At(r, "fill", "none"), At(r, "fill-rule", "nonzero"), At(r, "stroke-width", "2px"), pt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), pt(i, "d", "M4.364,4.364L19.636,19.636"), At(i, "fill", "none"), At(i, "fill-rule", "nonzero"), At(i, "stroke-width", "2px"), pt(e, "width", "100%"), pt(e, "height", "100%"), pt(e, "viewBox", "0 0 24 24"), pt(e, "version", "1.1"), pt(e, "xmlns", "http://www.w3.org/2000/svg"), pt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), pt(e, "xml:space", "preserve"), pt(e, "stroke", "currentColor"), At(e, "fill-rule", "evenodd"), At(e, "clip-rule", "evenodd"), At(e, "stroke-linecap", "round"), At(e, "stroke-linejoin", "round");
    },
    m(s, o) {
      Y_(s, e, o), Po(e, t), Po(t, r), Po(e, i);
    },
    p: Bo,
    i: Bo,
    o: Bo,
    d(s) {
      s && xr(e);
    }
  };
}
class Q_ extends G_ {
  constructor(e) {
    super(), J_(this, e, null, Z_, X_, {});
  }
}
const {
  SvelteComponent: dx,
  append_hydration: fx,
  attr: hx,
  children: px,
  claim_svg_element: mx,
  detach: gx,
  init: _x,
  insert_hydration: yx,
  noop: bx,
  safe_not_equal: kx,
  svg_element: wx
} = window.__gradio__svelte__internal, {
  SvelteComponent: vx,
  append_hydration: Ex,
  attr: Dx,
  children: Sx,
  claim_svg_element: Cx,
  detach: Ax,
  init: xx,
  insert_hydration: Tx,
  noop: Mx,
  safe_not_equal: Fx,
  svg_element: $x
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ox,
  append_hydration: Nx,
  attr: Ix,
  children: Rx,
  claim_svg_element: Lx,
  detach: Px,
  init: Bx,
  insert_hydration: zx,
  noop: Hx,
  safe_not_equal: qx,
  svg_element: Vx
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ux,
  append_hydration: jx,
  attr: Wx,
  children: Kx,
  claim_svg_element: Gx,
  detach: Jx,
  init: Yx,
  insert_hydration: Xx,
  noop: Zx,
  safe_not_equal: Qx,
  svg_element: eT
} = window.__gradio__svelte__internal, {
  SvelteComponent: tT,
  append_hydration: nT,
  attr: rT,
  children: iT,
  claim_svg_element: sT,
  detach: oT,
  init: lT,
  insert_hydration: aT,
  noop: cT,
  safe_not_equal: uT,
  svg_element: dT
} = window.__gradio__svelte__internal, {
  SvelteComponent: fT,
  append_hydration: hT,
  attr: pT,
  children: mT,
  claim_svg_element: gT,
  detach: _T,
  init: yT,
  insert_hydration: bT,
  noop: kT,
  safe_not_equal: wT,
  svg_element: vT
} = window.__gradio__svelte__internal, {
  SvelteComponent: ET,
  append_hydration: DT,
  attr: ST,
  children: CT,
  claim_svg_element: AT,
  detach: xT,
  init: TT,
  insert_hydration: MT,
  noop: FT,
  safe_not_equal: $T,
  svg_element: OT
} = window.__gradio__svelte__internal, {
  SvelteComponent: NT,
  append_hydration: IT,
  attr: RT,
  children: LT,
  claim_svg_element: PT,
  detach: BT,
  init: zT,
  insert_hydration: HT,
  noop: qT,
  safe_not_equal: VT,
  svg_element: UT
} = window.__gradio__svelte__internal, {
  SvelteComponent: jT,
  append_hydration: WT,
  attr: KT,
  children: GT,
  claim_svg_element: JT,
  detach: YT,
  init: XT,
  insert_hydration: ZT,
  noop: QT,
  safe_not_equal: eM,
  svg_element: tM
} = window.__gradio__svelte__internal, {
  SvelteComponent: nM,
  append_hydration: rM,
  attr: iM,
  children: sM,
  claim_svg_element: oM,
  detach: lM,
  init: aM,
  insert_hydration: cM,
  noop: uM,
  safe_not_equal: dM,
  svg_element: fM
} = window.__gradio__svelte__internal, {
  SvelteComponent: hM,
  append_hydration: pM,
  attr: mM,
  children: gM,
  claim_svg_element: _M,
  detach: yM,
  init: bM,
  insert_hydration: kM,
  noop: wM,
  safe_not_equal: vM,
  svg_element: EM
} = window.__gradio__svelte__internal, {
  SvelteComponent: DM,
  append_hydration: SM,
  attr: CM,
  children: AM,
  claim_svg_element: xM,
  detach: TM,
  init: MM,
  insert_hydration: FM,
  noop: $M,
  safe_not_equal: OM,
  svg_element: NM
} = window.__gradio__svelte__internal, {
  SvelteComponent: IM,
  append_hydration: RM,
  attr: LM,
  children: PM,
  claim_svg_element: BM,
  detach: zM,
  init: HM,
  insert_hydration: qM,
  noop: VM,
  safe_not_equal: UM,
  svg_element: jM
} = window.__gradio__svelte__internal, {
  SvelteComponent: WM,
  append_hydration: KM,
  attr: GM,
  children: JM,
  claim_svg_element: YM,
  detach: XM,
  init: ZM,
  insert_hydration: QM,
  noop: e2,
  safe_not_equal: t2,
  svg_element: n2
} = window.__gradio__svelte__internal, {
  SvelteComponent: r2,
  append_hydration: i2,
  attr: s2,
  children: o2,
  claim_svg_element: l2,
  detach: a2,
  init: c2,
  insert_hydration: u2,
  noop: d2,
  safe_not_equal: f2,
  svg_element: h2
} = window.__gradio__svelte__internal, {
  SvelteComponent: p2,
  append_hydration: m2,
  attr: g2,
  children: _2,
  claim_svg_element: y2,
  detach: b2,
  init: k2,
  insert_hydration: w2,
  noop: v2,
  safe_not_equal: E2,
  svg_element: D2
} = window.__gradio__svelte__internal, {
  SvelteComponent: S2,
  append_hydration: C2,
  attr: A2,
  children: x2,
  claim_svg_element: T2,
  detach: M2,
  init: F2,
  insert_hydration: $2,
  noop: O2,
  safe_not_equal: N2,
  svg_element: I2
} = window.__gradio__svelte__internal, {
  SvelteComponent: R2,
  append_hydration: L2,
  attr: P2,
  children: B2,
  claim_svg_element: z2,
  detach: H2,
  init: q2,
  insert_hydration: V2,
  noop: U2,
  safe_not_equal: j2,
  svg_element: W2
} = window.__gradio__svelte__internal, {
  SvelteComponent: K2,
  append_hydration: G2,
  attr: J2,
  children: Y2,
  claim_svg_element: X2,
  detach: Z2,
  init: Q2,
  insert_hydration: eF,
  noop: tF,
  safe_not_equal: nF,
  svg_element: rF
} = window.__gradio__svelte__internal, {
  SvelteComponent: iF,
  append_hydration: sF,
  attr: oF,
  children: lF,
  claim_svg_element: aF,
  detach: cF,
  init: uF,
  insert_hydration: dF,
  noop: fF,
  safe_not_equal: hF,
  svg_element: pF
} = window.__gradio__svelte__internal, {
  SvelteComponent: mF,
  append_hydration: gF,
  attr: _F,
  children: yF,
  claim_svg_element: bF,
  detach: kF,
  init: wF,
  insert_hydration: vF,
  noop: EF,
  safe_not_equal: DF,
  svg_element: SF
} = window.__gradio__svelte__internal, {
  SvelteComponent: CF,
  append_hydration: AF,
  attr: xF,
  children: TF,
  claim_svg_element: MF,
  detach: FF,
  init: $F,
  insert_hydration: OF,
  noop: NF,
  safe_not_equal: IF,
  svg_element: RF
} = window.__gradio__svelte__internal, {
  SvelteComponent: LF,
  append_hydration: PF,
  attr: BF,
  children: zF,
  claim_svg_element: HF,
  detach: qF,
  init: VF,
  insert_hydration: UF,
  noop: jF,
  safe_not_equal: WF,
  svg_element: KF
} = window.__gradio__svelte__internal, {
  SvelteComponent: GF,
  append_hydration: JF,
  attr: YF,
  children: XF,
  claim_svg_element: ZF,
  detach: QF,
  init: e$,
  insert_hydration: t$,
  noop: n$,
  safe_not_equal: r$,
  svg_element: i$
} = window.__gradio__svelte__internal, {
  SvelteComponent: s$,
  append_hydration: o$,
  attr: l$,
  children: a$,
  claim_svg_element: c$,
  detach: u$,
  init: d$,
  insert_hydration: f$,
  noop: h$,
  safe_not_equal: p$,
  svg_element: m$
} = window.__gradio__svelte__internal, {
  SvelteComponent: g$,
  append_hydration: _$,
  attr: y$,
  children: b$,
  claim_svg_element: k$,
  detach: w$,
  init: v$,
  insert_hydration: E$,
  noop: D$,
  safe_not_equal: S$,
  svg_element: C$
} = window.__gradio__svelte__internal, {
  SvelteComponent: A$,
  append_hydration: x$,
  attr: T$,
  children: M$,
  claim_svg_element: F$,
  detach: $$,
  init: O$,
  insert_hydration: N$,
  noop: I$,
  safe_not_equal: R$,
  svg_element: L$
} = window.__gradio__svelte__internal, {
  SvelteComponent: P$,
  append_hydration: B$,
  attr: z$,
  children: H$,
  claim_svg_element: q$,
  detach: V$,
  init: U$,
  insert_hydration: j$,
  noop: W$,
  safe_not_equal: K$,
  svg_element: G$
} = window.__gradio__svelte__internal, {
  SvelteComponent: J$,
  append_hydration: Y$,
  attr: X$,
  children: Z$,
  claim_svg_element: Q$,
  detach: eO,
  init: tO,
  insert_hydration: nO,
  noop: rO,
  safe_not_equal: iO,
  svg_element: sO
} = window.__gradio__svelte__internal, {
  SvelteComponent: oO,
  append_hydration: lO,
  attr: aO,
  children: cO,
  claim_svg_element: uO,
  detach: dO,
  init: fO,
  insert_hydration: hO,
  noop: pO,
  safe_not_equal: mO,
  svg_element: gO
} = window.__gradio__svelte__internal, {
  SvelteComponent: _O,
  append_hydration: yO,
  attr: bO,
  children: kO,
  claim_svg_element: wO,
  detach: vO,
  init: EO,
  insert_hydration: DO,
  noop: SO,
  safe_not_equal: CO,
  svg_element: AO
} = window.__gradio__svelte__internal, {
  SvelteComponent: xO,
  append_hydration: TO,
  attr: MO,
  children: FO,
  claim_svg_element: $O,
  detach: OO,
  init: NO,
  insert_hydration: IO,
  noop: RO,
  safe_not_equal: LO,
  svg_element: PO
} = window.__gradio__svelte__internal, {
  SvelteComponent: BO,
  append_hydration: zO,
  attr: HO,
  children: qO,
  claim_svg_element: VO,
  detach: UO,
  init: jO,
  insert_hydration: WO,
  noop: KO,
  safe_not_equal: GO,
  svg_element: JO
} = window.__gradio__svelte__internal, {
  SvelteComponent: YO,
  append_hydration: XO,
  attr: ZO,
  children: QO,
  claim_svg_element: eN,
  detach: tN,
  init: nN,
  insert_hydration: rN,
  noop: iN,
  safe_not_equal: sN,
  svg_element: oN
} = window.__gradio__svelte__internal, {
  SvelteComponent: lN,
  append_hydration: aN,
  attr: cN,
  children: uN,
  claim_svg_element: dN,
  detach: fN,
  init: hN,
  insert_hydration: pN,
  noop: mN,
  safe_not_equal: gN,
  set_style: _N,
  svg_element: yN
} = window.__gradio__svelte__internal, {
  SvelteComponent: bN,
  append_hydration: kN,
  attr: wN,
  children: vN,
  claim_svg_element: EN,
  detach: DN,
  init: SN,
  insert_hydration: CN,
  noop: AN,
  safe_not_equal: xN,
  svg_element: TN
} = window.__gradio__svelte__internal, {
  SvelteComponent: MN,
  append_hydration: FN,
  attr: $N,
  children: ON,
  claim_svg_element: NN,
  detach: IN,
  init: RN,
  insert_hydration: LN,
  noop: PN,
  safe_not_equal: BN,
  svg_element: zN
} = window.__gradio__svelte__internal, {
  SvelteComponent: HN,
  append_hydration: qN,
  attr: VN,
  children: UN,
  claim_svg_element: jN,
  detach: WN,
  init: KN,
  insert_hydration: GN,
  noop: JN,
  safe_not_equal: YN,
  svg_element: XN
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZN,
  append_hydration: QN,
  attr: eI,
  children: tI,
  claim_svg_element: nI,
  detach: rI,
  init: iI,
  insert_hydration: sI,
  noop: oI,
  safe_not_equal: lI,
  svg_element: aI
} = window.__gradio__svelte__internal, {
  SvelteComponent: cI,
  append_hydration: uI,
  attr: dI,
  children: fI,
  claim_svg_element: hI,
  detach: pI,
  init: mI,
  insert_hydration: gI,
  noop: _I,
  safe_not_equal: yI,
  svg_element: bI
} = window.__gradio__svelte__internal, {
  SvelteComponent: kI,
  append_hydration: wI,
  attr: vI,
  children: EI,
  claim_svg_element: DI,
  detach: SI,
  init: CI,
  insert_hydration: AI,
  noop: xI,
  safe_not_equal: TI,
  svg_element: MI
} = window.__gradio__svelte__internal, {
  SvelteComponent: FI,
  append_hydration: $I,
  attr: OI,
  children: NI,
  claim_svg_element: II,
  detach: RI,
  init: LI,
  insert_hydration: PI,
  noop: BI,
  safe_not_equal: zI,
  svg_element: HI
} = window.__gradio__svelte__internal, {
  SvelteComponent: qI,
  append_hydration: VI,
  attr: UI,
  children: jI,
  claim_svg_element: WI,
  detach: KI,
  init: GI,
  insert_hydration: JI,
  noop: YI,
  safe_not_equal: XI,
  svg_element: ZI
} = window.__gradio__svelte__internal, {
  SvelteComponent: QI,
  append_hydration: eR,
  attr: tR,
  children: nR,
  claim_svg_element: rR,
  claim_text: iR,
  detach: sR,
  init: oR,
  insert_hydration: lR,
  noop: aR,
  safe_not_equal: cR,
  svg_element: uR,
  text: dR
} = window.__gradio__svelte__internal, {
  SvelteComponent: fR,
  append_hydration: hR,
  attr: pR,
  children: mR,
  claim_svg_element: gR,
  detach: _R,
  init: yR,
  insert_hydration: bR,
  noop: kR,
  safe_not_equal: wR,
  svg_element: vR
} = window.__gradio__svelte__internal, {
  SvelteComponent: ER,
  append_hydration: DR,
  attr: SR,
  children: CR,
  claim_svg_element: AR,
  detach: xR,
  init: TR,
  insert_hydration: MR,
  noop: FR,
  safe_not_equal: $R,
  svg_element: OR
} = window.__gradio__svelte__internal, {
  SvelteComponent: NR,
  append_hydration: IR,
  attr: RR,
  children: LR,
  claim_svg_element: PR,
  detach: BR,
  init: zR,
  insert_hydration: HR,
  noop: qR,
  safe_not_equal: VR,
  svg_element: UR
} = window.__gradio__svelte__internal, {
  SvelteComponent: jR,
  append_hydration: WR,
  attr: KR,
  children: GR,
  claim_svg_element: JR,
  detach: YR,
  init: XR,
  insert_hydration: ZR,
  noop: QR,
  safe_not_equal: e3,
  svg_element: t3
} = window.__gradio__svelte__internal, {
  SvelteComponent: n3,
  append_hydration: r3,
  attr: i3,
  children: s3,
  claim_svg_element: o3,
  detach: l3,
  init: a3,
  insert_hydration: c3,
  noop: u3,
  safe_not_equal: d3,
  svg_element: f3
} = window.__gradio__svelte__internal, {
  SvelteComponent: h3,
  append_hydration: p3,
  attr: m3,
  children: g3,
  claim_svg_element: _3,
  detach: y3,
  init: b3,
  insert_hydration: k3,
  noop: w3,
  safe_not_equal: v3,
  svg_element: E3
} = window.__gradio__svelte__internal, {
  SvelteComponent: D3,
  append_hydration: S3,
  attr: C3,
  children: A3,
  claim_svg_element: x3,
  detach: T3,
  init: M3,
  insert_hydration: F3,
  noop: $3,
  safe_not_equal: O3,
  svg_element: N3
} = window.__gradio__svelte__internal, {
  SvelteComponent: I3,
  append_hydration: R3,
  attr: L3,
  children: P3,
  claim_svg_element: B3,
  claim_text: z3,
  detach: H3,
  init: q3,
  insert_hydration: V3,
  noop: U3,
  safe_not_equal: j3,
  svg_element: W3,
  text: K3
} = window.__gradio__svelte__internal, {
  SvelteComponent: G3,
  append_hydration: J3,
  attr: Y3,
  children: X3,
  claim_svg_element: Z3,
  claim_text: Q3,
  detach: eL,
  init: tL,
  insert_hydration: nL,
  noop: rL,
  safe_not_equal: iL,
  svg_element: sL,
  text: oL
} = window.__gradio__svelte__internal, {
  SvelteComponent: lL,
  append_hydration: aL,
  attr: cL,
  children: uL,
  claim_svg_element: dL,
  claim_text: fL,
  detach: hL,
  init: pL,
  insert_hydration: mL,
  noop: gL,
  safe_not_equal: _L,
  svg_element: yL,
  text: bL
} = window.__gradio__svelte__internal, {
  SvelteComponent: kL,
  append_hydration: wL,
  attr: vL,
  children: EL,
  claim_svg_element: DL,
  detach: SL,
  init: CL,
  insert_hydration: AL,
  noop: xL,
  safe_not_equal: TL,
  svg_element: ML
} = window.__gradio__svelte__internal, {
  SvelteComponent: FL,
  append_hydration: $L,
  attr: OL,
  children: NL,
  claim_svg_element: IL,
  detach: RL,
  init: LL,
  insert_hydration: PL,
  noop: BL,
  safe_not_equal: zL,
  svg_element: HL
} = window.__gradio__svelte__internal, {
  SvelteComponent: qL,
  append_hydration: VL,
  attr: UL,
  children: jL,
  claim_svg_element: WL,
  detach: KL,
  init: GL,
  insert_hydration: JL,
  noop: YL,
  safe_not_equal: XL,
  svg_element: ZL
} = window.__gradio__svelte__internal, {
  SvelteComponent: QL,
  append_hydration: eP,
  attr: tP,
  children: nP,
  claim_svg_element: rP,
  detach: iP,
  init: sP,
  insert_hydration: oP,
  noop: lP,
  safe_not_equal: aP,
  svg_element: cP
} = window.__gradio__svelte__internal, {
  SvelteComponent: uP,
  append_hydration: dP,
  attr: fP,
  children: hP,
  claim_svg_element: pP,
  detach: mP,
  init: gP,
  insert_hydration: _P,
  noop: yP,
  safe_not_equal: bP,
  svg_element: kP
} = window.__gradio__svelte__internal, {
  SvelteComponent: wP,
  append_hydration: vP,
  attr: EP,
  children: DP,
  claim_svg_element: SP,
  detach: CP,
  init: AP,
  insert_hydration: xP,
  noop: TP,
  safe_not_equal: MP,
  svg_element: FP
} = window.__gradio__svelte__internal, {
  SvelteComponent: $P,
  append_hydration: OP,
  attr: NP,
  children: IP,
  claim_svg_element: RP,
  detach: LP,
  init: PP,
  insert_hydration: BP,
  noop: zP,
  safe_not_equal: HP,
  svg_element: qP
} = window.__gradio__svelte__internal, {
  SvelteComponent: VP,
  append_hydration: UP,
  attr: jP,
  children: WP,
  claim_svg_element: KP,
  detach: GP,
  init: JP,
  insert_hydration: YP,
  noop: XP,
  safe_not_equal: ZP,
  svg_element: QP
} = window.__gradio__svelte__internal, ey = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Qc = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
ey.reduce(
  (n, { color: e, primary: t, secondary: r }) => ({
    ...n,
    [e]: {
      primary: Qc[e][t],
      secondary: Qc[e][r]
    }
  }),
  {}
);
const {
  SvelteComponent: e4,
  claim_component: t4,
  create_component: n4,
  destroy_component: r4,
  init: i4,
  mount_component: s4,
  safe_not_equal: o4,
  transition_in: l4,
  transition_out: a4
} = window.__gradio__svelte__internal, { createEventDispatcher: c4 } = window.__gradio__svelte__internal, {
  SvelteComponent: u4,
  append_hydration: d4,
  attr: f4,
  check_outros: h4,
  children: p4,
  claim_component: m4,
  claim_element: g4,
  claim_space: _4,
  claim_text: y4,
  create_component: b4,
  destroy_component: k4,
  detach: w4,
  element: v4,
  empty: E4,
  group_outros: D4,
  init: S4,
  insert_hydration: C4,
  mount_component: A4,
  safe_not_equal: x4,
  set_data: T4,
  space: M4,
  text: F4,
  toggle_class: $4,
  transition_in: O4,
  transition_out: N4
} = window.__gradio__svelte__internal, {
  SvelteComponent: I4,
  attr: R4,
  children: L4,
  claim_element: P4,
  create_slot: B4,
  detach: z4,
  element: H4,
  get_all_dirty_from_scope: q4,
  get_slot_changes: V4,
  init: U4,
  insert_hydration: j4,
  safe_not_equal: W4,
  toggle_class: K4,
  transition_in: G4,
  transition_out: J4,
  update_slot_base: Y4
} = window.__gradio__svelte__internal, {
  SvelteComponent: X4,
  append_hydration: Z4,
  attr: Q4,
  check_outros: e5,
  children: t5,
  claim_component: n5,
  claim_element: r5,
  claim_space: i5,
  create_component: s5,
  destroy_component: o5,
  detach: l5,
  element: a5,
  empty: c5,
  group_outros: u5,
  init: d5,
  insert_hydration: f5,
  listen: h5,
  mount_component: p5,
  safe_not_equal: m5,
  space: g5,
  toggle_class: _5,
  transition_in: y5,
  transition_out: b5
} = window.__gradio__svelte__internal, {
  SvelteComponent: k5,
  attr: w5,
  children: v5,
  claim_element: E5,
  create_slot: D5,
  detach: S5,
  element: C5,
  get_all_dirty_from_scope: A5,
  get_slot_changes: x5,
  init: T5,
  insert_hydration: M5,
  null_to_empty: F5,
  safe_not_equal: $5,
  transition_in: O5,
  transition_out: N5,
  update_slot_base: I5
} = window.__gradio__svelte__internal, {
  SvelteComponent: R5,
  check_outros: L5,
  claim_component: P5,
  create_component: B5,
  destroy_component: z5,
  detach: H5,
  empty: q5,
  group_outros: V5,
  init: U5,
  insert_hydration: j5,
  mount_component: W5,
  noop: K5,
  safe_not_equal: G5,
  transition_in: J5,
  transition_out: Y5
} = window.__gradio__svelte__internal, { createEventDispatcher: X5 } = window.__gradio__svelte__internal;
function dr(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let r = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + r;
}
function is() {
}
const Bf = typeof window < "u";
let eu = Bf ? () => window.performance.now() : () => Date.now(), zf = Bf ? (n) => requestAnimationFrame(n) : is;
const pr = /* @__PURE__ */ new Set();
function Hf(n) {
  pr.forEach((e) => {
    e.c(n) || (pr.delete(e), e.f());
  }), pr.size !== 0 && zf(Hf);
}
function ty(n) {
  let e;
  return pr.size === 0 && zf(Hf), { promise: new Promise((t) => {
    pr.add(e = { c: n, f: t });
  }), abort() {
    pr.delete(e);
  } };
}
const ir = [];
function ny(n, e = is) {
  let t;
  const r = /* @__PURE__ */ new Set();
  function i(o) {
    if (a = o, ((l = n) != l ? a == a : l !== a || l && typeof l == "object" || typeof l == "function") && (n = o, t)) {
      const c = !ir.length;
      for (const u of r) u[1](), ir.push(u, n);
      if (c) {
        for (let u = 0; u < ir.length; u += 2) ir[u][0](ir[u + 1]);
        ir.length = 0;
      }
    }
    var l, a;
  }
  function s(o) {
    i(o(n));
  }
  return { set: i, update: s, subscribe: function(o, l = is) {
    const a = [o, l];
    return r.add(a), r.size === 1 && (t = e(i, s) || is), o(n), () => {
      r.delete(a), r.size === 0 && t && (t(), t = null);
    };
  } };
}
function tu(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function Sl(n, e, t, r) {
  if (typeof t == "number" || tu(t)) {
    const i = r - t, s = (t - e) / (n.dt || 1 / 60), o = (s + (n.opts.stiffness * i - n.opts.damping * s) * n.inv_mass) * n.dt;
    return Math.abs(o) < n.opts.precision && Math.abs(i) < n.opts.precision ? r : (n.settled = !1, tu(t) ? new Date(t.getTime() + o) : t + o);
  }
  if (Array.isArray(t)) return t.map((i, s) => Sl(n, e[s], t[s], r[s]));
  if (typeof t == "object") {
    const i = {};
    for (const s in t) i[s] = Sl(n, e[s], t[s], r[s]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function nu(n, e = {}) {
  const t = ny(n), { stiffness: r = 0.15, damping: i = 0.8, precision: s = 0.01 } = e;
  let o, l, a, c = n, u = n, d = 1, f = 0, h = !1;
  function p(_, b = {}) {
    u = _;
    const y = a = {};
    return n == null || b.hard || m.stiffness >= 1 && m.damping >= 1 ? (h = !0, o = eu(), c = _, t.set(n = u), Promise.resolve()) : (b.soft && (f = 1 / (60 * (b.soft === !0 ? 0.5 : +b.soft)), d = 0), l || (o = eu(), h = !1, l = ty((g) => {
      if (h) return h = !1, l = null, !1;
      d = Math.min(d + f, 1);
      const w = { inv_mass: d, opts: m, settled: !0, dt: 60 * (g - o) / 1e3 }, E = Sl(w, c, n, u);
      return o = g, c = n, t.set(n = E), w.settled && (l = null), !w.settled;
    })), new Promise((g) => {
      l.promise.then(() => {
        y === a && g();
      });
    }));
  }
  const m = { set: p, update: (_, b) => p(_(u, n), b), subscribe: t.subscribe, stiffness: r, damping: i, precision: s };
  return m;
}
const {
  SvelteComponent: ry,
  append_hydration: mt,
  attr: W,
  children: tt,
  claim_element: iy,
  claim_svg_element: gt,
  component_subscribe: ru,
  detach: Ye,
  element: sy,
  init: oy,
  insert_hydration: ly,
  noop: iu,
  safe_not_equal: ay,
  set_style: Bi,
  svg_element: _t,
  toggle_class: su
} = window.__gradio__svelte__internal, { onMount: cy } = window.__gradio__svelte__internal;
function uy(n) {
  let e, t, r, i, s, o, l, a, c, u, d, f;
  return {
    c() {
      e = sy("div"), t = _t("svg"), r = _t("g"), i = _t("path"), s = _t("path"), o = _t("path"), l = _t("path"), a = _t("g"), c = _t("path"), u = _t("path"), d = _t("path"), f = _t("path"), this.h();
    },
    l(h) {
      e = iy(h, "DIV", { class: !0 });
      var p = tt(e);
      t = gt(p, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var m = tt(t);
      r = gt(m, "g", { style: !0 });
      var _ = tt(r);
      i = gt(_, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), tt(i).forEach(Ye), s = gt(_, "path", { d: !0, fill: !0, class: !0 }), tt(s).forEach(Ye), o = gt(_, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), tt(o).forEach(Ye), l = gt(_, "path", { d: !0, fill: !0, class: !0 }), tt(l).forEach(Ye), _.forEach(Ye), a = gt(m, "g", { style: !0 });
      var b = tt(a);
      c = gt(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), tt(c).forEach(Ye), u = gt(b, "path", { d: !0, fill: !0, class: !0 }), tt(u).forEach(Ye), d = gt(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), tt(d).forEach(Ye), f = gt(b, "path", { d: !0, fill: !0, class: !0 }), tt(f).forEach(Ye), b.forEach(Ye), m.forEach(Ye), p.forEach(Ye), this.h();
    },
    h() {
      W(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), W(i, "fill", "#FF7C00"), W(i, "fill-opacity", "0.4"), W(i, "class", "svelte-43sxxs"), W(s, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), W(s, "fill", "#FF7C00"), W(s, "class", "svelte-43sxxs"), W(o, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), W(o, "fill", "#FF7C00"), W(o, "fill-opacity", "0.4"), W(o, "class", "svelte-43sxxs"), W(l, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), W(l, "fill", "#FF7C00"), W(l, "class", "svelte-43sxxs"), Bi(r, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), W(c, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), W(c, "fill", "#FF7C00"), W(c, "fill-opacity", "0.4"), W(c, "class", "svelte-43sxxs"), W(u, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), W(u, "fill", "#FF7C00"), W(u, "class", "svelte-43sxxs"), W(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), W(d, "fill", "#FF7C00"), W(d, "fill-opacity", "0.4"), W(d, "class", "svelte-43sxxs"), W(f, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), W(f, "fill", "#FF7C00"), W(f, "class", "svelte-43sxxs"), Bi(a, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), W(t, "viewBox", "-1200 -1200 3000 3000"), W(t, "fill", "none"), W(t, "xmlns", "http://www.w3.org/2000/svg"), W(t, "class", "svelte-43sxxs"), W(e, "class", "svelte-43sxxs"), su(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(h, p) {
      ly(h, e, p), mt(e, t), mt(t, r), mt(r, i), mt(r, s), mt(r, o), mt(r, l), mt(t, a), mt(a, c), mt(a, u), mt(a, d), mt(a, f);
    },
    p(h, [p]) {
      p & /*$top*/
      2 && Bi(r, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), p & /*$bottom*/
      4 && Bi(a, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), p & /*margin*/
      1 && su(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: iu,
    o: iu,
    d(h) {
      h && Ye(e);
    }
  };
}
function dy(n, e, t) {
  let r, i;
  var s = this && this.__awaiter || function(h, p, m, _) {
    function b(y) {
      return y instanceof m ? y : new m(function(g) {
        g(y);
      });
    }
    return new (m || (m = Promise))(function(y, g) {
      function w(D) {
        try {
          v(_.next(D));
        } catch (S) {
          g(S);
        }
      }
      function E(D) {
        try {
          v(_.throw(D));
        } catch (S) {
          g(S);
        }
      }
      function v(D) {
        D.done ? y(D.value) : b(D.value).then(w, E);
      }
      v((_ = _.apply(h, p || [])).next());
    });
  };
  let { margin: o = !0 } = e;
  const l = nu([0, 0]);
  ru(n, l, (h) => t(1, r = h));
  const a = nu([0, 0]);
  ru(n, a, (h) => t(2, i = h));
  let c;
  function u() {
    return s(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 140]), a.set([-125, -140])]), yield Promise.all([l.set([-125, 140]), a.set([125, -140])]), yield Promise.all([l.set([-125, 0]), a.set([125, -0])]), yield Promise.all([l.set([125, 0]), a.set([-125, 0])]);
    });
  }
  function d() {
    return s(this, void 0, void 0, function* () {
      yield u(), c || d();
    });
  }
  function f() {
    return s(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 0]), a.set([-125, 0])]), d();
    });
  }
  return cy(() => (f(), () => c = !0)), n.$$set = (h) => {
    "margin" in h && t(0, o = h.margin);
  }, [o, r, i, l, a];
}
class fy extends ry {
  constructor(e) {
    super(), oy(this, e, dy, uy, ay, { margin: 0 });
  }
}
const {
  SvelteComponent: hy,
  append_hydration: xn,
  attr: wt,
  binding_callbacks: ou,
  check_outros: Cl,
  children: Nt,
  claim_component: qf,
  claim_element: It,
  claim_space: at,
  claim_text: oe,
  create_component: Vf,
  create_slot: Uf,
  destroy_component: jf,
  destroy_each: Wf,
  detach: P,
  element: Rt,
  empty: dt,
  ensure_array_like: ms,
  get_all_dirty_from_scope: Kf,
  get_slot_changes: Gf,
  group_outros: Al,
  init: py,
  insert_hydration: q,
  mount_component: Jf,
  noop: xl,
  safe_not_equal: my,
  set_data: ft,
  set_style: fn,
  space: ct,
  text: le,
  toggle_class: st,
  transition_in: bt,
  transition_out: Lt,
  update_slot_base: Yf
} = window.__gradio__svelte__internal, { tick: gy } = window.__gradio__svelte__internal, { onDestroy: _y } = window.__gradio__svelte__internal, { createEventDispatcher: yy } = window.__gradio__svelte__internal, by = (n) => ({}), lu = (n) => ({}), ky = (n) => ({}), au = (n) => ({});
function cu(n, e, t) {
  const r = n.slice();
  return r[40] = e[t], r[42] = t, r;
}
function uu(n, e, t) {
  const r = n.slice();
  return r[40] = e[t], r;
}
function wy(n) {
  let e, t, r, i, s = (
    /*i18n*/
    n[1]("common.error") + ""
  ), o, l, a;
  t = new K_({
    props: {
      Icon: Q_,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const c = (
    /*#slots*/
    n[30].error
  ), u = Uf(
    c,
    n,
    /*$$scope*/
    n[29],
    lu
  );
  return {
    c() {
      e = Rt("div"), Vf(t.$$.fragment), r = ct(), i = Rt("span"), o = le(s), l = ct(), u && u.c(), this.h();
    },
    l(d) {
      e = It(d, "DIV", { class: !0 });
      var f = Nt(e);
      qf(t.$$.fragment, f), f.forEach(P), r = at(d), i = It(d, "SPAN", { class: !0 });
      var h = Nt(i);
      o = oe(h, s), h.forEach(P), l = at(d), u && u.l(d), this.h();
    },
    h() {
      wt(e, "class", "clear-status svelte-17v219f"), wt(i, "class", "error svelte-17v219f");
    },
    m(d, f) {
      q(d, e, f), Jf(t, e, null), q(d, r, f), q(d, i, f), xn(i, o), q(d, l, f), u && u.m(d, f), a = !0;
    },
    p(d, f) {
      const h = {};
      f[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      d[1]("common.clear")), t.$set(h), (!a || f[0] & /*i18n*/
      2) && s !== (s = /*i18n*/
      d[1]("common.error") + "") && ft(o, s), u && u.p && (!a || f[0] & /*$$scope*/
      536870912) && Yf(
        u,
        c,
        d,
        /*$$scope*/
        d[29],
        a ? Gf(
          c,
          /*$$scope*/
          d[29],
          f,
          by
        ) : Kf(
          /*$$scope*/
          d[29]
        ),
        lu
      );
    },
    i(d) {
      a || (bt(t.$$.fragment, d), bt(u, d), a = !0);
    },
    o(d) {
      Lt(t.$$.fragment, d), Lt(u, d), a = !1;
    },
    d(d) {
      d && (P(e), P(r), P(i), P(l)), jf(t), u && u.d(d);
    }
  };
}
function vy(n) {
  let e, t, r, i, s, o, l, a, c, u = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && du(n)
  );
  function d(g, w) {
    if (
      /*progress*/
      g[7]
    ) return Sy;
    if (
      /*queue_position*/
      g[2] !== null && /*queue_size*/
      g[3] !== void 0 && /*queue_position*/
      g[2] >= 0
    ) return Dy;
    if (
      /*queue_position*/
      g[2] === 0
    ) return Ey;
  }
  let f = d(n), h = f && f(n), p = (
    /*timer*/
    n[5] && pu(n)
  );
  const m = [Ty, xy], _ = [];
  function b(g, w) {
    return (
      /*last_progress_level*/
      g[15] != null ? 0 : (
        /*show_progress*/
        g[6] === "full" ? 1 : -1
      )
    );
  }
  ~(s = b(n)) && (o = _[s] = m[s](n));
  let y = !/*timer*/
  n[5] && wu(n);
  return {
    c() {
      u && u.c(), e = ct(), t = Rt("div"), h && h.c(), r = ct(), p && p.c(), i = ct(), o && o.c(), l = ct(), y && y.c(), a = dt(), this.h();
    },
    l(g) {
      u && u.l(g), e = at(g), t = It(g, "DIV", { class: !0 });
      var w = Nt(t);
      h && h.l(w), r = at(w), p && p.l(w), w.forEach(P), i = at(g), o && o.l(g), l = at(g), y && y.l(g), a = dt(), this.h();
    },
    h() {
      wt(t, "class", "progress-text svelte-17v219f"), st(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), st(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(g, w) {
      u && u.m(g, w), q(g, e, w), q(g, t, w), h && h.m(t, null), xn(t, r), p && p.m(t, null), q(g, i, w), ~s && _[s].m(g, w), q(g, l, w), y && y.m(g, w), q(g, a, w), c = !0;
    },
    p(g, w) {
      /*variant*/
      g[8] === "default" && /*show_eta_bar*/
      g[18] && /*show_progress*/
      g[6] === "full" ? u ? u.p(g, w) : (u = du(g), u.c(), u.m(e.parentNode, e)) : u && (u.d(1), u = null), f === (f = d(g)) && h ? h.p(g, w) : (h && h.d(1), h = f && f(g), h && (h.c(), h.m(t, r))), /*timer*/
      g[5] ? p ? p.p(g, w) : (p = pu(g), p.c(), p.m(t, null)) : p && (p.d(1), p = null), (!c || w[0] & /*variant*/
      256) && st(
        t,
        "meta-text-center",
        /*variant*/
        g[8] === "center"
      ), (!c || w[0] & /*variant*/
      256) && st(
        t,
        "meta-text",
        /*variant*/
        g[8] === "default"
      );
      let E = s;
      s = b(g), s === E ? ~s && _[s].p(g, w) : (o && (Al(), Lt(_[E], 1, 1, () => {
        _[E] = null;
      }), Cl()), ~s ? (o = _[s], o ? o.p(g, w) : (o = _[s] = m[s](g), o.c()), bt(o, 1), o.m(l.parentNode, l)) : o = null), /*timer*/
      g[5] ? y && (Al(), Lt(y, 1, 1, () => {
        y = null;
      }), Cl()) : y ? (y.p(g, w), w[0] & /*timer*/
      32 && bt(y, 1)) : (y = wu(g), y.c(), bt(y, 1), y.m(a.parentNode, a));
    },
    i(g) {
      c || (bt(o), bt(y), c = !0);
    },
    o(g) {
      Lt(o), Lt(y), c = !1;
    },
    d(g) {
      g && (P(e), P(t), P(i), P(l), P(a)), u && u.d(g), h && h.d(), p && p.d(), ~s && _[s].d(g), y && y.d(g);
    }
  };
}
function du(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Rt("div"), this.h();
    },
    l(r) {
      e = It(r, "DIV", { class: !0 }), Nt(e).forEach(P), this.h();
    },
    h() {
      wt(e, "class", "eta-bar svelte-17v219f"), fn(e, "transform", t);
    },
    m(r, i) {
      q(r, e, i);
    },
    p(r, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && fn(e, "transform", t);
    },
    d(r) {
      r && P(e);
    }
  };
}
function Ey(n) {
  let e;
  return {
    c() {
      e = le("processing |");
    },
    l(t) {
      e = oe(t, "processing |");
    },
    m(t, r) {
      q(t, e, r);
    },
    p: xl,
    d(t) {
      t && P(e);
    }
  };
}
function Dy(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), r, i, s, o;
  return {
    c() {
      e = le("queue: "), r = le(t), i = le("/"), s = le(
        /*queue_size*/
        n[3]
      ), o = le(" |");
    },
    l(l) {
      e = oe(l, "queue: "), r = oe(l, t), i = oe(l, "/"), s = oe(
        l,
        /*queue_size*/
        n[3]
      ), o = oe(l, " |");
    },
    m(l, a) {
      q(l, e, a), q(l, r, a), q(l, i, a), q(l, s, a), q(l, o, a);
    },
    p(l, a) {
      a[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      l[2] + 1 + "") && ft(r, t), a[0] & /*queue_size*/
      8 && ft(
        s,
        /*queue_size*/
        l[3]
      );
    },
    d(l) {
      l && (P(e), P(r), P(i), P(s), P(o));
    }
  };
}
function Sy(n) {
  let e, t = ms(
    /*progress*/
    n[7]
  ), r = [];
  for (let i = 0; i < t.length; i += 1)
    r[i] = hu(uu(n, t, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      e = dt();
    },
    l(i) {
      for (let s = 0; s < r.length; s += 1)
        r[s].l(i);
      e = dt();
    },
    m(i, s) {
      for (let o = 0; o < r.length; o += 1)
        r[o] && r[o].m(i, s);
      q(i, e, s);
    },
    p(i, s) {
      if (s[0] & /*progress*/
      128) {
        t = ms(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const l = uu(i, t, o);
          r[o] ? r[o].p(l, s) : (r[o] = hu(l), r[o].c(), r[o].m(e.parentNode, e));
        }
        for (; o < r.length; o += 1)
          r[o].d(1);
        r.length = t.length;
      }
    },
    d(i) {
      i && P(e), Wf(r, i);
    }
  };
}
function fu(n) {
  let e, t = (
    /*p*/
    n[40].unit + ""
  ), r, i, s = " ", o;
  function l(u, d) {
    return (
      /*p*/
      u[40].length != null ? Ay : Cy
    );
  }
  let a = l(n), c = a(n);
  return {
    c() {
      c.c(), e = ct(), r = le(t), i = le(" | "), o = le(s);
    },
    l(u) {
      c.l(u), e = at(u), r = oe(u, t), i = oe(u, " | "), o = oe(u, s);
    },
    m(u, d) {
      c.m(u, d), q(u, e, d), q(u, r, d), q(u, i, d), q(u, o, d);
    },
    p(u, d) {
      a === (a = l(u)) && c ? c.p(u, d) : (c.d(1), c = a(u), c && (c.c(), c.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      u[40].unit + "") && ft(r, t);
    },
    d(u) {
      u && (P(e), P(r), P(i), P(o)), c.d(u);
    }
  };
}
function Cy(n) {
  let e = dr(
    /*p*/
    n[40].index || 0
  ) + "", t;
  return {
    c() {
      t = le(e);
    },
    l(r) {
      t = oe(r, e);
    },
    m(r, i) {
      q(r, t, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && e !== (e = dr(
        /*p*/
        r[40].index || 0
      ) + "") && ft(t, e);
    },
    d(r) {
      r && P(t);
    }
  };
}
function Ay(n) {
  let e = dr(
    /*p*/
    n[40].index || 0
  ) + "", t, r, i = dr(
    /*p*/
    n[40].length
  ) + "", s;
  return {
    c() {
      t = le(e), r = le("/"), s = le(i);
    },
    l(o) {
      t = oe(o, e), r = oe(o, "/"), s = oe(o, i);
    },
    m(o, l) {
      q(o, t, l), q(o, r, l), q(o, s, l);
    },
    p(o, l) {
      l[0] & /*progress*/
      128 && e !== (e = dr(
        /*p*/
        o[40].index || 0
      ) + "") && ft(t, e), l[0] & /*progress*/
      128 && i !== (i = dr(
        /*p*/
        o[40].length
      ) + "") && ft(s, i);
    },
    d(o) {
      o && (P(t), P(r), P(s));
    }
  };
}
function hu(n) {
  let e, t = (
    /*p*/
    n[40].index != null && fu(n)
  );
  return {
    c() {
      t && t.c(), e = dt();
    },
    l(r) {
      t && t.l(r), e = dt();
    },
    m(r, i) {
      t && t.m(r, i), q(r, e, i);
    },
    p(r, i) {
      /*p*/
      r[40].index != null ? t ? t.p(r, i) : (t = fu(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && P(e), t && t.d(r);
    }
  };
}
function pu(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), r, i;
  return {
    c() {
      e = le(
        /*formatted_timer*/
        n[20]
      ), r = le(t), i = le("s");
    },
    l(s) {
      e = oe(
        s,
        /*formatted_timer*/
        n[20]
      ), r = oe(s, t), i = oe(s, "s");
    },
    m(s, o) {
      q(s, e, o), q(s, r, o), q(s, i, o);
    },
    p(s, o) {
      o[0] & /*formatted_timer*/
      1048576 && ft(
        e,
        /*formatted_timer*/
        s[20]
      ), o[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      s[0] ? `/${/*formatted_eta*/
      s[19]}` : "") && ft(r, t);
    },
    d(s) {
      s && (P(e), P(r), P(i));
    }
  };
}
function xy(n) {
  let e, t;
  return e = new fy({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      Vf(e.$$.fragment);
    },
    l(r) {
      qf(e.$$.fragment, r);
    },
    m(r, i) {
      Jf(e, r, i), t = !0;
    },
    p(r, i) {
      const s = {};
      i[0] & /*variant*/
      256 && (s.margin = /*variant*/
      r[8] === "default"), e.$set(s);
    },
    i(r) {
      t || (bt(e.$$.fragment, r), t = !0);
    },
    o(r) {
      Lt(e.$$.fragment, r), t = !1;
    },
    d(r) {
      jf(e, r);
    }
  };
}
function Ty(n) {
  let e, t, r, i, s, o = `${/*last_progress_level*/
  n[15] * 100}%`, l = (
    /*progress*/
    n[7] != null && mu(n)
  );
  return {
    c() {
      e = Rt("div"), t = Rt("div"), l && l.c(), r = ct(), i = Rt("div"), s = Rt("div"), this.h();
    },
    l(a) {
      e = It(a, "DIV", { class: !0 });
      var c = Nt(e);
      t = It(c, "DIV", { class: !0 });
      var u = Nt(t);
      l && l.l(u), u.forEach(P), r = at(c), i = It(c, "DIV", { class: !0 });
      var d = Nt(i);
      s = It(d, "DIV", { class: !0 }), Nt(s).forEach(P), d.forEach(P), c.forEach(P), this.h();
    },
    h() {
      wt(t, "class", "progress-level-inner svelte-17v219f"), wt(s, "class", "progress-bar svelte-17v219f"), fn(s, "width", o), wt(i, "class", "progress-bar-wrap svelte-17v219f"), wt(e, "class", "progress-level svelte-17v219f");
    },
    m(a, c) {
      q(a, e, c), xn(e, t), l && l.m(t, null), xn(e, r), xn(e, i), xn(i, s), n[31](s);
    },
    p(a, c) {
      /*progress*/
      a[7] != null ? l ? l.p(a, c) : (l = mu(a), l.c(), l.m(t, null)) : l && (l.d(1), l = null), c[0] & /*last_progress_level*/
      32768 && o !== (o = `${/*last_progress_level*/
      a[15] * 100}%`) && fn(s, "width", o);
    },
    i: xl,
    o: xl,
    d(a) {
      a && P(e), l && l.d(), n[31](null);
    }
  };
}
function mu(n) {
  let e, t = ms(
    /*progress*/
    n[7]
  ), r = [];
  for (let i = 0; i < t.length; i += 1)
    r[i] = ku(cu(n, t, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      e = dt();
    },
    l(i) {
      for (let s = 0; s < r.length; s += 1)
        r[s].l(i);
      e = dt();
    },
    m(i, s) {
      for (let o = 0; o < r.length; o += 1)
        r[o] && r[o].m(i, s);
      q(i, e, s);
    },
    p(i, s) {
      if (s[0] & /*progress_level, progress*/
      16512) {
        t = ms(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const l = cu(i, t, o);
          r[o] ? r[o].p(l, s) : (r[o] = ku(l), r[o].c(), r[o].m(e.parentNode, e));
        }
        for (; o < r.length; o += 1)
          r[o].d(1);
        r.length = t.length;
      }
    },
    d(i) {
      i && P(e), Wf(r, i);
    }
  };
}
function gu(n) {
  let e, t, r, i, s = (
    /*i*/
    n[42] !== 0 && My()
  ), o = (
    /*p*/
    n[40].desc != null && _u(n)
  ), l = (
    /*p*/
    n[40].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null && yu()
  ), a = (
    /*progress_level*/
    n[14] != null && bu(n)
  );
  return {
    c() {
      s && s.c(), e = ct(), o && o.c(), t = ct(), l && l.c(), r = ct(), a && a.c(), i = dt();
    },
    l(c) {
      s && s.l(c), e = at(c), o && o.l(c), t = at(c), l && l.l(c), r = at(c), a && a.l(c), i = dt();
    },
    m(c, u) {
      s && s.m(c, u), q(c, e, u), o && o.m(c, u), q(c, t, u), l && l.m(c, u), q(c, r, u), a && a.m(c, u), q(c, i, u);
    },
    p(c, u) {
      /*p*/
      c[40].desc != null ? o ? o.p(c, u) : (o = _u(c), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null), /*p*/
      c[40].desc != null && /*progress_level*/
      c[14] && /*progress_level*/
      c[14][
        /*i*/
        c[42]
      ] != null ? l || (l = yu(), l.c(), l.m(r.parentNode, r)) : l && (l.d(1), l = null), /*progress_level*/
      c[14] != null ? a ? a.p(c, u) : (a = bu(c), a.c(), a.m(i.parentNode, i)) : a && (a.d(1), a = null);
    },
    d(c) {
      c && (P(e), P(t), P(r), P(i)), s && s.d(c), o && o.d(c), l && l.d(c), a && a.d(c);
    }
  };
}
function My(n) {
  let e;
  return {
    c() {
      e = le(" /");
    },
    l(t) {
      e = oe(t, " /");
    },
    m(t, r) {
      q(t, e, r);
    },
    d(t) {
      t && P(e);
    }
  };
}
function _u(n) {
  let e = (
    /*p*/
    n[40].desc + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    l(r) {
      t = oe(r, e);
    },
    m(r, i) {
      q(r, t, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      r[40].desc + "") && ft(t, e);
    },
    d(r) {
      r && P(t);
    }
  };
}
function yu(n) {
  let e;
  return {
    c() {
      e = le("-");
    },
    l(t) {
      e = oe(t, "-");
    },
    m(t, r) {
      q(t, e, r);
    },
    d(t) {
      t && P(e);
    }
  };
}
function bu(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[42]
  ] || 0)).toFixed(1) + "", t, r;
  return {
    c() {
      t = le(e), r = le("%");
    },
    l(i) {
      t = oe(i, e), r = oe(i, "%");
    },
    m(i, s) {
      q(i, t, s), q(i, r, s);
    },
    p(i, s) {
      s[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && ft(t, e);
    },
    d(i) {
      i && (P(t), P(r));
    }
  };
}
function ku(n) {
  let e, t = (
    /*p*/
    (n[40].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null) && gu(n)
  );
  return {
    c() {
      t && t.c(), e = dt();
    },
    l(r) {
      t && t.l(r), e = dt();
    },
    m(r, i) {
      t && t.m(r, i), q(r, e, i);
    },
    p(r, i) {
      /*p*/
      r[40].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[42]
      ] != null ? t ? t.p(r, i) : (t = gu(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && P(e), t && t.d(r);
    }
  };
}
function wu(n) {
  let e, t, r, i;
  const s = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), o = Uf(
    s,
    n,
    /*$$scope*/
    n[29],
    au
  );
  return {
    c() {
      e = Rt("p"), t = le(
        /*loading_text*/
        n[9]
      ), r = ct(), o && o.c(), this.h();
    },
    l(l) {
      e = It(l, "P", { class: !0 });
      var a = Nt(e);
      t = oe(
        a,
        /*loading_text*/
        n[9]
      ), a.forEach(P), r = at(l), o && o.l(l), this.h();
    },
    h() {
      wt(e, "class", "loading svelte-17v219f");
    },
    m(l, a) {
      q(l, e, a), xn(e, t), q(l, r, a), o && o.m(l, a), i = !0;
    },
    p(l, a) {
      (!i || a[0] & /*loading_text*/
      512) && ft(
        t,
        /*loading_text*/
        l[9]
      ), o && o.p && (!i || a[0] & /*$$scope*/
      536870912) && Yf(
        o,
        s,
        l,
        /*$$scope*/
        l[29],
        i ? Gf(
          s,
          /*$$scope*/
          l[29],
          a,
          ky
        ) : Kf(
          /*$$scope*/
          l[29]
        ),
        au
      );
    },
    i(l) {
      i || (bt(o, l), i = !0);
    },
    o(l) {
      Lt(o, l), i = !1;
    },
    d(l) {
      l && (P(e), P(r)), o && o.d(l);
    }
  };
}
function Fy(n) {
  let e, t, r, i, s;
  const o = [vy, wy], l = [];
  function a(c, u) {
    return (
      /*status*/
      c[4] === "pending" ? 0 : (
        /*status*/
        c[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = a(n)) && (r = l[t] = o[t](n)), {
    c() {
      e = Rt("div"), r && r.c(), this.h();
    },
    l(c) {
      e = It(c, "DIV", { class: !0 });
      var u = Nt(e);
      r && r.l(u), u.forEach(P), this.h();
    },
    h() {
      wt(e, "class", i = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), st(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), st(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), st(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), st(
        e,
        "border",
        /*border*/
        n[12]
      ), fn(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), fn(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(c, u) {
      q(c, e, u), ~t && l[t].m(e, null), n[33](e), s = !0;
    },
    p(c, u) {
      let d = t;
      t = a(c), t === d ? ~t && l[t].p(c, u) : (r && (Al(), Lt(l[d], 1, 1, () => {
        l[d] = null;
      }), Cl()), ~t ? (r = l[t], r ? r.p(c, u) : (r = l[t] = o[t](c), r.c()), bt(r, 1), r.m(e, null)) : r = null), (!s || u[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      c[8] + " " + /*show_progress*/
      c[6] + " svelte-17v219f")) && wt(e, "class", i), (!s || u[0] & /*variant, show_progress, status, show_progress*/
      336) && st(e, "hide", !/*status*/
      c[4] || /*status*/
      c[4] === "complete" || /*show_progress*/
      c[6] === "hidden" || /*status*/
      c[4] == "streaming"), (!s || u[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && st(
        e,
        "translucent",
        /*variant*/
        c[8] === "center" && /*status*/
        (c[4] === "pending" || /*status*/
        c[4] === "error") || /*translucent*/
        c[11] || /*show_progress*/
        c[6] === "minimal"
      ), (!s || u[0] & /*variant, show_progress, status, show_progress*/
      336) && st(
        e,
        "generating",
        /*status*/
        c[4] === "generating" && /*show_progress*/
        c[6] === "full"
      ), (!s || u[0] & /*variant, show_progress, border*/
      4416) && st(
        e,
        "border",
        /*border*/
        c[12]
      ), u[0] & /*absolute*/
      1024 && fn(
        e,
        "position",
        /*absolute*/
        c[10] ? "absolute" : "static"
      ), u[0] & /*absolute*/
      1024 && fn(
        e,
        "padding",
        /*absolute*/
        c[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(c) {
      s || (bt(r), s = !0);
    },
    o(c) {
      Lt(r), s = !1;
    },
    d(c) {
      c && P(e), ~t && l[t].d(), n[33](null);
    }
  };
}
var $y = function(n, e, t, r) {
  function i(s) {
    return s instanceof t ? s : new t(function(o) {
      o(s);
    });
  }
  return new (t || (t = Promise))(function(s, o) {
    function l(u) {
      try {
        c(r.next(u));
      } catch (d) {
        o(d);
      }
    }
    function a(u) {
      try {
        c(r.throw(u));
      } catch (d) {
        o(d);
      }
    }
    function c(u) {
      u.done ? s(u.value) : i(u.value).then(l, a);
    }
    c((r = r.apply(n, e || [])).next());
  });
};
let zi = [], zo = !1;
const Oy = typeof window < "u", Xf = Oy ? window.requestAnimationFrame : (n) => {
};
function Ny(n) {
  return $y(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (zi.push(e), !zo) zo = !0;
      else return;
      yield gy(), Xf(() => {
        let r = [0, 0];
        for (let i = 0; i < zi.length; i++) {
          const o = zi[i].getBoundingClientRect();
          (i === 0 || o.top + window.scrollY <= r[0]) && (r[0] = o.top + window.scrollY, r[1] = i);
        }
        window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), zo = !1, zi = [];
      });
    }
  });
}
function Iy(n, e, t) {
  let r, { $$slots: i = {}, $$scope: s } = e;
  const o = yy();
  let { i18n: l } = e, { eta: a = null } = e, { queue_position: c } = e, { queue_size: u } = e, { status: d } = e, { scroll_to_output: f = !1 } = e, { timer: h = !0 } = e, { show_progress: p = "full" } = e, { message: m = null } = e, { progress: _ = null } = e, { variant: b = "default" } = e, { loading_text: y = "Loading..." } = e, { absolute: g = !0 } = e, { translucent: w = !1 } = e, { border: E = !1 } = e, { autoscroll: v } = e, D, S = !1, C = 0, F = 0, N = null, H = null, ke = 0, Q = null, ce, K = null, pe = !0;
  const ie = () => {
    t(0, a = t(27, N = t(19, M = null))), t(25, C = performance.now()), t(26, F = 0), S = !0, Ce();
  };
  function Ce() {
    Xf(() => {
      t(26, F = (performance.now() - C) / 1e3), S && Ce();
    });
  }
  function je() {
    t(26, F = 0), t(0, a = t(27, N = t(19, M = null))), S && (S = !1);
  }
  _y(() => {
    S && je();
  });
  let M = null;
  function ye($) {
    ou[$ ? "unshift" : "push"](() => {
      K = $, t(16, K), t(7, _), t(14, Q), t(15, ce);
    });
  }
  const ne = () => {
    o("clear_status");
  };
  function Me($) {
    ou[$ ? "unshift" : "push"](() => {
      D = $, t(13, D);
    });
  }
  return n.$$set = ($) => {
    "i18n" in $ && t(1, l = $.i18n), "eta" in $ && t(0, a = $.eta), "queue_position" in $ && t(2, c = $.queue_position), "queue_size" in $ && t(3, u = $.queue_size), "status" in $ && t(4, d = $.status), "scroll_to_output" in $ && t(22, f = $.scroll_to_output), "timer" in $ && t(5, h = $.timer), "show_progress" in $ && t(6, p = $.show_progress), "message" in $ && t(23, m = $.message), "progress" in $ && t(7, _ = $.progress), "variant" in $ && t(8, b = $.variant), "loading_text" in $ && t(9, y = $.loading_text), "absolute" in $ && t(10, g = $.absolute), "translucent" in $ && t(11, w = $.translucent), "border" in $ && t(12, E = $.border), "autoscroll" in $ && t(24, v = $.autoscroll), "$$scope" in $ && t(29, s = $.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (a === null && t(0, a = N), a != null && N !== a && (t(28, H = (performance.now() - C) / 1e3 + a), t(19, M = H.toFixed(1)), t(27, N = a))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ke = H === null || H <= 0 || !F ? null : Math.min(F / H, 1)), n.$$.dirty[0] & /*progress*/
    128 && _ != null && t(18, pe = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (_ != null ? t(14, Q = _.map(($) => {
      if ($.index != null && $.length != null)
        return $.index / $.length;
      if ($.progress != null)
        return $.progress;
    })) : t(14, Q = null), Q ? (t(15, ce = Q[Q.length - 1]), K && (ce === 0 ? t(16, K.style.transition = "0", K) : t(16, K.style.transition = "150ms", K))) : t(15, ce = void 0)), n.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? ie() : je()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && D && f && (d === "pending" || d === "complete") && Ny(D, v), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, r = F.toFixed(1));
  }, [
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    _,
    b,
    y,
    g,
    w,
    E,
    D,
    Q,
    ce,
    K,
    ke,
    pe,
    M,
    r,
    o,
    f,
    m,
    v,
    C,
    F,
    N,
    H,
    s,
    i,
    ye,
    ne,
    Me
  ];
}
class Ry extends hy {
  constructor(e) {
    super(), py(
      this,
      e,
      Iy,
      Fy,
      my,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Zf,
  setPrototypeOf: vu,
  isFrozen: Ly,
  getPrototypeOf: Py,
  getOwnPropertyDescriptor: By
} = Object;
let {
  freeze: ze,
  seal: ht,
  create: Qf
} = Object, {
  apply: Tl,
  construct: Ml
} = typeof Reflect < "u" && Reflect;
ze || (ze = function(e) {
  return e;
});
ht || (ht = function(e) {
  return e;
});
Tl || (Tl = function(e, t, r) {
  return e.apply(t, r);
});
Ml || (Ml = function(e, t) {
  return new e(...t);
});
const Hi = He(Array.prototype.forEach), zy = He(Array.prototype.lastIndexOf), Eu = He(Array.prototype.pop), Tr = He(Array.prototype.push), Hy = He(Array.prototype.splice), ss = He(String.prototype.toLowerCase), Ho = He(String.prototype.toString), Du = He(String.prototype.match), Mr = He(String.prototype.replace), qy = He(String.prototype.indexOf), Vy = He(String.prototype.trim), yt = He(Object.prototype.hasOwnProperty), Pe = He(RegExp.prototype.test), Fr = Uy(TypeError);
function He(n) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
      r[i - 1] = arguments[i];
    return Tl(n, e, r);
  };
}
function Uy(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    return Ml(n, t);
  };
}
function j(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : ss;
  vu && vu(n, null);
  let r = e.length;
  for (; r--; ) {
    let i = e[r];
    if (typeof i == "string") {
      const s = t(i);
      s !== i && (Ly(e) || (e[r] = s), i = s);
    }
    n[i] = !0;
  }
  return n;
}
function jy(n) {
  for (let e = 0; e < n.length; e++)
    yt(n, e) || (n[e] = null);
  return n;
}
function Kt(n) {
  const e = Qf(null);
  for (const [t, r] of Zf(n))
    yt(n, t) && (Array.isArray(r) ? e[t] = jy(r) : r && typeof r == "object" && r.constructor === Object ? e[t] = Kt(r) : e[t] = r);
  return e;
}
function $r(n, e) {
  for (; n !== null; ) {
    const r = By(n, e);
    if (r) {
      if (r.get)
        return He(r.get);
      if (typeof r.value == "function")
        return He(r.value);
    }
    n = Py(n);
  }
  function t() {
    return null;
  }
  return t;
}
const Su = ze(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), qo = ze(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Vo = ze(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Wy = ze(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Uo = ze(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Ky = ze(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Cu = ze(["#text"]), Au = ze(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), jo = ze(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), xu = ze(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), qi = ze(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Gy = ht(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Jy = ht(/<%[\w\W]*|[\w\W]*%>/gm), Yy = ht(/\$\{[\w\W]*/gm), Xy = ht(/^data-[\-\w.\u00B7-\uFFFF]+$/), Zy = ht(/^aria-[\-\w]+$/), eh = ht(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Qy = ht(/^(?:\w+script|data):/i), e1 = ht(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), th = ht(/^html$/i), t1 = ht(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Tu = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Zy,
  ATTR_WHITESPACE: e1,
  CUSTOM_ELEMENT: t1,
  DATA_ATTR: Xy,
  DOCTYPE_NAME: th,
  ERB_EXPR: Jy,
  IS_ALLOWED_URI: eh,
  IS_SCRIPT_OR_DATA: Qy,
  MUSTACHE_EXPR: Gy,
  TMPLIT_EXPR: Yy
});
const Or = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, n1 = function() {
  return typeof window > "u" ? null : window;
}, r1 = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let r = null;
  const i = "data-tt-policy-suffix";
  t && t.hasAttribute(i) && (r = t.getAttribute(i));
  const s = "dompurify" + (r ? "#" + r : "");
  try {
    return e.createPolicy(s, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + s + " could not be created."), null;
  }
}, Mu = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function nh() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : n1();
  const e = (R) => nh(R);
  if (e.version = "3.2.6", e.removed = [], !n || !n.document || n.document.nodeType !== Or.document || !n.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const r = t, i = r.currentScript, {
    DocumentFragment: s,
    HTMLTemplateElement: o,
    Node: l,
    Element: a,
    NodeFilter: c,
    NamedNodeMap: u = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: d,
    DOMParser: f,
    trustedTypes: h
  } = n, p = a.prototype, m = $r(p, "cloneNode"), _ = $r(p, "remove"), b = $r(p, "nextSibling"), y = $r(p, "childNodes"), g = $r(p, "parentNode");
  if (typeof o == "function") {
    const R = t.createElement("template");
    R.content && R.content.ownerDocument && (t = R.content.ownerDocument);
  }
  let w, E = "";
  const {
    implementation: v,
    createNodeIterator: D,
    createDocumentFragment: S,
    getElementsByTagName: C
  } = t, {
    importNode: F
  } = r;
  let N = Mu();
  e.isSupported = typeof Zf == "function" && typeof g == "function" && v && v.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: H,
    ERB_EXPR: ke,
    TMPLIT_EXPR: Q,
    DATA_ATTR: ce,
    ARIA_ATTR: K,
    IS_SCRIPT_OR_DATA: pe,
    ATTR_WHITESPACE: ie,
    CUSTOM_ELEMENT: Ce
  } = Tu;
  let {
    IS_ALLOWED_URI: je
  } = Tu, M = null;
  const ye = j({}, [...Su, ...qo, ...Vo, ...Uo, ...Cu]);
  let ne = null;
  const Me = j({}, [...Au, ...jo, ...xu, ...qi]);
  let $ = Object.seal(Qf(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), et = null, en = null, Gn = !0, Jn = !0, Yn = !1, En = !0, tn = !1, nn = !0, Dn = !1, wo = !1, vo = !1, Xn = !1, vi = !1, Ei = !1, nc = !0, rc = !1;
  const Fm = "user-content-";
  let Eo = !0, Dr = !1, Zn = {}, Qn = null;
  const ic = j({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let sc = null;
  const oc = j({}, ["audio", "video", "img", "source", "image", "track"]);
  let Do = null;
  const lc = j({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), Di = "http://www.w3.org/1998/Math/MathML", Si = "http://www.w3.org/2000/svg", zt = "http://www.w3.org/1999/xhtml";
  let er = zt, So = !1, Co = null;
  const $m = j({}, [Di, Si, zt], Ho);
  let Ci = j({}, ["mi", "mo", "mn", "ms", "mtext"]), Ai = j({}, ["annotation-xml"]);
  const Om = j({}, ["title", "style", "font", "a", "script"]);
  let Sr = null;
  const Nm = ["application/xhtml+xml", "text/html"], Im = "text/html";
  let we = null, tr = null;
  const Rm = t.createElement("form"), ac = function(k) {
    return k instanceof RegExp || k instanceof Function;
  }, Ao = function() {
    let k = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(tr && tr === k)) {
      if ((!k || typeof k != "object") && (k = {}), k = Kt(k), Sr = // eslint-disable-next-line unicorn/prefer-includes
      Nm.indexOf(k.PARSER_MEDIA_TYPE) === -1 ? Im : k.PARSER_MEDIA_TYPE, we = Sr === "application/xhtml+xml" ? Ho : ss, M = yt(k, "ALLOWED_TAGS") ? j({}, k.ALLOWED_TAGS, we) : ye, ne = yt(k, "ALLOWED_ATTR") ? j({}, k.ALLOWED_ATTR, we) : Me, Co = yt(k, "ALLOWED_NAMESPACES") ? j({}, k.ALLOWED_NAMESPACES, Ho) : $m, Do = yt(k, "ADD_URI_SAFE_ATTR") ? j(Kt(lc), k.ADD_URI_SAFE_ATTR, we) : lc, sc = yt(k, "ADD_DATA_URI_TAGS") ? j(Kt(oc), k.ADD_DATA_URI_TAGS, we) : oc, Qn = yt(k, "FORBID_CONTENTS") ? j({}, k.FORBID_CONTENTS, we) : ic, et = yt(k, "FORBID_TAGS") ? j({}, k.FORBID_TAGS, we) : Kt({}), en = yt(k, "FORBID_ATTR") ? j({}, k.FORBID_ATTR, we) : Kt({}), Zn = yt(k, "USE_PROFILES") ? k.USE_PROFILES : !1, Gn = k.ALLOW_ARIA_ATTR !== !1, Jn = k.ALLOW_DATA_ATTR !== !1, Yn = k.ALLOW_UNKNOWN_PROTOCOLS || !1, En = k.ALLOW_SELF_CLOSE_IN_ATTR !== !1, tn = k.SAFE_FOR_TEMPLATES || !1, nn = k.SAFE_FOR_XML !== !1, Dn = k.WHOLE_DOCUMENT || !1, Xn = k.RETURN_DOM || !1, vi = k.RETURN_DOM_FRAGMENT || !1, Ei = k.RETURN_TRUSTED_TYPE || !1, vo = k.FORCE_BODY || !1, nc = k.SANITIZE_DOM !== !1, rc = k.SANITIZE_NAMED_PROPS || !1, Eo = k.KEEP_CONTENT !== !1, Dr = k.IN_PLACE || !1, je = k.ALLOWED_URI_REGEXP || eh, er = k.NAMESPACE || zt, Ci = k.MATHML_TEXT_INTEGRATION_POINTS || Ci, Ai = k.HTML_INTEGRATION_POINTS || Ai, $ = k.CUSTOM_ELEMENT_HANDLING || {}, k.CUSTOM_ELEMENT_HANDLING && ac(k.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && ($.tagNameCheck = k.CUSTOM_ELEMENT_HANDLING.tagNameCheck), k.CUSTOM_ELEMENT_HANDLING && ac(k.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && ($.attributeNameCheck = k.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), k.CUSTOM_ELEMENT_HANDLING && typeof k.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && ($.allowCustomizedBuiltInElements = k.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), tn && (Jn = !1), vi && (Xn = !0), Zn && (M = j({}, Cu), ne = [], Zn.html === !0 && (j(M, Su), j(ne, Au)), Zn.svg === !0 && (j(M, qo), j(ne, jo), j(ne, qi)), Zn.svgFilters === !0 && (j(M, Vo), j(ne, jo), j(ne, qi)), Zn.mathMl === !0 && (j(M, Uo), j(ne, xu), j(ne, qi))), k.ADD_TAGS && (M === ye && (M = Kt(M)), j(M, k.ADD_TAGS, we)), k.ADD_ATTR && (ne === Me && (ne = Kt(ne)), j(ne, k.ADD_ATTR, we)), k.ADD_URI_SAFE_ATTR && j(Do, k.ADD_URI_SAFE_ATTR, we), k.FORBID_CONTENTS && (Qn === ic && (Qn = Kt(Qn)), j(Qn, k.FORBID_CONTENTS, we)), Eo && (M["#text"] = !0), Dn && j(M, ["html", "head", "body"]), M.table && (j(M, ["tbody"]), delete et.tbody), k.TRUSTED_TYPES_POLICY) {
        if (typeof k.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Fr('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof k.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Fr('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        w = k.TRUSTED_TYPES_POLICY, E = w.createHTML("");
      } else
        w === void 0 && (w = r1(h, i)), w !== null && typeof E == "string" && (E = w.createHTML(""));
      ze && ze(k), tr = k;
    }
  }, cc = j({}, [...qo, ...Vo, ...Wy]), uc = j({}, [...Uo, ...Ky]), Lm = function(k) {
    let T = g(k);
    (!T || !T.tagName) && (T = {
      namespaceURI: er,
      tagName: "template"
    });
    const I = ss(k.tagName), re = ss(T.tagName);
    return Co[k.namespaceURI] ? k.namespaceURI === Si ? T.namespaceURI === zt ? I === "svg" : T.namespaceURI === Di ? I === "svg" && (re === "annotation-xml" || Ci[re]) : !!cc[I] : k.namespaceURI === Di ? T.namespaceURI === zt ? I === "math" : T.namespaceURI === Si ? I === "math" && Ai[re] : !!uc[I] : k.namespaceURI === zt ? T.namespaceURI === Si && !Ai[re] || T.namespaceURI === Di && !Ci[re] ? !1 : !uc[I] && (Om[I] || !cc[I]) : !!(Sr === "application/xhtml+xml" && Co[k.namespaceURI]) : !1;
  }, Ct = function(k) {
    Tr(e.removed, {
      element: k
    });
    try {
      g(k).removeChild(k);
    } catch {
      _(k);
    }
  }, nr = function(k, T) {
    try {
      Tr(e.removed, {
        attribute: T.getAttributeNode(k),
        from: T
      });
    } catch {
      Tr(e.removed, {
        attribute: null,
        from: T
      });
    }
    if (T.removeAttribute(k), k === "is")
      if (Xn || vi)
        try {
          Ct(T);
        } catch {
        }
      else
        try {
          T.setAttribute(k, "");
        } catch {
        }
  }, dc = function(k) {
    let T = null, I = null;
    if (vo)
      k = "<remove></remove>" + k;
    else {
      const be = Du(k, /^[\r\n\t ]+/);
      I = be && be[0];
    }
    Sr === "application/xhtml+xml" && er === zt && (k = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + k + "</body></html>");
    const re = w ? w.createHTML(k) : k;
    if (er === zt)
      try {
        T = new f().parseFromString(re, Sr);
      } catch {
      }
    if (!T || !T.documentElement) {
      T = v.createDocument(er, "template", null);
      try {
        T.documentElement.innerHTML = So ? E : re;
      } catch {
      }
    }
    const Fe = T.body || T.documentElement;
    return k && I && Fe.insertBefore(t.createTextNode(I), Fe.childNodes[0] || null), er === zt ? C.call(T, Dn ? "html" : "body")[0] : Dn ? T.documentElement : Fe;
  }, fc = function(k) {
    return D.call(
      k.ownerDocument || k,
      k,
      // eslint-disable-next-line no-bitwise
      c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION,
      null
    );
  }, xo = function(k) {
    return k instanceof d && (typeof k.nodeName != "string" || typeof k.textContent != "string" || typeof k.removeChild != "function" || !(k.attributes instanceof u) || typeof k.removeAttribute != "function" || typeof k.setAttribute != "function" || typeof k.namespaceURI != "string" || typeof k.insertBefore != "function" || typeof k.hasChildNodes != "function");
  }, hc = function(k) {
    return typeof l == "function" && k instanceof l;
  };
  function Ht(R, k, T) {
    Hi(R, (I) => {
      I.call(e, k, T, tr);
    });
  }
  const pc = function(k) {
    let T = null;
    if (Ht(N.beforeSanitizeElements, k, null), xo(k))
      return Ct(k), !0;
    const I = we(k.nodeName);
    if (Ht(N.uponSanitizeElement, k, {
      tagName: I,
      allowedTags: M
    }), nn && k.hasChildNodes() && !hc(k.firstElementChild) && Pe(/<[/\w!]/g, k.innerHTML) && Pe(/<[/\w!]/g, k.textContent) || k.nodeType === Or.progressingInstruction || nn && k.nodeType === Or.comment && Pe(/<[/\w]/g, k.data))
      return Ct(k), !0;
    if (!M[I] || et[I]) {
      if (!et[I] && gc(I) && ($.tagNameCheck instanceof RegExp && Pe($.tagNameCheck, I) || $.tagNameCheck instanceof Function && $.tagNameCheck(I)))
        return !1;
      if (Eo && !Qn[I]) {
        const re = g(k) || k.parentNode, Fe = y(k) || k.childNodes;
        if (Fe && re) {
          const be = Fe.length;
          for (let We = be - 1; We >= 0; --We) {
            const qt = m(Fe[We], !0);
            qt.__removalCount = (k.__removalCount || 0) + 1, re.insertBefore(qt, b(k));
          }
        }
      }
      return Ct(k), !0;
    }
    return k instanceof a && !Lm(k) || (I === "noscript" || I === "noembed" || I === "noframes") && Pe(/<\/no(script|embed|frames)/i, k.innerHTML) ? (Ct(k), !0) : (tn && k.nodeType === Or.text && (T = k.textContent, Hi([H, ke, Q], (re) => {
      T = Mr(T, re, " ");
    }), k.textContent !== T && (Tr(e.removed, {
      element: k.cloneNode()
    }), k.textContent = T)), Ht(N.afterSanitizeElements, k, null), !1);
  }, mc = function(k, T, I) {
    if (nc && (T === "id" || T === "name") && (I in t || I in Rm))
      return !1;
    if (!(Jn && !en[T] && Pe(ce, T))) {
      if (!(Gn && Pe(K, T))) {
        if (!ne[T] || en[T]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(gc(k) && ($.tagNameCheck instanceof RegExp && Pe($.tagNameCheck, k) || $.tagNameCheck instanceof Function && $.tagNameCheck(k)) && ($.attributeNameCheck instanceof RegExp && Pe($.attributeNameCheck, T) || $.attributeNameCheck instanceof Function && $.attributeNameCheck(T)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            T === "is" && $.allowCustomizedBuiltInElements && ($.tagNameCheck instanceof RegExp && Pe($.tagNameCheck, I) || $.tagNameCheck instanceof Function && $.tagNameCheck(I)))
          ) return !1;
        } else if (!Do[T]) {
          if (!Pe(je, Mr(I, ie, ""))) {
            if (!((T === "src" || T === "xlink:href" || T === "href") && k !== "script" && qy(I, "data:") === 0 && sc[k])) {
              if (!(Yn && !Pe(pe, Mr(I, ie, "")))) {
                if (I)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, gc = function(k) {
    return k !== "annotation-xml" && Du(k, Ce);
  }, _c = function(k) {
    Ht(N.beforeSanitizeAttributes, k, null);
    const {
      attributes: T
    } = k;
    if (!T || xo(k))
      return;
    const I = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: ne,
      forceKeepAttr: void 0
    };
    let re = T.length;
    for (; re--; ) {
      const Fe = T[re], {
        name: be,
        namespaceURI: We,
        value: qt
      } = Fe, Cr = we(be), To = qt;
      let $e = be === "value" ? To : Vy(To);
      if (I.attrName = Cr, I.attrValue = $e, I.keepAttr = !0, I.forceKeepAttr = void 0, Ht(N.uponSanitizeAttribute, k, I), $e = I.attrValue, rc && (Cr === "id" || Cr === "name") && (nr(be, k), $e = Fm + $e), nn && Pe(/((--!?|])>)|<\/(style|title)/i, $e)) {
        nr(be, k);
        continue;
      }
      if (I.forceKeepAttr)
        continue;
      if (!I.keepAttr) {
        nr(be, k);
        continue;
      }
      if (!En && Pe(/\/>/i, $e)) {
        nr(be, k);
        continue;
      }
      tn && Hi([H, ke, Q], (bc) => {
        $e = Mr($e, bc, " ");
      });
      const yc = we(k.nodeName);
      if (!mc(yc, Cr, $e)) {
        nr(be, k);
        continue;
      }
      if (w && typeof h == "object" && typeof h.getAttributeType == "function" && !We)
        switch (h.getAttributeType(yc, Cr)) {
          case "TrustedHTML": {
            $e = w.createHTML($e);
            break;
          }
          case "TrustedScriptURL": {
            $e = w.createScriptURL($e);
            break;
          }
        }
      if ($e !== To)
        try {
          We ? k.setAttributeNS(We, be, $e) : k.setAttribute(be, $e), xo(k) ? Ct(k) : Eu(e.removed);
        } catch {
          nr(be, k);
        }
    }
    Ht(N.afterSanitizeAttributes, k, null);
  }, Pm = function R(k) {
    let T = null;
    const I = fc(k);
    for (Ht(N.beforeSanitizeShadowDOM, k, null); T = I.nextNode(); )
      Ht(N.uponSanitizeShadowNode, T, null), pc(T), _c(T), T.content instanceof s && R(T.content);
    Ht(N.afterSanitizeShadowDOM, k, null);
  };
  return e.sanitize = function(R) {
    let k = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, T = null, I = null, re = null, Fe = null;
    if (So = !R, So && (R = "<!-->"), typeof R != "string" && !hc(R))
      if (typeof R.toString == "function") {
        if (R = R.toString(), typeof R != "string")
          throw Fr("dirty is not a string, aborting");
      } else
        throw Fr("toString is not a function");
    if (!e.isSupported)
      return R;
    if (wo || Ao(k), e.removed = [], typeof R == "string" && (Dr = !1), Dr) {
      if (R.nodeName) {
        const qt = we(R.nodeName);
        if (!M[qt] || et[qt])
          throw Fr("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (R instanceof l)
      T = dc("<!---->"), I = T.ownerDocument.importNode(R, !0), I.nodeType === Or.element && I.nodeName === "BODY" || I.nodeName === "HTML" ? T = I : T.appendChild(I);
    else {
      if (!Xn && !tn && !Dn && // eslint-disable-next-line unicorn/prefer-includes
      R.indexOf("<") === -1)
        return w && Ei ? w.createHTML(R) : R;
      if (T = dc(R), !T)
        return Xn ? null : Ei ? E : "";
    }
    T && vo && Ct(T.firstChild);
    const be = fc(Dr ? R : T);
    for (; re = be.nextNode(); )
      pc(re), _c(re), re.content instanceof s && Pm(re.content);
    if (Dr)
      return R;
    if (Xn) {
      if (vi)
        for (Fe = S.call(T.ownerDocument); T.firstChild; )
          Fe.appendChild(T.firstChild);
      else
        Fe = T;
      return (ne.shadowroot || ne.shadowrootmode) && (Fe = F.call(r, Fe, !0)), Fe;
    }
    let We = Dn ? T.outerHTML : T.innerHTML;
    return Dn && M["!doctype"] && T.ownerDocument && T.ownerDocument.doctype && T.ownerDocument.doctype.name && Pe(th, T.ownerDocument.doctype.name) && (We = "<!DOCTYPE " + T.ownerDocument.doctype.name + `>
` + We), tn && Hi([H, ke, Q], (qt) => {
      We = Mr(We, qt, " ");
    }), w && Ei ? w.createHTML(We) : We;
  }, e.setConfig = function() {
    let R = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Ao(R), wo = !0;
  }, e.clearConfig = function() {
    tr = null, wo = !1;
  }, e.isValidAttribute = function(R, k, T) {
    tr || Ao({});
    const I = we(R), re = we(k);
    return mc(I, re, T);
  }, e.addHook = function(R, k) {
    typeof k == "function" && Tr(N[R], k);
  }, e.removeHook = function(R, k) {
    if (k !== void 0) {
      const T = zy(N[R], k);
      return T === -1 ? void 0 : Hy(N[R], T, 1)[0];
    }
    return Eu(N[R]);
  }, e.removeHooks = function(R) {
    N[R] = [];
  }, e.removeAllHooks = function() {
    N = Mu();
  }, e;
}
var Z5 = nh();
const {
  HtmlTagHydration: Q5,
  SvelteComponent: eB,
  add_render_callback: tB,
  append_hydration: nB,
  attr: rB,
  bubble: iB,
  check_outros: sB,
  children: oB,
  claim_component: lB,
  claim_element: aB,
  claim_html_tag: cB,
  claim_space: uB,
  claim_text: dB,
  create_component: fB,
  create_in_transition: hB,
  create_out_transition: pB,
  destroy_component: mB,
  detach: gB,
  element: _B,
  get_svelte_dataset: yB,
  group_outros: bB,
  init: kB,
  insert_hydration: wB,
  listen: vB,
  mount_component: EB,
  run_all: DB,
  safe_not_equal: SB,
  set_data: CB,
  space: AB,
  stop_propagation: xB,
  text: TB,
  toggle_class: MB,
  transition_in: FB,
  transition_out: $B
} = window.__gradio__svelte__internal, { createEventDispatcher: OB, onMount: NB } = window.__gradio__svelte__internal, {
  SvelteComponent: IB,
  append_hydration: RB,
  attr: LB,
  bubble: PB,
  check_outros: BB,
  children: zB,
  claim_component: HB,
  claim_element: qB,
  claim_space: VB,
  create_animation: UB,
  create_component: jB,
  destroy_component: WB,
  detach: KB,
  element: GB,
  ensure_array_like: JB,
  fix_and_outro_and_destroy_block: YB,
  fix_position: XB,
  group_outros: ZB,
  init: QB,
  insert_hydration: e9,
  mount_component: t9,
  noop: n9,
  safe_not_equal: r9,
  set_style: i9,
  space: s9,
  transition_in: o9,
  transition_out: l9,
  update_keyed_each: a9
} = window.__gradio__svelte__internal, {
  SvelteComponent: c9,
  attr: u9,
  children: d9,
  claim_element: f9,
  detach: h9,
  element: p9,
  empty: m9,
  init: g9,
  insert_hydration: _9,
  noop: y9,
  safe_not_equal: b9,
  set_style: k9
} = window.__gradio__svelte__internal;
function Ae(n) {
  this.content = n;
}
Ae.prototype = {
  constructor: Ae,
  find: function(n) {
    for (var e = 0; e < this.content.length; e += 2)
      if (this.content[e] === n) return e;
    return -1;
  },
  // :: (string) → ?any
  // Retrieve the value stored under `key`, or return undefined when
  // no such key exists.
  get: function(n) {
    var e = this.find(n);
    return e == -1 ? void 0 : this.content[e + 1];
  },
  // :: (string, any, ?string) → OrderedMap
  // Create a new map by replacing the value of `key` with a new
  // value, or adding a binding to the end of the map. If `newKey` is
  // given, the key of the binding will be replaced with that key.
  update: function(n, e, t) {
    var r = t && t != n ? this.remove(t) : this, i = r.find(n), s = r.content.slice();
    return i == -1 ? s.push(t || n, e) : (s[i + 1] = e, t && (s[i] = t)), new Ae(s);
  },
  // :: (string) → OrderedMap
  // Return a map with the given key removed, if it existed.
  remove: function(n) {
    var e = this.find(n);
    if (e == -1) return this;
    var t = this.content.slice();
    return t.splice(e, 2), new Ae(t);
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the start of the map.
  addToStart: function(n, e) {
    return new Ae([n, e].concat(this.remove(n).content));
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the end of the map.
  addToEnd: function(n, e) {
    var t = this.remove(n).content.slice();
    return t.push(n, e), new Ae(t);
  },
  // :: (string, string, any) → OrderedMap
  // Add a key after the given key. If `place` is not found, the new
  // key is added to the end.
  addBefore: function(n, e, t) {
    var r = this.remove(e), i = r.content.slice(), s = r.find(n);
    return i.splice(s == -1 ? i.length : s, 0, e, t), new Ae(i);
  },
  // :: ((key: string, value: any))
  // Call the given function for each key/value pair in the map, in
  // order.
  forEach: function(n) {
    for (var e = 0; e < this.content.length; e += 2)
      n(this.content[e], this.content[e + 1]);
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by prepending the keys in this map that don't
  // appear in `map` before the keys in `map`.
  prepend: function(n) {
    return n = Ae.from(n), n.size ? new Ae(n.content.concat(this.subtract(n).content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by appending the keys in this map that don't
  // appear in `map` after the keys in `map`.
  append: function(n) {
    return n = Ae.from(n), n.size ? new Ae(this.subtract(n).content.concat(n.content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a map containing all the keys in this map that don't
  // appear in `map`.
  subtract: function(n) {
    var e = this;
    n = Ae.from(n);
    for (var t = 0; t < n.content.length; t += 2)
      e = e.remove(n.content[t]);
    return e;
  },
  // :: () → Object
  // Turn ordered map into a plain object.
  toObject: function() {
    var n = {};
    return this.forEach(function(e, t) {
      n[e] = t;
    }), n;
  },
  // :: number
  // The amount of keys in this map.
  get size() {
    return this.content.length >> 1;
  }
};
Ae.from = function(n) {
  if (n instanceof Ae) return n;
  var e = [];
  if (n) for (var t in n) e.push(t, n[t]);
  return new Ae(e);
};
function rh(n, e, t) {
  for (let r = 0; ; r++) {
    if (r == n.childCount || r == e.childCount)
      return n.childCount == e.childCount ? null : t;
    let i = n.child(r), s = e.child(r);
    if (i == s) {
      t += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(s))
      return t;
    if (i.isText && i.text != s.text) {
      for (let o = 0; i.text[o] == s.text[o]; o++)
        t++;
      return t;
    }
    if (i.content.size || s.content.size) {
      let o = rh(i.content, s.content, t + 1);
      if (o != null)
        return o;
    }
    t += i.nodeSize;
  }
}
function ih(n, e, t, r) {
  for (let i = n.childCount, s = e.childCount; ; ) {
    if (i == 0 || s == 0)
      return i == s ? null : { a: t, b: r };
    let o = n.child(--i), l = e.child(--s), a = o.nodeSize;
    if (o == l) {
      t -= a, r -= a;
      continue;
    }
    if (!o.sameMarkup(l))
      return { a: t, b: r };
    if (o.isText && o.text != l.text) {
      let c = 0, u = Math.min(o.text.length, l.text.length);
      for (; c < u && o.text[o.text.length - c - 1] == l.text[l.text.length - c - 1]; )
        c++, t--, r--;
      return { a: t, b: r };
    }
    if (o.content.size || l.content.size) {
      let c = ih(o.content, l.content, t - 1, r - 1);
      if (c)
        return c;
    }
    t -= a, r -= a;
  }
}
class A {
  /**
  @internal
  */
  constructor(e, t) {
    if (this.content = e, this.size = t || 0, t == null)
      for (let r = 0; r < e.length; r++)
        this.size += e[r].nodeSize;
  }
  /**
  Invoke a callback for all descendant nodes between the given two
  positions (relative to start of this fragment). Doesn't descend
  into a node when the callback returns `false`.
  */
  nodesBetween(e, t, r, i = 0, s) {
    for (let o = 0, l = 0; l < t; o++) {
      let a = this.content[o], c = l + a.nodeSize;
      if (c > e && r(a, i + l, s || null, o) !== !1 && a.content.size) {
        let u = l + 1;
        a.nodesBetween(Math.max(0, e - u), Math.min(a.content.size, t - u), r, i + u);
      }
      l = c;
    }
  }
  /**
  Call the given callback for every descendant node. `pos` will be
  relative to the start of the fragment. The callback may return
  `false` to prevent traversal of a given node's children.
  */
  descendants(e) {
    this.nodesBetween(0, this.size, e);
  }
  /**
  Extract the text between `from` and `to`. See the same method on
  [`Node`](https://prosemirror.net/docs/ref/#model.Node.textBetween).
  */
  textBetween(e, t, r, i) {
    let s = "", o = !0;
    return this.nodesBetween(e, t, (l, a) => {
      let c = l.isText ? l.text.slice(Math.max(e, a) - a, t - a) : l.isLeaf ? i ? typeof i == "function" ? i(l) : i : l.type.spec.leafText ? l.type.spec.leafText(l) : "" : "";
      l.isBlock && (l.isLeaf && c || l.isTextblock) && r && (o ? o = !1 : s += r), s += c;
    }, 0), s;
  }
  /**
  Create a new fragment containing the combined content of this
  fragment and the other.
  */
  append(e) {
    if (!e.size)
      return this;
    if (!this.size)
      return e;
    let t = this.lastChild, r = e.firstChild, i = this.content.slice(), s = 0;
    for (t.isText && t.sameMarkup(r) && (i[i.length - 1] = t.withText(t.text + r.text), s = 1); s < e.content.length; s++)
      i.push(e.content[s]);
    return new A(i, this.size + e.size);
  }
  /**
  Cut out the sub-fragment between the two given positions.
  */
  cut(e, t = this.size) {
    if (e == 0 && t == this.size)
      return this;
    let r = [], i = 0;
    if (t > e)
      for (let s = 0, o = 0; o < t; s++) {
        let l = this.content[s], a = o + l.nodeSize;
        a > e && ((o < e || a > t) && (l.isText ? l = l.cut(Math.max(0, e - o), Math.min(l.text.length, t - o)) : l = l.cut(Math.max(0, e - o - 1), Math.min(l.content.size, t - o - 1))), r.push(l), i += l.nodeSize), o = a;
      }
    return new A(r, i);
  }
  /**
  @internal
  */
  cutByIndex(e, t) {
    return e == t ? A.empty : e == 0 && t == this.content.length ? this : new A(this.content.slice(e, t));
  }
  /**
  Create a new fragment in which the node at the given index is
  replaced by the given node.
  */
  replaceChild(e, t) {
    let r = this.content[e];
    if (r == t)
      return this;
    let i = this.content.slice(), s = this.size + t.nodeSize - r.nodeSize;
    return i[e] = t, new A(i, s);
  }
  /**
  Create a new fragment by prepending the given node to this
  fragment.
  */
  addToStart(e) {
    return new A([e].concat(this.content), this.size + e.nodeSize);
  }
  /**
  Create a new fragment by appending the given node to this
  fragment.
  */
  addToEnd(e) {
    return new A(this.content.concat(e), this.size + e.nodeSize);
  }
  /**
  Compare this fragment to another one.
  */
  eq(e) {
    if (this.content.length != e.content.length)
      return !1;
    for (let t = 0; t < this.content.length; t++)
      if (!this.content[t].eq(e.content[t]))
        return !1;
    return !0;
  }
  /**
  The first child of the fragment, or `null` if it is empty.
  */
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  /**
  The last child of the fragment, or `null` if it is empty.
  */
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  /**
  The number of child nodes in this fragment.
  */
  get childCount() {
    return this.content.length;
  }
  /**
  Get the child node at the given index. Raise an error when the
  index is out of range.
  */
  child(e) {
    let t = this.content[e];
    if (!t)
      throw new RangeError("Index " + e + " out of range for " + this);
    return t;
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content[e] || null;
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    for (let t = 0, r = 0; t < this.content.length; t++) {
      let i = this.content[t];
      e(i, r, t), r += i.nodeSize;
    }
  }
  /**
  Find the first position at which this fragment and another
  fragment differ, or `null` if they are the same.
  */
  findDiffStart(e, t = 0) {
    return rh(this, e, t);
  }
  /**
  Find the first position, searching from the end, at which this
  fragment and the given fragment differ, or `null` if they are
  the same. Since this position will not be the same in both
  nodes, an object with two separate positions is returned.
  */
  findDiffEnd(e, t = this.size, r = e.size) {
    return ih(this, e, t, r);
  }
  /**
  Find the index and inner offset corresponding to a given relative
  position in this fragment. The result object will be reused
  (overwritten) the next time the function is called. @internal
  */
  findIndex(e) {
    if (e == 0)
      return Vi(0, e);
    if (e == this.size)
      return Vi(this.content.length, e);
    if (e > this.size || e < 0)
      throw new RangeError(`Position ${e} outside of fragment (${this})`);
    for (let t = 0, r = 0; ; t++) {
      let i = this.child(t), s = r + i.nodeSize;
      if (s >= e)
        return s == e ? Vi(t + 1, s) : Vi(t, r);
      r = s;
    }
  }
  /**
  Return a debugging string that describes this fragment.
  */
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  /**
  @internal
  */
  toStringInner() {
    return this.content.join(", ");
  }
  /**
  Create a JSON-serializeable representation of this fragment.
  */
  toJSON() {
    return this.content.length ? this.content.map((e) => e.toJSON()) : null;
  }
  /**
  Deserialize a fragment from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return A.empty;
    if (!Array.isArray(t))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return new A(t.map(e.nodeFromJSON));
  }
  /**
  Build a fragment from an array of nodes. Ensures that adjacent
  text nodes with the same marks are joined together.
  */
  static fromArray(e) {
    if (!e.length)
      return A.empty;
    let t, r = 0;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      r += s.nodeSize, i && s.isText && e[i - 1].sameMarkup(s) ? (t || (t = e.slice(0, i)), t[t.length - 1] = s.withText(t[t.length - 1].text + s.text)) : t && t.push(s);
    }
    return new A(t || e, r);
  }
  /**
  Create a fragment from something that can be interpreted as a
  set of nodes. For `null`, it returns the empty fragment. For a
  fragment, the fragment itself. For a node or array of nodes, a
  fragment containing those nodes.
  */
  static from(e) {
    if (!e)
      return A.empty;
    if (e instanceof A)
      return e;
    if (Array.isArray(e))
      return this.fromArray(e);
    if (e.attrs)
      return new A([e], e.nodeSize);
    throw new RangeError("Can not convert " + e + " to a Fragment" + (e.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
A.empty = new A([], 0);
const Wo = { index: 0, offset: 0 };
function Vi(n, e) {
  return Wo.index = n, Wo.offset = e, Wo;
}
function gs(n, e) {
  if (n === e)
    return !0;
  if (!(n && typeof n == "object") || !(e && typeof e == "object"))
    return !1;
  let t = Array.isArray(n);
  if (Array.isArray(e) != t)
    return !1;
  if (t) {
    if (n.length != e.length)
      return !1;
    for (let r = 0; r < n.length; r++)
      if (!gs(n[r], e[r]))
        return !1;
  } else {
    for (let r in n)
      if (!(r in e) || !gs(n[r], e[r]))
        return !1;
    for (let r in e)
      if (!(r in n))
        return !1;
  }
  return !0;
}
let Z = class Fl {
  /**
  @internal
  */
  constructor(e, t) {
    this.type = e, this.attrs = t;
  }
  /**
  Given a set of marks, create a new set which contains this one as
  well, in the right position. If this mark is already in the set,
  the set itself is returned. If any marks that are set to be
  [exclusive](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) with this mark are present,
  those are replaced by this one.
  */
  addToSet(e) {
    let t, r = !1;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      if (this.eq(s))
        return e;
      if (this.type.excludes(s.type))
        t || (t = e.slice(0, i));
      else {
        if (s.type.excludes(this.type))
          return e;
        !r && s.type.rank > this.type.rank && (t || (t = e.slice(0, i)), t.push(this), r = !0), t && t.push(s);
      }
    }
    return t || (t = e.slice()), r || t.push(this), t;
  }
  /**
  Remove this mark from the given set, returning a new set. If this
  mark is not in the set, the set itself is returned.
  */
  removeFromSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return e.slice(0, t).concat(e.slice(t + 1));
    return e;
  }
  /**
  Test whether this mark is in the given set of marks.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return !0;
    return !1;
  }
  /**
  Test whether this mark has the same type and attributes as
  another mark.
  */
  eq(e) {
    return this == e || this.type == e.type && gs(this.attrs, e.attrs);
  }
  /**
  Convert this mark to a JSON-serializeable representation.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return e;
  }
  /**
  Deserialize a mark from JSON.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let r = e.marks[t.type];
    if (!r)
      throw new RangeError(`There is no mark type ${t.type} in this schema`);
    let i = r.create(t.attrs);
    return r.checkAttrs(i.attrs), i;
  }
  /**
  Test whether two sets of marks are identical.
  */
  static sameSet(e, t) {
    if (e == t)
      return !0;
    if (e.length != t.length)
      return !1;
    for (let r = 0; r < e.length; r++)
      if (!e[r].eq(t[r]))
        return !1;
    return !0;
  }
  /**
  Create a properly sorted mark set from null, a single mark, or an
  unsorted array of marks.
  */
  static setFrom(e) {
    if (!e || Array.isArray(e) && e.length == 0)
      return Fl.none;
    if (e instanceof Fl)
      return [e];
    let t = e.slice();
    return t.sort((r, i) => r.type.rank - i.type.rank), t;
  }
};
Z.none = [];
class _s extends Error {
}
class O {
  /**
  Create a slice. When specifying a non-zero open depth, you must
  make sure that there are nodes of at least that depth at the
  appropriate side of the fragment—i.e. if the fragment is an
  empty paragraph node, `openStart` and `openEnd` can't be greater
  than 1.
  
  It is not necessary for the content of open nodes to conform to
  the schema's content constraints, though it should be a valid
  start/end/middle for such a node, depending on which sides are
  open.
  */
  constructor(e, t, r) {
    this.content = e, this.openStart = t, this.openEnd = r;
  }
  /**
  The size this slice would add when inserted into a document.
  */
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  /**
  @internal
  */
  insertAt(e, t) {
    let r = oh(this.content, e + this.openStart, t);
    return r && new O(r, this.openStart, this.openEnd);
  }
  /**
  @internal
  */
  removeBetween(e, t) {
    return new O(sh(this.content, e + this.openStart, t + this.openStart), this.openStart, this.openEnd);
  }
  /**
  Tests whether this slice is equal to another slice.
  */
  eq(e) {
    return this.content.eq(e.content) && this.openStart == e.openStart && this.openEnd == e.openEnd;
  }
  /**
  @internal
  */
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  /**
  Convert a slice to a JSON-serializable representation.
  */
  toJSON() {
    if (!this.content.size)
      return null;
    let e = { content: this.content.toJSON() };
    return this.openStart > 0 && (e.openStart = this.openStart), this.openEnd > 0 && (e.openEnd = this.openEnd), e;
  }
  /**
  Deserialize a slice from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return O.empty;
    let r = t.openStart || 0, i = t.openEnd || 0;
    if (typeof r != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new O(A.fromJSON(e, t.content), r, i);
  }
  /**
  Create a slice from a fragment by taking the maximum possible
  open value on both side of the fragment.
  */
  static maxOpen(e, t = !0) {
    let r = 0, i = 0;
    for (let s = e.firstChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.firstChild)
      r++;
    for (let s = e.lastChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.lastChild)
      i++;
    return new O(e, r, i);
  }
}
O.empty = new O(A.empty, 0, 0);
function sh(n, e, t) {
  let { index: r, offset: i } = n.findIndex(e), s = n.maybeChild(r), { index: o, offset: l } = n.findIndex(t);
  if (i == e || s.isText) {
    if (l != t && !n.child(o).isText)
      throw new RangeError("Removing non-flat range");
    return n.cut(0, e).append(n.cut(t));
  }
  if (r != o)
    throw new RangeError("Removing non-flat range");
  return n.replaceChild(r, s.copy(sh(s.content, e - i - 1, t - i - 1)));
}
function oh(n, e, t, r) {
  let { index: i, offset: s } = n.findIndex(e), o = n.maybeChild(i);
  if (s == e || o.isText)
    return n.cut(0, e).append(t).append(n.cut(e));
  let l = oh(o.content, e - s - 1, t);
  return l && n.replaceChild(i, o.copy(l));
}
function i1(n, e, t) {
  if (t.openStart > n.depth)
    throw new _s("Inserted content deeper than insertion position");
  if (n.depth - t.openStart != e.depth - t.openEnd)
    throw new _s("Inconsistent open depths");
  return lh(n, e, t, 0);
}
function lh(n, e, t, r) {
  let i = n.index(r), s = n.node(r);
  if (i == e.index(r) && r < n.depth - t.openStart) {
    let o = lh(n, e, t, r + 1);
    return s.copy(s.content.replaceChild(i, o));
  } else if (t.content.size)
    if (!t.openStart && !t.openEnd && n.depth == r && e.depth == r) {
      let o = n.parent, l = o.content;
      return Nn(o, l.cut(0, n.parentOffset).append(t.content).append(l.cut(e.parentOffset)));
    } else {
      let { start: o, end: l } = s1(t, n);
      return Nn(s, ch(n, o, l, e, r));
    }
  else return Nn(s, ys(n, e, r));
}
function ah(n, e) {
  if (!e.type.compatibleContent(n.type))
    throw new _s("Cannot join " + e.type.name + " onto " + n.type.name);
}
function $l(n, e, t) {
  let r = n.node(t);
  return ah(r, e.node(t)), r;
}
function On(n, e) {
  let t = e.length - 1;
  t >= 0 && n.isText && n.sameMarkup(e[t]) ? e[t] = n.withText(e[t].text + n.text) : e.push(n);
}
function Wr(n, e, t, r) {
  let i = (e || n).node(t), s = 0, o = e ? e.index(t) : i.childCount;
  n && (s = n.index(t), n.depth > t ? s++ : n.textOffset && (On(n.nodeAfter, r), s++));
  for (let l = s; l < o; l++)
    On(i.child(l), r);
  e && e.depth == t && e.textOffset && On(e.nodeBefore, r);
}
function Nn(n, e) {
  return n.type.checkContent(e), n.copy(e);
}
function ch(n, e, t, r, i) {
  let s = n.depth > i && $l(n, e, i + 1), o = r.depth > i && $l(t, r, i + 1), l = [];
  return Wr(null, n, i, l), s && o && e.index(i) == t.index(i) ? (ah(s, o), On(Nn(s, ch(n, e, t, r, i + 1)), l)) : (s && On(Nn(s, ys(n, e, i + 1)), l), Wr(e, t, i, l), o && On(Nn(o, ys(t, r, i + 1)), l)), Wr(r, null, i, l), new A(l);
}
function ys(n, e, t) {
  let r = [];
  if (Wr(null, n, t, r), n.depth > t) {
    let i = $l(n, e, t + 1);
    On(Nn(i, ys(n, e, t + 1)), r);
  }
  return Wr(e, null, t, r), new A(r);
}
function s1(n, e) {
  let t = e.depth - n.openStart, i = e.node(t).copy(n.content);
  for (let s = t - 1; s >= 0; s--)
    i = e.node(s).copy(A.from(i));
  return {
    start: i.resolveNoCache(n.openStart + t),
    end: i.resolveNoCache(i.content.size - n.openEnd - t)
  };
}
class si {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.pos = e, this.path = t, this.parentOffset = r, this.depth = t.length / 3 - 1;
  }
  /**
  @internal
  */
  resolveDepth(e) {
    return e == null ? this.depth : e < 0 ? this.depth + e : e;
  }
  /**
  The parent node that the position points into. Note that even if
  a position points into a text node, that node is not considered
  the parent—text nodes are ‘flat’ in this model, and have no content.
  */
  get parent() {
    return this.node(this.depth);
  }
  /**
  The root node in which the position was resolved.
  */
  get doc() {
    return this.node(0);
  }
  /**
  The ancestor node at the given level. `p.node(p.depth)` is the
  same as `p.parent`.
  */
  node(e) {
    return this.path[this.resolveDepth(e) * 3];
  }
  /**
  The index into the ancestor at the given level. If this points
  at the 3rd node in the 2nd paragraph on the top level, for
  example, `p.index(0)` is 1 and `p.index(1)` is 2.
  */
  index(e) {
    return this.path[this.resolveDepth(e) * 3 + 1];
  }
  /**
  The index pointing after this position into the ancestor at the
  given level.
  */
  indexAfter(e) {
    return e = this.resolveDepth(e), this.index(e) + (e == this.depth && !this.textOffset ? 0 : 1);
  }
  /**
  The (absolute) position at the start of the node at the given
  level.
  */
  start(e) {
    return e = this.resolveDepth(e), e == 0 ? 0 : this.path[e * 3 - 1] + 1;
  }
  /**
  The (absolute) position at the end of the node at the given
  level.
  */
  end(e) {
    return e = this.resolveDepth(e), this.start(e) + this.node(e).content.size;
  }
  /**
  The (absolute) position directly before the wrapping node at the
  given level, or, when `depth` is `this.depth + 1`, the original
  position.
  */
  before(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position before the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1];
  }
  /**
  The (absolute) position directly after the wrapping node at the
  given level, or the original position when `depth` is `this.depth + 1`.
  */
  after(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position after the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1] + this.path[e * 3].nodeSize;
  }
  /**
  When this position points into a text node, this returns the
  distance between the position and the start of the text node.
  Will be zero for positions that point between nodes.
  */
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  /**
  Get the node directly after the position, if any. If the position
  points into a text node, only the part of that node after the
  position is returned.
  */
  get nodeAfter() {
    let e = this.parent, t = this.index(this.depth);
    if (t == e.childCount)
      return null;
    let r = this.pos - this.path[this.path.length - 1], i = e.child(t);
    return r ? e.child(t).cut(r) : i;
  }
  /**
  Get the node directly before the position, if any. If the
  position points into a text node, only the part of that node
  before the position is returned.
  */
  get nodeBefore() {
    let e = this.index(this.depth), t = this.pos - this.path[this.path.length - 1];
    return t ? this.parent.child(e).cut(0, t) : e == 0 ? null : this.parent.child(e - 1);
  }
  /**
  Get the position at the given index in the parent node at the
  given depth (which defaults to `this.depth`).
  */
  posAtIndex(e, t) {
    t = this.resolveDepth(t);
    let r = this.path[t * 3], i = t == 0 ? 0 : this.path[t * 3 - 1] + 1;
    for (let s = 0; s < e; s++)
      i += r.child(s).nodeSize;
    return i;
  }
  /**
  Get the marks at this position, factoring in the surrounding
  marks' [`inclusive`](https://prosemirror.net/docs/ref/#model.MarkSpec.inclusive) property. If the
  position is at the start of a non-empty node, the marks of the
  node after it (if any) are returned.
  */
  marks() {
    let e = this.parent, t = this.index();
    if (e.content.size == 0)
      return Z.none;
    if (this.textOffset)
      return e.child(t).marks;
    let r = e.maybeChild(t - 1), i = e.maybeChild(t);
    if (!r) {
      let l = r;
      r = i, i = l;
    }
    let s = r.marks;
    for (var o = 0; o < s.length; o++)
      s[o].type.spec.inclusive === !1 && (!i || !s[o].isInSet(i.marks)) && (s = s[o--].removeFromSet(s));
    return s;
  }
  /**
  Get the marks after the current position, if any, except those
  that are non-inclusive and not present at position `$end`. This
  is mostly useful for getting the set of marks to preserve after a
  deletion. Will return `null` if this position is at the end of
  its parent node or its parent node isn't a textblock (in which
  case no marks should be preserved).
  */
  marksAcross(e) {
    let t = this.parent.maybeChild(this.index());
    if (!t || !t.isInline)
      return null;
    let r = t.marks, i = e.parent.maybeChild(e.index());
    for (var s = 0; s < r.length; s++)
      r[s].type.spec.inclusive === !1 && (!i || !r[s].isInSet(i.marks)) && (r = r[s--].removeFromSet(r));
    return r;
  }
  /**
  The depth up to which this position and the given (non-resolved)
  position share the same parent nodes.
  */
  sharedDepth(e) {
    for (let t = this.depth; t > 0; t--)
      if (this.start(t) <= e && this.end(t) >= e)
        return t;
    return 0;
  }
  /**
  Returns a range based on the place where this position and the
  given position diverge around block content. If both point into
  the same textblock, for example, a range around that textblock
  will be returned. If they point into different blocks, the range
  around those blocks in their shared ancestor is returned. You can
  pass in an optional predicate that will be called with a parent
  node to see if a range into that parent is acceptable.
  */
  blockRange(e = this, t) {
    if (e.pos < this.pos)
      return e.blockRange(this);
    for (let r = this.depth - (this.parent.inlineContent || this.pos == e.pos ? 1 : 0); r >= 0; r--)
      if (e.pos <= this.end(r) && (!t || t(this.node(r))))
        return new bs(this, e, r);
    return null;
  }
  /**
  Query whether the given position shares the same parent node.
  */
  sameParent(e) {
    return this.pos - this.parentOffset == e.pos - e.parentOffset;
  }
  /**
  Return the greater of this and the given position.
  */
  max(e) {
    return e.pos > this.pos ? e : this;
  }
  /**
  Return the smaller of this and the given position.
  */
  min(e) {
    return e.pos < this.pos ? e : this;
  }
  /**
  @internal
  */
  toString() {
    let e = "";
    for (let t = 1; t <= this.depth; t++)
      e += (e ? "/" : "") + this.node(t).type.name + "_" + this.index(t - 1);
    return e + ":" + this.parentOffset;
  }
  /**
  @internal
  */
  static resolve(e, t) {
    if (!(t >= 0 && t <= e.content.size))
      throw new RangeError("Position " + t + " out of range");
    let r = [], i = 0, s = t;
    for (let o = e; ; ) {
      let { index: l, offset: a } = o.content.findIndex(s), c = s - a;
      if (r.push(o, l, i + a), !c || (o = o.child(l), o.isText))
        break;
      s = c - 1, i += a + 1;
    }
    return new si(t, r, s);
  }
  /**
  @internal
  */
  static resolveCached(e, t) {
    let r = Fu.get(e);
    if (r)
      for (let s = 0; s < r.elts.length; s++) {
        let o = r.elts[s];
        if (o.pos == t)
          return o;
      }
    else
      Fu.set(e, r = new o1());
    let i = r.elts[r.i] = si.resolve(e, t);
    return r.i = (r.i + 1) % l1, i;
  }
}
class o1 {
  constructor() {
    this.elts = [], this.i = 0;
  }
}
const l1 = 12, Fu = /* @__PURE__ */ new WeakMap();
class bs {
  /**
  Construct a node range. `$from` and `$to` should point into the
  same node until at least the given `depth`, since a node range
  denotes an adjacent set of nodes in a single parent node.
  */
  constructor(e, t, r) {
    this.$from = e, this.$to = t, this.depth = r;
  }
  /**
  The position at the start of the range.
  */
  get start() {
    return this.$from.before(this.depth + 1);
  }
  /**
  The position at the end of the range.
  */
  get end() {
    return this.$to.after(this.depth + 1);
  }
  /**
  The parent node that the range points into.
  */
  get parent() {
    return this.$from.node(this.depth);
  }
  /**
  The start index of the range in the parent node.
  */
  get startIndex() {
    return this.$from.index(this.depth);
  }
  /**
  The end index of the range in the parent node.
  */
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const a1 = /* @__PURE__ */ Object.create(null);
class Dt {
  /**
  @internal
  */
  constructor(e, t, r, i = Z.none) {
    this.type = e, this.attrs = t, this.marks = i, this.content = r || A.empty;
  }
  /**
  The array of this node's child nodes.
  */
  get children() {
    return this.content.content;
  }
  /**
  The size of this node, as defined by the integer-based [indexing
  scheme](https://prosemirror.net/docs/guide/#doc.indexing). For text nodes, this is the
  amount of characters. For other leaf nodes, it is one. For
  non-leaf nodes, it is the size of the content plus two (the
  start and end token).
  */
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  /**
  The number of children that the node has.
  */
  get childCount() {
    return this.content.childCount;
  }
  /**
  Get the child node at the given index. Raises an error when the
  index is out of range.
  */
  child(e) {
    return this.content.child(e);
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content.maybeChild(e);
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    this.content.forEach(e);
  }
  /**
  Invoke a callback for all descendant nodes recursively between
  the given two positions that are relative to start of this
  node's content. The callback is invoked with the node, its
  position relative to the original node (method receiver),
  its parent node, and its child index. When the callback returns
  false for a given node, that node's children will not be
  recursed over. The last parameter can be used to specify a
  starting position to count from.
  */
  nodesBetween(e, t, r, i = 0) {
    this.content.nodesBetween(e, t, r, i, this);
  }
  /**
  Call the given callback for every descendant node. Doesn't
  descend into a node when the callback returns `false`.
  */
  descendants(e) {
    this.nodesBetween(0, this.content.size, e);
  }
  /**
  Concatenates all the text nodes found in this fragment and its
  children.
  */
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  /**
  Get all text between positions `from` and `to`. When
  `blockSeparator` is given, it will be inserted to separate text
  from different block nodes. If `leafText` is given, it'll be
  inserted for every non-text leaf node encountered, otherwise
  [`leafText`](https://prosemirror.net/docs/ref/#model.NodeSpec.leafText) will be used.
  */
  textBetween(e, t, r, i) {
    return this.content.textBetween(e, t, r, i);
  }
  /**
  Returns this node's first child, or `null` if there are no
  children.
  */
  get firstChild() {
    return this.content.firstChild;
  }
  /**
  Returns this node's last child, or `null` if there are no
  children.
  */
  get lastChild() {
    return this.content.lastChild;
  }
  /**
  Test whether two nodes represent the same piece of document.
  */
  eq(e) {
    return this == e || this.sameMarkup(e) && this.content.eq(e.content);
  }
  /**
  Compare the markup (type, attributes, and marks) of this node to
  those of another. Returns `true` if both have the same markup.
  */
  sameMarkup(e) {
    return this.hasMarkup(e.type, e.attrs, e.marks);
  }
  /**
  Check whether this node's markup correspond to the given type,
  attributes, and marks.
  */
  hasMarkup(e, t, r) {
    return this.type == e && gs(this.attrs, t || e.defaultAttrs || a1) && Z.sameSet(this.marks, r || Z.none);
  }
  /**
  Create a new node with the same markup as this node, containing
  the given content (or empty, if no content is given).
  */
  copy(e = null) {
    return e == this.content ? this : new Dt(this.type, this.attrs, e, this.marks);
  }
  /**
  Create a copy of this node, with the given set of marks instead
  of the node's own marks.
  */
  mark(e) {
    return e == this.marks ? this : new Dt(this.type, this.attrs, this.content, e);
  }
  /**
  Create a copy of this node with only the content between the
  given positions. If `to` is not given, it defaults to the end of
  the node.
  */
  cut(e, t = this.content.size) {
    return e == 0 && t == this.content.size ? this : this.copy(this.content.cut(e, t));
  }
  /**
  Cut out the part of the document between the given positions, and
  return it as a `Slice` object.
  */
  slice(e, t = this.content.size, r = !1) {
    if (e == t)
      return O.empty;
    let i = this.resolve(e), s = this.resolve(t), o = r ? 0 : i.sharedDepth(t), l = i.start(o), c = i.node(o).content.cut(i.pos - l, s.pos - l);
    return new O(c, i.depth - o, s.depth - o);
  }
  /**
  Replace the part of the document between the given positions with
  the given slice. The slice must 'fit', meaning its open sides
  must be able to connect to the surrounding content, and its
  content nodes must be valid children for the node they are placed
  into. If any of this is violated, an error of type
  [`ReplaceError`](https://prosemirror.net/docs/ref/#model.ReplaceError) is thrown.
  */
  replace(e, t, r) {
    return i1(this.resolve(e), this.resolve(t), r);
  }
  /**
  Find the node directly after the given position.
  */
  nodeAt(e) {
    for (let t = this; ; ) {
      let { index: r, offset: i } = t.content.findIndex(e);
      if (t = t.maybeChild(r), !t)
        return null;
      if (i == e || t.isText)
        return t;
      e -= i + 1;
    }
  }
  /**
  Find the (direct) child node after the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childAfter(e) {
    let { index: t, offset: r } = this.content.findIndex(e);
    return { node: this.content.maybeChild(t), index: t, offset: r };
  }
  /**
  Find the (direct) child node before the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childBefore(e) {
    if (e == 0)
      return { node: null, index: 0, offset: 0 };
    let { index: t, offset: r } = this.content.findIndex(e);
    if (r < e)
      return { node: this.content.child(t), index: t, offset: r };
    let i = this.content.child(t - 1);
    return { node: i, index: t - 1, offset: r - i.nodeSize };
  }
  /**
  Resolve the given position in the document, returning an
  [object](https://prosemirror.net/docs/ref/#model.ResolvedPos) with information about its context.
  */
  resolve(e) {
    return si.resolveCached(this, e);
  }
  /**
  @internal
  */
  resolveNoCache(e) {
    return si.resolve(this, e);
  }
  /**
  Test whether a given mark or mark type occurs in this document
  between the two given positions.
  */
  rangeHasMark(e, t, r) {
    let i = !1;
    return t > e && this.nodesBetween(e, t, (s) => (r.isInSet(s.marks) && (i = !0), !i)), i;
  }
  /**
  True when this is a block (non-inline node)
  */
  get isBlock() {
    return this.type.isBlock;
  }
  /**
  True when this is a textblock node, a block node with inline
  content.
  */
  get isTextblock() {
    return this.type.isTextblock;
  }
  /**
  True when this node allows inline content.
  */
  get inlineContent() {
    return this.type.inlineContent;
  }
  /**
  True when this is an inline node (a text node or a node that can
  appear among text).
  */
  get isInline() {
    return this.type.isInline;
  }
  /**
  True when this is a text node.
  */
  get isText() {
    return this.type.isText;
  }
  /**
  True when this is a leaf node.
  */
  get isLeaf() {
    return this.type.isLeaf;
  }
  /**
  True when this is an atom, i.e. when it does not have directly
  editable content. This is usually the same as `isLeaf`, but can
  be configured with the [`atom` property](https://prosemirror.net/docs/ref/#model.NodeSpec.atom)
  on a node's spec (typically used when the node is displayed as
  an uneditable [node view](https://prosemirror.net/docs/ref/#view.NodeView)).
  */
  get isAtom() {
    return this.type.isAtom;
  }
  /**
  Return a string representation of this node for debugging
  purposes.
  */
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let e = this.type.name;
    return this.content.size && (e += "(" + this.content.toStringInner() + ")"), uh(this.marks, e);
  }
  /**
  Get the content match in this node at the given index.
  */
  contentMatchAt(e) {
    let t = this.type.contentMatch.matchFragment(this.content, 0, e);
    if (!t)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return t;
  }
  /**
  Test whether replacing the range between `from` and `to` (by
  child index) with the given replacement fragment (which defaults
  to the empty fragment) would leave the node's content valid. You
  can optionally pass `start` and `end` indices into the
  replacement fragment.
  */
  canReplace(e, t, r = A.empty, i = 0, s = r.childCount) {
    let o = this.contentMatchAt(e).matchFragment(r, i, s), l = o && o.matchFragment(this.content, t);
    if (!l || !l.validEnd)
      return !1;
    for (let a = i; a < s; a++)
      if (!this.type.allowsMarks(r.child(a).marks))
        return !1;
    return !0;
  }
  /**
  Test whether replacing the range `from` to `to` (by index) with
  a node of the given type would leave the node's content valid.
  */
  canReplaceWith(e, t, r, i) {
    if (i && !this.type.allowsMarks(i))
      return !1;
    let s = this.contentMatchAt(e).matchType(r), o = s && s.matchFragment(this.content, t);
    return o ? o.validEnd : !1;
  }
  /**
  Test whether the given node's content could be appended to this
  node. If that node is empty, this will only return true if there
  is at least one node type that can appear in both nodes (to avoid
  merging completely incompatible nodes).
  */
  canAppend(e) {
    return e.content.size ? this.canReplace(this.childCount, this.childCount, e.content) : this.type.compatibleContent(e.type);
  }
  /**
  Check whether this node and its descendants conform to the
  schema, and raise an exception when they do not.
  */
  check() {
    this.type.checkContent(this.content), this.type.checkAttrs(this.attrs);
    let e = Z.none;
    for (let t = 0; t < this.marks.length; t++) {
      let r = this.marks[t];
      r.type.checkAttrs(r.attrs), e = r.addToSet(e);
    }
    if (!Z.sameSet(e, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((t) => t.type.name)}`);
    this.content.forEach((t) => t.check());
  }
  /**
  Return a JSON-serializeable representation of this node.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return this.content.size && (e.content = this.content.toJSON()), this.marks.length && (e.marks = this.marks.map((t) => t.toJSON())), e;
  }
  /**
  Deserialize a node from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Node.fromJSON");
    let r;
    if (t.marks) {
      if (!Array.isArray(t.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      r = t.marks.map(e.markFromJSON);
    }
    if (t.type == "text") {
      if (typeof t.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return e.text(t.text, r);
    }
    let i = A.fromJSON(e, t.content), s = e.nodeType(t.type).create(t.attrs, i, r);
    return s.type.checkAttrs(s.attrs), s;
  }
}
Dt.prototype.text = void 0;
class ks extends Dt {
  /**
  @internal
  */
  constructor(e, t, r, i) {
    if (super(e, t, null, i), !r)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = r;
  }
  toString() {
    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : uh(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(e, t) {
    return this.text.slice(e, t);
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(e) {
    return e == this.marks ? this : new ks(this.type, this.attrs, this.text, e);
  }
  withText(e) {
    return e == this.text ? this : new ks(this.type, this.attrs, e, this.marks);
  }
  cut(e = 0, t = this.text.length) {
    return e == 0 && t == this.text.length ? this : this.withText(this.text.slice(e, t));
  }
  eq(e) {
    return this.sameMarkup(e) && this.text == e.text;
  }
  toJSON() {
    let e = super.toJSON();
    return e.text = this.text, e;
  }
}
function uh(n, e) {
  for (let t = n.length - 1; t >= 0; t--)
    e = n[t].type.name + "(" + e + ")";
  return e;
}
class Bn {
  /**
  @internal
  */
  constructor(e) {
    this.validEnd = e, this.next = [], this.wrapCache = [];
  }
  /**
  @internal
  */
  static parse(e, t) {
    let r = new c1(e, t);
    if (r.next == null)
      return Bn.empty;
    let i = dh(r);
    r.next && r.err("Unexpected trailing text");
    let s = g1(m1(i));
    return _1(s, r), s;
  }
  /**
  Match a node type, returning a match after that node if
  successful.
  */
  matchType(e) {
    for (let t = 0; t < this.next.length; t++)
      if (this.next[t].type == e)
        return this.next[t].next;
    return null;
  }
  /**
  Try to match a fragment. Returns the resulting match when
  successful.
  */
  matchFragment(e, t = 0, r = e.childCount) {
    let i = this;
    for (let s = t; i && s < r; s++)
      i = i.matchType(e.child(s).type);
    return i;
  }
  /**
  @internal
  */
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  /**
  Get the first matching node type at this match position that can
  be generated.
  */
  get defaultType() {
    for (let e = 0; e < this.next.length; e++) {
      let { type: t } = this.next[e];
      if (!(t.isText || t.hasRequiredAttrs()))
        return t;
    }
    return null;
  }
  /**
  @internal
  */
  compatible(e) {
    for (let t = 0; t < this.next.length; t++)
      for (let r = 0; r < e.next.length; r++)
        if (this.next[t].type == e.next[r].type)
          return !0;
    return !1;
  }
  /**
  Try to match the given fragment, and if that fails, see if it can
  be made to match by inserting nodes in front of it. When
  successful, return a fragment of inserted nodes (which may be
  empty if nothing had to be inserted). When `toEnd` is true, only
  return a fragment if the resulting match goes to the end of the
  content expression.
  */
  fillBefore(e, t = !1, r = 0) {
    let i = [this];
    function s(o, l) {
      let a = o.matchFragment(e, r);
      if (a && (!t || a.validEnd))
        return A.from(l.map((c) => c.createAndFill()));
      for (let c = 0; c < o.next.length; c++) {
        let { type: u, next: d } = o.next[c];
        if (!(u.isText || u.hasRequiredAttrs()) && i.indexOf(d) == -1) {
          i.push(d);
          let f = s(d, l.concat(u));
          if (f)
            return f;
        }
      }
      return null;
    }
    return s(this, []);
  }
  /**
  Find a set of wrapping node types that would allow a node of the
  given type to appear at this position. The result may be empty
  (when it fits directly) and will be null when no such wrapping
  exists.
  */
  findWrapping(e) {
    for (let r = 0; r < this.wrapCache.length; r += 2)
      if (this.wrapCache[r] == e)
        return this.wrapCache[r + 1];
    let t = this.computeWrapping(e);
    return this.wrapCache.push(e, t), t;
  }
  /**
  @internal
  */
  computeWrapping(e) {
    let t = /* @__PURE__ */ Object.create(null), r = [{ match: this, type: null, via: null }];
    for (; r.length; ) {
      let i = r.shift(), s = i.match;
      if (s.matchType(e)) {
        let o = [];
        for (let l = i; l.type; l = l.via)
          o.push(l.type);
        return o.reverse();
      }
      for (let o = 0; o < s.next.length; o++) {
        let { type: l, next: a } = s.next[o];
        !l.isLeaf && !l.hasRequiredAttrs() && !(l.name in t) && (!i.type || a.validEnd) && (r.push({ match: l.contentMatch, type: l, via: i }), t[l.name] = !0);
      }
    }
    return null;
  }
  /**
  The number of outgoing edges this node has in the finite
  automaton that describes the content expression.
  */
  get edgeCount() {
    return this.next.length;
  }
  /**
  Get the _n_​th outgoing edge from this node in the finite
  automaton that describes the content expression.
  */
  edge(e) {
    if (e >= this.next.length)
      throw new RangeError(`There's no ${e}th edge in this content match`);
    return this.next[e];
  }
  /**
  @internal
  */
  toString() {
    let e = [];
    function t(r) {
      e.push(r);
      for (let i = 0; i < r.next.length; i++)
        e.indexOf(r.next[i].next) == -1 && t(r.next[i].next);
    }
    return t(this), e.map((r, i) => {
      let s = i + (r.validEnd ? "*" : " ") + " ";
      for (let o = 0; o < r.next.length; o++)
        s += (o ? ", " : "") + r.next[o].type.name + "->" + e.indexOf(r.next[o].next);
      return s;
    }).join(`
`);
  }
}
Bn.empty = new Bn(!0);
class c1 {
  constructor(e, t) {
    this.string = e, this.nodeTypes = t, this.inline = null, this.pos = 0, this.tokens = e.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(e) {
    return this.next == e && (this.pos++ || !0);
  }
  err(e) {
    throw new SyntaxError(e + " (in content expression '" + this.string + "')");
  }
}
function dh(n) {
  let e = [];
  do
    e.push(u1(n));
  while (n.eat("|"));
  return e.length == 1 ? e[0] : { type: "choice", exprs: e };
}
function u1(n) {
  let e = [];
  do
    e.push(d1(n));
  while (n.next && n.next != ")" && n.next != "|");
  return e.length == 1 ? e[0] : { type: "seq", exprs: e };
}
function d1(n) {
  let e = p1(n);
  for (; ; )
    if (n.eat("+"))
      e = { type: "plus", expr: e };
    else if (n.eat("*"))
      e = { type: "star", expr: e };
    else if (n.eat("?"))
      e = { type: "opt", expr: e };
    else if (n.eat("{"))
      e = f1(n, e);
    else
      break;
  return e;
}
function $u(n) {
  /\D/.test(n.next) && n.err("Expected number, got '" + n.next + "'");
  let e = Number(n.next);
  return n.pos++, e;
}
function f1(n, e) {
  let t = $u(n), r = t;
  return n.eat(",") && (n.next != "}" ? r = $u(n) : r = -1), n.eat("}") || n.err("Unclosed braced range"), { type: "range", min: t, max: r, expr: e };
}
function h1(n, e) {
  let t = n.nodeTypes, r = t[e];
  if (r)
    return [r];
  let i = [];
  for (let s in t) {
    let o = t[s];
    o.isInGroup(e) && i.push(o);
  }
  return i.length == 0 && n.err("No node type or group '" + e + "' found"), i;
}
function p1(n) {
  if (n.eat("(")) {
    let e = dh(n);
    return n.eat(")") || n.err("Missing closing paren"), e;
  } else if (/\W/.test(n.next))
    n.err("Unexpected token '" + n.next + "'");
  else {
    let e = h1(n, n.next).map((t) => (n.inline == null ? n.inline = t.isInline : n.inline != t.isInline && n.err("Mixing inline and block content"), { type: "name", value: t }));
    return n.pos++, e.length == 1 ? e[0] : { type: "choice", exprs: e };
  }
}
function m1(n) {
  let e = [[]];
  return i(s(n, 0), t()), e;
  function t() {
    return e.push([]) - 1;
  }
  function r(o, l, a) {
    let c = { term: a, to: l };
    return e[o].push(c), c;
  }
  function i(o, l) {
    o.forEach((a) => a.to = l);
  }
  function s(o, l) {
    if (o.type == "choice")
      return o.exprs.reduce((a, c) => a.concat(s(c, l)), []);
    if (o.type == "seq")
      for (let a = 0; ; a++) {
        let c = s(o.exprs[a], l);
        if (a == o.exprs.length - 1)
          return c;
        i(c, l = t());
      }
    else if (o.type == "star") {
      let a = t();
      return r(l, a), i(s(o.expr, a), a), [r(a)];
    } else if (o.type == "plus") {
      let a = t();
      return i(s(o.expr, l), a), i(s(o.expr, a), a), [r(a)];
    } else {
      if (o.type == "opt")
        return [r(l)].concat(s(o.expr, l));
      if (o.type == "range") {
        let a = l;
        for (let c = 0; c < o.min; c++) {
          let u = t();
          i(s(o.expr, a), u), a = u;
        }
        if (o.max == -1)
          i(s(o.expr, a), a);
        else
          for (let c = o.min; c < o.max; c++) {
            let u = t();
            r(a, u), i(s(o.expr, a), u), a = u;
          }
        return [r(a)];
      } else {
        if (o.type == "name")
          return [r(l, void 0, o.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function fh(n, e) {
  return e - n;
}
function Ou(n, e) {
  let t = [];
  return r(e), t.sort(fh);
  function r(i) {
    let s = n[i];
    if (s.length == 1 && !s[0].term)
      return r(s[0].to);
    t.push(i);
    for (let o = 0; o < s.length; o++) {
      let { term: l, to: a } = s[o];
      !l && t.indexOf(a) == -1 && r(a);
    }
  }
}
function g1(n) {
  let e = /* @__PURE__ */ Object.create(null);
  return t(Ou(n, 0));
  function t(r) {
    let i = [];
    r.forEach((o) => {
      n[o].forEach(({ term: l, to: a }) => {
        if (!l)
          return;
        let c;
        for (let u = 0; u < i.length; u++)
          i[u][0] == l && (c = i[u][1]);
        Ou(n, a).forEach((u) => {
          c || i.push([l, c = []]), c.indexOf(u) == -1 && c.push(u);
        });
      });
    });
    let s = e[r.join(",")] = new Bn(r.indexOf(n.length - 1) > -1);
    for (let o = 0; o < i.length; o++) {
      let l = i[o][1].sort(fh);
      s.next.push({ type: i[o][0], next: e[l.join(",")] || t(l) });
    }
    return s;
  }
}
function _1(n, e) {
  for (let t = 0, r = [n]; t < r.length; t++) {
    let i = r[t], s = !i.validEnd, o = [];
    for (let l = 0; l < i.next.length; l++) {
      let { type: a, next: c } = i.next[l];
      o.push(a.name), s && !(a.isText || a.hasRequiredAttrs()) && (s = !1), r.indexOf(c) == -1 && r.push(c);
    }
    s && e.err("Only non-generatable nodes (" + o.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function hh(n) {
  let e = /* @__PURE__ */ Object.create(null);
  for (let t in n) {
    let r = n[t];
    if (!r.hasDefault)
      return null;
    e[t] = r.default;
  }
  return e;
}
function ph(n, e) {
  let t = /* @__PURE__ */ Object.create(null);
  for (let r in n) {
    let i = e && e[r];
    if (i === void 0) {
      let s = n[r];
      if (s.hasDefault)
        i = s.default;
      else
        throw new RangeError("No value supplied for attribute " + r);
    }
    t[r] = i;
  }
  return t;
}
function mh(n, e, t, r) {
  for (let i in e)
    if (!(i in n))
      throw new RangeError(`Unsupported attribute ${i} for ${t} of type ${i}`);
  for (let i in n) {
    let s = n[i];
    s.validate && s.validate(e[i]);
  }
}
function gh(n, e) {
  let t = /* @__PURE__ */ Object.create(null);
  if (e)
    for (let r in e)
      t[r] = new b1(n, r, e[r]);
  return t;
}
let Nu = class _h {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.name = e, this.schema = t, this.spec = r, this.markSet = null, this.groups = r.group ? r.group.split(" ") : [], this.attrs = gh(e, r.attrs), this.defaultAttrs = hh(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(r.inline || e == "text"), this.isText = e == "text";
  }
  /**
  True if this is an inline type.
  */
  get isInline() {
    return !this.isBlock;
  }
  /**
  True if this is a textblock type, a block that contains inline
  content.
  */
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  /**
  True for node types that allow no content.
  */
  get isLeaf() {
    return this.contentMatch == Bn.empty;
  }
  /**
  True when this node is an atom, i.e. when it does not have
  directly editable content.
  */
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  /**
  Return true when this node type is part of the given
  [group](https://prosemirror.net/docs/ref/#model.NodeSpec.group).
  */
  isInGroup(e) {
    return this.groups.indexOf(e) > -1;
  }
  /**
  The node type's [whitespace](https://prosemirror.net/docs/ref/#model.NodeSpec.whitespace) option.
  */
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  /**
  Tells you whether this node type has any required attributes.
  */
  hasRequiredAttrs() {
    for (let e in this.attrs)
      if (this.attrs[e].isRequired)
        return !0;
    return !1;
  }
  /**
  Indicates whether this node allows some of the same content as
  the given node type.
  */
  compatibleContent(e) {
    return this == e || this.contentMatch.compatible(e.contentMatch);
  }
  /**
  @internal
  */
  computeAttrs(e) {
    return !e && this.defaultAttrs ? this.defaultAttrs : ph(this.attrs, e);
  }
  /**
  Create a `Node` of this type. The given attributes are
  checked and defaulted (you can pass `null` to use the type's
  defaults entirely, if no required attributes exist). `content`
  may be a `Fragment`, a node, an array of nodes, or
  `null`. Similarly `marks` may be `null` to default to the empty
  set of marks.
  */
  create(e = null, t, r) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new Dt(this, this.computeAttrs(e), A.from(t), Z.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but check the given content
  against the node type's content restrictions, and throw an error
  if it doesn't match.
  */
  createChecked(e = null, t, r) {
    return t = A.from(t), this.checkContent(t), new Dt(this, this.computeAttrs(e), t, Z.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but see if it is
  necessary to add nodes to the start or end of the given fragment
  to make it fit the node. If no fitting wrapping can be found,
  return null. Note that, due to the fact that required nodes can
  always be created, this will always succeed if you pass null or
  `Fragment.empty` as content.
  */
  createAndFill(e = null, t, r) {
    if (e = this.computeAttrs(e), t = A.from(t), t.size) {
      let o = this.contentMatch.fillBefore(t);
      if (!o)
        return null;
      t = o.append(t);
    }
    let i = this.contentMatch.matchFragment(t), s = i && i.fillBefore(A.empty, !0);
    return s ? new Dt(this, e, t.append(s), Z.setFrom(r)) : null;
  }
  /**
  Returns true if the given fragment is valid content for this node
  type.
  */
  validContent(e) {
    let t = this.contentMatch.matchFragment(e);
    if (!t || !t.validEnd)
      return !1;
    for (let r = 0; r < e.childCount; r++)
      if (!this.allowsMarks(e.child(r).marks))
        return !1;
    return !0;
  }
  /**
  Throws a RangeError if the given fragment is not valid content for this
  node type.
  @internal
  */
  checkContent(e) {
    if (!this.validContent(e))
      throw new RangeError(`Invalid content for node ${this.name}: ${e.toString().slice(0, 50)}`);
  }
  /**
  @internal
  */
  checkAttrs(e) {
    mh(this.attrs, e, "node", this.name);
  }
  /**
  Check whether the given mark type is allowed in this node.
  */
  allowsMarkType(e) {
    return this.markSet == null || this.markSet.indexOf(e) > -1;
  }
  /**
  Test whether the given set of marks are allowed in this node.
  */
  allowsMarks(e) {
    if (this.markSet == null)
      return !0;
    for (let t = 0; t < e.length; t++)
      if (!this.allowsMarkType(e[t].type))
        return !1;
    return !0;
  }
  /**
  Removes the marks that are not allowed in this node from the given set.
  */
  allowedMarks(e) {
    if (this.markSet == null)
      return e;
    let t;
    for (let r = 0; r < e.length; r++)
      this.allowsMarkType(e[r].type) ? t && t.push(e[r]) : t || (t = e.slice(0, r));
    return t ? t.length ? t : Z.none : e;
  }
  /**
  @internal
  */
  static compile(e, t) {
    let r = /* @__PURE__ */ Object.create(null);
    e.forEach((s, o) => r[s] = new _h(s, t, o));
    let i = t.spec.topNode || "doc";
    if (!r[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!r.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let s in r.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return r;
  }
};
function y1(n, e, t) {
  let r = t.split("|");
  return (i) => {
    let s = i === null ? "null" : typeof i;
    if (r.indexOf(s) < 0)
      throw new RangeError(`Expected value of type ${r} for attribute ${e} on type ${n}, got ${s}`);
  };
}
class b1 {
  constructor(e, t, r) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(r, "default"), this.default = r.default, this.validate = typeof r.validate == "string" ? y1(e, t, r.validate) : r.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class so {
  /**
  @internal
  */
  constructor(e, t, r, i) {
    this.name = e, this.rank = t, this.schema = r, this.spec = i, this.attrs = gh(e, i.attrs), this.excluded = null;
    let s = hh(this.attrs);
    this.instance = s ? new Z(this, s) : null;
  }
  /**
  Create a mark of this type. `attrs` may be `null` or an object
  containing only some of the mark's attributes. The others, if
  they have defaults, will be added.
  */
  create(e = null) {
    return !e && this.instance ? this.instance : new Z(this, ph(this.attrs, e));
  }
  /**
  @internal
  */
  static compile(e, t) {
    let r = /* @__PURE__ */ Object.create(null), i = 0;
    return e.forEach((s, o) => r[s] = new so(s, i++, t, o)), r;
  }
  /**
  When there is a mark of this type in the given set, a new set
  without it is returned. Otherwise, the input set is returned.
  */
  removeFromSet(e) {
    for (var t = 0; t < e.length; t++)
      e[t].type == this && (e = e.slice(0, t).concat(e.slice(t + 1)), t--);
    return e;
  }
  /**
  Tests whether there is a mark of this type in the given set.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (e[t].type == this)
        return e[t];
  }
  /**
  @internal
  */
  checkAttrs(e) {
    mh(this.attrs, e, "mark", this.name);
  }
  /**
  Queries whether a given mark type is
  [excluded](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) by this one.
  */
  excludes(e) {
    return this.excluded.indexOf(e) > -1;
  }
}
class yh {
  /**
  Construct a schema from a schema [specification](https://prosemirror.net/docs/ref/#model.SchemaSpec).
  */
  constructor(e) {
    this.linebreakReplacement = null, this.cached = /* @__PURE__ */ Object.create(null);
    let t = this.spec = {};
    for (let i in e)
      t[i] = e[i];
    t.nodes = Ae.from(e.nodes), t.marks = Ae.from(e.marks || {}), this.nodes = Nu.compile(this.spec.nodes, this), this.marks = so.compile(this.spec.marks, this);
    let r = /* @__PURE__ */ Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let s = this.nodes[i], o = s.spec.content || "", l = s.spec.marks;
      if (s.contentMatch = r[o] || (r[o] = Bn.parse(o, this.nodes)), s.inlineContent = s.contentMatch.inlineContent, s.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!s.isInline || !s.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = s;
      }
      s.markSet = l == "_" ? null : l ? Iu(this, l.split(" ")) : l == "" || !s.inlineContent ? [] : null;
    }
    for (let i in this.marks) {
      let s = this.marks[i], o = s.spec.excludes;
      s.excluded = o == null ? [s] : o == "" ? [] : Iu(this, o.split(" "));
    }
    this.nodeFromJSON = (i) => Dt.fromJSON(this, i), this.markFromJSON = (i) => Z.fromJSON(this, i), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = /* @__PURE__ */ Object.create(null);
  }
  /**
  Create a node in this schema. The `type` may be a string or a
  `NodeType` instance. Attributes will be extended with defaults,
  `content` may be a `Fragment`, `null`, a `Node`, or an array of
  nodes.
  */
  node(e, t = null, r, i) {
    if (typeof e == "string")
      e = this.nodeType(e);
    else if (e instanceof Nu) {
      if (e.schema != this)
        throw new RangeError("Node type from different schema used (" + e.name + ")");
    } else throw new RangeError("Invalid node type: " + e);
    return e.createChecked(t, r, i);
  }
  /**
  Create a text node in the schema. Empty text nodes are not
  allowed.
  */
  text(e, t) {
    let r = this.nodes.text;
    return new ks(r, r.defaultAttrs, e, Z.setFrom(t));
  }
  /**
  Create a mark with the given type and attributes.
  */
  mark(e, t) {
    return typeof e == "string" && (e = this.marks[e]), e.create(t);
  }
  /**
  @internal
  */
  nodeType(e) {
    let t = this.nodes[e];
    if (!t)
      throw new RangeError("Unknown node type: " + e);
    return t;
  }
}
function Iu(n, e) {
  let t = [];
  for (let r = 0; r < e.length; r++) {
    let i = e[r], s = n.marks[i], o = s;
    if (s)
      t.push(s);
    else
      for (let l in n.marks) {
        let a = n.marks[l];
        (i == "_" || a.spec.group && a.spec.group.split(" ").indexOf(i) > -1) && t.push(o = a);
      }
    if (!o)
      throw new SyntaxError("Unknown mark type: '" + e[r] + "'");
  }
  return t;
}
function k1(n) {
  return n.tag != null;
}
function w1(n) {
  return n.style != null;
}
let Kr = class Ol {
  /**
  Create a parser that targets the given schema, using the given
  parsing rules.
  */
  constructor(e, t) {
    this.schema = e, this.rules = t, this.tags = [], this.styles = [];
    let r = this.matchedStyles = [];
    t.forEach((i) => {
      if (k1(i))
        this.tags.push(i);
      else if (w1(i)) {
        let s = /[^=]*/.exec(i.style)[0];
        r.indexOf(s) < 0 && r.push(s), this.styles.push(i);
      }
    }), this.normalizeLists = !this.tags.some((i) => {
      if (!/^(ul|ol)\b/.test(i.tag) || !i.node)
        return !1;
      let s = e.nodes[i.node];
      return s.contentMatch.matchType(s);
    });
  }
  /**
  Parse a document from the content of a DOM node.
  */
  parse(e, t = {}) {
    let r = new Lu(this, t, !1);
    return r.addAll(e, Z.none, t.from, t.to), r.finish();
  }
  /**
  Parses the content of the given DOM node, like
  [`parse`](https://prosemirror.net/docs/ref/#model.DOMParser.parse), and takes the same set of
  options. But unlike that method, which produces a whole node,
  this one returns a slice that is open at the sides, meaning that
  the schema constraints aren't applied to the start of nodes to
  the left of the input and the end of nodes at the end.
  */
  parseSlice(e, t = {}) {
    let r = new Lu(this, t, !0);
    return r.addAll(e, Z.none, t.from, t.to), O.maxOpen(r.finish());
  }
  /**
  @internal
  */
  matchTag(e, t, r) {
    for (let i = r ? this.tags.indexOf(r) + 1 : 0; i < this.tags.length; i++) {
      let s = this.tags[i];
      if (D1(e, s.tag) && (s.namespace === void 0 || e.namespaceURI == s.namespace) && (!s.context || t.matchesContext(s.context))) {
        if (s.getAttrs) {
          let o = s.getAttrs(e);
          if (o === !1)
            continue;
          s.attrs = o || void 0;
        }
        return s;
      }
    }
  }
  /**
  @internal
  */
  matchStyle(e, t, r, i) {
    for (let s = i ? this.styles.indexOf(i) + 1 : 0; s < this.styles.length; s++) {
      let o = this.styles[s], l = o.style;
      if (!(l.indexOf(e) != 0 || o.context && !r.matchesContext(o.context) || // Test that the style string either precisely matches the prop,
      // or has an '=' sign after the prop, followed by the given
      // value.
      l.length > e.length && (l.charCodeAt(e.length) != 61 || l.slice(e.length + 1) != t))) {
        if (o.getAttrs) {
          let a = o.getAttrs(t);
          if (a === !1)
            continue;
          o.attrs = a || void 0;
        }
        return o;
      }
    }
  }
  /**
  @internal
  */
  static schemaRules(e) {
    let t = [];
    function r(i) {
      let s = i.priority == null ? 50 : i.priority, o = 0;
      for (; o < t.length; o++) {
        let l = t[o];
        if ((l.priority == null ? 50 : l.priority) < s)
          break;
      }
      t.splice(o, 0, i);
    }
    for (let i in e.marks) {
      let s = e.marks[i].spec.parseDOM;
      s && s.forEach((o) => {
        r(o = Pu(o)), o.mark || o.ignore || o.clearMark || (o.mark = i);
      });
    }
    for (let i in e.nodes) {
      let s = e.nodes[i].spec.parseDOM;
      s && s.forEach((o) => {
        r(o = Pu(o)), o.node || o.ignore || o.mark || (o.node = i);
      });
    }
    return t;
  }
  /**
  Construct a DOM parser using the parsing rules listed in a
  schema's [node specs](https://prosemirror.net/docs/ref/#model.NodeSpec.parseDOM), reordered by
  [priority](https://prosemirror.net/docs/ref/#model.GenericParseRule.priority).
  */
  static fromSchema(e) {
    return e.cached.domParser || (e.cached.domParser = new Ol(e, Ol.schemaRules(e)));
  }
};
const bh = {
  address: !0,
  article: !0,
  aside: !0,
  blockquote: !0,
  canvas: !0,
  dd: !0,
  div: !0,
  dl: !0,
  fieldset: !0,
  figcaption: !0,
  figure: !0,
  footer: !0,
  form: !0,
  h1: !0,
  h2: !0,
  h3: !0,
  h4: !0,
  h5: !0,
  h6: !0,
  header: !0,
  hgroup: !0,
  hr: !0,
  li: !0,
  noscript: !0,
  ol: !0,
  output: !0,
  p: !0,
  pre: !0,
  section: !0,
  table: !0,
  tfoot: !0,
  ul: !0
}, v1 = {
  head: !0,
  noscript: !0,
  object: !0,
  script: !0,
  style: !0,
  title: !0
}, kh = { ol: !0, ul: !0 }, oi = 1, Nl = 2, Gr = 4;
function Ru(n, e, t) {
  return e != null ? (e ? oi : 0) | (e === "full" ? Nl : 0) : n && n.whitespace == "pre" ? oi | Nl : t & ~Gr;
}
class Ui {
  constructor(e, t, r, i, s, o) {
    this.type = e, this.attrs = t, this.marks = r, this.solid = i, this.options = o, this.content = [], this.activeMarks = Z.none, this.match = s || (o & Gr ? null : e.contentMatch);
  }
  findWrapping(e) {
    if (!this.match) {
      if (!this.type)
        return [];
      let t = this.type.contentMatch.fillBefore(A.from(e));
      if (t)
        this.match = this.type.contentMatch.matchFragment(t);
      else {
        let r = this.type.contentMatch, i;
        return (i = r.findWrapping(e.type)) ? (this.match = r, i) : null;
      }
    }
    return this.match.findWrapping(e.type);
  }
  finish(e) {
    if (!(this.options & oi)) {
      let r = this.content[this.content.length - 1], i;
      if (r && r.isText && (i = /[ \t\r\n\u000c]+$/.exec(r.text))) {
        let s = r;
        r.text.length == i[0].length ? this.content.pop() : this.content[this.content.length - 1] = s.withText(s.text.slice(0, s.text.length - i[0].length));
      }
    }
    let t = A.from(this.content);
    return !e && this.match && (t = t.append(this.match.fillBefore(A.empty, !0))), this.type ? this.type.create(this.attrs, t, this.marks) : t;
  }
  inlineContext(e) {
    return this.type ? this.type.inlineContent : this.content.length ? this.content[0].isInline : e.parentNode && !bh.hasOwnProperty(e.parentNode.nodeName.toLowerCase());
  }
}
class Lu {
  constructor(e, t, r) {
    this.parser = e, this.options = t, this.isOpen = r, this.open = 0, this.localPreserveWS = !1;
    let i = t.topNode, s, o = Ru(null, t.preserveWhitespace, 0) | (r ? Gr : 0);
    i ? s = new Ui(i.type, i.attrs, Z.none, !0, t.topMatch || i.type.contentMatch, o) : r ? s = new Ui(null, null, Z.none, !0, null, o) : s = new Ui(e.schema.topNodeType, null, Z.none, !0, null, o), this.nodes = [s], this.find = t.findPositions, this.needsBlock = !1;
  }
  get top() {
    return this.nodes[this.open];
  }
  // Add a DOM node to the content. Text is inserted as text node,
  // otherwise, the node is passed to `addElement` or, if it has a
  // `style` attribute, `addElementWithStyles`.
  addDOM(e, t) {
    e.nodeType == 3 ? this.addTextNode(e, t) : e.nodeType == 1 && this.addElement(e, t);
  }
  addTextNode(e, t) {
    let r = e.nodeValue, i = this.top, s = i.options & Nl ? "full" : this.localPreserveWS || (i.options & oi) > 0;
    if (s === "full" || i.inlineContext(e) || /[^ \t\r\n\u000c]/.test(r)) {
      if (s)
        s !== "full" ? r = r.replace(/\r?\n|\r/g, " ") : r = r.replace(/\r\n?/g, `
`);
      else if (r = r.replace(/[ \t\r\n\u000c]+/g, " "), /^[ \t\r\n\u000c]/.test(r) && this.open == this.nodes.length - 1) {
        let o = i.content[i.content.length - 1], l = e.previousSibling;
        (!o || l && l.nodeName == "BR" || o.isText && /[ \t\r\n\u000c]$/.test(o.text)) && (r = r.slice(1));
      }
      r && this.insertNode(this.parser.schema.text(r), t, !/\S/.test(r)), this.findInText(e);
    } else
      this.findInside(e);
  }
  // Try to find a handler for the given tag and use that to parse. If
  // none is found, the element's content nodes are added directly.
  addElement(e, t, r) {
    let i = this.localPreserveWS, s = this.top;
    (e.tagName == "PRE" || /pre/.test(e.style && e.style.whiteSpace)) && (this.localPreserveWS = !0);
    let o = e.nodeName.toLowerCase(), l;
    kh.hasOwnProperty(o) && this.parser.normalizeLists && E1(e);
    let a = this.options.ruleFromNode && this.options.ruleFromNode(e) || (l = this.parser.matchTag(e, this, r));
    e: if (a ? a.ignore : v1.hasOwnProperty(o))
      this.findInside(e), this.ignoreFallback(e, t);
    else if (!a || a.skip || a.closeParent) {
      a && a.closeParent ? this.open = Math.max(0, this.open - 1) : a && a.skip.nodeType && (e = a.skip);
      let c, u = this.needsBlock;
      if (bh.hasOwnProperty(o))
        s.content.length && s.content[0].isInline && this.open && (this.open--, s = this.top), c = !0, s.type || (this.needsBlock = !0);
      else if (!e.firstChild) {
        this.leafFallback(e, t);
        break e;
      }
      let d = a && a.skip ? t : this.readStyles(e, t);
      d && this.addAll(e, d), c && this.sync(s), this.needsBlock = u;
    } else {
      let c = this.readStyles(e, t);
      c && this.addElementByRule(e, a, c, a.consuming === !1 ? l : void 0);
    }
    this.localPreserveWS = i;
  }
  // Called for leaf DOM nodes that would otherwise be ignored
  leafFallback(e, t) {
    e.nodeName == "BR" && this.top.type && this.top.type.inlineContent && this.addTextNode(e.ownerDocument.createTextNode(`
`), t);
  }
  // Called for ignored nodes
  ignoreFallback(e, t) {
    e.nodeName == "BR" && (!this.top.type || !this.top.type.inlineContent) && this.findPlace(this.parser.schema.text("-"), t, !0);
  }
  // Run any style parser associated with the node's styles. Either
  // return an updated array of marks, or null to indicate some of the
  // styles had a rule with `ignore` set.
  readStyles(e, t) {
    let r = e.style;
    if (r && r.length)
      for (let i = 0; i < this.parser.matchedStyles.length; i++) {
        let s = this.parser.matchedStyles[i], o = r.getPropertyValue(s);
        if (o)
          for (let l = void 0; ; ) {
            let a = this.parser.matchStyle(s, o, this, l);
            if (!a)
              break;
            if (a.ignore)
              return null;
            if (a.clearMark ? t = t.filter((c) => !a.clearMark(c)) : t = t.concat(this.parser.schema.marks[a.mark].create(a.attrs)), a.consuming === !1)
              l = a;
            else
              break;
          }
      }
    return t;
  }
  // Look up a handler for the given node. If none are found, return
  // false. Otherwise, apply it, use its return value to drive the way
  // the node's content is wrapped, and return true.
  addElementByRule(e, t, r, i) {
    let s, o;
    if (t.node)
      if (o = this.parser.schema.nodes[t.node], o.isLeaf)
        this.insertNode(o.create(t.attrs), r, e.nodeName == "BR") || this.leafFallback(e, r);
      else {
        let a = this.enter(o, t.attrs || null, r, t.preserveWhitespace);
        a && (s = !0, r = a);
      }
    else {
      let a = this.parser.schema.marks[t.mark];
      r = r.concat(a.create(t.attrs));
    }
    let l = this.top;
    if (o && o.isLeaf)
      this.findInside(e);
    else if (i)
      this.addElement(e, r, i);
    else if (t.getContent)
      this.findInside(e), t.getContent(e, this.parser.schema).forEach((a) => this.insertNode(a, r, !1));
    else {
      let a = e;
      typeof t.contentElement == "string" ? a = e.querySelector(t.contentElement) : typeof t.contentElement == "function" ? a = t.contentElement(e) : t.contentElement && (a = t.contentElement), this.findAround(e, a, !0), this.addAll(a, r), this.findAround(e, a, !1);
    }
    s && this.sync(l) && this.open--;
  }
  // Add all child nodes between `startIndex` and `endIndex` (or the
  // whole node, if not given). If `sync` is passed, use it to
  // synchronize after every block element.
  addAll(e, t, r, i) {
    let s = r || 0;
    for (let o = r ? e.childNodes[r] : e.firstChild, l = i == null ? null : e.childNodes[i]; o != l; o = o.nextSibling, ++s)
      this.findAtPoint(e, s), this.addDOM(o, t);
    this.findAtPoint(e, s);
  }
  // Try to find a way to fit the given node type into the current
  // context. May add intermediate wrappers and/or leave non-solid
  // nodes that we're in.
  findPlace(e, t, r) {
    let i, s;
    for (let o = this.open, l = 0; o >= 0; o--) {
      let a = this.nodes[o], c = a.findWrapping(e);
      if (c && (!i || i.length > c.length + l) && (i = c, s = a, !c.length))
        break;
      if (a.solid) {
        if (r)
          break;
        l += 2;
      }
    }
    if (!i)
      return null;
    this.sync(s);
    for (let o = 0; o < i.length; o++)
      t = this.enterInner(i[o], null, t, !1);
    return t;
  }
  // Try to insert the given node, adjusting the context when needed.
  insertNode(e, t, r) {
    if (e.isInline && this.needsBlock && !this.top.type) {
      let s = this.textblockFromContext();
      s && (t = this.enterInner(s, null, t));
    }
    let i = this.findPlace(e, t, r);
    if (i) {
      this.closeExtra();
      let s = this.top;
      s.match && (s.match = s.match.matchType(e.type));
      let o = Z.none;
      for (let l of i.concat(e.marks))
        (s.type ? s.type.allowsMarkType(l.type) : Bu(l.type, e.type)) && (o = l.addToSet(o));
      return s.content.push(e.mark(o)), !0;
    }
    return !1;
  }
  // Try to start a node of the given type, adjusting the context when
  // necessary.
  enter(e, t, r, i) {
    let s = this.findPlace(e.create(t), r, !1);
    return s && (s = this.enterInner(e, t, r, !0, i)), s;
  }
  // Open a node of the given type
  enterInner(e, t, r, i = !1, s) {
    this.closeExtra();
    let o = this.top;
    o.match = o.match && o.match.matchType(e);
    let l = Ru(e, s, o.options);
    o.options & Gr && o.content.length == 0 && (l |= Gr);
    let a = Z.none;
    return r = r.filter((c) => (o.type ? o.type.allowsMarkType(c.type) : Bu(c.type, e)) ? (a = c.addToSet(a), !1) : !0), this.nodes.push(new Ui(e, t, a, i, null, l)), this.open++, r;
  }
  // Make sure all nodes above this.open are finished and added to
  // their parents
  closeExtra(e = !1) {
    let t = this.nodes.length - 1;
    if (t > this.open) {
      for (; t > this.open; t--)
        this.nodes[t - 1].content.push(this.nodes[t].finish(e));
      this.nodes.length = this.open + 1;
    }
  }
  finish() {
    return this.open = 0, this.closeExtra(this.isOpen), this.nodes[0].finish(!!(this.isOpen || this.options.topOpen));
  }
  sync(e) {
    for (let t = this.open; t >= 0; t--) {
      if (this.nodes[t] == e)
        return this.open = t, !0;
      this.localPreserveWS && (this.nodes[t].options |= oi);
    }
    return !1;
  }
  get currentPos() {
    this.closeExtra();
    let e = 0;
    for (let t = this.open; t >= 0; t--) {
      let r = this.nodes[t].content;
      for (let i = r.length - 1; i >= 0; i--)
        e += r[i].nodeSize;
      t && e++;
    }
    return e;
  }
  findAtPoint(e, t) {
    if (this.find)
      for (let r = 0; r < this.find.length; r++)
        this.find[r].node == e && this.find[r].offset == t && (this.find[r].pos = this.currentPos);
  }
  findInside(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].pos == null && e.nodeType == 1 && e.contains(this.find[t].node) && (this.find[t].pos = this.currentPos);
  }
  findAround(e, t, r) {
    if (e != t && this.find)
      for (let i = 0; i < this.find.length; i++)
        this.find[i].pos == null && e.nodeType == 1 && e.contains(this.find[i].node) && t.compareDocumentPosition(this.find[i].node) & (r ? 2 : 4) && (this.find[i].pos = this.currentPos);
  }
  findInText(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].node == e && (this.find[t].pos = this.currentPos - (e.nodeValue.length - this.find[t].offset));
  }
  // Determines whether the given context string matches this context.
  matchesContext(e) {
    if (e.indexOf("|") > -1)
      return e.split(/\s*\|\s*/).some(this.matchesContext, this);
    let t = e.split("/"), r = this.options.context, i = !this.isOpen && (!r || r.parent.type == this.nodes[0].type), s = -(r ? r.depth + 1 : 0) + (i ? 0 : 1), o = (l, a) => {
      for (; l >= 0; l--) {
        let c = t[l];
        if (c == "") {
          if (l == t.length - 1 || l == 0)
            continue;
          for (; a >= s; a--)
            if (o(l - 1, a))
              return !0;
          return !1;
        } else {
          let u = a > 0 || a == 0 && i ? this.nodes[a].type : r && a >= s ? r.node(a - s).type : null;
          if (!u || u.name != c && !u.isInGroup(c))
            return !1;
          a--;
        }
      }
      return !0;
    };
    return o(t.length - 1, this.open);
  }
  textblockFromContext() {
    let e = this.options.context;
    if (e)
      for (let t = e.depth; t >= 0; t--) {
        let r = e.node(t).contentMatchAt(e.indexAfter(t)).defaultType;
        if (r && r.isTextblock && r.defaultAttrs)
          return r;
      }
    for (let t in this.parser.schema.nodes) {
      let r = this.parser.schema.nodes[t];
      if (r.isTextblock && r.defaultAttrs)
        return r;
    }
  }
}
function E1(n) {
  for (let e = n.firstChild, t = null; e; e = e.nextSibling) {
    let r = e.nodeType == 1 ? e.nodeName.toLowerCase() : null;
    r && kh.hasOwnProperty(r) && t ? (t.appendChild(e), e = t) : r == "li" ? t = e : r && (t = null);
  }
}
function D1(n, e) {
  return (n.matches || n.msMatchesSelector || n.webkitMatchesSelector || n.mozMatchesSelector).call(n, e);
}
function Pu(n) {
  let e = {};
  for (let t in n)
    e[t] = n[t];
  return e;
}
function Bu(n, e) {
  let t = e.schema.nodes;
  for (let r in t) {
    let i = t[r];
    if (!i.allowsMarkType(n))
      continue;
    let s = [], o = (l) => {
      s.push(l);
      for (let a = 0; a < l.edgeCount; a++) {
        let { type: c, next: u } = l.edge(a);
        if (c == e || s.indexOf(u) < 0 && o(u))
          return !0;
      }
    };
    if (o(i.contentMatch))
      return !0;
  }
}
class Wn {
  /**
  Create a serializer. `nodes` should map node names to functions
  that take a node and return a description of the corresponding
  DOM. `marks` does the same for mark names, but also gets an
  argument that tells it whether the mark's content is block or
  inline content (for typical use, it'll always be inline). A mark
  serializer may be `null` to indicate that marks of that type
  should not be serialized.
  */
  constructor(e, t) {
    this.nodes = e, this.marks = t;
  }
  /**
  Serialize the content of this fragment to a DOM fragment. When
  not in the browser, the `document` option, containing a DOM
  document, should be passed so that the serializer can create
  nodes.
  */
  serializeFragment(e, t = {}, r) {
    r || (r = Ko(t).createDocumentFragment());
    let i = r, s = [];
    return e.forEach((o) => {
      if (s.length || o.marks.length) {
        let l = 0, a = 0;
        for (; l < s.length && a < o.marks.length; ) {
          let c = o.marks[a];
          if (!this.marks[c.type.name]) {
            a++;
            continue;
          }
          if (!c.eq(s[l][0]) || c.type.spec.spanning === !1)
            break;
          l++, a++;
        }
        for (; l < s.length; )
          i = s.pop()[1];
        for (; a < o.marks.length; ) {
          let c = o.marks[a++], u = this.serializeMark(c, o.isInline, t);
          u && (s.push([c, i]), i.appendChild(u.dom), i = u.contentDOM || u.dom);
        }
      }
      i.appendChild(this.serializeNodeInner(o, t));
    }), r;
  }
  /**
  @internal
  */
  serializeNodeInner(e, t) {
    let { dom: r, contentDOM: i } = ls(Ko(t), this.nodes[e.type.name](e), null, e.attrs);
    if (i) {
      if (e.isLeaf)
        throw new RangeError("Content hole not allowed in a leaf node spec");
      this.serializeFragment(e.content, t, i);
    }
    return r;
  }
  /**
  Serialize this node to a DOM node. This can be useful when you
  need to serialize a part of a document, as opposed to the whole
  document. To serialize a whole document, use
  [`serializeFragment`](https://prosemirror.net/docs/ref/#model.DOMSerializer.serializeFragment) on
  its [content](https://prosemirror.net/docs/ref/#model.Node.content).
  */
  serializeNode(e, t = {}) {
    let r = this.serializeNodeInner(e, t);
    for (let i = e.marks.length - 1; i >= 0; i--) {
      let s = this.serializeMark(e.marks[i], e.isInline, t);
      s && ((s.contentDOM || s.dom).appendChild(r), r = s.dom);
    }
    return r;
  }
  /**
  @internal
  */
  serializeMark(e, t, r = {}) {
    let i = this.marks[e.type.name];
    return i && ls(Ko(r), i(e, t), null, e.attrs);
  }
  static renderSpec(e, t, r = null, i) {
    return ls(e, t, r, i);
  }
  /**
  Build a serializer using the [`toDOM`](https://prosemirror.net/docs/ref/#model.NodeSpec.toDOM)
  properties in a schema's node and mark specs.
  */
  static fromSchema(e) {
    return e.cached.domSerializer || (e.cached.domSerializer = new Wn(this.nodesFromSchema(e), this.marksFromSchema(e)));
  }
  /**
  Gather the serializers in a schema's node specs into an object.
  This can be useful as a base to build a custom serializer from.
  */
  static nodesFromSchema(e) {
    let t = zu(e.nodes);
    return t.text || (t.text = (r) => r.text), t;
  }
  /**
  Gather the serializers in a schema's mark specs into an object.
  */
  static marksFromSchema(e) {
    return zu(e.marks);
  }
}
function zu(n) {
  let e = {};
  for (let t in n) {
    let r = n[t].spec.toDOM;
    r && (e[t] = r);
  }
  return e;
}
function Ko(n) {
  return n.document || window.document;
}
const Hu = /* @__PURE__ */ new WeakMap();
function S1(n) {
  let e = Hu.get(n);
  return e === void 0 && Hu.set(n, e = C1(n)), e;
}
function C1(n) {
  let e = null;
  function t(r) {
    if (r && typeof r == "object")
      if (Array.isArray(r))
        if (typeof r[0] == "string")
          e || (e = []), e.push(r);
        else
          for (let i = 0; i < r.length; i++)
            t(r[i]);
      else
        for (let i in r)
          t(r[i]);
  }
  return t(n), e;
}
function ls(n, e, t, r) {
  if (typeof e == "string")
    return { dom: n.createTextNode(e) };
  if (e.nodeType != null)
    return { dom: e };
  if (e.dom && e.dom.nodeType != null)
    return e;
  let i = e[0], s;
  if (typeof i != "string")
    throw new RangeError("Invalid array passed to renderSpec");
  if (r && (s = S1(r)) && s.indexOf(e) > -1)
    throw new RangeError("Using an array from an attribute object as a DOM spec. This may be an attempted cross site scripting attack.");
  let o = i.indexOf(" ");
  o > 0 && (t = i.slice(0, o), i = i.slice(o + 1));
  let l, a = t ? n.createElementNS(t, i) : n.createElement(i), c = e[1], u = 1;
  if (c && typeof c == "object" && c.nodeType == null && !Array.isArray(c)) {
    u = 2;
    for (let d in c)
      if (c[d] != null) {
        let f = d.indexOf(" ");
        f > 0 ? a.setAttributeNS(d.slice(0, f), d.slice(f + 1), c[d]) : d == "style" && a.style ? a.style.cssText = c[d] : a.setAttribute(d, c[d]);
      }
  }
  for (let d = u; d < e.length; d++) {
    let f = e[d];
    if (f === 0) {
      if (d < e.length - 1 || d > u)
        throw new RangeError("Content hole must be the only child of its parent node");
      return { dom: a, contentDOM: a };
    } else {
      let { dom: h, contentDOM: p } = ls(n, f, t, r);
      if (a.appendChild(h), p) {
        if (l)
          throw new RangeError("Multiple content holes");
        l = p;
      }
    }
  }
  return { dom: a, contentDOM: l };
}
const wh = 65535, vh = Math.pow(2, 16);
function A1(n, e) {
  return n + e * vh;
}
function qu(n) {
  return n & wh;
}
function x1(n) {
  return (n - (n & wh)) / vh;
}
const Eh = 1, Dh = 2, as = 4, Sh = 8;
class Il {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.pos = e, this.delInfo = t, this.recover = r;
  }
  /**
  Tells you whether the position was deleted, that is, whether the
  step removed the token on the side queried (via the `assoc`)
  argument from the document.
  */
  get deleted() {
    return (this.delInfo & Sh) > 0;
  }
  /**
  Tells you whether the token before the mapped position was deleted.
  */
  get deletedBefore() {
    return (this.delInfo & (Eh | as)) > 0;
  }
  /**
  True when the token after the mapped position was deleted.
  */
  get deletedAfter() {
    return (this.delInfo & (Dh | as)) > 0;
  }
  /**
  Tells whether any of the steps mapped through deletes across the
  position (including both the token before and after the
  position).
  */
  get deletedAcross() {
    return (this.delInfo & as) > 0;
  }
}
class Ze {
  /**
  Create a position map. The modifications to the document are
  represented as an array of numbers, in which each group of three
  represents a modified chunk as `[start, oldSize, newSize]`.
  */
  constructor(e, t = !1) {
    if (this.ranges = e, this.inverted = t, !e.length && Ze.empty)
      return Ze.empty;
  }
  /**
  @internal
  */
  recover(e) {
    let t = 0, r = qu(e);
    if (!this.inverted)
      for (let i = 0; i < r; i++)
        t += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[r * 3] + t + x1(e);
  }
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  map(e, t = 1) {
    return this._map(e, t, !0);
  }
  /**
  @internal
  */
  _map(e, t, r) {
    let i = 0, s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? i : 0);
      if (a > e)
        break;
      let c = this.ranges[l + s], u = this.ranges[l + o], d = a + c;
      if (e <= d) {
        let f = c ? e == a ? -1 : e == d ? 1 : t : t, h = a + i + (f < 0 ? 0 : u);
        if (r)
          return h;
        let p = e == (t < 0 ? a : d) ? null : A1(l / 3, e - a), m = e == a ? Dh : e == d ? Eh : as;
        return (t < 0 ? e != a : e != d) && (m |= Sh), new Il(h, m, p);
      }
      i += u - c;
    }
    return r ? e + i : new Il(e + i, 0, null);
  }
  /**
  @internal
  */
  touches(e, t) {
    let r = 0, i = qu(t), s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? r : 0);
      if (a > e)
        break;
      let c = this.ranges[l + s], u = a + c;
      if (e <= u && l == i * 3)
        return !0;
      r += this.ranges[l + o] - c;
    }
    return !1;
  }
  /**
  Calls the given function on each of the changed ranges included in
  this map.
  */
  forEach(e) {
    let t = this.inverted ? 2 : 1, r = this.inverted ? 1 : 2;
    for (let i = 0, s = 0; i < this.ranges.length; i += 3) {
      let o = this.ranges[i], l = o - (this.inverted ? s : 0), a = o + (this.inverted ? 0 : s), c = this.ranges[i + t], u = this.ranges[i + r];
      e(l, l + c, a, a + u), s += u - c;
    }
  }
  /**
  Create an inverted version of this map. The result can be used to
  map positions in the post-step document to the pre-step document.
  */
  invert() {
    return new Ze(this.ranges, !this.inverted);
  }
  /**
  @internal
  */
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  /**
  Create a map that moves all positions by offset `n` (which may be
  negative). This can be useful when applying steps meant for a
  sub-document to a larger document, or vice-versa.
  */
  static offset(e) {
    return e == 0 ? Ze.empty : new Ze(e < 0 ? [0, -e, 0] : [0, 0, e]);
  }
}
Ze.empty = new Ze([]);
class li {
  /**
  Create a new mapping with the given position maps.
  */
  constructor(e, t, r = 0, i = e ? e.length : 0) {
    this.mirror = t, this.from = r, this.to = i, this._maps = e || [], this.ownData = !(e || t);
  }
  /**
  The step maps in this mapping.
  */
  get maps() {
    return this._maps;
  }
  /**
  Create a mapping that maps only through a part of this one.
  */
  slice(e = 0, t = this.maps.length) {
    return new li(this._maps, this.mirror, e, t);
  }
  /**
  Add a step map to the end of this mapping. If `mirrors` is
  given, it should be the index of the step map that is the mirror
  image of this one.
  */
  appendMap(e, t) {
    this.ownData || (this._maps = this._maps.slice(), this.mirror = this.mirror && this.mirror.slice(), this.ownData = !0), this.to = this._maps.push(e), t != null && this.setMirror(this._maps.length - 1, t);
  }
  /**
  Add all the step maps in a given mapping to this one (preserving
  mirroring information).
  */
  appendMapping(e) {
    for (let t = 0, r = this._maps.length; t < e._maps.length; t++) {
      let i = e.getMirror(t);
      this.appendMap(e._maps[t], i != null && i < t ? r + i : void 0);
    }
  }
  /**
  Finds the offset of the step map that mirrors the map at the
  given offset, in this mapping (as per the second argument to
  `appendMap`).
  */
  getMirror(e) {
    if (this.mirror) {
      for (let t = 0; t < this.mirror.length; t++)
        if (this.mirror[t] == e)
          return this.mirror[t + (t % 2 ? -1 : 1)];
    }
  }
  /**
  @internal
  */
  setMirror(e, t) {
    this.mirror || (this.mirror = []), this.mirror.push(e, t);
  }
  /**
  Append the inverse of the given mapping to this one.
  */
  appendMappingInverted(e) {
    for (let t = e.maps.length - 1, r = this._maps.length + e._maps.length; t >= 0; t--) {
      let i = e.getMirror(t);
      this.appendMap(e._maps[t].invert(), i != null && i > t ? r - i - 1 : void 0);
    }
  }
  /**
  Create an inverted version of this mapping.
  */
  invert() {
    let e = new li();
    return e.appendMappingInverted(this), e;
  }
  /**
  Map a position through this mapping.
  */
  map(e, t = 1) {
    if (this.mirror)
      return this._map(e, t, !0);
    for (let r = this.from; r < this.to; r++)
      e = this._maps[r].map(e, t);
    return e;
  }
  /**
  Map a position through this mapping, returning a mapping
  result.
  */
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  /**
  @internal
  */
  _map(e, t, r) {
    let i = 0;
    for (let s = this.from; s < this.to; s++) {
      let o = this._maps[s], l = o.mapResult(e, t);
      if (l.recover != null) {
        let a = this.getMirror(s);
        if (a != null && a > s && a < this.to) {
          s = a, e = this._maps[a].recover(l.recover);
          continue;
        }
      }
      i |= l.delInfo, e = l.pos;
    }
    return r ? e : new Il(e, i, null);
  }
}
const Go = /* @__PURE__ */ Object.create(null);
class Le {
  /**
  Get the step map that represents the changes made by this step,
  and which can be used to transform between positions in the old
  and the new document.
  */
  getMap() {
    return Ze.empty;
  }
  /**
  Try to merge this step with another one, to be applied directly
  after it. Returns the merged step when possible, null if the
  steps can't be merged.
  */
  merge(e) {
    return null;
  }
  /**
  Deserialize a step from its JSON representation. Will call
  through to the step class' own implementation of this method.
  */
  static fromJSON(e, t) {
    if (!t || !t.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let r = Go[t.stepType];
    if (!r)
      throw new RangeError(`No step type ${t.stepType} defined`);
    return r.fromJSON(e, t);
  }
  /**
  To be able to serialize steps to JSON, each step needs a string
  ID to attach to its JSON representation. Use this method to
  register an ID for your step classes. Try to pick something
  that's unlikely to clash with steps from other modules.
  */
  static jsonID(e, t) {
    if (e in Go)
      throw new RangeError("Duplicate use of step JSON ID " + e);
    return Go[e] = t, t.prototype.jsonID = e, t;
  }
}
class me {
  /**
  @internal
  */
  constructor(e, t) {
    this.doc = e, this.failed = t;
  }
  /**
  Create a successful step result.
  */
  static ok(e) {
    return new me(e, null);
  }
  /**
  Create a failed step result.
  */
  static fail(e) {
    return new me(null, e);
  }
  /**
  Call [`Node.replace`](https://prosemirror.net/docs/ref/#model.Node.replace) with the given
  arguments. Create a successful result if it succeeds, and a
  failed one if it throws a `ReplaceError`.
  */
  static fromReplace(e, t, r, i) {
    try {
      return me.ok(e.replace(t, r, i));
    } catch (s) {
      if (s instanceof _s)
        return me.fail(s.message);
      throw s;
    }
  }
}
function ma(n, e, t) {
  let r = [];
  for (let i = 0; i < n.childCount; i++) {
    let s = n.child(i);
    s.content.size && (s = s.copy(ma(s.content, e, s))), s.isInline && (s = e(s, t, i)), r.push(s);
  }
  return A.fromArray(r);
}
class hn extends Le {
  /**
  Create a mark step.
  */
  constructor(e, t, r) {
    super(), this.from = e, this.to = t, this.mark = r;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), r = e.resolve(this.from), i = r.node(r.sharedDepth(this.to)), s = new O(ma(t.content, (o, l) => !o.isAtom || !l.type.allowsMarkType(this.mark.type) ? o : o.mark(this.mark.addToSet(o.marks)), i), t.openStart, t.openEnd);
    return me.fromReplace(e, this.from, this.to, s);
  }
  invert() {
    return new vt(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
    return t.deleted && r.deleted || t.pos >= r.pos ? null : new hn(t.pos, r.pos, this.mark);
  }
  merge(e) {
    return e instanceof hn && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new hn(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new hn(t.from, t.to, e.markFromJSON(t.mark));
  }
}
Le.jsonID("addMark", hn);
class vt extends Le {
  /**
  Create a mark-removing step.
  */
  constructor(e, t, r) {
    super(), this.from = e, this.to = t, this.mark = r;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), r = new O(ma(t.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), e), t.openStart, t.openEnd);
    return me.fromReplace(e, this.from, this.to, r);
  }
  invert() {
    return new hn(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
    return t.deleted && r.deleted || t.pos >= r.pos ? null : new vt(t.pos, r.pos, this.mark);
  }
  merge(e) {
    return e instanceof vt && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new vt(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new vt(t.from, t.to, e.markFromJSON(t.mark));
  }
}
Le.jsonID("removeMark", vt);
class pn extends Le {
  /**
  Create a node mark step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return me.fail("No node at mark step's position");
    let r = t.type.create(t.attrs, null, this.mark.addToSet(t.marks));
    return me.fromReplace(e, this.pos, this.pos + 1, new O(A.from(r), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    if (t) {
      let r = this.mark.addToSet(t.marks);
      if (r.length == t.marks.length) {
        for (let i = 0; i < t.marks.length; i++)
          if (!t.marks[i].isInSet(r))
            return new pn(this.pos, t.marks[i]);
        return new pn(this.pos, this.mark);
      }
    }
    return new zn(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new pn(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new pn(t.pos, e.markFromJSON(t.mark));
  }
}
Le.jsonID("addNodeMark", pn);
class zn extends Le {
  /**
  Create a mark-removing step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return me.fail("No node at mark step's position");
    let r = t.type.create(t.attrs, null, this.mark.removeFromSet(t.marks));
    return me.fromReplace(e, this.pos, this.pos + 1, new O(A.from(r), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    return !t || !this.mark.isInSet(t.marks) ? this : new pn(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new zn(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new zn(t.pos, e.markFromJSON(t.mark));
  }
}
Le.jsonID("removeNodeMark", zn);
class Ee extends Le {
  /**
  The given `slice` should fit the 'gap' between `from` and
  `to`—the depths must line up, and the surrounding nodes must be
  able to be joined with the open sides of the slice. When
  `structure` is true, the step will fail if the content between
  from and to is not just a sequence of closing and then opening
  tokens (this is to guard against rebased replace steps
  overwriting something they weren't supposed to).
  */
  constructor(e, t, r, i = !1) {
    super(), this.from = e, this.to = t, this.slice = r, this.structure = i;
  }
  apply(e) {
    return this.structure && Rl(e, this.from, this.to) ? me.fail("Structure replace would overwrite content") : me.fromReplace(e, this.from, this.to, this.slice);
  }
  getMap() {
    return new Ze([this.from, this.to - this.from, this.slice.size]);
  }
  invert(e) {
    return new Ee(this.from, this.from + this.slice.size, e.slice(this.from, this.to));
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
    return t.deletedAcross && r.deletedAcross ? null : new Ee(t.pos, Math.max(t.pos, r.pos), this.slice, this.structure);
  }
  merge(e) {
    if (!(e instanceof Ee) || e.structure || this.structure)
      return null;
    if (this.from + this.slice.size == e.from && !this.slice.openEnd && !e.slice.openStart) {
      let t = this.slice.size + e.slice.size == 0 ? O.empty : new O(this.slice.content.append(e.slice.content), this.slice.openStart, e.slice.openEnd);
      return new Ee(this.from, this.to + (e.to - e.from), t, this.structure);
    } else if (e.to == this.from && !this.slice.openStart && !e.slice.openEnd) {
      let t = this.slice.size + e.slice.size == 0 ? O.empty : new O(e.slice.content.append(this.slice.content), e.slice.openStart, this.slice.openEnd);
      return new Ee(e.from, this.to, t, this.structure);
    } else
      return null;
  }
  toJSON() {
    let e = { stepType: "replace", from: this.from, to: this.to };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new Ee(t.from, t.to, O.fromJSON(e, t.slice), !!t.structure);
  }
}
Le.jsonID("replace", Ee);
class De extends Le {
  /**
  Create a replace-around step with the given range and gap.
  `insert` should be the point in the slice into which the content
  of the gap should be moved. `structure` has the same meaning as
  it has in the [`ReplaceStep`](https://prosemirror.net/docs/ref/#transform.ReplaceStep) class.
  */
  constructor(e, t, r, i, s, o, l = !1) {
    super(), this.from = e, this.to = t, this.gapFrom = r, this.gapTo = i, this.slice = s, this.insert = o, this.structure = l;
  }
  apply(e) {
    if (this.structure && (Rl(e, this.from, this.gapFrom) || Rl(e, this.gapTo, this.to)))
      return me.fail("Structure gap-replace would overwrite content");
    let t = e.slice(this.gapFrom, this.gapTo);
    if (t.openStart || t.openEnd)
      return me.fail("Gap is not a flat range");
    let r = this.slice.insertAt(this.insert, t.content);
    return r ? me.fromReplace(e, this.from, this.to, r) : me.fail("Content does not fit in gap");
  }
  getMap() {
    return new Ze([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert
    ]);
  }
  invert(e) {
    let t = this.gapTo - this.gapFrom;
    return new De(this.from, this.from + this.slice.size + t, this.from + this.insert, this.from + this.insert + t, e.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1), i = this.from == this.gapFrom ? t.pos : e.map(this.gapFrom, -1), s = this.to == this.gapTo ? r.pos : e.map(this.gapTo, 1);
    return t.deletedAcross && r.deletedAcross || i < t.pos || s > r.pos ? null : new De(t.pos, r.pos, i, s, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let e = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert
    };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number" || typeof t.gapFrom != "number" || typeof t.gapTo != "number" || typeof t.insert != "number")
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new De(t.from, t.to, t.gapFrom, t.gapTo, O.fromJSON(e, t.slice), t.insert, !!t.structure);
  }
}
Le.jsonID("replaceAround", De);
function Rl(n, e, t) {
  let r = n.resolve(e), i = t - e, s = r.depth;
  for (; i > 0 && s > 0 && r.indexAfter(s) == r.node(s).childCount; )
    s--, i--;
  if (i > 0) {
    let o = r.node(s).maybeChild(r.indexAfter(s));
    for (; i > 0; ) {
      if (!o || o.isLeaf)
        return !0;
      o = o.firstChild, i--;
    }
  }
  return !1;
}
function T1(n, e, t, r) {
  let i = [], s = [], o, l;
  n.doc.nodesBetween(e, t, (a, c, u) => {
    if (!a.isInline)
      return;
    let d = a.marks;
    if (!r.isInSet(d) && u.type.allowsMarkType(r.type)) {
      let f = Math.max(c, e), h = Math.min(c + a.nodeSize, t), p = r.addToSet(d);
      for (let m = 0; m < d.length; m++)
        d[m].isInSet(p) || (o && o.to == f && o.mark.eq(d[m]) ? o.to = h : i.push(o = new vt(f, h, d[m])));
      l && l.to == f ? l.to = h : s.push(l = new hn(f, h, r));
    }
  }), i.forEach((a) => n.step(a)), s.forEach((a) => n.step(a));
}
function M1(n, e, t, r) {
  let i = [], s = 0;
  n.doc.nodesBetween(e, t, (o, l) => {
    if (!o.isInline)
      return;
    s++;
    let a = null;
    if (r instanceof so) {
      let c = o.marks, u;
      for (; u = r.isInSet(c); )
        (a || (a = [])).push(u), c = u.removeFromSet(c);
    } else r ? r.isInSet(o.marks) && (a = [r]) : a = o.marks;
    if (a && a.length) {
      let c = Math.min(l + o.nodeSize, t);
      for (let u = 0; u < a.length; u++) {
        let d = a[u], f;
        for (let h = 0; h < i.length; h++) {
          let p = i[h];
          p.step == s - 1 && d.eq(i[h].style) && (f = p);
        }
        f ? (f.to = c, f.step = s) : i.push({ style: d, from: Math.max(l, e), to: c, step: s });
      }
    }
  }), i.forEach((o) => n.step(new vt(o.from, o.to, o.style)));
}
function ga(n, e, t, r = t.contentMatch, i = !0) {
  let s = n.doc.nodeAt(e), o = [], l = e + 1;
  for (let a = 0; a < s.childCount; a++) {
    let c = s.child(a), u = l + c.nodeSize, d = r.matchType(c.type);
    if (!d)
      o.push(new Ee(l, u, O.empty));
    else {
      r = d;
      for (let f = 0; f < c.marks.length; f++)
        t.allowsMarkType(c.marks[f].type) || n.step(new vt(l, u, c.marks[f]));
      if (i && c.isText && t.whitespace != "pre") {
        let f, h = /\r?\n|\r/g, p;
        for (; f = h.exec(c.text); )
          p || (p = new O(A.from(t.schema.text(" ", t.allowedMarks(c.marks))), 0, 0)), o.push(new Ee(l + f.index, l + f.index + f[0].length, p));
      }
    }
    l = u;
  }
  if (!r.validEnd) {
    let a = r.fillBefore(A.empty, !0);
    n.replace(l, l, new O(a, 0, 0));
  }
  for (let a = o.length - 1; a >= 0; a--)
    n.step(o[a]);
}
function F1(n, e, t) {
  return (e == 0 || n.canReplace(e, n.childCount)) && (t == n.childCount || n.canReplace(0, t));
}
function Er(n) {
  let t = n.parent.content.cutByIndex(n.startIndex, n.endIndex);
  for (let r = n.depth; ; --r) {
    let i = n.$from.node(r), s = n.$from.index(r), o = n.$to.indexAfter(r);
    if (r < n.depth && i.canReplace(s, o, t))
      return r;
    if (r == 0 || i.type.spec.isolating || !F1(i, s, o))
      break;
  }
  return null;
}
function $1(n, e, t) {
  let { $from: r, $to: i, depth: s } = e, o = r.before(s + 1), l = i.after(s + 1), a = o, c = l, u = A.empty, d = 0;
  for (let p = s, m = !1; p > t; p--)
    m || r.index(p) > 0 ? (m = !0, u = A.from(r.node(p).copy(u)), d++) : a--;
  let f = A.empty, h = 0;
  for (let p = s, m = !1; p > t; p--)
    m || i.after(p + 1) < i.end(p) ? (m = !0, f = A.from(i.node(p).copy(f)), h++) : c++;
  n.step(new De(a, c, o, l, new O(u.append(f), d, h), u.size - d, !0));
}
function _a(n, e, t = null, r = n) {
  let i = O1(n, e), s = i && N1(r, e);
  return s ? i.map(Vu).concat({ type: e, attrs: t }).concat(s.map(Vu)) : null;
}
function Vu(n) {
  return { type: n, attrs: null };
}
function O1(n, e) {
  let { parent: t, startIndex: r, endIndex: i } = n, s = t.contentMatchAt(r).findWrapping(e);
  if (!s)
    return null;
  let o = s.length ? s[0] : e;
  return t.canReplaceWith(r, i, o) ? s : null;
}
function N1(n, e) {
  let { parent: t, startIndex: r, endIndex: i } = n, s = t.child(r), o = e.contentMatch.findWrapping(s.type);
  if (!o)
    return null;
  let a = (o.length ? o[o.length - 1] : e).contentMatch;
  for (let c = r; a && c < i; c++)
    a = a.matchType(t.child(c).type);
  return !a || !a.validEnd ? null : o;
}
function I1(n, e, t) {
  let r = A.empty;
  for (let o = t.length - 1; o >= 0; o--) {
    if (r.size) {
      let l = t[o].type.contentMatch.matchFragment(r);
      if (!l || !l.validEnd)
        throw new RangeError("Wrapper type given to Transform.wrap does not form valid content of its parent wrapper");
    }
    r = A.from(t[o].type.create(t[o].attrs, r));
  }
  let i = e.start, s = e.end;
  n.step(new De(i, s, i, s, new O(r, 0, 0), t.length, !0));
}
function R1(n, e, t, r, i) {
  if (!r.isTextblock)
    throw new RangeError("Type given to setBlockType should be a textblock");
  let s = n.steps.length;
  n.doc.nodesBetween(e, t, (o, l) => {
    let a = typeof i == "function" ? i(o) : i;
    if (o.isTextblock && !o.hasMarkup(r, a) && L1(n.doc, n.mapping.slice(s).map(l), r)) {
      let c = null;
      if (r.schema.linebreakReplacement) {
        let h = r.whitespace == "pre", p = !!r.contentMatch.matchType(r.schema.linebreakReplacement);
        h && !p ? c = !1 : !h && p && (c = !0);
      }
      c === !1 && Ah(n, o, l, s), ga(n, n.mapping.slice(s).map(l, 1), r, void 0, c === null);
      let u = n.mapping.slice(s), d = u.map(l, 1), f = u.map(l + o.nodeSize, 1);
      return n.step(new De(d, f, d + 1, f - 1, new O(A.from(r.create(a, null, o.marks)), 0, 0), 1, !0)), c === !0 && Ch(n, o, l, s), !1;
    }
  });
}
function Ch(n, e, t, r) {
  e.forEach((i, s) => {
    if (i.isText) {
      let o, l = /\r?\n|\r/g;
      for (; o = l.exec(i.text); ) {
        let a = n.mapping.slice(r).map(t + 1 + s + o.index);
        n.replaceWith(a, a + 1, e.type.schema.linebreakReplacement.create());
      }
    }
  });
}
function Ah(n, e, t, r) {
  e.forEach((i, s) => {
    if (i.type == i.type.schema.linebreakReplacement) {
      let o = n.mapping.slice(r).map(t + 1 + s);
      n.replaceWith(o, o + 1, e.type.schema.text(`
`));
    }
  });
}
function L1(n, e, t) {
  let r = n.resolve(e), i = r.index();
  return r.parent.canReplaceWith(i, i + 1, t);
}
function P1(n, e, t, r, i) {
  let s = n.doc.nodeAt(e);
  if (!s)
    throw new RangeError("No node at given position");
  t || (t = s.type);
  let o = t.create(r, null, i || s.marks);
  if (s.isLeaf)
    return n.replaceWith(e, e + s.nodeSize, o);
  if (!t.validContent(s.content))
    throw new RangeError("Invalid content for node type " + t.name);
  n.step(new De(e, e + s.nodeSize, e + 1, e + s.nodeSize - 1, new O(A.from(o), 0, 0), 1, !0));
}
function Xt(n, e, t = 1, r) {
  let i = n.resolve(e), s = i.depth - t, o = r && r[r.length - 1] || i.parent;
  if (s < 0 || i.parent.type.spec.isolating || !i.parent.canReplace(i.index(), i.parent.childCount) || !o.type.validContent(i.parent.content.cutByIndex(i.index(), i.parent.childCount)))
    return !1;
  for (let c = i.depth - 1, u = t - 2; c > s; c--, u--) {
    let d = i.node(c), f = i.index(c);
    if (d.type.spec.isolating)
      return !1;
    let h = d.content.cutByIndex(f, d.childCount), p = r && r[u + 1];
    p && (h = h.replaceChild(0, p.type.create(p.attrs)));
    let m = r && r[u] || d;
    if (!d.canReplace(f + 1, d.childCount) || !m.type.validContent(h))
      return !1;
  }
  let l = i.indexAfter(s), a = r && r[0];
  return i.node(s).canReplaceWith(l, l, a ? a.type : i.node(s + 1).type);
}
function B1(n, e, t = 1, r) {
  let i = n.doc.resolve(e), s = A.empty, o = A.empty;
  for (let l = i.depth, a = i.depth - t, c = t - 1; l > a; l--, c--) {
    s = A.from(i.node(l).copy(s));
    let u = r && r[c];
    o = A.from(u ? u.type.create(u.attrs, o) : i.node(l).copy(o));
  }
  n.step(new Ee(e, e, new O(s.append(o), t, t), !0));
}
function wn(n, e) {
  let t = n.resolve(e), r = t.index();
  return xh(t.nodeBefore, t.nodeAfter) && t.parent.canReplace(r, r + 1);
}
function z1(n, e) {
  e.content.size || n.type.compatibleContent(e.type);
  let t = n.contentMatchAt(n.childCount), { linebreakReplacement: r } = n.type.schema;
  for (let i = 0; i < e.childCount; i++) {
    let s = e.child(i), o = s.type == r ? n.type.schema.nodes.text : s.type;
    if (t = t.matchType(o), !t || !n.type.allowsMarks(s.marks))
      return !1;
  }
  return t.validEnd;
}
function xh(n, e) {
  return !!(n && e && !n.isLeaf && z1(n, e));
}
function oo(n, e, t = -1) {
  let r = n.resolve(e);
  for (let i = r.depth; ; i--) {
    let s, o, l = r.index(i);
    if (i == r.depth ? (s = r.nodeBefore, o = r.nodeAfter) : t > 0 ? (s = r.node(i + 1), l++, o = r.node(i).maybeChild(l)) : (s = r.node(i).maybeChild(l - 1), o = r.node(i + 1)), s && !s.isTextblock && xh(s, o) && r.node(i).canReplace(l, l + 1))
      return e;
    if (i == 0)
      break;
    e = t < 0 ? r.before(i) : r.after(i);
  }
}
function H1(n, e, t) {
  let r = null, { linebreakReplacement: i } = n.doc.type.schema, s = n.doc.resolve(e - t), o = s.node().type;
  if (i && o.inlineContent) {
    let u = o.whitespace == "pre", d = !!o.contentMatch.matchType(i);
    u && !d ? r = !1 : !u && d && (r = !0);
  }
  let l = n.steps.length;
  if (r === !1) {
    let u = n.doc.resolve(e + t);
    Ah(n, u.node(), u.before(), l);
  }
  o.inlineContent && ga(n, e + t - 1, o, s.node().contentMatchAt(s.index()), r == null);
  let a = n.mapping.slice(l), c = a.map(e - t);
  if (n.step(new Ee(c, a.map(e + t, -1), O.empty, !0)), r === !0) {
    let u = n.doc.resolve(c);
    Ch(n, u.node(), u.before(), n.steps.length);
  }
  return n;
}
function q1(n, e, t) {
  let r = n.resolve(e);
  if (r.parent.canReplaceWith(r.index(), r.index(), t))
    return e;
  if (r.parentOffset == 0)
    for (let i = r.depth - 1; i >= 0; i--) {
      let s = r.index(i);
      if (r.node(i).canReplaceWith(s, s, t))
        return r.before(i + 1);
      if (s > 0)
        return null;
    }
  if (r.parentOffset == r.parent.content.size)
    for (let i = r.depth - 1; i >= 0; i--) {
      let s = r.indexAfter(i);
      if (r.node(i).canReplaceWith(s, s, t))
        return r.after(i + 1);
      if (s < r.node(i).childCount)
        return null;
    }
  return null;
}
function Th(n, e, t) {
  let r = n.resolve(e);
  if (!t.content.size)
    return e;
  let i = t.content;
  for (let s = 0; s < t.openStart; s++)
    i = i.firstChild.content;
  for (let s = 1; s <= (t.openStart == 0 && t.size ? 2 : 1); s++)
    for (let o = r.depth; o >= 0; o--) {
      let l = o == r.depth ? 0 : r.pos <= (r.start(o + 1) + r.end(o + 1)) / 2 ? -1 : 1, a = r.index(o) + (l > 0 ? 1 : 0), c = r.node(o), u = !1;
      if (s == 1)
        u = c.canReplace(a, a, i);
      else {
        let d = c.contentMatchAt(a).findWrapping(i.firstChild.type);
        u = d && c.canReplaceWith(a, a, d[0]);
      }
      if (u)
        return l == 0 ? r.pos : l < 0 ? r.before(o + 1) : r.after(o + 1);
    }
  return null;
}
function lo(n, e, t = e, r = O.empty) {
  if (e == t && !r.size)
    return null;
  let i = n.resolve(e), s = n.resolve(t);
  return Mh(i, s, r) ? new Ee(e, t, r) : new V1(i, s, r).fit();
}
function Mh(n, e, t) {
  return !t.openStart && !t.openEnd && n.start() == e.start() && n.parent.canReplace(n.index(), e.index(), t.content);
}
class V1 {
  constructor(e, t, r) {
    this.$from = e, this.$to = t, this.unplaced = r, this.frontier = [], this.placed = A.empty;
    for (let i = 0; i <= e.depth; i++) {
      let s = e.node(i);
      this.frontier.push({
        type: s.type,
        match: s.contentMatchAt(e.indexAfter(i))
      });
    }
    for (let i = e.depth; i > 0; i--)
      this.placed = A.from(e.node(i).copy(this.placed));
  }
  get depth() {
    return this.frontier.length - 1;
  }
  fit() {
    for (; this.unplaced.size; ) {
      let c = this.findFittable();
      c ? this.placeNodes(c) : this.openMore() || this.dropNode();
    }
    let e = this.mustMoveInline(), t = this.placed.size - this.depth - this.$from.depth, r = this.$from, i = this.close(e < 0 ? this.$to : r.doc.resolve(e));
    if (!i)
      return null;
    let s = this.placed, o = r.depth, l = i.depth;
    for (; o && l && s.childCount == 1; )
      s = s.firstChild.content, o--, l--;
    let a = new O(s, o, l);
    return e > -1 ? new De(r.pos, e, this.$to.pos, this.$to.end(), a, t) : a.size || r.pos != this.$to.pos ? new Ee(r.pos, i.pos, a) : null;
  }
  // Find a position on the start spine of `this.unplaced` that has
  // content that can be moved somewhere on the frontier. Returns two
  // depths, one for the slice and one for the frontier.
  findFittable() {
    let e = this.unplaced.openStart;
    for (let t = this.unplaced.content, r = 0, i = this.unplaced.openEnd; r < e; r++) {
      let s = t.firstChild;
      if (t.childCount > 1 && (i = 0), s.type.spec.isolating && i <= r) {
        e = r;
        break;
      }
      t = s.content;
    }
    for (let t = 1; t <= 2; t++)
      for (let r = t == 1 ? e : this.unplaced.openStart; r >= 0; r--) {
        let i, s = null;
        r ? (s = Jo(this.unplaced.content, r - 1).firstChild, i = s.content) : i = this.unplaced.content;
        let o = i.firstChild;
        for (let l = this.depth; l >= 0; l--) {
          let { type: a, match: c } = this.frontier[l], u, d = null;
          if (t == 1 && (o ? c.matchType(o.type) || (d = c.fillBefore(A.from(o), !1)) : s && a.compatibleContent(s.type)))
            return { sliceDepth: r, frontierDepth: l, parent: s, inject: d };
          if (t == 2 && o && (u = c.findWrapping(o.type)))
            return { sliceDepth: r, frontierDepth: l, parent: s, wrap: u };
          if (s && c.matchType(s.type))
            break;
        }
      }
  }
  openMore() {
    let { content: e, openStart: t, openEnd: r } = this.unplaced, i = Jo(e, t);
    return !i.childCount || i.firstChild.isLeaf ? !1 : (this.unplaced = new O(e, t + 1, Math.max(r, i.size + t >= e.size - r ? t + 1 : 0)), !0);
  }
  dropNode() {
    let { content: e, openStart: t, openEnd: r } = this.unplaced, i = Jo(e, t);
    if (i.childCount <= 1 && t > 0) {
      let s = e.size - t <= t + i.size;
      this.unplaced = new O(Lr(e, t - 1, 1), t - 1, s ? t - 1 : r);
    } else
      this.unplaced = new O(Lr(e, t, 1), t, r);
  }
  // Move content from the unplaced slice at `sliceDepth` to the
  // frontier node at `frontierDepth`. Close that frontier node when
  // applicable.
  placeNodes({ sliceDepth: e, frontierDepth: t, parent: r, inject: i, wrap: s }) {
    for (; this.depth > t; )
      this.closeFrontierNode();
    if (s)
      for (let m = 0; m < s.length; m++)
        this.openFrontierNode(s[m]);
    let o = this.unplaced, l = r ? r.content : o.content, a = o.openStart - e, c = 0, u = [], { match: d, type: f } = this.frontier[t];
    if (i) {
      for (let m = 0; m < i.childCount; m++)
        u.push(i.child(m));
      d = d.matchFragment(i);
    }
    let h = l.size + e - (o.content.size - o.openEnd);
    for (; c < l.childCount; ) {
      let m = l.child(c), _ = d.matchType(m.type);
      if (!_)
        break;
      c++, (c > 1 || a == 0 || m.content.size) && (d = _, u.push(Fh(m.mark(f.allowedMarks(m.marks)), c == 1 ? a : 0, c == l.childCount ? h : -1)));
    }
    let p = c == l.childCount;
    p || (h = -1), this.placed = Pr(this.placed, t, A.from(u)), this.frontier[t].match = d, p && h < 0 && r && r.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
    for (let m = 0, _ = l; m < h; m++) {
      let b = _.lastChild;
      this.frontier.push({ type: b.type, match: b.contentMatchAt(b.childCount) }), _ = b.content;
    }
    this.unplaced = p ? e == 0 ? O.empty : new O(Lr(o.content, e - 1, 1), e - 1, h < 0 ? o.openEnd : e - 1) : new O(Lr(o.content, e, c), o.openStart, o.openEnd);
  }
  mustMoveInline() {
    if (!this.$to.parent.isTextblock)
      return -1;
    let e = this.frontier[this.depth], t;
    if (!e.type.isTextblock || !Yo(this.$to, this.$to.depth, e.type, e.match, !1) || this.$to.depth == this.depth && (t = this.findCloseLevel(this.$to)) && t.depth == this.depth)
      return -1;
    let { depth: r } = this.$to, i = this.$to.after(r);
    for (; r > 1 && i == this.$to.end(--r); )
      ++i;
    return i;
  }
  findCloseLevel(e) {
    e: for (let t = Math.min(this.depth, e.depth); t >= 0; t--) {
      let { match: r, type: i } = this.frontier[t], s = t < e.depth && e.end(t + 1) == e.pos + (e.depth - (t + 1)), o = Yo(e, t, i, r, s);
      if (o) {
        for (let l = t - 1; l >= 0; l--) {
          let { match: a, type: c } = this.frontier[l], u = Yo(e, l, c, a, !0);
          if (!u || u.childCount)
            continue e;
        }
        return { depth: t, fit: o, move: s ? e.doc.resolve(e.after(t + 1)) : e };
      }
    }
  }
  close(e) {
    let t = this.findCloseLevel(e);
    if (!t)
      return null;
    for (; this.depth > t.depth; )
      this.closeFrontierNode();
    t.fit.childCount && (this.placed = Pr(this.placed, t.depth, t.fit)), e = t.move;
    for (let r = t.depth + 1; r <= e.depth; r++) {
      let i = e.node(r), s = i.type.contentMatch.fillBefore(i.content, !0, e.index(r));
      this.openFrontierNode(i.type, i.attrs, s);
    }
    return e;
  }
  openFrontierNode(e, t = null, r) {
    let i = this.frontier[this.depth];
    i.match = i.match.matchType(e), this.placed = Pr(this.placed, this.depth, A.from(e.create(t, r))), this.frontier.push({ type: e, match: e.contentMatch });
  }
  closeFrontierNode() {
    let t = this.frontier.pop().match.fillBefore(A.empty, !0);
    t.childCount && (this.placed = Pr(this.placed, this.frontier.length, t));
  }
}
function Lr(n, e, t) {
  return e == 0 ? n.cutByIndex(t, n.childCount) : n.replaceChild(0, n.firstChild.copy(Lr(n.firstChild.content, e - 1, t)));
}
function Pr(n, e, t) {
  return e == 0 ? n.append(t) : n.replaceChild(n.childCount - 1, n.lastChild.copy(Pr(n.lastChild.content, e - 1, t)));
}
function Jo(n, e) {
  for (let t = 0; t < e; t++)
    n = n.firstChild.content;
  return n;
}
function Fh(n, e, t) {
  if (e <= 0)
    return n;
  let r = n.content;
  return e > 1 && (r = r.replaceChild(0, Fh(r.firstChild, e - 1, r.childCount == 1 ? t - 1 : 0))), e > 0 && (r = n.type.contentMatch.fillBefore(r).append(r), t <= 0 && (r = r.append(n.type.contentMatch.matchFragment(r).fillBefore(A.empty, !0)))), n.copy(r);
}
function Yo(n, e, t, r, i) {
  let s = n.node(e), o = i ? n.indexAfter(e) : n.index(e);
  if (o == s.childCount && !t.compatibleContent(s.type))
    return null;
  let l = r.fillBefore(s.content, !0, o);
  return l && !U1(t, s.content, o) ? l : null;
}
function U1(n, e, t) {
  for (let r = t; r < e.childCount; r++)
    if (!n.allowsMarks(e.child(r).marks))
      return !0;
  return !1;
}
function j1(n) {
  return n.spec.defining || n.spec.definingForContent;
}
function W1(n, e, t, r) {
  if (!r.size)
    return n.deleteRange(e, t);
  let i = n.doc.resolve(e), s = n.doc.resolve(t);
  if (Mh(i, s, r))
    return n.step(new Ee(e, t, r));
  let o = Oh(i, n.doc.resolve(t));
  o[o.length - 1] == 0 && o.pop();
  let l = -(i.depth + 1);
  o.unshift(l);
  for (let f = i.depth, h = i.pos - 1; f > 0; f--, h--) {
    let p = i.node(f).type.spec;
    if (p.defining || p.definingAsContext || p.isolating)
      break;
    o.indexOf(f) > -1 ? l = f : i.before(f) == h && o.splice(1, 0, -f);
  }
  let a = o.indexOf(l), c = [], u = r.openStart;
  for (let f = r.content, h = 0; ; h++) {
    let p = f.firstChild;
    if (c.push(p), h == r.openStart)
      break;
    f = p.content;
  }
  for (let f = u - 1; f >= 0; f--) {
    let h = c[f], p = j1(h.type);
    if (p && !h.sameMarkup(i.node(Math.abs(l) - 1)))
      u = f;
    else if (p || !h.type.isTextblock)
      break;
  }
  for (let f = r.openStart; f >= 0; f--) {
    let h = (f + u + 1) % (r.openStart + 1), p = c[h];
    if (p)
      for (let m = 0; m < o.length; m++) {
        let _ = o[(m + a) % o.length], b = !0;
        _ < 0 && (b = !1, _ = -_);
        let y = i.node(_ - 1), g = i.index(_ - 1);
        if (y.canReplaceWith(g, g, p.type, p.marks))
          return n.replace(i.before(_), b ? s.after(_) : t, new O($h(r.content, 0, r.openStart, h), h, r.openEnd));
      }
  }
  let d = n.steps.length;
  for (let f = o.length - 1; f >= 0 && (n.replace(e, t, r), !(n.steps.length > d)); f--) {
    let h = o[f];
    h < 0 || (e = i.before(h), t = s.after(h));
  }
}
function $h(n, e, t, r, i) {
  if (e < t) {
    let s = n.firstChild;
    n = n.replaceChild(0, s.copy($h(s.content, e + 1, t, r, s)));
  }
  if (e > r) {
    let s = i.contentMatchAt(0), o = s.fillBefore(n).append(n);
    n = o.append(s.matchFragment(o).fillBefore(A.empty, !0));
  }
  return n;
}
function K1(n, e, t, r) {
  if (!r.isInline && e == t && n.doc.resolve(e).parent.content.size) {
    let i = q1(n.doc, e, r.type);
    i != null && (e = t = i);
  }
  n.replaceRange(e, t, new O(A.from(r), 0, 0));
}
function G1(n, e, t) {
  let r = n.doc.resolve(e), i = n.doc.resolve(t), s = Oh(r, i);
  for (let o = 0; o < s.length; o++) {
    let l = s[o], a = o == s.length - 1;
    if (a && l == 0 || r.node(l).type.contentMatch.validEnd)
      return n.delete(r.start(l), i.end(l));
    if (l > 0 && (a || r.node(l - 1).canReplace(r.index(l - 1), i.indexAfter(l - 1))))
      return n.delete(r.before(l), i.after(l));
  }
  for (let o = 1; o <= r.depth && o <= i.depth; o++)
    if (e - r.start(o) == r.depth - o && t > r.end(o) && i.end(o) - t != i.depth - o && r.start(o - 1) == i.start(o - 1) && r.node(o - 1).canReplace(r.index(o - 1), i.index(o - 1)))
      return n.delete(r.before(o), t);
  n.delete(e, t);
}
function Oh(n, e) {
  let t = [], r = Math.min(n.depth, e.depth);
  for (let i = r; i >= 0; i--) {
    let s = n.start(i);
    if (s < n.pos - (n.depth - i) || e.end(i) > e.pos + (e.depth - i) || n.node(i).type.spec.isolating || e.node(i).type.spec.isolating)
      break;
    (s == e.start(i) || i == n.depth && i == e.depth && n.parent.inlineContent && e.parent.inlineContent && i && e.start(i - 1) == s - 1) && t.push(i);
  }
  return t;
}
class mr extends Le {
  /**
  Construct an attribute step.
  */
  constructor(e, t, r) {
    super(), this.pos = e, this.attr = t, this.value = r;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return me.fail("No node at attribute step's position");
    let r = /* @__PURE__ */ Object.create(null);
    for (let s in t.attrs)
      r[s] = t.attrs[s];
    r[this.attr] = this.value;
    let i = t.type.create(r, null, t.marks);
    return me.fromReplace(e, this.pos, this.pos + 1, new O(A.from(i), 0, t.isLeaf ? 0 : 1));
  }
  getMap() {
    return Ze.empty;
  }
  invert(e) {
    return new mr(this.pos, this.attr, e.nodeAt(this.pos).attrs[this.attr]);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new mr(t.pos, this.attr, this.value);
  }
  toJSON() {
    return { stepType: "attr", pos: this.pos, attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number" || typeof t.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new mr(t.pos, t.attr, t.value);
  }
}
Le.jsonID("attr", mr);
class ai extends Le {
  /**
  Construct an attribute step.
  */
  constructor(e, t) {
    super(), this.attr = e, this.value = t;
  }
  apply(e) {
    let t = /* @__PURE__ */ Object.create(null);
    for (let i in e.attrs)
      t[i] = e.attrs[i];
    t[this.attr] = this.value;
    let r = e.type.create(t, e.content, e.marks);
    return me.ok(r);
  }
  getMap() {
    return Ze.empty;
  }
  invert(e) {
    return new ai(this.attr, e.attrs[this.attr]);
  }
  map(e) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new ai(t.attr, t.value);
  }
}
Le.jsonID("docAttr", ai);
let _r = class extends Error {
};
_r = function n(e) {
  let t = Error.call(this, e);
  return t.__proto__ = n.prototype, t;
};
_r.prototype = Object.create(Error.prototype);
_r.prototype.constructor = _r;
_r.prototype.name = "TransformError";
class Nh {
  /**
  Create a transform that starts with the given document.
  */
  constructor(e) {
    this.doc = e, this.steps = [], this.docs = [], this.mapping = new li();
  }
  /**
  The starting document.
  */
  get before() {
    return this.docs.length ? this.docs[0] : this.doc;
  }
  /**
  Apply a new step in this transform, saving the result. Throws an
  error when the step fails.
  */
  step(e) {
    let t = this.maybeStep(e);
    if (t.failed)
      throw new _r(t.failed);
    return this;
  }
  /**
  Try to apply a step in this transformation, ignoring it if it
  fails. Returns the step result.
  */
  maybeStep(e) {
    let t = e.apply(this.doc);
    return t.failed || this.addStep(e, t.doc), t;
  }
  /**
  True when the document has been changed (when there are any
  steps).
  */
  get docChanged() {
    return this.steps.length > 0;
  }
  /**
  @internal
  */
  addStep(e, t) {
    this.docs.push(this.doc), this.steps.push(e), this.mapping.appendMap(e.getMap()), this.doc = t;
  }
  /**
  Replace the part of the document between `from` and `to` with the
  given `slice`.
  */
  replace(e, t = e, r = O.empty) {
    let i = lo(this.doc, e, t, r);
    return i && this.step(i), this;
  }
  /**
  Replace the given range with the given content, which may be a
  fragment, node, or array of nodes.
  */
  replaceWith(e, t, r) {
    return this.replace(e, t, new O(A.from(r), 0, 0));
  }
  /**
  Delete the content between the given positions.
  */
  delete(e, t) {
    return this.replace(e, t, O.empty);
  }
  /**
  Insert the given content at the given position.
  */
  insert(e, t) {
    return this.replaceWith(e, e, t);
  }
  /**
  Replace a range of the document with a given slice, using
  `from`, `to`, and the slice's
  [`openStart`](https://prosemirror.net/docs/ref/#model.Slice.openStart) property as hints, rather
  than fixed start and end points. This method may grow the
  replaced area or close open nodes in the slice in order to get a
  fit that is more in line with WYSIWYG expectations, by dropping
  fully covered parent nodes of the replaced region when they are
  marked [non-defining as
  context](https://prosemirror.net/docs/ref/#model.NodeSpec.definingAsContext), or including an
  open parent node from the slice that _is_ marked as [defining
  its content](https://prosemirror.net/docs/ref/#model.NodeSpec.definingForContent).
  
  This is the method, for example, to handle paste. The similar
  [`replace`](https://prosemirror.net/docs/ref/#transform.Transform.replace) method is a more
  primitive tool which will _not_ move the start and end of its given
  range, and is useful in situations where you need more precise
  control over what happens.
  */
  replaceRange(e, t, r) {
    return W1(this, e, t, r), this;
  }
  /**
  Replace the given range with a node, but use `from` and `to` as
  hints, rather than precise positions. When from and to are the same
  and are at the start or end of a parent node in which the given
  node doesn't fit, this method may _move_ them out towards a parent
  that does allow the given node to be placed. When the given range
  completely covers a parent node, this method may completely replace
  that parent node.
  */
  replaceRangeWith(e, t, r) {
    return K1(this, e, t, r), this;
  }
  /**
  Delete the given range, expanding it to cover fully covered
  parent nodes until a valid replace is found.
  */
  deleteRange(e, t) {
    return G1(this, e, t), this;
  }
  /**
  Split the content in the given range off from its parent, if there
  is sibling content before or after it, and move it up the tree to
  the depth specified by `target`. You'll probably want to use
  [`liftTarget`](https://prosemirror.net/docs/ref/#transform.liftTarget) to compute `target`, to make
  sure the lift is valid.
  */
  lift(e, t) {
    return $1(this, e, t), this;
  }
  /**
  Join the blocks around the given position. If depth is 2, their
  last and first siblings are also joined, and so on.
  */
  join(e, t = 1) {
    return H1(this, e, t), this;
  }
  /**
  Wrap the given [range](https://prosemirror.net/docs/ref/#model.NodeRange) in the given set of wrappers.
  The wrappers are assumed to be valid in this position, and should
  probably be computed with [`findWrapping`](https://prosemirror.net/docs/ref/#transform.findWrapping).
  */
  wrap(e, t) {
    return I1(this, e, t), this;
  }
  /**
  Set the type of all textblocks (partly) between `from` and `to` to
  the given node type with the given attributes.
  */
  setBlockType(e, t = e, r, i = null) {
    return R1(this, e, t, r, i), this;
  }
  /**
  Change the type, attributes, and/or marks of the node at `pos`.
  When `type` isn't given, the existing node type is preserved,
  */
  setNodeMarkup(e, t, r = null, i) {
    return P1(this, e, t, r, i), this;
  }
  /**
  Set a single attribute on a given node to a new value.
  The `pos` addresses the document content. Use `setDocAttribute`
  to set attributes on the document itself.
  */
  setNodeAttribute(e, t, r) {
    return this.step(new mr(e, t, r)), this;
  }
  /**
  Set a single attribute on the document to a new value.
  */
  setDocAttribute(e, t) {
    return this.step(new ai(e, t)), this;
  }
  /**
  Add a mark to the node at position `pos`.
  */
  addNodeMark(e, t) {
    return this.step(new pn(e, t)), this;
  }
  /**
  Remove a mark (or all marks of the given type) from the node at
  position `pos`.
  */
  removeNodeMark(e, t) {
    let r = this.doc.nodeAt(e);
    if (!r)
      throw new RangeError("No node at position " + e);
    if (t instanceof Z)
      t.isInSet(r.marks) && this.step(new zn(e, t));
    else {
      let i = r.marks, s, o = [];
      for (; s = t.isInSet(i); )
        o.push(new zn(e, s)), i = s.removeFromSet(i);
      for (let l = o.length - 1; l >= 0; l--)
        this.step(o[l]);
    }
    return this;
  }
  /**
  Split the node at the given position, and optionally, if `depth` is
  greater than one, any number of nodes above that. By default, the
  parts split off will inherit the node type of the original node.
  This can be changed by passing an array of types and attributes to
  use after the split (with the outermost nodes coming first).
  */
  split(e, t = 1, r) {
    return B1(this, e, t, r), this;
  }
  /**
  Add the given mark to the inline content between `from` and `to`.
  */
  addMark(e, t, r) {
    return T1(this, e, t, r), this;
  }
  /**
  Remove marks from inline nodes between `from` and `to`. When
  `mark` is a single mark, remove precisely that mark. When it is
  a mark type, remove all marks of that type. When it is null,
  remove all marks of any type.
  */
  removeMark(e, t, r) {
    return M1(this, e, t, r), this;
  }
  /**
  Removes all marks and nodes from the content of the node at
  `pos` that don't match the given new parent node type. Accepts
  an optional starting [content match](https://prosemirror.net/docs/ref/#model.ContentMatch) as
  third argument.
  */
  clearIncompatible(e, t, r) {
    return ga(this, e, t, r), this;
  }
}
const Xo = /* @__PURE__ */ Object.create(null);
class V {
  /**
  Initialize a selection with the head and anchor and ranges. If no
  ranges are given, constructs a single range across `$anchor` and
  `$head`.
  */
  constructor(e, t, r) {
    this.$anchor = e, this.$head = t, this.ranges = r || [new J1(e.min(t), e.max(t))];
  }
  /**
  The selection's anchor, as an unresolved position.
  */
  get anchor() {
    return this.$anchor.pos;
  }
  /**
  The selection's head.
  */
  get head() {
    return this.$head.pos;
  }
  /**
  The lower bound of the selection's main range.
  */
  get from() {
    return this.$from.pos;
  }
  /**
  The upper bound of the selection's main range.
  */
  get to() {
    return this.$to.pos;
  }
  /**
  The resolved lower  bound of the selection's main range.
  */
  get $from() {
    return this.ranges[0].$from;
  }
  /**
  The resolved upper bound of the selection's main range.
  */
  get $to() {
    return this.ranges[0].$to;
  }
  /**
  Indicates whether the selection contains any content.
  */
  get empty() {
    let e = this.ranges;
    for (let t = 0; t < e.length; t++)
      if (e[t].$from.pos != e[t].$to.pos)
        return !1;
    return !0;
  }
  /**
  Get the content of this selection as a slice.
  */
  content() {
    return this.$from.doc.slice(this.from, this.to, !0);
  }
  /**
  Replace the selection with a slice or, if no slice is given,
  delete the selection. Will append to the given transaction.
  */
  replace(e, t = O.empty) {
    let r = t.content.lastChild, i = null;
    for (let l = 0; l < t.openEnd; l++)
      i = r, r = r.lastChild;
    let s = e.steps.length, o = this.ranges;
    for (let l = 0; l < o.length; l++) {
      let { $from: a, $to: c } = o[l], u = e.mapping.slice(s);
      e.replaceRange(u.map(a.pos), u.map(c.pos), l ? O.empty : t), l == 0 && Wu(e, s, (r ? r.isInline : i && i.isTextblock) ? -1 : 1);
    }
  }
  /**
  Replace the selection with the given node, appending the changes
  to the given transaction.
  */
  replaceWith(e, t) {
    let r = e.steps.length, i = this.ranges;
    for (let s = 0; s < i.length; s++) {
      let { $from: o, $to: l } = i[s], a = e.mapping.slice(r), c = a.map(o.pos), u = a.map(l.pos);
      s ? e.deleteRange(c, u) : (e.replaceRangeWith(c, u, t), Wu(e, r, t.isInline ? -1 : 1));
    }
  }
  /**
  Find a valid cursor or leaf node selection starting at the given
  position and searching back if `dir` is negative, and forward if
  positive. When `textOnly` is true, only consider cursor
  selections. Will return null when no valid selection position is
  found.
  */
  static findFrom(e, t, r = !1) {
    let i = e.parent.inlineContent ? new z(e) : lr(e.node(0), e.parent, e.pos, e.index(), t, r);
    if (i)
      return i;
    for (let s = e.depth - 1; s >= 0; s--) {
      let o = t < 0 ? lr(e.node(0), e.node(s), e.before(s + 1), e.index(s), t, r) : lr(e.node(0), e.node(s), e.after(s + 1), e.index(s) + 1, t, r);
      if (o)
        return o;
    }
    return null;
  }
  /**
  Find a valid cursor or leaf node selection near the given
  position. Searches forward first by default, but if `bias` is
  negative, it will search backwards first.
  */
  static near(e, t = 1) {
    return this.findFrom(e, t) || this.findFrom(e, -t) || new Qe(e.node(0));
  }
  /**
  Find the cursor or leaf node selection closest to the start of
  the given document. Will return an
  [`AllSelection`](https://prosemirror.net/docs/ref/#state.AllSelection) if no valid position
  exists.
  */
  static atStart(e) {
    return lr(e, e, 0, 0, 1) || new Qe(e);
  }
  /**
  Find the cursor or leaf node selection closest to the end of the
  given document.
  */
  static atEnd(e) {
    return lr(e, e, e.content.size, e.childCount, -1) || new Qe(e);
  }
  /**
  Deserialize the JSON representation of a selection. Must be
  implemented for custom classes (as a static class method).
  */
  static fromJSON(e, t) {
    if (!t || !t.type)
      throw new RangeError("Invalid input for Selection.fromJSON");
    let r = Xo[t.type];
    if (!r)
      throw new RangeError(`No selection type ${t.type} defined`);
    return r.fromJSON(e, t);
  }
  /**
  To be able to deserialize selections from JSON, custom selection
  classes must register themselves with an ID string, so that they
  can be disambiguated. Try to pick something that's unlikely to
  clash with classes from other modules.
  */
  static jsonID(e, t) {
    if (e in Xo)
      throw new RangeError("Duplicate use of selection JSON ID " + e);
    return Xo[e] = t, t.prototype.jsonID = e, t;
  }
  /**
  Get a [bookmark](https://prosemirror.net/docs/ref/#state.SelectionBookmark) for this selection,
  which is a value that can be mapped without having access to a
  current document, and later resolved to a real selection for a
  given document again. (This is used mostly by the history to
  track and restore old selections.) The default implementation of
  this method just converts the selection to a text selection and
  returns the bookmark for that.
  */
  getBookmark() {
    return z.between(this.$anchor, this.$head).getBookmark();
  }
}
V.prototype.visible = !0;
class J1 {
  /**
  Create a range.
  */
  constructor(e, t) {
    this.$from = e, this.$to = t;
  }
}
let Uu = !1;
function ju(n) {
  !Uu && !n.parent.inlineContent && (Uu = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + n.parent.type.name + ")"));
}
class z extends V {
  /**
  Construct a text selection between the given points.
  */
  constructor(e, t = e) {
    ju(e), ju(t), super(e, t);
  }
  /**
  Returns a resolved position if this is a cursor selection (an
  empty text selection), and null otherwise.
  */
  get $cursor() {
    return this.$anchor.pos == this.$head.pos ? this.$head : null;
  }
  map(e, t) {
    let r = e.resolve(t.map(this.head));
    if (!r.parent.inlineContent)
      return V.near(r);
    let i = e.resolve(t.map(this.anchor));
    return new z(i.parent.inlineContent ? i : r, r);
  }
  replace(e, t = O.empty) {
    if (super.replace(e, t), t == O.empty) {
      let r = this.$from.marksAcross(this.$to);
      r && e.ensureMarks(r);
    }
  }
  eq(e) {
    return e instanceof z && e.anchor == this.anchor && e.head == this.head;
  }
  getBookmark() {
    return new ao(this.anchor, this.head);
  }
  toJSON() {
    return { type: "text", anchor: this.anchor, head: this.head };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number" || typeof t.head != "number")
      throw new RangeError("Invalid input for TextSelection.fromJSON");
    return new z(e.resolve(t.anchor), e.resolve(t.head));
  }
  /**
  Create a text selection from non-resolved positions.
  */
  static create(e, t, r = t) {
    let i = e.resolve(t);
    return new this(i, r == t ? i : e.resolve(r));
  }
  /**
  Return a text selection that spans the given positions or, if
  they aren't text positions, find a text selection near them.
  `bias` determines whether the method searches forward (default)
  or backwards (negative number) first. Will fall back to calling
  [`Selection.near`](https://prosemirror.net/docs/ref/#state.Selection^near) when the document
  doesn't contain a valid text position.
  */
  static between(e, t, r) {
    let i = e.pos - t.pos;
    if ((!r || i) && (r = i >= 0 ? 1 : -1), !t.parent.inlineContent) {
      let s = V.findFrom(t, r, !0) || V.findFrom(t, -r, !0);
      if (s)
        t = s.$head;
      else
        return V.near(t, r);
    }
    return e.parent.inlineContent || (i == 0 ? e = t : (e = (V.findFrom(e, -r, !0) || V.findFrom(e, r, !0)).$anchor, e.pos < t.pos != i < 0 && (e = t))), new z(e, t);
  }
}
V.jsonID("text", z);
class ao {
  constructor(e, t) {
    this.anchor = e, this.head = t;
  }
  map(e) {
    return new ao(e.map(this.anchor), e.map(this.head));
  }
  resolve(e) {
    return z.between(e.resolve(this.anchor), e.resolve(this.head));
  }
}
class B extends V {
  /**
  Create a node selection. Does not verify the validity of its
  argument.
  */
  constructor(e) {
    let t = e.nodeAfter, r = e.node(0).resolve(e.pos + t.nodeSize);
    super(e, r), this.node = t;
  }
  map(e, t) {
    let { deleted: r, pos: i } = t.mapResult(this.anchor), s = e.resolve(i);
    return r ? V.near(s) : new B(s);
  }
  content() {
    return new O(A.from(this.node), 0, 0);
  }
  eq(e) {
    return e instanceof B && e.anchor == this.anchor;
  }
  toJSON() {
    return { type: "node", anchor: this.anchor };
  }
  getBookmark() {
    return new ya(this.anchor);
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number")
      throw new RangeError("Invalid input for NodeSelection.fromJSON");
    return new B(e.resolve(t.anchor));
  }
  /**
  Create a node selection from non-resolved positions.
  */
  static create(e, t) {
    return new B(e.resolve(t));
  }
  /**
  Determines whether the given node may be selected as a node
  selection.
  */
  static isSelectable(e) {
    return !e.isText && e.type.spec.selectable !== !1;
  }
}
B.prototype.visible = !1;
V.jsonID("node", B);
class ya {
  constructor(e) {
    this.anchor = e;
  }
  map(e) {
    let { deleted: t, pos: r } = e.mapResult(this.anchor);
    return t ? new ao(r, r) : new ya(r);
  }
  resolve(e) {
    let t = e.resolve(this.anchor), r = t.nodeAfter;
    return r && B.isSelectable(r) ? new B(t) : V.near(t);
  }
}
class Qe extends V {
  /**
  Create an all-selection over the given document.
  */
  constructor(e) {
    super(e.resolve(0), e.resolve(e.content.size));
  }
  replace(e, t = O.empty) {
    if (t == O.empty) {
      e.delete(0, e.doc.content.size);
      let r = V.atStart(e.doc);
      r.eq(e.selection) || e.setSelection(r);
    } else
      super.replace(e, t);
  }
  toJSON() {
    return { type: "all" };
  }
  /**
  @internal
  */
  static fromJSON(e) {
    return new Qe(e);
  }
  map(e) {
    return new Qe(e);
  }
  eq(e) {
    return e instanceof Qe;
  }
  getBookmark() {
    return Y1;
  }
}
V.jsonID("all", Qe);
const Y1 = {
  map() {
    return this;
  },
  resolve(n) {
    return new Qe(n);
  }
};
function lr(n, e, t, r, i, s = !1) {
  if (e.inlineContent)
    return z.create(n, t);
  for (let o = r - (i > 0 ? 0 : 1); i > 0 ? o < e.childCount : o >= 0; o += i) {
    let l = e.child(o);
    if (l.isAtom) {
      if (!s && B.isSelectable(l))
        return B.create(n, t - (i < 0 ? l.nodeSize : 0));
    } else {
      let a = lr(n, l, t + i, i < 0 ? l.childCount : 0, i, s);
      if (a)
        return a;
    }
    t += l.nodeSize * i;
  }
  return null;
}
function Wu(n, e, t) {
  let r = n.steps.length - 1;
  if (r < e)
    return;
  let i = n.steps[r];
  if (!(i instanceof Ee || i instanceof De))
    return;
  let s = n.mapping.maps[r], o;
  s.forEach((l, a, c, u) => {
    o == null && (o = u);
  }), n.setSelection(V.near(n.doc.resolve(o), t));
}
const Ku = 1, ji = 2, Gu = 4;
class X1 extends Nh {
  /**
  @internal
  */
  constructor(e) {
    super(e.doc), this.curSelectionFor = 0, this.updated = 0, this.meta = /* @__PURE__ */ Object.create(null), this.time = Date.now(), this.curSelection = e.selection, this.storedMarks = e.storedMarks;
  }
  /**
  The transaction's current selection. This defaults to the editor
  selection [mapped](https://prosemirror.net/docs/ref/#state.Selection.map) through the steps in the
  transaction, but can be overwritten with
  [`setSelection`](https://prosemirror.net/docs/ref/#state.Transaction.setSelection).
  */
  get selection() {
    return this.curSelectionFor < this.steps.length && (this.curSelection = this.curSelection.map(this.doc, this.mapping.slice(this.curSelectionFor)), this.curSelectionFor = this.steps.length), this.curSelection;
  }
  /**
  Update the transaction's current selection. Will determine the
  selection that the editor gets when the transaction is applied.
  */
  setSelection(e) {
    if (e.$from.doc != this.doc)
      throw new RangeError("Selection passed to setSelection must point at the current document");
    return this.curSelection = e, this.curSelectionFor = this.steps.length, this.updated = (this.updated | Ku) & ~ji, this.storedMarks = null, this;
  }
  /**
  Whether the selection was explicitly updated by this transaction.
  */
  get selectionSet() {
    return (this.updated & Ku) > 0;
  }
  /**
  Set the current stored marks.
  */
  setStoredMarks(e) {
    return this.storedMarks = e, this.updated |= ji, this;
  }
  /**
  Make sure the current stored marks or, if that is null, the marks
  at the selection, match the given set of marks. Does nothing if
  this is already the case.
  */
  ensureMarks(e) {
    return Z.sameSet(this.storedMarks || this.selection.$from.marks(), e) || this.setStoredMarks(e), this;
  }
  /**
  Add a mark to the set of stored marks.
  */
  addStoredMark(e) {
    return this.ensureMarks(e.addToSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Remove a mark or mark type from the set of stored marks.
  */
  removeStoredMark(e) {
    return this.ensureMarks(e.removeFromSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Whether the stored marks were explicitly set for this transaction.
  */
  get storedMarksSet() {
    return (this.updated & ji) > 0;
  }
  /**
  @internal
  */
  addStep(e, t) {
    super.addStep(e, t), this.updated = this.updated & ~ji, this.storedMarks = null;
  }
  /**
  Update the timestamp for the transaction.
  */
  setTime(e) {
    return this.time = e, this;
  }
  /**
  Replace the current selection with the given slice.
  */
  replaceSelection(e) {
    return this.selection.replace(this, e), this;
  }
  /**
  Replace the selection with the given node. When `inheritMarks` is
  true and the content is inline, it inherits the marks from the
  place where it is inserted.
  */
  replaceSelectionWith(e, t = !0) {
    let r = this.selection;
    return t && (e = e.mark(this.storedMarks || (r.empty ? r.$from.marks() : r.$from.marksAcross(r.$to) || Z.none))), r.replaceWith(this, e), this;
  }
  /**
  Delete the selection.
  */
  deleteSelection() {
    return this.selection.replace(this), this;
  }
  /**
  Replace the given range, or the selection if no range is given,
  with a text node containing the given string.
  */
  insertText(e, t, r) {
    let i = this.doc.type.schema;
    if (t == null)
      return e ? this.replaceSelectionWith(i.text(e), !0) : this.deleteSelection();
    {
      if (r == null && (r = t), r = r ?? t, !e)
        return this.deleteRange(t, r);
      let s = this.storedMarks;
      if (!s) {
        let o = this.doc.resolve(t);
        s = r == t ? o.marks() : o.marksAcross(this.doc.resolve(r));
      }
      return this.replaceRangeWith(t, r, i.text(e, s)), this.selection.empty || this.setSelection(V.near(this.selection.$to)), this;
    }
  }
  /**
  Store a metadata property in this transaction, keyed either by
  name or by plugin.
  */
  setMeta(e, t) {
    return this.meta[typeof e == "string" ? e : e.key] = t, this;
  }
  /**
  Retrieve a metadata property for a given name or plugin.
  */
  getMeta(e) {
    return this.meta[typeof e == "string" ? e : e.key];
  }
  /**
  Returns true if this transaction doesn't contain any metadata,
  and can thus safely be extended.
  */
  get isGeneric() {
    for (let e in this.meta)
      return !1;
    return !0;
  }
  /**
  Indicate that the editor should scroll the selection into view
  when updated to the state produced by this transaction.
  */
  scrollIntoView() {
    return this.updated |= Gu, this;
  }
  /**
  True when this transaction has had `scrollIntoView` called on it.
  */
  get scrolledIntoView() {
    return (this.updated & Gu) > 0;
  }
}
function Ju(n, e) {
  return !e || !n ? n : n.bind(e);
}
class Br {
  constructor(e, t, r) {
    this.name = e, this.init = Ju(t.init, r), this.apply = Ju(t.apply, r);
  }
}
const Z1 = [
  new Br("doc", {
    init(n) {
      return n.doc || n.schema.topNodeType.createAndFill();
    },
    apply(n) {
      return n.doc;
    }
  }),
  new Br("selection", {
    init(n, e) {
      return n.selection || V.atStart(e.doc);
    },
    apply(n) {
      return n.selection;
    }
  }),
  new Br("storedMarks", {
    init(n) {
      return n.storedMarks || null;
    },
    apply(n, e, t, r) {
      return r.selection.$cursor ? n.storedMarks : null;
    }
  }),
  new Br("scrollToSelection", {
    init() {
      return 0;
    },
    apply(n, e) {
      return n.scrolledIntoView ? e + 1 : e;
    }
  })
];
class Zo {
  constructor(e, t) {
    this.schema = e, this.plugins = [], this.pluginsByKey = /* @__PURE__ */ Object.create(null), this.fields = Z1.slice(), t && t.forEach((r) => {
      if (this.pluginsByKey[r.key])
        throw new RangeError("Adding different instances of a keyed plugin (" + r.key + ")");
      this.plugins.push(r), this.pluginsByKey[r.key] = r, r.spec.state && this.fields.push(new Br(r.key, r.spec.state, r));
    });
  }
}
class fr {
  /**
  @internal
  */
  constructor(e) {
    this.config = e;
  }
  /**
  The schema of the state's document.
  */
  get schema() {
    return this.config.schema;
  }
  /**
  The plugins that are active in this state.
  */
  get plugins() {
    return this.config.plugins;
  }
  /**
  Apply the given transaction to produce a new state.
  */
  apply(e) {
    return this.applyTransaction(e).state;
  }
  /**
  @internal
  */
  filterTransaction(e, t = -1) {
    for (let r = 0; r < this.config.plugins.length; r++)
      if (r != t) {
        let i = this.config.plugins[r];
        if (i.spec.filterTransaction && !i.spec.filterTransaction.call(i, e, this))
          return !1;
      }
    return !0;
  }
  /**
  Verbose variant of [`apply`](https://prosemirror.net/docs/ref/#state.EditorState.apply) that
  returns the precise transactions that were applied (which might
  be influenced by the [transaction
  hooks](https://prosemirror.net/docs/ref/#state.PluginSpec.filterTransaction) of
  plugins) along with the new state.
  */
  applyTransaction(e) {
    if (!this.filterTransaction(e))
      return { state: this, transactions: [] };
    let t = [e], r = this.applyInner(e), i = null;
    for (; ; ) {
      let s = !1;
      for (let o = 0; o < this.config.plugins.length; o++) {
        let l = this.config.plugins[o];
        if (l.spec.appendTransaction) {
          let a = i ? i[o].n : 0, c = i ? i[o].state : this, u = a < t.length && l.spec.appendTransaction.call(l, a ? t.slice(a) : t, c, r);
          if (u && r.filterTransaction(u, o)) {
            if (u.setMeta("appendedTransaction", e), !i) {
              i = [];
              for (let d = 0; d < this.config.plugins.length; d++)
                i.push(d < o ? { state: r, n: t.length } : { state: this, n: 0 });
            }
            t.push(u), r = r.applyInner(u), s = !0;
          }
          i && (i[o] = { state: r, n: t.length });
        }
      }
      if (!s)
        return { state: r, transactions: t };
    }
  }
  /**
  @internal
  */
  applyInner(e) {
    if (!e.before.eq(this.doc))
      throw new RangeError("Applying a mismatched transaction");
    let t = new fr(this.config), r = this.config.fields;
    for (let i = 0; i < r.length; i++) {
      let s = r[i];
      t[s.name] = s.apply(e, this[s.name], this, t);
    }
    return t;
  }
  /**
  Start a [transaction](https://prosemirror.net/docs/ref/#state.Transaction) from this state.
  */
  get tr() {
    return new X1(this);
  }
  /**
  Create a new state.
  */
  static create(e) {
    let t = new Zo(e.doc ? e.doc.type.schema : e.schema, e.plugins), r = new fr(t);
    for (let i = 0; i < t.fields.length; i++)
      r[t.fields[i].name] = t.fields[i].init(e, r);
    return r;
  }
  /**
  Create a new state based on this one, but with an adjusted set
  of active plugins. State fields that exist in both sets of
  plugins are kept unchanged. Those that no longer exist are
  dropped, and those that are new are initialized using their
  [`init`](https://prosemirror.net/docs/ref/#state.StateField.init) method, passing in the new
  configuration object..
  */
  reconfigure(e) {
    let t = new Zo(this.schema, e.plugins), r = t.fields, i = new fr(t);
    for (let s = 0; s < r.length; s++) {
      let o = r[s].name;
      i[o] = this.hasOwnProperty(o) ? this[o] : r[s].init(e, i);
    }
    return i;
  }
  /**
  Serialize this state to JSON. If you want to serialize the state
  of plugins, pass an object mapping property names to use in the
  resulting JSON object to plugin objects. The argument may also be
  a string or number, in which case it is ignored, to support the
  way `JSON.stringify` calls `toString` methods.
  */
  toJSON(e) {
    let t = { doc: this.doc.toJSON(), selection: this.selection.toJSON() };
    if (this.storedMarks && (t.storedMarks = this.storedMarks.map((r) => r.toJSON())), e && typeof e == "object")
      for (let r in e) {
        if (r == "doc" || r == "selection")
          throw new RangeError("The JSON fields `doc` and `selection` are reserved");
        let i = e[r], s = i.spec.state;
        s && s.toJSON && (t[r] = s.toJSON.call(i, this[i.key]));
      }
    return t;
  }
  /**
  Deserialize a JSON representation of a state. `config` should
  have at least a `schema` field, and should contain array of
  plugins to initialize the state with. `pluginFields` can be used
  to deserialize the state of plugins, by associating plugin
  instances with the property names they use in the JSON object.
  */
  static fromJSON(e, t, r) {
    if (!t)
      throw new RangeError("Invalid input for EditorState.fromJSON");
    if (!e.schema)
      throw new RangeError("Required config field 'schema' missing");
    let i = new Zo(e.schema, e.plugins), s = new fr(i);
    return i.fields.forEach((o) => {
      if (o.name == "doc")
        s.doc = Dt.fromJSON(e.schema, t.doc);
      else if (o.name == "selection")
        s.selection = V.fromJSON(s.doc, t.selection);
      else if (o.name == "storedMarks")
        t.storedMarks && (s.storedMarks = t.storedMarks.map(e.schema.markFromJSON));
      else {
        if (r)
          for (let l in r) {
            let a = r[l], c = a.spec.state;
            if (a.key == o.name && c && c.fromJSON && Object.prototype.hasOwnProperty.call(t, l)) {
              s[o.name] = c.fromJSON.call(a, e, t[l], s);
              return;
            }
          }
        s[o.name] = o.init(e, s);
      }
    }), s;
  }
}
function Ih(n, e, t) {
  for (let r in n) {
    let i = n[r];
    i instanceof Function ? i = i.bind(e) : r == "handleDOMEvents" && (i = Ih(i, e, {})), t[r] = i;
  }
  return t;
}
class ae {
  /**
  Create a plugin.
  */
  constructor(e) {
    this.spec = e, this.props = {}, e.props && Ih(e.props, this, this.props), this.key = e.key ? e.key.key : Rh("plugin");
  }
  /**
  Extract the plugin's state field from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const Qo = /* @__PURE__ */ Object.create(null);
function Rh(n) {
  return n in Qo ? n + "$" + ++Qo[n] : (Qo[n] = 0, n + "$");
}
class _e {
  /**
  Create a plugin key.
  */
  constructor(e = "key") {
    this.key = Rh(e);
  }
  /**
  Get the active plugin with this key, if any, from an editor
  state.
  */
  get(e) {
    return e.config.pluginsByKey[this.key];
  }
  /**
  Get the plugin's state from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const xe = function(n) {
  for (var e = 0; ; e++)
    if (n = n.previousSibling, !n)
      return e;
}, yr = function(n) {
  let e = n.assignedSlot || n.parentNode;
  return e && e.nodeType == 11 ? e.host : e;
};
let Ll = null;
const Jt = function(n, e, t) {
  let r = Ll || (Ll = document.createRange());
  return r.setEnd(n, t ?? n.nodeValue.length), r.setStart(n, e || 0), r;
}, Q1 = function() {
  Ll = null;
}, Hn = function(n, e, t, r) {
  return t && (Yu(n, e, t, r, -1) || Yu(n, e, t, r, 1));
}, eb = /^(img|br|input|textarea|hr)$/i;
function Yu(n, e, t, r, i) {
  for (var s; ; ) {
    if (n == t && e == r)
      return !0;
    if (e == (i < 0 ? 0 : lt(n))) {
      let o = n.parentNode;
      if (!o || o.nodeType != 1 || yi(n) || eb.test(n.nodeName) || n.contentEditable == "false")
        return !1;
      e = xe(n) + (i < 0 ? 0 : 1), n = o;
    } else if (n.nodeType == 1) {
      let o = n.childNodes[e + (i < 0 ? -1 : 0)];
      if (o.nodeType == 1 && o.contentEditable == "false")
        if (!((s = o.pmViewDesc) === null || s === void 0) && s.ignoreForSelection)
          e += i;
        else
          return !1;
      else
        n = o, e = i < 0 ? lt(n) : 0;
    } else
      return !1;
  }
}
function lt(n) {
  return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length;
}
function tb(n, e) {
  for (; ; ) {
    if (n.nodeType == 3 && e)
      return n;
    if (n.nodeType == 1 && e > 0) {
      if (n.contentEditable == "false")
        return null;
      n = n.childNodes[e - 1], e = lt(n);
    } else if (n.parentNode && !yi(n))
      e = xe(n), n = n.parentNode;
    else
      return null;
  }
}
function nb(n, e) {
  for (; ; ) {
    if (n.nodeType == 3 && e < n.nodeValue.length)
      return n;
    if (n.nodeType == 1 && e < n.childNodes.length) {
      if (n.contentEditable == "false")
        return null;
      n = n.childNodes[e], e = 0;
    } else if (n.parentNode && !yi(n))
      e = xe(n) + 1, n = n.parentNode;
    else
      return null;
  }
}
function rb(n, e, t) {
  for (let r = e == 0, i = e == lt(n); r || i; ) {
    if (n == t)
      return !0;
    let s = xe(n);
    if (n = n.parentNode, !n)
      return !1;
    r = r && s == 0, i = i && s == lt(n);
  }
}
function yi(n) {
  let e;
  for (let t = n; t && !(e = t.pmViewDesc); t = t.parentNode)
    ;
  return e && e.node && e.node.isBlock && (e.dom == n || e.contentDOM == n);
}
const co = function(n) {
  return n.focusNode && Hn(n.focusNode, n.focusOffset, n.anchorNode, n.anchorOffset);
};
function An(n, e) {
  let t = document.createEvent("Event");
  return t.initEvent("keydown", !0, !0), t.keyCode = n, t.key = t.code = e, t;
}
function ib(n) {
  let e = n.activeElement;
  for (; e && e.shadowRoot; )
    e = e.shadowRoot.activeElement;
  return e;
}
function sb(n, e, t) {
  if (n.caretPositionFromPoint)
    try {
      let r = n.caretPositionFromPoint(e, t);
      if (r)
        return { node: r.offsetNode, offset: Math.min(lt(r.offsetNode), r.offset) };
    } catch {
    }
  if (n.caretRangeFromPoint) {
    let r = n.caretRangeFromPoint(e, t);
    if (r)
      return { node: r.startContainer, offset: Math.min(lt(r.startContainer), r.startOffset) };
  }
}
const Pt = typeof navigator < "u" ? navigator : null, Xu = typeof document < "u" ? document : null, vn = Pt && Pt.userAgent || "", Pl = /Edge\/(\d+)/.exec(vn), Lh = /MSIE \d/.exec(vn), Bl = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(vn), Ge = !!(Lh || Bl || Pl), gn = Lh ? document.documentMode : Bl ? +Bl[1] : Pl ? +Pl[1] : 0, St = !Ge && /gecko\/(\d+)/i.test(vn);
St && +(/Firefox\/(\d+)/.exec(vn) || [0, 0])[1];
const zl = !Ge && /Chrome\/(\d+)/.exec(vn), Re = !!zl, Ph = zl ? +zl[1] : 0, qe = !Ge && !!Pt && /Apple Computer/.test(Pt.vendor), br = qe && (/Mobile\/\w+/.test(vn) || !!Pt && Pt.maxTouchPoints > 2), ot = br || (Pt ? /Mac/.test(Pt.platform) : !1), ob = Pt ? /Win/.test(Pt.platform) : !1, Yt = /Android \d/.test(vn), bi = !!Xu && "webkitFontSmoothing" in Xu.documentElement.style, lb = bi ? +(/\bAppleWebKit\/(\d+)/.exec(navigator.userAgent) || [0, 0])[1] : 0;
function ab(n) {
  let e = n.defaultView && n.defaultView.visualViewport;
  return e ? {
    left: 0,
    right: e.width,
    top: 0,
    bottom: e.height
  } : {
    left: 0,
    right: n.documentElement.clientWidth,
    top: 0,
    bottom: n.documentElement.clientHeight
  };
}
function Vt(n, e) {
  return typeof n == "number" ? n : n[e];
}
function cb(n) {
  let e = n.getBoundingClientRect(), t = e.width / n.offsetWidth || 1, r = e.height / n.offsetHeight || 1;
  return {
    left: e.left,
    right: e.left + n.clientWidth * t,
    top: e.top,
    bottom: e.top + n.clientHeight * r
  };
}
function Zu(n, e, t) {
  let r = n.someProp("scrollThreshold") || 0, i = n.someProp("scrollMargin") || 5, s = n.dom.ownerDocument;
  for (let o = t || n.dom; o; ) {
    if (o.nodeType != 1) {
      o = yr(o);
      continue;
    }
    let l = o, a = l == s.body, c = a ? ab(s) : cb(l), u = 0, d = 0;
    if (e.top < c.top + Vt(r, "top") ? d = -(c.top - e.top + Vt(i, "top")) : e.bottom > c.bottom - Vt(r, "bottom") && (d = e.bottom - e.top > c.bottom - c.top ? e.top + Vt(i, "top") - c.top : e.bottom - c.bottom + Vt(i, "bottom")), e.left < c.left + Vt(r, "left") ? u = -(c.left - e.left + Vt(i, "left")) : e.right > c.right - Vt(r, "right") && (u = e.right - c.right + Vt(i, "right")), u || d)
      if (a)
        s.defaultView.scrollBy(u, d);
      else {
        let h = l.scrollLeft, p = l.scrollTop;
        d && (l.scrollTop += d), u && (l.scrollLeft += u);
        let m = l.scrollLeft - h, _ = l.scrollTop - p;
        e = { left: e.left - m, top: e.top - _, right: e.right - m, bottom: e.bottom - _ };
      }
    let f = a ? "fixed" : getComputedStyle(o).position;
    if (/^(fixed|sticky)$/.test(f))
      break;
    o = f == "absolute" ? o.offsetParent : yr(o);
  }
}
function ub(n) {
  let e = n.dom.getBoundingClientRect(), t = Math.max(0, e.top), r, i;
  for (let s = (e.left + e.right) / 2, o = t + 1; o < Math.min(innerHeight, e.bottom); o += 5) {
    let l = n.root.elementFromPoint(s, o);
    if (!l || l == n.dom || !n.dom.contains(l))
      continue;
    let a = l.getBoundingClientRect();
    if (a.top >= t - 20) {
      r = l, i = a.top;
      break;
    }
  }
  return { refDOM: r, refTop: i, stack: Bh(n.dom) };
}
function Bh(n) {
  let e = [], t = n.ownerDocument;
  for (let r = n; r && (e.push({ dom: r, top: r.scrollTop, left: r.scrollLeft }), n != t); r = yr(r))
    ;
  return e;
}
function db({ refDOM: n, refTop: e, stack: t }) {
  let r = n ? n.getBoundingClientRect().top : 0;
  zh(t, r == 0 ? 0 : r - e);
}
function zh(n, e) {
  for (let t = 0; t < n.length; t++) {
    let { dom: r, top: i, left: s } = n[t];
    r.scrollTop != i + e && (r.scrollTop = i + e), r.scrollLeft != s && (r.scrollLeft = s);
  }
}
let sr = null;
function fb(n) {
  if (n.setActive)
    return n.setActive();
  if (sr)
    return n.focus(sr);
  let e = Bh(n);
  n.focus(sr == null ? {
    get preventScroll() {
      return sr = { preventScroll: !0 }, !0;
    }
  } : void 0), sr || (sr = !1, zh(e, 0));
}
function Hh(n, e) {
  let t, r = 2e8, i, s = 0, o = e.top, l = e.top, a, c;
  for (let u = n.firstChild, d = 0; u; u = u.nextSibling, d++) {
    let f;
    if (u.nodeType == 1)
      f = u.getClientRects();
    else if (u.nodeType == 3)
      f = Jt(u).getClientRects();
    else
      continue;
    for (let h = 0; h < f.length; h++) {
      let p = f[h];
      if (p.top <= o && p.bottom >= l) {
        o = Math.max(p.bottom, o), l = Math.min(p.top, l);
        let m = p.left > e.left ? p.left - e.left : p.right < e.left ? e.left - p.right : 0;
        if (m < r) {
          t = u, r = m, i = m && t.nodeType == 3 ? {
            left: p.right < e.left ? p.right : p.left,
            top: e.top
          } : e, u.nodeType == 1 && m && (s = d + (e.left >= (p.left + p.right) / 2 ? 1 : 0));
          continue;
        }
      } else p.top > e.top && !a && p.left <= e.left && p.right >= e.left && (a = u, c = { left: Math.max(p.left, Math.min(p.right, e.left)), top: p.top });
      !t && (e.left >= p.right && e.top >= p.top || e.left >= p.left && e.top >= p.bottom) && (s = d + 1);
    }
  }
  return !t && a && (t = a, i = c, r = 0), t && t.nodeType == 3 ? hb(t, i) : !t || r && t.nodeType == 1 ? { node: n, offset: s } : Hh(t, i);
}
function hb(n, e) {
  let t = n.nodeValue.length, r = document.createRange();
  for (let i = 0; i < t; i++) {
    r.setEnd(n, i + 1), r.setStart(n, i);
    let s = on(r, 1);
    if (s.top != s.bottom && ba(e, s))
      return { node: n, offset: i + (e.left >= (s.left + s.right) / 2 ? 1 : 0) };
  }
  return { node: n, offset: 0 };
}
function ba(n, e) {
  return n.left >= e.left - 1 && n.left <= e.right + 1 && n.top >= e.top - 1 && n.top <= e.bottom + 1;
}
function pb(n, e) {
  let t = n.parentNode;
  return t && /^li$/i.test(t.nodeName) && e.left < n.getBoundingClientRect().left ? t : n;
}
function mb(n, e, t) {
  let { node: r, offset: i } = Hh(e, t), s = -1;
  if (r.nodeType == 1 && !r.firstChild) {
    let o = r.getBoundingClientRect();
    s = o.left != o.right && t.left > (o.left + o.right) / 2 ? 1 : -1;
  }
  return n.docView.posFromDOM(r, i, s);
}
function gb(n, e, t, r) {
  let i = -1;
  for (let s = e, o = !1; s != n.dom; ) {
    let l = n.docView.nearestDesc(s, !0), a;
    if (!l)
      return null;
    if (l.dom.nodeType == 1 && (l.node.isBlock && l.parent || !l.contentDOM) && // Ignore elements with zero-size bounding rectangles
    ((a = l.dom.getBoundingClientRect()).width || a.height) && (l.node.isBlock && l.parent && !/^T(R|BODY|HEAD|FOOT)$/.test(l.dom.nodeName) && (!o && a.left > r.left || a.top > r.top ? i = l.posBefore : (!o && a.right < r.left || a.bottom < r.top) && (i = l.posAfter), o = !0), !l.contentDOM && i < 0 && !l.node.isText))
      return (l.node.isBlock ? r.top < (a.top + a.bottom) / 2 : r.left < (a.left + a.right) / 2) ? l.posBefore : l.posAfter;
    s = l.dom.parentNode;
  }
  return i > -1 ? i : n.docView.posFromDOM(e, t, -1);
}
function qh(n, e, t) {
  let r = n.childNodes.length;
  if (r && t.top < t.bottom)
    for (let i = Math.max(0, Math.min(r - 1, Math.floor(r * (e.top - t.top) / (t.bottom - t.top)) - 2)), s = i; ; ) {
      let o = n.childNodes[s];
      if (o.nodeType == 1) {
        let l = o.getClientRects();
        for (let a = 0; a < l.length; a++) {
          let c = l[a];
          if (ba(e, c))
            return qh(o, e, c);
        }
      }
      if ((s = (s + 1) % r) == i)
        break;
    }
  return n;
}
function _b(n, e) {
  let t = n.dom.ownerDocument, r, i = 0, s = sb(t, e.left, e.top);
  s && ({ node: r, offset: i } = s);
  let o = (n.root.elementFromPoint ? n.root : t).elementFromPoint(e.left, e.top), l;
  if (!o || !n.dom.contains(o.nodeType != 1 ? o.parentNode : o)) {
    let c = n.dom.getBoundingClientRect();
    if (!ba(e, c) || (o = qh(n.dom, e, c), !o))
      return null;
  }
  if (qe)
    for (let c = o; r && c; c = yr(c))
      c.draggable && (r = void 0);
  if (o = pb(o, e), r) {
    if (St && r.nodeType == 1 && (i = Math.min(i, r.childNodes.length), i < r.childNodes.length)) {
      let u = r.childNodes[i], d;
      u.nodeName == "IMG" && (d = u.getBoundingClientRect()).right <= e.left && d.bottom > e.top && i++;
    }
    let c;
    bi && i && r.nodeType == 1 && (c = r.childNodes[i - 1]).nodeType == 1 && c.contentEditable == "false" && c.getBoundingClientRect().top >= e.top && i--, r == n.dom && i == r.childNodes.length - 1 && r.lastChild.nodeType == 1 && e.top > r.lastChild.getBoundingClientRect().bottom ? l = n.state.doc.content.size : (i == 0 || r.nodeType != 1 || r.childNodes[i - 1].nodeName != "BR") && (l = gb(n, r, i, e));
  }
  l == null && (l = mb(n, o, e));
  let a = n.docView.nearestDesc(o, !0);
  return { pos: l, inside: a ? a.posAtStart - a.border : -1 };
}
function Qu(n) {
  return n.top < n.bottom || n.left < n.right;
}
function on(n, e) {
  let t = n.getClientRects();
  if (t.length) {
    let r = t[e < 0 ? 0 : t.length - 1];
    if (Qu(r))
      return r;
  }
  return Array.prototype.find.call(t, Qu) || n.getBoundingClientRect();
}
const yb = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/;
function Vh(n, e, t) {
  let { node: r, offset: i, atom: s } = n.docView.domFromPos(e, t < 0 ? -1 : 1), o = bi || St;
  if (r.nodeType == 3)
    if (o && (yb.test(r.nodeValue) || (t < 0 ? !i : i == r.nodeValue.length))) {
      let a = on(Jt(r, i, i), t);
      if (St && i && /\s/.test(r.nodeValue[i - 1]) && i < r.nodeValue.length) {
        let c = on(Jt(r, i - 1, i - 1), -1);
        if (c.top == a.top) {
          let u = on(Jt(r, i, i + 1), -1);
          if (u.top != a.top)
            return Nr(u, u.left < c.left);
        }
      }
      return a;
    } else {
      let a = i, c = i, u = t < 0 ? 1 : -1;
      return t < 0 && !i ? (c++, u = -1) : t >= 0 && i == r.nodeValue.length ? (a--, u = 1) : t < 0 ? a-- : c++, Nr(on(Jt(r, a, c), u), u < 0);
    }
  if (!n.state.doc.resolve(e - (s || 0)).parent.inlineContent) {
    if (s == null && i && (t < 0 || i == lt(r))) {
      let a = r.childNodes[i - 1];
      if (a.nodeType == 1)
        return el(a.getBoundingClientRect(), !1);
    }
    if (s == null && i < lt(r)) {
      let a = r.childNodes[i];
      if (a.nodeType == 1)
        return el(a.getBoundingClientRect(), !0);
    }
    return el(r.getBoundingClientRect(), t >= 0);
  }
  if (s == null && i && (t < 0 || i == lt(r))) {
    let a = r.childNodes[i - 1], c = a.nodeType == 3 ? Jt(a, lt(a) - (o ? 0 : 1)) : a.nodeType == 1 && (a.nodeName != "BR" || !a.nextSibling) ? a : null;
    if (c)
      return Nr(on(c, 1), !1);
  }
  if (s == null && i < lt(r)) {
    let a = r.childNodes[i];
    for (; a.pmViewDesc && a.pmViewDesc.ignoreForCoords; )
      a = a.nextSibling;
    let c = a ? a.nodeType == 3 ? Jt(a, 0, o ? 0 : 1) : a.nodeType == 1 ? a : null : null;
    if (c)
      return Nr(on(c, -1), !0);
  }
  return Nr(on(r.nodeType == 3 ? Jt(r) : r, -t), t >= 0);
}
function Nr(n, e) {
  if (n.width == 0)
    return n;
  let t = e ? n.left : n.right;
  return { top: n.top, bottom: n.bottom, left: t, right: t };
}
function el(n, e) {
  if (n.height == 0)
    return n;
  let t = e ? n.top : n.bottom;
  return { top: t, bottom: t, left: n.left, right: n.right };
}
function Uh(n, e, t) {
  let r = n.state, i = n.root.activeElement;
  r != e && n.updateState(e), i != n.dom && n.focus();
  try {
    return t();
  } finally {
    r != e && n.updateState(r), i != n.dom && i && i.focus();
  }
}
function bb(n, e, t) {
  let r = e.selection, i = t == "up" ? r.$from : r.$to;
  return Uh(n, e, () => {
    let { node: s } = n.docView.domFromPos(i.pos, t == "up" ? -1 : 1);
    for (; ; ) {
      let l = n.docView.nearestDesc(s, !0);
      if (!l)
        break;
      if (l.node.isBlock) {
        s = l.contentDOM || l.dom;
        break;
      }
      s = l.dom.parentNode;
    }
    let o = Vh(n, i.pos, 1);
    for (let l = s.firstChild; l; l = l.nextSibling) {
      let a;
      if (l.nodeType == 1)
        a = l.getClientRects();
      else if (l.nodeType == 3)
        a = Jt(l, 0, l.nodeValue.length).getClientRects();
      else
        continue;
      for (let c = 0; c < a.length; c++) {
        let u = a[c];
        if (u.bottom > u.top + 1 && (t == "up" ? o.top - u.top > (u.bottom - o.top) * 2 : u.bottom - o.bottom > (o.bottom - u.top) * 2))
          return !1;
      }
    }
    return !0;
  });
}
const kb = /[\u0590-\u08ac]/;
function wb(n, e, t) {
  let { $head: r } = e.selection;
  if (!r.parent.isTextblock)
    return !1;
  let i = r.parentOffset, s = !i, o = i == r.parent.content.size, l = n.domSelection();
  return l ? !kb.test(r.parent.textContent) || !l.modify ? t == "left" || t == "backward" ? s : o : Uh(n, e, () => {
    let { focusNode: a, focusOffset: c, anchorNode: u, anchorOffset: d } = n.domSelectionRange(), f = l.caretBidiLevel;
    l.modify("move", t, "character");
    let h = r.depth ? n.docView.domAfterPos(r.before()) : n.dom, { focusNode: p, focusOffset: m } = n.domSelectionRange(), _ = p && !h.contains(p.nodeType == 1 ? p : p.parentNode) || a == p && c == m;
    try {
      l.collapse(u, d), a && (a != u || c != d) && l.extend && l.extend(a, c);
    } catch {
    }
    return f != null && (l.caretBidiLevel = f), _;
  }) : r.pos == r.start() || r.pos == r.end();
}
let ed = null, td = null, nd = !1;
function vb(n, e, t) {
  return ed == e && td == t ? nd : (ed = e, td = t, nd = t == "up" || t == "down" ? bb(n, e, t) : wb(n, e, t));
}
const ut = 0, rd = 1, Tn = 2, Bt = 3;
class ki {
  constructor(e, t, r, i) {
    this.parent = e, this.children = t, this.dom = r, this.contentDOM = i, this.dirty = ut, r.pmViewDesc = this;
  }
  // Used to check whether a given description corresponds to a
  // widget/mark/node.
  matchesWidget(e) {
    return !1;
  }
  matchesMark(e) {
    return !1;
  }
  matchesNode(e, t, r) {
    return !1;
  }
  matchesHack(e) {
    return !1;
  }
  // When parsing in-editor content (in domchange.js), we allow
  // descriptions to determine the parse rules that should be used to
  // parse them.
  parseRule() {
    return null;
  }
  // Used by the editor's event handler to ignore events that come
  // from certain descs.
  stopEvent(e) {
    return !1;
  }
  // The size of the content represented by this desc.
  get size() {
    let e = 0;
    for (let t = 0; t < this.children.length; t++)
      e += this.children[t].size;
    return e;
  }
  // For block nodes, this represents the space taken up by their
  // start/end tokens.
  get border() {
    return 0;
  }
  destroy() {
    this.parent = void 0, this.dom.pmViewDesc == this && (this.dom.pmViewDesc = void 0);
    for (let e = 0; e < this.children.length; e++)
      this.children[e].destroy();
  }
  posBeforeChild(e) {
    for (let t = 0, r = this.posAtStart; ; t++) {
      let i = this.children[t];
      if (i == e)
        return r;
      r += i.size;
    }
  }
  get posBefore() {
    return this.parent.posBeforeChild(this);
  }
  get posAtStart() {
    return this.parent ? this.parent.posBeforeChild(this) + this.border : 0;
  }
  get posAfter() {
    return this.posBefore + this.size;
  }
  get posAtEnd() {
    return this.posAtStart + this.size - 2 * this.border;
  }
  localPosFromDOM(e, t, r) {
    if (this.contentDOM && this.contentDOM.contains(e.nodeType == 1 ? e : e.parentNode))
      if (r < 0) {
        let s, o;
        if (e == this.contentDOM)
          s = e.childNodes[t - 1];
        else {
          for (; e.parentNode != this.contentDOM; )
            e = e.parentNode;
          s = e.previousSibling;
        }
        for (; s && !((o = s.pmViewDesc) && o.parent == this); )
          s = s.previousSibling;
        return s ? this.posBeforeChild(o) + o.size : this.posAtStart;
      } else {
        let s, o;
        if (e == this.contentDOM)
          s = e.childNodes[t];
        else {
          for (; e.parentNode != this.contentDOM; )
            e = e.parentNode;
          s = e.nextSibling;
        }
        for (; s && !((o = s.pmViewDesc) && o.parent == this); )
          s = s.nextSibling;
        return s ? this.posBeforeChild(o) : this.posAtEnd;
      }
    let i;
    if (e == this.dom && this.contentDOM)
      i = t > xe(this.contentDOM);
    else if (this.contentDOM && this.contentDOM != this.dom && this.dom.contains(this.contentDOM))
      i = e.compareDocumentPosition(this.contentDOM) & 2;
    else if (this.dom.firstChild) {
      if (t == 0)
        for (let s = e; ; s = s.parentNode) {
          if (s == this.dom) {
            i = !1;
            break;
          }
          if (s.previousSibling)
            break;
        }
      if (i == null && t == e.childNodes.length)
        for (let s = e; ; s = s.parentNode) {
          if (s == this.dom) {
            i = !0;
            break;
          }
          if (s.nextSibling)
            break;
        }
    }
    return i ?? r > 0 ? this.posAtEnd : this.posAtStart;
  }
  nearestDesc(e, t = !1) {
    for (let r = !0, i = e; i; i = i.parentNode) {
      let s = this.getDesc(i), o;
      if (s && (!t || s.node))
        if (r && (o = s.nodeDOM) && !(o.nodeType == 1 ? o.contains(e.nodeType == 1 ? e : e.parentNode) : o == e))
          r = !1;
        else
          return s;
    }
  }
  getDesc(e) {
    let t = e.pmViewDesc;
    for (let r = t; r; r = r.parent)
      if (r == this)
        return t;
  }
  posFromDOM(e, t, r) {
    for (let i = e; i; i = i.parentNode) {
      let s = this.getDesc(i);
      if (s)
        return s.localPosFromDOM(e, t, r);
    }
    return -1;
  }
  // Find the desc for the node after the given pos, if any. (When a
  // parent node overrode rendering, there might not be one.)
  descAt(e) {
    for (let t = 0, r = 0; t < this.children.length; t++) {
      let i = this.children[t], s = r + i.size;
      if (r == e && s != r) {
        for (; !i.border && i.children.length; )
          for (let o = 0; o < i.children.length; o++) {
            let l = i.children[o];
            if (l.size) {
              i = l;
              break;
            }
          }
        return i;
      }
      if (e < s)
        return i.descAt(e - r - i.border);
      r = s;
    }
  }
  domFromPos(e, t) {
    if (!this.contentDOM)
      return { node: this.dom, offset: 0, atom: e + 1 };
    let r = 0, i = 0;
    for (let s = 0; r < this.children.length; r++) {
      let o = this.children[r], l = s + o.size;
      if (l > e || o instanceof Wh) {
        i = e - s;
        break;
      }
      s = l;
    }
    if (i)
      return this.children[r].domFromPos(i - this.children[r].border, t);
    for (let s; r && !(s = this.children[r - 1]).size && s instanceof jh && s.side >= 0; r--)
      ;
    if (t <= 0) {
      let s, o = !0;
      for (; s = r ? this.children[r - 1] : null, !(!s || s.dom.parentNode == this.contentDOM); r--, o = !1)
        ;
      return s && t && o && !s.border && !s.domAtom ? s.domFromPos(s.size, t) : { node: this.contentDOM, offset: s ? xe(s.dom) + 1 : 0 };
    } else {
      let s, o = !0;
      for (; s = r < this.children.length ? this.children[r] : null, !(!s || s.dom.parentNode == this.contentDOM); r++, o = !1)
        ;
      return s && o && !s.border && !s.domAtom ? s.domFromPos(0, t) : { node: this.contentDOM, offset: s ? xe(s.dom) : this.contentDOM.childNodes.length };
    }
  }
  // Used to find a DOM range in a single parent for a given changed
  // range.
  parseRange(e, t, r = 0) {
    if (this.children.length == 0)
      return { node: this.contentDOM, from: e, to: t, fromOffset: 0, toOffset: this.contentDOM.childNodes.length };
    let i = -1, s = -1;
    for (let o = r, l = 0; ; l++) {
      let a = this.children[l], c = o + a.size;
      if (i == -1 && e <= c) {
        let u = o + a.border;
        if (e >= u && t <= c - a.border && a.node && a.contentDOM && this.contentDOM.contains(a.contentDOM))
          return a.parseRange(e, t, u);
        e = o;
        for (let d = l; d > 0; d--) {
          let f = this.children[d - 1];
          if (f.size && f.dom.parentNode == this.contentDOM && !f.emptyChildAt(1)) {
            i = xe(f.dom) + 1;
            break;
          }
          e -= f.size;
        }
        i == -1 && (i = 0);
      }
      if (i > -1 && (c > t || l == this.children.length - 1)) {
        t = c;
        for (let u = l + 1; u < this.children.length; u++) {
          let d = this.children[u];
          if (d.size && d.dom.parentNode == this.contentDOM && !d.emptyChildAt(-1)) {
            s = xe(d.dom);
            break;
          }
          t += d.size;
        }
        s == -1 && (s = this.contentDOM.childNodes.length);
        break;
      }
      o = c;
    }
    return { node: this.contentDOM, from: e, to: t, fromOffset: i, toOffset: s };
  }
  emptyChildAt(e) {
    if (this.border || !this.contentDOM || !this.children.length)
      return !1;
    let t = this.children[e < 0 ? 0 : this.children.length - 1];
    return t.size == 0 || t.emptyChildAt(e);
  }
  domAfterPos(e) {
    let { node: t, offset: r } = this.domFromPos(e, 0);
    if (t.nodeType != 1 || r == t.childNodes.length)
      throw new RangeError("No node after pos " + e);
    return t.childNodes[r];
  }
  // View descs are responsible for setting any selection that falls
  // entirely inside of them, so that custom implementations can do
  // custom things with the selection. Note that this falls apart when
  // a selection starts in such a node and ends in another, in which
  // case we just use whatever domFromPos produces as a best effort.
  setSelection(e, t, r, i = !1) {
    let s = Math.min(e, t), o = Math.max(e, t);
    for (let h = 0, p = 0; h < this.children.length; h++) {
      let m = this.children[h], _ = p + m.size;
      if (s > p && o < _)
        return m.setSelection(e - p - m.border, t - p - m.border, r, i);
      p = _;
    }
    let l = this.domFromPos(e, e ? -1 : 1), a = t == e ? l : this.domFromPos(t, t ? -1 : 1), c = r.root.getSelection(), u = r.domSelectionRange(), d = !1;
    if ((St || qe) && e == t) {
      let { node: h, offset: p } = l;
      if (h.nodeType == 3) {
        if (d = !!(p && h.nodeValue[p - 1] == `
`), d && p == h.nodeValue.length)
          for (let m = h, _; m; m = m.parentNode) {
            if (_ = m.nextSibling) {
              _.nodeName == "BR" && (l = a = { node: _.parentNode, offset: xe(_) + 1 });
              break;
            }
            let b = m.pmViewDesc;
            if (b && b.node && b.node.isBlock)
              break;
          }
      } else {
        let m = h.childNodes[p - 1];
        d = m && (m.nodeName == "BR" || m.contentEditable == "false");
      }
    }
    if (St && u.focusNode && u.focusNode != a.node && u.focusNode.nodeType == 1) {
      let h = u.focusNode.childNodes[u.focusOffset];
      h && h.contentEditable == "false" && (i = !0);
    }
    if (!(i || d && qe) && Hn(l.node, l.offset, u.anchorNode, u.anchorOffset) && Hn(a.node, a.offset, u.focusNode, u.focusOffset))
      return;
    let f = !1;
    if ((c.extend || e == t) && !d) {
      c.collapse(l.node, l.offset);
      try {
        e != t && c.extend(a.node, a.offset), f = !0;
      } catch {
      }
    }
    if (!f) {
      if (e > t) {
        let p = l;
        l = a, a = p;
      }
      let h = document.createRange();
      h.setEnd(a.node, a.offset), h.setStart(l.node, l.offset), c.removeAllRanges(), c.addRange(h);
    }
  }
  ignoreMutation(e) {
    return !this.contentDOM && e.type != "selection";
  }
  get contentLost() {
    return this.contentDOM && this.contentDOM != this.dom && !this.dom.contains(this.contentDOM);
  }
  // Remove a subtree of the element tree that has been touched
  // by a DOM change, so that the next update will redraw it.
  markDirty(e, t) {
    for (let r = 0, i = 0; i < this.children.length; i++) {
      let s = this.children[i], o = r + s.size;
      if (r == o ? e <= o && t >= r : e < o && t > r) {
        let l = r + s.border, a = o - s.border;
        if (e >= l && t <= a) {
          this.dirty = e == r || t == o ? Tn : rd, e == l && t == a && (s.contentLost || s.dom.parentNode != this.contentDOM) ? s.dirty = Bt : s.markDirty(e - l, t - l);
          return;
        } else
          s.dirty = s.dom == s.contentDOM && s.dom.parentNode == this.contentDOM && !s.children.length ? Tn : Bt;
      }
      r = o;
    }
    this.dirty = Tn;
  }
  markParentsDirty() {
    let e = 1;
    for (let t = this.parent; t; t = t.parent, e++) {
      let r = e == 1 ? Tn : rd;
      t.dirty < r && (t.dirty = r);
    }
  }
  get domAtom() {
    return !1;
  }
  get ignoreForCoords() {
    return !1;
  }
  get ignoreForSelection() {
    return !1;
  }
  isText(e) {
    return !1;
  }
}
class jh extends ki {
  constructor(e, t, r, i) {
    let s, o = t.type.toDOM;
    if (typeof o == "function" && (o = o(r, () => {
      if (!s)
        return i;
      if (s.parent)
        return s.parent.posBeforeChild(s);
    })), !t.type.spec.raw) {
      if (o.nodeType != 1) {
        let l = document.createElement("span");
        l.appendChild(o), o = l;
      }
      o.contentEditable = "false", o.classList.add("ProseMirror-widget");
    }
    super(e, [], o, null), this.widget = t, this.widget = t, s = this;
  }
  matchesWidget(e) {
    return this.dirty == ut && e.type.eq(this.widget.type);
  }
  parseRule() {
    return { ignore: !0 };
  }
  stopEvent(e) {
    let t = this.widget.spec.stopEvent;
    return t ? t(e) : !1;
  }
  ignoreMutation(e) {
    return e.type != "selection" || this.widget.spec.ignoreSelection;
  }
  destroy() {
    this.widget.type.destroy(this.dom), super.destroy();
  }
  get domAtom() {
    return !0;
  }
  get ignoreForSelection() {
    return !!this.widget.type.spec.relaxedSide;
  }
  get side() {
    return this.widget.type.side;
  }
}
class Eb extends ki {
  constructor(e, t, r, i) {
    super(e, [], t, null), this.textDOM = r, this.text = i;
  }
  get size() {
    return this.text.length;
  }
  localPosFromDOM(e, t) {
    return e != this.textDOM ? this.posAtStart + (t ? this.size : 0) : this.posAtStart + t;
  }
  domFromPos(e) {
    return { node: this.textDOM, offset: e };
  }
  ignoreMutation(e) {
    return e.type === "characterData" && e.target.nodeValue == e.oldValue;
  }
}
class qn extends ki {
  constructor(e, t, r, i, s) {
    super(e, [], r, i), this.mark = t, this.spec = s;
  }
  static create(e, t, r, i) {
    let s = i.nodeViews[t.type.name], o = s && s(t, i, r);
    return (!o || !o.dom) && (o = Wn.renderSpec(document, t.type.spec.toDOM(t, r), null, t.attrs)), new qn(e, t, o.dom, o.contentDOM || o.dom, o);
  }
  parseRule() {
    return this.dirty & Bt || this.mark.type.spec.reparseInView ? null : { mark: this.mark.type.name, attrs: this.mark.attrs, contentElement: this.contentDOM };
  }
  matchesMark(e) {
    return this.dirty != Bt && this.mark.eq(e);
  }
  markDirty(e, t) {
    if (super.markDirty(e, t), this.dirty != ut) {
      let r = this.parent;
      for (; !r.node; )
        r = r.parent;
      r.dirty < this.dirty && (r.dirty = this.dirty), this.dirty = ut;
    }
  }
  slice(e, t, r) {
    let i = qn.create(this.parent, this.mark, !0, r), s = this.children, o = this.size;
    t < o && (s = ql(s, t, o, r)), e > 0 && (s = ql(s, 0, e, r));
    for (let l = 0; l < s.length; l++)
      s[l].parent = i;
    return i.children = s, i;
  }
  ignoreMutation(e) {
    return this.spec.ignoreMutation ? this.spec.ignoreMutation(e) : super.ignoreMutation(e);
  }
  destroy() {
    this.spec.destroy && this.spec.destroy(), super.destroy();
  }
}
class _n extends ki {
  constructor(e, t, r, i, s, o, l, a, c) {
    super(e, [], s, o), this.node = t, this.outerDeco = r, this.innerDeco = i, this.nodeDOM = l;
  }
  // By default, a node is rendered using the `toDOM` method from the
  // node type spec. But client code can use the `nodeViews` spec to
  // supply a custom node view, which can influence various aspects of
  // the way the node works.
  //
  // (Using subclassing for this was intentionally decided against,
  // since it'd require exposing a whole slew of finicky
  // implementation details to the user code that they probably will
  // never need.)
  static create(e, t, r, i, s, o) {
    let l = s.nodeViews[t.type.name], a, c = l && l(t, s, () => {
      if (!a)
        return o;
      if (a.parent)
        return a.parent.posBeforeChild(a);
    }, r, i), u = c && c.dom, d = c && c.contentDOM;
    if (t.isText) {
      if (!u)
        u = document.createTextNode(t.text);
      else if (u.nodeType != 3)
        throw new RangeError("Text must be rendered as a DOM text node");
    } else u || ({ dom: u, contentDOM: d } = Wn.renderSpec(document, t.type.spec.toDOM(t), null, t.attrs));
    !d && !t.isText && u.nodeName != "BR" && (u.hasAttribute("contenteditable") || (u.contentEditable = "false"), t.type.spec.draggable && (u.draggable = !0));
    let f = u;
    return u = Jh(u, r, t), c ? a = new Db(e, t, r, i, u, d || null, f, c, s, o + 1) : t.isText ? new uo(e, t, r, i, u, f, s) : new _n(e, t, r, i, u, d || null, f, s, o + 1);
  }
  parseRule() {
    if (this.node.type.spec.reparseInView)
      return null;
    let e = { node: this.node.type.name, attrs: this.node.attrs };
    if (this.node.type.whitespace == "pre" && (e.preserveWhitespace = "full"), !this.contentDOM)
      e.getContent = () => this.node.content;
    else if (!this.contentLost)
      e.contentElement = this.contentDOM;
    else {
      for (let t = this.children.length - 1; t >= 0; t--) {
        let r = this.children[t];
        if (this.dom.contains(r.dom.parentNode)) {
          e.contentElement = r.dom.parentNode;
          break;
        }
      }
      e.contentElement || (e.getContent = () => A.empty);
    }
    return e;
  }
  matchesNode(e, t, r) {
    return this.dirty == ut && e.eq(this.node) && ws(t, this.outerDeco) && r.eq(this.innerDeco);
  }
  get size() {
    return this.node.nodeSize;
  }
  get border() {
    return this.node.isLeaf ? 0 : 1;
  }
  // Syncs `this.children` to match `this.node.content` and the local
  // decorations, possibly introducing nesting for marks. Then, in a
  // separate step, syncs the DOM inside `this.contentDOM` to
  // `this.children`.
  updateChildren(e, t) {
    let r = this.node.inlineContent, i = t, s = e.composing ? this.localCompositionInfo(e, t) : null, o = s && s.pos > -1 ? s : null, l = s && s.pos < 0, a = new Cb(this, o && o.node, e);
    Tb(this.node, this.innerDeco, (c, u, d) => {
      c.spec.marks ? a.syncToMarks(c.spec.marks, r, e) : c.type.side >= 0 && !d && a.syncToMarks(u == this.node.childCount ? Z.none : this.node.child(u).marks, r, e), a.placeWidget(c, e, i);
    }, (c, u, d, f) => {
      a.syncToMarks(c.marks, r, e);
      let h;
      a.findNodeMatch(c, u, d, f) || l && e.state.selection.from > i && e.state.selection.to < i + c.nodeSize && (h = a.findIndexWithChild(s.node)) > -1 && a.updateNodeAt(c, u, d, h, e) || a.updateNextNode(c, u, d, e, f, i) || a.addNode(c, u, d, e, i), i += c.nodeSize;
    }), a.syncToMarks([], r, e), this.node.isTextblock && a.addTextblockHacks(), a.destroyRest(), (a.changed || this.dirty == Tn) && (o && this.protectLocalComposition(e, o), Kh(this.contentDOM, this.children, e), br && Mb(this.dom));
  }
  localCompositionInfo(e, t) {
    let { from: r, to: i } = e.state.selection;
    if (!(e.state.selection instanceof z) || r < t || i > t + this.node.content.size)
      return null;
    let s = e.input.compositionNode;
    if (!s || !this.dom.contains(s.parentNode))
      return null;
    if (this.node.inlineContent) {
      let o = s.nodeValue, l = Fb(this.node.content, o, r - t, i - t);
      return l < 0 ? null : { node: s, pos: l, text: o };
    } else
      return { node: s, pos: -1, text: "" };
  }
  protectLocalComposition(e, { node: t, pos: r, text: i }) {
    if (this.getDesc(t))
      return;
    let s = t;
    for (; s.parentNode != this.contentDOM; s = s.parentNode) {
      for (; s.previousSibling; )
        s.parentNode.removeChild(s.previousSibling);
      for (; s.nextSibling; )
        s.parentNode.removeChild(s.nextSibling);
      s.pmViewDesc && (s.pmViewDesc = void 0);
    }
    let o = new Eb(this, s, t, i);
    e.input.compositionNodes.push(o), this.children = ql(this.children, r, r + i.length, e, o);
  }
  // If this desc must be updated to match the given node decoration,
  // do so and return true.
  update(e, t, r, i) {
    return this.dirty == Bt || !e.sameMarkup(this.node) ? !1 : (this.updateInner(e, t, r, i), !0);
  }
  updateInner(e, t, r, i) {
    this.updateOuterDeco(t), this.node = e, this.innerDeco = r, this.contentDOM && this.updateChildren(i, this.posAtStart), this.dirty = ut;
  }
  updateOuterDeco(e) {
    if (ws(e, this.outerDeco))
      return;
    let t = this.nodeDOM.nodeType != 1, r = this.dom;
    this.dom = Gh(this.dom, this.nodeDOM, Hl(this.outerDeco, this.node, t), Hl(e, this.node, t)), this.dom != r && (r.pmViewDesc = void 0, this.dom.pmViewDesc = this), this.outerDeco = e;
  }
  // Mark this node as being the selected node.
  selectNode() {
    this.nodeDOM.nodeType == 1 && this.nodeDOM.classList.add("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && (this.dom.draggable = !0);
  }
  // Remove selected node marking from this node.
  deselectNode() {
    this.nodeDOM.nodeType == 1 && (this.nodeDOM.classList.remove("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && this.dom.removeAttribute("draggable"));
  }
  get domAtom() {
    return this.node.isAtom;
  }
}
function id(n, e, t, r, i) {
  Jh(r, e, n);
  let s = new _n(void 0, n, e, t, r, r, r, i, 0);
  return s.contentDOM && s.updateChildren(i, 0), s;
}
class uo extends _n {
  constructor(e, t, r, i, s, o, l) {
    super(e, t, r, i, s, null, o, l, 0);
  }
  parseRule() {
    let e = this.nodeDOM.parentNode;
    for (; e && e != this.dom && !e.pmIsDeco; )
      e = e.parentNode;
    return { skip: e || !0 };
  }
  update(e, t, r, i) {
    return this.dirty == Bt || this.dirty != ut && !this.inParent() || !e.sameMarkup(this.node) ? !1 : (this.updateOuterDeco(t), (this.dirty != ut || e.text != this.node.text) && e.text != this.nodeDOM.nodeValue && (this.nodeDOM.nodeValue = e.text, i.trackWrites == this.nodeDOM && (i.trackWrites = null)), this.node = e, this.dirty = ut, !0);
  }
  inParent() {
    let e = this.parent.contentDOM;
    for (let t = this.nodeDOM; t; t = t.parentNode)
      if (t == e)
        return !0;
    return !1;
  }
  domFromPos(e) {
    return { node: this.nodeDOM, offset: e };
  }
  localPosFromDOM(e, t, r) {
    return e == this.nodeDOM ? this.posAtStart + Math.min(t, this.node.text.length) : super.localPosFromDOM(e, t, r);
  }
  ignoreMutation(e) {
    return e.type != "characterData" && e.type != "selection";
  }
  slice(e, t, r) {
    let i = this.node.cut(e, t), s = document.createTextNode(i.text);
    return new uo(this.parent, i, this.outerDeco, this.innerDeco, s, s, r);
  }
  markDirty(e, t) {
    super.markDirty(e, t), this.dom != this.nodeDOM && (e == 0 || t == this.nodeDOM.nodeValue.length) && (this.dirty = Bt);
  }
  get domAtom() {
    return !1;
  }
  isText(e) {
    return this.node.text == e;
  }
}
class Wh extends ki {
  parseRule() {
    return { ignore: !0 };
  }
  matchesHack(e) {
    return this.dirty == ut && this.dom.nodeName == e;
  }
  get domAtom() {
    return !0;
  }
  get ignoreForCoords() {
    return this.dom.nodeName == "IMG";
  }
}
class Db extends _n {
  constructor(e, t, r, i, s, o, l, a, c, u) {
    super(e, t, r, i, s, o, l, c, u), this.spec = a;
  }
  // A custom `update` method gets to decide whether the update goes
  // through. If it does, and there's a `contentDOM` node, our logic
  // updates the children.
  update(e, t, r, i) {
    if (this.dirty == Bt)
      return !1;
    if (this.spec.update && (this.node.type == e.type || this.spec.multiType)) {
      let s = this.spec.update(e, t, r);
      return s && this.updateInner(e, t, r, i), s;
    } else return !this.contentDOM && !e.isLeaf ? !1 : super.update(e, t, r, i);
  }
  selectNode() {
    this.spec.selectNode ? this.spec.selectNode() : super.selectNode();
  }
  deselectNode() {
    this.spec.deselectNode ? this.spec.deselectNode() : super.deselectNode();
  }
  setSelection(e, t, r, i) {
    this.spec.setSelection ? this.spec.setSelection(e, t, r.root) : super.setSelection(e, t, r, i);
  }
  destroy() {
    this.spec.destroy && this.spec.destroy(), super.destroy();
  }
  stopEvent(e) {
    return this.spec.stopEvent ? this.spec.stopEvent(e) : !1;
  }
  ignoreMutation(e) {
    return this.spec.ignoreMutation ? this.spec.ignoreMutation(e) : super.ignoreMutation(e);
  }
}
function Kh(n, e, t) {
  let r = n.firstChild, i = !1;
  for (let s = 0; s < e.length; s++) {
    let o = e[s], l = o.dom;
    if (l.parentNode == n) {
      for (; l != r; )
        r = sd(r), i = !0;
      r = r.nextSibling;
    } else
      i = !0, n.insertBefore(l, r);
    if (o instanceof qn) {
      let a = r ? r.previousSibling : n.lastChild;
      Kh(o.contentDOM, o.children, t), r = a ? a.nextSibling : n.firstChild;
    }
  }
  for (; r; )
    r = sd(r), i = !0;
  i && t.trackWrites == n && (t.trackWrites = null);
}
const Jr = function(n) {
  n && (this.nodeName = n);
};
Jr.prototype = /* @__PURE__ */ Object.create(null);
const Mn = [new Jr()];
function Hl(n, e, t) {
  if (n.length == 0)
    return Mn;
  let r = t ? Mn[0] : new Jr(), i = [r];
  for (let s = 0; s < n.length; s++) {
    let o = n[s].type.attrs;
    if (o) {
      o.nodeName && i.push(r = new Jr(o.nodeName));
      for (let l in o) {
        let a = o[l];
        a != null && (t && i.length == 1 && i.push(r = new Jr(e.isInline ? "span" : "div")), l == "class" ? r.class = (r.class ? r.class + " " : "") + a : l == "style" ? r.style = (r.style ? r.style + ";" : "") + a : l != "nodeName" && (r[l] = a));
      }
    }
  }
  return i;
}
function Gh(n, e, t, r) {
  if (t == Mn && r == Mn)
    return e;
  let i = e;
  for (let s = 0; s < r.length; s++) {
    let o = r[s], l = t[s];
    if (s) {
      let a;
      l && l.nodeName == o.nodeName && i != n && (a = i.parentNode) && a.nodeName.toLowerCase() == o.nodeName || (a = document.createElement(o.nodeName), a.pmIsDeco = !0, a.appendChild(i), l = Mn[0]), i = a;
    }
    Sb(i, l || Mn[0], o);
  }
  return i;
}
function Sb(n, e, t) {
  for (let r in e)
    r != "class" && r != "style" && r != "nodeName" && !(r in t) && n.removeAttribute(r);
  for (let r in t)
    r != "class" && r != "style" && r != "nodeName" && t[r] != e[r] && n.setAttribute(r, t[r]);
  if (e.class != t.class) {
    let r = e.class ? e.class.split(" ").filter(Boolean) : [], i = t.class ? t.class.split(" ").filter(Boolean) : [];
    for (let s = 0; s < r.length; s++)
      i.indexOf(r[s]) == -1 && n.classList.remove(r[s]);
    for (let s = 0; s < i.length; s++)
      r.indexOf(i[s]) == -1 && n.classList.add(i[s]);
    n.classList.length == 0 && n.removeAttribute("class");
  }
  if (e.style != t.style) {
    if (e.style) {
      let r = /\s*([\w\-\xa1-\uffff]+)\s*:(?:"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\(.*?\)|[^;])*/g, i;
      for (; i = r.exec(e.style); )
        n.style.removeProperty(i[1]);
    }
    t.style && (n.style.cssText += t.style);
  }
}
function Jh(n, e, t) {
  return Gh(n, n, Mn, Hl(e, t, n.nodeType != 1));
}
function ws(n, e) {
  if (n.length != e.length)
    return !1;
  for (let t = 0; t < n.length; t++)
    if (!n[t].type.eq(e[t].type))
      return !1;
  return !0;
}
function sd(n) {
  let e = n.nextSibling;
  return n.parentNode.removeChild(n), e;
}
class Cb {
  constructor(e, t, r) {
    this.lock = t, this.view = r, this.index = 0, this.stack = [], this.changed = !1, this.top = e, this.preMatch = Ab(e.node.content, e);
  }
  // Destroy and remove the children between the given indices in
  // `this.top`.
  destroyBetween(e, t) {
    if (e != t) {
      for (let r = e; r < t; r++)
        this.top.children[r].destroy();
      this.top.children.splice(e, t - e), this.changed = !0;
    }
  }
  // Destroy all remaining children in `this.top`.
  destroyRest() {
    this.destroyBetween(this.index, this.top.children.length);
  }
  // Sync the current stack of mark descs with the given array of
  // marks, reusing existing mark descs when possible.
  syncToMarks(e, t, r) {
    let i = 0, s = this.stack.length >> 1, o = Math.min(s, e.length);
    for (; i < o && (i == s - 1 ? this.top : this.stack[i + 1 << 1]).matchesMark(e[i]) && e[i].type.spec.spanning !== !1; )
      i++;
    for (; i < s; )
      this.destroyRest(), this.top.dirty = ut, this.index = this.stack.pop(), this.top = this.stack.pop(), s--;
    for (; s < e.length; ) {
      this.stack.push(this.top, this.index + 1);
      let l = -1;
      for (let a = this.index; a < Math.min(this.index + 3, this.top.children.length); a++) {
        let c = this.top.children[a];
        if (c.matchesMark(e[s]) && !this.isLocked(c.dom)) {
          l = a;
          break;
        }
      }
      if (l > -1)
        l > this.index && (this.changed = !0, this.destroyBetween(this.index, l)), this.top = this.top.children[this.index];
      else {
        let a = qn.create(this.top, e[s], t, r);
        this.top.children.splice(this.index, 0, a), this.top = a, this.changed = !0;
      }
      this.index = 0, s++;
    }
  }
  // Try to find a node desc matching the given data. Skip over it and
  // return true when successful.
  findNodeMatch(e, t, r, i) {
    let s = -1, o;
    if (i >= this.preMatch.index && (o = this.preMatch.matches[i - this.preMatch.index]).parent == this.top && o.matchesNode(e, t, r))
      s = this.top.children.indexOf(o, this.index);
    else
      for (let l = this.index, a = Math.min(this.top.children.length, l + 5); l < a; l++) {
        let c = this.top.children[l];
        if (c.matchesNode(e, t, r) && !this.preMatch.matched.has(c)) {
          s = l;
          break;
        }
      }
    return s < 0 ? !1 : (this.destroyBetween(this.index, s), this.index++, !0);
  }
  updateNodeAt(e, t, r, i, s) {
    let o = this.top.children[i];
    return o.dirty == Bt && o.dom == o.contentDOM && (o.dirty = Tn), o.update(e, t, r, s) ? (this.destroyBetween(this.index, i), this.index++, !0) : !1;
  }
  findIndexWithChild(e) {
    for (; ; ) {
      let t = e.parentNode;
      if (!t)
        return -1;
      if (t == this.top.contentDOM) {
        let r = e.pmViewDesc;
        if (r) {
          for (let i = this.index; i < this.top.children.length; i++)
            if (this.top.children[i] == r)
              return i;
        }
        return -1;
      }
      e = t;
    }
  }
  // Try to update the next node, if any, to the given data. Checks
  // pre-matches to avoid overwriting nodes that could still be used.
  updateNextNode(e, t, r, i, s, o) {
    for (let l = this.index; l < this.top.children.length; l++) {
      let a = this.top.children[l];
      if (a instanceof _n) {
        let c = this.preMatch.matched.get(a);
        if (c != null && c != s)
          return !1;
        let u = a.dom, d, f = this.isLocked(u) && !(e.isText && a.node && a.node.isText && a.nodeDOM.nodeValue == e.text && a.dirty != Bt && ws(t, a.outerDeco));
        if (!f && a.update(e, t, r, i))
          return this.destroyBetween(this.index, l), a.dom != u && (this.changed = !0), this.index++, !0;
        if (!f && (d = this.recreateWrapper(a, e, t, r, i, o)))
          return this.destroyBetween(this.index, l), this.top.children[this.index] = d, d.contentDOM && (d.dirty = Tn, d.updateChildren(i, o + 1), d.dirty = ut), this.changed = !0, this.index++, !0;
        break;
      }
    }
    return !1;
  }
  // When a node with content is replaced by a different node with
  // identical content, move over its children.
  recreateWrapper(e, t, r, i, s, o) {
    if (e.dirty || t.isAtom || !e.children.length || !e.node.content.eq(t.content) || !ws(r, e.outerDeco) || !i.eq(e.innerDeco))
      return null;
    let l = _n.create(this.top, t, r, i, s, o);
    if (l.contentDOM) {
      l.children = e.children, e.children = [];
      for (let a of l.children)
        a.parent = l;
    }
    return e.destroy(), l;
  }
  // Insert the node as a newly created node desc.
  addNode(e, t, r, i, s) {
    let o = _n.create(this.top, e, t, r, i, s);
    o.contentDOM && o.updateChildren(i, s + 1), this.top.children.splice(this.index++, 0, o), this.changed = !0;
  }
  placeWidget(e, t, r) {
    let i = this.index < this.top.children.length ? this.top.children[this.index] : null;
    if (i && i.matchesWidget(e) && (e == i.widget || !i.widget.type.toDOM.parentNode))
      this.index++;
    else {
      let s = new jh(this.top, e, t, r);
      this.top.children.splice(this.index++, 0, s), this.changed = !0;
    }
  }
  // Make sure a textblock looks and behaves correctly in
  // contentEditable.
  addTextblockHacks() {
    let e = this.top.children[this.index - 1], t = this.top;
    for (; e instanceof qn; )
      t = e, e = t.children[t.children.length - 1];
    (!e || // Empty textblock
    !(e instanceof uo) || /\n$/.test(e.node.text) || this.view.requiresGeckoHackNode && /\s$/.test(e.node.text)) && ((qe || Re) && e && e.dom.contentEditable == "false" && this.addHackNode("IMG", t), this.addHackNode("BR", this.top));
  }
  addHackNode(e, t) {
    if (t == this.top && this.index < t.children.length && t.children[this.index].matchesHack(e))
      this.index++;
    else {
      let r = document.createElement(e);
      e == "IMG" && (r.className = "ProseMirror-separator", r.alt = ""), e == "BR" && (r.className = "ProseMirror-trailingBreak");
      let i = new Wh(this.top, [], r, null);
      t != this.top ? t.children.push(i) : t.children.splice(this.index++, 0, i), this.changed = !0;
    }
  }
  isLocked(e) {
    return this.lock && (e == this.lock || e.nodeType == 1 && e.contains(this.lock.parentNode));
  }
}
function Ab(n, e) {
  let t = e, r = t.children.length, i = n.childCount, s = /* @__PURE__ */ new Map(), o = [];
  e: for (; i > 0; ) {
    let l;
    for (; ; )
      if (r) {
        let c = t.children[r - 1];
        if (c instanceof qn)
          t = c, r = c.children.length;
        else {
          l = c, r--;
          break;
        }
      } else {
        if (t == e)
          break e;
        r = t.parent.children.indexOf(t), t = t.parent;
      }
    let a = l.node;
    if (a) {
      if (a != n.child(i - 1))
        break;
      --i, s.set(l, i), o.push(l);
    }
  }
  return { index: i, matched: s, matches: o.reverse() };
}
function xb(n, e) {
  return n.type.side - e.type.side;
}
function Tb(n, e, t, r) {
  let i = e.locals(n), s = 0;
  if (i.length == 0) {
    for (let c = 0; c < n.childCount; c++) {
      let u = n.child(c);
      r(u, i, e.forChild(s, u), c), s += u.nodeSize;
    }
    return;
  }
  let o = 0, l = [], a = null;
  for (let c = 0; ; ) {
    let u, d;
    for (; o < i.length && i[o].to == s; ) {
      let _ = i[o++];
      _.widget && (u ? (d || (d = [u])).push(_) : u = _);
    }
    if (u)
      if (d) {
        d.sort(xb);
        for (let _ = 0; _ < d.length; _++)
          t(d[_], c, !!a);
      } else
        t(u, c, !!a);
    let f, h;
    if (a)
      h = -1, f = a, a = null;
    else if (c < n.childCount)
      h = c, f = n.child(c++);
    else
      break;
    for (let _ = 0; _ < l.length; _++)
      l[_].to <= s && l.splice(_--, 1);
    for (; o < i.length && i[o].from <= s && i[o].to > s; )
      l.push(i[o++]);
    let p = s + f.nodeSize;
    if (f.isText) {
      let _ = p;
      o < i.length && i[o].from < _ && (_ = i[o].from);
      for (let b = 0; b < l.length; b++)
        l[b].to < _ && (_ = l[b].to);
      _ < p && (a = f.cut(_ - s), f = f.cut(0, _ - s), p = _, h = -1);
    } else
      for (; o < i.length && i[o].to < p; )
        o++;
    let m = f.isInline && !f.isLeaf ? l.filter((_) => !_.inline) : l.slice();
    r(f, m, e.forChild(s, f), h), s = p;
  }
}
function Mb(n) {
  if (n.nodeName == "UL" || n.nodeName == "OL") {
    let e = n.style.cssText;
    n.style.cssText = e + "; list-style: square !important", window.getComputedStyle(n).listStyle, n.style.cssText = e;
  }
}
function Fb(n, e, t, r) {
  for (let i = 0, s = 0; i < n.childCount && s <= r; ) {
    let o = n.child(i++), l = s;
    if (s += o.nodeSize, !o.isText)
      continue;
    let a = o.text;
    for (; i < n.childCount; ) {
      let c = n.child(i++);
      if (s += c.nodeSize, !c.isText)
        break;
      a += c.text;
    }
    if (s >= t) {
      if (s >= r && a.slice(r - e.length - l, r - l) == e)
        return r - e.length;
      let c = l < r ? a.lastIndexOf(e, r - l - 1) : -1;
      if (c >= 0 && c + e.length + l >= t)
        return l + c;
      if (t == r && a.length >= r + e.length - l && a.slice(r - l, r - l + e.length) == e)
        return r;
    }
  }
  return -1;
}
function ql(n, e, t, r, i) {
  let s = [];
  for (let o = 0, l = 0; o < n.length; o++) {
    let a = n[o], c = l, u = l += a.size;
    c >= t || u <= e ? s.push(a) : (c < e && s.push(a.slice(0, e - c, r)), i && (s.push(i), i = void 0), u > t && s.push(a.slice(t - c, a.size, r)));
  }
  return s;
}
function ka(n, e = null) {
  let t = n.domSelectionRange(), r = n.state.doc;
  if (!t.focusNode)
    return null;
  let i = n.docView.nearestDesc(t.focusNode), s = i && i.size == 0, o = n.docView.posFromDOM(t.focusNode, t.focusOffset, 1);
  if (o < 0)
    return null;
  let l = r.resolve(o), a, c;
  if (co(t)) {
    for (a = o; i && !i.node; )
      i = i.parent;
    let d = i.node;
    if (i && d.isAtom && B.isSelectable(d) && i.parent && !(d.isInline && rb(t.focusNode, t.focusOffset, i.dom))) {
      let f = i.posBefore;
      c = new B(o == f ? l : r.resolve(f));
    }
  } else {
    if (t instanceof n.dom.ownerDocument.defaultView.Selection && t.rangeCount > 1) {
      let d = o, f = o;
      for (let h = 0; h < t.rangeCount; h++) {
        let p = t.getRangeAt(h);
        d = Math.min(d, n.docView.posFromDOM(p.startContainer, p.startOffset, 1)), f = Math.max(f, n.docView.posFromDOM(p.endContainer, p.endOffset, -1));
      }
      if (d < 0)
        return null;
      [a, o] = f == n.state.selection.anchor ? [f, d] : [d, f], l = r.resolve(o);
    } else
      a = n.docView.posFromDOM(t.anchorNode, t.anchorOffset, 1);
    if (a < 0)
      return null;
  }
  let u = r.resolve(a);
  if (!c) {
    let d = e == "pointer" || n.state.selection.head < l.pos && !s ? 1 : -1;
    c = wa(n, u, l, d);
  }
  return c;
}
function Yh(n) {
  return n.editable ? n.hasFocus() : Zh(n) && document.activeElement && document.activeElement.contains(n.dom);
}
function Zt(n, e = !1) {
  let t = n.state.selection;
  if (Xh(n, t), !!Yh(n)) {
    if (!e && n.input.mouseDown && n.input.mouseDown.allowDefault && Re) {
      let r = n.domSelectionRange(), i = n.domObserver.currentSelection;
      if (r.anchorNode && i.anchorNode && Hn(r.anchorNode, r.anchorOffset, i.anchorNode, i.anchorOffset)) {
        n.input.mouseDown.delayedSelectionSync = !0, n.domObserver.setCurSelection();
        return;
      }
    }
    if (n.domObserver.disconnectSelection(), n.cursorWrapper)
      Ob(n);
    else {
      let { anchor: r, head: i } = t, s, o;
      od && !(t instanceof z) && (t.$from.parent.inlineContent || (s = ld(n, t.from)), !t.empty && !t.$from.parent.inlineContent && (o = ld(n, t.to))), n.docView.setSelection(r, i, n, e), od && (s && ad(s), o && ad(o)), t.visible ? n.dom.classList.remove("ProseMirror-hideselection") : (n.dom.classList.add("ProseMirror-hideselection"), "onselectionchange" in document && $b(n));
    }
    n.domObserver.setCurSelection(), n.domObserver.connectSelection();
  }
}
const od = qe || Re && Ph < 63;
function ld(n, e) {
  let { node: t, offset: r } = n.docView.domFromPos(e, 0), i = r < t.childNodes.length ? t.childNodes[r] : null, s = r ? t.childNodes[r - 1] : null;
  if (qe && i && i.contentEditable == "false")
    return tl(i);
  if ((!i || i.contentEditable == "false") && (!s || s.contentEditable == "false")) {
    if (i)
      return tl(i);
    if (s)
      return tl(s);
  }
}
function tl(n) {
  return n.contentEditable = "true", qe && n.draggable && (n.draggable = !1, n.wasDraggable = !0), n;
}
function ad(n) {
  n.contentEditable = "false", n.wasDraggable && (n.draggable = !0, n.wasDraggable = null);
}
function $b(n) {
  let e = n.dom.ownerDocument;
  e.removeEventListener("selectionchange", n.input.hideSelectionGuard);
  let t = n.domSelectionRange(), r = t.anchorNode, i = t.anchorOffset;
  e.addEventListener("selectionchange", n.input.hideSelectionGuard = () => {
    (t.anchorNode != r || t.anchorOffset != i) && (e.removeEventListener("selectionchange", n.input.hideSelectionGuard), setTimeout(() => {
      (!Yh(n) || n.state.selection.visible) && n.dom.classList.remove("ProseMirror-hideselection");
    }, 20));
  });
}
function Ob(n) {
  let e = n.domSelection(), t = document.createRange();
  if (!e)
    return;
  let r = n.cursorWrapper.dom, i = r.nodeName == "IMG";
  i ? t.setStart(r.parentNode, xe(r) + 1) : t.setStart(r, 0), t.collapse(!0), e.removeAllRanges(), e.addRange(t), !i && !n.state.selection.visible && Ge && gn <= 11 && (r.disabled = !0, r.disabled = !1);
}
function Xh(n, e) {
  if (e instanceof B) {
    let t = n.docView.descAt(e.from);
    t != n.lastSelectedViewDesc && (cd(n), t && t.selectNode(), n.lastSelectedViewDesc = t);
  } else
    cd(n);
}
function cd(n) {
  n.lastSelectedViewDesc && (n.lastSelectedViewDesc.parent && n.lastSelectedViewDesc.deselectNode(), n.lastSelectedViewDesc = void 0);
}
function wa(n, e, t, r) {
  return n.someProp("createSelectionBetween", (i) => i(n, e, t)) || z.between(e, t, r);
}
function ud(n) {
  return n.editable && !n.hasFocus() ? !1 : Zh(n);
}
function Zh(n) {
  let e = n.domSelectionRange();
  if (!e.anchorNode)
    return !1;
  try {
    return n.dom.contains(e.anchorNode.nodeType == 3 ? e.anchorNode.parentNode : e.anchorNode) && (n.editable || n.dom.contains(e.focusNode.nodeType == 3 ? e.focusNode.parentNode : e.focusNode));
  } catch {
    return !1;
  }
}
function Nb(n) {
  let e = n.docView.domFromPos(n.state.selection.anchor, 0), t = n.domSelectionRange();
  return Hn(e.node, e.offset, t.anchorNode, t.anchorOffset);
}
function Vl(n, e) {
  let { $anchor: t, $head: r } = n.selection, i = e > 0 ? t.max(r) : t.min(r), s = i.parent.inlineContent ? i.depth ? n.doc.resolve(e > 0 ? i.after() : i.before()) : null : i;
  return s && V.findFrom(s, e);
}
function ln(n, e) {
  return n.dispatch(n.state.tr.setSelection(e).scrollIntoView()), !0;
}
function dd(n, e, t) {
  let r = n.state.selection;
  if (r instanceof z)
    if (t.indexOf("s") > -1) {
      let { $head: i } = r, s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter;
      if (!s || s.isText || !s.isLeaf)
        return !1;
      let o = n.state.doc.resolve(i.pos + s.nodeSize * (e < 0 ? -1 : 1));
      return ln(n, new z(r.$anchor, o));
    } else if (r.empty) {
      if (n.endOfTextblock(e > 0 ? "forward" : "backward")) {
        let i = Vl(n.state, e);
        return i && i instanceof B ? ln(n, i) : !1;
      } else if (!(ot && t.indexOf("m") > -1)) {
        let i = r.$head, s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter, o;
        if (!s || s.isText)
          return !1;
        let l = e < 0 ? i.pos - s.nodeSize : i.pos;
        return s.isAtom || (o = n.docView.descAt(l)) && !o.contentDOM ? B.isSelectable(s) ? ln(n, new B(e < 0 ? n.state.doc.resolve(i.pos - s.nodeSize) : i)) : bi ? ln(n, new z(n.state.doc.resolve(e < 0 ? l : l + s.nodeSize))) : !1 : !1;
      }
    } else return !1;
  else {
    if (r instanceof B && r.node.isInline)
      return ln(n, new z(e > 0 ? r.$to : r.$from));
    {
      let i = Vl(n.state, e);
      return i ? ln(n, i) : !1;
    }
  }
}
function vs(n) {
  return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length;
}
function Yr(n, e) {
  let t = n.pmViewDesc;
  return t && t.size == 0 && (e < 0 || n.nextSibling || n.nodeName != "BR");
}
function or(n, e) {
  return e < 0 ? Ib(n) : Rb(n);
}
function Ib(n) {
  let e = n.domSelectionRange(), t = e.focusNode, r = e.focusOffset;
  if (!t)
    return;
  let i, s, o = !1;
  for (St && t.nodeType == 1 && r < vs(t) && Yr(t.childNodes[r], -1) && (o = !0); ; )
    if (r > 0) {
      if (t.nodeType != 1)
        break;
      {
        let l = t.childNodes[r - 1];
        if (Yr(l, -1))
          i = t, s = --r;
        else if (l.nodeType == 3)
          t = l, r = t.nodeValue.length;
        else
          break;
      }
    } else {
      if (Qh(t))
        break;
      {
        let l = t.previousSibling;
        for (; l && Yr(l, -1); )
          i = t.parentNode, s = xe(l), l = l.previousSibling;
        if (l)
          t = l, r = vs(t);
        else {
          if (t = t.parentNode, t == n.dom)
            break;
          r = 0;
        }
      }
    }
  o ? Ul(n, t, r) : i && Ul(n, i, s);
}
function Rb(n) {
  let e = n.domSelectionRange(), t = e.focusNode, r = e.focusOffset;
  if (!t)
    return;
  let i = vs(t), s, o;
  for (; ; )
    if (r < i) {
      if (t.nodeType != 1)
        break;
      let l = t.childNodes[r];
      if (Yr(l, 1))
        s = t, o = ++r;
      else
        break;
    } else {
      if (Qh(t))
        break;
      {
        let l = t.nextSibling;
        for (; l && Yr(l, 1); )
          s = l.parentNode, o = xe(l) + 1, l = l.nextSibling;
        if (l)
          t = l, r = 0, i = vs(t);
        else {
          if (t = t.parentNode, t == n.dom)
            break;
          r = i = 0;
        }
      }
    }
  s && Ul(n, s, o);
}
function Qh(n) {
  let e = n.pmViewDesc;
  return e && e.node && e.node.isBlock;
}
function Lb(n, e) {
  for (; n && e == n.childNodes.length && !yi(n); )
    e = xe(n) + 1, n = n.parentNode;
  for (; n && e < n.childNodes.length; ) {
    let t = n.childNodes[e];
    if (t.nodeType == 3)
      return t;
    if (t.nodeType == 1 && t.contentEditable == "false")
      break;
    n = t, e = 0;
  }
}
function Pb(n, e) {
  for (; n && !e && !yi(n); )
    e = xe(n), n = n.parentNode;
  for (; n && e; ) {
    let t = n.childNodes[e - 1];
    if (t.nodeType == 3)
      return t;
    if (t.nodeType == 1 && t.contentEditable == "false")
      break;
    n = t, e = n.childNodes.length;
  }
}
function Ul(n, e, t) {
  if (e.nodeType != 3) {
    let s, o;
    (o = Lb(e, t)) ? (e = o, t = 0) : (s = Pb(e, t)) && (e = s, t = s.nodeValue.length);
  }
  let r = n.domSelection();
  if (!r)
    return;
  if (co(r)) {
    let s = document.createRange();
    s.setEnd(e, t), s.setStart(e, t), r.removeAllRanges(), r.addRange(s);
  } else r.extend && r.extend(e, t);
  n.domObserver.setCurSelection();
  let { state: i } = n;
  setTimeout(() => {
    n.state == i && Zt(n);
  }, 50);
}
function fd(n, e) {
  let t = n.state.doc.resolve(e);
  if (!(Re || ob) && t.parent.inlineContent) {
    let i = n.coordsAtPos(e);
    if (e > t.start()) {
      let s = n.coordsAtPos(e - 1), o = (s.top + s.bottom) / 2;
      if (o > i.top && o < i.bottom && Math.abs(s.left - i.left) > 1)
        return s.left < i.left ? "ltr" : "rtl";
    }
    if (e < t.end()) {
      let s = n.coordsAtPos(e + 1), o = (s.top + s.bottom) / 2;
      if (o > i.top && o < i.bottom && Math.abs(s.left - i.left) > 1)
        return s.left > i.left ? "ltr" : "rtl";
    }
  }
  return getComputedStyle(n.dom).direction == "rtl" ? "rtl" : "ltr";
}
function hd(n, e, t) {
  let r = n.state.selection;
  if (r instanceof z && !r.empty || t.indexOf("s") > -1 || ot && t.indexOf("m") > -1)
    return !1;
  let { $from: i, $to: s } = r;
  if (!i.parent.inlineContent || n.endOfTextblock(e < 0 ? "up" : "down")) {
    let o = Vl(n.state, e);
    if (o && o instanceof B)
      return ln(n, o);
  }
  if (!i.parent.inlineContent) {
    let o = e < 0 ? i : s, l = r instanceof Qe ? V.near(o, e) : V.findFrom(o, e);
    return l ? ln(n, l) : !1;
  }
  return !1;
}
function pd(n, e) {
  if (!(n.state.selection instanceof z))
    return !0;
  let { $head: t, $anchor: r, empty: i } = n.state.selection;
  if (!t.sameParent(r))
    return !0;
  if (!i)
    return !1;
  if (n.endOfTextblock(e > 0 ? "forward" : "backward"))
    return !0;
  let s = !t.textOffset && (e < 0 ? t.nodeBefore : t.nodeAfter);
  if (s && !s.isText) {
    let o = n.state.tr;
    return e < 0 ? o.delete(t.pos - s.nodeSize, t.pos) : o.delete(t.pos, t.pos + s.nodeSize), n.dispatch(o), !0;
  }
  return !1;
}
function md(n, e, t) {
  n.domObserver.stop(), e.contentEditable = t, n.domObserver.start();
}
function Bb(n) {
  if (!qe || n.state.selection.$head.parentOffset > 0)
    return !1;
  let { focusNode: e, focusOffset: t } = n.domSelectionRange();
  if (e && e.nodeType == 1 && t == 0 && e.firstChild && e.firstChild.contentEditable == "false") {
    let r = e.firstChild;
    md(n, r, "true"), setTimeout(() => md(n, r, "false"), 20);
  }
  return !1;
}
function zb(n) {
  let e = "";
  return n.ctrlKey && (e += "c"), n.metaKey && (e += "m"), n.altKey && (e += "a"), n.shiftKey && (e += "s"), e;
}
function Hb(n, e) {
  let t = e.keyCode, r = zb(e);
  if (t == 8 || ot && t == 72 && r == "c")
    return pd(n, -1) || or(n, -1);
  if (t == 46 && !e.shiftKey || ot && t == 68 && r == "c")
    return pd(n, 1) || or(n, 1);
  if (t == 13 || t == 27)
    return !0;
  if (t == 37 || ot && t == 66 && r == "c") {
    let i = t == 37 ? fd(n, n.state.selection.from) == "ltr" ? -1 : 1 : -1;
    return dd(n, i, r) || or(n, i);
  } else if (t == 39 || ot && t == 70 && r == "c") {
    let i = t == 39 ? fd(n, n.state.selection.from) == "ltr" ? 1 : -1 : 1;
    return dd(n, i, r) || or(n, i);
  } else {
    if (t == 38 || ot && t == 80 && r == "c")
      return hd(n, -1, r) || or(n, -1);
    if (t == 40 || ot && t == 78 && r == "c")
      return Bb(n) || hd(n, 1, r) || or(n, 1);
    if (r == (ot ? "m" : "c") && (t == 66 || t == 73 || t == 89 || t == 90))
      return !0;
  }
  return !1;
}
function va(n, e) {
  n.someProp("transformCopied", (h) => {
    e = h(e, n);
  });
  let t = [], { content: r, openStart: i, openEnd: s } = e;
  for (; i > 1 && s > 1 && r.childCount == 1 && r.firstChild.childCount == 1; ) {
    i--, s--;
    let h = r.firstChild;
    t.push(h.type.name, h.attrs != h.type.defaultAttrs ? h.attrs : null), r = h.content;
  }
  let o = n.someProp("clipboardSerializer") || Wn.fromSchema(n.state.schema), l = sp(), a = l.createElement("div");
  a.appendChild(o.serializeFragment(r, { document: l }));
  let c = a.firstChild, u, d = 0;
  for (; c && c.nodeType == 1 && (u = ip[c.nodeName.toLowerCase()]); ) {
    for (let h = u.length - 1; h >= 0; h--) {
      let p = l.createElement(u[h]);
      for (; a.firstChild; )
        p.appendChild(a.firstChild);
      a.appendChild(p), d++;
    }
    c = a.firstChild;
  }
  c && c.nodeType == 1 && c.setAttribute("data-pm-slice", `${i} ${s}${d ? ` -${d}` : ""} ${JSON.stringify(t)}`);
  let f = n.someProp("clipboardTextSerializer", (h) => h(e, n)) || e.content.textBetween(0, e.content.size, `

`);
  return { dom: a, text: f, slice: e };
}
function ep(n, e, t, r, i) {
  let s = i.parent.type.spec.code, o, l;
  if (!t && !e)
    return null;
  let a = e && (r || s || !t);
  if (a) {
    if (n.someProp("transformPastedText", (f) => {
      e = f(e, s || r, n);
    }), s)
      return e ? new O(A.from(n.state.schema.text(e.replace(/\r\n?/g, `
`))), 0, 0) : O.empty;
    let d = n.someProp("clipboardTextParser", (f) => f(e, i, r, n));
    if (d)
      l = d;
    else {
      let f = i.marks(), { schema: h } = n.state, p = Wn.fromSchema(h);
      o = document.createElement("div"), e.split(/(?:\r\n?|\n)+/).forEach((m) => {
        let _ = o.appendChild(document.createElement("p"));
        m && _.appendChild(p.serializeNode(h.text(m, f)));
      });
    }
  } else
    n.someProp("transformPastedHTML", (d) => {
      t = d(t, n);
    }), o = jb(t), bi && Wb(o);
  let c = o && o.querySelector("[data-pm-slice]"), u = c && /^(\d+) (\d+)(?: -(\d+))? (.*)/.exec(c.getAttribute("data-pm-slice") || "");
  if (u && u[3])
    for (let d = +u[3]; d > 0; d--) {
      let f = o.firstChild;
      for (; f && f.nodeType != 1; )
        f = f.nextSibling;
      if (!f)
        break;
      o = f;
    }
  if (l || (l = (n.someProp("clipboardParser") || n.someProp("domParser") || Kr.fromSchema(n.state.schema)).parseSlice(o, {
    preserveWhitespace: !!(a || u),
    context: i,
    ruleFromNode(f) {
      return f.nodeName == "BR" && !f.nextSibling && f.parentNode && !qb.test(f.parentNode.nodeName) ? { ignore: !0 } : null;
    }
  })), u)
    l = Kb(gd(l, +u[1], +u[2]), u[4]);
  else if (l = O.maxOpen(Vb(l.content, i), !0), l.openStart || l.openEnd) {
    let d = 0, f = 0;
    for (let h = l.content.firstChild; d < l.openStart && !h.type.spec.isolating; d++, h = h.firstChild)
      ;
    for (let h = l.content.lastChild; f < l.openEnd && !h.type.spec.isolating; f++, h = h.lastChild)
      ;
    l = gd(l, d, f);
  }
  return n.someProp("transformPasted", (d) => {
    l = d(l, n);
  }), l;
}
const qb = /^(a|abbr|acronym|b|cite|code|del|em|i|ins|kbd|label|output|q|ruby|s|samp|span|strong|sub|sup|time|u|tt|var)$/i;
function Vb(n, e) {
  if (n.childCount < 2)
    return n;
  for (let t = e.depth; t >= 0; t--) {
    let i = e.node(t).contentMatchAt(e.index(t)), s, o = [];
    if (n.forEach((l) => {
      if (!o)
        return;
      let a = i.findWrapping(l.type), c;
      if (!a)
        return o = null;
      if (c = o.length && s.length && np(a, s, l, o[o.length - 1], 0))
        o[o.length - 1] = c;
      else {
        o.length && (o[o.length - 1] = rp(o[o.length - 1], s.length));
        let u = tp(l, a);
        o.push(u), i = i.matchType(u.type), s = a;
      }
    }), o)
      return A.from(o);
  }
  return n;
}
function tp(n, e, t = 0) {
  for (let r = e.length - 1; r >= t; r--)
    n = e[r].create(null, A.from(n));
  return n;
}
function np(n, e, t, r, i) {
  if (i < n.length && i < e.length && n[i] == e[i]) {
    let s = np(n, e, t, r.lastChild, i + 1);
    if (s)
      return r.copy(r.content.replaceChild(r.childCount - 1, s));
    if (r.contentMatchAt(r.childCount).matchType(i == n.length - 1 ? t.type : n[i + 1]))
      return r.copy(r.content.append(A.from(tp(t, n, i + 1))));
  }
}
function rp(n, e) {
  if (e == 0)
    return n;
  let t = n.content.replaceChild(n.childCount - 1, rp(n.lastChild, e - 1)), r = n.contentMatchAt(n.childCount).fillBefore(A.empty, !0);
  return n.copy(t.append(r));
}
function jl(n, e, t, r, i, s) {
  let o = e < 0 ? n.firstChild : n.lastChild, l = o.content;
  return n.childCount > 1 && (s = 0), i < r - 1 && (l = jl(l, e, t, r, i + 1, s)), i >= t && (l = e < 0 ? o.contentMatchAt(0).fillBefore(l, s <= i).append(l) : l.append(o.contentMatchAt(o.childCount).fillBefore(A.empty, !0))), n.replaceChild(e < 0 ? 0 : n.childCount - 1, o.copy(l));
}
function gd(n, e, t) {
  return e < n.openStart && (n = new O(jl(n.content, -1, e, n.openStart, 0, n.openEnd), e, n.openEnd)), t < n.openEnd && (n = new O(jl(n.content, 1, t, n.openEnd, 0, 0), n.openStart, t)), n;
}
const ip = {
  thead: ["table"],
  tbody: ["table"],
  tfoot: ["table"],
  caption: ["table"],
  colgroup: ["table"],
  col: ["table", "colgroup"],
  tr: ["table", "tbody"],
  td: ["table", "tbody", "tr"],
  th: ["table", "tbody", "tr"]
};
let _d = null;
function sp() {
  return _d || (_d = document.implementation.createHTMLDocument("title"));
}
let nl = null;
function Ub(n) {
  let e = window.trustedTypes;
  return e ? (nl || (nl = e.defaultPolicy || e.createPolicy("ProseMirrorClipboard", { createHTML: (t) => t })), nl.createHTML(n)) : n;
}
function jb(n) {
  let e = /^(\s*<meta [^>]*>)*/.exec(n);
  e && (n = n.slice(e[0].length));
  let t = sp().createElement("div"), r = /<([a-z][^>\s]+)/i.exec(n), i;
  if ((i = r && ip[r[1].toLowerCase()]) && (n = i.map((s) => "<" + s + ">").join("") + n + i.map((s) => "</" + s + ">").reverse().join("")), t.innerHTML = Ub(n), i)
    for (let s = 0; s < i.length; s++)
      t = t.querySelector(i[s]) || t;
  return t;
}
function Wb(n) {
  let e = n.querySelectorAll(Re ? "span:not([class]):not([style])" : "span.Apple-converted-space");
  for (let t = 0; t < e.length; t++) {
    let r = e[t];
    r.childNodes.length == 1 && r.textContent == " " && r.parentNode && r.parentNode.replaceChild(n.ownerDocument.createTextNode(" "), r);
  }
}
function Kb(n, e) {
  if (!n.size)
    return n;
  let t = n.content.firstChild.type.schema, r;
  try {
    r = JSON.parse(e);
  } catch {
    return n;
  }
  let { content: i, openStart: s, openEnd: o } = n;
  for (let l = r.length - 2; l >= 0; l -= 2) {
    let a = t.nodes[r[l]];
    if (!a || a.hasRequiredAttrs())
      break;
    i = A.from(a.create(r[l + 1], i)), s++, o++;
  }
  return new O(i, s, o);
}
const Ve = {}, Ue = {}, Gb = { touchstart: !0, touchmove: !0 };
class Jb {
  constructor() {
    this.shiftKey = !1, this.mouseDown = null, this.lastKeyCode = null, this.lastKeyCodeTime = 0, this.lastClick = { time: 0, x: 0, y: 0, type: "", button: 0 }, this.lastSelectionOrigin = null, this.lastSelectionTime = 0, this.lastIOSEnter = 0, this.lastIOSEnterFallbackTimeout = -1, this.lastFocus = 0, this.lastTouch = 0, this.lastChromeDelete = 0, this.composing = !1, this.compositionNode = null, this.composingTimeout = -1, this.compositionNodes = [], this.compositionEndedAt = -2e8, this.compositionID = 1, this.compositionPendingChanges = 0, this.domChangeCount = 0, this.eventHandlers = /* @__PURE__ */ Object.create(null), this.hideSelectionGuard = null;
  }
}
function Yb(n) {
  for (let e in Ve) {
    let t = Ve[e];
    n.dom.addEventListener(e, n.input.eventHandlers[e] = (r) => {
      Zb(n, r) && !Ea(n, r) && (n.editable || !(r.type in Ue)) && t(n, r);
    }, Gb[e] ? { passive: !0 } : void 0);
  }
  qe && n.dom.addEventListener("input", () => null), Wl(n);
}
function mn(n, e) {
  n.input.lastSelectionOrigin = e, n.input.lastSelectionTime = Date.now();
}
function Xb(n) {
  n.domObserver.stop();
  for (let e in n.input.eventHandlers)
    n.dom.removeEventListener(e, n.input.eventHandlers[e]);
  clearTimeout(n.input.composingTimeout), clearTimeout(n.input.lastIOSEnterFallbackTimeout);
}
function Wl(n) {
  n.someProp("handleDOMEvents", (e) => {
    for (let t in e)
      n.input.eventHandlers[t] || n.dom.addEventListener(t, n.input.eventHandlers[t] = (r) => Ea(n, r));
  });
}
function Ea(n, e) {
  return n.someProp("handleDOMEvents", (t) => {
    let r = t[e.type];
    return r ? r(n, e) || e.defaultPrevented : !1;
  });
}
function Zb(n, e) {
  if (!e.bubbles)
    return !0;
  if (e.defaultPrevented)
    return !1;
  for (let t = e.target; t != n.dom; t = t.parentNode)
    if (!t || t.nodeType == 11 || t.pmViewDesc && t.pmViewDesc.stopEvent(e))
      return !1;
  return !0;
}
function Qb(n, e) {
  !Ea(n, e) && Ve[e.type] && (n.editable || !(e.type in Ue)) && Ve[e.type](n, e);
}
Ue.keydown = (n, e) => {
  let t = e;
  if (n.input.shiftKey = t.keyCode == 16 || t.shiftKey, !lp(n, t) && (n.input.lastKeyCode = t.keyCode, n.input.lastKeyCodeTime = Date.now(), !(Yt && Re && t.keyCode == 13)))
    if (t.keyCode != 229 && n.domObserver.forceFlush(), br && t.keyCode == 13 && !t.ctrlKey && !t.altKey && !t.metaKey) {
      let r = Date.now();
      n.input.lastIOSEnter = r, n.input.lastIOSEnterFallbackTimeout = setTimeout(() => {
        n.input.lastIOSEnter == r && (n.someProp("handleKeyDown", (i) => i(n, An(13, "Enter"))), n.input.lastIOSEnter = 0);
      }, 200);
    } else n.someProp("handleKeyDown", (r) => r(n, t)) || Hb(n, t) ? t.preventDefault() : mn(n, "key");
};
Ue.keyup = (n, e) => {
  e.keyCode == 16 && (n.input.shiftKey = !1);
};
Ue.keypress = (n, e) => {
  let t = e;
  if (lp(n, t) || !t.charCode || t.ctrlKey && !t.altKey || ot && t.metaKey)
    return;
  if (n.someProp("handleKeyPress", (i) => i(n, t))) {
    t.preventDefault();
    return;
  }
  let r = n.state.selection;
  if (!(r instanceof z) || !r.$from.sameParent(r.$to)) {
    let i = String.fromCharCode(t.charCode), s = () => n.state.tr.insertText(i).scrollIntoView();
    !/[\r\n]/.test(i) && !n.someProp("handleTextInput", (o) => o(n, r.$from.pos, r.$to.pos, i, s)) && n.dispatch(s()), t.preventDefault();
  }
};
function fo(n) {
  return { left: n.clientX, top: n.clientY };
}
function ek(n, e) {
  let t = e.x - n.clientX, r = e.y - n.clientY;
  return t * t + r * r < 100;
}
function Da(n, e, t, r, i) {
  if (r == -1)
    return !1;
  let s = n.state.doc.resolve(r);
  for (let o = s.depth + 1; o > 0; o--)
    if (n.someProp(e, (l) => o > s.depth ? l(n, t, s.nodeAfter, s.before(o), i, !0) : l(n, t, s.node(o), s.before(o), i, !1)))
      return !0;
  return !1;
}
function gr(n, e, t) {
  if (n.focused || n.focus(), n.state.selection.eq(e))
    return;
  let r = n.state.tr.setSelection(e);
  r.setMeta("pointer", !0), n.dispatch(r);
}
function tk(n, e) {
  if (e == -1)
    return !1;
  let t = n.state.doc.resolve(e), r = t.nodeAfter;
  return r && r.isAtom && B.isSelectable(r) ? (gr(n, new B(t)), !0) : !1;
}
function nk(n, e) {
  if (e == -1)
    return !1;
  let t = n.state.selection, r, i;
  t instanceof B && (r = t.node);
  let s = n.state.doc.resolve(e);
  for (let o = s.depth + 1; o > 0; o--) {
    let l = o > s.depth ? s.nodeAfter : s.node(o);
    if (B.isSelectable(l)) {
      r && t.$from.depth > 0 && o >= t.$from.depth && s.before(t.$from.depth + 1) == t.$from.pos ? i = s.before(t.$from.depth) : i = s.before(o);
      break;
    }
  }
  return i != null ? (gr(n, B.create(n.state.doc, i)), !0) : !1;
}
function rk(n, e, t, r, i) {
  return Da(n, "handleClickOn", e, t, r) || n.someProp("handleClick", (s) => s(n, e, r)) || (i ? nk(n, t) : tk(n, t));
}
function ik(n, e, t, r) {
  return Da(n, "handleDoubleClickOn", e, t, r) || n.someProp("handleDoubleClick", (i) => i(n, e, r));
}
function sk(n, e, t, r) {
  return Da(n, "handleTripleClickOn", e, t, r) || n.someProp("handleTripleClick", (i) => i(n, e, r)) || ok(n, t, r);
}
function ok(n, e, t) {
  if (t.button != 0)
    return !1;
  let r = n.state.doc;
  if (e == -1)
    return r.inlineContent ? (gr(n, z.create(r, 0, r.content.size)), !0) : !1;
  let i = r.resolve(e);
  for (let s = i.depth + 1; s > 0; s--) {
    let o = s > i.depth ? i.nodeAfter : i.node(s), l = i.before(s);
    if (o.inlineContent)
      gr(n, z.create(r, l + 1, l + 1 + o.content.size));
    else if (B.isSelectable(o))
      gr(n, B.create(r, l));
    else
      continue;
    return !0;
  }
}
function Sa(n) {
  return Es(n);
}
const op = ot ? "metaKey" : "ctrlKey";
Ve.mousedown = (n, e) => {
  let t = e;
  n.input.shiftKey = t.shiftKey;
  let r = Sa(n), i = Date.now(), s = "singleClick";
  i - n.input.lastClick.time < 500 && ek(t, n.input.lastClick) && !t[op] && n.input.lastClick.button == t.button && (n.input.lastClick.type == "singleClick" ? s = "doubleClick" : n.input.lastClick.type == "doubleClick" && (s = "tripleClick")), n.input.lastClick = { time: i, x: t.clientX, y: t.clientY, type: s, button: t.button };
  let o = n.posAtCoords(fo(t));
  o && (s == "singleClick" ? (n.input.mouseDown && n.input.mouseDown.done(), n.input.mouseDown = new lk(n, o, t, !!r)) : (s == "doubleClick" ? ik : sk)(n, o.pos, o.inside, t) ? t.preventDefault() : mn(n, "pointer"));
};
class lk {
  constructor(e, t, r, i) {
    this.view = e, this.pos = t, this.event = r, this.flushed = i, this.delayedSelectionSync = !1, this.mightDrag = null, this.startDoc = e.state.doc, this.selectNode = !!r[op], this.allowDefault = r.shiftKey;
    let s, o;
    if (t.inside > -1)
      s = e.state.doc.nodeAt(t.inside), o = t.inside;
    else {
      let u = e.state.doc.resolve(t.pos);
      s = u.parent, o = u.depth ? u.before() : 0;
    }
    const l = i ? null : r.target, a = l ? e.docView.nearestDesc(l, !0) : null;
    this.target = a && a.dom.nodeType == 1 ? a.dom : null;
    let { selection: c } = e.state;
    (r.button == 0 && s.type.spec.draggable && s.type.spec.selectable !== !1 || c instanceof B && c.from <= o && c.to > o) && (this.mightDrag = {
      node: s,
      pos: o,
      addAttr: !!(this.target && !this.target.draggable),
      setUneditable: !!(this.target && St && !this.target.hasAttribute("contentEditable"))
    }), this.target && this.mightDrag && (this.mightDrag.addAttr || this.mightDrag.setUneditable) && (this.view.domObserver.stop(), this.mightDrag.addAttr && (this.target.draggable = !0), this.mightDrag.setUneditable && setTimeout(() => {
      this.view.input.mouseDown == this && this.target.setAttribute("contentEditable", "false");
    }, 20), this.view.domObserver.start()), e.root.addEventListener("mouseup", this.up = this.up.bind(this)), e.root.addEventListener("mousemove", this.move = this.move.bind(this)), mn(e, "pointer");
  }
  done() {
    this.view.root.removeEventListener("mouseup", this.up), this.view.root.removeEventListener("mousemove", this.move), this.mightDrag && this.target && (this.view.domObserver.stop(), this.mightDrag.addAttr && this.target.removeAttribute("draggable"), this.mightDrag.setUneditable && this.target.removeAttribute("contentEditable"), this.view.domObserver.start()), this.delayedSelectionSync && setTimeout(() => Zt(this.view)), this.view.input.mouseDown = null;
  }
  up(e) {
    if (this.done(), !this.view.dom.contains(e.target))
      return;
    let t = this.pos;
    this.view.state.doc != this.startDoc && (t = this.view.posAtCoords(fo(e))), this.updateAllowDefault(e), this.allowDefault || !t ? mn(this.view, "pointer") : rk(this.view, t.pos, t.inside, e, this.selectNode) ? e.preventDefault() : e.button == 0 && (this.flushed || // Safari ignores clicks on draggable elements
    qe && this.mightDrag && !this.mightDrag.node.isAtom || // Chrome will sometimes treat a node selection as a
    // cursor, but still report that the node is selected
    // when asked through getSelection. You'll then get a
    // situation where clicking at the point where that
    // (hidden) cursor is doesn't change the selection, and
    // thus doesn't get a reaction from ProseMirror. This
    // works around that.
    Re && !this.view.state.selection.visible && Math.min(Math.abs(t.pos - this.view.state.selection.from), Math.abs(t.pos - this.view.state.selection.to)) <= 2) ? (gr(this.view, V.near(this.view.state.doc.resolve(t.pos))), e.preventDefault()) : mn(this.view, "pointer");
  }
  move(e) {
    this.updateAllowDefault(e), mn(this.view, "pointer"), e.buttons == 0 && this.done();
  }
  updateAllowDefault(e) {
    !this.allowDefault && (Math.abs(this.event.x - e.clientX) > 4 || Math.abs(this.event.y - e.clientY) > 4) && (this.allowDefault = !0);
  }
}
Ve.touchstart = (n) => {
  n.input.lastTouch = Date.now(), Sa(n), mn(n, "pointer");
};
Ve.touchmove = (n) => {
  n.input.lastTouch = Date.now(), mn(n, "pointer");
};
Ve.contextmenu = (n) => Sa(n);
function lp(n, e) {
  return n.composing ? !0 : qe && Math.abs(e.timeStamp - n.input.compositionEndedAt) < 500 ? (n.input.compositionEndedAt = -2e8, !0) : !1;
}
const ak = Yt ? 5e3 : -1;
Ue.compositionstart = Ue.compositionupdate = (n) => {
  if (!n.composing) {
    n.domObserver.flush();
    let { state: e } = n, t = e.selection.$to;
    if (e.selection instanceof z && (e.storedMarks || !t.textOffset && t.parentOffset && t.nodeBefore.marks.some((r) => r.type.spec.inclusive === !1)))
      n.markCursor = n.state.storedMarks || t.marks(), Es(n, !0), n.markCursor = null;
    else if (Es(n, !e.selection.empty), St && e.selection.empty && t.parentOffset && !t.textOffset && t.nodeBefore.marks.length) {
      let r = n.domSelectionRange();
      for (let i = r.focusNode, s = r.focusOffset; i && i.nodeType == 1 && s != 0; ) {
        let o = s < 0 ? i.lastChild : i.childNodes[s - 1];
        if (!o)
          break;
        if (o.nodeType == 3) {
          let l = n.domSelection();
          l && l.collapse(o, o.nodeValue.length);
          break;
        } else
          i = o, s = -1;
      }
    }
    n.input.composing = !0;
  }
  ap(n, ak);
};
Ue.compositionend = (n, e) => {
  n.composing && (n.input.composing = !1, n.input.compositionEndedAt = e.timeStamp, n.input.compositionPendingChanges = n.domObserver.pendingRecords().length ? n.input.compositionID : 0, n.input.compositionNode = null, n.input.compositionPendingChanges && Promise.resolve().then(() => n.domObserver.flush()), n.input.compositionID++, ap(n, 20));
};
function ap(n, e) {
  clearTimeout(n.input.composingTimeout), e > -1 && (n.input.composingTimeout = setTimeout(() => Es(n), e));
}
function cp(n) {
  for (n.composing && (n.input.composing = !1, n.input.compositionEndedAt = uk()); n.input.compositionNodes.length > 0; )
    n.input.compositionNodes.pop().markParentsDirty();
}
function ck(n) {
  let e = n.domSelectionRange();
  if (!e.focusNode)
    return null;
  let t = tb(e.focusNode, e.focusOffset), r = nb(e.focusNode, e.focusOffset);
  if (t && r && t != r) {
    let i = r.pmViewDesc, s = n.domObserver.lastChangedTextNode;
    if (t == s || r == s)
      return s;
    if (!i || !i.isText(r.nodeValue))
      return r;
    if (n.input.compositionNode == r) {
      let o = t.pmViewDesc;
      if (!(!o || !o.isText(t.nodeValue)))
        return r;
    }
  }
  return t || r;
}
function uk() {
  let n = document.createEvent("Event");
  return n.initEvent("event", !0, !0), n.timeStamp;
}
function Es(n, e = !1) {
  if (!(Yt && n.domObserver.flushingSoon >= 0)) {
    if (n.domObserver.forceFlush(), cp(n), e || n.docView && n.docView.dirty) {
      let t = ka(n), r = n.state.selection;
      return t && !t.eq(r) ? n.dispatch(n.state.tr.setSelection(t)) : (n.markCursor || e) && !r.$from.node(r.$from.sharedDepth(r.to)).inlineContent ? n.dispatch(n.state.tr.deleteSelection()) : n.updateState(n.state), !0;
    }
    return !1;
  }
}
function dk(n, e) {
  if (!n.dom.parentNode)
    return;
  let t = n.dom.parentNode.appendChild(document.createElement("div"));
  t.appendChild(e), t.style.cssText = "position: fixed; left: -10000px; top: 10px";
  let r = getSelection(), i = document.createRange();
  i.selectNodeContents(e), n.dom.blur(), r.removeAllRanges(), r.addRange(i), setTimeout(() => {
    t.parentNode && t.parentNode.removeChild(t), n.focus();
  }, 50);
}
const ci = Ge && gn < 15 || br && lb < 604;
Ve.copy = Ue.cut = (n, e) => {
  let t = e, r = n.state.selection, i = t.type == "cut";
  if (r.empty)
    return;
  let s = ci ? null : t.clipboardData, o = r.content(), { dom: l, text: a } = va(n, o);
  s ? (t.preventDefault(), s.clearData(), s.setData("text/html", l.innerHTML), s.setData("text/plain", a)) : dk(n, l), i && n.dispatch(n.state.tr.deleteSelection().scrollIntoView().setMeta("uiEvent", "cut"));
};
function fk(n) {
  return n.openStart == 0 && n.openEnd == 0 && n.content.childCount == 1 ? n.content.firstChild : null;
}
function hk(n, e) {
  if (!n.dom.parentNode)
    return;
  let t = n.input.shiftKey || n.state.selection.$from.parent.type.spec.code, r = n.dom.parentNode.appendChild(document.createElement(t ? "textarea" : "div"));
  t || (r.contentEditable = "true"), r.style.cssText = "position: fixed; left: -10000px; top: 10px", r.focus();
  let i = n.input.shiftKey && n.input.lastKeyCode != 45;
  setTimeout(() => {
    n.focus(), r.parentNode && r.parentNode.removeChild(r), t ? ui(n, r.value, null, i, e) : ui(n, r.textContent, r.innerHTML, i, e);
  }, 50);
}
function ui(n, e, t, r, i) {
  let s = ep(n, e, t, r, n.state.selection.$from);
  if (n.someProp("handlePaste", (a) => a(n, i, s || O.empty)))
    return !0;
  if (!s)
    return !1;
  let o = fk(s), l = o ? n.state.tr.replaceSelectionWith(o, r) : n.state.tr.replaceSelection(s);
  return n.dispatch(l.scrollIntoView().setMeta("paste", !0).setMeta("uiEvent", "paste")), !0;
}
function up(n) {
  let e = n.getData("text/plain") || n.getData("Text");
  if (e)
    return e;
  let t = n.getData("text/uri-list");
  return t ? t.replace(/\r?\n/g, " ") : "";
}
Ue.paste = (n, e) => {
  let t = e;
  if (n.composing && !Yt)
    return;
  let r = ci ? null : t.clipboardData, i = n.input.shiftKey && n.input.lastKeyCode != 45;
  r && ui(n, up(r), r.getData("text/html"), i, t) ? t.preventDefault() : hk(n, t);
};
class dp {
  constructor(e, t, r) {
    this.slice = e, this.move = t, this.node = r;
  }
}
const pk = ot ? "altKey" : "ctrlKey";
function fp(n, e) {
  let t = n.someProp("dragCopies", (r) => !r(e));
  return t ?? !e[pk];
}
Ve.dragstart = (n, e) => {
  let t = e, r = n.input.mouseDown;
  if (r && r.done(), !t.dataTransfer)
    return;
  let i = n.state.selection, s = i.empty ? null : n.posAtCoords(fo(t)), o;
  if (!(s && s.pos >= i.from && s.pos <= (i instanceof B ? i.to - 1 : i.to))) {
    if (r && r.mightDrag)
      o = B.create(n.state.doc, r.mightDrag.pos);
    else if (t.target && t.target.nodeType == 1) {
      let d = n.docView.nearestDesc(t.target, !0);
      d && d.node.type.spec.draggable && d != n.docView && (o = B.create(n.state.doc, d.posBefore));
    }
  }
  let l = (o || n.state.selection).content(), { dom: a, text: c, slice: u } = va(n, l);
  (!t.dataTransfer.files.length || !Re || Ph > 120) && t.dataTransfer.clearData(), t.dataTransfer.setData(ci ? "Text" : "text/html", a.innerHTML), t.dataTransfer.effectAllowed = "copyMove", ci || t.dataTransfer.setData("text/plain", c), n.dragging = new dp(u, fp(n, t), o);
};
Ve.dragend = (n) => {
  let e = n.dragging;
  window.setTimeout(() => {
    n.dragging == e && (n.dragging = null);
  }, 50);
};
Ue.dragover = Ue.dragenter = (n, e) => e.preventDefault();
Ue.drop = (n, e) => {
  let t = e, r = n.dragging;
  if (n.dragging = null, !t.dataTransfer)
    return;
  let i = n.posAtCoords(fo(t));
  if (!i)
    return;
  let s = n.state.doc.resolve(i.pos), o = r && r.slice;
  o ? n.someProp("transformPasted", (p) => {
    o = p(o, n);
  }) : o = ep(n, up(t.dataTransfer), ci ? null : t.dataTransfer.getData("text/html"), !1, s);
  let l = !!(r && fp(n, t));
  if (n.someProp("handleDrop", (p) => p(n, t, o || O.empty, l))) {
    t.preventDefault();
    return;
  }
  if (!o)
    return;
  t.preventDefault();
  let a = o ? Th(n.state.doc, s.pos, o) : s.pos;
  a == null && (a = s.pos);
  let c = n.state.tr;
  if (l) {
    let { node: p } = r;
    p ? p.replace(c) : c.deleteSelection();
  }
  let u = c.mapping.map(a), d = o.openStart == 0 && o.openEnd == 0 && o.content.childCount == 1, f = c.doc;
  if (d ? c.replaceRangeWith(u, u, o.content.firstChild) : c.replaceRange(u, u, o), c.doc.eq(f))
    return;
  let h = c.doc.resolve(u);
  if (d && B.isSelectable(o.content.firstChild) && h.nodeAfter && h.nodeAfter.sameMarkup(o.content.firstChild))
    c.setSelection(new B(h));
  else {
    let p = c.mapping.map(a);
    c.mapping.maps[c.mapping.maps.length - 1].forEach((m, _, b, y) => p = y), c.setSelection(wa(n, h, c.doc.resolve(p)));
  }
  n.focus(), n.dispatch(c.setMeta("uiEvent", "drop"));
};
Ve.focus = (n) => {
  n.input.lastFocus = Date.now(), n.focused || (n.domObserver.stop(), n.dom.classList.add("ProseMirror-focused"), n.domObserver.start(), n.focused = !0, setTimeout(() => {
    n.docView && n.hasFocus() && !n.domObserver.currentSelection.eq(n.domSelectionRange()) && Zt(n);
  }, 20));
};
Ve.blur = (n, e) => {
  let t = e;
  n.focused && (n.domObserver.stop(), n.dom.classList.remove("ProseMirror-focused"), n.domObserver.start(), t.relatedTarget && n.dom.contains(t.relatedTarget) && n.domObserver.currentSelection.clear(), n.focused = !1);
};
Ve.beforeinput = (n, e) => {
  if (Re && Yt && e.inputType == "deleteContentBackward") {
    n.domObserver.flushSoon();
    let { domChangeCount: r } = n.input;
    setTimeout(() => {
      if (n.input.domChangeCount != r || (n.dom.blur(), n.focus(), n.someProp("handleKeyDown", (s) => s(n, An(8, "Backspace")))))
        return;
      let { $cursor: i } = n.state.selection;
      i && i.pos > 0 && n.dispatch(n.state.tr.delete(i.pos - 1, i.pos).scrollIntoView());
    }, 50);
  }
};
for (let n in Ue)
  Ve[n] = Ue[n];
function di(n, e) {
  if (n == e)
    return !0;
  for (let t in n)
    if (n[t] !== e[t])
      return !1;
  for (let t in e)
    if (!(t in n))
      return !1;
  return !0;
}
class Ds {
  constructor(e, t) {
    this.toDOM = e, this.spec = t || In, this.side = this.spec.side || 0;
  }
  map(e, t, r, i) {
    let { pos: s, deleted: o } = e.mapResult(t.from + i, this.side < 0 ? -1 : 1);
    return o ? null : new Be(s - r, s - r, this);
  }
  valid() {
    return !0;
  }
  eq(e) {
    return this == e || e instanceof Ds && (this.spec.key && this.spec.key == e.spec.key || this.toDOM == e.toDOM && di(this.spec, e.spec));
  }
  destroy(e) {
    this.spec.destroy && this.spec.destroy(e);
  }
}
class yn {
  constructor(e, t) {
    this.attrs = e, this.spec = t || In;
  }
  map(e, t, r, i) {
    let s = e.map(t.from + i, this.spec.inclusiveStart ? -1 : 1) - r, o = e.map(t.to + i, this.spec.inclusiveEnd ? 1 : -1) - r;
    return s >= o ? null : new Be(s, o, this);
  }
  valid(e, t) {
    return t.from < t.to;
  }
  eq(e) {
    return this == e || e instanceof yn && di(this.attrs, e.attrs) && di(this.spec, e.spec);
  }
  static is(e) {
    return e.type instanceof yn;
  }
  destroy() {
  }
}
class Ca {
  constructor(e, t) {
    this.attrs = e, this.spec = t || In;
  }
  map(e, t, r, i) {
    let s = e.mapResult(t.from + i, 1);
    if (s.deleted)
      return null;
    let o = e.mapResult(t.to + i, -1);
    return o.deleted || o.pos <= s.pos ? null : new Be(s.pos - r, o.pos - r, this);
  }
  valid(e, t) {
    let { index: r, offset: i } = e.content.findIndex(t.from), s;
    return i == t.from && !(s = e.child(r)).isText && i + s.nodeSize == t.to;
  }
  eq(e) {
    return this == e || e instanceof Ca && di(this.attrs, e.attrs) && di(this.spec, e.spec);
  }
  destroy() {
  }
}
class Be {
  /**
  @internal
  */
  constructor(e, t, r) {
    this.from = e, this.to = t, this.type = r;
  }
  /**
  @internal
  */
  copy(e, t) {
    return new Be(e, t, this.type);
  }
  /**
  @internal
  */
  eq(e, t = 0) {
    return this.type.eq(e.type) && this.from + t == e.from && this.to + t == e.to;
  }
  /**
  @internal
  */
  map(e, t, r) {
    return this.type.map(e, this, t, r);
  }
  /**
  Creates a widget decoration, which is a DOM node that's shown in
  the document at the given position. It is recommended that you
  delay rendering the widget by passing a function that will be
  called when the widget is actually drawn in a view, but you can
  also directly pass a DOM node. `getPos` can be used to find the
  widget's current document position.
  */
  static widget(e, t, r) {
    return new Be(e, e, new Ds(t, r));
  }
  /**
  Creates an inline decoration, which adds the given attributes to
  each inline node between `from` and `to`.
  */
  static inline(e, t, r, i) {
    return new Be(e, t, new yn(r, i));
  }
  /**
  Creates a node decoration. `from` and `to` should point precisely
  before and after a node in the document. That node, and only that
  node, will receive the given attributes.
  */
  static node(e, t, r, i) {
    return new Be(e, t, new Ca(r, i));
  }
  /**
  The spec provided when creating this decoration. Can be useful
  if you've stored extra information in that object.
  */
  get spec() {
    return this.type.spec;
  }
  /**
  @internal
  */
  get inline() {
    return this.type instanceof yn;
  }
  /**
  @internal
  */
  get widget() {
    return this.type instanceof Ds;
  }
}
const ar = [], In = {};
class se {
  /**
  @internal
  */
  constructor(e, t) {
    this.local = e.length ? e : ar, this.children = t.length ? t : ar;
  }
  /**
  Create a set of decorations, using the structure of the given
  document. This will consume (modify) the `decorations` array, so
  you must make a copy if you want need to preserve that.
  */
  static create(e, t) {
    return t.length ? Ss(t, e, 0, In) : Ie;
  }
  /**
  Find all decorations in this set which touch the given range
  (including decorations that start or end directly at the
  boundaries) and match the given predicate on their spec. When
  `start` and `end` are omitted, all decorations in the set are
  considered. When `predicate` isn't given, all decorations are
  assumed to match.
  */
  find(e, t, r) {
    let i = [];
    return this.findInner(e ?? 0, t ?? 1e9, i, 0, r), i;
  }
  findInner(e, t, r, i, s) {
    for (let o = 0; o < this.local.length; o++) {
      let l = this.local[o];
      l.from <= t && l.to >= e && (!s || s(l.spec)) && r.push(l.copy(l.from + i, l.to + i));
    }
    for (let o = 0; o < this.children.length; o += 3)
      if (this.children[o] < t && this.children[o + 1] > e) {
        let l = this.children[o] + 1;
        this.children[o + 2].findInner(e - l, t - l, r, i + l, s);
      }
  }
  /**
  Map the set of decorations in response to a change in the
  document.
  */
  map(e, t, r) {
    return this == Ie || e.maps.length == 0 ? this : this.mapInner(e, t, 0, 0, r || In);
  }
  /**
  @internal
  */
  mapInner(e, t, r, i, s) {
    let o;
    for (let l = 0; l < this.local.length; l++) {
      let a = this.local[l].map(e, r, i);
      a && a.type.valid(t, a) ? (o || (o = [])).push(a) : s.onRemove && s.onRemove(this.local[l].spec);
    }
    return this.children.length ? mk(this.children, o || [], e, t, r, i, s) : o ? new se(o.sort(Rn), ar) : Ie;
  }
  /**
  Add the given array of decorations to the ones in the set,
  producing a new set. Consumes the `decorations` array. Needs
  access to the current document to create the appropriate tree
  structure.
  */
  add(e, t) {
    return t.length ? this == Ie ? se.create(e, t) : this.addInner(e, t, 0) : this;
  }
  addInner(e, t, r) {
    let i, s = 0;
    e.forEach((l, a) => {
      let c = a + r, u;
      if (u = pp(t, l, c)) {
        for (i || (i = this.children.slice()); s < i.length && i[s] < a; )
          s += 3;
        i[s] == a ? i[s + 2] = i[s + 2].addInner(l, u, c + 1) : i.splice(s, 0, a, a + l.nodeSize, Ss(u, l, c + 1, In)), s += 3;
      }
    });
    let o = hp(s ? mp(t) : t, -r);
    for (let l = 0; l < o.length; l++)
      o[l].type.valid(e, o[l]) || o.splice(l--, 1);
    return new se(o.length ? this.local.concat(o).sort(Rn) : this.local, i || this.children);
  }
  /**
  Create a new set that contains the decorations in this set, minus
  the ones in the given array.
  */
  remove(e) {
    return e.length == 0 || this == Ie ? this : this.removeInner(e, 0);
  }
  removeInner(e, t) {
    let r = this.children, i = this.local;
    for (let s = 0; s < r.length; s += 3) {
      let o, l = r[s] + t, a = r[s + 1] + t;
      for (let u = 0, d; u < e.length; u++)
        (d = e[u]) && d.from > l && d.to < a && (e[u] = null, (o || (o = [])).push(d));
      if (!o)
        continue;
      r == this.children && (r = this.children.slice());
      let c = r[s + 2].removeInner(o, l + 1);
      c != Ie ? r[s + 2] = c : (r.splice(s, 3), s -= 3);
    }
    if (i.length) {
      for (let s = 0, o; s < e.length; s++)
        if (o = e[s])
          for (let l = 0; l < i.length; l++)
            i[l].eq(o, t) && (i == this.local && (i = this.local.slice()), i.splice(l--, 1));
    }
    return r == this.children && i == this.local ? this : i.length || r.length ? new se(i, r) : Ie;
  }
  forChild(e, t) {
    if (this == Ie)
      return this;
    if (t.isLeaf)
      return se.empty;
    let r, i;
    for (let l = 0; l < this.children.length; l += 3)
      if (this.children[l] >= e) {
        this.children[l] == e && (r = this.children[l + 2]);
        break;
      }
    let s = e + 1, o = s + t.content.size;
    for (let l = 0; l < this.local.length; l++) {
      let a = this.local[l];
      if (a.from < o && a.to > s && a.type instanceof yn) {
        let c = Math.max(s, a.from) - s, u = Math.min(o, a.to) - s;
        c < u && (i || (i = [])).push(a.copy(c, u));
      }
    }
    if (i) {
      let l = new se(i.sort(Rn), ar);
      return r ? new un([l, r]) : l;
    }
    return r || Ie;
  }
  /**
  @internal
  */
  eq(e) {
    if (this == e)
      return !0;
    if (!(e instanceof se) || this.local.length != e.local.length || this.children.length != e.children.length)
      return !1;
    for (let t = 0; t < this.local.length; t++)
      if (!this.local[t].eq(e.local[t]))
        return !1;
    for (let t = 0; t < this.children.length; t += 3)
      if (this.children[t] != e.children[t] || this.children[t + 1] != e.children[t + 1] || !this.children[t + 2].eq(e.children[t + 2]))
        return !1;
    return !0;
  }
  /**
  @internal
  */
  locals(e) {
    return Aa(this.localsInner(e));
  }
  /**
  @internal
  */
  localsInner(e) {
    if (this == Ie)
      return ar;
    if (e.inlineContent || !this.local.some(yn.is))
      return this.local;
    let t = [];
    for (let r = 0; r < this.local.length; r++)
      this.local[r].type instanceof yn || t.push(this.local[r]);
    return t;
  }
  forEachSet(e) {
    e(this);
  }
}
se.empty = new se([], []);
se.removeOverlap = Aa;
const Ie = se.empty;
class un {
  constructor(e) {
    this.members = e;
  }
  map(e, t) {
    const r = this.members.map((i) => i.map(e, t, In));
    return un.from(r);
  }
  forChild(e, t) {
    if (t.isLeaf)
      return se.empty;
    let r = [];
    for (let i = 0; i < this.members.length; i++) {
      let s = this.members[i].forChild(e, t);
      s != Ie && (s instanceof un ? r = r.concat(s.members) : r.push(s));
    }
    return un.from(r);
  }
  eq(e) {
    if (!(e instanceof un) || e.members.length != this.members.length)
      return !1;
    for (let t = 0; t < this.members.length; t++)
      if (!this.members[t].eq(e.members[t]))
        return !1;
    return !0;
  }
  locals(e) {
    let t, r = !0;
    for (let i = 0; i < this.members.length; i++) {
      let s = this.members[i].localsInner(e);
      if (s.length)
        if (!t)
          t = s;
        else {
          r && (t = t.slice(), r = !1);
          for (let o = 0; o < s.length; o++)
            t.push(s[o]);
        }
    }
    return t ? Aa(r ? t : t.sort(Rn)) : ar;
  }
  // Create a group for the given array of decoration sets, or return
  // a single set when possible.
  static from(e) {
    switch (e.length) {
      case 0:
        return Ie;
      case 1:
        return e[0];
      default:
        return new un(e.every((t) => t instanceof se) ? e : e.reduce((t, r) => t.concat(r instanceof se ? r : r.members), []));
    }
  }
  forEachSet(e) {
    for (let t = 0; t < this.members.length; t++)
      this.members[t].forEachSet(e);
  }
}
function mk(n, e, t, r, i, s, o) {
  let l = n.slice();
  for (let c = 0, u = s; c < t.maps.length; c++) {
    let d = 0;
    t.maps[c].forEach((f, h, p, m) => {
      let _ = m - p - (h - f);
      for (let b = 0; b < l.length; b += 3) {
        let y = l[b + 1];
        if (y < 0 || f > y + u - d)
          continue;
        let g = l[b] + u - d;
        h >= g ? l[b + 1] = f <= g ? -2 : -1 : f >= u && _ && (l[b] += _, l[b + 1] += _);
      }
      d += _;
    }), u = t.maps[c].map(u, -1);
  }
  let a = !1;
  for (let c = 0; c < l.length; c += 3)
    if (l[c + 1] < 0) {
      if (l[c + 1] == -2) {
        a = !0, l[c + 1] = -1;
        continue;
      }
      let u = t.map(n[c] + s), d = u - i;
      if (d < 0 || d >= r.content.size) {
        a = !0;
        continue;
      }
      let f = t.map(n[c + 1] + s, -1), h = f - i, { index: p, offset: m } = r.content.findIndex(d), _ = r.maybeChild(p);
      if (_ && m == d && m + _.nodeSize == h) {
        let b = l[c + 2].mapInner(t, _, u + 1, n[c] + s + 1, o);
        b != Ie ? (l[c] = d, l[c + 1] = h, l[c + 2] = b) : (l[c + 1] = -2, a = !0);
      } else
        a = !0;
    }
  if (a) {
    let c = gk(l, n, e, t, i, s, o), u = Ss(c, r, 0, o);
    e = u.local;
    for (let d = 0; d < l.length; d += 3)
      l[d + 1] < 0 && (l.splice(d, 3), d -= 3);
    for (let d = 0, f = 0; d < u.children.length; d += 3) {
      let h = u.children[d];
      for (; f < l.length && l[f] < h; )
        f += 3;
      l.splice(f, 0, u.children[d], u.children[d + 1], u.children[d + 2]);
    }
  }
  return new se(e.sort(Rn), l);
}
function hp(n, e) {
  if (!e || !n.length)
    return n;
  let t = [];
  for (let r = 0; r < n.length; r++) {
    let i = n[r];
    t.push(new Be(i.from + e, i.to + e, i.type));
  }
  return t;
}
function gk(n, e, t, r, i, s, o) {
  function l(a, c) {
    for (let u = 0; u < a.local.length; u++) {
      let d = a.local[u].map(r, i, c);
      d ? t.push(d) : o.onRemove && o.onRemove(a.local[u].spec);
    }
    for (let u = 0; u < a.children.length; u += 3)
      l(a.children[u + 2], a.children[u] + c + 1);
  }
  for (let a = 0; a < n.length; a += 3)
    n[a + 1] == -1 && l(n[a + 2], e[a] + s + 1);
  return t;
}
function pp(n, e, t) {
  if (e.isLeaf)
    return null;
  let r = t + e.nodeSize, i = null;
  for (let s = 0, o; s < n.length; s++)
    (o = n[s]) && o.from > t && o.to < r && ((i || (i = [])).push(o), n[s] = null);
  return i;
}
function mp(n) {
  let e = [];
  for (let t = 0; t < n.length; t++)
    n[t] != null && e.push(n[t]);
  return e;
}
function Ss(n, e, t, r) {
  let i = [], s = !1;
  e.forEach((l, a) => {
    let c = pp(n, l, a + t);
    if (c) {
      s = !0;
      let u = Ss(c, l, t + a + 1, r);
      u != Ie && i.push(a, a + l.nodeSize, u);
    }
  });
  let o = hp(s ? mp(n) : n, -t).sort(Rn);
  for (let l = 0; l < o.length; l++)
    o[l].type.valid(e, o[l]) || (r.onRemove && r.onRemove(o[l].spec), o.splice(l--, 1));
  return o.length || i.length ? new se(o, i) : Ie;
}
function Rn(n, e) {
  return n.from - e.from || n.to - e.to;
}
function Aa(n) {
  let e = n;
  for (let t = 0; t < e.length - 1; t++) {
    let r = e[t];
    if (r.from != r.to)
      for (let i = t + 1; i < e.length; i++) {
        let s = e[i];
        if (s.from == r.from) {
          s.to != r.to && (e == n && (e = n.slice()), e[i] = s.copy(s.from, r.to), yd(e, i + 1, s.copy(r.to, s.to)));
          continue;
        } else {
          s.from < r.to && (e == n && (e = n.slice()), e[t] = r.copy(r.from, s.from), yd(e, i, r.copy(s.from, r.to)));
          break;
        }
      }
  }
  return e;
}
function yd(n, e, t) {
  for (; e < n.length && Rn(t, n[e]) > 0; )
    e++;
  n.splice(e, 0, t);
}
function rl(n) {
  let e = [];
  return n.someProp("decorations", (t) => {
    let r = t(n.state);
    r && r != Ie && e.push(r);
  }), n.cursorWrapper && e.push(se.create(n.state.doc, [n.cursorWrapper.deco])), un.from(e);
}
const _k = {
  childList: !0,
  characterData: !0,
  characterDataOldValue: !0,
  attributes: !0,
  attributeOldValue: !0,
  subtree: !0
}, yk = Ge && gn <= 11;
class bk {
  constructor() {
    this.anchorNode = null, this.anchorOffset = 0, this.focusNode = null, this.focusOffset = 0;
  }
  set(e) {
    this.anchorNode = e.anchorNode, this.anchorOffset = e.anchorOffset, this.focusNode = e.focusNode, this.focusOffset = e.focusOffset;
  }
  clear() {
    this.anchorNode = this.focusNode = null;
  }
  eq(e) {
    return e.anchorNode == this.anchorNode && e.anchorOffset == this.anchorOffset && e.focusNode == this.focusNode && e.focusOffset == this.focusOffset;
  }
}
class kk {
  constructor(e, t) {
    this.view = e, this.handleDOMChange = t, this.queue = [], this.flushingSoon = -1, this.observer = null, this.currentSelection = new bk(), this.onCharData = null, this.suppressingSelectionUpdates = !1, this.lastChangedTextNode = null, this.observer = window.MutationObserver && new window.MutationObserver((r) => {
      for (let i = 0; i < r.length; i++)
        this.queue.push(r[i]);
      Ge && gn <= 11 && r.some((i) => i.type == "childList" && i.removedNodes.length || i.type == "characterData" && i.oldValue.length > i.target.nodeValue.length) ? this.flushSoon() : this.flush();
    }), yk && (this.onCharData = (r) => {
      this.queue.push({ target: r.target, type: "characterData", oldValue: r.prevValue }), this.flushSoon();
    }), this.onSelectionChange = this.onSelectionChange.bind(this);
  }
  flushSoon() {
    this.flushingSoon < 0 && (this.flushingSoon = window.setTimeout(() => {
      this.flushingSoon = -1, this.flush();
    }, 20));
  }
  forceFlush() {
    this.flushingSoon > -1 && (window.clearTimeout(this.flushingSoon), this.flushingSoon = -1, this.flush());
  }
  start() {
    this.observer && (this.observer.takeRecords(), this.observer.observe(this.view.dom, _k)), this.onCharData && this.view.dom.addEventListener("DOMCharacterDataModified", this.onCharData), this.connectSelection();
  }
  stop() {
    if (this.observer) {
      let e = this.observer.takeRecords();
      if (e.length) {
        for (let t = 0; t < e.length; t++)
          this.queue.push(e[t]);
        window.setTimeout(() => this.flush(), 20);
      }
      this.observer.disconnect();
    }
    this.onCharData && this.view.dom.removeEventListener("DOMCharacterDataModified", this.onCharData), this.disconnectSelection();
  }
  connectSelection() {
    this.view.dom.ownerDocument.addEventListener("selectionchange", this.onSelectionChange);
  }
  disconnectSelection() {
    this.view.dom.ownerDocument.removeEventListener("selectionchange", this.onSelectionChange);
  }
  suppressSelectionUpdates() {
    this.suppressingSelectionUpdates = !0, setTimeout(() => this.suppressingSelectionUpdates = !1, 50);
  }
  onSelectionChange() {
    if (ud(this.view)) {
      if (this.suppressingSelectionUpdates)
        return Zt(this.view);
      if (Ge && gn <= 11 && !this.view.state.selection.empty) {
        let e = this.view.domSelectionRange();
        if (e.focusNode && Hn(e.focusNode, e.focusOffset, e.anchorNode, e.anchorOffset))
          return this.flushSoon();
      }
      this.flush();
    }
  }
  setCurSelection() {
    this.currentSelection.set(this.view.domSelectionRange());
  }
  ignoreSelectionChange(e) {
    if (!e.focusNode)
      return !0;
    let t = /* @__PURE__ */ new Set(), r;
    for (let s = e.focusNode; s; s = yr(s))
      t.add(s);
    for (let s = e.anchorNode; s; s = yr(s))
      if (t.has(s)) {
        r = s;
        break;
      }
    let i = r && this.view.docView.nearestDesc(r);
    if (i && i.ignoreMutation({
      type: "selection",
      target: r.nodeType == 3 ? r.parentNode : r
    }))
      return this.setCurSelection(), !0;
  }
  pendingRecords() {
    if (this.observer)
      for (let e of this.observer.takeRecords())
        this.queue.push(e);
    return this.queue;
  }
  flush() {
    let { view: e } = this;
    if (!e.docView || this.flushingSoon > -1)
      return;
    let t = this.pendingRecords();
    t.length && (this.queue = []);
    let r = e.domSelectionRange(), i = !this.suppressingSelectionUpdates && !this.currentSelection.eq(r) && ud(e) && !this.ignoreSelectionChange(r), s = -1, o = -1, l = !1, a = [];
    if (e.editable)
      for (let u = 0; u < t.length; u++) {
        let d = this.registerMutation(t[u], a);
        d && (s = s < 0 ? d.from : Math.min(d.from, s), o = o < 0 ? d.to : Math.max(d.to, o), d.typeOver && (l = !0));
      }
    if (St && a.length) {
      let u = a.filter((d) => d.nodeName == "BR");
      if (u.length == 2) {
        let [d, f] = u;
        d.parentNode && d.parentNode.parentNode == f.parentNode ? f.remove() : d.remove();
      } else {
        let { focusNode: d } = this.currentSelection;
        for (let f of u) {
          let h = f.parentNode;
          h && h.nodeName == "LI" && (!d || Ek(e, d) != h) && f.remove();
        }
      }
    }
    let c = null;
    s < 0 && i && e.input.lastFocus > Date.now() - 200 && Math.max(e.input.lastTouch, e.input.lastClick.time) < Date.now() - 300 && co(r) && (c = ka(e)) && c.eq(V.near(e.state.doc.resolve(0), 1)) ? (e.input.lastFocus = 0, Zt(e), this.currentSelection.set(r), e.scrollToSelection()) : (s > -1 || i) && (s > -1 && (e.docView.markDirty(s, o), wk(e)), this.handleDOMChange(s, o, l, a), e.docView && e.docView.dirty ? e.updateState(e.state) : this.currentSelection.eq(r) || Zt(e), this.currentSelection.set(r));
  }
  registerMutation(e, t) {
    if (t.indexOf(e.target) > -1)
      return null;
    let r = this.view.docView.nearestDesc(e.target);
    if (e.type == "attributes" && (r == this.view.docView || e.attributeName == "contenteditable" || // Firefox sometimes fires spurious events for null/empty styles
    e.attributeName == "style" && !e.oldValue && !e.target.getAttribute("style")) || !r || r.ignoreMutation(e))
      return null;
    if (e.type == "childList") {
      for (let u = 0; u < e.addedNodes.length; u++) {
        let d = e.addedNodes[u];
        t.push(d), d.nodeType == 3 && (this.lastChangedTextNode = d);
      }
      if (r.contentDOM && r.contentDOM != r.dom && !r.contentDOM.contains(e.target))
        return { from: r.posBefore, to: r.posAfter };
      let i = e.previousSibling, s = e.nextSibling;
      if (Ge && gn <= 11 && e.addedNodes.length)
        for (let u = 0; u < e.addedNodes.length; u++) {
          let { previousSibling: d, nextSibling: f } = e.addedNodes[u];
          (!d || Array.prototype.indexOf.call(e.addedNodes, d) < 0) && (i = d), (!f || Array.prototype.indexOf.call(e.addedNodes, f) < 0) && (s = f);
        }
      let o = i && i.parentNode == e.target ? xe(i) + 1 : 0, l = r.localPosFromDOM(e.target, o, -1), a = s && s.parentNode == e.target ? xe(s) : e.target.childNodes.length, c = r.localPosFromDOM(e.target, a, 1);
      return { from: l, to: c };
    } else return e.type == "attributes" ? { from: r.posAtStart - r.border, to: r.posAtEnd + r.border } : (this.lastChangedTextNode = e.target, {
      from: r.posAtStart,
      to: r.posAtEnd,
      // An event was generated for a text change that didn't change
      // any text. Mark the dom change to fall back to assuming the
      // selection was typed over with an identical value if it can't
      // find another change.
      typeOver: e.target.nodeValue == e.oldValue
    });
  }
}
let bd = /* @__PURE__ */ new WeakMap(), kd = !1;
function wk(n) {
  if (!bd.has(n) && (bd.set(n, null), ["normal", "nowrap", "pre-line"].indexOf(getComputedStyle(n.dom).whiteSpace) !== -1)) {
    if (n.requiresGeckoHackNode = St, kd)
      return;
    console.warn("ProseMirror expects the CSS white-space property to be set, preferably to 'pre-wrap'. It is recommended to load style/prosemirror.css from the prosemirror-view package."), kd = !0;
  }
}
function wd(n, e) {
  let t = e.startContainer, r = e.startOffset, i = e.endContainer, s = e.endOffset, o = n.domAtPos(n.state.selection.anchor);
  return Hn(o.node, o.offset, i, s) && ([t, r, i, s] = [i, s, t, r]), { anchorNode: t, anchorOffset: r, focusNode: i, focusOffset: s };
}
function vk(n, e) {
  if (e.getComposedRanges) {
    let i = e.getComposedRanges(n.root)[0];
    if (i)
      return wd(n, i);
  }
  let t;
  function r(i) {
    i.preventDefault(), i.stopImmediatePropagation(), t = i.getTargetRanges()[0];
  }
  return n.dom.addEventListener("beforeinput", r, !0), document.execCommand("indent"), n.dom.removeEventListener("beforeinput", r, !0), t ? wd(n, t) : null;
}
function Ek(n, e) {
  for (let t = e.parentNode; t && t != n.dom; t = t.parentNode) {
    let r = n.docView.nearestDesc(t, !0);
    if (r && r.node.isBlock)
      return t;
  }
  return null;
}
function Dk(n, e, t) {
  let { node: r, fromOffset: i, toOffset: s, from: o, to: l } = n.docView.parseRange(e, t), a = n.domSelectionRange(), c, u = a.anchorNode;
  if (u && n.dom.contains(u.nodeType == 1 ? u : u.parentNode) && (c = [{ node: u, offset: a.anchorOffset }], co(a) || c.push({ node: a.focusNode, offset: a.focusOffset })), Re && n.input.lastKeyCode === 8)
    for (let _ = s; _ > i; _--) {
      let b = r.childNodes[_ - 1], y = b.pmViewDesc;
      if (b.nodeName == "BR" && !y) {
        s = _;
        break;
      }
      if (!y || y.size)
        break;
    }
  let d = n.state.doc, f = n.someProp("domParser") || Kr.fromSchema(n.state.schema), h = d.resolve(o), p = null, m = f.parse(r, {
    topNode: h.parent,
    topMatch: h.parent.contentMatchAt(h.index()),
    topOpen: !0,
    from: i,
    to: s,
    preserveWhitespace: h.parent.type.whitespace == "pre" ? "full" : !0,
    findPositions: c,
    ruleFromNode: Sk,
    context: h
  });
  if (c && c[0].pos != null) {
    let _ = c[0].pos, b = c[1] && c[1].pos;
    b == null && (b = _), p = { anchor: _ + o, head: b + o };
  }
  return { doc: m, sel: p, from: o, to: l };
}
function Sk(n) {
  let e = n.pmViewDesc;
  if (e)
    return e.parseRule();
  if (n.nodeName == "BR" && n.parentNode) {
    if (qe && /^(ul|ol)$/i.test(n.parentNode.nodeName)) {
      let t = document.createElement("div");
      return t.appendChild(document.createElement("li")), { skip: t };
    } else if (n.parentNode.lastChild == n || qe && /^(tr|table)$/i.test(n.parentNode.nodeName))
      return { ignore: !0 };
  } else if (n.nodeName == "IMG" && n.getAttribute("mark-placeholder"))
    return { ignore: !0 };
  return null;
}
const Ck = /^(a|abbr|acronym|b|bd[io]|big|br|button|cite|code|data(list)?|del|dfn|em|i|img|ins|kbd|label|map|mark|meter|output|q|ruby|s|samp|small|span|strong|su[bp]|time|u|tt|var)$/i;
function Ak(n, e, t, r, i) {
  let s = n.input.compositionPendingChanges || (n.composing ? n.input.compositionID : 0);
  if (n.input.compositionPendingChanges = 0, e < 0) {
    let S = n.input.lastSelectionTime > Date.now() - 50 ? n.input.lastSelectionOrigin : null, C = ka(n, S);
    if (C && !n.state.selection.eq(C)) {
      if (Re && Yt && n.input.lastKeyCode === 13 && Date.now() - 100 < n.input.lastKeyCodeTime && n.someProp("handleKeyDown", (N) => N(n, An(13, "Enter"))))
        return;
      let F = n.state.tr.setSelection(C);
      S == "pointer" ? F.setMeta("pointer", !0) : S == "key" && F.scrollIntoView(), s && F.setMeta("composition", s), n.dispatch(F);
    }
    return;
  }
  let o = n.state.doc.resolve(e), l = o.sharedDepth(t);
  e = o.before(l + 1), t = n.state.doc.resolve(t).after(l + 1);
  let a = n.state.selection, c = Dk(n, e, t), u = n.state.doc, d = u.slice(c.from, c.to), f, h;
  n.input.lastKeyCode === 8 && Date.now() - 100 < n.input.lastKeyCodeTime ? (f = n.state.selection.to, h = "end") : (f = n.state.selection.from, h = "start"), n.input.lastKeyCode = null;
  let p = Mk(d.content, c.doc.content, c.from, f, h);
  if (p && n.input.domChangeCount++, (br && n.input.lastIOSEnter > Date.now() - 225 || Yt) && i.some((S) => S.nodeType == 1 && !Ck.test(S.nodeName)) && (!p || p.endA >= p.endB) && n.someProp("handleKeyDown", (S) => S(n, An(13, "Enter")))) {
    n.input.lastIOSEnter = 0;
    return;
  }
  if (!p)
    if (r && a instanceof z && !a.empty && a.$head.sameParent(a.$anchor) && !n.composing && !(c.sel && c.sel.anchor != c.sel.head))
      p = { start: a.from, endA: a.to, endB: a.to };
    else {
      if (c.sel) {
        let S = vd(n, n.state.doc, c.sel);
        if (S && !S.eq(n.state.selection)) {
          let C = n.state.tr.setSelection(S);
          s && C.setMeta("composition", s), n.dispatch(C);
        }
      }
      return;
    }
  n.state.selection.from < n.state.selection.to && p.start == p.endB && n.state.selection instanceof z && (p.start > n.state.selection.from && p.start <= n.state.selection.from + 2 && n.state.selection.from >= c.from ? p.start = n.state.selection.from : p.endA < n.state.selection.to && p.endA >= n.state.selection.to - 2 && n.state.selection.to <= c.to && (p.endB += n.state.selection.to - p.endA, p.endA = n.state.selection.to)), Ge && gn <= 11 && p.endB == p.start + 1 && p.endA == p.start && p.start > c.from && c.doc.textBetween(p.start - c.from - 1, p.start - c.from + 1) == "  " && (p.start--, p.endA--, p.endB--);
  let m = c.doc.resolveNoCache(p.start - c.from), _ = c.doc.resolveNoCache(p.endB - c.from), b = u.resolve(p.start), y = m.sameParent(_) && m.parent.inlineContent && b.end() >= p.endA, g;
  if ((br && n.input.lastIOSEnter > Date.now() - 225 && (!y || i.some((S) => S.nodeName == "DIV" || S.nodeName == "P")) || !y && m.pos < c.doc.content.size && (!m.sameParent(_) || !m.parent.inlineContent) && !/\S/.test(c.doc.textBetween(m.pos, _.pos, "", "")) && (g = V.findFrom(c.doc.resolve(m.pos + 1), 1, !0)) && g.head > m.pos) && n.someProp("handleKeyDown", (S) => S(n, An(13, "Enter")))) {
    n.input.lastIOSEnter = 0;
    return;
  }
  if (n.state.selection.anchor > p.start && Tk(u, p.start, p.endA, m, _) && n.someProp("handleKeyDown", (S) => S(n, An(8, "Backspace")))) {
    Yt && Re && n.domObserver.suppressSelectionUpdates();
    return;
  }
  Re && p.endB == p.start && (n.input.lastChromeDelete = Date.now()), Yt && !y && m.start() != _.start() && _.parentOffset == 0 && m.depth == _.depth && c.sel && c.sel.anchor == c.sel.head && c.sel.head == p.endA && (p.endB -= 2, _ = c.doc.resolveNoCache(p.endB - c.from), setTimeout(() => {
    n.someProp("handleKeyDown", function(S) {
      return S(n, An(13, "Enter"));
    });
  }, 20));
  let w = p.start, E = p.endA, v = (S) => {
    let C = S || n.state.tr.replace(w, E, c.doc.slice(p.start - c.from, p.endB - c.from));
    if (c.sel) {
      let F = vd(n, C.doc, c.sel);
      F && !(Re && n.composing && F.empty && (p.start != p.endB || n.input.lastChromeDelete < Date.now() - 100) && (F.head == w || F.head == C.mapping.map(E) - 1) || Ge && F.empty && F.head == w) && C.setSelection(F);
    }
    return s && C.setMeta("composition", s), C.scrollIntoView();
  }, D;
  if (y) {
    if (m.pos == _.pos) {
      Ge && gn <= 11 && m.parentOffset == 0 && (n.domObserver.suppressSelectionUpdates(), setTimeout(() => Zt(n), 20));
      let S = v(n.state.tr.delete(w, E)), C = u.resolve(p.start).marksAcross(u.resolve(p.endA));
      C && S.ensureMarks(C), n.dispatch(S);
    } else if (
      // Adding or removing a mark
      p.endA == p.endB && (D = xk(m.parent.content.cut(m.parentOffset, _.parentOffset), b.parent.content.cut(b.parentOffset, p.endA - b.start())))
    ) {
      let S = v(n.state.tr);
      D.type == "add" ? S.addMark(w, E, D.mark) : S.removeMark(w, E, D.mark), n.dispatch(S);
    } else if (m.parent.child(m.index()).isText && m.index() == _.index() - (_.textOffset ? 0 : 1)) {
      let S = m.parent.textBetween(m.parentOffset, _.parentOffset), C = () => v(n.state.tr.insertText(S, w, E));
      n.someProp("handleTextInput", (F) => F(n, w, E, S, C)) || n.dispatch(C());
    }
  } else
    n.dispatch(v());
}
function vd(n, e, t) {
  return Math.max(t.anchor, t.head) > e.content.size ? null : wa(n, e.resolve(t.anchor), e.resolve(t.head));
}
function xk(n, e) {
  let t = n.firstChild.marks, r = e.firstChild.marks, i = t, s = r, o, l, a;
  for (let u = 0; u < r.length; u++)
    i = r[u].removeFromSet(i);
  for (let u = 0; u < t.length; u++)
    s = t[u].removeFromSet(s);
  if (i.length == 1 && s.length == 0)
    l = i[0], o = "add", a = (u) => u.mark(l.addToSet(u.marks));
  else if (i.length == 0 && s.length == 1)
    l = s[0], o = "remove", a = (u) => u.mark(l.removeFromSet(u.marks));
  else
    return null;
  let c = [];
  for (let u = 0; u < e.childCount; u++)
    c.push(a(e.child(u)));
  if (A.from(c).eq(n))
    return { mark: l, type: o };
}
function Tk(n, e, t, r, i) {
  if (
    // The content must have shrunk
    t - e <= i.pos - r.pos || // newEnd must point directly at or after the end of the block that newStart points into
    il(r, !0, !1) < i.pos
  )
    return !1;
  let s = n.resolve(e);
  if (!r.parent.isTextblock) {
    let l = s.nodeAfter;
    return l != null && t == e + l.nodeSize;
  }
  if (s.parentOffset < s.parent.content.size || !s.parent.isTextblock)
    return !1;
  let o = n.resolve(il(s, !0, !0));
  return !o.parent.isTextblock || o.pos > t || il(o, !0, !1) < t ? !1 : r.parent.content.cut(r.parentOffset).eq(o.parent.content);
}
function il(n, e, t) {
  let r = n.depth, i = e ? n.end() : n.pos;
  for (; r > 0 && (e || n.indexAfter(r) == n.node(r).childCount); )
    r--, i++, e = !1;
  if (t) {
    let s = n.node(r).maybeChild(n.indexAfter(r));
    for (; s && !s.isLeaf; )
      s = s.firstChild, i++;
  }
  return i;
}
function Mk(n, e, t, r, i) {
  let s = n.findDiffStart(e, t);
  if (s == null)
    return null;
  let { a: o, b: l } = n.findDiffEnd(e, t + n.size, t + e.size);
  if (i == "end") {
    let a = Math.max(0, s - Math.min(o, l));
    r -= o + a - s;
  }
  if (o < s && n.size < e.size) {
    let a = r <= s && r >= o ? s - r : 0;
    s -= a, s && s < e.size && Ed(e.textBetween(s - 1, s + 1)) && (s += a ? 1 : -1), l = s + (l - o), o = s;
  } else if (l < s) {
    let a = r <= s && r >= l ? s - r : 0;
    s -= a, s && s < n.size && Ed(n.textBetween(s - 1, s + 1)) && (s += a ? 1 : -1), o = s + (o - l), l = s;
  }
  return { start: s, endA: o, endB: l };
}
function Ed(n) {
  if (n.length != 2)
    return !1;
  let e = n.charCodeAt(0), t = n.charCodeAt(1);
  return e >= 56320 && e <= 57343 && t >= 55296 && t <= 56319;
}
class gp {
  /**
  Create a view. `place` may be a DOM node that the editor should
  be appended to, a function that will place it into the document,
  or an object whose `mount` property holds the node to use as the
  document container. If it is `null`, the editor will not be
  added to the document.
  */
  constructor(e, t) {
    this._root = null, this.focused = !1, this.trackWrites = null, this.mounted = !1, this.markCursor = null, this.cursorWrapper = null, this.lastSelectedViewDesc = void 0, this.input = new Jb(), this.prevDirectPlugins = [], this.pluginViews = [], this.requiresGeckoHackNode = !1, this.dragging = null, this._props = t, this.state = t.state, this.directPlugins = t.plugins || [], this.directPlugins.forEach(xd), this.dispatch = this.dispatch.bind(this), this.dom = e && e.mount || document.createElement("div"), e && (e.appendChild ? e.appendChild(this.dom) : typeof e == "function" ? e(this.dom) : e.mount && (this.mounted = !0)), this.editable = Cd(this), Sd(this), this.nodeViews = Ad(this), this.docView = id(this.state.doc, Dd(this), rl(this), this.dom, this), this.domObserver = new kk(this, (r, i, s, o) => Ak(this, r, i, s, o)), this.domObserver.start(), Yb(this), this.updatePluginViews();
  }
  /**
  Holds `true` when a
  [composition](https://w3c.github.io/uievents/#events-compositionevents)
  is active.
  */
  get composing() {
    return this.input.composing;
  }
  /**
  The view's current [props](https://prosemirror.net/docs/ref/#view.EditorProps).
  */
  get props() {
    if (this._props.state != this.state) {
      let e = this._props;
      this._props = {};
      for (let t in e)
        this._props[t] = e[t];
      this._props.state = this.state;
    }
    return this._props;
  }
  /**
  Update the view's props. Will immediately cause an update to
  the DOM.
  */
  update(e) {
    e.handleDOMEvents != this._props.handleDOMEvents && Wl(this);
    let t = this._props;
    this._props = e, e.plugins && (e.plugins.forEach(xd), this.directPlugins = e.plugins), this.updateStateInner(e.state, t);
  }
  /**
  Update the view by updating existing props object with the object
  given as argument. Equivalent to `view.update(Object.assign({},
  view.props, props))`.
  */
  setProps(e) {
    let t = {};
    for (let r in this._props)
      t[r] = this._props[r];
    t.state = this.state;
    for (let r in e)
      t[r] = e[r];
    this.update(t);
  }
  /**
  Update the editor's `state` prop, without touching any of the
  other props.
  */
  updateState(e) {
    this.updateStateInner(e, this._props);
  }
  updateStateInner(e, t) {
    var r;
    let i = this.state, s = !1, o = !1;
    e.storedMarks && this.composing && (cp(this), o = !0), this.state = e;
    let l = i.plugins != e.plugins || this._props.plugins != t.plugins;
    if (l || this._props.plugins != t.plugins || this._props.nodeViews != t.nodeViews) {
      let h = Ad(this);
      $k(h, this.nodeViews) && (this.nodeViews = h, s = !0);
    }
    (l || t.handleDOMEvents != this._props.handleDOMEvents) && Wl(this), this.editable = Cd(this), Sd(this);
    let a = rl(this), c = Dd(this), u = i.plugins != e.plugins && !i.doc.eq(e.doc) ? "reset" : e.scrollToSelection > i.scrollToSelection ? "to selection" : "preserve", d = s || !this.docView.matchesNode(e.doc, c, a);
    (d || !e.selection.eq(i.selection)) && (o = !0);
    let f = u == "preserve" && o && this.dom.style.overflowAnchor == null && ub(this);
    if (o) {
      this.domObserver.stop();
      let h = d && (Ge || Re) && !this.composing && !i.selection.empty && !e.selection.empty && Fk(i.selection, e.selection);
      if (d) {
        let p = Re ? this.trackWrites = this.domSelectionRange().focusNode : null;
        this.composing && (this.input.compositionNode = ck(this)), (s || !this.docView.update(e.doc, c, a, this)) && (this.docView.updateOuterDeco(c), this.docView.destroy(), this.docView = id(e.doc, c, a, this.dom, this)), p && !this.trackWrites && (h = !0);
      }
      h || !(this.input.mouseDown && this.domObserver.currentSelection.eq(this.domSelectionRange()) && Nb(this)) ? Zt(this, h) : (Xh(this, e.selection), this.domObserver.setCurSelection()), this.domObserver.start();
    }
    this.updatePluginViews(i), !((r = this.dragging) === null || r === void 0) && r.node && !i.doc.eq(e.doc) && this.updateDraggedNode(this.dragging, i), u == "reset" ? this.dom.scrollTop = 0 : u == "to selection" ? this.scrollToSelection() : f && db(f);
  }
  /**
  @internal
  */
  scrollToSelection() {
    let e = this.domSelectionRange().focusNode;
    if (!(!e || !this.dom.contains(e.nodeType == 1 ? e : e.parentNode))) {
      if (!this.someProp("handleScrollToSelection", (t) => t(this))) if (this.state.selection instanceof B) {
        let t = this.docView.domAfterPos(this.state.selection.from);
        t.nodeType == 1 && Zu(this, t.getBoundingClientRect(), e);
      } else
        Zu(this, this.coordsAtPos(this.state.selection.head, 1), e);
    }
  }
  destroyPluginViews() {
    let e;
    for (; e = this.pluginViews.pop(); )
      e.destroy && e.destroy();
  }
  updatePluginViews(e) {
    if (!e || e.plugins != this.state.plugins || this.directPlugins != this.prevDirectPlugins) {
      this.prevDirectPlugins = this.directPlugins, this.destroyPluginViews();
      for (let t = 0; t < this.directPlugins.length; t++) {
        let r = this.directPlugins[t];
        r.spec.view && this.pluginViews.push(r.spec.view(this));
      }
      for (let t = 0; t < this.state.plugins.length; t++) {
        let r = this.state.plugins[t];
        r.spec.view && this.pluginViews.push(r.spec.view(this));
      }
    } else
      for (let t = 0; t < this.pluginViews.length; t++) {
        let r = this.pluginViews[t];
        r.update && r.update(this, e);
      }
  }
  updateDraggedNode(e, t) {
    let r = e.node, i = -1;
    if (this.state.doc.nodeAt(r.from) == r.node)
      i = r.from;
    else {
      let s = r.from + (this.state.doc.content.size - t.doc.content.size);
      (s > 0 && this.state.doc.nodeAt(s)) == r.node && (i = s);
    }
    this.dragging = new dp(e.slice, e.move, i < 0 ? void 0 : B.create(this.state.doc, i));
  }
  someProp(e, t) {
    let r = this._props && this._props[e], i;
    if (r != null && (i = t ? t(r) : r))
      return i;
    for (let o = 0; o < this.directPlugins.length; o++) {
      let l = this.directPlugins[o].props[e];
      if (l != null && (i = t ? t(l) : l))
        return i;
    }
    let s = this.state.plugins;
    if (s)
      for (let o = 0; o < s.length; o++) {
        let l = s[o].props[e];
        if (l != null && (i = t ? t(l) : l))
          return i;
      }
  }
  /**
  Query whether the view has focus.
  */
  hasFocus() {
    if (Ge) {
      let e = this.root.activeElement;
      if (e == this.dom)
        return !0;
      if (!e || !this.dom.contains(e))
        return !1;
      for (; e && this.dom != e && this.dom.contains(e); ) {
        if (e.contentEditable == "false")
          return !1;
        e = e.parentElement;
      }
      return !0;
    }
    return this.root.activeElement == this.dom;
  }
  /**
  Focus the editor.
  */
  focus() {
    this.domObserver.stop(), this.editable && fb(this.dom), Zt(this), this.domObserver.start();
  }
  /**
  Get the document root in which the editor exists. This will
  usually be the top-level `document`, but might be a [shadow
  DOM](https://developer.mozilla.org/en-US/docs/Web/Web_Components/Shadow_DOM)
  root if the editor is inside one.
  */
  get root() {
    let e = this._root;
    if (e == null) {
      for (let t = this.dom.parentNode; t; t = t.parentNode)
        if (t.nodeType == 9 || t.nodeType == 11 && t.host)
          return t.getSelection || (Object.getPrototypeOf(t).getSelection = () => t.ownerDocument.getSelection()), this._root = t;
    }
    return e || document;
  }
  /**
  When an existing editor view is moved to a new document or
  shadow tree, call this to make it recompute its root.
  */
  updateRoot() {
    this._root = null;
  }
  /**
  Given a pair of viewport coordinates, return the document
  position that corresponds to them. May return null if the given
  coordinates aren't inside of the editor. When an object is
  returned, its `pos` property is the position nearest to the
  coordinates, and its `inside` property holds the position of the
  inner node that the position falls inside of, or -1 if it is at
  the top level, not in any node.
  */
  posAtCoords(e) {
    return _b(this, e);
  }
  /**
  Returns the viewport rectangle at a given document position.
  `left` and `right` will be the same number, as this returns a
  flat cursor-ish rectangle. If the position is between two things
  that aren't directly adjacent, `side` determines which element
  is used. When < 0, the element before the position is used,
  otherwise the element after.
  */
  coordsAtPos(e, t = 1) {
    return Vh(this, e, t);
  }
  /**
  Find the DOM position that corresponds to the given document
  position. When `side` is negative, find the position as close as
  possible to the content before the position. When positive,
  prefer positions close to the content after the position. When
  zero, prefer as shallow a position as possible.
  
  Note that you should **not** mutate the editor's internal DOM,
  only inspect it (and even that is usually not necessary).
  */
  domAtPos(e, t = 0) {
    return this.docView.domFromPos(e, t);
  }
  /**
  Find the DOM node that represents the document node after the
  given position. May return `null` when the position doesn't point
  in front of a node or if the node is inside an opaque node view.
  
  This is intended to be able to call things like
  `getBoundingClientRect` on that DOM node. Do **not** mutate the
  editor DOM directly, or add styling this way, since that will be
  immediately overriden by the editor as it redraws the node.
  */
  nodeDOM(e) {
    let t = this.docView.descAt(e);
    return t ? t.nodeDOM : null;
  }
  /**
  Find the document position that corresponds to a given DOM
  position. (Whenever possible, it is preferable to inspect the
  document structure directly, rather than poking around in the
  DOM, but sometimes—for example when interpreting an event
  target—you don't have a choice.)
  
  The `bias` parameter can be used to influence which side of a DOM
  node to use when the position is inside a leaf node.
  */
  posAtDOM(e, t, r = -1) {
    let i = this.docView.posFromDOM(e, t, r);
    if (i == null)
      throw new RangeError("DOM position not inside the editor");
    return i;
  }
  /**
  Find out whether the selection is at the end of a textblock when
  moving in a given direction. When, for example, given `"left"`,
  it will return true if moving left from the current cursor
  position would leave that position's parent textblock. Will apply
  to the view's current state by default, but it is possible to
  pass a different state.
  */
  endOfTextblock(e, t) {
    return vb(this, t || this.state, e);
  }
  /**
  Run the editor's paste logic with the given HTML string. The
  `event`, if given, will be passed to the
  [`handlePaste`](https://prosemirror.net/docs/ref/#view.EditorProps.handlePaste) hook.
  */
  pasteHTML(e, t) {
    return ui(this, "", e, !1, t || new ClipboardEvent("paste"));
  }
  /**
  Run the editor's paste logic with the given plain-text input.
  */
  pasteText(e, t) {
    return ui(this, e, null, !0, t || new ClipboardEvent("paste"));
  }
  /**
  Serialize the given slice as it would be if it was copied from
  this editor. Returns a DOM element that contains a
  representation of the slice as its children, a textual
  representation, and the transformed slice (which can be
  different from the given input due to hooks like
  [`transformCopied`](https://prosemirror.net/docs/ref/#view.EditorProps.transformCopied)).
  */
  serializeForClipboard(e) {
    return va(this, e);
  }
  /**
  Removes the editor from the DOM and destroys all [node
  views](https://prosemirror.net/docs/ref/#view.NodeView).
  */
  destroy() {
    this.docView && (Xb(this), this.destroyPluginViews(), this.mounted ? (this.docView.update(this.state.doc, [], rl(this), this), this.dom.textContent = "") : this.dom.parentNode && this.dom.parentNode.removeChild(this.dom), this.docView.destroy(), this.docView = null, Q1());
  }
  /**
  This is true when the view has been
  [destroyed](https://prosemirror.net/docs/ref/#view.EditorView.destroy) (and thus should not be
  used anymore).
  */
  get isDestroyed() {
    return this.docView == null;
  }
  /**
  Used for testing.
  */
  dispatchEvent(e) {
    return Qb(this, e);
  }
  /**
  @internal
  */
  domSelectionRange() {
    let e = this.domSelection();
    return e ? qe && this.root.nodeType === 11 && ib(this.dom.ownerDocument) == this.dom && vk(this, e) || e : { focusNode: null, focusOffset: 0, anchorNode: null, anchorOffset: 0 };
  }
  /**
  @internal
  */
  domSelection() {
    return this.root.getSelection();
  }
}
gp.prototype.dispatch = function(n) {
  let e = this._props.dispatchTransaction;
  e ? e.call(this, n) : this.updateState(this.state.apply(n));
};
function Dd(n) {
  let e = /* @__PURE__ */ Object.create(null);
  return e.class = "ProseMirror", e.contenteditable = String(n.editable), n.someProp("attributes", (t) => {
    if (typeof t == "function" && (t = t(n.state)), t)
      for (let r in t)
        r == "class" ? e.class += " " + t[r] : r == "style" ? e.style = (e.style ? e.style + ";" : "") + t[r] : !e[r] && r != "contenteditable" && r != "nodeName" && (e[r] = String(t[r]));
  }), e.translate || (e.translate = "no"), [Be.node(0, n.state.doc.content.size, e)];
}
function Sd(n) {
  if (n.markCursor) {
    let e = document.createElement("img");
    e.className = "ProseMirror-separator", e.setAttribute("mark-placeholder", "true"), e.setAttribute("alt", ""), n.cursorWrapper = { dom: e, deco: Be.widget(n.state.selection.from, e, { raw: !0, marks: n.markCursor }) };
  } else
    n.cursorWrapper = null;
}
function Cd(n) {
  return !n.someProp("editable", (e) => e(n.state) === !1);
}
function Fk(n, e) {
  let t = Math.min(n.$anchor.sharedDepth(n.head), e.$anchor.sharedDepth(e.head));
  return n.$anchor.start(t) != e.$anchor.start(t);
}
function Ad(n) {
  let e = /* @__PURE__ */ Object.create(null);
  function t(r) {
    for (let i in r)
      Object.prototype.hasOwnProperty.call(e, i) || (e[i] = r[i]);
  }
  return n.someProp("nodeViews", t), n.someProp("markViews", t), e;
}
function $k(n, e) {
  let t = 0, r = 0;
  for (let i in n) {
    if (n[i] != e[i])
      return !0;
    t++;
  }
  for (let i in e)
    r++;
  return t != r;
}
function xd(n) {
  if (n.spec.state || n.spec.filterTransaction || n.spec.appendTransaction)
    throw new RangeError("Plugins passed directly to the view must not have a state component");
}
var bn = {
  8: "Backspace",
  9: "Tab",
  10: "Enter",
  12: "NumLock",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  44: "PrintScreen",
  45: "Insert",
  46: "Delete",
  59: ";",
  61: "=",
  91: "Meta",
  92: "Meta",
  106: "*",
  107: "+",
  108: ",",
  109: "-",
  110: ".",
  111: "/",
  144: "NumLock",
  145: "ScrollLock",
  160: "Shift",
  161: "Shift",
  162: "Control",
  163: "Control",
  164: "Alt",
  165: "Alt",
  173: "-",
  186: ";",
  187: "=",
  188: ",",
  189: "-",
  190: ".",
  191: "/",
  192: "`",
  219: "[",
  220: "\\",
  221: "]",
  222: "'"
}, Cs = {
  48: ")",
  49: "!",
  50: "@",
  51: "#",
  52: "$",
  53: "%",
  54: "^",
  55: "&",
  56: "*",
  57: "(",
  59: ":",
  61: "+",
  173: "_",
  186: ":",
  187: "+",
  188: "<",
  189: "_",
  190: ">",
  191: "?",
  192: "~",
  219: "{",
  220: "|",
  221: "}",
  222: '"'
}, Ok = typeof navigator < "u" && /Mac/.test(navigator.platform), Nk = typeof navigator < "u" && /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent);
for (var Te = 0; Te < 10; Te++) bn[48 + Te] = bn[96 + Te] = String(Te);
for (var Te = 1; Te <= 24; Te++) bn[Te + 111] = "F" + Te;
for (var Te = 65; Te <= 90; Te++)
  bn[Te] = String.fromCharCode(Te + 32), Cs[Te] = String.fromCharCode(Te);
for (var sl in bn) Cs.hasOwnProperty(sl) || (Cs[sl] = bn[sl]);
function Ik(n) {
  var e = Ok && n.metaKey && n.shiftKey && !n.ctrlKey && !n.altKey || Nk && n.shiftKey && n.key && n.key.length == 1 || n.key == "Unidentified", t = !e && n.key || (n.shiftKey ? Cs : bn)[n.keyCode] || n.key || "Unidentified";
  return t == "Esc" && (t = "Escape"), t == "Del" && (t = "Delete"), t == "Left" && (t = "ArrowLeft"), t == "Up" && (t = "ArrowUp"), t == "Right" && (t = "ArrowRight"), t == "Down" && (t = "ArrowDown"), t;
}
const Rk = typeof navigator < "u" && /Mac|iP(hone|[oa]d)/.test(navigator.platform), Lk = typeof navigator < "u" && /Win/.test(navigator.platform);
function Pk(n) {
  let e = n.split(/-(?!$)/), t = e[e.length - 1];
  t == "Space" && (t = " ");
  let r, i, s, o;
  for (let l = 0; l < e.length - 1; l++) {
    let a = e[l];
    if (/^(cmd|meta|m)$/i.test(a))
      o = !0;
    else if (/^a(lt)?$/i.test(a))
      r = !0;
    else if (/^(c|ctrl|control)$/i.test(a))
      i = !0;
    else if (/^s(hift)?$/i.test(a))
      s = !0;
    else if (/^mod$/i.test(a))
      Rk ? o = !0 : i = !0;
    else
      throw new Error("Unrecognized modifier name: " + a);
  }
  return r && (t = "Alt-" + t), i && (t = "Ctrl-" + t), o && (t = "Meta-" + t), s && (t = "Shift-" + t), t;
}
function Bk(n) {
  let e = /* @__PURE__ */ Object.create(null);
  for (let t in n)
    e[Pk(t)] = n[t];
  return e;
}
function ol(n, e, t = !0) {
  return e.altKey && (n = "Alt-" + n), e.ctrlKey && (n = "Ctrl-" + n), e.metaKey && (n = "Meta-" + n), t && e.shiftKey && (n = "Shift-" + n), n;
}
function zk(n) {
  return new ae({ props: { handleKeyDown: _p(n) } });
}
function _p(n) {
  let e = Bk(n);
  return function(t, r) {
    let i = Ik(r), s, o = e[ol(i, r)];
    if (o && o(t.state, t.dispatch, t))
      return !0;
    if (i.length == 1 && i != " ") {
      if (r.shiftKey) {
        let l = e[ol(i, r, !1)];
        if (l && l(t.state, t.dispatch, t))
          return !0;
      }
      if ((r.altKey || r.metaKey || r.ctrlKey) && // Ctrl-Alt may be used for AltGr on Windows
      !(Lk && r.ctrlKey && r.altKey) && (s = bn[r.keyCode]) && s != i) {
        let l = e[ol(s, r)];
        if (l && l(t.state, t.dispatch, t))
          return !0;
      }
    }
    return !1;
  };
}
const xa = (n, e) => n.selection.empty ? !1 : (e && e(n.tr.deleteSelection().scrollIntoView()), !0);
function yp(n, e) {
  let { $cursor: t } = n.selection;
  return !t || (e ? !e.endOfTextblock("backward", n) : t.parentOffset > 0) ? null : t;
}
const bp = (n, e, t) => {
  let r = yp(n, t);
  if (!r)
    return !1;
  let i = Ta(r);
  if (!i) {
    let o = r.blockRange(), l = o && Er(o);
    return l == null ? !1 : (e && e(n.tr.lift(o, l).scrollIntoView()), !0);
  }
  let s = i.nodeBefore;
  if (xp(n, i, e, -1))
    return !0;
  if (r.parent.content.size == 0 && (kr(s, "end") || B.isSelectable(s)))
    for (let o = r.depth; ; o--) {
      let l = lo(n.doc, r.before(o), r.after(o), O.empty);
      if (l && l.slice.size < l.to - l.from) {
        if (e) {
          let a = n.tr.step(l);
          a.setSelection(kr(s, "end") ? V.findFrom(a.doc.resolve(a.mapping.map(i.pos, -1)), -1) : B.create(a.doc, i.pos - s.nodeSize)), e(a.scrollIntoView());
        }
        return !0;
      }
      if (o == 1 || r.node(o - 1).childCount > 1)
        break;
    }
  return s.isAtom && i.depth == r.depth - 1 ? (e && e(n.tr.delete(i.pos - s.nodeSize, i.pos).scrollIntoView()), !0) : !1;
}, Hk = (n, e, t) => {
  let r = yp(n, t);
  if (!r)
    return !1;
  let i = Ta(r);
  return i ? kp(n, i, e) : !1;
}, qk = (n, e, t) => {
  let r = vp(n, t);
  if (!r)
    return !1;
  let i = Ma(r);
  return i ? kp(n, i, e) : !1;
};
function kp(n, e, t) {
  let r = e.nodeBefore, i = r, s = e.pos - 1;
  for (; !i.isTextblock; s--) {
    if (i.type.spec.isolating)
      return !1;
    let u = i.lastChild;
    if (!u)
      return !1;
    i = u;
  }
  let o = e.nodeAfter, l = o, a = e.pos + 1;
  for (; !l.isTextblock; a++) {
    if (l.type.spec.isolating)
      return !1;
    let u = l.firstChild;
    if (!u)
      return !1;
    l = u;
  }
  let c = lo(n.doc, s, a, O.empty);
  if (!c || c.from != s || c instanceof Ee && c.slice.size >= a - s)
    return !1;
  if (t) {
    let u = n.tr.step(c);
    u.setSelection(z.create(u.doc, s)), t(u.scrollIntoView());
  }
  return !0;
}
function kr(n, e, t = !1) {
  for (let r = n; r; r = e == "start" ? r.firstChild : r.lastChild) {
    if (r.isTextblock)
      return !0;
    if (t && r.childCount != 1)
      return !1;
  }
  return !1;
}
const wp = (n, e, t) => {
  let { $head: r, empty: i } = n.selection, s = r;
  if (!i)
    return !1;
  if (r.parent.isTextblock) {
    if (t ? !t.endOfTextblock("backward", n) : r.parentOffset > 0)
      return !1;
    s = Ta(r);
  }
  let o = s && s.nodeBefore;
  return !o || !B.isSelectable(o) ? !1 : (e && e(n.tr.setSelection(B.create(n.doc, s.pos - o.nodeSize)).scrollIntoView()), !0);
};
function Ta(n) {
  if (!n.parent.type.spec.isolating)
    for (let e = n.depth - 1; e >= 0; e--) {
      if (n.index(e) > 0)
        return n.doc.resolve(n.before(e + 1));
      if (n.node(e).type.spec.isolating)
        break;
    }
  return null;
}
function vp(n, e) {
  let { $cursor: t } = n.selection;
  return !t || (e ? !e.endOfTextblock("forward", n) : t.parentOffset < t.parent.content.size) ? null : t;
}
const Ep = (n, e, t) => {
  let r = vp(n, t);
  if (!r)
    return !1;
  let i = Ma(r);
  if (!i)
    return !1;
  let s = i.nodeAfter;
  if (xp(n, i, e, 1))
    return !0;
  if (r.parent.content.size == 0 && (kr(s, "start") || B.isSelectable(s))) {
    let o = lo(n.doc, r.before(), r.after(), O.empty);
    if (o && o.slice.size < o.to - o.from) {
      if (e) {
        let l = n.tr.step(o);
        l.setSelection(kr(s, "start") ? V.findFrom(l.doc.resolve(l.mapping.map(i.pos)), 1) : B.create(l.doc, l.mapping.map(i.pos))), e(l.scrollIntoView());
      }
      return !0;
    }
  }
  return s.isAtom && i.depth == r.depth - 1 ? (e && e(n.tr.delete(i.pos, i.pos + s.nodeSize).scrollIntoView()), !0) : !1;
}, Dp = (n, e, t) => {
  let { $head: r, empty: i } = n.selection, s = r;
  if (!i)
    return !1;
  if (r.parent.isTextblock) {
    if (t ? !t.endOfTextblock("forward", n) : r.parentOffset < r.parent.content.size)
      return !1;
    s = Ma(r);
  }
  let o = s && s.nodeAfter;
  return !o || !B.isSelectable(o) ? !1 : (e && e(n.tr.setSelection(B.create(n.doc, s.pos)).scrollIntoView()), !0);
};
function Ma(n) {
  if (!n.parent.type.spec.isolating)
    for (let e = n.depth - 1; e >= 0; e--) {
      let t = n.node(e);
      if (n.index(e) + 1 < t.childCount)
        return n.doc.resolve(n.after(e + 1));
      if (t.type.spec.isolating)
        break;
    }
  return null;
}
const Vk = (n, e) => {
  let t = n.selection, r = t instanceof B, i;
  if (r) {
    if (t.node.isTextblock || !wn(n.doc, t.from))
      return !1;
    i = t.from;
  } else if (i = oo(n.doc, t.from, -1), i == null)
    return !1;
  if (e) {
    let s = n.tr.join(i);
    r && s.setSelection(B.create(s.doc, i - n.doc.resolve(i).nodeBefore.nodeSize)), e(s.scrollIntoView());
  }
  return !0;
}, Uk = (n, e) => {
  let t = n.selection, r;
  if (t instanceof B) {
    if (t.node.isTextblock || !wn(n.doc, t.to))
      return !1;
    r = t.to;
  } else if (r = oo(n.doc, t.to, 1), r == null)
    return !1;
  return e && e(n.tr.join(r).scrollIntoView()), !0;
}, jk = (n, e) => {
  let { $from: t, $to: r } = n.selection, i = t.blockRange(r), s = i && Er(i);
  return s == null ? !1 : (e && e(n.tr.lift(i, s).scrollIntoView()), !0);
}, Sp = (n, e) => {
  let { $head: t, $anchor: r } = n.selection;
  return !t.parent.type.spec.code || !t.sameParent(r) ? !1 : (e && e(n.tr.insertText(`
`).scrollIntoView()), !0);
};
function Fa(n) {
  for (let e = 0; e < n.edgeCount; e++) {
    let { type: t } = n.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
const Wk = (n, e) => {
  let { $head: t, $anchor: r } = n.selection;
  if (!t.parent.type.spec.code || !t.sameParent(r))
    return !1;
  let i = t.node(-1), s = t.indexAfter(-1), o = Fa(i.contentMatchAt(s));
  if (!o || !i.canReplaceWith(s, s, o))
    return !1;
  if (e) {
    let l = t.after(), a = n.tr.replaceWith(l, l, o.createAndFill());
    a.setSelection(V.near(a.doc.resolve(l), 1)), e(a.scrollIntoView());
  }
  return !0;
}, Cp = (n, e) => {
  let t = n.selection, { $from: r, $to: i } = t;
  if (t instanceof Qe || r.parent.inlineContent || i.parent.inlineContent)
    return !1;
  let s = Fa(i.parent.contentMatchAt(i.indexAfter()));
  if (!s || !s.isTextblock)
    return !1;
  if (e) {
    let o = (!r.parentOffset && i.index() < i.parent.childCount ? r : i).pos, l = n.tr.insert(o, s.createAndFill());
    l.setSelection(z.create(l.doc, o + 1)), e(l.scrollIntoView());
  }
  return !0;
}, Ap = (n, e) => {
  let { $cursor: t } = n.selection;
  if (!t || t.parent.content.size)
    return !1;
  if (t.depth > 1 && t.after() != t.end(-1)) {
    let s = t.before();
    if (Xt(n.doc, s))
      return e && e(n.tr.split(s).scrollIntoView()), !0;
  }
  let r = t.blockRange(), i = r && Er(r);
  return i == null ? !1 : (e && e(n.tr.lift(r, i).scrollIntoView()), !0);
};
function Kk(n) {
  return (e, t) => {
    let { $from: r, $to: i } = e.selection;
    if (e.selection instanceof B && e.selection.node.isBlock)
      return !r.parentOffset || !Xt(e.doc, r.pos) ? !1 : (t && t(e.tr.split(r.pos).scrollIntoView()), !0);
    if (!r.depth)
      return !1;
    let s = [], o, l, a = !1, c = !1;
    for (let h = r.depth; ; h--)
      if (r.node(h).isBlock) {
        a = r.end(h) == r.pos + (r.depth - h), c = r.start(h) == r.pos - (r.depth - h), l = Fa(r.node(h - 1).contentMatchAt(r.indexAfter(h - 1))), s.unshift(a && l ? { type: l } : null), o = h;
        break;
      } else {
        if (h == 1)
          return !1;
        s.unshift(null);
      }
    let u = e.tr;
    (e.selection instanceof z || e.selection instanceof Qe) && u.deleteSelection();
    let d = u.mapping.map(r.pos), f = Xt(u.doc, d, s.length, s);
    if (f || (s[0] = l ? { type: l } : null, f = Xt(u.doc, d, s.length, s)), !f)
      return !1;
    if (u.split(d, s.length, s), !a && c && r.node(o).type != l) {
      let h = u.mapping.map(r.before(o)), p = u.doc.resolve(h);
      l && r.node(o - 1).canReplaceWith(p.index(), p.index() + 1, l) && u.setNodeMarkup(u.mapping.map(r.before(o)), l);
    }
    return t && t(u.scrollIntoView()), !0;
  };
}
const Gk = Kk(), Jk = (n, e) => {
  let { $from: t, to: r } = n.selection, i, s = t.sharedDepth(r);
  return s == 0 ? !1 : (i = t.before(s), e && e(n.tr.setSelection(B.create(n.doc, i))), !0);
};
function Yk(n, e, t) {
  let r = e.nodeBefore, i = e.nodeAfter, s = e.index();
  return !r || !i || !r.type.compatibleContent(i.type) ? !1 : !r.content.size && e.parent.canReplace(s - 1, s) ? (t && t(n.tr.delete(e.pos - r.nodeSize, e.pos).scrollIntoView()), !0) : !e.parent.canReplace(s, s + 1) || !(i.isTextblock || wn(n.doc, e.pos)) ? !1 : (t && t(n.tr.join(e.pos).scrollIntoView()), !0);
}
function xp(n, e, t, r) {
  let i = e.nodeBefore, s = e.nodeAfter, o, l, a = i.type.spec.isolating || s.type.spec.isolating;
  if (!a && Yk(n, e, t))
    return !0;
  let c = !a && e.parent.canReplace(e.index(), e.index() + 1);
  if (c && (o = (l = i.contentMatchAt(i.childCount)).findWrapping(s.type)) && l.matchType(o[0] || s.type).validEnd) {
    if (t) {
      let h = e.pos + s.nodeSize, p = A.empty;
      for (let b = o.length - 1; b >= 0; b--)
        p = A.from(o[b].create(null, p));
      p = A.from(i.copy(p));
      let m = n.tr.step(new De(e.pos - 1, h, e.pos, h, new O(p, 1, 0), o.length, !0)), _ = m.doc.resolve(h + 2 * o.length);
      _.nodeAfter && _.nodeAfter.type == i.type && wn(m.doc, _.pos) && m.join(_.pos), t(m.scrollIntoView());
    }
    return !0;
  }
  let u = s.type.spec.isolating || r > 0 && a ? null : V.findFrom(e, 1), d = u && u.$from.blockRange(u.$to), f = d && Er(d);
  if (f != null && f >= e.depth)
    return t && t(n.tr.lift(d, f).scrollIntoView()), !0;
  if (c && kr(s, "start", !0) && kr(i, "end")) {
    let h = i, p = [];
    for (; p.push(h), !h.isTextblock; )
      h = h.lastChild;
    let m = s, _ = 1;
    for (; !m.isTextblock; m = m.firstChild)
      _++;
    if (h.canReplace(h.childCount, h.childCount, m.content)) {
      if (t) {
        let b = A.empty;
        for (let g = p.length - 1; g >= 0; g--)
          b = A.from(p[g].copy(b));
        let y = n.tr.step(new De(e.pos - p.length, e.pos + s.nodeSize, e.pos + _, e.pos + s.nodeSize - _, new O(b, p.length, 0), 0, !0));
        t(y.scrollIntoView());
      }
      return !0;
    }
  }
  return !1;
}
function Tp(n) {
  return function(e, t) {
    let r = e.selection, i = n < 0 ? r.$from : r.$to, s = i.depth;
    for (; i.node(s).isInline; ) {
      if (!s)
        return !1;
      s--;
    }
    return i.node(s).isTextblock ? (t && t(e.tr.setSelection(z.create(e.doc, n < 0 ? i.start(s) : i.end(s)))), !0) : !1;
  };
}
const Xk = Tp(-1), Zk = Tp(1);
function Qk(n, e = null) {
  return function(t, r) {
    let { $from: i, $to: s } = t.selection, o = i.blockRange(s), l = o && _a(o, n, e);
    return l ? (r && r(t.tr.wrap(o, l).scrollIntoView()), !0) : !1;
  };
}
function Td(n, e = null) {
  return function(t, r) {
    let i = !1;
    for (let s = 0; s < t.selection.ranges.length && !i; s++) {
      let { $from: { pos: o }, $to: { pos: l } } = t.selection.ranges[s];
      t.doc.nodesBetween(o, l, (a, c) => {
        if (i)
          return !1;
        if (!(!a.isTextblock || a.hasMarkup(n, e)))
          if (a.type == n)
            i = !0;
          else {
            let u = t.doc.resolve(c), d = u.index();
            i = u.parent.canReplaceWith(d, d + 1, n);
          }
      });
    }
    if (!i)
      return !1;
    if (r) {
      let s = t.tr;
      for (let o = 0; o < t.selection.ranges.length; o++) {
        let { $from: { pos: l }, $to: { pos: a } } = t.selection.ranges[o];
        s.setBlockType(l, a, n, e);
      }
      r(s.scrollIntoView());
    }
    return !0;
  };
}
function $a(...n) {
  return function(e, t, r) {
    for (let i = 0; i < n.length; i++)
      if (n[i](e, t, r))
        return !0;
    return !1;
  };
}
$a(xa, bp, wp);
$a(xa, Ep, Dp);
$a(Sp, Cp, Ap, Gk);
typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : typeof os < "u" && os.platform && os.platform() == "darwin";
function ew(n, e = null) {
  return function(t, r) {
    let { $from: i, $to: s } = t.selection, o = i.blockRange(s);
    if (!o)
      return !1;
    let l = r ? t.tr : null;
    return tw(l, o, n, e) ? (r && r(l.scrollIntoView()), !0) : !1;
  };
}
function tw(n, e, t, r = null) {
  let i = !1, s = e, o = e.$from.doc;
  if (e.depth >= 2 && e.$from.node(e.depth - 1).type.compatibleContent(t) && e.startIndex == 0) {
    if (e.$from.index(e.depth - 1) == 0)
      return !1;
    let a = o.resolve(e.start - 2);
    s = new bs(a, a, e.depth), e.endIndex < e.parent.childCount && (e = new bs(e.$from, o.resolve(e.$to.end(e.depth)), e.depth)), i = !0;
  }
  let l = _a(s, t, r, e);
  return l ? (n && nw(n, e, l, i, t), !0) : !1;
}
function nw(n, e, t, r, i) {
  let s = A.empty;
  for (let u = t.length - 1; u >= 0; u--)
    s = A.from(t[u].type.create(t[u].attrs, s));
  n.step(new De(e.start - (r ? 2 : 0), e.end, e.start, e.end, new O(s, 0, 0), t.length, !0));
  let o = 0;
  for (let u = 0; u < t.length; u++)
    t[u].type == i && (o = u + 1);
  let l = t.length - o, a = e.start + t.length - (r ? 2 : 0), c = e.parent;
  for (let u = e.startIndex, d = e.endIndex, f = !0; u < d; u++, f = !1)
    !f && Xt(n.doc, a, l) && (n.split(a, l), a += 2 * l), a += c.child(u).nodeSize;
  return n;
}
function rw(n) {
  return function(e, t) {
    let { $from: r, $to: i } = e.selection, s = r.blockRange(i, (o) => o.childCount > 0 && o.firstChild.type == n);
    return s ? t ? r.node(s.depth - 1).type == n ? iw(e, t, n, s) : sw(e, t, s) : !0 : !1;
  };
}
function iw(n, e, t, r) {
  let i = n.tr, s = r.end, o = r.$to.end(r.depth);
  s < o && (i.step(new De(s - 1, o, s, o, new O(A.from(t.create(null, r.parent.copy())), 1, 0), 1, !0)), r = new bs(i.doc.resolve(r.$from.pos), i.doc.resolve(o), r.depth));
  const l = Er(r);
  if (l == null)
    return !1;
  i.lift(r, l);
  let a = i.doc.resolve(i.mapping.map(s, -1) - 1);
  return wn(i.doc, a.pos) && a.nodeBefore.type == a.nodeAfter.type && i.join(a.pos), e(i.scrollIntoView()), !0;
}
function sw(n, e, t) {
  let r = n.tr, i = t.parent;
  for (let h = t.end, p = t.endIndex - 1, m = t.startIndex; p > m; p--)
    h -= i.child(p).nodeSize, r.delete(h - 1, h + 1);
  let s = r.doc.resolve(t.start), o = s.nodeAfter;
  if (r.mapping.map(t.end) != t.start + s.nodeAfter.nodeSize)
    return !1;
  let l = t.startIndex == 0, a = t.endIndex == i.childCount, c = s.node(-1), u = s.index(-1);
  if (!c.canReplace(u + (l ? 0 : 1), u + 1, o.content.append(a ? A.empty : A.from(i))))
    return !1;
  let d = s.pos, f = d + o.nodeSize;
  return r.step(new De(d - (l ? 1 : 0), f + (a ? 1 : 0), d + 1, f - 1, new O((l ? A.empty : A.from(i.copy(A.empty))).append(a ? A.empty : A.from(i.copy(A.empty))), l ? 0 : 1, a ? 0 : 1), l ? 0 : 1)), e(r.scrollIntoView()), !0;
}
function ow(n) {
  return function(e, t) {
    let { $from: r, $to: i } = e.selection, s = r.blockRange(i, (c) => c.childCount > 0 && c.firstChild.type == n);
    if (!s)
      return !1;
    let o = s.startIndex;
    if (o == 0)
      return !1;
    let l = s.parent, a = l.child(o - 1);
    if (a.type != n)
      return !1;
    if (t) {
      let c = a.lastChild && a.lastChild.type == l.type, u = A.from(c ? n.create() : null), d = new O(A.from(n.create(null, A.from(l.type.create(null, u)))), c ? 3 : 1, 0), f = s.start, h = s.end;
      t(e.tr.step(new De(f - (c ? 3 : 1), h, f, h, d, 1, !0)).scrollIntoView());
    }
    return !0;
  };
}
var lw = Object.defineProperty, Mp = (n, e) => {
  for (var t in e)
    lw(n, t, { get: e[t], enumerable: !0 });
};
function ho(n) {
  const { state: e, transaction: t } = n;
  let { selection: r } = t, { doc: i } = t, { storedMarks: s } = t;
  return {
    ...e,
    apply: e.apply.bind(e),
    applyTransaction: e.applyTransaction.bind(e),
    plugins: e.plugins,
    schema: e.schema,
    reconfigure: e.reconfigure.bind(e),
    toJSON: e.toJSON.bind(e),
    get storedMarks() {
      return s;
    },
    get selection() {
      return r;
    },
    get doc() {
      return i;
    },
    get tr() {
      return r = t.selection, i = t.doc, s = t.storedMarks, t;
    }
  };
}
var po = class {
  constructor(n) {
    this.editor = n.editor, this.rawCommands = this.editor.extensionManager.commands, this.customState = n.state;
  }
  get hasCustomState() {
    return !!this.customState;
  }
  get state() {
    return this.customState || this.editor.state;
  }
  get commands() {
    const { rawCommands: n, editor: e, state: t } = this, { view: r } = e, { tr: i } = t, s = this.buildProps(i);
    return Object.fromEntries(
      Object.entries(n).map(([o, l]) => [o, (...c) => {
        const u = l(...c)(s);
        return !i.getMeta("preventDispatch") && !this.hasCustomState && r.dispatch(i), u;
      }])
    );
  }
  get chain() {
    return () => this.createChain();
  }
  get can() {
    return () => this.createCan();
  }
  createChain(n, e = !0) {
    const { rawCommands: t, editor: r, state: i } = this, { view: s } = r, o = [], l = !!n, a = n || i.tr, c = () => (!l && e && !a.getMeta("preventDispatch") && !this.hasCustomState && s.dispatch(a), o.every((d) => d === !0)), u = {
      ...Object.fromEntries(
        Object.entries(t).map(([d, f]) => [d, (...p) => {
          const m = this.buildProps(a, e), _ = f(...p)(m);
          return o.push(_), u;
        }])
      ),
      run: c
    };
    return u;
  }
  createCan(n) {
    const { rawCommands: e, state: t } = this, r = !1, i = n || t.tr, s = this.buildProps(i, r);
    return {
      ...Object.fromEntries(
        Object.entries(e).map(([l, a]) => [l, (...c) => a(...c)({ ...s, dispatch: void 0 })])
      ),
      chain: () => this.createChain(i, r)
    };
  }
  buildProps(n, e = !0) {
    const { rawCommands: t, editor: r, state: i } = this, { view: s } = r, o = {
      tr: n,
      editor: r,
      view: s,
      state: ho({
        state: i,
        transaction: n
      }),
      dispatch: e ? () => {
      } : void 0,
      chain: () => this.createChain(n, e),
      can: () => this.createCan(n),
      get commands() {
        return Object.fromEntries(
          Object.entries(t).map(([l, a]) => [l, (...c) => a(...c)(o)])
        );
      }
    };
    return o;
  }
}, aw = class {
  constructor() {
    this.callbacks = {};
  }
  on(n, e) {
    return this.callbacks[n] || (this.callbacks[n] = []), this.callbacks[n].push(e), this;
  }
  emit(n, ...e) {
    const t = this.callbacks[n];
    return t && t.forEach((r) => r.apply(this, e)), this;
  }
  off(n, e) {
    const t = this.callbacks[n];
    return t && (e ? this.callbacks[n] = t.filter((r) => r !== e) : delete this.callbacks[n]), this;
  }
  once(n, e) {
    const t = (...r) => {
      this.off(n, t), e.apply(this, r);
    };
    return this.on(n, t);
  }
  removeAllListeners() {
    this.callbacks = {};
  }
};
function Fp(n, e) {
  const t = new Nh(n);
  return e.forEach((r) => {
    r.steps.forEach((i) => {
      t.step(i);
    });
  }), t;
}
var $p = (n) => {
  const e = n.childNodes;
  for (let t = e.length - 1; t >= 0; t -= 1) {
    const r = e[t];
    r.nodeType === 3 && r.nodeValue && /^(\n\s\s|\n)$/.test(r.nodeValue) ? n.removeChild(r) : r.nodeType === 1 && $p(r);
  }
  return n;
};
function Wi(n) {
  if (typeof window > "u")
    throw new Error("[tiptap error]: there is no window object available, so this function cannot be used");
  const e = `<body>${n}</body>`, t = new window.DOMParser().parseFromString(e, "text/html").body;
  return $p(t);
}
function fi(n, e, t) {
  if (n instanceof Dt || n instanceof A)
    return n;
  t = {
    slice: !0,
    parseOptions: {},
    ...t
  };
  const r = typeof n == "object" && n !== null, i = typeof n == "string";
  if (r)
    try {
      if (Array.isArray(n) && n.length > 0)
        return A.fromArray(n.map((l) => e.nodeFromJSON(l)));
      const o = e.nodeFromJSON(n);
      return t.errorOnInvalidContent && o.check(), o;
    } catch (s) {
      if (t.errorOnInvalidContent)
        throw new Error("[tiptap error]: Invalid JSON content", { cause: s });
      return console.warn("[tiptap warn]: Invalid content.", "Passed value:", n, "Error:", s), fi("", e, t);
    }
  if (i) {
    if (t.errorOnInvalidContent) {
      let o = !1, l = "";
      const a = new yh({
        topNode: e.spec.topNode,
        marks: e.spec.marks,
        // Prosemirror's schemas are executed such that: the last to execute, matches last
        // This means that we can add a catch-all node at the end of the schema to catch any content that we don't know how to handle
        nodes: e.spec.nodes.append({
          __tiptap__private__unknown__catch__all__node: {
            content: "inline*",
            group: "block",
            parseDOM: [
              {
                tag: "*",
                getAttrs: (c) => (o = !0, l = typeof c == "string" ? c : c.outerHTML, null)
              }
            ]
          }
        })
      });
      if (t.slice ? Kr.fromSchema(a).parseSlice(Wi(n), t.parseOptions) : Kr.fromSchema(a).parse(Wi(n), t.parseOptions), t.errorOnInvalidContent && o)
        throw new Error("[tiptap error]: Invalid HTML content", {
          cause: new Error(`Invalid element found: ${l}`)
        });
    }
    const s = Kr.fromSchema(e);
    return t.slice ? s.parseSlice(Wi(n), t.parseOptions).content : s.parse(Wi(n), t.parseOptions);
  }
  return fi("", e, t);
}
function Kl(n, e, t = {}, r = {}) {
  return fi(n, e, {
    slice: !1,
    parseOptions: t,
    errorOnInvalidContent: r.errorOnInvalidContent
  });
}
function cw(n) {
  for (let e = 0; e < n.edgeCount; e += 1) {
    const { type: t } = n.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
function uw(n, e, t) {
  const r = [];
  return n.nodesBetween(e.from, e.to, (i, s) => {
    t(i) && r.push({
      node: i,
      pos: s
    });
  }), r;
}
function dw(n, e) {
  for (let t = n.depth; t > 0; t -= 1) {
    const r = n.node(t);
    if (e(r))
      return {
        pos: t > 0 ? n.before(t) : 0,
        start: n.start(t),
        depth: t,
        node: r
      };
  }
}
function mo(n) {
  return (e) => dw(e.$from, n);
}
function L(n, e, t) {
  return n.config[e] === void 0 && n.parent ? L(n.parent, e, t) : typeof n.config[e] == "function" ? n.config[e].bind({
    ...t,
    parent: n.parent ? L(n.parent, e, t) : null
  }) : n.config[e];
}
function Oa(n) {
  return n.map((e) => {
    const t = {
      name: e.name,
      options: e.options,
      storage: e.storage
    }, r = L(e, "addExtensions", t);
    return r ? [e, ...Oa(r())] : e;
  }).flat(10);
}
function Na(n, e) {
  const t = Wn.fromSchema(e).serializeFragment(n), i = document.implementation.createHTMLDocument().createElement("div");
  return i.appendChild(t), i.innerHTML;
}
function Op(n) {
  return typeof n == "function";
}
function J(n, e = void 0, ...t) {
  return Op(n) ? e ? n.bind(e)(...t) : n(...t) : n;
}
function fw(n = {}) {
  return Object.keys(n).length === 0 && n.constructor === Object;
}
function hi(n) {
  const e = n.filter((i) => i.type === "extension"), t = n.filter((i) => i.type === "node"), r = n.filter((i) => i.type === "mark");
  return {
    baseExtensions: e,
    nodeExtensions: t,
    markExtensions: r
  };
}
function Np(n) {
  const e = [], { nodeExtensions: t, markExtensions: r } = hi(n), i = [...t, ...r], s = {
    default: null,
    validate: void 0,
    rendered: !0,
    renderHTML: null,
    parseHTML: null,
    keepOnSplit: !0,
    isRequired: !1
  };
  return n.forEach((o) => {
    const l = {
      name: o.name,
      options: o.options,
      storage: o.storage,
      extensions: i
    }, a = L(
      o,
      "addGlobalAttributes",
      l
    );
    if (!a)
      return;
    a().forEach((u) => {
      u.types.forEach((d) => {
        Object.entries(u.attributes).forEach(([f, h]) => {
          e.push({
            type: d,
            name: f,
            attribute: {
              ...s,
              ...h
            }
          });
        });
      });
    });
  }), i.forEach((o) => {
    const l = {
      name: o.name,
      options: o.options,
      storage: o.storage
    }, a = L(
      o,
      "addAttributes",
      l
    );
    if (!a)
      return;
    const c = a();
    Object.entries(c).forEach(([u, d]) => {
      const f = {
        ...s,
        ...d
      };
      typeof (f == null ? void 0 : f.default) == "function" && (f.default = f.default()), f != null && f.isRequired && (f == null ? void 0 : f.default) === void 0 && delete f.default, e.push({
        type: o.name,
        name: u,
        attribute: f
      });
    });
  }), e;
}
function fe(...n) {
  return n.filter((e) => !!e).reduce((e, t) => {
    const r = { ...e };
    return Object.entries(t).forEach(([i, s]) => {
      if (!r[i]) {
        r[i] = s;
        return;
      }
      if (i === "class") {
        const l = s ? String(s).split(" ") : [], a = r[i] ? r[i].split(" ") : [], c = l.filter((u) => !a.includes(u));
        r[i] = [...a, ...c].join(" ");
      } else if (i === "style") {
        const l = s ? s.split(";").map((u) => u.trim()).filter(Boolean) : [], a = r[i] ? r[i].split(";").map((u) => u.trim()).filter(Boolean) : [], c = /* @__PURE__ */ new Map();
        a.forEach((u) => {
          const [d, f] = u.split(":").map((h) => h.trim());
          c.set(d, f);
        }), l.forEach((u) => {
          const [d, f] = u.split(":").map((h) => h.trim());
          c.set(d, f);
        }), r[i] = Array.from(c.entries()).map(([u, d]) => `${u}: ${d}`).join("; ");
      } else
        r[i] = s;
    }), r;
  }, {});
}
function As(n, e) {
  return e.filter((t) => t.type === n.type.name).filter((t) => t.attribute.rendered).map((t) => t.attribute.renderHTML ? t.attribute.renderHTML(n.attrs) || {} : {
    [t.name]: n.attrs[t.name]
  }).reduce((t, r) => fe(t, r), {});
}
function hw(n) {
  return typeof n != "string" ? n : n.match(/^[+-]?(?:\d*\.)?\d+$/) ? Number(n) : n === "true" ? !0 : n === "false" ? !1 : n;
}
function Md(n, e) {
  return "style" in n ? n : {
    ...n,
    getAttrs: (t) => {
      const r = n.getAttrs ? n.getAttrs(t) : n.attrs;
      if (r === !1)
        return !1;
      const i = e.reduce((s, o) => {
        const l = o.attribute.parseHTML ? o.attribute.parseHTML(t) : hw(t.getAttribute(o.name));
        return l == null ? s : {
          ...s,
          [o.name]: l
        };
      }, {});
      return { ...r, ...i };
    }
  };
}
function Fd(n) {
  return Object.fromEntries(
    // @ts-ignore
    Object.entries(n).filter(([e, t]) => e === "attrs" && fw(t) ? !1 : t != null)
  );
}
function pw(n, e) {
  var t;
  const r = Np(n), { nodeExtensions: i, markExtensions: s } = hi(n), o = (t = i.find((c) => L(c, "topNode"))) == null ? void 0 : t.name, l = Object.fromEntries(
    i.map((c) => {
      const u = r.filter((b) => b.type === c.name), d = {
        name: c.name,
        options: c.options,
        storage: c.storage,
        editor: e
      }, f = n.reduce((b, y) => {
        const g = L(y, "extendNodeSchema", d);
        return {
          ...b,
          ...g ? g(c) : {}
        };
      }, {}), h = Fd({
        ...f,
        content: J(L(c, "content", d)),
        marks: J(L(c, "marks", d)),
        group: J(L(c, "group", d)),
        inline: J(L(c, "inline", d)),
        atom: J(L(c, "atom", d)),
        selectable: J(L(c, "selectable", d)),
        draggable: J(L(c, "draggable", d)),
        code: J(L(c, "code", d)),
        whitespace: J(L(c, "whitespace", d)),
        linebreakReplacement: J(
          L(c, "linebreakReplacement", d)
        ),
        defining: J(L(c, "defining", d)),
        isolating: J(L(c, "isolating", d)),
        attrs: Object.fromEntries(
          u.map((b) => {
            var y, g;
            return [
              b.name,
              { default: (y = b == null ? void 0 : b.attribute) == null ? void 0 : y.default, validate: (g = b == null ? void 0 : b.attribute) == null ? void 0 : g.validate }
            ];
          })
        )
      }), p = J(L(c, "parseHTML", d));
      p && (h.parseDOM = p.map(
        (b) => Md(b, u)
      ));
      const m = L(c, "renderHTML", d);
      m && (h.toDOM = (b) => m({
        node: b,
        HTMLAttributes: As(b, u)
      }));
      const _ = L(c, "renderText", d);
      return _ && (h.toText = _), [c.name, h];
    })
  ), a = Object.fromEntries(
    s.map((c) => {
      const u = r.filter((_) => _.type === c.name), d = {
        name: c.name,
        options: c.options,
        storage: c.storage,
        editor: e
      }, f = n.reduce((_, b) => {
        const y = L(b, "extendMarkSchema", d);
        return {
          ..._,
          ...y ? y(c) : {}
        };
      }, {}), h = Fd({
        ...f,
        inclusive: J(L(c, "inclusive", d)),
        excludes: J(L(c, "excludes", d)),
        group: J(L(c, "group", d)),
        spanning: J(L(c, "spanning", d)),
        code: J(L(c, "code", d)),
        attrs: Object.fromEntries(
          u.map((_) => {
            var b, y;
            return [
              _.name,
              { default: (b = _ == null ? void 0 : _.attribute) == null ? void 0 : b.default, validate: (y = _ == null ? void 0 : _.attribute) == null ? void 0 : y.validate }
            ];
          })
        )
      }), p = J(L(c, "parseHTML", d));
      p && (h.parseDOM = p.map(
        (_) => Md(_, u)
      ));
      const m = L(c, "renderHTML", d);
      return m && (h.toDOM = (_) => m({
        mark: _,
        HTMLAttributes: As(_, u)
      })), [c.name, h];
    })
  );
  return new yh({
    topNode: o,
    nodes: l,
    marks: a
  });
}
function mw(n) {
  const e = n.filter((t, r) => n.indexOf(t) !== r);
  return Array.from(new Set(e));
}
function Ia(n) {
  return n.sort((t, r) => {
    const i = L(t, "priority") || 100, s = L(r, "priority") || 100;
    return i > s ? -1 : i < s ? 1 : 0;
  });
}
function Ip(n) {
  const e = Ia(Oa(n)), t = mw(e.map((r) => r.name));
  return t.length && console.warn(
    `[tiptap warn]: Duplicate extension names found: [${t.map((r) => `'${r}'`).join(", ")}]. This can lead to issues.`
  ), e;
}
function Rp(n, e, t) {
  const { from: r, to: i } = e, { blockSeparator: s = `

`, textSerializers: o = {} } = t || {};
  let l = "";
  return n.nodesBetween(r, i, (a, c, u, d) => {
    var f;
    a.isBlock && c > r && (l += s);
    const h = o == null ? void 0 : o[a.type.name];
    if (h)
      return u && (l += h({
        node: a,
        pos: c,
        parent: u,
        index: d,
        range: e
      })), !1;
    a.isText && (l += (f = a == null ? void 0 : a.text) == null ? void 0 : f.slice(Math.max(r, c) - c, i - c));
  }), l;
}
function gw(n, e) {
  const t = {
    from: 0,
    to: n.content.size
  };
  return Rp(n, t, e);
}
function Lp(n) {
  return Object.fromEntries(
    Object.entries(n.nodes).filter(([, e]) => e.spec.toText).map(([e, t]) => [e, t.spec.toText])
  );
}
function Qt(n, e) {
  if (typeof n == "string") {
    if (!e.marks[n])
      throw Error(`There is no mark type named '${n}'. Maybe you forgot to add the extension?`);
    return e.marks[n];
  }
  return n;
}
function Pp(n, e) {
  const t = Qt(e, n.schema), { from: r, to: i, empty: s } = n.selection, o = [];
  s ? (n.storedMarks && o.push(...n.storedMarks), o.push(...n.selection.$head.marks())) : n.doc.nodesBetween(r, i, (a) => {
    o.push(...a.marks);
  });
  const l = o.find((a) => a.type.name === t.name);
  return l ? { ...l.attrs } : {};
}
function ge(n, e) {
  if (typeof n == "string") {
    if (!e.nodes[n])
      throw Error(`There is no node type named '${n}'. Maybe you forgot to add the extension?`);
    return e.nodes[n];
  }
  return n;
}
function _w(n, e) {
  const t = ge(e, n.schema), { from: r, to: i } = n.selection, s = [];
  n.doc.nodesBetween(r, i, (l) => {
    s.push(l);
  });
  const o = s.reverse().find((l) => l.type.name === t.name);
  return o ? { ...o.attrs } : {};
}
function go(n, e) {
  return e.nodes[n] ? "node" : e.marks[n] ? "mark" : null;
}
function Bp(n, e) {
  const t = go(
    typeof e == "string" ? e : e.name,
    n.schema
  );
  return t === "node" ? _w(n, e) : t === "mark" ? Pp(n, e) : {};
}
function yw(n, e = JSON.stringify) {
  const t = {};
  return n.filter((r) => {
    const i = e(r);
    return Object.prototype.hasOwnProperty.call(t, i) ? !1 : t[i] = !0;
  });
}
function bw(n) {
  const e = yw(n);
  return e.length === 1 ? e : e.filter((t, r) => !e.filter((s, o) => o !== r).some((s) => t.oldRange.from >= s.oldRange.from && t.oldRange.to <= s.oldRange.to && t.newRange.from >= s.newRange.from && t.newRange.to <= s.newRange.to));
}
function zp(n) {
  const { mapping: e, steps: t } = n, r = [];
  return e.maps.forEach((i, s) => {
    const o = [];
    if (i.ranges.length)
      i.forEach((l, a) => {
        o.push({ from: l, to: a });
      });
    else {
      const { from: l, to: a } = t[s];
      if (l === void 0 || a === void 0)
        return;
      o.push({ from: l, to: a });
    }
    o.forEach(({ from: l, to: a }) => {
      const c = e.slice(s).map(l, -1), u = e.slice(s).map(a), d = e.invert().map(c, -1), f = e.invert().map(u);
      r.push({
        oldRange: {
          from: d,
          to: f
        },
        newRange: {
          from: c,
          to: u
        }
      });
    });
  }), bw(r);
}
function Ra(n) {
  return Object.prototype.toString.call(n) === "[object RegExp]";
}
function xs(n, e, t = { strict: !0 }) {
  const r = Object.keys(e);
  return r.length ? r.every((i) => t.strict ? e[i] === n[i] : Ra(e[i]) ? e[i].test(n[i]) : e[i] === n[i]) : !0;
}
function Hp(n, e, t = {}) {
  return n.find((r) => r.type === e && xs(
    // Only check equality for the attributes that are provided
    Object.fromEntries(Object.keys(t).map((i) => [i, r.attrs[i]])),
    t
  ));
}
function $d(n, e, t = {}) {
  return !!Hp(n, e, t);
}
function La(n, e, t) {
  var r;
  if (!n || !e)
    return;
  let i = n.parent.childAfter(n.parentOffset);
  if ((!i.node || !i.node.marks.some((u) => u.type === e)) && (i = n.parent.childBefore(n.parentOffset)), !i.node || !i.node.marks.some((u) => u.type === e) || (t = t || ((r = i.node.marks[0]) == null ? void 0 : r.attrs), !Hp([...i.node.marks], e, t)))
    return;
  let o = i.index, l = n.start() + i.offset, a = o + 1, c = l + i.node.nodeSize;
  for (; o > 0 && $d([...n.parent.child(o - 1).marks], e, t); )
    o -= 1, l -= n.parent.child(o).nodeSize;
  for (; a < n.parent.childCount && $d([...n.parent.child(a).marks], e, t); )
    c += n.parent.child(a).nodeSize, a += 1;
  return {
    from: l,
    to: c
  };
}
function Pa(n, e, t) {
  const r = [];
  return n === e ? t.resolve(n).marks().forEach((i) => {
    const s = t.resolve(n), o = La(s, i.type);
    o && r.push({
      mark: i,
      ...o
    });
  }) : t.nodesBetween(n, e, (i, s) => {
    !i || (i == null ? void 0 : i.nodeSize) === void 0 || r.push(
      ...i.marks.map((o) => ({
        from: s,
        to: s + i.nodeSize,
        mark: o
      }))
    );
  }), r;
}
var kw = (n, e, t, r = 20) => {
  const i = n.doc.resolve(t);
  let s = r, o = null;
  for (; s > 0 && o === null; ) {
    const l = i.node(s);
    (l == null ? void 0 : l.type.name) === e ? o = l : s -= 1;
  }
  return [o, s];
};
function ll(n, e) {
  return e.nodes[n] || e.marks[n] || null;
}
function cs(n, e, t) {
  return Object.fromEntries(
    Object.entries(t).filter(([r]) => {
      const i = n.find((s) => s.type === e && s.name === r);
      return i ? i.attribute.keepOnSplit : !1;
    })
  );
}
var ww = (n, e = 500) => {
  let t = "";
  const r = n.parentOffset;
  return n.parent.nodesBetween(Math.max(0, r - e), r, (i, s, o, l) => {
    var a, c;
    const u = ((c = (a = i.type.spec).toText) == null ? void 0 : c.call(a, {
      node: i,
      pos: s,
      parent: o,
      index: l
    })) || i.textContent || "%leaf%";
    t += i.isAtom && !i.isText ? u : u.slice(0, Math.max(0, r - s));
  }), t;
};
function Gl(n, e, t = {}) {
  const { empty: r, ranges: i } = n.selection, s = e ? Qt(e, n.schema) : null;
  if (r)
    return !!(n.storedMarks || n.selection.$from.marks()).filter((d) => s ? s.name === d.type.name : !0).find((d) => xs(d.attrs, t, { strict: !1 }));
  let o = 0;
  const l = [];
  if (i.forEach(({ $from: d, $to: f }) => {
    const h = d.pos, p = f.pos;
    n.doc.nodesBetween(h, p, (m, _) => {
      if (!m.isText && !m.marks.length)
        return;
      const b = Math.max(h, _), y = Math.min(p, _ + m.nodeSize), g = y - b;
      o += g, l.push(
        ...m.marks.map((w) => ({
          mark: w,
          from: b,
          to: y
        }))
      );
    });
  }), o === 0)
    return !1;
  const a = l.filter((d) => s ? s.name === d.mark.type.name : !0).filter((d) => xs(d.mark.attrs, t, { strict: !1 })).reduce((d, f) => d + f.to - f.from, 0), c = l.filter((d) => s ? d.mark.type !== s && d.mark.type.excludes(s) : !0).reduce((d, f) => d + f.to - f.from, 0);
  return (a > 0 ? a + c : a) >= o;
}
function kn(n, e, t = {}) {
  const { from: r, to: i, empty: s } = n.selection, o = e ? ge(e, n.schema) : null, l = [];
  n.doc.nodesBetween(r, i, (d, f) => {
    if (d.isText)
      return;
    const h = Math.max(r, f), p = Math.min(i, f + d.nodeSize);
    l.push({
      node: d,
      from: h,
      to: p
    });
  });
  const a = i - r, c = l.filter((d) => o ? o.name === d.node.type.name : !0).filter((d) => xs(d.node.attrs, t, { strict: !1 }));
  return s ? !!c.length : c.reduce((d, f) => d + f.to - f.from, 0) >= a;
}
function vw(n, e, t = {}) {
  if (!e)
    return kn(n, null, t) || Gl(n, null, t);
  const r = go(e, n.schema);
  return r === "node" ? kn(n, e, t) : r === "mark" ? Gl(n, e, t) : !1;
}
var Ew = (n, e) => {
  const { $from: t, $to: r, $anchor: i } = n.selection;
  if (e) {
    const s = mo((l) => l.type.name === e)(n.selection);
    if (!s)
      return !1;
    const o = n.doc.resolve(s.pos + 1);
    return i.pos + 1 === o.end();
  }
  return !(r.parentOffset < r.parent.nodeSize - 2 || t.pos !== r.pos);
}, Dw = (n) => {
  const { $from: e, $to: t } = n.selection;
  return !(e.parentOffset > 0 || e.pos !== t.pos);
};
function Od(n, e) {
  return Array.isArray(e) ? e.some((t) => (typeof t == "string" ? t : t.name) === n.name) : e;
}
function Nd(n, e) {
  const { nodeExtensions: t } = hi(e), r = t.find((o) => o.name === n);
  if (!r)
    return !1;
  const i = {
    name: r.name,
    options: r.options,
    storage: r.storage
  }, s = J(L(r, "group", i));
  return typeof s != "string" ? !1 : s.split(" ").includes("list");
}
function _o(n, {
  checkChildren: e = !0,
  ignoreWhitespace: t = !1
} = {}) {
  var r;
  if (t) {
    if (n.type.name === "hardBreak")
      return !0;
    if (n.isText)
      return /^\s*$/m.test((r = n.text) != null ? r : "");
  }
  if (n.isText)
    return !n.text;
  if (n.isAtom || n.isLeaf)
    return !1;
  if (n.content.childCount === 0)
    return !0;
  if (e) {
    let i = !0;
    return n.content.forEach((s) => {
      i !== !1 && (_o(s, { ignoreWhitespace: t, checkChildren: e }) || (i = !1));
    }), i;
  }
  return !1;
}
function qp(n) {
  return n instanceof B;
}
function Vp(n) {
  return n instanceof z;
}
function Fn(n = 0, e = 0, t = 0) {
  return Math.min(Math.max(n, e), t);
}
function Up(n, e = null) {
  if (!e)
    return null;
  const t = V.atStart(n), r = V.atEnd(n);
  if (e === "start" || e === !0)
    return t;
  if (e === "end")
    return r;
  const i = t.from, s = r.to;
  return e === "all" ? z.create(n, Fn(0, i, s), Fn(n.content.size, i, s)) : z.create(n, Fn(e, i, s), Fn(e, i, s));
}
function Sw(n, e, t) {
  const r = n.steps.length - 1;
  if (r < e)
    return;
  const i = n.steps[r];
  if (!(i instanceof Ee || i instanceof De))
    return;
  const s = n.mapping.maps[r];
  let o = 0;
  s.forEach((l, a, c, u) => {
    o === 0 && (o = u);
  }), n.setSelection(V.near(n.doc.resolve(o), t));
}
var yo = class {
  constructor(n) {
    this.find = n.find, this.handler = n.handler;
  }
}, Cw = (n, e) => {
  if (Ra(e))
    return e.exec(n);
  const t = e(n);
  if (!t)
    return null;
  const r = [t.text];
  return r.index = t.index, r.input = n, r.data = t.data, t.replaceWith && (t.text.includes(t.replaceWith) || console.warn('[tiptap warn]: "inputRuleMatch.replaceWith" must be part of "inputRuleMatch.text".'), r.push(t.replaceWith)), r;
};
function Ki(n) {
  var e;
  const { editor: t, from: r, to: i, text: s, rules: o, plugin: l } = n, { view: a } = t;
  if (a.composing)
    return !1;
  const c = a.state.doc.resolve(r);
  if (
    // check for code node
    c.parent.type.spec.code || (e = c.nodeBefore || c.nodeAfter) != null && e.marks.find((f) => f.type.spec.code)
  )
    return !1;
  let u = !1;
  const d = ww(c) + s;
  return o.forEach((f) => {
    if (u)
      return;
    const h = Cw(d, f.find);
    if (!h)
      return;
    const p = a.state.tr, m = ho({
      state: a.state,
      transaction: p
    }), _ = {
      from: r - (h[0].length - s.length),
      to: i
    }, { commands: b, chain: y, can: g } = new po({
      editor: t,
      state: m
    });
    f.handler({
      state: m,
      range: _,
      match: h,
      commands: b,
      chain: y,
      can: g
    }) === null || !p.steps.length || (p.setMeta(l, {
      transform: p,
      from: r,
      to: i,
      text: s
    }), a.dispatch(p), u = !0);
  }), u;
}
function Aw(n) {
  const { editor: e, rules: t } = n, r = new ae({
    state: {
      init() {
        return null;
      },
      apply(i, s, o) {
        const l = i.getMeta(r);
        if (l)
          return l;
        const a = i.getMeta("applyInputRules");
        return !!a && setTimeout(() => {
          let { text: u } = a;
          typeof u == "string" ? u = u : u = Na(A.from(u), o.schema);
          const { from: d } = a, f = d + u.length;
          Ki({
            editor: e,
            from: d,
            to: f,
            text: u,
            rules: t,
            plugin: r
          });
        }), i.selectionSet || i.docChanged ? null : s;
      }
    },
    props: {
      handleTextInput(i, s, o, l) {
        return Ki({
          editor: e,
          from: s,
          to: o,
          text: l,
          rules: t,
          plugin: r
        });
      },
      handleDOMEvents: {
        compositionend: (i) => (setTimeout(() => {
          const { $cursor: s } = i.state.selection;
          s && Ki({
            editor: e,
            from: s.pos,
            to: s.pos,
            text: "",
            rules: t,
            plugin: r
          });
        }), !1)
      },
      // add support for input rules to trigger on enter
      // this is useful for example for code blocks
      handleKeyDown(i, s) {
        if (s.key !== "Enter")
          return !1;
        const { $cursor: o } = i.state.selection;
        return o ? Ki({
          editor: e,
          from: o.pos,
          to: o.pos,
          text: `
`,
          rules: t,
          plugin: r
        }) : !1;
      }
    },
    // @ts-ignore
    isInputRules: !0
  });
  return r;
}
function xw(n) {
  return Object.prototype.toString.call(n).slice(8, -1);
}
function Gi(n) {
  return xw(n) !== "Object" ? !1 : n.constructor === Object && Object.getPrototypeOf(n) === Object.prototype;
}
function jp(n, e) {
  const t = { ...n };
  return Gi(n) && Gi(e) && Object.keys(e).forEach((r) => {
    Gi(e[r]) && Gi(n[r]) ? t[r] = jp(n[r], e[r]) : t[r] = e[r];
  }), t;
}
var Ba = class {
  constructor(n = {}) {
    this.type = "extendable", this.parent = null, this.child = null, this.name = "", this.config = {
      name: this.name
    }, this.config = {
      ...this.config,
      ...n
    }, this.name = this.config.name;
  }
  get options() {
    return {
      ...J(
        L(this, "addOptions", {
          name: this.name
        })
      ) || {}
    };
  }
  get storage() {
    return {
      ...J(
        L(this, "addStorage", {
          name: this.name,
          options: this.options
        })
      ) || {}
    };
  }
  configure(n = {}) {
    const e = this.extend({
      ...this.config,
      addOptions: () => jp(this.options, n)
    });
    return e.name = this.name, e.parent = this.parent, e;
  }
  extend(n = {}) {
    const e = new this.constructor({ ...this.config, ...n });
    return e.parent = this, this.child = e, e.name = "name" in n ? n.name : e.parent.name, e;
  }
}, Kn = class Wp extends Ba {
  constructor() {
    super(...arguments), this.type = "mark";
  }
  /**
   * Create a new Mark instance
   * @param config - Mark configuration object or a function that returns a configuration object
   */
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new Wp(t);
  }
  static handleExit({ editor: e, mark: t }) {
    const { tr: r } = e.state, i = e.state.selection.$from;
    if (i.pos === i.end()) {
      const o = i.marks();
      if (!!!o.find((c) => (c == null ? void 0 : c.type.name) === t.name))
        return !1;
      const a = o.find((c) => (c == null ? void 0 : c.type.name) === t.name);
      return a && r.removeStoredMark(a), r.insertText(" ", i.pos), e.view.dispatch(r), !0;
    }
    return !1;
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
};
function Tw(n) {
  return typeof n == "number";
}
var Mw = class {
  constructor(n) {
    this.find = n.find, this.handler = n.handler;
  }
}, Fw = (n, e, t) => {
  if (Ra(e))
    return [...n.matchAll(e)];
  const r = e(n, t);
  return r ? r.map((i) => {
    const s = [i.text];
    return s.index = i.index, s.input = n, s.data = i.data, i.replaceWith && (i.text.includes(i.replaceWith) || console.warn('[tiptap warn]: "pasteRuleMatch.replaceWith" must be part of "pasteRuleMatch.text".'), s.push(i.replaceWith)), s;
  }) : [];
};
function $w(n) {
  const { editor: e, state: t, from: r, to: i, rule: s, pasteEvent: o, dropEvent: l } = n, { commands: a, chain: c, can: u } = new po({
    editor: e,
    state: t
  }), d = [];
  return t.doc.nodesBetween(r, i, (h, p) => {
    if (!h.isTextblock || h.type.spec.code)
      return;
    const m = Math.max(r, p), _ = Math.min(i, p + h.content.size), b = h.textBetween(m - p, _ - p, void 0, "￼");
    Fw(b, s.find, o).forEach((g) => {
      if (g.index === void 0)
        return;
      const w = m + g.index + 1, E = w + g[0].length, v = {
        from: t.tr.mapping.map(w),
        to: t.tr.mapping.map(E)
      }, D = s.handler({
        state: t,
        range: v,
        match: g,
        commands: a,
        chain: c,
        can: u,
        pasteEvent: o,
        dropEvent: l
      });
      d.push(D);
    });
  }), d.every((h) => h !== null);
}
var Ji = null, Ow = (n) => {
  var e;
  const t = new ClipboardEvent("paste", {
    clipboardData: new DataTransfer()
  });
  return (e = t.clipboardData) == null || e.setData("text/html", n), t;
};
function Nw(n) {
  const { editor: e, rules: t } = n;
  let r = null, i = !1, s = !1, o = typeof ClipboardEvent < "u" ? new ClipboardEvent("paste") : null, l;
  try {
    l = typeof DragEvent < "u" ? new DragEvent("drop") : null;
  } catch {
    l = null;
  }
  const a = ({
    state: u,
    from: d,
    to: f,
    rule: h,
    pasteEvt: p
  }) => {
    const m = u.tr, _ = ho({
      state: u,
      transaction: m
    });
    if (!(!$w({
      editor: e,
      state: _,
      from: Math.max(d - 1, 0),
      to: f.b - 1,
      rule: h,
      pasteEvent: p,
      dropEvent: l
    }) || !m.steps.length)) {
      try {
        l = typeof DragEvent < "u" ? new DragEvent("drop") : null;
      } catch {
        l = null;
      }
      return o = typeof ClipboardEvent < "u" ? new ClipboardEvent("paste") : null, m;
    }
  };
  return t.map((u) => new ae({
    // we register a global drag handler to track the current drag source element
    view(d) {
      const f = (p) => {
        var m;
        r = (m = d.dom.parentElement) != null && m.contains(p.target) ? d.dom.parentElement : null, r && (Ji = e);
      }, h = () => {
        Ji && (Ji = null);
      };
      return window.addEventListener("dragstart", f), window.addEventListener("dragend", h), {
        destroy() {
          window.removeEventListener("dragstart", f), window.removeEventListener("dragend", h);
        }
      };
    },
    props: {
      handleDOMEvents: {
        drop: (d, f) => {
          if (s = r === d.dom.parentElement, l = f, !s) {
            const h = Ji;
            h != null && h.isEditable && setTimeout(() => {
              const p = h.state.selection;
              p && h.commands.deleteRange({ from: p.from, to: p.to });
            }, 10);
          }
          return !1;
        },
        paste: (d, f) => {
          var h;
          const p = (h = f.clipboardData) == null ? void 0 : h.getData("text/html");
          return o = f, i = !!(p != null && p.includes("data-pm-slice")), !1;
        }
      }
    },
    appendTransaction: (d, f, h) => {
      const p = d[0], m = p.getMeta("uiEvent") === "paste" && !i, _ = p.getMeta("uiEvent") === "drop" && !s, b = p.getMeta("applyPasteRules"), y = !!b;
      if (!m && !_ && !y)
        return;
      if (y) {
        let { text: E } = b;
        typeof E == "string" ? E = E : E = Na(A.from(E), h.schema);
        const { from: v } = b, D = v + E.length, S = Ow(E);
        return a({
          rule: u,
          state: h,
          from: v,
          to: { b: D },
          pasteEvt: S
        });
      }
      const g = f.doc.content.findDiffStart(h.doc.content), w = f.doc.content.findDiffEnd(h.doc.content);
      if (!(!Tw(g) || !w || g === w.b))
        return a({
          rule: u,
          state: h,
          from: g,
          to: w,
          pasteEvt: o
        });
    }
  }));
}
var bo = class {
  constructor(n, e) {
    this.splittableMarks = [], this.editor = e, this.extensions = Ip(n), this.schema = pw(this.extensions, e), this.setupExtensions();
  }
  /**
   * Get all commands from the extensions.
   * @returns An object with all commands where the key is the command name and the value is the command function
   */
  get commands() {
    return this.extensions.reduce((n, e) => {
      const t = {
        name: e.name,
        options: e.options,
        storage: this.editor.extensionStorage[e.name],
        editor: this.editor,
        type: ll(e.name, this.schema)
      }, r = L(e, "addCommands", t);
      return r ? {
        ...n,
        ...r()
      } : n;
    }, {});
  }
  /**
   * Get all registered Prosemirror plugins from the extensions.
   * @returns An array of Prosemirror plugins
   */
  get plugins() {
    const { editor: n } = this, e = Ia([...this.extensions].reverse()), t = [], r = [], i = e.map((s) => {
      const o = {
        name: s.name,
        options: s.options,
        storage: this.editor.extensionStorage[s.name],
        editor: n,
        type: ll(s.name, this.schema)
      }, l = [], a = L(
        s,
        "addKeyboardShortcuts",
        o
      );
      let c = {};
      if (s.type === "mark" && L(s, "exitable", o) && (c.ArrowRight = () => Kn.handleExit({ editor: n, mark: s })), a) {
        const p = Object.fromEntries(
          Object.entries(a()).map(([m, _]) => [m, () => _({ editor: n })])
        );
        c = { ...c, ...p };
      }
      const u = zk(c);
      l.push(u);
      const d = L(s, "addInputRules", o);
      Od(s, n.options.enableInputRules) && d && t.push(...d());
      const f = L(s, "addPasteRules", o);
      Od(s, n.options.enablePasteRules) && f && r.push(...f());
      const h = L(
        s,
        "addProseMirrorPlugins",
        o
      );
      if (h) {
        const p = h();
        l.push(...p);
      }
      return l;
    }).flat();
    return [
      Aw({
        editor: n,
        rules: t
      }),
      ...Nw({
        editor: n,
        rules: r
      }),
      ...i
    ];
  }
  /**
   * Get all attributes from the extensions.
   * @returns An array of attributes
   */
  get attributes() {
    return Np(this.extensions);
  }
  /**
   * Get all node views from the extensions.
   * @returns An object with all node views where the key is the node name and the value is the node view function
   */
  get nodeViews() {
    const { editor: n } = this, { nodeExtensions: e } = hi(this.extensions);
    return Object.fromEntries(
      e.filter((t) => !!L(t, "addNodeView")).map((t) => {
        const r = this.attributes.filter((l) => l.type === t.name), i = {
          name: t.name,
          options: t.options,
          storage: this.editor.extensionStorage[t.name],
          editor: n,
          type: ge(t.name, this.schema)
        }, s = L(t, "addNodeView", i);
        if (!s)
          return [];
        const o = (l, a, c, u, d) => {
          const f = As(l, r);
          return s()({
            // pass-through
            node: l,
            view: a,
            getPos: c,
            decorations: u,
            innerDecorations: d,
            // tiptap-specific
            editor: n,
            extension: t,
            HTMLAttributes: f
          });
        };
        return [t.name, o];
      })
    );
  }
  get markViews() {
    const { editor: n } = this, { markExtensions: e } = hi(this.extensions);
    return Object.fromEntries(
      e.filter((t) => !!L(t, "addMarkView")).map((t) => {
        const r = this.attributes.filter((l) => l.type === t.name), i = {
          name: t.name,
          options: t.options,
          storage: this.editor.extensionStorage[t.name],
          editor: n,
          type: Qt(t.name, this.schema)
        }, s = L(t, "addMarkView", i);
        if (!s)
          return [];
        const o = (l, a, c) => {
          const u = As(l, r);
          return s()({
            // pass-through
            mark: l,
            view: a,
            inline: c,
            // tiptap-specific
            editor: n,
            extension: t,
            HTMLAttributes: u,
            updateAttributes: (d) => {
              Jv(l, n, d);
            }
          });
        };
        return [t.name, o];
      })
    );
  }
  /**
   * Go through all extensions, create extension storages & setup marks
   * & bind editor event listener.
   */
  setupExtensions() {
    const n = this.extensions;
    this.editor.extensionStorage = Object.fromEntries(
      n.map((e) => [e.name, e.storage])
    ), n.forEach((e) => {
      var t;
      const r = {
        name: e.name,
        options: e.options,
        storage: this.editor.extensionStorage[e.name],
        editor: this.editor,
        type: ll(e.name, this.schema)
      };
      e.type === "mark" && ((t = J(L(e, "keepOnSplit", r))) == null || t) && this.splittableMarks.push(e.name);
      const i = L(e, "onBeforeCreate", r), s = L(e, "onCreate", r), o = L(e, "onUpdate", r), l = L(
        e,
        "onSelectionUpdate",
        r
      ), a = L(e, "onTransaction", r), c = L(e, "onFocus", r), u = L(e, "onBlur", r), d = L(e, "onDestroy", r);
      i && this.editor.on("beforeCreate", i), s && this.editor.on("create", s), o && this.editor.on("update", o), l && this.editor.on("selectionUpdate", l), a && this.editor.on("transaction", a), c && this.editor.on("focus", c), u && this.editor.on("blur", u), d && this.editor.on("destroy", d);
    });
  }
};
bo.resolve = Ip;
bo.sort = Ia;
bo.flatten = Oa;
var Iw = {};
Mp(Iw, {
  ClipboardTextSerializer: () => Gp,
  Commands: () => Xp,
  Delete: () => Zp,
  Drop: () => Qp,
  Editable: () => em,
  FocusEvents: () => nm,
  Keymap: () => rm,
  Paste: () => im,
  Tabindex: () => sm,
  focusEventsPluginKey: () => tm
});
var he = class Kp extends Ba {
  constructor() {
    super(...arguments), this.type = "extension";
  }
  /**
   * Create a new Extension instance
   * @param config - Extension configuration object or a function that returns a configuration object
   */
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new Kp(t);
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
}, Gp = he.create({
  name: "clipboardTextSerializer",
  addOptions() {
    return {
      blockSeparator: void 0
    };
  },
  addProseMirrorPlugins() {
    return [
      new ae({
        key: new _e("clipboardTextSerializer"),
        props: {
          clipboardTextSerializer: () => {
            const { editor: n } = this, { state: e, schema: t } = n, { doc: r, selection: i } = e, { ranges: s } = i, o = Math.min(...s.map((u) => u.$from.pos)), l = Math.max(...s.map((u) => u.$to.pos)), a = Lp(t);
            return Rp(r, { from: o, to: l }, {
              ...this.options.blockSeparator !== void 0 ? { blockSeparator: this.options.blockSeparator } : {},
              textSerializers: a
            });
          }
        }
      })
    ];
  }
}), Jp = {};
Mp(Jp, {
  blur: () => Rw,
  clearContent: () => Lw,
  clearNodes: () => Pw,
  command: () => Bw,
  createParagraphNear: () => zw,
  cut: () => Hw,
  deleteCurrentNode: () => qw,
  deleteNode: () => Vw,
  deleteRange: () => Uw,
  deleteSelection: () => jw,
  enter: () => Ww,
  exitCode: () => Kw,
  extendMarkRange: () => Gw,
  first: () => Jw,
  focus: () => Xw,
  forEach: () => Zw,
  insertContent: () => Qw,
  insertContentAt: () => tv,
  joinBackward: () => iv,
  joinDown: () => rv,
  joinForward: () => sv,
  joinItemBackward: () => ov,
  joinItemForward: () => lv,
  joinTextblockBackward: () => av,
  joinTextblockForward: () => cv,
  joinUp: () => nv,
  keyboardShortcut: () => dv,
  lift: () => fv,
  liftEmptyBlock: () => hv,
  liftListItem: () => pv,
  newlineInCode: () => mv,
  resetAttributes: () => gv,
  scrollIntoView: () => _v,
  selectAll: () => yv,
  selectNodeBackward: () => bv,
  selectNodeForward: () => kv,
  selectParentNode: () => wv,
  selectTextblockEnd: () => vv,
  selectTextblockStart: () => Ev,
  setContent: () => Dv,
  setMark: () => Cv,
  setMeta: () => Av,
  setNode: () => xv,
  setNodeSelection: () => Tv,
  setTextSelection: () => Mv,
  sinkListItem: () => Fv,
  splitBlock: () => $v,
  splitListItem: () => Ov,
  toggleList: () => Nv,
  toggleMark: () => Iv,
  toggleNode: () => Rv,
  toggleWrap: () => Lv,
  undoInputRule: () => Pv,
  unsetAllMarks: () => Bv,
  unsetMark: () => zv,
  updateAttributes: () => Hv,
  wrapIn: () => qv,
  wrapInList: () => Vv
});
var Rw = () => ({ editor: n, view: e }) => (requestAnimationFrame(() => {
  var t;
  n.isDestroyed || (e.dom.blur(), (t = window == null ? void 0 : window.getSelection()) == null || t.removeAllRanges());
}), !0), Lw = (n = !0) => ({ commands: e }) => e.setContent("", { emitUpdate: n }), Pw = () => ({ state: n, tr: e, dispatch: t }) => {
  const { selection: r } = e, { ranges: i } = r;
  return t && i.forEach(({ $from: s, $to: o }) => {
    n.doc.nodesBetween(s.pos, o.pos, (l, a) => {
      if (l.type.isText)
        return;
      const { doc: c, mapping: u } = e, d = c.resolve(u.map(a)), f = c.resolve(u.map(a + l.nodeSize)), h = d.blockRange(f);
      if (!h)
        return;
      const p = Er(h);
      if (l.type.isTextblock) {
        const { defaultType: m } = d.parent.contentMatchAt(d.index());
        e.setNodeMarkup(h.start, m);
      }
      (p || p === 0) && e.lift(h, p);
    });
  }), !0;
}, Bw = (n) => (e) => n(e), zw = () => ({ state: n, dispatch: e }) => Cp(n, e), Hw = (n, e) => ({ editor: t, tr: r }) => {
  const { state: i } = t, s = i.doc.slice(n.from, n.to);
  r.deleteRange(n.from, n.to);
  const o = r.mapping.map(e);
  return r.insert(o, s.content), r.setSelection(new z(r.doc.resolve(Math.max(o - 1, 0)))), !0;
}, qw = () => ({ tr: n, dispatch: e }) => {
  const { selection: t } = n, r = t.$anchor.node();
  if (r.content.size > 0)
    return !1;
  const i = n.selection.$anchor;
  for (let s = i.depth; s > 0; s -= 1)
    if (i.node(s).type === r.type) {
      if (e) {
        const l = i.before(s), a = i.after(s);
        n.delete(l, a).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, Vw = (n) => ({ tr: e, state: t, dispatch: r }) => {
  const i = ge(n, t.schema), s = e.selection.$anchor;
  for (let o = s.depth; o > 0; o -= 1)
    if (s.node(o).type === i) {
      if (r) {
        const a = s.before(o), c = s.after(o);
        e.delete(a, c).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, Uw = (n) => ({ tr: e, dispatch: t }) => {
  const { from: r, to: i } = n;
  return t && e.delete(r, i), !0;
}, jw = () => ({ state: n, dispatch: e }) => xa(n, e), Ww = () => ({ commands: n }) => n.keyboardShortcut("Enter"), Kw = () => ({ state: n, dispatch: e }) => Wk(n, e), Gw = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  const s = Qt(n, r.schema), { doc: o, selection: l } = t, { $from: a, from: c, to: u } = l;
  if (i) {
    const d = La(a, s, e);
    if (d && d.from <= c && d.to >= u) {
      const f = z.create(o, d.from, d.to);
      t.setSelection(f);
    }
  }
  return !0;
}, Jw = (n) => (e) => {
  const t = typeof n == "function" ? n(e) : n;
  for (let r = 0; r < t.length; r += 1)
    if (t[r](e))
      return !0;
  return !1;
};
function Yw() {
  return navigator.platform === "Android" || /android/i.test(navigator.userAgent);
}
function za() {
  return ["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"].includes(navigator.platform) || // iPad on iOS 13 detection
  navigator.userAgent.includes("Mac") && "ontouchend" in document;
}
var Xw = (n = null, e = {}) => ({ editor: t, view: r, tr: i, dispatch: s }) => {
  e = {
    scrollIntoView: !0,
    ...e
  };
  const o = () => {
    (za() || Yw()) && r.dom.focus(), requestAnimationFrame(() => {
      t.isDestroyed || (r.focus(), e != null && e.scrollIntoView && t.commands.scrollIntoView());
    });
  };
  if (r.hasFocus() && n === null || n === !1)
    return !0;
  if (s && n === null && !Vp(t.state.selection))
    return o(), !0;
  const l = Up(i.doc, n) || t.state.selection, a = t.state.selection.eq(l);
  return s && (a || i.setSelection(l), a && i.storedMarks && i.setStoredMarks(i.storedMarks), o()), !0;
}, Zw = (n, e) => (t) => n.every((r, i) => e(r, { ...t, index: i })), Qw = (n, e) => ({ tr: t, commands: r }) => r.insertContentAt({ from: t.selection.from, to: t.selection.to }, n, e), ev = (n) => !("type" in n), tv = (n, e, t) => ({ tr: r, dispatch: i, editor: s }) => {
  var o;
  if (i) {
    t = {
      parseOptions: s.options.parseOptions,
      updateSelection: !0,
      applyInputRules: !1,
      applyPasteRules: !1,
      ...t
    };
    let l;
    const { selection: a } = s.state, c = (b) => {
      s.emit("contentError", {
        editor: s,
        error: b,
        disableCollaboration: () => {
          "collaboration" in s.storage && typeof s.storage.collaboration == "object" && s.storage.collaboration && (s.storage.collaboration.isDisabled = !0);
        }
      });
    }, u = {
      preserveWhitespace: "full",
      ...t.parseOptions
    };
    if (!t.errorOnInvalidContent && !s.options.enableContentCheck && s.options.emitContentError)
      try {
        fi(e, s.schema, {
          parseOptions: u,
          errorOnInvalidContent: !0
        });
      } catch (b) {
        c(b);
      }
    try {
      l = fi(e, s.schema, {
        parseOptions: u,
        errorOnInvalidContent: (o = t.errorOnInvalidContent) != null ? o : s.options.enableContentCheck
      });
    } catch (b) {
      return c(b), !1;
    }
    let { from: d, to: f } = typeof n == "number" ? { from: n, to: n } : { from: n.from, to: n.to }, h = !0, p = !0;
    if ((ev(l) ? l : [l]).forEach((b) => {
      b.check(), h = h ? b.isText && b.marks.length === 0 : !1, p = p ? b.isBlock : !1;
    }), d === f && p) {
      const { parent: b } = r.doc.resolve(d);
      b.isTextblock && !b.type.spec.code && !b.childCount && (d -= 1, f += 1);
    }
    let _;
    if (h) {
      if (Array.isArray(e))
        _ = e.map((b) => b.text || "").join("");
      else if (e instanceof A) {
        let b = "";
        e.forEach((y) => {
          y.text && (b += y.text);
        }), _ = b;
      } else typeof e == "object" && e && e.text ? _ = e.text : _ = e;
      r.insertText(_, d, f);
    } else {
      _ = l;
      const b = a.$from.parentOffset === 0, y = a.$from.node().isText || a.$from.node().isTextblock, g = a.$from.node().content.size > 0;
      b && y && g && (d = Math.max(0, d - 1)), r.replaceWith(d, f, _);
    }
    t.updateSelection && Sw(r, r.steps.length - 1, -1), t.applyInputRules && r.setMeta("applyInputRules", { from: d, text: _ }), t.applyPasteRules && r.setMeta("applyPasteRules", { from: d, text: _ });
  }
  return !0;
}, nv = () => ({ state: n, dispatch: e }) => Vk(n, e), rv = () => ({ state: n, dispatch: e }) => Uk(n, e), iv = () => ({ state: n, dispatch: e }) => bp(n, e), sv = () => ({ state: n, dispatch: e }) => Ep(n, e), ov = () => ({ state: n, dispatch: e, tr: t }) => {
  try {
    const r = oo(n.doc, n.selection.$from.pos, -1);
    return r == null ? !1 : (t.join(r, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, lv = () => ({ state: n, dispatch: e, tr: t }) => {
  try {
    const r = oo(n.doc, n.selection.$from.pos, 1);
    return r == null ? !1 : (t.join(r, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, av = () => ({ state: n, dispatch: e }) => Hk(n, e), cv = () => ({ state: n, dispatch: e }) => qk(n, e);
function Yp() {
  return typeof navigator < "u" ? /Mac/.test(navigator.platform) : !1;
}
function uv(n) {
  const e = n.split(/-(?!$)/);
  let t = e[e.length - 1];
  t === "Space" && (t = " ");
  let r, i, s, o;
  for (let l = 0; l < e.length - 1; l += 1) {
    const a = e[l];
    if (/^(cmd|meta|m)$/i.test(a))
      o = !0;
    else if (/^a(lt)?$/i.test(a))
      r = !0;
    else if (/^(c|ctrl|control)$/i.test(a))
      i = !0;
    else if (/^s(hift)?$/i.test(a))
      s = !0;
    else if (/^mod$/i.test(a))
      za() || Yp() ? o = !0 : i = !0;
    else
      throw new Error(`Unrecognized modifier name: ${a}`);
  }
  return r && (t = `Alt-${t}`), i && (t = `Ctrl-${t}`), o && (t = `Meta-${t}`), s && (t = `Shift-${t}`), t;
}
var dv = (n) => ({ editor: e, view: t, tr: r, dispatch: i }) => {
  const s = uv(n).split(/-(?!$)/), o = s.find((c) => !["Alt", "Ctrl", "Meta", "Shift"].includes(c)), l = new KeyboardEvent("keydown", {
    key: o === "Space" ? " " : o,
    altKey: s.includes("Alt"),
    ctrlKey: s.includes("Ctrl"),
    metaKey: s.includes("Meta"),
    shiftKey: s.includes("Shift"),
    bubbles: !0,
    cancelable: !0
  }), a = e.captureTransaction(() => {
    t.someProp("handleKeyDown", (c) => c(t, l));
  });
  return a == null || a.steps.forEach((c) => {
    const u = c.map(r.mapping);
    u && i && r.maybeStep(u);
  }), !0;
}, fv = (n, e = {}) => ({ state: t, dispatch: r }) => {
  const i = ge(n, t.schema);
  return kn(t, i, e) ? jk(t, r) : !1;
}, hv = () => ({ state: n, dispatch: e }) => Ap(n, e), pv = (n) => ({ state: e, dispatch: t }) => {
  const r = ge(n, e.schema);
  return rw(r)(e, t);
}, mv = () => ({ state: n, dispatch: e }) => Sp(n, e);
function Id(n, e) {
  const t = typeof e == "string" ? [e] : e;
  return Object.keys(n).reduce((r, i) => (t.includes(i) || (r[i] = n[i]), r), {});
}
var gv = (n, e) => ({ tr: t, state: r, dispatch: i }) => {
  let s = null, o = null;
  const l = go(
    typeof n == "string" ? n : n.name,
    r.schema
  );
  return l ? (l === "node" && (s = ge(n, r.schema)), l === "mark" && (o = Qt(n, r.schema)), i && t.selection.ranges.forEach((a) => {
    r.doc.nodesBetween(a.$from.pos, a.$to.pos, (c, u) => {
      s && s === c.type && t.setNodeMarkup(u, void 0, Id(c.attrs, e)), o && c.marks.length && c.marks.forEach((d) => {
        o === d.type && t.addMark(u, u + c.nodeSize, o.create(Id(d.attrs, e)));
      });
    });
  }), !0) : !1;
}, _v = () => ({ tr: n, dispatch: e }) => (e && n.scrollIntoView(), !0), yv = () => ({ tr: n, dispatch: e }) => {
  if (e) {
    const t = new Qe(n.doc);
    n.setSelection(t);
  }
  return !0;
}, bv = () => ({ state: n, dispatch: e }) => wp(n, e), kv = () => ({ state: n, dispatch: e }) => Dp(n, e), wv = () => ({ state: n, dispatch: e }) => Jk(n, e), vv = () => ({ state: n, dispatch: e }) => Zk(n, e), Ev = () => ({ state: n, dispatch: e }) => Xk(n, e), Dv = (n, { errorOnInvalidContent: e, emitUpdate: t = !0, parseOptions: r = {} } = {}) => ({ editor: i, tr: s, dispatch: o, commands: l }) => {
  const { doc: a } = s;
  if (r.preserveWhitespace !== "full") {
    const c = Kl(n, i.schema, r, {
      errorOnInvalidContent: e ?? i.options.enableContentCheck
    });
    return o && s.replaceWith(0, a.content.size, c).setMeta("preventUpdate", !t), !0;
  }
  return o && s.setMeta("preventUpdate", !t), l.insertContentAt({ from: 0, to: a.content.size }, n, {
    parseOptions: r,
    errorOnInvalidContent: e ?? i.options.enableContentCheck
  });
};
function Sv(n, e, t) {
  var r;
  const { selection: i } = e;
  let s = null;
  if (Vp(i) && (s = i.$cursor), s) {
    const l = (r = n.storedMarks) != null ? r : s.marks();
    return !!t.isInSet(l) || !l.some((a) => a.type.excludes(t));
  }
  const { ranges: o } = i;
  return o.some(({ $from: l, $to: a }) => {
    let c = l.depth === 0 ? n.doc.inlineContent && n.doc.type.allowsMarkType(t) : !1;
    return n.doc.nodesBetween(l.pos, a.pos, (u, d, f) => {
      if (c)
        return !1;
      if (u.isInline) {
        const h = !f || f.type.allowsMarkType(t), p = !!t.isInSet(u.marks) || !u.marks.some((m) => m.type.excludes(t));
        c = h && p;
      }
      return !c;
    }), c;
  });
}
var Cv = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  const { selection: s } = t, { empty: o, ranges: l } = s, a = Qt(n, r.schema);
  if (i)
    if (o) {
      const c = Pp(r, a);
      t.addStoredMark(
        a.create({
          ...c,
          ...e
        })
      );
    } else
      l.forEach((c) => {
        const u = c.$from.pos, d = c.$to.pos;
        r.doc.nodesBetween(u, d, (f, h) => {
          const p = Math.max(h, u), m = Math.min(h + f.nodeSize, d);
          f.marks.find((b) => b.type === a) ? f.marks.forEach((b) => {
            a === b.type && t.addMark(
              p,
              m,
              a.create({
                ...b.attrs,
                ...e
              })
            );
          }) : t.addMark(p, m, a.create(e));
        });
      });
  return Sv(r, t, a);
}, Av = (n, e) => ({ tr: t }) => (t.setMeta(n, e), !0), xv = (n, e = {}) => ({ state: t, dispatch: r, chain: i }) => {
  const s = ge(n, t.schema);
  let o;
  return t.selection.$anchor.sameParent(t.selection.$head) && (o = t.selection.$anchor.parent.attrs), s.isTextblock ? i().command(({ commands: l }) => Td(s, { ...o, ...e })(t) ? !0 : l.clearNodes()).command(({ state: l }) => Td(s, { ...o, ...e })(l, r)).run() : (console.warn('[tiptap warn]: Currently "setNode()" only supports text block nodes.'), !1);
}, Tv = (n) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: r } = e, i = Fn(n, 0, r.content.size), s = B.create(r, i);
    e.setSelection(s);
  }
  return !0;
}, Mv = (n) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: r } = e, { from: i, to: s } = typeof n == "number" ? { from: n, to: n } : n, o = z.atStart(r).from, l = z.atEnd(r).to, a = Fn(i, o, l), c = Fn(s, o, l), u = z.create(r, a, c);
    e.setSelection(u);
  }
  return !0;
}, Fv = (n) => ({ state: e, dispatch: t }) => {
  const r = ge(n, e.schema);
  return ow(r)(e, t);
};
function Rd(n, e) {
  const t = n.storedMarks || n.selection.$to.parentOffset && n.selection.$from.marks();
  if (t) {
    const r = t.filter((i) => e == null ? void 0 : e.includes(i.type.name));
    n.tr.ensureMarks(r);
  }
}
var $v = ({ keepMarks: n = !0 } = {}) => ({ tr: e, state: t, dispatch: r, editor: i }) => {
  const { selection: s, doc: o } = e, { $from: l, $to: a } = s, c = i.extensionManager.attributes, u = cs(c, l.node().type.name, l.node().attrs);
  if (s instanceof B && s.node.isBlock)
    return !l.parentOffset || !Xt(o, l.pos) ? !1 : (r && (n && Rd(t, i.extensionManager.splittableMarks), e.split(l.pos).scrollIntoView()), !0);
  if (!l.parent.isBlock)
    return !1;
  const d = a.parentOffset === a.parent.content.size, f = l.depth === 0 ? void 0 : cw(l.node(-1).contentMatchAt(l.indexAfter(-1)));
  let h = d && f ? [
    {
      type: f,
      attrs: u
    }
  ] : void 0, p = Xt(e.doc, e.mapping.map(l.pos), 1, h);
  if (!h && !p && Xt(e.doc, e.mapping.map(l.pos), 1, f ? [{ type: f }] : void 0) && (p = !0, h = f ? [
    {
      type: f,
      attrs: u
    }
  ] : void 0), r) {
    if (p && (s instanceof z && e.deleteSelection(), e.split(e.mapping.map(l.pos), 1, h), f && !d && !l.parentOffset && l.parent.type !== f)) {
      const m = e.mapping.map(l.before()), _ = e.doc.resolve(m);
      l.node(-1).canReplaceWith(_.index(), _.index() + 1, f) && e.setNodeMarkup(e.mapping.map(l.before()), f);
    }
    n && Rd(t, i.extensionManager.splittableMarks), e.scrollIntoView();
  }
  return p;
}, Ov = (n, e = {}) => ({ tr: t, state: r, dispatch: i, editor: s }) => {
  var o;
  const l = ge(n, r.schema), { $from: a, $to: c } = r.selection, u = r.selection.node;
  if (u && u.isBlock || a.depth < 2 || !a.sameParent(c))
    return !1;
  const d = a.node(-1);
  if (d.type !== l)
    return !1;
  const f = s.extensionManager.attributes;
  if (a.parent.content.size === 0 && a.node(-1).childCount === a.indexAfter(-1)) {
    if (a.depth === 2 || a.node(-3).type !== l || a.index(-2) !== a.node(-2).childCount - 1)
      return !1;
    if (i) {
      let b = A.empty;
      const y = a.index(-1) ? 1 : a.index(-2) ? 2 : 3;
      for (let S = a.depth - y; S >= a.depth - 3; S -= 1)
        b = A.from(a.node(S).copy(b));
      const g = (
        // eslint-disable-next-line no-nested-ternary
        a.indexAfter(-1) < a.node(-2).childCount ? 1 : a.indexAfter(-2) < a.node(-3).childCount ? 2 : 3
      ), w = {
        ...cs(f, a.node().type.name, a.node().attrs),
        ...e
      }, E = ((o = l.contentMatch.defaultType) == null ? void 0 : o.createAndFill(w)) || void 0;
      b = b.append(A.from(l.createAndFill(null, E) || void 0));
      const v = a.before(a.depth - (y - 1));
      t.replace(v, a.after(-g), new O(b, 4 - y, 0));
      let D = -1;
      t.doc.nodesBetween(v, t.doc.content.size, (S, C) => {
        if (D > -1)
          return !1;
        S.isTextblock && S.content.size === 0 && (D = C + 1);
      }), D > -1 && t.setSelection(z.near(t.doc.resolve(D))), t.scrollIntoView();
    }
    return !0;
  }
  const h = c.pos === a.end() ? d.contentMatchAt(0).defaultType : null, p = {
    ...cs(f, d.type.name, d.attrs),
    ...e
  }, m = {
    ...cs(f, a.node().type.name, a.node().attrs),
    ...e
  };
  t.delete(a.pos, c.pos);
  const _ = h ? [
    { type: l, attrs: p },
    { type: h, attrs: m }
  ] : [{ type: l, attrs: p }];
  if (!Xt(t.doc, a.pos, 2))
    return !1;
  if (i) {
    const { selection: b, storedMarks: y } = r, { splittableMarks: g } = s.extensionManager, w = y || b.$to.parentOffset && b.$from.marks();
    if (t.split(a.pos, 2, _).scrollIntoView(), !w || !i)
      return !0;
    const E = w.filter((v) => g.includes(v.type.name));
    t.ensureMarks(E);
  }
  return !0;
}, al = (n, e) => {
  const t = mo((o) => o.type === e)(n.selection);
  if (!t)
    return !0;
  const r = n.doc.resolve(Math.max(0, t.pos - 1)).before(t.depth);
  if (r === void 0)
    return !0;
  const i = n.doc.nodeAt(r);
  return t.node.type === (i == null ? void 0 : i.type) && wn(n.doc, t.pos) && n.join(t.pos), !0;
}, cl = (n, e) => {
  const t = mo((o) => o.type === e)(n.selection);
  if (!t)
    return !0;
  const r = n.doc.resolve(t.start).after(t.depth);
  if (r === void 0)
    return !0;
  const i = n.doc.nodeAt(r);
  return t.node.type === (i == null ? void 0 : i.type) && wn(n.doc, r) && n.join(r), !0;
}, Nv = (n, e, t, r = {}) => ({ editor: i, tr: s, state: o, dispatch: l, chain: a, commands: c, can: u }) => {
  const { extensions: d, splittableMarks: f } = i.extensionManager, h = ge(n, o.schema), p = ge(e, o.schema), { selection: m, storedMarks: _ } = o, { $from: b, $to: y } = m, g = b.blockRange(y), w = _ || m.$to.parentOffset && m.$from.marks();
  if (!g)
    return !1;
  const E = mo((v) => Nd(v.type.name, d))(m);
  if (g.depth >= 1 && E && g.depth - E.depth <= 1) {
    if (E.node.type === h)
      return c.liftListItem(p);
    if (Nd(E.node.type.name, d) && h.validContent(E.node.content) && l)
      return a().command(() => (s.setNodeMarkup(E.pos, h), !0)).command(() => al(s, h)).command(() => cl(s, h)).run();
  }
  return !t || !w || !l ? a().command(() => u().wrapInList(h, r) ? !0 : c.clearNodes()).wrapInList(h, r).command(() => al(s, h)).command(() => cl(s, h)).run() : a().command(() => {
    const v = u().wrapInList(h, r), D = w.filter((S) => f.includes(S.type.name));
    return s.ensureMarks(D), v ? !0 : c.clearNodes();
  }).wrapInList(h, r).command(() => al(s, h)).command(() => cl(s, h)).run();
}, Iv = (n, e = {}, t = {}) => ({ state: r, commands: i }) => {
  const { extendEmptyMarkRange: s = !1 } = t, o = Qt(n, r.schema);
  return Gl(r, o, e) ? i.unsetMark(o, { extendEmptyMarkRange: s }) : i.setMark(o, e);
}, Rv = (n, e, t = {}) => ({ state: r, commands: i }) => {
  const s = ge(n, r.schema), o = ge(e, r.schema), l = kn(r, s, t);
  let a;
  return r.selection.$anchor.sameParent(r.selection.$head) && (a = r.selection.$anchor.parent.attrs), l ? i.setNode(o, a) : i.setNode(s, { ...a, ...t });
}, Lv = (n, e = {}) => ({ state: t, commands: r }) => {
  const i = ge(n, t.schema);
  return kn(t, i, e) ? r.lift(i) : r.wrapIn(i, e);
}, Pv = () => ({ state: n, dispatch: e }) => {
  const t = n.plugins;
  for (let r = 0; r < t.length; r += 1) {
    const i = t[r];
    let s;
    if (i.spec.isInputRules && (s = i.getState(n))) {
      if (e) {
        const o = n.tr, l = s.transform;
        for (let a = l.steps.length - 1; a >= 0; a -= 1)
          o.step(l.steps[a].invert(l.docs[a]));
        if (s.text) {
          const a = o.doc.resolve(s.from).marks();
          o.replaceWith(s.from, s.to, n.schema.text(s.text, a));
        } else
          o.delete(s.from, s.to);
      }
      return !0;
    }
  }
  return !1;
}, Bv = () => ({ tr: n, dispatch: e }) => {
  const { selection: t } = n, { empty: r, ranges: i } = t;
  return r || e && i.forEach((s) => {
    n.removeMark(s.$from.pos, s.$to.pos);
  }), !0;
}, zv = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  var s;
  const { extendEmptyMarkRange: o = !1 } = e, { selection: l } = t, a = Qt(n, r.schema), { $from: c, empty: u, ranges: d } = l;
  if (!i)
    return !0;
  if (u && o) {
    let { from: f, to: h } = l;
    const p = (s = c.marks().find((_) => _.type === a)) == null ? void 0 : s.attrs, m = La(c, a, p);
    m && (f = m.from, h = m.to), t.removeMark(f, h, a);
  } else
    d.forEach((f) => {
      t.removeMark(f.$from.pos, f.$to.pos, a);
    });
  return t.removeStoredMark(a), !0;
}, Hv = (n, e = {}) => ({ tr: t, state: r, dispatch: i }) => {
  let s = null, o = null;
  const l = go(
    typeof n == "string" ? n : n.name,
    r.schema
  );
  return l ? (l === "node" && (s = ge(n, r.schema)), l === "mark" && (o = Qt(n, r.schema)), i && t.selection.ranges.forEach((a) => {
    const c = a.$from.pos, u = a.$to.pos;
    let d, f, h, p;
    t.selection.empty ? r.doc.nodesBetween(c, u, (m, _) => {
      s && s === m.type && (h = Math.max(_, c), p = Math.min(_ + m.nodeSize, u), d = _, f = m);
    }) : r.doc.nodesBetween(c, u, (m, _) => {
      _ < c && s && s === m.type && (h = Math.max(_, c), p = Math.min(_ + m.nodeSize, u), d = _, f = m), _ >= c && _ <= u && (s && s === m.type && t.setNodeMarkup(_, void 0, {
        ...m.attrs,
        ...e
      }), o && m.marks.length && m.marks.forEach((b) => {
        if (o === b.type) {
          const y = Math.max(_, c), g = Math.min(_ + m.nodeSize, u);
          t.addMark(
            y,
            g,
            o.create({
              ...b.attrs,
              ...e
            })
          );
        }
      }));
    }), f && (d !== void 0 && t.setNodeMarkup(d, void 0, {
      ...f.attrs,
      ...e
    }), o && f.marks.length && f.marks.forEach((m) => {
      o === m.type && t.addMark(
        h,
        p,
        o.create({
          ...m.attrs,
          ...e
        })
      );
    }));
  }), !0) : !1;
}, qv = (n, e = {}) => ({ state: t, dispatch: r }) => {
  const i = ge(n, t.schema);
  return Qk(i, e)(t, r);
}, Vv = (n, e = {}) => ({ state: t, dispatch: r }) => {
  const i = ge(n, t.schema);
  return ew(i, e)(t, r);
}, Xp = he.create({
  name: "commands",
  addCommands() {
    return {
      ...Jp
    };
  }
}), Zp = he.create({
  name: "delete",
  onUpdate({ transaction: n, appendedTransactions: e }) {
    var t, r, i;
    const s = () => {
      var o, l, a, c;
      if ((c = (a = (l = (o = this.editor.options.coreExtensionOptions) == null ? void 0 : o.delete) == null ? void 0 : l.filterTransaction) == null ? void 0 : a.call(l, n)) != null ? c : n.getMeta("y-sync$"))
        return;
      const u = Fp(n.before, [n, ...e]);
      zp(u).forEach((h) => {
        u.mapping.mapResult(h.oldRange.from).deletedAfter && u.mapping.mapResult(h.oldRange.to).deletedBefore && u.before.nodesBetween(h.oldRange.from, h.oldRange.to, (p, m) => {
          const _ = m + p.nodeSize - 2, b = h.oldRange.from <= m && _ <= h.oldRange.to;
          this.editor.emit("delete", {
            type: "node",
            node: p,
            from: m,
            to: _,
            newFrom: u.mapping.map(m),
            newTo: u.mapping.map(_),
            deletedRange: h.oldRange,
            newRange: h.newRange,
            partial: !b,
            editor: this.editor,
            transaction: n,
            combinedTransform: u
          });
        });
      });
      const f = u.mapping;
      u.steps.forEach((h, p) => {
        var m, _;
        if (h instanceof vt) {
          const b = f.slice(p).map(h.from, -1), y = f.slice(p).map(h.to), g = f.invert().map(b, -1), w = f.invert().map(y), E = (m = u.doc.nodeAt(b - 1)) == null ? void 0 : m.marks.some((D) => D.eq(h.mark)), v = (_ = u.doc.nodeAt(y)) == null ? void 0 : _.marks.some((D) => D.eq(h.mark));
          this.editor.emit("delete", {
            type: "mark",
            mark: h.mark,
            from: h.from,
            to: h.to,
            deletedRange: {
              from: g,
              to: w
            },
            newRange: {
              from: b,
              to: y
            },
            partial: !!(v || E),
            editor: this.editor,
            transaction: n,
            combinedTransform: u
          });
        }
      });
    };
    (i = (r = (t = this.editor.options.coreExtensionOptions) == null ? void 0 : t.delete) == null ? void 0 : r.async) == null || i ? setTimeout(s, 0) : s();
  }
}), Qp = he.create({
  name: "drop",
  addProseMirrorPlugins() {
    return [
      new ae({
        key: new _e("tiptapDrop"),
        props: {
          handleDrop: (n, e, t, r) => {
            this.editor.emit("drop", {
              editor: this.editor,
              event: e,
              slice: t,
              moved: r
            });
          }
        }
      })
    ];
  }
}), em = he.create({
  name: "editable",
  addProseMirrorPlugins() {
    return [
      new ae({
        key: new _e("editable"),
        props: {
          editable: () => this.editor.options.editable
        }
      })
    ];
  }
}), tm = new _e("focusEvents"), nm = he.create({
  name: "focusEvents",
  addProseMirrorPlugins() {
    const { editor: n } = this;
    return [
      new ae({
        key: tm,
        props: {
          handleDOMEvents: {
            focus: (e, t) => {
              n.isFocused = !0;
              const r = n.state.tr.setMeta("focus", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(r), !1;
            },
            blur: (e, t) => {
              n.isFocused = !1;
              const r = n.state.tr.setMeta("blur", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(r), !1;
            }
          }
        }
      })
    ];
  }
}), rm = he.create({
  name: "keymap",
  addKeyboardShortcuts() {
    const n = () => this.editor.commands.first(({ commands: o }) => [
      () => o.undoInputRule(),
      // maybe convert first text block node to default node
      () => o.command(({ tr: l }) => {
        const { selection: a, doc: c } = l, { empty: u, $anchor: d } = a, { pos: f, parent: h } = d, p = d.parent.isTextblock && f > 0 ? l.doc.resolve(f - 1) : d, m = p.parent.type.spec.isolating, _ = d.pos - d.parentOffset, b = m && p.parent.childCount === 1 ? _ === d.pos : V.atStart(c).from === f;
        return !u || !h.type.isTextblock || h.textContent.length || !b || b && d.parent.type.name === "paragraph" ? !1 : o.clearNodes();
      }),
      () => o.deleteSelection(),
      () => o.joinBackward(),
      () => o.selectNodeBackward()
    ]), e = () => this.editor.commands.first(({ commands: o }) => [
      () => o.deleteSelection(),
      () => o.deleteCurrentNode(),
      () => o.joinForward(),
      () => o.selectNodeForward()
    ]), r = {
      Enter: () => this.editor.commands.first(({ commands: o }) => [
        () => o.newlineInCode(),
        () => o.createParagraphNear(),
        () => o.liftEmptyBlock(),
        () => o.splitBlock()
      ]),
      "Mod-Enter": () => this.editor.commands.exitCode(),
      Backspace: n,
      "Mod-Backspace": n,
      "Shift-Backspace": n,
      Delete: e,
      "Mod-Delete": e,
      "Mod-a": () => this.editor.commands.selectAll()
    }, i = {
      ...r
    }, s = {
      ...r,
      "Ctrl-h": n,
      "Alt-Backspace": n,
      "Ctrl-d": e,
      "Ctrl-Alt-Backspace": e,
      "Alt-Delete": e,
      "Alt-d": e,
      "Ctrl-a": () => this.editor.commands.selectTextblockStart(),
      "Ctrl-e": () => this.editor.commands.selectTextblockEnd()
    };
    return za() || Yp() ? s : i;
  },
  addProseMirrorPlugins() {
    return [
      // With this plugin we check if the whole document was selected and deleted.
      // In this case we will additionally call `clearNodes()` to convert e.g. a heading
      // to a paragraph if necessary.
      // This is an alternative to ProseMirror's `AllSelection`, which doesn’t work well
      // with many other commands.
      new ae({
        key: new _e("clearDocument"),
        appendTransaction: (n, e, t) => {
          if (n.some((m) => m.getMeta("composition")))
            return;
          const r = n.some((m) => m.docChanged) && !e.doc.eq(t.doc), i = n.some((m) => m.getMeta("preventClearDocument"));
          if (!r || i)
            return;
          const { empty: s, from: o, to: l } = e.selection, a = V.atStart(e.doc).from, c = V.atEnd(e.doc).to;
          if (s || !(o === a && l === c) || !_o(t.doc))
            return;
          const f = t.tr, h = ho({
            state: t,
            transaction: f
          }), { commands: p } = new po({
            editor: this.editor,
            state: h
          });
          if (p.clearNodes(), !!f.steps.length)
            return f;
        }
      })
    ];
  }
}), im = he.create({
  name: "paste",
  addProseMirrorPlugins() {
    return [
      new ae({
        key: new _e("tiptapPaste"),
        props: {
          handlePaste: (n, e, t) => {
            this.editor.emit("paste", {
              editor: this.editor,
              event: e,
              slice: t
            });
          }
        }
      })
    ];
  }
}), sm = he.create({
  name: "tabindex",
  addProseMirrorPlugins() {
    return [
      new ae({
        key: new _e("tabindex"),
        props: {
          attributes: () => this.editor.isEditable ? { tabindex: "0" } : {}
        }
      })
    ];
  }
}), Uv = class cr {
  constructor(e, t, r = !1, i = null) {
    this.currentNode = null, this.actualDepth = null, this.isBlock = r, this.resolvedPos = e, this.editor = t, this.currentNode = i;
  }
  get name() {
    return this.node.type.name;
  }
  get node() {
    return this.currentNode || this.resolvedPos.node();
  }
  get element() {
    return this.editor.view.domAtPos(this.pos).node;
  }
  get depth() {
    var e;
    return (e = this.actualDepth) != null ? e : this.resolvedPos.depth;
  }
  get pos() {
    return this.resolvedPos.pos;
  }
  get content() {
    return this.node.content;
  }
  set content(e) {
    let t = this.from, r = this.to;
    if (this.isBlock) {
      if (this.content.size === 0) {
        console.error(`You can’t set content on a block node. Tried to set content on ${this.name} at ${this.pos}`);
        return;
      }
      t = this.from + 1, r = this.to - 1;
    }
    this.editor.commands.insertContentAt({ from: t, to: r }, e);
  }
  get attributes() {
    return this.node.attrs;
  }
  get textContent() {
    return this.node.textContent;
  }
  get size() {
    return this.node.nodeSize;
  }
  get from() {
    return this.isBlock ? this.pos : this.resolvedPos.start(this.resolvedPos.depth);
  }
  get range() {
    return {
      from: this.from,
      to: this.to
    };
  }
  get to() {
    return this.isBlock ? this.pos + this.size : this.resolvedPos.end(this.resolvedPos.depth) + (this.node.isText ? 0 : 1);
  }
  get parent() {
    if (this.depth === 0)
      return null;
    const e = this.resolvedPos.start(this.resolvedPos.depth - 1), t = this.resolvedPos.doc.resolve(e);
    return new cr(t, this.editor);
  }
  get before() {
    let e = this.resolvedPos.doc.resolve(this.from - (this.isBlock ? 1 : 2));
    return e.depth !== this.depth && (e = this.resolvedPos.doc.resolve(this.from - 3)), new cr(e, this.editor);
  }
  get after() {
    let e = this.resolvedPos.doc.resolve(this.to + (this.isBlock ? 2 : 1));
    return e.depth !== this.depth && (e = this.resolvedPos.doc.resolve(this.to + 3)), new cr(e, this.editor);
  }
  get children() {
    const e = [];
    return this.node.content.forEach((t, r) => {
      const i = t.isBlock && !t.isTextblock, s = t.isAtom && !t.isText, o = this.pos + r + (s ? 0 : 1);
      if (o < 0 || o > this.resolvedPos.doc.nodeSize - 2)
        return;
      const l = this.resolvedPos.doc.resolve(o);
      if (!i && l.depth <= this.depth)
        return;
      const a = new cr(l, this.editor, i, i ? t : null);
      i && (a.actualDepth = this.depth + 1), e.push(new cr(l, this.editor, i, i ? t : null));
    }), e;
  }
  get firstChild() {
    return this.children[0] || null;
  }
  get lastChild() {
    const e = this.children;
    return e[e.length - 1] || null;
  }
  closest(e, t = {}) {
    let r = null, i = this.parent;
    for (; i && !r; ) {
      if (i.node.type.name === e)
        if (Object.keys(t).length > 0) {
          const s = i.node.attrs, o = Object.keys(t);
          for (let l = 0; l < o.length; l += 1) {
            const a = o[l];
            if (s[a] !== t[a])
              break;
          }
        } else
          r = i;
      i = i.parent;
    }
    return r;
  }
  querySelector(e, t = {}) {
    return this.querySelectorAll(e, t, !0)[0] || null;
  }
  querySelectorAll(e, t = {}, r = !1) {
    let i = [];
    if (!this.children || this.children.length === 0)
      return i;
    const s = Object.keys(t);
    return this.children.forEach((o) => {
      r && i.length > 0 || (o.node.type.name === e && s.every((a) => t[a] === o.node.attrs[a]) && i.push(o), !(r && i.length > 0) && (i = i.concat(o.querySelectorAll(e, t, r))));
    }), i;
  }
  setAttribute(e) {
    const { tr: t } = this.editor.state;
    t.setNodeMarkup(this.from, void 0, {
      ...this.node.attrs,
      ...e
    }), this.editor.view.dispatch(t);
  }
}, jv = `.ProseMirror {
  position: relative;
}

.ProseMirror {
  word-wrap: break-word;
  white-space: pre-wrap;
  white-space: break-spaces;
  -webkit-font-variant-ligatures: none;
  font-variant-ligatures: none;
  font-feature-settings: "liga" 0; /* the above doesn't seem to work in Edge */
}

.ProseMirror [contenteditable="false"] {
  white-space: normal;
}

.ProseMirror [contenteditable="false"] [contenteditable="true"] {
  white-space: pre-wrap;
}

.ProseMirror pre {
  white-space: pre-wrap;
}

img.ProseMirror-separator {
  display: inline !important;
  border: none !important;
  margin: 0 !important;
  width: 0 !important;
  height: 0 !important;
}

.ProseMirror-gapcursor {
  display: none;
  pointer-events: none;
  position: absolute;
  margin: 0;
}

.ProseMirror-gapcursor:after {
  content: "";
  display: block;
  position: absolute;
  top: -2px;
  width: 20px;
  border-top: 1px solid black;
  animation: ProseMirror-cursor-blink 1.1s steps(2, start) infinite;
}

@keyframes ProseMirror-cursor-blink {
  to {
    visibility: hidden;
  }
}

.ProseMirror-hideselection *::selection {
  background: transparent;
}

.ProseMirror-hideselection *::-moz-selection {
  background: transparent;
}

.ProseMirror-hideselection * {
  caret-color: transparent;
}

.ProseMirror-focused .ProseMirror-gapcursor {
  display: block;
}`;
function Wv(n, e, t) {
  const r = document.querySelector("style[data-tiptap-style]");
  if (r !== null)
    return r;
  const i = document.createElement("style");
  return e && i.setAttribute("nonce", e), i.setAttribute("data-tiptap-style", ""), i.innerHTML = n, document.getElementsByTagName("head")[0].appendChild(i), i;
}
var Kv = class extends aw {
  constructor(n = {}) {
    super(), this.css = null, this.editorView = null, this.isFocused = !1, this.isInitialized = !1, this.extensionStorage = {}, this.instanceId = Math.random().toString(36).slice(2, 9), this.options = {
      element: typeof document < "u" ? document.createElement("div") : null,
      content: "",
      injectCSS: !0,
      injectNonce: void 0,
      extensions: [],
      autofocus: !1,
      editable: !0,
      editorProps: {},
      parseOptions: {},
      coreExtensionOptions: {},
      enableInputRules: !0,
      enablePasteRules: !0,
      enableCoreExtensions: !0,
      enableContentCheck: !1,
      emitContentError: !1,
      onBeforeCreate: () => null,
      onCreate: () => null,
      onUpdate: () => null,
      onSelectionUpdate: () => null,
      onTransaction: () => null,
      onFocus: () => null,
      onBlur: () => null,
      onDestroy: () => null,
      onContentError: ({ error: r }) => {
        throw r;
      },
      onPaste: () => null,
      onDrop: () => null,
      onDelete: () => null
    }, this.isCapturingTransaction = !1, this.capturedTransaction = null, this.setOptions(n), this.createExtensionManager(), this.createCommandManager(), this.createSchema(), this.on("beforeCreate", this.options.onBeforeCreate), this.emit("beforeCreate", { editor: this }), this.on("contentError", this.options.onContentError), this.on("create", this.options.onCreate), this.on("update", this.options.onUpdate), this.on("selectionUpdate", this.options.onSelectionUpdate), this.on("transaction", this.options.onTransaction), this.on("focus", this.options.onFocus), this.on("blur", this.options.onBlur), this.on("destroy", this.options.onDestroy), this.on("drop", ({ event: r, slice: i, moved: s }) => this.options.onDrop(r, i, s)), this.on("paste", ({ event: r, slice: i }) => this.options.onPaste(r, i)), this.on("delete", this.options.onDelete);
    const e = this.createDoc(), t = Up(e, this.options.autofocus);
    this.editorState = fr.create({
      doc: e,
      schema: this.schema,
      selection: t || void 0
    }), this.options.element && this.mount(this.options.element);
  }
  /**
   * Attach the editor to the DOM, creating a new editor view.
   */
  mount(n) {
    if (typeof document > "u")
      throw new Error(
        "[tiptap error]: The editor cannot be mounted because there is no 'document' defined in this environment."
      );
    this.createView(n), window.setTimeout(() => {
      this.isDestroyed || (this.commands.focus(this.options.autofocus), this.emit("create", { editor: this }), this.isInitialized = !0);
    }, 0);
  }
  /**
   * Remove the editor from the DOM, but still allow remounting at a different point in time
   */
  unmount() {
    var n;
    if (this.editorView) {
      const e = this.editorView.dom;
      e != null && e.editor && delete e.editor, this.editorView.destroy();
    }
    this.editorView = null, this.isInitialized = !1, (n = this.css) == null || n.remove(), this.css = null;
  }
  /**
   * Returns the editor storage.
   */
  get storage() {
    return this.extensionStorage;
  }
  /**
   * An object of all registered commands.
   */
  get commands() {
    return this.commandManager.commands;
  }
  /**
   * Create a command chain to call multiple commands at once.
   */
  chain() {
    return this.commandManager.chain();
  }
  /**
   * Check if a command or a command chain can be executed. Without executing it.
   */
  can() {
    return this.commandManager.can();
  }
  /**
   * Inject CSS styles.
   */
  injectCSS() {
    this.options.injectCSS && typeof document < "u" && (this.css = Wv(jv, this.options.injectNonce));
  }
  /**
   * Update editor options.
   *
   * @param options A list of options
   */
  setOptions(n = {}) {
    this.options = {
      ...this.options,
      ...n
    }, !(!this.editorView || !this.state || this.isDestroyed) && (this.options.editorProps && this.view.setProps(this.options.editorProps), this.view.updateState(this.state));
  }
  /**
   * Update editable state of the editor.
   */
  setEditable(n, e = !0) {
    this.setOptions({ editable: n }), e && this.emit("update", { editor: this, transaction: this.state.tr, appendedTransactions: [] });
  }
  /**
   * Returns whether the editor is editable.
   */
  get isEditable() {
    return this.options.editable && this.view && this.view.editable;
  }
  /**
   * Returns the editor state.
   */
  get view() {
    return this.editorView ? this.editorView : new Proxy(
      {
        state: this.editorState,
        updateState: (n) => {
          this.editorState = n;
        },
        dispatch: (n) => {
          this.editorState = this.state.apply(n);
        },
        // Stub some commonly accessed properties to prevent errors
        composing: !1,
        dragging: null,
        editable: !0,
        isDestroyed: !1
      },
      {
        get: (n, e) => {
          if (e === "state")
            return this.editorState;
          if (e in n)
            return Reflect.get(n, e);
          throw new Error(
            `[tiptap error]: The editor view is not available. Cannot access view['${e}']. The editor may not be mounted yet.`
          );
        }
      }
    );
  }
  /**
   * Returns the editor state.
   */
  get state() {
    return this.editorView && (this.editorState = this.view.state), this.editorState;
  }
  /**
   * Register a ProseMirror plugin.
   *
   * @param plugin A ProseMirror plugin
   * @param handlePlugins Control how to merge the plugin into the existing plugins.
   * @returns The new editor state
   */
  registerPlugin(n, e) {
    const t = Op(e) ? e(n, [...this.state.plugins]) : [...this.state.plugins, n], r = this.state.reconfigure({ plugins: t });
    return this.view.updateState(r), r;
  }
  /**
   * Unregister a ProseMirror plugin.
   *
   * @param nameOrPluginKeyToRemove The plugins name
   * @returns The new editor state or undefined if the editor is destroyed
   */
  unregisterPlugin(n) {
    if (this.isDestroyed)
      return;
    const e = this.state.plugins;
    let t = e;
    if ([].concat(n).forEach((i) => {
      const s = typeof i == "string" ? `${i}$` : i.key;
      t = t.filter((o) => !o.key.startsWith(s));
    }), e.length === t.length)
      return;
    const r = this.state.reconfigure({
      plugins: t
    });
    return this.view.updateState(r), r;
  }
  /**
   * Creates an extension manager.
   */
  createExtensionManager() {
    var n, e;
    const r = [...this.options.enableCoreExtensions ? [
      em,
      Gp.configure({
        blockSeparator: (e = (n = this.options.coreExtensionOptions) == null ? void 0 : n.clipboardTextSerializer) == null ? void 0 : e.blockSeparator
      }),
      Xp,
      nm,
      rm,
      sm,
      Qp,
      im,
      Zp
    ].filter((i) => typeof this.options.enableCoreExtensions == "object" ? this.options.enableCoreExtensions[i.name] !== !1 : !0) : [], ...this.options.extensions].filter((i) => ["extension", "node", "mark"].includes(i == null ? void 0 : i.type));
    this.extensionManager = new bo(r, this);
  }
  /**
   * Creates an command manager.
   */
  createCommandManager() {
    this.commandManager = new po({
      editor: this
    });
  }
  /**
   * Creates a ProseMirror schema.
   */
  createSchema() {
    this.schema = this.extensionManager.schema;
  }
  /**
   * Creates the initial document.
   */
  createDoc() {
    let n;
    try {
      n = Kl(this.options.content, this.schema, this.options.parseOptions, {
        errorOnInvalidContent: this.options.enableContentCheck
      });
    } catch (e) {
      if (!(e instanceof Error) || !["[tiptap error]: Invalid JSON content", "[tiptap error]: Invalid HTML content"].includes(e.message))
        throw e;
      this.emit("contentError", {
        editor: this,
        error: e,
        disableCollaboration: () => {
          "collaboration" in this.storage && typeof this.storage.collaboration == "object" && this.storage.collaboration && (this.storage.collaboration.isDisabled = !0), this.options.extensions = this.options.extensions.filter((t) => t.name !== "collaboration"), this.createExtensionManager();
        }
      }), n = Kl(this.options.content, this.schema, this.options.parseOptions, {
        errorOnInvalidContent: !1
      });
    }
    return n;
  }
  /**
   * Creates a ProseMirror view.
   */
  createView(n) {
    var e;
    this.editorView = new gp(n, {
      ...this.options.editorProps,
      attributes: {
        // add `role="textbox"` to the editor element
        role: "textbox",
        ...(e = this.options.editorProps) == null ? void 0 : e.attributes
      },
      dispatchTransaction: this.dispatchTransaction.bind(this),
      state: this.editorState
    });
    const t = this.state.reconfigure({
      plugins: this.extensionManager.plugins
    });
    this.view.updateState(t), this.createNodeViews(), this.prependClass(), this.injectCSS();
    const r = this.view.dom;
    r.editor = this;
  }
  /**
   * Creates all node and mark views.
   */
  createNodeViews() {
    this.view.isDestroyed || this.view.setProps({
      markViews: this.extensionManager.markViews,
      nodeViews: this.extensionManager.nodeViews
    });
  }
  /**
   * Prepend class name to element.
   */
  prependClass() {
    this.view.dom.className = `tiptap ${this.view.dom.className}`;
  }
  captureTransaction(n) {
    this.isCapturingTransaction = !0, n(), this.isCapturingTransaction = !1;
    const e = this.capturedTransaction;
    return this.capturedTransaction = null, e;
  }
  /**
   * The callback over which to send transactions (state updates) produced by the view.
   *
   * @param transaction An editor state transaction
   */
  dispatchTransaction(n) {
    if (this.view.isDestroyed)
      return;
    if (this.isCapturingTransaction) {
      if (!this.capturedTransaction) {
        this.capturedTransaction = n;
        return;
      }
      n.steps.forEach((c) => {
        var u;
        return (u = this.capturedTransaction) == null ? void 0 : u.step(c);
      });
      return;
    }
    const { state: e, transactions: t } = this.state.applyTransaction(n), r = !this.state.selection.eq(e.selection), i = t.includes(n), s = this.state;
    if (this.emit("beforeTransaction", {
      editor: this,
      transaction: n,
      nextState: e
    }), !i)
      return;
    this.view.updateState(e), this.emit("transaction", {
      editor: this,
      transaction: n,
      appendedTransactions: t.slice(1)
    }), r && this.emit("selectionUpdate", {
      editor: this,
      transaction: n
    });
    const o = t.findLast((c) => c.getMeta("focus") || c.getMeta("blur")), l = o == null ? void 0 : o.getMeta("focus"), a = o == null ? void 0 : o.getMeta("blur");
    l && this.emit("focus", {
      editor: this,
      event: l.event,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      transaction: o
    }), a && this.emit("blur", {
      editor: this,
      event: a.event,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      transaction: o
    }), !(n.getMeta("preventUpdate") || !t.some((c) => c.docChanged) || s.doc.eq(e.doc)) && this.emit("update", {
      editor: this,
      transaction: n,
      appendedTransactions: t.slice(1)
    });
  }
  /**
   * Get attributes of the currently selected node or mark.
   */
  getAttributes(n) {
    return Bp(this.state, n);
  }
  isActive(n, e) {
    const t = typeof n == "string" ? n : null, r = typeof n == "string" ? e : n;
    return vw(this.state, t, r);
  }
  /**
   * Get the document as JSON.
   */
  getJSON() {
    return this.state.doc.toJSON();
  }
  /**
   * Get the document as HTML.
   */
  getHTML() {
    return Na(this.state.doc.content, this.schema);
  }
  /**
   * Get the document as text.
   */
  getText(n) {
    const { blockSeparator: e = `

`, textSerializers: t = {} } = n || {};
    return gw(this.state.doc, {
      blockSeparator: e,
      textSerializers: {
        ...Lp(this.schema),
        ...t
      }
    });
  }
  /**
   * Check if there is no content.
   */
  get isEmpty() {
    return _o(this.state.doc);
  }
  /**
   * Destroy the editor.
   */
  destroy() {
    this.emit("destroy"), this.unmount(), this.removeAllListeners();
  }
  /**
   * Check if the editor is already destroyed.
   */
  get isDestroyed() {
    var n, e;
    return (e = (n = this.editorView) == null ? void 0 : n.isDestroyed) != null ? e : !0;
  }
  $node(n, e) {
    var t;
    return ((t = this.$doc) == null ? void 0 : t.querySelector(n, e)) || null;
  }
  $nodes(n, e) {
    var t;
    return ((t = this.$doc) == null ? void 0 : t.querySelectorAll(n, e)) || null;
  }
  $pos(n) {
    const e = this.state.doc.resolve(n);
    return new Uv(e, this);
  }
  get $doc() {
    return this.$pos(0);
  }
};
function wr(n) {
  return new yo({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = J(n.getAttributes, void 0, r);
      if (i === !1 || i === null)
        return null;
      const { tr: s } = e, o = r[r.length - 1], l = r[0];
      if (o) {
        const a = l.search(/\S/), c = t.from + l.indexOf(o), u = c + o.length;
        if (Pa(t.from, t.to, e.doc).filter((h) => h.mark.type.excluded.find((m) => m === n.type && m !== h.mark.type)).filter((h) => h.to > c).length)
          return null;
        u < t.to && s.delete(u, t.to), c > t.from && s.delete(t.from + a, c);
        const f = t.from + a + o.length;
        s.addMark(t.from + a, f, n.type.create(i || {})), s.removeStoredMark(n.type);
      }
    }
  });
}
function om(n) {
  return new yo({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = J(n.getAttributes, void 0, r) || {}, { tr: s } = e, o = t.from;
      let l = t.to;
      const a = n.type.create(i);
      if (r[1]) {
        const c = r[0].lastIndexOf(r[1]);
        let u = o + c;
        u > l ? u = l : l = u + r[1].length;
        const d = r[0][r[0].length - 1];
        s.insertText(d, o + r[0].length - 1), s.replaceWith(u, l, a);
      } else if (r[0]) {
        const c = n.type.isInline ? o : o - 1;
        s.insert(c, n.type.create(i)).delete(s.mapping.map(o), s.mapping.map(l));
      }
      s.scrollIntoView();
    }
  });
}
function Jl(n) {
  return new yo({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = e.doc.resolve(t.from), s = J(n.getAttributes, void 0, r) || {};
      if (!i.node(-1).canReplaceWith(i.index(-1), i.indexAfter(-1), n.type))
        return null;
      e.tr.delete(t.from, t.to).setBlockType(t.from, t.from, n.type, s);
    }
  });
}
function vr(n) {
  return new yo({
    find: n.find,
    handler: ({ state: e, range: t, match: r, chain: i }) => {
      const s = J(n.getAttributes, void 0, r) || {}, o = e.tr.delete(t.from, t.to), a = o.doc.resolve(t.from).blockRange(), c = a && _a(a, n.type, s);
      if (!c)
        return null;
      if (o.wrap(a, c), n.keepMarks && n.editor) {
        const { selection: d, storedMarks: f } = e, { splittableMarks: h } = n.editor.extensionManager, p = f || d.$to.parentOffset && d.$from.marks();
        if (p) {
          const m = p.filter((_) => h.includes(_.type.name));
          o.ensureMarks(m);
        }
      }
      if (n.keepAttributes) {
        const d = n.type.name === "bulletList" || n.type.name === "orderedList" ? "listItem" : "taskList";
        i().updateAttributes(d, s).run();
      }
      const u = o.doc.resolve(t.from - 1).nodeBefore;
      u && u.type === n.type && wn(o.doc, t.from - 1) && (!n.joinPredicate || n.joinPredicate(r, u)) && o.join(t.from - 1);
    }
  });
}
function Gv(n, e) {
  const { selection: t } = n, { $from: r } = t;
  if (t instanceof B) {
    const s = r.index();
    return r.parent.canReplaceWith(s, s + 1, e);
  }
  let i = r.depth;
  for (; i >= 0; ) {
    const s = r.index(i);
    if (r.node(i).contentMatchAt(s).matchType(e))
      return !0;
    i -= 1;
  }
  return !1;
}
function Jv(n, e, t = {}) {
  const { state: r } = e, { doc: i, tr: s } = r, o = n;
  i.descendants((l, a) => {
    const c = s.mapping.map(a), u = s.mapping.map(a) + l.nodeSize;
    let d = null;
    if (l.marks.forEach((h) => {
      if (h !== o)
        return !1;
      d = h;
    }), !d)
      return;
    let f = !1;
    if (Object.keys(t).forEach((h) => {
      t[h] !== d.attrs[h] && (f = !0);
    }), f) {
      const h = n.type.create({
        ...n.attrs,
        ...t
      });
      s.removeMark(c, u, n.type), s.addMark(c, u, h);
    }
  }), s.docChanged && e.view.dispatch(s);
}
var Je = class lm extends Ba {
  constructor() {
    super(...arguments), this.type = "node";
  }
  /**
   * Create a new Node instance
   * @param config - Node configuration object or a function that returns a configuration object
   */
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new lm(t);
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
};
function Vn(n) {
  return new Mw({
    find: n.find,
    handler: ({ state: e, range: t, match: r, pasteEvent: i }) => {
      const s = J(n.getAttributes, void 0, r, i);
      if (s === !1 || s === null)
        return null;
      const { tr: o } = e, l = r[r.length - 1], a = r[0];
      let c = t.to;
      if (l) {
        const u = a.search(/\S/), d = t.from + a.indexOf(l), f = d + l.length;
        if (Pa(t.from, t.to, e.doc).filter((p) => p.mark.type.excluded.find((_) => _ === n.type && _ !== p.mark.type)).filter((p) => p.to > d).length)
          return null;
        f < t.to && o.delete(f, t.to), d > t.from && o.delete(t.from + u, d), c = t.from + u + l.length, o.addMark(t.from + u, c, n.type.create(s || {})), o.removeStoredMark(n.type);
      }
    }
  });
}
var Ts = (n, e) => {
  if (n === "slot")
    return 0;
  if (n instanceof Function)
    return n(e);
  const { children: t, ...r } = e ?? {};
  if (n === "svg")
    throw new Error("SVG elements are not supported in the JSX syntax, use the array syntax instead");
  return [n, r, t];
}, Yv = /^\s*>\s$/, Xv = Je.create({
  name: "blockquote",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  content: "block+",
  group: "block",
  defining: !0,
  parseHTML() {
    return [{ tag: "blockquote" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return /* @__PURE__ */ Ts("blockquote", { ...fe(this.options.HTMLAttributes, n), children: /* @__PURE__ */ Ts("slot", {}) });
  },
  addCommands() {
    return {
      setBlockquote: () => ({ commands: n }) => n.wrapIn(this.name),
      toggleBlockquote: () => ({ commands: n }) => n.toggleWrap(this.name),
      unsetBlockquote: () => ({ commands: n }) => n.lift(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-b": () => this.editor.commands.toggleBlockquote()
    };
  },
  addInputRules() {
    return [
      vr({
        find: Yv,
        type: this.type
      })
    ];
  }
}), Zv = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))$/, Qv = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))/g, eE = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))$/, tE = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))/g, nE = Kn.create({
  name: "bold",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "strong"
      },
      {
        tag: "b",
        getAttrs: (n) => n.style.fontWeight !== "normal" && null
      },
      {
        style: "font-weight=400",
        clearMark: (n) => n.type.name === this.name
      },
      {
        style: "font-weight",
        getAttrs: (n) => /^(bold(er)?|[5-9]\d{2,})$/.test(n) && null
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return /* @__PURE__ */ Ts("strong", { ...fe(this.options.HTMLAttributes, n), children: /* @__PURE__ */ Ts("slot", {}) });
  },
  addCommands() {
    return {
      setBold: () => ({ commands: n }) => n.setMark(this.name),
      toggleBold: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetBold: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-b": () => this.editor.commands.toggleBold(),
      "Mod-B": () => this.editor.commands.toggleBold()
    };
  },
  addInputRules() {
    return [
      wr({
        find: Zv,
        type: this.type
      }),
      wr({
        find: eE,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      Vn({
        find: Qv,
        type: this.type
      }),
      Vn({
        find: tE,
        type: this.type
      })
    ];
  }
}), rE = /(^|[^`])`([^`]+)`(?!`)/, iE = /(^|[^`])`([^`]+)`(?!`)/g, sE = Kn.create({
  name: "code",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  excludes: "_",
  code: !0,
  exitable: !0,
  parseHTML() {
    return [{ tag: "code" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["code", fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setCode: () => ({ commands: n }) => n.setMark(this.name),
      toggleCode: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetCode: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-e": () => this.editor.commands.toggleCode()
    };
  },
  addInputRules() {
    return [
      wr({
        find: rE,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      Vn({
        find: iE,
        type: this.type
      })
    ];
  }
}), oE = /^```([a-z]+)?[\s\n]$/, lE = /^~~~([a-z]+)?[\s\n]$/, aE = Je.create({
  name: "codeBlock",
  addOptions() {
    return {
      languageClassPrefix: "language-",
      exitOnTripleEnter: !0,
      exitOnArrowDown: !0,
      defaultLanguage: null,
      HTMLAttributes: {}
    };
  },
  content: "text*",
  marks: "",
  group: "block",
  code: !0,
  defining: !0,
  addAttributes() {
    return {
      language: {
        default: this.options.defaultLanguage,
        parseHTML: (n) => {
          var e;
          const { languageClassPrefix: t } = this.options, s = [...((e = n.firstElementChild) == null ? void 0 : e.classList) || []].filter((o) => o.startsWith(t)).map((o) => o.replace(t, ""))[0];
          return s || null;
        },
        rendered: !1
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "pre",
        preserveWhitespace: "full"
      }
    ];
  },
  renderHTML({ node: n, HTMLAttributes: e }) {
    return [
      "pre",
      fe(this.options.HTMLAttributes, e),
      [
        "code",
        {
          class: n.attrs.language ? this.options.languageClassPrefix + n.attrs.language : null
        },
        0
      ]
    ];
  },
  addCommands() {
    return {
      setCodeBlock: (n) => ({ commands: e }) => e.setNode(this.name, n),
      toggleCodeBlock: (n) => ({ commands: e }) => e.toggleNode(this.name, "paragraph", n)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Alt-c": () => this.editor.commands.toggleCodeBlock(),
      // remove code block when at start of document or code block is empty
      Backspace: () => {
        const { empty: n, $anchor: e } = this.editor.state.selection, t = e.pos === 1;
        return !n || e.parent.type.name !== this.name ? !1 : t || !e.parent.textContent.length ? this.editor.commands.clearNodes() : !1;
      },
      // exit node on triple enter
      Enter: ({ editor: n }) => {
        if (!this.options.exitOnTripleEnter)
          return !1;
        const { state: e } = n, { selection: t } = e, { $from: r, empty: i } = t;
        if (!i || r.parent.type !== this.type)
          return !1;
        const s = r.parentOffset === r.parent.nodeSize - 2, o = r.parent.textContent.endsWith(`

`);
        return !s || !o ? !1 : n.chain().command(({ tr: l }) => (l.delete(r.pos - 2, r.pos), !0)).exitCode().run();
      },
      // exit node on arrow down
      ArrowDown: ({ editor: n }) => {
        if (!this.options.exitOnArrowDown)
          return !1;
        const { state: e } = n, { selection: t, doc: r } = e, { $from: i, empty: s } = t;
        if (!s || i.parent.type !== this.type || !(i.parentOffset === i.parent.nodeSize - 2))
          return !1;
        const l = i.after();
        return l === void 0 ? !1 : r.nodeAt(l) ? n.commands.command(({ tr: c }) => (c.setSelection(V.near(r.resolve(l))), !0)) : n.commands.exitCode();
      }
    };
  },
  addInputRules() {
    return [
      Jl({
        find: oE,
        type: this.type,
        getAttributes: (n) => ({
          language: n[1]
        })
      }),
      Jl({
        find: lE,
        type: this.type,
        getAttributes: (n) => ({
          language: n[1]
        })
      })
    ];
  },
  addProseMirrorPlugins() {
    return [
      // this plugin creates a code block for pasted content from VS Code
      // we can also detect the copied code language
      new ae({
        key: new _e("codeBlockVSCodeHandler"),
        props: {
          handlePaste: (n, e) => {
            if (!e.clipboardData || this.editor.isActive(this.type.name))
              return !1;
            const t = e.clipboardData.getData("text/plain"), r = e.clipboardData.getData("vscode-editor-data"), i = r ? JSON.parse(r) : void 0, s = i == null ? void 0 : i.mode;
            if (!t || !s)
              return !1;
            const { tr: o, schema: l } = n.state, a = l.text(t.replace(/\r\n?/g, `
`));
            return o.replaceSelectionWith(this.type.create({ language: s }, a)), o.selection.$from.parent.type !== this.type && o.setSelection(z.near(o.doc.resolve(Math.max(0, o.selection.from - 2)))), o.setMeta("paste", !0), n.dispatch(o), !0;
          }
        }
      })
    ];
  }
}), cE = Je.create({
  name: "doc",
  topNode: !0,
  content: "block+"
}), uE = Je.create({
  name: "hardBreak",
  addOptions() {
    return {
      keepMarks: !0,
      HTMLAttributes: {}
    };
  },
  inline: !0,
  group: "inline",
  selectable: !1,
  linebreakReplacement: !0,
  parseHTML() {
    return [{ tag: "br" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["br", fe(this.options.HTMLAttributes, n)];
  },
  renderText() {
    return `
`;
  },
  addCommands() {
    return {
      setHardBreak: () => ({ commands: n, chain: e, state: t, editor: r }) => n.first([
        () => n.exitCode(),
        () => n.command(() => {
          const { selection: i, storedMarks: s } = t;
          if (i.$from.parent.type.spec.isolating)
            return !1;
          const { keepMarks: o } = this.options, { splittableMarks: l } = r.extensionManager, a = s || i.$to.parentOffset && i.$from.marks();
          return e().insertContent({ type: this.name }).command(({ tr: c, dispatch: u }) => {
            if (u && a && o) {
              const d = a.filter((f) => l.includes(f.type.name));
              c.ensureMarks(d);
            }
            return !0;
          }).run();
        })
      ])
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Enter": () => this.editor.commands.setHardBreak(),
      "Shift-Enter": () => this.editor.commands.setHardBreak()
    };
  }
}), dE = Je.create({
  name: "heading",
  addOptions() {
    return {
      levels: [1, 2, 3, 4, 5, 6],
      HTMLAttributes: {}
    };
  },
  content: "inline*",
  group: "block",
  defining: !0,
  addAttributes() {
    return {
      level: {
        default: 1,
        rendered: !1
      }
    };
  },
  parseHTML() {
    return this.options.levels.map((n) => ({
      tag: `h${n}`,
      attrs: { level: n }
    }));
  },
  renderHTML({ node: n, HTMLAttributes: e }) {
    return [`h${this.options.levels.includes(n.attrs.level) ? n.attrs.level : this.options.levels[0]}`, fe(this.options.HTMLAttributes, e), 0];
  },
  addCommands() {
    return {
      setHeading: (n) => ({ commands: e }) => this.options.levels.includes(n.level) ? e.setNode(this.name, n) : !1,
      toggleHeading: (n) => ({ commands: e }) => this.options.levels.includes(n.level) ? e.toggleNode(this.name, "paragraph", n) : !1
    };
  },
  addKeyboardShortcuts() {
    return this.options.levels.reduce(
      (n, e) => ({
        ...n,
        [`Mod-Alt-${e}`]: () => this.editor.commands.toggleHeading({ level: e })
      }),
      {}
    );
  },
  addInputRules() {
    return this.options.levels.map((n) => Jl({
      find: new RegExp(`^(#{${Math.min(...this.options.levels)},${n}})\\s$`),
      type: this.type,
      getAttributes: {
        level: n
      }
    }));
  }
}), fE = Je.create({
  name: "horizontalRule",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  group: "block",
  parseHTML() {
    return [{ tag: "hr" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["hr", fe(this.options.HTMLAttributes, n)];
  },
  addCommands() {
    return {
      setHorizontalRule: () => ({ chain: n, state: e }) => {
        if (!Gv(e, e.schema.nodes[this.name]))
          return !1;
        const { selection: t } = e, { $to: r } = t, i = n();
        return qp(t) ? i.insertContentAt(r.pos, {
          type: this.name
        }) : i.insertContent({ type: this.name }), i.command(({ tr: s, dispatch: o }) => {
          var l;
          if (o) {
            const { $to: a } = s.selection, c = a.end();
            if (a.nodeAfter)
              a.nodeAfter.isTextblock ? s.setSelection(z.create(s.doc, a.pos + 1)) : a.nodeAfter.isBlock ? s.setSelection(B.create(s.doc, a.pos)) : s.setSelection(z.create(s.doc, a.pos));
            else {
              const u = (l = a.parent.type.contentMatch.defaultType) == null ? void 0 : l.create();
              u && (s.insert(c, u), s.setSelection(z.create(s.doc, c + 1)));
            }
            s.scrollIntoView();
          }
          return !0;
        }).run();
      }
    };
  },
  addInputRules() {
    return [
      om({
        find: /^(?:---|—-|___\s|\*\*\*\s)$/,
        type: this.type
      })
    ];
  }
}), hE = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))$/, pE = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))/g, mE = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))$/, gE = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))/g, _E = Kn.create({
  name: "italic",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "em"
      },
      {
        tag: "i",
        getAttrs: (n) => n.style.fontStyle !== "normal" && null
      },
      {
        style: "font-style=normal",
        clearMark: (n) => n.type.name === this.name
      },
      {
        style: "font-style=italic"
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["em", fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setItalic: () => ({ commands: n }) => n.setMark(this.name),
      toggleItalic: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetItalic: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-i": () => this.editor.commands.toggleItalic(),
      "Mod-I": () => this.editor.commands.toggleItalic()
    };
  },
  addInputRules() {
    return [
      wr({
        find: hE,
        type: this.type
      }),
      wr({
        find: mE,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      Vn({
        find: pE,
        type: this.type
      }),
      Vn({
        find: gE,
        type: this.type
      })
    ];
  }
});
const yE = "aaa1rp3bb0ott3vie4c1le2ogado5udhabi7c0ademy5centure6ountant0s9o1tor4d0s1ult4e0g1ro2tna4f0l1rica5g0akhan5ency5i0g1rbus3force5tel5kdn3l0ibaba4pay4lfinanz6state5y2sace3tom5m0azon4ericanexpress7family11x2fam3ica3sterdam8nalytics7droid5quan4z2o0l2partments8p0le4q0uarelle8r0ab1mco4chi3my2pa2t0e3s0da2ia2sociates9t0hleta5torney7u0ction5di0ble3o3spost5thor3o0s4w0s2x0a2z0ure5ba0by2idu3namex4d1k2r0celona5laycard4s5efoot5gains6seball5ketball8uhaus5yern5b0c1t1va3cg1n2d1e0ats2uty4er2rlin4st0buy5t2f1g1h0arti5i0ble3d1ke2ng0o3o1z2j1lack0friday9ockbuster8g1omberg7ue3m0s1w2n0pparibas9o0ats3ehringer8fa2m1nd2o0k0ing5sch2tik2on4t1utique6x2r0adesco6idgestone9oadway5ker3ther5ussels7s1t1uild0ers6siness6y1zz3v1w1y1z0h3ca0b1fe2l0l1vinklein9m0era3p2non3petown5ital0one8r0avan4ds2e0er0s4s2sa1e1h1ino4t0ering5holic7ba1n1re3c1d1enter4o1rn3f0a1d2g1h0anel2nel4rity4se2t2eap3intai5ristmas6ome4urch5i0priani6rcle4sco3tadel4i0c2y3k1l0aims4eaning6ick2nic1que6othing5ud3ub0med6m1n1o0ach3des3ffee4llege4ogne5m0mbank4unity6pany2re3uter5sec4ndos3struction8ulting7tact3ractors9oking4l1p2rsica5untry4pon0s4rses6pa2r0edit0card4union9icket5own3s1uise0s6u0isinella9v1w1x1y0mru3ou3z2dad1nce3ta1e1ing3sun4y2clk3ds2e0al0er2s3gree4livery5l1oitte5ta3mocrat6ntal2ist5si0gn4v2hl2iamonds6et2gital5rect0ory7scount3ver5h2y2j1k1m1np2o0cs1tor4g1mains5t1wnload7rive4tv2ubai3nlop4pont4rban5vag2r2z2earth3t2c0o2deka3u0cation8e1g1mail3erck5nergy4gineer0ing9terprises10pson4quipment8r0icsson6ni3s0q1tate5t1u0rovision8s2vents5xchange6pert3osed4ress5traspace10fage2il1rwinds6th3mily4n0s2rm0ers5shion4t3edex3edback6rrari3ero6i0delity5o2lm2nal1nce1ial7re0stone6mdale6sh0ing5t0ness6j1k1lickr3ghts4r2orist4wers5y2m1o0o0d1tball6rd1ex2sale4um3undation8x2r0ee1senius7l1ogans4ntier7tr2ujitsu5n0d2rniture7tbol5yi3ga0l0lery3o1up4me0s3p1rden4y2b0iz3d0n2e0a1nt0ing5orge5f1g0ee3h1i0ft0s3ves2ing5l0ass3e1obal2o4m0ail3bh2o1x2n1odaddy5ld0point6f2o0dyear5g0le4p1t1v2p1q1r0ainger5phics5tis4een3ipe3ocery4up4s1t1u0cci3ge2ide2tars5ru3w1y2hair2mburg5ngout5us3bo2dfc0bank7ealth0care8lp1sinki6re1mes5iphop4samitsu7tachi5v2k0t2m1n1ockey4ldings5iday5medepot5goods5s0ense7nda3rse3spital5t0ing5t0els3mail5use3w2r1sbc3t1u0ghes5yatt3undai7ibm2cbc2e1u2d1e0ee3fm2kano4l1m0amat4db2mo0bilien9n0c1dustries8finiti5o2g1k1stitute6urance4e4t0ernational10uit4vestments10o1piranga7q1r0ish4s0maili5t0anbul7t0au2v3jaguar4va3cb2e0ep2tzt3welry6io2ll2m0p2nj2o0bs1urg4t1y2p0morgan6rs3uegos4niper7kaufen5ddi3e0rryhotels6properties14fh2g1h1i0a1ds2m1ndle4tchen5wi3m1n1oeln3matsu5sher5p0mg2n2r0d1ed3uokgroup8w1y0oto4z2la0caixa5mborghini8er3nd0rover6xess5salle5t0ino3robe5w0yer5b1c1ds2ease3clerc5frak4gal2o2xus4gbt3i0dl2fe0insurance9style7ghting6ke2lly3mited4o2ncoln4k2ve1ing5k1lc1p2oan0s3cker3us3l1ndon4tte1o3ve3pl0financial11r1s1t0d0a3u0ndbeck6xe1ury5v1y2ma0drid4if1son4keup4n0agement7go3p1rket0ing3s4riott5shalls7ttel5ba2c0kinsey7d1e0d0ia3et2lbourne7me1orial6n0u2rckmsd7g1h1iami3crosoft7l1ni1t2t0subishi9k1l0b1s2m0a2n1o0bi0le4da2e1i1m1nash3ey2ster5rmon3tgage6scow4to0rcycles9v0ie4p1q1r1s0d2t0n1r2u0seum3ic4v1w1x1y1z2na0b1goya4me2vy3ba2c1e0c1t0bank4flix4work5ustar5w0s2xt0direct7us4f0l2g0o2hk2i0co2ke1on3nja3ssan1y5l1o0kia3rton4w0ruz3tv4p1r0a1w2tt2u1yc2z2obi1server7ffice5kinawa6layan0group9lo3m0ega4ne1g1l0ine5oo2pen3racle3nge4g0anic5igins6saka4tsuka4t2vh3pa0ge2nasonic7ris2s1tners4s1y3y2ccw3e0t2f0izer5g1h0armacy6d1ilips5one2to0graphy6s4ysio5ics1tet2ures6d1n0g1k2oneer5zza4k1l0ace2y0station9umbing5s3m1n0c2ohl2ker3litie5rn2st3r0axi3ess3ime3o0d0uctions8f1gressive8mo2perties3y5tection8u0dential9s1t1ub2w0c2y2qa1pon3uebec3st5racing4dio4e0ad1lestate6tor2y4cipes5d0stone5umbrella9hab3ise0n3t2liance6n0t0als5pair3ort3ublican8st0aurant8view0s5xroth6ich0ardli6oh3l1o1p2o0cks3deo3gers4om3s0vp3u0gby3hr2n2w0e2yukyu6sa0arland6fe0ty4kura4le1on3msclub4ung5ndvik0coromant12ofi4p1rl2s1ve2xo3b0i1s2c0b1haeffler7midt4olarships8ol3ule3warz5ience5ot3d1e0arch3t2cure1ity6ek2lect4ner3rvices6ven3w1x0y3fr2g1h0angrila6rp3ell3ia1ksha5oes2p0ping5uji3w3i0lk2na1gles5te3j1k0i0n2y0pe4l0ing4m0art3ile4n0cf3o0ccer3ial4ftbank4ware6hu2lar2utions7ng1y2y2pa0ce3ort2t3r0l2s1t0ada2ples4r1tebank4farm7c0group6ockholm6rage3e3ream4udio2y3yle4u0cks3pplies3y2ort5rf1gery5zuki5v1watch4iss4x1y0dney4stems6z2tab1ipei4lk2obao4rget4tamotors6r2too4x0i3c0i2d0k2eam2ch0nology8l1masek5nnis4va3f1g1h0d1eater2re6iaa2ckets5enda4ps2res2ol4j0maxx4x2k0maxx5l1m0all4n1o0day3kyo3ols3p1ray3shiba5tal3urs3wn2yota3s3r0ade1ing4ining5vel0ers0insurance16ust3v2t1ube2i1nes3shu4v0s2w1z2ua1bank3s2g1k1nicom3versity8o2ol2ps2s1y1z2va0cations7na1guard7c1e0gas3ntures6risign5mögensberater2ung14sicherung10t2g1i0ajes4deo3g1king4llas4n1p1rgin4sa1ion4va1o3laanderen9n1odka3lvo3te1ing3o2yage5u2wales2mart4ter4ng0gou5tch0es6eather0channel12bcam3er2site5d0ding5ibo2r3f1hoswho6ien2ki2lliamhill9n0dows4e1ners6me2olterskluwer11odside6rk0s2ld3w2s1tc1f3xbox3erox4ihuan4n2xx2yz3yachts4hoo3maxun5ndex5e1odobashi7ga2kohama6u0tube6t1un3za0ppos4ra3ero3ip2m1one3uerich6w2", bE = "ελ1υ2бг1ел3дети4ею2католик6ом3мкд2он1сква6онлайн5рг3рус2ф2сайт3рб3укр3қаз3հայ3ישראל5קום3ابوظبي5رامكو5لاردن4بحرين5جزائر5سعودية6عليان5مغرب5مارات5یران5بارت2زار4يتك3ھارت5تونس4سودان3رية5شبكة4عراق2ب2مان4فلسطين6قطر3كاثوليك6وم3مصر2ليسيا5وريتانيا7قع4همراه5پاکستان7ڀارت4कॉम3नेट3भारत0म्3ोत5संगठन5বাংলা5ভারত2ৰত4ਭਾਰਤ4ભારત4ଭାରତ4இந்தியா6லங்கை6சிங்கப்பூர்11భారత్5ಭಾರತ4ഭാരതം5ලංකා4คอม3ไทย3ລາວ3გე2みんな3アマゾン4クラウド4グーグル4コム2ストア3セール3ファッション6ポイント4世界2中信1国1國1文网3亚马逊3企业2佛山2信息2健康2八卦2公司1益2台湾1灣2商城1店1标2嘉里0大酒店5在线2大拿2天主教3娱乐2家電2广东2微博2慈善2我爱你3手机2招聘2政务1府2新加坡2闻2时尚2書籍2机构2淡马锡3游戏2澳門2点看2移动2组织机构4网址1店1站1络2联通2谷歌2购物2通販2集团2電訊盈科4飞利浦3食品2餐厅2香格里拉3港2닷넷1컴2삼성2한국2", Yl = "numeric", Xl = "ascii", Zl = "alpha", Xr = "asciinumeric", zr = "alphanumeric", Ql = "domain", am = "emoji", kE = "scheme", wE = "slashscheme", ul = "whitespace";
function vE(n, e) {
  return n in e || (e[n] = []), e[n];
}
function $n(n, e, t) {
  e[Yl] && (e[Xr] = !0, e[zr] = !0), e[Xl] && (e[Xr] = !0, e[Zl] = !0), e[Xr] && (e[zr] = !0), e[Zl] && (e[zr] = !0), e[zr] && (e[Ql] = !0), e[am] && (e[Ql] = !0);
  for (const r in e) {
    const i = vE(r, t);
    i.indexOf(n) < 0 && i.push(n);
  }
}
function EE(n, e) {
  const t = {};
  for (const r in e)
    e[r].indexOf(n) >= 0 && (t[r] = !0);
  return t;
}
function Ke(n = null) {
  this.j = {}, this.jr = [], this.jd = null, this.t = n;
}
Ke.groups = {};
Ke.prototype = {
  accepts() {
    return !!this.t;
  },
  /**
   * Follow an existing transition from the given input to the next state.
   * Does not mutate.
   * @param {string} input character or token type to transition on
   * @returns {?State<T>} the next state, if any
   */
  go(n) {
    const e = this, t = e.j[n];
    if (t)
      return t;
    for (let r = 0; r < e.jr.length; r++) {
      const i = e.jr[r][0], s = e.jr[r][1];
      if (s && i.test(n))
        return s;
    }
    return e.jd;
  },
  /**
   * Whether the state has a transition for the given input. Set the second
   * argument to true to only look for an exact match (and not a default or
   * regular-expression-based transition)
   * @param {string} input
   * @param {boolean} exactOnly
   */
  has(n, e = !1) {
    return e ? n in this.j : !!this.go(n);
  },
  /**
   * Short for "transition all"; create a transition from the array of items
   * in the given list to the same final resulting state.
   * @param {string | string[]} inputs Group of inputs to transition on
   * @param {Transition<T> | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of token groups
   */
  ta(n, e, t, r) {
    for (let i = 0; i < n.length; i++)
      this.tt(n[i], e, t, r);
  },
  /**
   * Short for "take regexp transition"; defines a transition for this state
   * when it encounters a token which matches the given regular expression
   * @param {RegExp} regexp Regular expression transition (populate first)
   * @param {T | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of token groups
   * @returns {State<T>} taken after the given input
   */
  tr(n, e, t, r) {
    r = r || Ke.groups;
    let i;
    return e && e.j ? i = e : (i = new Ke(e), t && r && $n(e, t, r)), this.jr.push([n, i]), i;
  },
  /**
   * Short for "take transitions", will take as many sequential transitions as
   * the length of the given input and returns the
   * resulting final state.
   * @param {string | string[]} input
   * @param {T | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of token groups
   * @returns {State<T>} taken after the given input
   */
  ts(n, e, t, r) {
    let i = this;
    const s = n.length;
    if (!s)
      return i;
    for (let o = 0; o < s - 1; o++)
      i = i.tt(n[o]);
    return i.tt(n[s - 1], e, t, r);
  },
  /**
   * Short for "take transition", this is a method for building/working with
   * state machines.
   *
   * If a state already exists for the given input, returns it.
   *
   * If a token is specified, that state will emit that token when reached by
   * the linkify engine.
   *
   * If no state exists, it will be initialized with some default transitions
   * that resemble existing default transitions.
   *
   * If a state is given for the second argument, that state will be
   * transitioned to on the given input regardless of what that input
   * previously did.
   *
   * Specify a token group flags to define groups that this token belongs to.
   * The token will be added to corresponding entires in the given groups
   * object.
   *
   * @param {string} input character, token type to transition on
   * @param {T | State<T>} [next] Transition options
   * @param {Flags} [flags] Collections flags to add token to
   * @param {Collections<T>} [groups] Master list of groups
   * @returns {State<T>} taken after the given input
   */
  tt(n, e, t, r) {
    r = r || Ke.groups;
    const i = this;
    if (e && e.j)
      return i.j[n] = e, e;
    const s = e;
    let o, l = i.go(n);
    if (l ? (o = new Ke(), Object.assign(o.j, l.j), o.jr.push.apply(o.jr, l.jr), o.jd = l.jd, o.t = l.t) : o = new Ke(), s) {
      if (r)
        if (o.t && typeof o.t == "string") {
          const a = Object.assign(EE(o.t, r), t);
          $n(s, a, r);
        } else t && $n(s, t, r);
      o.t = s;
    }
    return i.j[n] = o, o;
  }
};
const U = (n, e, t, r, i) => n.ta(e, t, r, i), ue = (n, e, t, r, i) => n.tr(e, t, r, i), Ld = (n, e, t, r, i) => n.ts(e, t, r, i), x = (n, e, t, r, i) => n.tt(e, t, r, i), Gt = "WORD", ea = "UWORD", cm = "ASCIINUMERICAL", um = "ALPHANUMERICAL", pi = "LOCALHOST", ta = "TLD", na = "UTLD", us = "SCHEME", ur = "SLASH_SCHEME", Ha = "NUM", ra = "WS", qa = "NL", Zr = "OPENBRACE", Qr = "CLOSEBRACE", Ms = "OPENBRACKET", Fs = "CLOSEBRACKET", $s = "OPENPAREN", Os = "CLOSEPAREN", Ns = "OPENANGLEBRACKET", Is = "CLOSEANGLEBRACKET", Rs = "FULLWIDTHLEFTPAREN", Ls = "FULLWIDTHRIGHTPAREN", Ps = "LEFTCORNERBRACKET", Bs = "RIGHTCORNERBRACKET", zs = "LEFTWHITECORNERBRACKET", Hs = "RIGHTWHITECORNERBRACKET", qs = "FULLWIDTHLESSTHAN", Vs = "FULLWIDTHGREATERTHAN", Us = "AMPERSAND", js = "APOSTROPHE", Ws = "ASTERISK", an = "AT", Ks = "BACKSLASH", Gs = "BACKTICK", Js = "CARET", dn = "COLON", Va = "COMMA", Ys = "DOLLAR", xt = "DOT", Xs = "EQUALS", Ua = "EXCLAMATION", it = "HYPHEN", ei = "PERCENT", Zs = "PIPE", Qs = "PLUS", eo = "POUND", ti = "QUERY", ja = "QUOTE", dm = "FULLWIDTHMIDDLEDOT", Wa = "SEMI", Tt = "SLASH", ni = "TILDE", to = "UNDERSCORE", fm = "EMOJI", no = "SYM";
var hm = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ALPHANUMERICAL: um,
  AMPERSAND: Us,
  APOSTROPHE: js,
  ASCIINUMERICAL: cm,
  ASTERISK: Ws,
  AT: an,
  BACKSLASH: Ks,
  BACKTICK: Gs,
  CARET: Js,
  CLOSEANGLEBRACKET: Is,
  CLOSEBRACE: Qr,
  CLOSEBRACKET: Fs,
  CLOSEPAREN: Os,
  COLON: dn,
  COMMA: Va,
  DOLLAR: Ys,
  DOT: xt,
  EMOJI: fm,
  EQUALS: Xs,
  EXCLAMATION: Ua,
  FULLWIDTHGREATERTHAN: Vs,
  FULLWIDTHLEFTPAREN: Rs,
  FULLWIDTHLESSTHAN: qs,
  FULLWIDTHMIDDLEDOT: dm,
  FULLWIDTHRIGHTPAREN: Ls,
  HYPHEN: it,
  LEFTCORNERBRACKET: Ps,
  LEFTWHITECORNERBRACKET: zs,
  LOCALHOST: pi,
  NL: qa,
  NUM: Ha,
  OPENANGLEBRACKET: Ns,
  OPENBRACE: Zr,
  OPENBRACKET: Ms,
  OPENPAREN: $s,
  PERCENT: ei,
  PIPE: Zs,
  PLUS: Qs,
  POUND: eo,
  QUERY: ti,
  QUOTE: ja,
  RIGHTCORNERBRACKET: Bs,
  RIGHTWHITECORNERBRACKET: Hs,
  SCHEME: us,
  SEMI: Wa,
  SLASH: Tt,
  SLASH_SCHEME: ur,
  SYM: no,
  TILDE: ni,
  TLD: ta,
  UNDERSCORE: to,
  UTLD: na,
  UWORD: ea,
  WORD: Gt,
  WS: ra
});
const Ut = /[a-z]/, Ir = new RegExp("\\p{L}", "u"), dl = new RegExp("\\p{Emoji}", "u"), jt = /\d/, fl = /\s/, Pd = "\r", hl = `
`, DE = "️", SE = "‍", pl = "￼";
let Yi = null, Xi = null;
function CE(n = []) {
  const e = {};
  Ke.groups = e;
  const t = new Ke();
  Yi == null && (Yi = Bd(yE)), Xi == null && (Xi = Bd(bE)), x(t, "'", js), x(t, "{", Zr), x(t, "}", Qr), x(t, "[", Ms), x(t, "]", Fs), x(t, "(", $s), x(t, ")", Os), x(t, "<", Ns), x(t, ">", Is), x(t, "（", Rs), x(t, "）", Ls), x(t, "「", Ps), x(t, "」", Bs), x(t, "『", zs), x(t, "』", Hs), x(t, "＜", qs), x(t, "＞", Vs), x(t, "&", Us), x(t, "*", Ws), x(t, "@", an), x(t, "`", Gs), x(t, "^", Js), x(t, ":", dn), x(t, ",", Va), x(t, "$", Ys), x(t, ".", xt), x(t, "=", Xs), x(t, "!", Ua), x(t, "-", it), x(t, "%", ei), x(t, "|", Zs), x(t, "+", Qs), x(t, "#", eo), x(t, "?", ti), x(t, '"', ja), x(t, "/", Tt), x(t, ";", Wa), x(t, "~", ni), x(t, "_", to), x(t, "\\", Ks), x(t, "・", dm);
  const r = ue(t, jt, Ha, {
    [Yl]: !0
  });
  ue(r, jt, r);
  const i = ue(r, Ut, cm, {
    [Xr]: !0
  }), s = ue(r, Ir, um, {
    [zr]: !0
  }), o = ue(t, Ut, Gt, {
    [Xl]: !0
  });
  ue(o, jt, i), ue(o, Ut, o), ue(i, jt, i), ue(i, Ut, i);
  const l = ue(t, Ir, ea, {
    [Zl]: !0
  });
  ue(l, Ut), ue(l, jt, s), ue(l, Ir, l), ue(s, jt, s), ue(s, Ut), ue(s, Ir, s);
  const a = x(t, hl, qa, {
    [ul]: !0
  }), c = x(t, Pd, ra, {
    [ul]: !0
  }), u = ue(t, fl, ra, {
    [ul]: !0
  });
  x(t, pl, u), x(c, hl, a), x(c, pl, u), ue(c, fl, u), x(u, Pd), x(u, hl), ue(u, fl, u), x(u, pl, u);
  const d = ue(t, dl, fm, {
    [am]: !0
  });
  x(d, "#"), ue(d, dl, d), x(d, DE, d);
  const f = x(d, SE);
  x(f, "#"), ue(f, dl, d);
  const h = [[Ut, o], [jt, i]], p = [[Ut, null], [Ir, l], [jt, s]];
  for (let m = 0; m < Yi.length; m++)
    rn(t, Yi[m], ta, Gt, h);
  for (let m = 0; m < Xi.length; m++)
    rn(t, Xi[m], na, ea, p);
  $n(ta, {
    tld: !0,
    ascii: !0
  }, e), $n(na, {
    utld: !0,
    alpha: !0
  }, e), rn(t, "file", us, Gt, h), rn(t, "mailto", us, Gt, h), rn(t, "http", ur, Gt, h), rn(t, "https", ur, Gt, h), rn(t, "ftp", ur, Gt, h), rn(t, "ftps", ur, Gt, h), $n(us, {
    scheme: !0,
    ascii: !0
  }, e), $n(ur, {
    slashscheme: !0,
    ascii: !0
  }, e), n = n.sort((m, _) => m[0] > _[0] ? 1 : -1);
  for (let m = 0; m < n.length; m++) {
    const _ = n[m][0], y = n[m][1] ? {
      [kE]: !0
    } : {
      [wE]: !0
    };
    _.indexOf("-") >= 0 ? y[Ql] = !0 : Ut.test(_) ? jt.test(_) ? y[Xr] = !0 : y[Xl] = !0 : y[Yl] = !0, Ld(t, _, _, y);
  }
  return Ld(t, "localhost", pi, {
    ascii: !0
  }), t.jd = new Ke(no), {
    start: t,
    tokens: Object.assign({
      groups: e
    }, hm)
  };
}
function pm(n, e) {
  const t = AE(e.replace(/[A-Z]/g, (l) => l.toLowerCase())), r = t.length, i = [];
  let s = 0, o = 0;
  for (; o < r; ) {
    let l = n, a = null, c = 0, u = null, d = -1, f = -1;
    for (; o < r && (a = l.go(t[o])); )
      l = a, l.accepts() ? (d = 0, f = 0, u = l) : d >= 0 && (d += t[o].length, f++), c += t[o].length, s += t[o].length, o++;
    s -= d, o -= f, c -= d, i.push({
      t: u.t,
      // token type/name
      v: e.slice(s - c, s),
      // string value
      s: s - c,
      // start index
      e: s
      // end index (excluding)
    });
  }
  return i;
}
function AE(n) {
  const e = [], t = n.length;
  let r = 0;
  for (; r < t; ) {
    let i = n.charCodeAt(r), s, o = i < 55296 || i > 56319 || r + 1 === t || (s = n.charCodeAt(r + 1)) < 56320 || s > 57343 ? n[r] : n.slice(r, r + 2);
    e.push(o), r += o.length;
  }
  return e;
}
function rn(n, e, t, r, i) {
  let s;
  const o = e.length;
  for (let l = 0; l < o - 1; l++) {
    const a = e[l];
    n.j[a] ? s = n.j[a] : (s = new Ke(r), s.jr = i.slice(), n.j[a] = s), n = s;
  }
  return s = new Ke(t), s.jr = i.slice(), n.j[e[o - 1]] = s, s;
}
function Bd(n) {
  const e = [], t = [];
  let r = 0, i = "0123456789";
  for (; r < n.length; ) {
    let s = 0;
    for (; i.indexOf(n[r + s]) >= 0; )
      s++;
    if (s > 0) {
      e.push(t.join(""));
      for (let o = parseInt(n.substring(r, r + s), 10); o > 0; o--)
        t.pop();
      r += s;
    } else
      t.push(n[r]), r++;
  }
  return e;
}
const mi = {
  defaultProtocol: "http",
  events: null,
  format: zd,
  formatHref: zd,
  nl2br: !1,
  tagName: "a",
  target: null,
  rel: null,
  validate: !0,
  truncate: 1 / 0,
  className: null,
  attributes: null,
  ignoreTags: [],
  render: null
};
function Ka(n, e = null) {
  let t = Object.assign({}, mi);
  n && (t = Object.assign(t, n instanceof Ka ? n.o : n));
  const r = t.ignoreTags, i = [];
  for (let s = 0; s < r.length; s++)
    i.push(r[s].toUpperCase());
  this.o = t, e && (this.defaultRender = e), this.ignoreTags = i;
}
Ka.prototype = {
  o: mi,
  /**
   * @type string[]
   */
  ignoreTags: [],
  /**
   * @param {IntermediateRepresentation} ir
   * @returns {any}
   */
  defaultRender(n) {
    return n;
  },
  /**
   * Returns true or false based on whether a token should be displayed as a
   * link based on the user options.
   * @param {MultiToken} token
   * @returns {boolean}
   */
  check(n) {
    return this.get("validate", n.toString(), n);
  },
  // Private methods
  /**
   * Resolve an option's value based on the value of the option and the given
   * params. If operator and token are specified and the target option is
   * callable, automatically calls the function with the given argument.
   * @template {keyof Opts} K
   * @param {K} key Name of option to use
   * @param {string} [operator] will be passed to the target option if it's a
   * function. If not specified, RAW function value gets returned
   * @param {MultiToken} [token] The token from linkify.tokenize
   * @returns {Opts[K] | any}
   */
  get(n, e, t) {
    const r = e != null;
    let i = this.o[n];
    return i && (typeof i == "object" ? (i = t.t in i ? i[t.t] : mi[n], typeof i == "function" && r && (i = i(e, t))) : typeof i == "function" && r && (i = i(e, t.t, t)), i);
  },
  /**
   * @template {keyof Opts} L
   * @param {L} key Name of options object to use
   * @param {string} [operator]
   * @param {MultiToken} [token]
   * @returns {Opts[L] | any}
   */
  getObj(n, e, t) {
    let r = this.o[n];
    return typeof r == "function" && e != null && (r = r(e, t.t, t)), r;
  },
  /**
   * Convert the given token to a rendered element that may be added to the
   * calling-interface's DOM
   * @param {MultiToken} token Token to render to an HTML element
   * @returns {any} Render result; e.g., HTML string, DOM element, React
   *   Component, etc.
   */
  render(n) {
    const e = n.render(this);
    return (this.get("render", null, n) || this.defaultRender)(e, n.t, n);
  }
};
function zd(n) {
  return n;
}
function mm(n, e) {
  this.t = "token", this.v = n, this.tk = e;
}
mm.prototype = {
  isLink: !1,
  /**
   * Return the string this token represents.
   * @return {string}
   */
  toString() {
    return this.v;
  },
  /**
   * What should the value for this token be in the `href` HTML attribute?
   * Returns the `.toString` value by default.
   * @param {string} [scheme]
   * @return {string}
   */
  toHref(n) {
    return this.toString();
  },
  /**
   * @param {Options} options Formatting options
   * @returns {string}
   */
  toFormattedString(n) {
    const e = this.toString(), t = n.get("truncate", e, this), r = n.get("format", e, this);
    return t && r.length > t ? r.substring(0, t) + "…" : r;
  },
  /**
   *
   * @param {Options} options
   * @returns {string}
   */
  toFormattedHref(n) {
    return n.get("formatHref", this.toHref(n.get("defaultProtocol")), this);
  },
  /**
   * The start index of this token in the original input string
   * @returns {number}
   */
  startIndex() {
    return this.tk[0].s;
  },
  /**
   * The end index of this token in the original input string (up to this
   * index but not including it)
   * @returns {number}
   */
  endIndex() {
    return this.tk[this.tk.length - 1].e;
  },
  /**
  	Returns an object  of relevant values for this token, which includes keys
  	* type - Kind of token ('url', 'email', etc.)
  	* value - Original text
  	* href - The value that should be added to the anchor tag's href
  		attribute
  		@method toObject
  	@param {string} [protocol] `'http'` by default
  */
  toObject(n = mi.defaultProtocol) {
    return {
      type: this.t,
      value: this.toString(),
      isLink: this.isLink,
      href: this.toHref(n),
      start: this.startIndex(),
      end: this.endIndex()
    };
  },
  /**
   *
   * @param {Options} options Formatting option
   */
  toFormattedObject(n) {
    return {
      type: this.t,
      value: this.toFormattedString(n),
      isLink: this.isLink,
      href: this.toFormattedHref(n),
      start: this.startIndex(),
      end: this.endIndex()
    };
  },
  /**
   * Whether this token should be rendered as a link according to the given options
   * @param {Options} options
   * @returns {boolean}
   */
  validate(n) {
    return n.get("validate", this.toString(), this);
  },
  /**
   * Return an object that represents how this link should be rendered.
   * @param {Options} options Formattinng options
   */
  render(n) {
    const e = this, t = this.toHref(n.get("defaultProtocol")), r = n.get("formatHref", t, this), i = n.get("tagName", t, e), s = this.toFormattedString(n), o = {}, l = n.get("className", t, e), a = n.get("target", t, e), c = n.get("rel", t, e), u = n.getObj("attributes", t, e), d = n.getObj("events", t, e);
    return o.href = r, l && (o.class = l), a && (o.target = a), c && (o.rel = c), u && Object.assign(o, u), {
      tagName: i,
      attributes: o,
      content: s,
      eventListeners: d
    };
  }
};
function ko(n, e) {
  class t extends mm {
    constructor(i, s) {
      super(i, s), this.t = n;
    }
  }
  for (const r in e)
    t.prototype[r] = e[r];
  return t.t = n, t;
}
const Hd = ko("email", {
  isLink: !0,
  toHref() {
    return "mailto:" + this.toString();
  }
}), qd = ko("text"), xE = ko("nl"), Zi = ko("url", {
  isLink: !0,
  /**
  	Lowercases relevant parts of the domain and adds the protocol if
  	required. Note that this will not escape unsafe HTML characters in the
  	URL.
  		@param {string} [scheme] default scheme (e.g., 'https')
  	@return {string} the full href
  */
  toHref(n = mi.defaultProtocol) {
    return this.hasProtocol() ? this.v : `${n}://${this.v}`;
  },
  /**
   * Check whether this URL token has a protocol
   * @return {boolean}
   */
  hasProtocol() {
    const n = this.tk;
    return n.length >= 2 && n[0].t !== pi && n[1].t === dn;
  }
}), nt = (n) => new Ke(n);
function TE({
  groups: n
}) {
  const e = n.domain.concat([Us, Ws, an, Ks, Gs, Js, Ys, Xs, it, Ha, ei, Zs, Qs, eo, Tt, no, ni, to]), t = [js, dn, Va, xt, Ua, ei, ti, ja, Wa, Ns, Is, Zr, Qr, Fs, Ms, $s, Os, Rs, Ls, Ps, Bs, zs, Hs, qs, Vs], r = [Us, js, Ws, Ks, Gs, Js, Ys, Xs, it, Zr, Qr, ei, Zs, Qs, eo, ti, Tt, no, ni, to], i = nt(), s = x(i, ni);
  U(s, r, s), U(s, n.domain, s);
  const o = nt(), l = nt(), a = nt();
  U(i, n.domain, o), U(i, n.scheme, l), U(i, n.slashscheme, a), U(o, r, s), U(o, n.domain, o);
  const c = x(o, an);
  x(s, an, c), x(l, an, c), x(a, an, c);
  const u = x(s, xt);
  U(u, r, s), U(u, n.domain, s);
  const d = nt();
  U(c, n.domain, d), U(d, n.domain, d);
  const f = x(d, xt);
  U(f, n.domain, d);
  const h = nt(Hd);
  U(f, n.tld, h), U(f, n.utld, h), x(c, pi, h);
  const p = x(d, it);
  x(p, it, p), U(p, n.domain, d), U(h, n.domain, d), x(h, xt, f), x(h, it, p);
  const m = x(h, dn);
  U(m, n.numeric, Hd);
  const _ = x(o, it), b = x(o, xt);
  x(_, it, _), U(_, n.domain, o), U(b, r, s), U(b, n.domain, o);
  const y = nt(Zi);
  U(b, n.tld, y), U(b, n.utld, y), U(y, n.domain, o), U(y, r, s), x(y, xt, b), x(y, it, _), x(y, an, c);
  const g = x(y, dn), w = nt(Zi);
  U(g, n.numeric, w);
  const E = nt(Zi), v = nt();
  U(E, e, E), U(E, t, v), U(v, e, E), U(v, t, v), x(y, Tt, E), x(w, Tt, E);
  const D = x(l, dn), S = x(a, dn), C = x(S, Tt), F = x(C, Tt);
  U(l, n.domain, o), x(l, xt, b), x(l, it, _), U(a, n.domain, o), x(a, xt, b), x(a, it, _), U(D, n.domain, E), x(D, Tt, E), x(D, ti, E), U(F, n.domain, E), U(F, e, E), x(F, Tt, E);
  const N = [
    [Zr, Qr],
    // {}
    [Ms, Fs],
    // []
    [$s, Os],
    // ()
    [Ns, Is],
    // <>
    [Rs, Ls],
    // （）
    [Ps, Bs],
    // 「」
    [zs, Hs],
    // 『』
    [qs, Vs]
    // ＜＞
  ];
  for (let H = 0; H < N.length; H++) {
    const [ke, Q] = N[H], ce = x(E, ke);
    x(v, ke, ce), x(ce, Q, E);
    const K = nt(Zi);
    U(ce, e, K);
    const pe = nt();
    U(ce, t), U(K, e, K), U(K, t, pe), U(pe, e, K), U(pe, t, pe), x(K, Q, E), x(pe, Q, E);
  }
  return x(i, pi, y), x(i, qa, xE), {
    start: i,
    tokens: hm
  };
}
function ME(n, e, t) {
  let r = t.length, i = 0, s = [], o = [];
  for (; i < r; ) {
    let l = n, a = null, c = null, u = 0, d = null, f = -1;
    for (; i < r && !(a = l.go(t[i].t)); )
      o.push(t[i++]);
    for (; i < r && (c = a || l.go(t[i].t)); )
      a = null, l = c, l.accepts() ? (f = 0, d = l) : f >= 0 && f++, i++, u++;
    if (f < 0)
      i -= u, i < r && (o.push(t[i]), i++);
    else {
      o.length > 0 && (s.push(ml(qd, e, o)), o = []), i -= f, u -= f;
      const h = d.t, p = t.slice(i - u, i);
      s.push(ml(h, e, p));
    }
  }
  return o.length > 0 && s.push(ml(qd, e, o)), s;
}
function ml(n, e, t) {
  const r = t[0].s, i = t[t.length - 1].e, s = e.slice(r, i);
  return new n(s, t);
}
const FE = typeof console < "u" && console && console.warn || (() => {
}), $E = "until manual call of linkify.init(). Register all schemes and plugins before invoking linkify the first time.", te = {
  scanner: null,
  parser: null,
  tokenQueue: [],
  pluginQueue: [],
  customSchemes: [],
  initialized: !1
};
function OE() {
  return Ke.groups = {}, te.scanner = null, te.parser = null, te.tokenQueue = [], te.pluginQueue = [], te.customSchemes = [], te.initialized = !1, te;
}
function Vd(n, e = !1) {
  if (te.initialized && FE(`linkifyjs: already initialized - will not register custom scheme "${n}" ${$E}`), !/^[0-9a-z]+(-[0-9a-z]+)*$/.test(n))
    throw new Error(`linkifyjs: incorrect scheme format.
1. Must only contain digits, lowercase ASCII letters or "-"
2. Cannot start or end with "-"
3. "-" cannot repeat`);
  te.customSchemes.push([n, e]);
}
function NE() {
  te.scanner = CE(te.customSchemes);
  for (let n = 0; n < te.tokenQueue.length; n++)
    te.tokenQueue[n][1]({
      scanner: te.scanner
    });
  te.parser = TE(te.scanner.tokens);
  for (let n = 0; n < te.pluginQueue.length; n++)
    te.pluginQueue[n][1]({
      scanner: te.scanner,
      parser: te.parser
    });
  return te.initialized = !0, te;
}
function Ga(n) {
  return te.initialized || NE(), ME(te.parser.start, n, pm(te.scanner.start, n));
}
Ga.scan = pm;
function gm(n, e = null, t = null) {
  if (e && typeof e == "object") {
    if (t)
      throw Error(`linkifyjs: Invalid link type ${e}; must be a string`);
    t = e, e = null;
  }
  const r = new Ka(t), i = Ga(n), s = [];
  for (let o = 0; o < i.length; o++) {
    const l = i[o];
    l.isLink && (!e || l.t === e) && r.check(l) && s.push(l.toFormattedObject(r));
  }
  return s;
}
var Ja = "[\0-   ᠎ -\u2029 　]", IE = new RegExp(Ja), RE = new RegExp(`${Ja}$`), LE = new RegExp(Ja, "g");
function PE(n) {
  return n.length === 1 ? n[0].isLink : n.length === 3 && n[1].isLink ? ["()", "[]"].includes(n[0].value + n[2].value) : !1;
}
function BE(n) {
  return new ae({
    key: new _e("autolink"),
    appendTransaction: (e, t, r) => {
      const i = e.some((c) => c.docChanged) && !t.doc.eq(r.doc), s = e.some((c) => c.getMeta("preventAutolink"));
      if (!i || s)
        return;
      const { tr: o } = r, l = Fp(t.doc, [...e]);
      if (zp(l).forEach(({ newRange: c }) => {
        const u = uw(r.doc, c, (h) => h.isTextblock);
        let d, f;
        if (u.length > 1)
          d = u[0], f = r.doc.textBetween(
            d.pos,
            d.pos + d.node.nodeSize,
            void 0,
            " "
          );
        else if (u.length) {
          const h = r.doc.textBetween(c.from, c.to, " ", " ");
          if (!RE.test(h))
            return;
          d = u[0], f = r.doc.textBetween(d.pos, c.to, void 0, " ");
        }
        if (d && f) {
          const h = f.split(IE).filter(Boolean);
          if (h.length <= 0)
            return !1;
          const p = h[h.length - 1], m = d.pos + f.lastIndexOf(p);
          if (!p)
            return !1;
          const _ = Ga(p).map((b) => b.toObject(n.defaultProtocol));
          if (!PE(_))
            return !1;
          _.filter((b) => b.isLink).map((b) => ({
            ...b,
            from: m + b.start + 1,
            to: m + b.end + 1
          })).filter((b) => r.schema.marks.code ? !r.doc.rangeHasMark(b.from, b.to, r.schema.marks.code) : !0).filter((b) => n.validate(b.value)).filter((b) => n.shouldAutoLink(b.value)).forEach((b) => {
            Pa(b.from, b.to, r.doc).some((y) => y.mark.type === n.type) || o.addMark(
              b.from,
              b.to,
              n.type.create({
                href: b.href
              })
            );
          });
        }
      }), !!o.steps.length)
        return o;
    }
  });
}
function zE(n) {
  return new ae({
    key: new _e("handleClickLink"),
    props: {
      handleClick: (e, t, r) => {
        var i, s;
        if (r.button !== 0 || !e.editable)
          return !1;
        let o = null;
        if (r.target instanceof HTMLAnchorElement)
          o = r.target;
        else {
          let u = r.target;
          const d = [];
          for (; u.nodeName !== "DIV"; )
            d.push(u), u = u.parentNode;
          o = d.find((f) => f.nodeName === "A");
        }
        if (!o)
          return !1;
        const l = Bp(e.state, n.type.name), a = (i = o == null ? void 0 : o.href) != null ? i : l.href, c = (s = o == null ? void 0 : o.target) != null ? s : l.target;
        return n.enableClickSelection && n.editor.commands.extendMarkRange(n.type.name), o && a ? (window.open(a, c), !0) : !1;
      }
    }
  });
}
function HE(n) {
  return new ae({
    key: new _e("handlePasteLink"),
    props: {
      handlePaste: (e, t, r) => {
        const { state: i } = e, { selection: s } = i, { empty: o } = s;
        if (o)
          return !1;
        let l = "";
        r.content.forEach((c) => {
          l += c.textContent;
        });
        const a = gm(l, { defaultProtocol: n.defaultProtocol }).find(
          (c) => c.isLink && c.value === l
        );
        return !l || !a ? !1 : n.editor.commands.setMark(n.type, {
          href: a.href
        });
      }
    }
  });
}
function Cn(n, e) {
  const t = ["http", "https", "ftp", "ftps", "mailto", "tel", "callto", "sms", "cid", "xmpp"];
  return e && e.forEach((r) => {
    const i = typeof r == "string" ? r : r.scheme;
    i && t.push(i);
  }), !n || n.replace(LE, "").match(
    new RegExp(
      // eslint-disable-next-line no-useless-escape
      `^(?:(?:${t.join("|")}):|[^a-z]|[a-z0-9+.-]+(?:[^a-z+.-:]|$))`,
      "i"
    )
  );
}
var _m = Kn.create({
  name: "link",
  priority: 1e3,
  keepOnSplit: !1,
  exitable: !0,
  onCreate() {
    this.options.validate && !this.options.shouldAutoLink && (this.options.shouldAutoLink = this.options.validate, console.warn("The `validate` option is deprecated. Rename to the `shouldAutoLink` option instead.")), this.options.protocols.forEach((n) => {
      if (typeof n == "string") {
        Vd(n);
        return;
      }
      Vd(n.scheme, n.optionalSlashes);
    });
  },
  onDestroy() {
    OE();
  },
  inclusive() {
    return this.options.autolink;
  },
  addOptions() {
    return {
      openOnClick: !0,
      enableClickSelection: !1,
      linkOnPaste: !0,
      autolink: !0,
      protocols: [],
      defaultProtocol: "http",
      HTMLAttributes: {
        target: "_blank",
        rel: "noopener noreferrer nofollow",
        class: null
      },
      isAllowedUri: (n, e) => !!Cn(n, e.protocols),
      validate: (n) => !!n,
      shouldAutoLink: (n) => !!n
    };
  },
  addAttributes() {
    return {
      href: {
        default: null,
        parseHTML(n) {
          return n.getAttribute("href");
        }
      },
      target: {
        default: this.options.HTMLAttributes.target
      },
      rel: {
        default: this.options.HTMLAttributes.rel
      },
      class: {
        default: this.options.HTMLAttributes.class
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "a[href]",
        getAttrs: (n) => {
          const e = n.getAttribute("href");
          return !e || !this.options.isAllowedUri(e, {
            defaultValidate: (t) => !!Cn(t, this.options.protocols),
            protocols: this.options.protocols,
            defaultProtocol: this.options.defaultProtocol
          }) ? !1 : null;
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return this.options.isAllowedUri(n.href, {
      defaultValidate: (e) => !!Cn(e, this.options.protocols),
      protocols: this.options.protocols,
      defaultProtocol: this.options.defaultProtocol
    }) ? ["a", fe(this.options.HTMLAttributes, n), 0] : ["a", fe(this.options.HTMLAttributes, { ...n, href: "" }), 0];
  },
  addCommands() {
    return {
      setLink: (n) => ({ chain: e }) => {
        const { href: t } = n;
        return this.options.isAllowedUri(t, {
          defaultValidate: (r) => !!Cn(r, this.options.protocols),
          protocols: this.options.protocols,
          defaultProtocol: this.options.defaultProtocol
        }) ? e().setMark(this.name, n).setMeta("preventAutolink", !0).run() : !1;
      },
      toggleLink: (n) => ({ chain: e }) => {
        const { href: t } = n || {};
        return t && !this.options.isAllowedUri(t, {
          defaultValidate: (r) => !!Cn(r, this.options.protocols),
          protocols: this.options.protocols,
          defaultProtocol: this.options.defaultProtocol
        }) ? !1 : e().toggleMark(this.name, n, { extendEmptyMarkRange: !0 }).setMeta("preventAutolink", !0).run();
      },
      unsetLink: () => ({ chain: n }) => n().unsetMark(this.name, { extendEmptyMarkRange: !0 }).setMeta("preventAutolink", !0).run()
    };
  },
  addPasteRules() {
    return [
      Vn({
        find: (n) => {
          const e = [];
          if (n) {
            const { protocols: t, defaultProtocol: r } = this.options, i = gm(n).filter(
              (s) => s.isLink && this.options.isAllowedUri(s.value, {
                defaultValidate: (o) => !!Cn(o, t),
                protocols: t,
                defaultProtocol: r
              })
            );
            i.length && i.forEach(
              (s) => e.push({
                text: s.value,
                data: {
                  href: s.href
                },
                index: s.start
              })
            );
          }
          return e;
        },
        type: this.type,
        getAttributes: (n) => {
          var e;
          return {
            href: (e = n.data) == null ? void 0 : e.href
          };
        }
      })
    ];
  },
  addProseMirrorPlugins() {
    const n = [], { protocols: e, defaultProtocol: t } = this.options;
    return this.options.autolink && n.push(
      BE({
        type: this.type,
        defaultProtocol: this.options.defaultProtocol,
        validate: (r) => this.options.isAllowedUri(r, {
          defaultValidate: (i) => !!Cn(i, e),
          protocols: e,
          defaultProtocol: t
        }),
        shouldAutoLink: this.options.shouldAutoLink
      })
    ), this.options.openOnClick === !0 && n.push(
      zE({
        type: this.type,
        editor: this.editor,
        enableClickSelection: this.options.enableClickSelection
      })
    ), this.options.linkOnPaste && n.push(
      HE({
        editor: this.editor,
        defaultProtocol: this.options.defaultProtocol,
        type: this.type
      })
    ), n;
  }
}), qE = _m, VE = Object.defineProperty, UE = (n, e) => {
  for (var t in e)
    VE(n, t, { get: e[t], enumerable: !0 });
}, jE = "listItem", Ud = "textStyle", jd = /^\s*([-+*])\s$/, ym = Je.create({
  name: "bulletList",
  addOptions() {
    return {
      itemTypeName: "listItem",
      HTMLAttributes: {},
      keepMarks: !1,
      keepAttributes: !1
    };
  },
  group: "block list",
  content() {
    return `${this.options.itemTypeName}+`;
  },
  parseHTML() {
    return [{ tag: "ul" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["ul", fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      toggleBulletList: () => ({ commands: n, chain: e }) => this.options.keepAttributes ? e().toggleList(this.name, this.options.itemTypeName, this.options.keepMarks).updateAttributes(jE, this.editor.getAttributes(Ud)).run() : n.toggleList(this.name, this.options.itemTypeName, this.options.keepMarks)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-8": () => this.editor.commands.toggleBulletList()
    };
  },
  addInputRules() {
    let n = vr({
      find: jd,
      type: this.type
    });
    return (this.options.keepMarks || this.options.keepAttributes) && (n = vr({
      find: jd,
      type: this.type,
      keepMarks: this.options.keepMarks,
      keepAttributes: this.options.keepAttributes,
      getAttributes: () => this.editor.getAttributes(Ud),
      editor: this.editor
    })), [n];
  }
}), bm = Je.create({
  name: "listItem",
  addOptions() {
    return {
      HTMLAttributes: {},
      bulletListTypeName: "bulletList",
      orderedListTypeName: "orderedList"
    };
  },
  content: "paragraph block*",
  defining: !0,
  parseHTML() {
    return [
      {
        tag: "li"
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["li", fe(this.options.HTMLAttributes, n), 0];
  },
  addKeyboardShortcuts() {
    return {
      Enter: () => this.editor.commands.splitListItem(this.name),
      Tab: () => this.editor.commands.sinkListItem(this.name),
      "Shift-Tab": () => this.editor.commands.liftListItem(this.name)
    };
  }
}), WE = {};
UE(WE, {
  findListItemPos: () => wi,
  getNextListDepth: () => Ya,
  handleBackspace: () => ia,
  handleDelete: () => sa,
  hasListBefore: () => km,
  hasListItemAfter: () => KE,
  hasListItemBefore: () => wm,
  listItemHasSubList: () => vm,
  nextListIsDeeper: () => Em,
  nextListIsHigher: () => Dm
});
var wi = (n, e) => {
  const { $from: t } = e.selection, r = ge(n, e.schema);
  let i = null, s = t.depth, o = t.pos, l = null;
  for (; s > 0 && l === null; )
    i = t.node(s), i.type === r ? l = s : (s -= 1, o -= 1);
  return l === null ? null : { $pos: e.doc.resolve(o), depth: l };
}, Ya = (n, e) => {
  const t = wi(n, e);
  if (!t)
    return !1;
  const [, r] = kw(e, n, t.$pos.pos + 4);
  return r;
}, km = (n, e, t) => {
  const { $anchor: r } = n.selection, i = Math.max(0, r.pos - 2), s = n.doc.resolve(i).node();
  return !(!s || !t.includes(s.type.name));
}, wm = (n, e) => {
  var t;
  const { $anchor: r } = e.selection, i = e.doc.resolve(r.pos - 2);
  return !(i.index() === 0 || ((t = i.nodeBefore) == null ? void 0 : t.type.name) !== n);
}, vm = (n, e, t) => {
  if (!t)
    return !1;
  const r = ge(n, e.schema);
  let i = !1;
  return t.descendants((s) => {
    s.type === r && (i = !0);
  }), i;
}, ia = (n, e, t) => {
  if (n.commands.undoInputRule())
    return !0;
  if (n.state.selection.from !== n.state.selection.to)
    return !1;
  if (!kn(n.state, e) && km(n.state, e, t)) {
    const { $anchor: l } = n.state.selection, a = n.state.doc.resolve(l.before() - 1), c = [];
    a.node().descendants((f, h) => {
      f.type.name === e && c.push({ node: f, pos: h });
    });
    const u = c.at(-1);
    if (!u)
      return !1;
    const d = n.state.doc.resolve(a.start() + u.pos + 1);
    return n.chain().cut({ from: l.start() - 1, to: l.end() + 1 }, d.end()).joinForward().run();
  }
  if (!kn(n.state, e) || !Dw(n.state))
    return !1;
  const r = wi(e, n.state);
  if (!r)
    return !1;
  const s = n.state.doc.resolve(r.$pos.pos - 2).node(r.depth), o = vm(e, n.state, s);
  return wm(e, n.state) && !o ? n.commands.joinItemBackward() : n.chain().liftListItem(e).run();
}, Em = (n, e) => {
  const t = Ya(n, e), r = wi(n, e);
  return !r || !t ? !1 : t > r.depth;
}, Dm = (n, e) => {
  const t = Ya(n, e), r = wi(n, e);
  return !r || !t ? !1 : t < r.depth;
}, sa = (n, e) => {
  if (!kn(n.state, e) || !Ew(n.state, e))
    return !1;
  const { selection: t } = n.state, { $from: r, $to: i } = t;
  return !t.empty && r.sameParent(i) ? !1 : Em(e, n.state) ? n.chain().focus(n.state.selection.from + 4).lift(e).joinBackward().run() : Dm(e, n.state) ? n.chain().joinForward().joinBackward().run() : n.commands.joinItemForward();
}, KE = (n, e) => {
  var t;
  const { $anchor: r } = e.selection, i = e.doc.resolve(r.pos - r.parentOffset - 2);
  return !(i.index() === i.parent.childCount - 1 || ((t = i.nodeAfter) == null ? void 0 : t.type.name) !== n);
}, Sm = he.create({
  name: "listKeymap",
  addOptions() {
    return {
      listTypes: [
        {
          itemName: "listItem",
          wrapperNames: ["bulletList", "orderedList"]
        },
        {
          itemName: "taskItem",
          wrapperNames: ["taskList"]
        }
      ]
    };
  },
  addKeyboardShortcuts() {
    return {
      Delete: ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t }) => {
          n.state.schema.nodes[t] !== void 0 && sa(n, t) && (e = !0);
        }), e;
      },
      "Mod-Delete": ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t }) => {
          n.state.schema.nodes[t] !== void 0 && sa(n, t) && (e = !0);
        }), e;
      },
      Backspace: ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t, wrapperNames: r }) => {
          n.state.schema.nodes[t] !== void 0 && ia(n, t, r) && (e = !0);
        }), e;
      },
      "Mod-Backspace": ({ editor: n }) => {
        let e = !1;
        return this.options.listTypes.forEach(({ itemName: t, wrapperNames: r }) => {
          n.state.schema.nodes[t] !== void 0 && ia(n, t, r) && (e = !0);
        }), e;
      }
    };
  }
}), GE = "listItem", Wd = "textStyle", Kd = /^(\d+)\.\s$/, Cm = Je.create({
  name: "orderedList",
  addOptions() {
    return {
      itemTypeName: "listItem",
      HTMLAttributes: {},
      keepMarks: !1,
      keepAttributes: !1
    };
  },
  group: "block list",
  content() {
    return `${this.options.itemTypeName}+`;
  },
  addAttributes() {
    return {
      start: {
        default: 1,
        parseHTML: (n) => n.hasAttribute("start") ? parseInt(n.getAttribute("start") || "", 10) : 1
      },
      type: {
        default: null,
        parseHTML: (n) => n.getAttribute("type")
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "ol"
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    const { start: e, ...t } = n;
    return e === 1 ? ["ol", fe(this.options.HTMLAttributes, t), 0] : ["ol", fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      toggleOrderedList: () => ({ commands: n, chain: e }) => this.options.keepAttributes ? e().toggleList(this.name, this.options.itemTypeName, this.options.keepMarks).updateAttributes(GE, this.editor.getAttributes(Wd)).run() : n.toggleList(this.name, this.options.itemTypeName, this.options.keepMarks)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-7": () => this.editor.commands.toggleOrderedList()
    };
  },
  addInputRules() {
    let n = vr({
      find: Kd,
      type: this.type,
      getAttributes: (e) => ({ start: +e[1] }),
      joinPredicate: (e, t) => t.childCount + t.attrs.start === +e[1]
    });
    return (this.options.keepMarks || this.options.keepAttributes) && (n = vr({
      find: Kd,
      type: this.type,
      keepMarks: this.options.keepMarks,
      keepAttributes: this.options.keepAttributes,
      getAttributes: (e) => ({ start: +e[1], ...this.editor.getAttributes(Wd) }),
      joinPredicate: (e, t) => t.childCount + t.attrs.start === +e[1],
      editor: this.editor
    })), [n];
  }
}), JE = /^\s*(\[([( |x])?\])\s$/, YE = Je.create({
  name: "taskItem",
  addOptions() {
    return {
      nested: !1,
      HTMLAttributes: {},
      taskListTypeName: "taskList",
      a11y: void 0
    };
  },
  content() {
    return this.options.nested ? "paragraph block*" : "paragraph+";
  },
  defining: !0,
  addAttributes() {
    return {
      checked: {
        default: !1,
        keepOnSplit: !1,
        parseHTML: (n) => {
          const e = n.getAttribute("data-checked");
          return e === "" || e === "true";
        },
        renderHTML: (n) => ({
          "data-checked": n.checked
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: `li[data-type="${this.name}"]`,
        priority: 51
      }
    ];
  },
  renderHTML({ node: n, HTMLAttributes: e }) {
    return [
      "li",
      fe(this.options.HTMLAttributes, e, {
        "data-type": this.name
      }),
      [
        "label",
        [
          "input",
          {
            type: "checkbox",
            checked: n.attrs.checked ? "checked" : null
          }
        ],
        ["span"]
      ],
      ["div", 0]
    ];
  },
  addKeyboardShortcuts() {
    const n = {
      Enter: () => this.editor.commands.splitListItem(this.name),
      "Shift-Tab": () => this.editor.commands.liftListItem(this.name)
    };
    return this.options.nested ? {
      ...n,
      Tab: () => this.editor.commands.sinkListItem(this.name)
    } : n;
  },
  addNodeView() {
    return ({ node: n, HTMLAttributes: e, getPos: t, editor: r }) => {
      const i = document.createElement("li"), s = document.createElement("label"), o = document.createElement("span"), l = document.createElement("input"), a = document.createElement("div"), c = () => {
        var u, d;
        l.ariaLabel = ((d = (u = this.options.a11y) == null ? void 0 : u.checkboxLabel) == null ? void 0 : d.call(u, n, l.checked)) || `Task item checkbox for ${n.textContent || "empty task item"}`;
      };
      return c(), s.contentEditable = "false", l.type = "checkbox", l.addEventListener("mousedown", (u) => u.preventDefault()), l.addEventListener("change", (u) => {
        if (!r.isEditable && !this.options.onReadOnlyChecked) {
          l.checked = !l.checked;
          return;
        }
        const { checked: d } = u.target;
        r.isEditable && typeof t == "function" && r.chain().focus(void 0, { scrollIntoView: !1 }).command(({ tr: f }) => {
          const h = t();
          if (typeof h != "number")
            return !1;
          const p = f.doc.nodeAt(h);
          return f.setNodeMarkup(h, void 0, {
            ...p == null ? void 0 : p.attrs,
            checked: d
          }), !0;
        }).run(), !r.isEditable && this.options.onReadOnlyChecked && (this.options.onReadOnlyChecked(n, d) || (l.checked = !l.checked));
      }), Object.entries(this.options.HTMLAttributes).forEach(([u, d]) => {
        i.setAttribute(u, d);
      }), i.dataset.checked = n.attrs.checked, l.checked = n.attrs.checked, s.append(l, o), i.append(s, a), Object.entries(e).forEach(([u, d]) => {
        i.setAttribute(u, d);
      }), {
        dom: i,
        contentDOM: a,
        update: (u) => u.type !== this.type ? !1 : (i.dataset.checked = u.attrs.checked, l.checked = u.attrs.checked, c(), !0)
      };
    };
  },
  addInputRules() {
    return [
      vr({
        find: JE,
        type: this.type,
        getAttributes: (n) => ({
          checked: n[n.length - 1] === "x"
        })
      })
    ];
  }
}), XE = Je.create({
  name: "taskList",
  addOptions() {
    return {
      itemTypeName: "taskItem",
      HTMLAttributes: {}
    };
  },
  group: "block list",
  content() {
    return `${this.options.itemTypeName}+`;
  },
  parseHTML() {
    return [
      {
        tag: `ul[data-type="${this.name}"]`,
        priority: 51
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["ul", fe(this.options.HTMLAttributes, n, { "data-type": this.name }), 0];
  },
  addCommands() {
    return {
      toggleTaskList: () => ({ commands: n }) => n.toggleList(this.name, this.options.itemTypeName)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-9": () => this.editor.commands.toggleTaskList()
    };
  }
});
he.create({
  name: "listKit",
  addExtensions() {
    const n = [];
    return this.options.bulletList !== !1 && n.push(ym.configure(this.options.bulletList)), this.options.listItem !== !1 && n.push(bm.configure(this.options.listItem)), this.options.listKeymap !== !1 && n.push(Sm.configure(this.options.listKeymap)), this.options.orderedList !== !1 && n.push(Cm.configure(this.options.orderedList)), this.options.taskItem !== !1 && n.push(YE.configure(this.options.taskItem)), this.options.taskList !== !1 && n.push(XE.configure(this.options.taskList)), n;
  }
});
var ZE = Je.create({
  name: "paragraph",
  priority: 1e3,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  group: "block",
  content: "inline*",
  parseHTML() {
    return [{ tag: "p" }];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["p", fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setParagraph: () => ({ commands: n }) => n.setNode(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Alt-0": () => this.editor.commands.setParagraph()
    };
  }
}), QE = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))$/, eD = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))/g, tD = Kn.create({
  name: "strike",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "s"
      },
      {
        tag: "del"
      },
      {
        tag: "strike"
      },
      {
        style: "text-decoration",
        consuming: !1,
        getAttrs: (n) => n.includes("line-through") ? {} : !1
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["s", fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setStrike: () => ({ commands: n }) => n.setMark(this.name),
      toggleStrike: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetStrike: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-s": () => this.editor.commands.toggleStrike()
    };
  },
  addInputRules() {
    return [
      wr({
        find: QE,
        type: this.type
      })
    ];
  },
  addPasteRules() {
    return [
      Vn({
        find: eD,
        type: this.type
      })
    ];
  }
}), nD = Je.create({
  name: "text",
  group: "inline"
}), rD = Kn.create({
  name: "underline",
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  parseHTML() {
    return [
      {
        tag: "u"
      },
      {
        style: "text-decoration",
        consuming: !1,
        getAttrs: (n) => n.includes("underline") ? {} : !1
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["u", fe(this.options.HTMLAttributes, n), 0];
  },
  addCommands() {
    return {
      setUnderline: () => ({ commands: n }) => n.setMark(this.name),
      toggleUnderline: () => ({ commands: n }) => n.toggleMark(this.name),
      unsetUnderline: () => ({ commands: n }) => n.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-u": () => this.editor.commands.toggleUnderline(),
      "Mod-U": () => this.editor.commands.toggleUnderline()
    };
  }
});
function iD(n = {}) {
  return new ae({
    view(e) {
      return new sD(e, n);
    }
  });
}
class sD {
  constructor(e, t) {
    var r;
    this.editorView = e, this.cursorPos = null, this.element = null, this.timeout = -1, this.width = (r = t.width) !== null && r !== void 0 ? r : 1, this.color = t.color === !1 ? void 0 : t.color || "black", this.class = t.class, this.handlers = ["dragover", "dragend", "drop", "dragleave"].map((i) => {
      let s = (o) => {
        this[i](o);
      };
      return e.dom.addEventListener(i, s), { name: i, handler: s };
    });
  }
  destroy() {
    this.handlers.forEach(({ name: e, handler: t }) => this.editorView.dom.removeEventListener(e, t));
  }
  update(e, t) {
    this.cursorPos != null && t.doc != e.state.doc && (this.cursorPos > e.state.doc.content.size ? this.setCursor(null) : this.updateOverlay());
  }
  setCursor(e) {
    e != this.cursorPos && (this.cursorPos = e, e == null ? (this.element.parentNode.removeChild(this.element), this.element = null) : this.updateOverlay());
  }
  updateOverlay() {
    let e = this.editorView.state.doc.resolve(this.cursorPos), t = !e.parent.inlineContent, r, i = this.editorView.dom, s = i.getBoundingClientRect(), o = s.width / i.offsetWidth, l = s.height / i.offsetHeight;
    if (t) {
      let d = e.nodeBefore, f = e.nodeAfter;
      if (d || f) {
        let h = this.editorView.nodeDOM(this.cursorPos - (d ? d.nodeSize : 0));
        if (h) {
          let p = h.getBoundingClientRect(), m = d ? p.bottom : p.top;
          d && f && (m = (m + this.editorView.nodeDOM(this.cursorPos).getBoundingClientRect().top) / 2);
          let _ = this.width / 2 * l;
          r = { left: p.left, right: p.right, top: m - _, bottom: m + _ };
        }
      }
    }
    if (!r) {
      let d = this.editorView.coordsAtPos(this.cursorPos), f = this.width / 2 * o;
      r = { left: d.left - f, right: d.left + f, top: d.top, bottom: d.bottom };
    }
    let a = this.editorView.dom.offsetParent;
    this.element || (this.element = a.appendChild(document.createElement("div")), this.class && (this.element.className = this.class), this.element.style.cssText = "position: absolute; z-index: 50; pointer-events: none;", this.color && (this.element.style.backgroundColor = this.color)), this.element.classList.toggle("prosemirror-dropcursor-block", t), this.element.classList.toggle("prosemirror-dropcursor-inline", !t);
    let c, u;
    if (!a || a == document.body && getComputedStyle(a).position == "static")
      c = -pageXOffset, u = -pageYOffset;
    else {
      let d = a.getBoundingClientRect(), f = d.width / a.offsetWidth, h = d.height / a.offsetHeight;
      c = d.left - a.scrollLeft * f, u = d.top - a.scrollTop * h;
    }
    this.element.style.left = (r.left - c) / o + "px", this.element.style.top = (r.top - u) / l + "px", this.element.style.width = (r.right - r.left) / o + "px", this.element.style.height = (r.bottom - r.top) / l + "px";
  }
  scheduleRemoval(e) {
    clearTimeout(this.timeout), this.timeout = setTimeout(() => this.setCursor(null), e);
  }
  dragover(e) {
    if (!this.editorView.editable)
      return;
    let t = this.editorView.posAtCoords({ left: e.clientX, top: e.clientY }), r = t && t.inside >= 0 && this.editorView.state.doc.nodeAt(t.inside), i = r && r.type.spec.disableDropCursor, s = typeof i == "function" ? i(this.editorView, t, e) : i;
    if (t && !s) {
      let o = t.pos;
      if (this.editorView.dragging && this.editorView.dragging.slice) {
        let l = Th(this.editorView.state.doc, o, this.editorView.dragging.slice);
        l != null && (o = l);
      }
      this.setCursor(o), this.scheduleRemoval(5e3);
    }
  }
  dragend() {
    this.scheduleRemoval(20);
  }
  drop() {
    this.scheduleRemoval(20);
  }
  dragleave(e) {
    this.editorView.dom.contains(e.relatedTarget) || this.setCursor(null);
  }
}
class de extends V {
  /**
  Create a gap cursor.
  */
  constructor(e) {
    super(e, e);
  }
  map(e, t) {
    let r = e.resolve(t.map(this.head));
    return de.valid(r) ? new de(r) : V.near(r);
  }
  content() {
    return O.empty;
  }
  eq(e) {
    return e instanceof de && e.head == this.head;
  }
  toJSON() {
    return { type: "gapcursor", pos: this.head };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for GapCursor.fromJSON");
    return new de(e.resolve(t.pos));
  }
  /**
  @internal
  */
  getBookmark() {
    return new Xa(this.anchor);
  }
  /**
  @internal
  */
  static valid(e) {
    let t = e.parent;
    if (t.isTextblock || !oD(e) || !lD(e))
      return !1;
    let r = t.type.spec.allowGapCursor;
    if (r != null)
      return r;
    let i = t.contentMatchAt(e.index()).defaultType;
    return i && i.isTextblock;
  }
  /**
  @internal
  */
  static findGapCursorFrom(e, t, r = !1) {
    e: for (; ; ) {
      if (!r && de.valid(e))
        return e;
      let i = e.pos, s = null;
      for (let o = e.depth; ; o--) {
        let l = e.node(o);
        if (t > 0 ? e.indexAfter(o) < l.childCount : e.index(o) > 0) {
          s = l.child(t > 0 ? e.indexAfter(o) : e.index(o) - 1);
          break;
        } else if (o == 0)
          return null;
        i += t;
        let a = e.doc.resolve(i);
        if (de.valid(a))
          return a;
      }
      for (; ; ) {
        let o = t > 0 ? s.firstChild : s.lastChild;
        if (!o) {
          if (s.isAtom && !s.isText && !B.isSelectable(s)) {
            e = e.doc.resolve(i + s.nodeSize * t), r = !1;
            continue e;
          }
          break;
        }
        s = o, i += t;
        let l = e.doc.resolve(i);
        if (de.valid(l))
          return l;
      }
      return null;
    }
  }
}
de.prototype.visible = !1;
de.findFrom = de.findGapCursorFrom;
V.jsonID("gapcursor", de);
class Xa {
  constructor(e) {
    this.pos = e;
  }
  map(e) {
    return new Xa(e.map(this.pos));
  }
  resolve(e) {
    let t = e.resolve(this.pos);
    return de.valid(t) ? new de(t) : V.near(t);
  }
}
function oD(n) {
  for (let e = n.depth; e >= 0; e--) {
    let t = n.index(e), r = n.node(e);
    if (t == 0) {
      if (r.type.spec.isolating)
        return !0;
      continue;
    }
    for (let i = r.child(t - 1); ; i = i.lastChild) {
      if (i.childCount == 0 && !i.inlineContent || i.isAtom || i.type.spec.isolating)
        return !0;
      if (i.inlineContent)
        return !1;
    }
  }
  return !0;
}
function lD(n) {
  for (let e = n.depth; e >= 0; e--) {
    let t = n.indexAfter(e), r = n.node(e);
    if (t == r.childCount) {
      if (r.type.spec.isolating)
        return !0;
      continue;
    }
    for (let i = r.child(t); ; i = i.firstChild) {
      if (i.childCount == 0 && !i.inlineContent || i.isAtom || i.type.spec.isolating)
        return !0;
      if (i.inlineContent)
        return !1;
    }
  }
  return !0;
}
function aD() {
  return new ae({
    props: {
      decorations: fD,
      createSelectionBetween(n, e, t) {
        return e.pos == t.pos && de.valid(t) ? new de(t) : null;
      },
      handleClick: uD,
      handleKeyDown: cD,
      handleDOMEvents: { beforeinput: dD }
    }
  });
}
const cD = _p({
  ArrowLeft: Qi("horiz", -1),
  ArrowRight: Qi("horiz", 1),
  ArrowUp: Qi("vert", -1),
  ArrowDown: Qi("vert", 1)
});
function Qi(n, e) {
  const t = n == "vert" ? e > 0 ? "down" : "up" : e > 0 ? "right" : "left";
  return function(r, i, s) {
    let o = r.selection, l = e > 0 ? o.$to : o.$from, a = o.empty;
    if (o instanceof z) {
      if (!s.endOfTextblock(t) || l.depth == 0)
        return !1;
      a = !1, l = r.doc.resolve(e > 0 ? l.after() : l.before());
    }
    let c = de.findGapCursorFrom(l, e, a);
    return c ? (i && i(r.tr.setSelection(new de(c))), !0) : !1;
  };
}
function uD(n, e, t) {
  if (!n || !n.editable)
    return !1;
  let r = n.state.doc.resolve(e);
  if (!de.valid(r))
    return !1;
  let i = n.posAtCoords({ left: t.clientX, top: t.clientY });
  return i && i.inside > -1 && B.isSelectable(n.state.doc.nodeAt(i.inside)) ? !1 : (n.dispatch(n.state.tr.setSelection(new de(r))), !0);
}
function dD(n, e) {
  if (e.inputType != "insertCompositionText" || !(n.state.selection instanceof de))
    return !1;
  let { $from: t } = n.state.selection, r = t.parent.contentMatchAt(t.index()).findWrapping(n.state.schema.nodes.text);
  if (!r)
    return !1;
  let i = A.empty;
  for (let o = r.length - 1; o >= 0; o--)
    i = A.from(r[o].createAndFill(null, i));
  let s = n.state.tr.replace(t.pos, t.pos, new O(i, 0, 0));
  return s.setSelection(z.near(s.doc.resolve(t.pos + 1))), n.dispatch(s), !1;
}
function fD(n) {
  if (!(n.selection instanceof de))
    return null;
  let e = document.createElement("div");
  return e.className = "ProseMirror-gapcursor", se.create(n.doc, [Be.widget(n.selection.head, e, { key: "gapcursor" })]);
}
var ro = 200, Se = function() {
};
Se.prototype.append = function(e) {
  return e.length ? (e = Se.from(e), !this.length && e || e.length < ro && this.leafAppend(e) || this.length < ro && e.leafPrepend(this) || this.appendInner(e)) : this;
};
Se.prototype.prepend = function(e) {
  return e.length ? Se.from(e).append(this) : this;
};
Se.prototype.appendInner = function(e) {
  return new hD(this, e);
};
Se.prototype.slice = function(e, t) {
  return e === void 0 && (e = 0), t === void 0 && (t = this.length), e >= t ? Se.empty : this.sliceInner(Math.max(0, e), Math.min(this.length, t));
};
Se.prototype.get = function(e) {
  if (!(e < 0 || e >= this.length))
    return this.getInner(e);
};
Se.prototype.forEach = function(e, t, r) {
  t === void 0 && (t = 0), r === void 0 && (r = this.length), t <= r ? this.forEachInner(e, t, r, 0) : this.forEachInvertedInner(e, t, r, 0);
};
Se.prototype.map = function(e, t, r) {
  t === void 0 && (t = 0), r === void 0 && (r = this.length);
  var i = [];
  return this.forEach(function(s, o) {
    return i.push(e(s, o));
  }, t, r), i;
};
Se.from = function(e) {
  return e instanceof Se ? e : e && e.length ? new Am(e) : Se.empty;
};
var Am = /* @__PURE__ */ function(n) {
  function e(r) {
    n.call(this), this.values = r;
  }
  n && (e.__proto__ = n), e.prototype = Object.create(n && n.prototype), e.prototype.constructor = e;
  var t = { length: { configurable: !0 }, depth: { configurable: !0 } };
  return e.prototype.flatten = function() {
    return this.values;
  }, e.prototype.sliceInner = function(i, s) {
    return i == 0 && s == this.length ? this : new e(this.values.slice(i, s));
  }, e.prototype.getInner = function(i) {
    return this.values[i];
  }, e.prototype.forEachInner = function(i, s, o, l) {
    for (var a = s; a < o; a++)
      if (i(this.values[a], l + a) === !1)
        return !1;
  }, e.prototype.forEachInvertedInner = function(i, s, o, l) {
    for (var a = s - 1; a >= o; a--)
      if (i(this.values[a], l + a) === !1)
        return !1;
  }, e.prototype.leafAppend = function(i) {
    if (this.length + i.length <= ro)
      return new e(this.values.concat(i.flatten()));
  }, e.prototype.leafPrepend = function(i) {
    if (this.length + i.length <= ro)
      return new e(i.flatten().concat(this.values));
  }, t.length.get = function() {
    return this.values.length;
  }, t.depth.get = function() {
    return 0;
  }, Object.defineProperties(e.prototype, t), e;
}(Se);
Se.empty = new Am([]);
var hD = /* @__PURE__ */ function(n) {
  function e(t, r) {
    n.call(this), this.left = t, this.right = r, this.length = t.length + r.length, this.depth = Math.max(t.depth, r.depth) + 1;
  }
  return n && (e.__proto__ = n), e.prototype = Object.create(n && n.prototype), e.prototype.constructor = e, e.prototype.flatten = function() {
    return this.left.flatten().concat(this.right.flatten());
  }, e.prototype.getInner = function(r) {
    return r < this.left.length ? this.left.get(r) : this.right.get(r - this.left.length);
  }, e.prototype.forEachInner = function(r, i, s, o) {
    var l = this.left.length;
    if (i < l && this.left.forEachInner(r, i, Math.min(s, l), o) === !1 || s > l && this.right.forEachInner(r, Math.max(i - l, 0), Math.min(this.length, s) - l, o + l) === !1)
      return !1;
  }, e.prototype.forEachInvertedInner = function(r, i, s, o) {
    var l = this.left.length;
    if (i > l && this.right.forEachInvertedInner(r, i - l, Math.max(s, l) - l, o + l) === !1 || s < l && this.left.forEachInvertedInner(r, Math.min(i, l), s, o) === !1)
      return !1;
  }, e.prototype.sliceInner = function(r, i) {
    if (r == 0 && i == this.length)
      return this;
    var s = this.left.length;
    return i <= s ? this.left.slice(r, i) : r >= s ? this.right.slice(r - s, i - s) : this.left.slice(r, s).append(this.right.slice(0, i - s));
  }, e.prototype.leafAppend = function(r) {
    var i = this.right.leafAppend(r);
    if (i)
      return new e(this.left, i);
  }, e.prototype.leafPrepend = function(r) {
    var i = this.left.leafPrepend(r);
    if (i)
      return new e(i, this.right);
  }, e.prototype.appendInner = function(r) {
    return this.left.depth >= Math.max(this.right.depth, r.depth) + 1 ? new e(this.left, new e(this.right, r)) : new e(this, r);
  }, e;
}(Se);
const pD = 500;
class kt {
  constructor(e, t) {
    this.items = e, this.eventCount = t;
  }
  // Pop the latest event off the branch's history and apply it
  // to a document transform.
  popEvent(e, t) {
    if (this.eventCount == 0)
      return null;
    let r = this.items.length;
    for (; ; r--)
      if (this.items.get(r - 1).selection) {
        --r;
        break;
      }
    let i, s;
    t && (i = this.remapping(r, this.items.length), s = i.maps.length);
    let o = e.tr, l, a, c = [], u = [];
    return this.items.forEach((d, f) => {
      if (!d.step) {
        i || (i = this.remapping(r, f + 1), s = i.maps.length), s--, u.push(d);
        return;
      }
      if (i) {
        u.push(new Mt(d.map));
        let h = d.step.map(i.slice(s)), p;
        h && o.maybeStep(h).doc && (p = o.mapping.maps[o.mapping.maps.length - 1], c.push(new Mt(p, void 0, void 0, c.length + u.length))), s--, p && i.appendMap(p, s);
      } else
        o.maybeStep(d.step);
      if (d.selection)
        return l = i ? d.selection.map(i.slice(s)) : d.selection, a = new kt(this.items.slice(0, r).append(u.reverse().concat(c)), this.eventCount - 1), !1;
    }, this.items.length, 0), { remaining: a, transform: o, selection: l };
  }
  // Create a new branch with the given transform added.
  addTransform(e, t, r, i) {
    let s = [], o = this.eventCount, l = this.items, a = !i && l.length ? l.get(l.length - 1) : null;
    for (let u = 0; u < e.steps.length; u++) {
      let d = e.steps[u].invert(e.docs[u]), f = new Mt(e.mapping.maps[u], d, t), h;
      (h = a && a.merge(f)) && (f = h, u ? s.pop() : l = l.slice(0, l.length - 1)), s.push(f), t && (o++, t = void 0), i || (a = f);
    }
    let c = o - r.depth;
    return c > gD && (l = mD(l, c), o -= c), new kt(l.append(s), o);
  }
  remapping(e, t) {
    let r = new li();
    return this.items.forEach((i, s) => {
      let o = i.mirrorOffset != null && s - i.mirrorOffset >= e ? r.maps.length - i.mirrorOffset : void 0;
      r.appendMap(i.map, o);
    }, e, t), r;
  }
  addMaps(e) {
    return this.eventCount == 0 ? this : new kt(this.items.append(e.map((t) => new Mt(t))), this.eventCount);
  }
  // When the collab module receives remote changes, the history has
  // to know about those, so that it can adjust the steps that were
  // rebased on top of the remote changes, and include the position
  // maps for the remote changes in its array of items.
  rebased(e, t) {
    if (!this.eventCount)
      return this;
    let r = [], i = Math.max(0, this.items.length - t), s = e.mapping, o = e.steps.length, l = this.eventCount;
    this.items.forEach((f) => {
      f.selection && l--;
    }, i);
    let a = t;
    this.items.forEach((f) => {
      let h = s.getMirror(--a);
      if (h == null)
        return;
      o = Math.min(o, h);
      let p = s.maps[h];
      if (f.step) {
        let m = e.steps[h].invert(e.docs[h]), _ = f.selection && f.selection.map(s.slice(a + 1, h));
        _ && l++, r.push(new Mt(p, m, _));
      } else
        r.push(new Mt(p));
    }, i);
    let c = [];
    for (let f = t; f < o; f++)
      c.push(new Mt(s.maps[f]));
    let u = this.items.slice(0, i).append(c).append(r), d = new kt(u, l);
    return d.emptyItemCount() > pD && (d = d.compress(this.items.length - r.length)), d;
  }
  emptyItemCount() {
    let e = 0;
    return this.items.forEach((t) => {
      t.step || e++;
    }), e;
  }
  // Compressing a branch means rewriting it to push the air (map-only
  // items) out. During collaboration, these naturally accumulate
  // because each remote change adds one. The `upto` argument is used
  // to ensure that only the items below a given level are compressed,
  // because `rebased` relies on a clean, untouched set of items in
  // order to associate old items with rebased steps.
  compress(e = this.items.length) {
    let t = this.remapping(0, e), r = t.maps.length, i = [], s = 0;
    return this.items.forEach((o, l) => {
      if (l >= e)
        i.push(o), o.selection && s++;
      else if (o.step) {
        let a = o.step.map(t.slice(r)), c = a && a.getMap();
        if (r--, c && t.appendMap(c, r), a) {
          let u = o.selection && o.selection.map(t.slice(r));
          u && s++;
          let d = new Mt(c.invert(), a, u), f, h = i.length - 1;
          (f = i.length && i[h].merge(d)) ? i[h] = f : i.push(d);
        }
      } else o.map && r--;
    }, this.items.length, 0), new kt(Se.from(i.reverse()), s);
  }
}
kt.empty = new kt(Se.empty, 0);
function mD(n, e) {
  let t;
  return n.forEach((r, i) => {
    if (r.selection && e-- == 0)
      return t = i, !1;
  }), n.slice(t);
}
class Mt {
  constructor(e, t, r, i) {
    this.map = e, this.step = t, this.selection = r, this.mirrorOffset = i;
  }
  merge(e) {
    if (this.step && e.step && !e.selection) {
      let t = e.step.merge(this.step);
      if (t)
        return new Mt(t.getMap().invert(), t, this.selection);
    }
  }
}
class cn {
  constructor(e, t, r, i, s) {
    this.done = e, this.undone = t, this.prevRanges = r, this.prevTime = i, this.prevComposition = s;
  }
}
const gD = 20;
function _D(n, e, t, r) {
  let i = t.getMeta(Ln), s;
  if (i)
    return i.historyState;
  t.getMeta(kD) && (n = new cn(n.done, n.undone, null, 0, -1));
  let o = t.getMeta("appendedTransaction");
  if (t.steps.length == 0)
    return n;
  if (o && o.getMeta(Ln))
    return o.getMeta(Ln).redo ? new cn(n.done.addTransform(t, void 0, r, ds(e)), n.undone, Gd(t.mapping.maps), n.prevTime, n.prevComposition) : new cn(n.done, n.undone.addTransform(t, void 0, r, ds(e)), null, n.prevTime, n.prevComposition);
  if (t.getMeta("addToHistory") !== !1 && !(o && o.getMeta("addToHistory") === !1)) {
    let l = t.getMeta("composition"), a = n.prevTime == 0 || !o && n.prevComposition != l && (n.prevTime < (t.time || 0) - r.newGroupDelay || !yD(t, n.prevRanges)), c = o ? gl(n.prevRanges, t.mapping) : Gd(t.mapping.maps);
    return new cn(n.done.addTransform(t, a ? e.selection.getBookmark() : void 0, r, ds(e)), kt.empty, c, t.time, l ?? n.prevComposition);
  } else return (s = t.getMeta("rebased")) ? new cn(n.done.rebased(t, s), n.undone.rebased(t, s), gl(n.prevRanges, t.mapping), n.prevTime, n.prevComposition) : new cn(n.done.addMaps(t.mapping.maps), n.undone.addMaps(t.mapping.maps), gl(n.prevRanges, t.mapping), n.prevTime, n.prevComposition);
}
function yD(n, e) {
  if (!e)
    return !1;
  if (!n.docChanged)
    return !0;
  let t = !1;
  return n.mapping.maps[0].forEach((r, i) => {
    for (let s = 0; s < e.length; s += 2)
      r <= e[s + 1] && i >= e[s] && (t = !0);
  }), t;
}
function Gd(n) {
  let e = [];
  for (let t = n.length - 1; t >= 0 && e.length == 0; t--)
    n[t].forEach((r, i, s, o) => e.push(s, o));
  return e;
}
function gl(n, e) {
  if (!n)
    return null;
  let t = [];
  for (let r = 0; r < n.length; r += 2) {
    let i = e.map(n[r], 1), s = e.map(n[r + 1], -1);
    i <= s && t.push(i, s);
  }
  return t;
}
function bD(n, e, t) {
  let r = ds(e), i = Ln.get(e).spec.config, s = (t ? n.undone : n.done).popEvent(e, r);
  if (!s)
    return null;
  let o = s.selection.resolve(s.transform.doc), l = (t ? n.done : n.undone).addTransform(s.transform, e.selection.getBookmark(), i, r), a = new cn(t ? l : s.remaining, t ? s.remaining : l, null, 0, -1);
  return s.transform.setSelection(o).setMeta(Ln, { redo: t, historyState: a });
}
let _l = !1, Jd = null;
function ds(n) {
  let e = n.plugins;
  if (Jd != e) {
    _l = !1, Jd = e;
    for (let t = 0; t < e.length; t++)
      if (e[t].spec.historyPreserveItems) {
        _l = !0;
        break;
      }
  }
  return _l;
}
const Ln = new _e("history"), kD = new _e("closeHistory");
function wD(n = {}) {
  return n = {
    depth: n.depth || 100,
    newGroupDelay: n.newGroupDelay || 500
  }, new ae({
    key: Ln,
    state: {
      init() {
        return new cn(kt.empty, kt.empty, null, 0, -1);
      },
      apply(e, t, r) {
        return _D(t, r, e, n);
      }
    },
    config: n,
    props: {
      handleDOMEvents: {
        beforeinput(e, t) {
          let r = t.inputType, i = r == "historyUndo" ? Tm : r == "historyRedo" ? Mm : null;
          return i ? (t.preventDefault(), i(e.state, e.dispatch)) : !1;
        }
      }
    }
  });
}
function xm(n, e) {
  return (t, r) => {
    let i = Ln.getState(t);
    if (!i || (n ? i.undone : i.done).eventCount == 0)
      return !1;
    if (r) {
      let s = bD(i, t, n);
      s && r(e ? s.scrollIntoView() : s);
    }
    return !0;
  };
}
const Tm = xm(!1, !0), Mm = xm(!0, !0);
he.create({
  name: "characterCount",
  addOptions() {
    return {
      limit: null,
      mode: "textSize",
      textCounter: (n) => n.length,
      wordCounter: (n) => n.split(" ").filter((e) => e !== "").length
    };
  },
  addStorage() {
    return {
      characters: () => 0,
      words: () => 0
    };
  },
  onBeforeCreate() {
    this.storage.characters = (n) => {
      const e = (n == null ? void 0 : n.node) || this.editor.state.doc;
      if (((n == null ? void 0 : n.mode) || this.options.mode) === "textSize") {
        const r = e.textBetween(0, e.content.size, void 0, " ");
        return this.options.textCounter(r);
      }
      return e.nodeSize;
    }, this.storage.words = (n) => {
      const e = (n == null ? void 0 : n.node) || this.editor.state.doc, t = e.textBetween(0, e.content.size, " ", " ");
      return this.options.wordCounter(t);
    };
  },
  addProseMirrorPlugins() {
    let n = !1;
    return [
      new ae({
        key: new _e("characterCount"),
        appendTransaction: (e, t, r) => {
          if (n)
            return;
          const i = this.options.limit;
          if (i == null || i === 0) {
            n = !0;
            return;
          }
          const s = this.storage.characters({ node: r.doc });
          if (s > i) {
            const o = s - i, l = 0, a = o;
            console.warn(
              `[CharacterCount] Initial content exceeded limit of ${i} characters. Content was automatically trimmed.`
            );
            const c = r.tr.deleteRange(l, a);
            return n = !0, c;
          }
          n = !0;
        },
        filterTransaction: (e, t) => {
          const r = this.options.limit;
          if (!e.docChanged || r === 0 || r === null || r === void 0)
            return !0;
          const i = this.storage.characters({ node: t.doc }), s = this.storage.characters({ node: e.doc });
          if (s <= r || i > r && s > r && s <= i)
            return !0;
          if (i > r && s > r && s > i || !e.getMeta("paste"))
            return !1;
          const l = e.selection.$head.pos, a = s - r, c = l - a, u = l;
          return e.deleteRange(c, u), !(this.storage.characters({ node: e.doc }) > r);
        }
      })
    ];
  }
});
var vD = he.create({
  name: "dropCursor",
  addOptions() {
    return {
      color: "currentColor",
      width: 1,
      class: void 0
    };
  },
  addProseMirrorPlugins() {
    return [iD(this.options)];
  }
});
he.create({
  name: "focus",
  addOptions() {
    return {
      className: "has-focus",
      mode: "all"
    };
  },
  addProseMirrorPlugins() {
    return [
      new ae({
        key: new _e("focus"),
        props: {
          decorations: ({ doc: n, selection: e }) => {
            const { isEditable: t, isFocused: r } = this.editor, { anchor: i } = e, s = [];
            if (!t || !r)
              return se.create(n, []);
            let o = 0;
            this.options.mode === "deepest" && n.descendants((a, c) => {
              if (a.isText)
                return;
              if (!(i >= c && i <= c + a.nodeSize - 1))
                return !1;
              o += 1;
            });
            let l = 0;
            return n.descendants((a, c) => {
              if (a.isText || !(i >= c && i <= c + a.nodeSize - 1))
                return !1;
              if (l += 1, this.options.mode === "deepest" && o - l > 0 || this.options.mode === "shallowest" && l > 1)
                return this.options.mode === "deepest";
              s.push(
                Be.node(c, c + a.nodeSize, {
                  class: this.options.className
                })
              );
            }), se.create(n, s);
          }
        }
      })
    ];
  }
});
var ED = he.create({
  name: "gapCursor",
  addProseMirrorPlugins() {
    return [aD()];
  },
  extendNodeSchema(n) {
    var e;
    const t = {
      name: n.name,
      options: n.options,
      storage: n.storage
    };
    return {
      allowGapCursor: (e = J(L(n, "allowGapCursor", t))) != null ? e : null
    };
  }
});
he.create({
  name: "placeholder",
  addOptions() {
    return {
      emptyEditorClass: "is-editor-empty",
      emptyNodeClass: "is-empty",
      placeholder: "Write something …",
      showOnlyWhenEditable: !0,
      showOnlyCurrent: !0,
      includeChildren: !1
    };
  },
  addProseMirrorPlugins() {
    return [
      new ae({
        key: new _e("placeholder"),
        props: {
          decorations: ({ doc: n, selection: e }) => {
            const t = this.editor.isEditable || !this.options.showOnlyWhenEditable, { anchor: r } = e, i = [];
            if (!t)
              return null;
            const s = this.editor.isEmpty;
            return n.descendants((o, l) => {
              const a = r >= l && r <= l + o.nodeSize, c = !o.isLeaf && _o(o);
              if ((a || !this.options.showOnlyCurrent) && c) {
                const u = [this.options.emptyNodeClass];
                s && u.push(this.options.emptyEditorClass);
                const d = Be.node(l, l + o.nodeSize, {
                  class: u.join(" "),
                  "data-placeholder": typeof this.options.placeholder == "function" ? this.options.placeholder({
                    editor: this.editor,
                    node: o,
                    pos: l,
                    hasAnchor: a
                  }) : this.options.placeholder
                });
                i.push(d);
              }
              return this.options.includeChildren;
            }), se.create(n, i);
          }
        }
      })
    ];
  }
});
he.create({
  name: "selection",
  addOptions() {
    return {
      className: "selection"
    };
  },
  addProseMirrorPlugins() {
    const { editor: n, options: e } = this;
    return [
      new ae({
        key: new _e("selection"),
        props: {
          decorations(t) {
            return t.selection.empty || n.isFocused || !n.isEditable || qp(t.selection) || n.view.dragging ? null : se.create(t.doc, [
              Be.inline(t.selection.from, t.selection.to, {
                class: e.className
              })
            ]);
          }
        }
      })
    ];
  }
});
function Yd({ types: n, node: e }) {
  return e && Array.isArray(n) && n.includes(e.type) || (e == null ? void 0 : e.type) === n;
}
var DD = he.create({
  name: "trailingNode",
  addOptions() {
    return {
      node: "paragraph",
      notAfter: []
    };
  },
  addProseMirrorPlugins() {
    const n = new _e(this.name), e = Object.entries(this.editor.schema.nodes).map(([, t]) => t).filter((t) => (this.options.notAfter || []).concat(this.options.node).includes(t.name));
    return [
      new ae({
        key: n,
        appendTransaction: (t, r, i) => {
          const { doc: s, tr: o, schema: l } = i, a = n.getState(i), c = s.content.size, u = l.nodes[this.options.node];
          if (a)
            return o.insert(c, u.create());
        },
        state: {
          init: (t, r) => {
            const i = r.tr.doc.lastChild;
            return !Yd({ node: i, types: e });
          },
          apply: (t, r) => {
            if (!t.docChanged)
              return r;
            const i = t.doc.lastChild;
            return !Yd({ node: i, types: e });
          }
        }
      })
    ];
  }
}), SD = he.create({
  name: "undoRedo",
  addOptions() {
    return {
      depth: 100,
      newGroupDelay: 500
    };
  },
  addCommands() {
    return {
      undo: () => ({ state: n, dispatch: e }) => Tm(n, e),
      redo: () => ({ state: n, dispatch: e }) => Mm(n, e)
    };
  },
  addProseMirrorPlugins() {
    return [wD(this.options)];
  },
  addKeyboardShortcuts() {
    return {
      "Mod-z": () => this.editor.commands.undo(),
      "Shift-Mod-z": () => this.editor.commands.redo(),
      "Mod-y": () => this.editor.commands.redo(),
      // Russian keyboard layouts
      "Mod-я": () => this.editor.commands.undo(),
      "Shift-Mod-я": () => this.editor.commands.redo()
    };
  }
}), CD = he.create({
  name: "starterKit",
  addExtensions() {
    var n, e, t, r;
    const i = [];
    return this.options.bold !== !1 && i.push(nE.configure(this.options.bold)), this.options.blockquote !== !1 && i.push(Xv.configure(this.options.blockquote)), this.options.bulletList !== !1 && i.push(ym.configure(this.options.bulletList)), this.options.code !== !1 && i.push(sE.configure(this.options.code)), this.options.codeBlock !== !1 && i.push(aE.configure(this.options.codeBlock)), this.options.document !== !1 && i.push(cE.configure(this.options.document)), this.options.dropcursor !== !1 && i.push(vD.configure(this.options.dropcursor)), this.options.gapcursor !== !1 && i.push(ED.configure(this.options.gapcursor)), this.options.hardBreak !== !1 && i.push(uE.configure(this.options.hardBreak)), this.options.heading !== !1 && i.push(dE.configure(this.options.heading)), this.options.undoRedo !== !1 && i.push(SD.configure(this.options.undoRedo)), this.options.horizontalRule !== !1 && i.push(fE.configure(this.options.horizontalRule)), this.options.italic !== !1 && i.push(_E.configure(this.options.italic)), this.options.listItem !== !1 && i.push(bm.configure(this.options.listItem)), this.options.listKeymap !== !1 && i.push(Sm.configure((n = this.options) == null ? void 0 : n.listKeymap)), this.options.link !== !1 && i.push(_m.configure((e = this.options) == null ? void 0 : e.link)), this.options.orderedList !== !1 && i.push(Cm.configure(this.options.orderedList)), this.options.paragraph !== !1 && i.push(ZE.configure(this.options.paragraph)), this.options.strike !== !1 && i.push(tD.configure(this.options.strike)), this.options.text !== !1 && i.push(nD.configure(this.options.text)), this.options.underline !== !1 && i.push(rD.configure((t = this.options) == null ? void 0 : t.underline)), this.options.trailingNode !== !1 && i.push(DD.configure((r = this.options) == null ? void 0 : r.trailingNode)), i;
  }
}), AD = CD, xD = /(?:^|\s)(!\[(.+|:?)]\((\S+)(?:(?:\s+)["'](\S+)["'])?\))$/, TD = Je.create({
  name: "image",
  addOptions() {
    return {
      inline: !1,
      allowBase64: !1,
      HTMLAttributes: {}
    };
  },
  inline() {
    return this.options.inline;
  },
  group() {
    return this.options.inline ? "inline" : "block";
  },
  draggable: !0,
  addAttributes() {
    return {
      src: {
        default: null
      },
      alt: {
        default: null
      },
      title: {
        default: null
      },
      width: {
        default: null
      },
      height: {
        default: null
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: this.options.allowBase64 ? "img[src]" : 'img[src]:not([src^="data:"])'
      }
    ];
  },
  renderHTML({ HTMLAttributes: n }) {
    return ["img", fe(this.options.HTMLAttributes, n)];
  },
  addCommands() {
    return {
      setImage: (n) => ({ commands: e }) => e.insertContent({
        type: this.name,
        attrs: n
      })
    };
  },
  addInputRules() {
    return [
      om({
        find: xD,
        type: this.type,
        getAttributes: (n) => {
          const [, , e, t, r] = n;
          return { src: t, alt: e, title: r };
        }
      })
    ];
  }
}), MD = TD, FD = ({ key: n, editor: e, onPaste: t, onDrop: r, allowedMimeTypes: i }) => new ae({
  key: n || new _e("fileHandler"),
  props: {
    handleDrop(s, o) {
      var l;
      if (!r || !((l = o.dataTransfer) != null && l.files.length))
        return !1;
      const a = s.posAtCoords({
        left: o.clientX,
        top: o.clientY
      });
      let c = Array.from(o.dataTransfer.files);
      return i && (c = c.filter((u) => i.includes(u.type))), c.length === 0 ? !1 : (o.preventDefault(), o.stopPropagation(), r(e, c, (a == null ? void 0 : a.pos) || 0), !0);
    },
    handlePaste(s, o) {
      var l;
      if (!t || !((l = o.clipboardData) != null && l.files.length))
        return !1;
      let a = Array.from(o.clipboardData.files);
      const c = o.clipboardData.getData("text/html");
      return i && (a = a.filter((u) => i.includes(u.type))), !(a.length === 0 || (o.preventDefault(), o.stopPropagation(), t(e, a, c), c.length > 0));
    }
  }
}), $D = he.create({
  name: "fileHandler",
  addOptions() {
    return {
      onPaste: void 0,
      onDrop: void 0,
      allowedMimeTypes: void 0
    };
  },
  addProseMirrorPlugins() {
    return [
      FD({
        key: new _e(this.name),
        editor: this.editor,
        allowedMimeTypes: this.options.allowedMimeTypes,
        onDrop: this.options.onDrop,
        onPaste: this.options.onPaste
      })
    ];
  }
}), OD = $D;
const {
  SvelteComponent: ND,
  append_hydration: Xd,
  assign: ID,
  attr: Zd,
  binding_callbacks: RD,
  check_outros: LD,
  children: Qd,
  claim_component: Za,
  claim_element: ef,
  claim_space: tf,
  claim_text: PD,
  create_component: Qa,
  destroy_component: ec,
  detach: Hr,
  element: nf,
  flush: rt,
  get_spread_object: BD,
  get_spread_update: zD,
  group_outros: HD,
  init: qD,
  insert_hydration: oa,
  mount_component: tc,
  safe_not_equal: VD,
  set_data: UD,
  space: rf,
  text: jD,
  transition_in: hr,
  transition_out: ri
} = window.__gradio__svelte__internal, { onMount: WD, onDestroy: KD } = window.__gradio__svelte__internal;
function sf(n) {
  let e, t;
  const r = [
    { autoscroll: (
      /*gradio*/
      n[0].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      n[0].i18n
    ) },
    /*loading_status*/
    n[8]
  ];
  let i = {};
  for (let s = 0; s < r.length; s += 1)
    i = ID(i, r[s]);
  return e = new Ry({ props: i }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    n[14]
  ), {
    c() {
      Qa(e.$$.fragment);
    },
    l(s) {
      Za(e.$$.fragment, s);
    },
    m(s, o) {
      tc(e, s, o), t = !0;
    },
    p(s, o) {
      const l = o & /*gradio, loading_status*/
      257 ? zD(r, [
        o & /*gradio*/
        1 && { autoscroll: (
          /*gradio*/
          s[0].autoscroll
        ) },
        o & /*gradio*/
        1 && { i18n: (
          /*gradio*/
          s[0].i18n
        ) },
        o & /*loading_status*/
        256 && BD(
          /*loading_status*/
          s[8]
        )
      ]) : {};
      e.$set(l);
    },
    i(s) {
      t || (hr(e.$$.fragment, s), t = !0);
    },
    o(s) {
      ri(e.$$.fragment, s), t = !1;
    },
    d(s) {
      ec(e, s);
    }
  };
}
function GD(n) {
  let e;
  return {
    c() {
      e = jD(
        /*label*/
        n[1]
      );
    },
    l(t) {
      e = PD(
        t,
        /*label*/
        n[1]
      );
    },
    m(t, r) {
      oa(t, e, r);
    },
    p(t, r) {
      r & /*label*/
      2 && UD(
        e,
        /*label*/
        t[1]
      );
    },
    d(t) {
      t && Hr(e);
    }
  };
}
function JD(n) {
  let e, t, r, i, s, o, l = (
    /*loading_status*/
    n[8] && sf(n)
  );
  return r = new T_({
    props: {
      show_label: (
        /*show_label*/
        n[5]
      ),
      info: void 0,
      $$slots: { default: [GD] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      l && l.c(), e = rf(), t = nf("div"), Qa(r.$$.fragment), i = rf(), s = nf("div"), this.h();
    },
    l(a) {
      l && l.l(a), e = tf(a), t = ef(a, "DIV", { class: !0 });
      var c = Qd(t);
      Za(r.$$.fragment, c), i = tf(c), s = ef(c, "DIV", { class: !0 }), Qd(s).forEach(Hr), c.forEach(Hr), this.h();
    },
    h() {
      Zd(s, "class", "editor scroll-hide svelte-112w9nn"), Zd(t, "class", "container svelte-112w9nn");
    },
    m(a, c) {
      l && l.m(a, c), oa(a, e, c), oa(a, t, c), tc(r, t, null), Xd(t, i), Xd(t, s), n[15](s), o = !0;
    },
    p(a, c) {
      /*loading_status*/
      a[8] ? l ? (l.p(a, c), c & /*loading_status*/
      256 && hr(l, 1)) : (l = sf(a), l.c(), hr(l, 1), l.m(e.parentNode, e)) : l && (HD(), ri(l, 1, 1, () => {
        l = null;
      }), LD());
      const u = {};
      c & /*show_label*/
      32 && (u.show_label = /*show_label*/
      a[5]), c & /*$$scope, label*/
      65538 && (u.$$scope = { dirty: c, ctx: a }), r.$set(u);
    },
    i(a) {
      o || (hr(l), hr(r.$$.fragment, a), o = !0);
    },
    o(a) {
      ri(l), ri(r.$$.fragment, a), o = !1;
    },
    d(a) {
      a && (Hr(e), Hr(t)), l && l.d(a), ec(r), n[15](null);
    }
  };
}
function YD(n) {
  let e, t;
  return e = new rg({
    props: {
      visible: (
        /*visible*/
        n[4]
      ),
      elem_id: (
        /*elem_id*/
        n[2]
      ),
      elem_classes: (
        /*elem_classes*/
        n[3]
      ),
      scale: (
        /*scale*/
        n[6]
      ),
      min_width: (
        /*min_width*/
        n[7]
      ),
      allow_overflow: !1,
      padding: !0,
      $$slots: { default: [JD] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Qa(e.$$.fragment);
    },
    l(r) {
      Za(e.$$.fragment, r);
    },
    m(r, i) {
      tc(e, r, i), t = !0;
    },
    p(r, [i]) {
      const s = {};
      i & /*visible*/
      16 && (s.visible = /*visible*/
      r[4]), i & /*elem_id*/
      4 && (s.elem_id = /*elem_id*/
      r[2]), i & /*elem_classes*/
      8 && (s.elem_classes = /*elem_classes*/
      r[3]), i & /*scale*/
      64 && (s.scale = /*scale*/
      r[6]), i & /*min_width*/
      128 && (s.min_width = /*min_width*/
      r[7]), i & /*$$scope, element, show_label, label, gradio, loading_status*/
      66339 && (s.$$scope = { dirty: i, ctx: r }), e.$set(s);
    },
    i(r) {
      t || (hr(e.$$.fragment, r), t = !0);
    },
    o(r) {
      ri(e.$$.fragment, r), t = !1;
    },
    d(r) {
      ec(e, r);
    }
  };
}
function XD(n, e, t) {
  let { gradio: r } = e, { label: i = "Textbox" } = e, { elem_id: s = "" } = e, { elem_classes: o = [] } = e, { visible: l = !0 } = e, { value: a = "" } = e, { show_label: c } = e, { scale: u = null } = e, { min_width: d = void 0 } = e, { loading_status: f = void 0 } = e, { value_is_output: h = !1 } = e, { interactive: p } = e, m, _;
  WD(() => {
    t(13, _ = new Kv({
      element: m,
      extensions: [
        AD.configure({
          bulletList: { keepMarks: !0, keepAttributes: !1 },
          orderedList: { keepMarks: !0, keepAttributes: !1 },
          codeBlock: !1,
          hardBreak: { keepMarks: !1 }
        }),
        MD.extend({
          renderHTML({ HTMLAttributes: g }) {
            return [
              "div",
              { class: "resizable-image-container" },
              ["img", g]
            ];
          }
        }).configure({ inline: !0, allowBase64: !0 }),
        OD.configure({
          accept: ["image/*", "application/pdf"],
          onDrop(g, w) {
            return w.forEach((E) => {
              const v = new FileReader();
              v.onload = () => g.commands.setImage({ src: v.result, alt: E.name }), v.readAsDataURL(E);
            }), !0;
          }
        }),
        qE.configure({
          openOnClick: !1,
          defaultProtocol: "https"
        }).extend({
          addKeyboardShortcuts() {
            return {
              "Mod-k": () => {
                var g;
                const w = (g = prompt("Enter URL")) !== null && g !== void 0 ? g : "";
                if (w) {
                  const E = w.match(/^https?:\/\//) ? w : `https://${w}`;
                  this.editor.chain().focus().setLink({ href: E }).setTextSelection(this.editor.state.selection.to).unsetMark("link").run();
                } else
                  this.editor.commands.unsetLink();
                return !0;
              }
            };
          }
        })
      ],
      content: a,
      editable: p,
      onUpdate: ({ editor: g }) => {
        t(10, a = g.getHTML()), r.dispatch("change"), h || r.dispatch("input");
      }
    }));
  }), KD(() => {
    _ && _.destroy();
  });
  const b = () => r.dispatch("clear_status", f);
  function y(g) {
    RD[g ? "unshift" : "push"](() => {
      m = g, t(9, m);
    });
  }
  return n.$$set = (g) => {
    "gradio" in g && t(0, r = g.gradio), "label" in g && t(1, i = g.label), "elem_id" in g && t(2, s = g.elem_id), "elem_classes" in g && t(3, o = g.elem_classes), "visible" in g && t(4, l = g.visible), "value" in g && t(10, a = g.value), "show_label" in g && t(5, c = g.show_label), "scale" in g && t(6, u = g.scale), "min_width" in g && t(7, d = g.min_width), "loading_status" in g && t(8, f = g.loading_status), "value_is_output" in g && t(11, h = g.value_is_output), "interactive" in g && t(12, p = g.interactive);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1024 && a === null && t(10, a = ""), n.$$.dirty & /*editor, value*/
    9216 && _ && a !== _.getHTML() && _.commands.setContent(a), n.$$.dirty & /*editor, interactive*/
    12288 && _ && _.setEditable(p);
  }, [
    r,
    i,
    s,
    o,
    l,
    c,
    u,
    d,
    f,
    m,
    a,
    h,
    p,
    _,
    b,
    y
  ];
}
class w9 extends ND {
  constructor(e) {
    super(), qD(this, e, XD, YD, VD, {
      gradio: 0,
      label: 1,
      elem_id: 2,
      elem_classes: 3,
      visible: 4,
      value: 10,
      show_label: 5,
      scale: 6,
      min_width: 7,
      loading_status: 8,
      value_is_output: 11,
      interactive: 12
    });
  }
  get gradio() {
    return this.$$.ctx[0];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), rt();
  }
  get label() {
    return this.$$.ctx[1];
  }
  set label(e) {
    this.$$set({ label: e }), rt();
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), rt();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), rt();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), rt();
  }
  get value() {
    return this.$$.ctx[10];
  }
  set value(e) {
    this.$$set({ value: e }), rt();
  }
  get show_label() {
    return this.$$.ctx[5];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), rt();
  }
  get scale() {
    return this.$$.ctx[6];
  }
  set scale(e) {
    this.$$set({ scale: e }), rt();
  }
  get min_width() {
    return this.$$.ctx[7];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), rt();
  }
  get loading_status() {
    return this.$$.ctx[8];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), rt();
  }
  get value_is_output() {
    return this.$$.ctx[11];
  }
  set value_is_output(e) {
    this.$$set({ value_is_output: e }), rt();
  }
  get interactive() {
    return this.$$.ctx[12];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), rt();
  }
}
export {
  w9 as I,
  Ic as c,
  QD as g,
  Z5 as p
};
