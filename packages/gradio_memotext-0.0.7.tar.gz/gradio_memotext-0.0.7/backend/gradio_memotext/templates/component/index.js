import { I as f } from "./Index-DgoXN_V5.js";
export {
  f as default
};
