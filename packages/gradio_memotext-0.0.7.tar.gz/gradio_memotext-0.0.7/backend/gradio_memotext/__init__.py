
from .memotext import MemoText

__all__ = ['MemoText']
