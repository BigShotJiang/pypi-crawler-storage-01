from django.apps import AppConfig


class SharedLibConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shared_lib'
