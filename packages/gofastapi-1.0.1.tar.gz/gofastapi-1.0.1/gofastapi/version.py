"""Version information for GoFastAPI."""

__version__ = "1.0.1"
