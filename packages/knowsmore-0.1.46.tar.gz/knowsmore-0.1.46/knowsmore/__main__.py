#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from . import knowsmore

if __name__ == "__main__":
    knowsmore.run()