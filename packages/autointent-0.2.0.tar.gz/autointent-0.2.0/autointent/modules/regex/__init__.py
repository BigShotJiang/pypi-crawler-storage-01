from ._simple import SimpleRegex

__all__ = ["SimpleRegex"]
