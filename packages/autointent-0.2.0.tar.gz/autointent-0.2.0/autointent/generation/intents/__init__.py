"""Generative methods for enriching intents' metadata."""

from ._description_generation import generate_descriptions

__all__ = ["generate_descriptions"]
