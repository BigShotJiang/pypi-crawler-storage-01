"""logscale package initialization module."""

from .order_of_magnitude import order_of_magnitude

__all__ = ["order_of_magnitude"]
