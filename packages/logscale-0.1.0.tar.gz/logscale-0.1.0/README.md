# logscale
Compute orders of magnitude
