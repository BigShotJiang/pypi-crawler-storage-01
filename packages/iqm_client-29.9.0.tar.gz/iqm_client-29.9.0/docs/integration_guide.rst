.. _integration_guide:
.. include:: ../INTEGRATION_GUIDE.rst
