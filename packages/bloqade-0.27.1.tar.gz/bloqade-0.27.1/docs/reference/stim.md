---
title: stim
---

# ::: bloqade.stim
    options:
        show_submodules: true
