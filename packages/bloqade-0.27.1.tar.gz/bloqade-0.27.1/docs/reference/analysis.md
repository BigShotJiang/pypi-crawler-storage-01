---
title: analysis
---

# ::: bloqade.analysis
    options:
        show_submodules: true
