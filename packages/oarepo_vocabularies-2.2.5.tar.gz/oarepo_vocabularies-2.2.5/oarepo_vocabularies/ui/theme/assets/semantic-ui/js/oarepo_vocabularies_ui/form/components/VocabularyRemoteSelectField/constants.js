export const ModalActions = {
    SEARCH: "search",
    ADD: "add",
};

export const SearchSource = {
    INTERNAL: "int",
    EXTERNAL: "ext",
};