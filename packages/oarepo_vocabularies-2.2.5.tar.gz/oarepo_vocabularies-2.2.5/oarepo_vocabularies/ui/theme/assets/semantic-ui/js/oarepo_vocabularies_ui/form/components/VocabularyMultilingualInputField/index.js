export * from "./VocabularyMultilingualInputField";
