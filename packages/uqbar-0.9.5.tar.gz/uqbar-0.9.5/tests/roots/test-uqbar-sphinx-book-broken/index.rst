Fake Docs
=========

::

    >>> for i in range(10):
    ...     1 / 0
    ...
    Traceback (most recent call last):
      File "<stdin>", line 2, in <module>
    ZeroDivisionError: division by zero

::
    
    >>> print(this_name_does_not_exist)
