master_doc = "index"

extensions = ["sphinx.ext.autodoc", "uqbar.sphinx.api"]

html_static_path = ["_static"]

uqbar_api_source_paths = ["fake_package"]
