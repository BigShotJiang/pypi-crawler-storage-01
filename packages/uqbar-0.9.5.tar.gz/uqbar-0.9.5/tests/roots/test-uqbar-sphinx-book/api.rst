API
===

.. autofunction:: fake.just_a_function

Text::

    >>> print("I am text.")

.. autoclass:: fake.GrandParent
   :members:
   :inherited-members:

Text::

    >>> print("I am text.")

.. autoclass:: fake.Parent
   :members:
   :inherited-members:

Text::

    >>> print("I am text.")

.. autoclass:: fake.Uncle
   :members:
   :inherited-members:

Text::

    >>> print("I am text.")

.. autoclass:: fake.Child
   :members:
   :inherited-members:

Text::

    >>> print("I am text.")

.. autoclass:: fake.Outer
   :members:
   :inherited-members:
