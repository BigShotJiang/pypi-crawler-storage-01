# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-08-03)

### Bug Fixes

- V4 ?
  ([`86ac8cd`](https://github.com/PyMoX-fr/GC7/commit/86ac8cd570643f194249b83de5e90feeaf639fbb))


## v0.0.2 (2025-08-03)

### Bug Fixes

- V2 ?
  ([`8733b83`](https://github.com/PyMoX-fr/GC7/commit/8733b830ba3be3a3f0c5d5e3ca8b3ef0eec903f6))


## v0.0.1 (2025-08-03)

### Bug Fixes

- For 4
  ([`31bcf6b`](https://github.com/PyMoX-fr/GC7/commit/31bcf6b49b8cf0d332282af209ba40847f4d0d49))

- Reset
  ([`6fc5fb9`](https://github.com/PyMoX-fr/GC7/commit/6fc5fb90abe71be4e42e82086b094820ec6c6ed7))

- Reset dynamic version
  ([`d07896f`](https://github.com/PyMoX-fr/GC7/commit/d07896f1052d5b4f14d2e4924ba57e2f2ca22d97))

- Reset v0.0.2
  ([`93b91ea`](https://github.com/PyMoX-fr/GC7/commit/93b91ea5d002c5408d81a20f2a2192585e386422))

- Set v.0.2
  ([`32e8cf0`](https://github.com/PyMoX-fr/GC7/commit/32e8cf0c38b70126e5835e072e7b087713ad6799))

- Set v0
  ([`a6b08a1`](https://github.com/PyMoX-fr/GC7/commit/a6b08a18a35182456f8144f907a5e6cf5cacfa7b))

- Synchro v3
  ([`2848f25`](https://github.com/PyMoX-fr/GC7/commit/2848f2532427b7bab5c71aca64166d5d31854bab))

- Try v3
  ([`794c4da`](https://github.com/PyMoX-fr/GC7/commit/794c4da9e6c46757755c0cf04736ca501162f7de))

- Try v4
  ([`d0268b2`](https://github.com/PyMoX-fr/GC7/commit/d0268b24dd68d62f322da6640f0cb69c3b89243e))


## v0.0.0 (2025-08-03)

- Initial Release
