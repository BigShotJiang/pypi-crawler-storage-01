pytblis package
===============

.. automodule:: pytblis
   :members:
   :show-inheritance:
   :undoc-members:

.. autofunction:: pytblis.add
.. autofunction:: pytblis.mult
.. autofunction:: pytblis.dot
.. autofunction:: pytblis.reduce
.. autofunction:: pytblis.shift
