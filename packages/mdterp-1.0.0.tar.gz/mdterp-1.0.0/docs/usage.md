# Usage

To use MDTerp in a project:

```
import MDTerp
```

Go to https://shams-mehdi.github.io/MDTerp/MDTerp_demo1.ipynb, https://shams-mehdi.github.io/MDTerp/MDTerp_demo2.ipynb for explicit usage.
