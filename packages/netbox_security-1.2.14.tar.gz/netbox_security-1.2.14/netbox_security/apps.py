from django.apps import AppConfig


class NetBoxSecurityConfig(AppConfig):
    name = "netbox_security"
