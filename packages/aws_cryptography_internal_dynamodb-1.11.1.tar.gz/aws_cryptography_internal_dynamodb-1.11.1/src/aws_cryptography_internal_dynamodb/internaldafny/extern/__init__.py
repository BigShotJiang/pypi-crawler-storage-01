from . import (
    Com_Amazonaws_Dynamodb,
)