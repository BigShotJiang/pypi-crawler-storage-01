"""
TestZeus CLI - Command-line interface for TestZeus testing platform
"""

__version__ = "0.0.1"
