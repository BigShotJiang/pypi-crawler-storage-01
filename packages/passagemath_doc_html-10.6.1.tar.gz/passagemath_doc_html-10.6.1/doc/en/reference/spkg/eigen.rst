.. _spkg_eigen:

eigen: C++ template library for linear algebra
========================================================

Description
-----------

Eigen is a C++ template library for linear algebra: matrices, vectors, numerical
solvers, and related algorithms.


License
-------

MPL 2


Upstream Contact
----------------

https://eigen.tuxfamily.org/index.php?title=Main_Page#Requirements

Type
----

optional


Dependencies
------------


Version Information
-------------------

package-version.txt::

    3.4.0


Equivalent System Packages
--------------------------

(none known)

