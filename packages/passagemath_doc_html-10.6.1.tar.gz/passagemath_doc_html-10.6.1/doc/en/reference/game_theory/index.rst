Game Theory
===========

.. toctree::
   :maxdepth: 1

   sage/game_theory/cooperative_game
   sage/game_theory/matching_game
   sage/game_theory/normal_form_game
   sage/game_theory/catalog_normal_form_games
   sage/game_theory/parser

.. include:: ../footer.txt
