* Finish and test documentation
* Update `CHANGELOG.md`
