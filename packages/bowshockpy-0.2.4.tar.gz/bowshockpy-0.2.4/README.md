# BowshockPy

*A Python package for generating spectral channel maps of a jet-driven bowshock model*

``Bowshockpy`` is a Python package that generates synthetic spectral cubes, position-velocity diagrams, and moment images for a simple analytical jet-driven bowshock model, using the prescription for protostellar jets presented in [Ostriker et al. (2001)](https://ui.adsabs.harvard.edu/abs/2001ApJ...557..443O/abstract) and [Tabone et al. (2018)](https://ui.adsabs.harvard.edu/abs/2018A%26A...614A.119T/abstract). The software computes the intensities of low-J rotational transitions of the CO molecule, providing mock observations of the CO emission that radio telescopes as ALMA are able to detect at millimeter wavelengths.


<!--
 computes spectral channel maps of jet-driven bowshock model. The bowshock shell morphology and kinematics are determined from the momentum conservation in the interaction of jet material ejected sideways by an internal working surface and the ambient medium (or a surrounding disk wind moving in the jet axis direction). Well mixing between the jet and ambient material are assumed.
-->

## Documentation

An extensive documentation on ``bowshockpy`` can be found [here](https://bowshockpy.readthedocs.io/en/latest/)


## Requirements
bowshockpy requires:

* Python3 
* astropy
* matplotlib
* numpy
* scipy 

It has been tested with `python == 3.10`, but it could work with previous versions.


## Installation

You can install ``bowshockpy`` from PyPI. 

```bash
$ pip install bowshockpy 
```

## How to use

There are two different ways to use ``bowshockpy``:

1. Run it from the terminal specifying an input file: Use an [example of input file](https://github.com/gblazquez/bowshockpy/tree/main/examples) and modify the input parameters according your scientific goals. Then, run ``bowshockpy`` in your terminal:

  ```bash
  $ bowshockpy -r inputfile.py 
  ```

2. Importing ``bowshockpy`` package in your Python code: We include an [notebook example](https://github.com/gblazquez/bowshockpy/tree/main/examples/example_notebook.ipynb) that shows how to use the main classes. 

See the [documentation](https://bowshockpy.readthedocs.io/en/latest/) for more details on the usage of bowshockpy.

## Contributing

If you are interested in contributing, see [contributing](CONTRIBUTING.md)

## License

This project is licensed under the MIT License. For details see the [LICENSE](LICENSE).


## Citation

```tex
@software{gblazquez2025,
  author    = {Blazquez-Calero, Guillermo AND et al.},
  title     = {{BowshockPy}: A Python package for the generation of synthetic spectral channel maps of a jet-driven
bowshock model},
  year      = {2025},
  version   = {0.2.4},
  url       = {https://github.com/gblazquez/bowshockpy}
}
```
