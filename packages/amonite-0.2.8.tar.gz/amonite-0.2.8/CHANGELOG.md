# 0.1.6
  * Added walls loader utility.