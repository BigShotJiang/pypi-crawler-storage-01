"""This is required to allow the frozen app to find the scripts resources..."""
