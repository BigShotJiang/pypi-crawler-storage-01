"""
Demonstration code.
"""
