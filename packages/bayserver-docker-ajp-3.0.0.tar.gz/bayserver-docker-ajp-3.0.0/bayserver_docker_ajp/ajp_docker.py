from bayserver_core.docker.docker import Docker

class AjpDocker(Docker):
    PROTO_NAME = "ajp"
