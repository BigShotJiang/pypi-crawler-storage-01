gbd\_mapping package
====================

Submodules
----------

gbd\_mapping.base\_template module
----------------------------------

.. automodule:: gbd_mapping.base_template
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.cause module
-------------------------

.. automodule:: gbd_mapping.cause
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.cause\_template module
-----------------------------------

.. automodule:: gbd_mapping.cause_template
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.covariate module
-----------------------------

.. automodule:: gbd_mapping.covariate
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.covariate\_template module
---------------------------------------

.. automodule:: gbd_mapping.covariate_template
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.etiology module
----------------------------

.. automodule:: gbd_mapping.etiology
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.etiology\_template module
--------------------------------------

.. automodule:: gbd_mapping.etiology_template
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.id module
----------------------

.. automodule:: gbd_mapping.id
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.risk module
------------------------

.. automodule:: gbd_mapping.risk_factor
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.risk\_template module
----------------------------------

.. automodule:: gbd_mapping.risk_factor_template
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.sequela module
---------------------------

.. automodule:: gbd_mapping.sequela
    :members:
    :undoc-members:
    :show-inheritance:

gbd\_mapping.sequela\_template module
-------------------------------------

.. automodule:: gbd_mapping.sequela_template
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: gbd_mapping
    :members:
    :undoc-members:
    :show-inheritance:
