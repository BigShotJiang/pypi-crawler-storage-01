from project.core.util import setup_logging


def create_site_app():
    setup_logging()
