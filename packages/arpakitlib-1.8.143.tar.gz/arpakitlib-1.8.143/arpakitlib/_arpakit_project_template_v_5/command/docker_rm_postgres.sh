cd ..
source .env
sudo docker rm -f ${project_name}_postgres
