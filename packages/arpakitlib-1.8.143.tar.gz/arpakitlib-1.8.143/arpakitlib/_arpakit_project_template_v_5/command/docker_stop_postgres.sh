cd ..
source .env
sudo docker stop ${project_name}_postgres
