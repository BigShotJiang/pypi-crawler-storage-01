"""Tests for osm-fieldwork."""
