"""OSM Fieldwork Package."""

import os

package_root = os.path.dirname(os.path.abspath(__file__))
