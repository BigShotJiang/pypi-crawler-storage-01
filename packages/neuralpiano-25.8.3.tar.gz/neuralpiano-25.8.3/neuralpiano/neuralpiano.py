# Neural Piano main Python module

def neuralpiano()
    return None