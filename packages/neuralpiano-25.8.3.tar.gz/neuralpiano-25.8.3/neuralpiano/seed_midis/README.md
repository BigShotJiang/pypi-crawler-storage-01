# Neural Piano sample seed MIDIs

***

### Project Los Angeles
### Tegridy Code 2025
