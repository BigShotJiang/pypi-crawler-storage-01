def main():
    print("Did you mean: python -m microprojects.calc")


if __name__ == "__main__":
    main()
