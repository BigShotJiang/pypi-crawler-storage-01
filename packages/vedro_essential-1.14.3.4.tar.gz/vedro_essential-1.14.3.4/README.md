# Vedro Essential

Most common Vedro plugin for testing pipeline.

# Versioning
```
{1.14.3}.{1}
```
`1.14.3` - vedro version base
`1` - compose version
