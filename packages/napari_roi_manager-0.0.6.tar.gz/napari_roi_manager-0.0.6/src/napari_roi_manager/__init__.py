__version__ = "0.0.6"

from .widgets import QRoiManager

__all__ = ["QRoiManager"]
