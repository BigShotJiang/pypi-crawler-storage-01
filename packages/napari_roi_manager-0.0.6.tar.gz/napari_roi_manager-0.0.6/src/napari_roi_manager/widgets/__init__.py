from __future__ import annotations

from ._roi_manager import QRoiManager

__all__ = ["QRoiManager"]
