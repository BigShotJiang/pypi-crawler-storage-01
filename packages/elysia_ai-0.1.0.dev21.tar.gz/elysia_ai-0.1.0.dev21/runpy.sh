source .venv/bin/activate
python elysia/api/cli.py start --port 8000 --host 0.0.0.0 
