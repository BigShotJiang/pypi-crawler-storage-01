"""
More complex testing of retrieval accuracy.
I.e. testing whether the correct data is retrieved for a given prompt.
This also includes testing the constructed query code contains the correct fields/filters etc.
"""

# TODO: after query/aggregate rework
