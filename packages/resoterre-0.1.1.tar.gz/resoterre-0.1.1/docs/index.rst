Welcome to resoterre's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   contributing
   releasing
   authors
   changelog

.. toctree::
   :maxdepth: 1
   :caption: All Modules

   apidoc/modules

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
