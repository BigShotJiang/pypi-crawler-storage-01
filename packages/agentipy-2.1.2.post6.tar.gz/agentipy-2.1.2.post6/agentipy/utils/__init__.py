class AgentKitError(Exception):
    """Custom exception for errors in AgentKit"""
    pass