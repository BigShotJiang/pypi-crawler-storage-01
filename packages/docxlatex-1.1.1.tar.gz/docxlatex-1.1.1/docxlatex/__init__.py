__version__ = "1.1.1"

from docxlatex.docxlatex import Document
from docxlatex.parser import utils
from docxlatex import cleaners
