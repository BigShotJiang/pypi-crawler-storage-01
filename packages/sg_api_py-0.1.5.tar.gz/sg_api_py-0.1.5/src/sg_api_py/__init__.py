__version = "0.1.1"


from .api import characters, episodes
# import the actual .py file

__all__ = ["characters", "episodes"]
