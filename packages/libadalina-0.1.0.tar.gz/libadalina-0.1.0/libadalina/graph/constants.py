from libadalina.graph.coordinate_formats import EPSGFormats

DEFAULT_EPSG = EPSGFormats.EPSG4326.value #3857