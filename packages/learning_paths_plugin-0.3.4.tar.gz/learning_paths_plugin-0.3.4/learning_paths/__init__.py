"""
Learning Paths plugin.
"""

__version__ = "0.3.4"
