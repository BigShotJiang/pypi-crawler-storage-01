# LlamaIndex Vector_Stores Integration: ApertureDB
