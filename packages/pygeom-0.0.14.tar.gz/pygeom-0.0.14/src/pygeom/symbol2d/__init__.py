from .symbolicvector2d import SymbolicVector2D as SymbolicVector2D
from .symbolicvector2d import empty_symbolicvector2d as empty_symbolicvector2d
from .symbolicvector2d import symple_vector2d as symple_vector2d

IHAT = SymbolicVector2D(1, 0)
JHAT = SymbolicVector2D(0, 1)
