from .cubicspline1d import CubicSpline1D as CubicSpline1D
from .linearspline1d import LinearSpline1D as LinearSpline1D
