from .vector import Vector


class Point(Vector):
    pass
