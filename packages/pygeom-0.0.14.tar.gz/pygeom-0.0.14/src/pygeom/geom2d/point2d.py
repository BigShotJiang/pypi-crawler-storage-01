from .vector2d import Vector2D


class Point2D(Vector2D):
    pass
