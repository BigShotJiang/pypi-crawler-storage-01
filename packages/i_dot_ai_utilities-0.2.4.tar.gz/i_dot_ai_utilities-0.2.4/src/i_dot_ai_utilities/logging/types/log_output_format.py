from enum import Enum


class LogOutputFormat(Enum):
    JSON = 1
    TEXT = 2
