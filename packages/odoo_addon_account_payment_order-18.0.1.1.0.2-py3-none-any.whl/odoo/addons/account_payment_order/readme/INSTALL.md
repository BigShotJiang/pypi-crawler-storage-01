This module depends on:

- account_payment_partner
- base_iban
- document

This modules is part of the OCA/bank-payment suite.
