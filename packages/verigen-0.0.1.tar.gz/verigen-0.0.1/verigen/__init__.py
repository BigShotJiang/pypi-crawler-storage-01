"""Top-level package for verigen."""

__author__ = """GNPower"""
__email__ = "powerg@mcmaster.ca"
__version__ = "0.0.1"
