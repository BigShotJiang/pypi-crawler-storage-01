# VeriGen
Generates Verilog and SystemVerilog files from templates using Jinja2
