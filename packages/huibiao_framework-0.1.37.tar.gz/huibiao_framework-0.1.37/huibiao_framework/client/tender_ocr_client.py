class TenderOcrClient:
    """
    tender-ocr的文件实现类
    """
