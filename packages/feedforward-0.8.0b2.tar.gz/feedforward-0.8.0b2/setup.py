from setuptools import setup

setup(use_scm_version={"write_to": "feedforward/_version.py"})
