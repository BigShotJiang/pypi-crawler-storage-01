from MCQuantLib.Instrument.instrument import InstrumentMC

class BarrierOption(InstrumentMC):
    pass
