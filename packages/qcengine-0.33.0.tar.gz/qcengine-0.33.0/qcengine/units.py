"""
Pinning point for QCElemental units
"""

# Pin Codata
import qcelemental as qcel

ureg = qcel.PhysicalConstantsContext("CODATA2014")
