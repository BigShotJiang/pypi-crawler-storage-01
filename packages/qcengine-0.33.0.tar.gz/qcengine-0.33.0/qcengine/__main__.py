import qcengine.cli

qcengine.cli.main()
