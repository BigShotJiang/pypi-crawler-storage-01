1.  Go to *Manufacturing -\> Operation \> Work Orders* and click in
    window open button (after the "Start" and "Block" options).
2.  The smart-button "Product Attachments" display the attachments of the
    related product. The smart-button "BoM Attachments" displays the
    attachments of the workorder BoM.
3.  Go to *Manufacturing -\> Products \> Bill of material -\> Desk
    Combination*.
4.  Go to "Attachment" icon related to "Office Chair Black" component
    and upload some file.
5.  The smart-button "Component Attachments" (from Bill of material) display the
    attachments of all components. The smart-button "Product Attachments"
    displays the Desk Combination attachments.
6.  Go to *Manufacturing -\> Products \> Products -\> Desk Combination*.
7.  The smart-button "Components Attachments" display the attachments of all
    components from Bill of material. The smart-button "Bom Attachments"
    displays the attachments of all the product Bill of materials.
