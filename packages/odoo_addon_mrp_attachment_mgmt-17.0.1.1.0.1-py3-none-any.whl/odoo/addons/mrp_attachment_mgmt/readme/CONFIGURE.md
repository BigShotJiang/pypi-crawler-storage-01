To configure this module, you need to:

1.  Go to *Manufacturing -\> Configuration -\> Settings* and check "Work
    Orders" option.
