# This is parsed by regex in conda recipe meta file. Make sure not to break it.
VERSION = "1.9.2"
