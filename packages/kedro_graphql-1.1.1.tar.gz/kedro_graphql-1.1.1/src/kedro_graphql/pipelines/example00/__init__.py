"""
This is a boilerplate pipeline 'example00'
generated using Kedro 0.18.4
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
