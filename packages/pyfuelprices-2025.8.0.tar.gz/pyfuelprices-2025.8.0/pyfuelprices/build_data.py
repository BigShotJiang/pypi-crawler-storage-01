"""This file contains mappings that are filled during build."""

GASPASS_URL="https://gaspassproxy2-dhf8a6aphxbng9g4.brazilsouth-01.azurewebsites.net"
FINELLY_URL="https://api.finelly.co.nz/api"
