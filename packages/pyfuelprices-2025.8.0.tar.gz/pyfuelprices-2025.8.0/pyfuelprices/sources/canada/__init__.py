"""Canadian sources."""

from pyfuelprices.sources.usa import SOURCE_MAP as USA_SOURCE_MAP

SOURCE_MAP = {
    **USA_SOURCE_MAP
}
