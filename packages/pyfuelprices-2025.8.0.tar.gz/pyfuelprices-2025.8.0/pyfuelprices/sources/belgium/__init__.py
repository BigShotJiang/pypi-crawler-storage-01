"""Belgium sources."""

from pyfuelprices.sources.netherlands import SOURCE_MAP as NL_SOURCE_MAP

SOURCE_MAP = {
    **NL_SOURCE_MAP
}
