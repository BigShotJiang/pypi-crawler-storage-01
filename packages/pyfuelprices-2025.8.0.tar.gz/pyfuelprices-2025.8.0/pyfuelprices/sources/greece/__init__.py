"""Greece Fuel Sources and parsers."""

from .fuelgr import FuelGrSource

SOURCE_MAP = {"fuelgr": (FuelGrSource, 1, 1,)}
