"""Austria Fuel Source."""

from .spritpreisrechner import SpripreisrechnerATSource

SOURCE_MAP = {
    "spritpreisrechner": (SpripreisrechnerATSource, 1, 1,)
}
