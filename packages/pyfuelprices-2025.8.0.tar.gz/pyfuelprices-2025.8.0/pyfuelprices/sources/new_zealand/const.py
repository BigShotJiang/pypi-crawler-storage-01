"""NZ Consts."""

FINELLY_FUEL_API = (
    "{FURL}/api/HomeAssistantPetrolStation"
    "/GetPetrolStations"
    "?latitude={LAT}&longitude={LONG}"
    "&radiusInKm={RAD}&userId={USER}"
)
