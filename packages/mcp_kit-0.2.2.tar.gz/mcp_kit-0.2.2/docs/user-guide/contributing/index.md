---
sidebar_position: 1
# This file was auto-generated and should not be edited manually
---

# Introduction
This section provides more in depth technical documentation useful for understanding some of the design decisions and for contributing to mcp-kit-python.
