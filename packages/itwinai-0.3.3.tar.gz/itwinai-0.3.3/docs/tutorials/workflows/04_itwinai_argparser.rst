Integrating configuration with command line arguments
=========================================================


.. include:: ../../../tutorials/ml-workflows/04-itwinai-argparser/README.md
   :parser: myst_parser.sphinx_


main.py
---------

.. literalinclude:: ../../../tutorials/ml-workflows/04-itwinai-argparser/main.py
   :language: python


