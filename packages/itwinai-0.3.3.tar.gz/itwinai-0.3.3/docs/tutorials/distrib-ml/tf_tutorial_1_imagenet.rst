Tensorflow ImageNet example
===========================

.. include:: ../../../tutorials/distributed-ml/tf-tutorial-1-imagenet/README.md
   :parser: myst_parser.sphinx_

train.py
++++++++

.. literalinclude:: ../../../tutorials/distributed-ml/tf-tutorial-1-imagenet/train.py
   :language: python


tfmirrored_slurm.sh
+++++++++++++++++++

.. literalinclude:: ../../../tutorials/distributed-ml/tf-tutorial-1-imagenet/tfmirrored_slurm.sh
   :language: bash

