Tensorflow scaling test
=======================

.. include:: ../../../tutorials/distributed-ml/tf-scaling-test-jube/README.md
   :parser: myst_parser.sphinx_


train.py
++++++++

.. literalinclude:: ../../../tutorials/distributed-ml/tf-scaling-test-jube/train.py
   :language: python


jube_ddp.sh
+++++++++++

.. literalinclude:: ../../../tutorials/distributed-ml/tf-scaling-test-jube/jube_ddp.sh
   :language: bash


.. TODO: improve notebook rendering

.. bench_plot.ipynb
.. ++++++++++++++++

.. .. literalinclude:: ../../../tutorials/distributed-ml/tf-scaling-test-jube/bench_plot.ipynb
..    :language: python
