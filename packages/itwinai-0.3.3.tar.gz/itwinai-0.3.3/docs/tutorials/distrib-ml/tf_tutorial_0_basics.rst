Introduction on distributed training with TensorFlow
===========================================================

.. include:: ../../../tutorials/distributed-ml/tf-tutorial-0-basics/README.md
   :parser: myst_parser.sphinx_

train.py
++++++++

.. literalinclude:: ../../../tutorials/distributed-ml/tf-tutorial-0-basics/train.py
   :language: python


tfmirrored_slurm.sh
+++++++++++++++++++

.. literalinclude:: ../../../tutorials/distributed-ml/tf-tutorial-0-basics/tfmirrored_slurm.sh
   :language: bash

