ML-based extreme events detection and characterization (xtclim, CERFACS)
========================================================================
 
 .. include:: ../../use-cases/xtclim/README.md
    :parser: myst_parser.sphinx_
    :start-line: 3
