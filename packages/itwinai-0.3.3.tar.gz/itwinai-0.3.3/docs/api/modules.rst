Python SDK 
==========

.. toctree::
   :maxdepth: 4

   itwinai.components
   itwinai.distributed
   itwinai.loggers
   itwinai.parser
   itwinai.pipeline
   itwinai.scalability_report.modules
   itwinai.serialization
   itwinai.tests.modules
   itwinai.tf.modules
   itwinai.torch.modules
   itwinai.type
   itwinai.utils
