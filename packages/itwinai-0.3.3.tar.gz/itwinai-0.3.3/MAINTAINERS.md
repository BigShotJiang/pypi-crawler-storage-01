# Authors

## Mantainers

- Matteo Bunino - CERN - matteo.bunino\<at\>cern.ch
- Jarl Sondre Saether - CERN - jarl.sondre.saether\<at\>cern.ch
- Anna Elisa Lappe - CERN - anna.elisa.lappe\<at\>cern.ch
- Rakesh Sarma - FZJ - r.sarma\<at\>fz-juelich.de

## Contributors

- Kalliopi Tsolaki - CERN - kalliopi.tsolaki\<at\>cern.ch
- Killian Verder - CERN - killian.verder\<at\>cern.ch
- Henry Mutegeki - CERN - henry.mutegeki\<at\>cern.ch
- Roman Machacek - CERN - roman.machacek\<at\>cern.ch
- Alexander Zoechbauer - CERN - alexander.zoechbauer\<at\>cern.ch
- Mario Ruettgers - FZJ - m.ruettgers\<at\>fz-juelich.de

[Full contributors list](https://github.com/interTwin-eu/itwinai/graphs/contributors)
