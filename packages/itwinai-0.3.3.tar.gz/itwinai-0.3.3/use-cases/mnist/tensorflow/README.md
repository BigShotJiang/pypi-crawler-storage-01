# TensorFlow example on MNIST dataset

**Integration author(s)**: Roman Machacek (CERN), Matteo Bunino (CERN)

## Training

```bash
# Run the whole training pipeline
itwinai exec-pipeline +pipe_key=pipeline
```
