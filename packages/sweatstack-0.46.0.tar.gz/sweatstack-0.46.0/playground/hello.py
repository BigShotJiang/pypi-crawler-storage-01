def main():
    print("Hello from playground!")


if __name__ == "__main__":
    main()
