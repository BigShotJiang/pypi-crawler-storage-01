# pylint: disable=missing-module-docstring
from .manager import TemplateManager
