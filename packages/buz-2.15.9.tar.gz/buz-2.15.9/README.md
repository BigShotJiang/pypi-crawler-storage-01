# Buz

Buz is a set of light, simple and extensible implementations of event, command and query buses.
 