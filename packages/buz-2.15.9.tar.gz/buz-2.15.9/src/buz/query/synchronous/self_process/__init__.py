from buz.query.synchronous.self_process.self_process_query_bus import SelfProcessQueryBus

__all__ = ["SelfProcessQueryBus"]
