from buz.query.asynchronous.self_process.self_process_query_bus import SelfProcessQueryBus

__all__ = ["SelfProcessQueryBus"]
