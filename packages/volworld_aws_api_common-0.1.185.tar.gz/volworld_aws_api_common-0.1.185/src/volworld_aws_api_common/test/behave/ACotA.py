from typing import Final

# ====== ContextA: Attribute ======


class ACotA:

    LoginUser: Final[str] = "LoginUser"

    MockScenario: Final[str] = "MockScenario"

    TargetPage: Final[str] = "TargetPage"

    UserName: Final[str] = "UserName"
    UserPassword: Final[str] = "UserPassword"

