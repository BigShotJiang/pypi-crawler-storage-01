from aenum import IntEnum


class ProjectModeType(IntEnum):
    StandAlone = 1

    Combined = 99

