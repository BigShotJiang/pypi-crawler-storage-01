from aenum import IntEnum


class QueryModeType(IntEnum):
    MockTest = 10

    ServerTest = 66

    Product = 99

