from __future__ import annotations

import loopy.cli


loopy.cli.main()
