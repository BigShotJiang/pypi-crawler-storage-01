"""Module for Plotter"""

raise ImportError("'pina.plotter' is deprecated and cannot be imported.")
