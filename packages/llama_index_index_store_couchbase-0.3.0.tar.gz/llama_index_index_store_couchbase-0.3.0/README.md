# LlamaIndex Index_Store Integration: Couchbase Index Store
