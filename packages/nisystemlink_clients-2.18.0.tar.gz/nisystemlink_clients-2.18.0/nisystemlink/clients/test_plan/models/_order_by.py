from enum import Enum


class OrderBy(Enum):
    """The state of the test plan."""

    ID = "ID"
    UPDATE_AT = "UPDATE_AT"
