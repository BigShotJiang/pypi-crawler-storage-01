"""Empty revision due to wrong revision creation

Revision ID: 5ab9d7a75887
Revises: d80267806131
Create Date: 2022-06-06 22:33:26.331874

"""

# revision identifiers, used by Alembic.
revision = "5ab9d7a75887"
down_revision = "d80267806131"
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
