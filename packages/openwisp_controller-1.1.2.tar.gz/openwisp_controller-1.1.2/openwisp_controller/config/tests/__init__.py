# pragma: no cover
# kept for backward compatibility with previous versions
from .utils import (  # noqa
    CreateConfigMixin,
    CreateConfigTemplateMixin,
    CreateDeviceMixin,
    CreateTemplateMixin,
    CreateVpnMixin,
    TestVpnX509Mixin,
)
