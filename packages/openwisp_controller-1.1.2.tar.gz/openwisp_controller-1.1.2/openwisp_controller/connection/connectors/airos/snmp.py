from ..snmp import Snmp as BaseSnmp


class AirOsSnmp(BaseSnmp):
    pass
