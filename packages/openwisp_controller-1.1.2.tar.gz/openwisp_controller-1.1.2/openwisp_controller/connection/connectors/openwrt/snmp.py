from ..snmp import Snmp as BaseSnmp


class OpenWRTSnmp(BaseSnmp):
    pass
