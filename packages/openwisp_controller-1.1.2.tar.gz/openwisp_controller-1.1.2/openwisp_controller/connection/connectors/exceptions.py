class CommandFailedException(Exception):
    """
    raised when a command returns an unexpected result
    """

    pass
