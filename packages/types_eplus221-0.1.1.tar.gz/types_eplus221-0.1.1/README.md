# types_eplus221

Type stubs for EnergyPlusV22.1 generated with [mypy_eppy_builder 0.0.1](https://github.com/samuelduchesne/mypy-eppy-builder).
