from .core import load, loads, dump, dumps

__version__ = "1.0.0"
__all__ = ["load", "loads", "dump", "dumps"]