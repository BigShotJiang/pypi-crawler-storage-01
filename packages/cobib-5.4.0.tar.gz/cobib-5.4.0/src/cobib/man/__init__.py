"""coBib's manual.

.. include:: cobib.1.html_fragment
"""
