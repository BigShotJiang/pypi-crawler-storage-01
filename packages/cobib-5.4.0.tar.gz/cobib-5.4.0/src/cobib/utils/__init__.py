"""coBib's utilities.

This module provides some general purpose utilities.
This includes both, general purpose objects used throughout coBib's source code and test suite, as
well as helper methods exposed via the command line interface.
"""
