from aioinject.providers.abc import Provider


__all__ = ["Provider"]
