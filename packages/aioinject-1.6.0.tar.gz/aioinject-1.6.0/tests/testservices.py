class AbstractService:
    pass


class AbstractImplA(AbstractService):
    pass


class AbstractImplB(AbstractService):
    pass
