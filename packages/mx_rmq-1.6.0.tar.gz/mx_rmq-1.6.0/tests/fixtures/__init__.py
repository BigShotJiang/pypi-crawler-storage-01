"""
空的__init__.py文件，使fixtures目录成为Python包
"""