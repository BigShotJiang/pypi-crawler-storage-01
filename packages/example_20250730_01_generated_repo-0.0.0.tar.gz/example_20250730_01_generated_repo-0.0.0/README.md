# example_20250730_01_generated_repo

## Quick start

```bash
pip install example_20250730_01_generated_repo
```

```python
from example_20250730_01_generated_package import ...
```

## Contributing

```bash
# clone the repo
git clone https://github.com/momomozhang/example_20250730_01_generated_repo.git

# install the dev dependencies
make install

# run the tests
make test
```
