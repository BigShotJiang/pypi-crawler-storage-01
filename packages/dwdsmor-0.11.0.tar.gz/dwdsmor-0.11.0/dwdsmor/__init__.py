from .automaton import automata, lemmatizer
from .version import __version__

__all__ = ["automata", "lemmatizer", "__version__"]
