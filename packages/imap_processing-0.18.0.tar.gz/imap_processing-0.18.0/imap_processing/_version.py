# These version placeholders will be replaced later during substitution.
__version__ = "0.18.0"
__version_tuple__ = (0, 18, 0)
