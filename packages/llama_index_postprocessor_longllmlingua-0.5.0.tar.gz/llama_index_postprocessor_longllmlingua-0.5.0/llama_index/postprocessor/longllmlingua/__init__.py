from llama_index.postprocessor.longllmlingua.base import LongLLMLinguaPostprocessor

__all__ = ["LongLLMLinguaPostprocessor"]
