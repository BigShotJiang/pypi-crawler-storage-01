__VERSION__ = "4.4.4"


def getVersion():
    return __VERSION__
