import { ap as o, aq as n } from "./mermaid.core-9x_dKBN0.js";
const t = (a, r) => o.lang.round(n.parse(a)[r]);
export {
  t as c
};
