import { I as f } from "./Index-Sd0jT25B.js";
export {
  f as default
};
