from haupt.db.abstracts.bookmarks import BaseBookmark


class Bookmark(BaseBookmark):
    pass
