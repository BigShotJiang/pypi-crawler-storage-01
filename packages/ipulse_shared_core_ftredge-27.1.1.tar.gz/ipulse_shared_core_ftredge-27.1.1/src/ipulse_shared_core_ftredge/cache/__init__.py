"""Cache utilities for shared core."""
from ipulse_shared_core_ftredge.cache.shared_cache import SharedCache

__all__ = ['SharedCache']
