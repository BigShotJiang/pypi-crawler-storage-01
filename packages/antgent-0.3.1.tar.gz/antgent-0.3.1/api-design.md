- POST api/v1/agents/$agent-name
 {context:
  input: }
- POST api/v1/workflows/$workflow-name
  {
   context:
   input: 
  }
