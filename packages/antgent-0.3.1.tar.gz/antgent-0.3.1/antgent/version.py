#!/usr/bin/env python3
from ant31box.version import VERSION

from antgent import __version__

VERSION.set_version(__version__)
