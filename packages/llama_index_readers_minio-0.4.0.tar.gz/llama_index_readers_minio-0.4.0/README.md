# Minio Reader

## Install

`pip install llama-index-readers-minio`

## Import

from llama_index.core.readers.minio import MinioReader, BotoMinioReader`
