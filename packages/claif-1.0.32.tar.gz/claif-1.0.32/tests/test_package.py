"""Test suite for claif."""


def test_version():
    """Verify package exposes version."""
    import claif

    assert claif.__version__
