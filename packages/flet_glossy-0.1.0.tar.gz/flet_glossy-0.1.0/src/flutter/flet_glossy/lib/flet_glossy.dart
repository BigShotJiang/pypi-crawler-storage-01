library flet_glossy;

export "../src/create_control.dart" show createControl, ensureInitialized;
