"""Default package."""

__version__ = "3.0.12"
