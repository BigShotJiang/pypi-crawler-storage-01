# __main__.py

from mcp_12306 import main

main()