"""Scripts package for intent-kit."""
