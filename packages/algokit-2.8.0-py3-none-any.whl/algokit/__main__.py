from multiprocessing import freeze_support

from algokit.cli import algokit

freeze_support()
algokit()
