"""
Core XML Analysis Framework Components

This module contains the core framework components for XML analysis.
"""
