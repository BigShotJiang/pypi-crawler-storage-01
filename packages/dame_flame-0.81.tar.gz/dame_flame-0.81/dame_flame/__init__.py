"""
Copyright Duke University 2020
License: MIT
The :mod:`dame_flame` module includes matching models for causal inference
"""

from . import matching
from . import utils

