## 13.0.1.1.0 (2020-07-01)

**Features**

- - New setting *Update NFP on Stock Buffers on relevant events*.
  - New dedicated settings block.
    ([\#50](https://github.com/OCA/ddmrp/issues/50))

## 13.0.1.0.0 (2020-06-11)

- \[MIG/REF\] Migration of module to v13 and refactor (added new
  dedicated model for stock buffer).

## 11.0.1.3.0 (2019-02-21)

- \[ADD\] New chart that depict information about the supply and demand
  ( displaying also de order spike threshold and horizon) for a buffer.
  ([\#40](https://github.com/OCA/ddmrp/pull/40))

## 11.0.1.2.0 (2019-01-29)

- \[IMP\] Performance improvement of execution priority calculation and
  ADU. ([\#36](https://github.com/OCA/ddmrp/pull/36))
- \[IMP\] Use the minimum quantity to adjust the procure recommendation.
  ([\#37](https://github.com/OCA/ddmrp/pull/37))

## 11.0.1.1.0 (2018-08-31)

- \[IMP\] Implemented Blended ADU calculation method.
  ([\#23](https://github.com/OCA/ddmrp/pull/23))

## 11.0.1.0.0 (2018-07-16)

- Start of the history
