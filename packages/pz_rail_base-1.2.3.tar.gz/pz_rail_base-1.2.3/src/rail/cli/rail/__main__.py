# This file must exist with these contents
from .commands import cli

if __name__ == "__main__":
    cli()
