# Basic file to enable running the CLI with `python -m planetmapper`
# https://docs.python.org/3/library/__main__.html#main-py-in-python-packages

from . import cli

cli.main()
