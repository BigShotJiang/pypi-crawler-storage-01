# Copyright 2024 Marimo. All rights reserved.
import marimo

__generated_with = "0.5.2"
app = marimo.App()


@app.cell
def __():
    """
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell

    """
    qwerty = 10
    return qwerty,


@app.cell
def __(qwerty):
    """
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell
    hello, this is a cell

    """
    a = f"{qwerty} 10"
    return a,


@app.cell
def __(a):
    a
    return


if __name__ == "__main__":
    app.run()
