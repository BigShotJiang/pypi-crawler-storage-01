from llama_index.embeddings.gemini.base import GeminiEmbedding

__all__ = ["GeminiEmbedding"]
