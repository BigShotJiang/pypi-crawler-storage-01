from django.apps import AppConfig


class LoggingAppConfig(AppConfig):
    name = "ephios.modellogging"
