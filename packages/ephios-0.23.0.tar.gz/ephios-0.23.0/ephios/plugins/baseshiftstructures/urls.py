app_name = "baseshiftstructure"
urlpatterns = []
