from os import PathLike
from pathlib import Path
from typing import Union

AppPath = Union[str, Path, PathLike]
