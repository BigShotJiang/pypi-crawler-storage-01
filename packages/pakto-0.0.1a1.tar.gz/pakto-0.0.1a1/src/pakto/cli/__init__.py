"""CLI utilities for Pakto."""
