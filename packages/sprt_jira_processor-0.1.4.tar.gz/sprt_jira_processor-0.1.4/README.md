# JIRA Processor

## Overview
JIRA Processor is a Python library designed to process JIRA issues and generate summaries using AI.

## Installation
```bash
pip install jira_processor
