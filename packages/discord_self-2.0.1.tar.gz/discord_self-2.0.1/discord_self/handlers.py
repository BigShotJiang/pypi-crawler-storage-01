from discord_self._vendor.discord.handlers import CaptchaHandler

__all__ = ["CaptchaHandler"]
