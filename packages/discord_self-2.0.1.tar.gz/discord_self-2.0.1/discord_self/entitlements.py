from discord_self._vendor.discord.entitlements import Entitlement, Gift, GiftBatch

__all__ = ["Entitlement", "Gift", "GiftBatch"]
