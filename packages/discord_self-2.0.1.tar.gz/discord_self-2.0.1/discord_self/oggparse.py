from discord_self._vendor.discord.oggparse import OggError, OggPage, OggStream

__all__ = ["OggError", "OggPage", "OggStream"]
