from discord_self._vendor.discord.permissions import PermissionOverwrite, Permissions

__all__ = ["PermissionOverwrite", "Permissions"]
