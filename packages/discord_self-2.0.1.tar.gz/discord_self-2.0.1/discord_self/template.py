from discord_self._vendor.discord.template import Template

__all__ = ["Template"]
