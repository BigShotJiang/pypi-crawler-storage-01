from discord_self._vendor.discord.connections import Connection, PartialConnection

__all__ = ["Connection", "PartialConnection"]
