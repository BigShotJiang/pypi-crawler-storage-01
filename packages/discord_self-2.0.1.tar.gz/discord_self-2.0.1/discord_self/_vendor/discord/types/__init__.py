"""
discord.types
~~~~~~~~~~~~~~

Typings for the Discord API

:copyright: (c) 2015-present Rapptz
:license: MIT, see LICENSE for more details.

"""
