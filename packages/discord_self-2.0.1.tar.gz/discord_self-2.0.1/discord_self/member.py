from discord_self._vendor.discord.member import Member, VoiceState

__all__ = ["Member", "VoiceState"]
