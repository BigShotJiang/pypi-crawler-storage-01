from discord_self._vendor.discord.context_managers import Typing

__all__ = ["Typing"]
