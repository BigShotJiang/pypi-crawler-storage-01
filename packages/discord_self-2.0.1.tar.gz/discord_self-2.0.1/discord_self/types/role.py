from discord_self._vendor.discord.types.role import Role, RoleTags
from discord_self._vendor.discord.types.snowflake import Snowflake

__all__ = ["Role", "RoleTags", "Snowflake"]
