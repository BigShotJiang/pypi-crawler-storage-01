from discord_self._vendor.discord.types.snowflake import Snowflake, SnowflakeList

__all__ = ["Snowflake", "SnowflakeList"]
