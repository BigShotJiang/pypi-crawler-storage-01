from discord_self._vendor.discord.emoji import Emoji

__all__ = ["Emoji"]
