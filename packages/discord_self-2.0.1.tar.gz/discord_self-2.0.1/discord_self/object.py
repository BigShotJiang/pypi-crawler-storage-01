from discord_self._vendor.discord.object import Object

__all__ = ["Object"]
