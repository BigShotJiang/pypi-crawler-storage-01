from discord_self._vendor.discord.role import Role, RoleTags

__all__ = ["Role", "RoleTags"]
