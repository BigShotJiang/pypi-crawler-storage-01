from discord_self._vendor.discord.stage_instance import StageInstance

__all__ = ["StageInstance"]
