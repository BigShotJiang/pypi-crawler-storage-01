from synapse_sdk.i18n import gettext as _


def get_message():
    return _('hello world from sdk')
