class NoCollectionError(RuntimeError):
    pass


class TooManyCollectionsError(RuntimeError):
    pass