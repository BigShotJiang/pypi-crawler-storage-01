name = "xr-360-camera-streamer"
version = "0.0.1"
copyright = "Copyright 2025, Yunho Cho"
