# Parent Manager

::: tkinter_layout_helpers.parent_manager
