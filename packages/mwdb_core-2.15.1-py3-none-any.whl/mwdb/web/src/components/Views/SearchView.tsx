import { RecentObjects } from "../ShowObject/common/RecentObjects";

export function SearchView() {
    return <RecentObjects />;
}
