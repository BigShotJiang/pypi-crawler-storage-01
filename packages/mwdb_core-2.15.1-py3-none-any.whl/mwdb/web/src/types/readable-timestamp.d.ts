declare module "readable-timestamp";
