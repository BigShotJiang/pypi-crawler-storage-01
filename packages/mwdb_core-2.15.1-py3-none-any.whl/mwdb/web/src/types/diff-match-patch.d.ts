declare module "diff-match-patch";
