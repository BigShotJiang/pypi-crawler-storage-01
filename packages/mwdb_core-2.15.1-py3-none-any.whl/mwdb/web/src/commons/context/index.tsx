import { ObjectContextValues } from "@mwdb-web/types/context";
import React from "react";

export const ObjectContext = React.createContext({} as ObjectContextValues);
