This module makes suggestions for promotions whose rules include a product added to the
cart. It also allows you to configure and apply these promotions with an elegant eCommerce
wizard.
