To apply promotions:

Option 1:

#. Go to /promotions and choose the one apply.
#. You'll be prompted to check the promotion configuration.
#. Apply after that.

Option 2:

#. Add a product in the promotion rules.
#. A cart suggestion will appear.
#. Add the promotion and configure the options.

Option 3:

#. Select a suggested promotion in the shopping cart from a list of "Suggested promotions".
#. Add the promotion and configure the options.
