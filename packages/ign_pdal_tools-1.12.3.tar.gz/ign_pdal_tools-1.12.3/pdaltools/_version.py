__version__ = "1.12.3"


if __name__ == "__main__":
    print(__version__)
