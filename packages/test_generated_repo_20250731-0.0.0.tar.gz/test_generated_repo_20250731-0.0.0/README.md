# test_generated_repo_20250731

## Install as package

```bash
pip install test_generated_repo_20250731
```

```python
from test_generated_repo_20250731 import ...
```

## Contributing

```bash
# clone the repo
git clone https://github.com/momomozhang/test_generated_repo_20250731.git

# install the dev dependencies
make install

# run the tests
make test
```
