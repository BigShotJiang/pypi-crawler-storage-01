"""
###  show_file

Cats a file.

#### Parameters:

- fn: filepath

"""

from ..make_file import *

run = show_file
