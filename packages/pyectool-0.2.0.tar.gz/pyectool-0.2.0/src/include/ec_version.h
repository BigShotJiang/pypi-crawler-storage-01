#define CROS_ECTOOL_VERSION "0.0.1-isolate"
#define DATE __DATE__
#define BUILDER "none"
