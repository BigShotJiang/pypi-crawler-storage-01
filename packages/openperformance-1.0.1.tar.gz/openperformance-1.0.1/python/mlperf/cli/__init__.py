"""
Command Line Interface for ML Performance Engineering Platform.
"""

from .main import app, main

__all__ = ["app", "main"] 