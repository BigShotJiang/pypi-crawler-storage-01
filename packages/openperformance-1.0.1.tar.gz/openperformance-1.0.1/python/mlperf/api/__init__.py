"""
FastAPI web service for ML Performance Engineering Platform.
"""

from .main import app

__all__ = ["app"] 