OS Data Hub Downloads API
=========================

Open Data Product
-----------------------------------------

.. automodule:: osdatahub.DownloadsAPI.opendata
   :members:
   :undoc-members:
   :show-inheritance:

Data Package
-----------------------------------------

.. automodule:: osdatahub.DownloadsAPI.data_package
   :members:
   :undoc-members:
   :show-inheritance:
