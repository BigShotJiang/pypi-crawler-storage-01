OS Data Hub Places API
=========================

PlacesAPI
-----------------------------------------

.. automodule:: osdatahub.PlacesAPI.places_api
   :members:
   :undoc-members:
   :show-inheritance:
