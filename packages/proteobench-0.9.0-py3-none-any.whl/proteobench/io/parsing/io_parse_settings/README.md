# io_parse_settings

Configuration files for parsing output for modules from data analysis software 
output files.
