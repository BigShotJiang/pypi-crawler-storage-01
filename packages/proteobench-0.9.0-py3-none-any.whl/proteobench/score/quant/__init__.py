"""
Module for quantification scoring.
"""
