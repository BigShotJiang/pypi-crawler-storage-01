To build docs:

  - `cd docs`
  - create an environment using the `requirements.txt` file in this directory, e.g., `pip install -r requirements.txt`
  - run `make html`
  - open `build/html/index.html`
