from .trust_free import TRUST  # note: trust_free is the compiled .so module

__all__ = ['TRUST']
