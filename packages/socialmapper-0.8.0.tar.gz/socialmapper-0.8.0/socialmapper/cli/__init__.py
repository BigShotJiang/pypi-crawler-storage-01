"""CLI module for SocialMapper."""

# Import main function from cli_main module
from ..cli_main import main

__all__ = ["main"]
