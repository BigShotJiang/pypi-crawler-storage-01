"""SocialMapper API Server

FastAPI-based REST API server that wraps the SocialMapper library
to provide a clean separation between frontend and backend components.
"""

__version__ = "0.1.0"
