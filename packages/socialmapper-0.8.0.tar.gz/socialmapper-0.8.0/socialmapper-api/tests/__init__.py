"""Test suite for SocialMapper API."""
