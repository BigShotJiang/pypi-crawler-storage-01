# [Agentic] Hello ACP

This tutorial demonstrates how to implement the base agentic ACP type in AgentEx agents.

## Official Documentation

[000 Hello Base Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/base/hello_acp/) 