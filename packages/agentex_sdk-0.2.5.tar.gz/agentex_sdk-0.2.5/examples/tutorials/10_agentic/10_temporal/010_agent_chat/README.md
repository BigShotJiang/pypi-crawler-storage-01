# [Agentic] Agent Chat with Temporal

This tutorial demonstrates how to implement streaming multiturn tool-enabled chat with tracing using Temporal workflows in AgentEx agents.

## Official Documentation

[010 Agent Chat Temporal Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/temporal/agent_chat/)