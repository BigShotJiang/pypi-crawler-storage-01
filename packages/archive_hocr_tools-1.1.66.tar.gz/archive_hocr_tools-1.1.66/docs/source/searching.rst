.. _searching:

Searching
=========


.. automodule:: hocr.searching
    :members:
