.. _parse:

Parsing hOCR
============


.. automodule:: hocr.parse
    :members:
