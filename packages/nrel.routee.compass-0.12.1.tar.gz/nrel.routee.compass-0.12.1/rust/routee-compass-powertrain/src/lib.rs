#![doc = include_str!("doc.md")]

pub mod model;
