mod debug_builder;
mod debug_plugin;

pub use debug_builder::DebugInputPluginBuilder;
pub use debug_plugin::DebugInputPlugin;
