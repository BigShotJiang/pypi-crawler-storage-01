#![doc = include_str!("doc.md")]

pub mod app;
pub mod plugin;
