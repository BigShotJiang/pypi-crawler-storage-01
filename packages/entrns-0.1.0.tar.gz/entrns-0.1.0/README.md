# entrns

Una librería simple para crear bots básicos entrenados en tiempo simulado, tokenización y corrección ligera.
