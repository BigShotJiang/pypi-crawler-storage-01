"""Generated gRPC code for user service"""

from .user_service_pb2 import *
from .user_service_pb2_grpc import *
