![pollenisator_flat](https://github.com/AlgoSecure/Pollenisator/wiki/uploads/1e17b6e558bec07767eb12506ed6b2bf/pollenisator_flat.png)

 

## INSTALL ##
[Read the installation procedure in the wiki](https://github.com/fbarre96/PollenisatorGUI/wiki)

