# CeroChat

Real-time terminal chat application

## Installation

```bash
pip install cerochat
```
