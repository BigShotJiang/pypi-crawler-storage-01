
import os

SUPABASE_URL = os.getenv("SUPABASE_URL", "https://inqmjggdcynrcjyksdsg.supabase.co")
SUPABASE_API_KEY = os.getenv("SUPABASE_API_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlucW1qZ2dkY3lucmNqeWtzZHNnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4OTM2MjcsImV4cCI6MjA2OTQ2OTYyN30.lNV_qRxgOkojPm-vmLh6ROo2YjDOhrXAgkRt4UaNr4Y")