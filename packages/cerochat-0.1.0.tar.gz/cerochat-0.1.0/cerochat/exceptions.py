class UsernameTakenError(Exception):
    """Foydalanuvchi nomi band bo'lganda chiqadigan xato"""
    pass

class ConnectionError(Exception):
    """Ulanish xatolari uchun"""
    pass