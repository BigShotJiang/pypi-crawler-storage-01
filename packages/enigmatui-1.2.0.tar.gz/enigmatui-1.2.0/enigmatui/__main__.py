from enigmatui.app import EnigmaApp
import os
    
def main():
    # os.system("printf '\033[8;30;80t'")
    app = EnigmaApp()
    app.run() 

if __name__ == "__main__":
    main()