"""Nextplot plot functions."""
