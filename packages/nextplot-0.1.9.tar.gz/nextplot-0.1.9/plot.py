#!/usr/bin/env python3
# PYTHON_ARGCOMPLETE_OK
from nextplot import main

if __name__ == "__main__":
    main.entry_point()
