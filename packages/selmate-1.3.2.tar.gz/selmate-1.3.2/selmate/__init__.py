import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__version__ = '1.3.2'