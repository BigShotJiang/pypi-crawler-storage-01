# Puddy Approves
This is a tutorial on how to use a data struct description

# Data Structure Report - created at 2025-07-29 15:54
	Data Structure  found from the search string:  `All`

<a id="3e4bc9a1-2661-4d24-a753-b26060c61e34"></a>
# Data Structure Name: 

## Qualified Name
[DataStruct::TBDF-Incoming Weekly Measurement Data](#3e4bc9a1-2661-4d24-a753-b26060c61e34)

## Description
This describes the weekly measurement data for each patient for the Teddy Bear drop foot clinical trial.

## GUID
3e4bc9a1-2661-4d24-a753-b26060c61e34

[[Data Structure]]