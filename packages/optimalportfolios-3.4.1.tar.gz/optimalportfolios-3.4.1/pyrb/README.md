
This package is forked from pyrb package https://github.com/jcrichard/pyrb

for the distribution of optimalportfolios package, because Pyrb is not available through pip install

jcrichard/pyrb is licensed under the  MIT License

for 