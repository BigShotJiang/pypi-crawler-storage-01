__VERSION__ = "4.4.3"


def getVersion():
    return __VERSION__
