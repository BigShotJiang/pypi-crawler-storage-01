Design Tools
************

In order to assist developers peakrdl-python can be run from a script. This means the
peakrdl-python package does not need to be installed and uninstalled during development.

See ``generate_and_test.py``

.. code-block:: bash

    python -m generate_and_test --RDL_source_file "tests\testcases\basic.rdl" --root_node "basic"