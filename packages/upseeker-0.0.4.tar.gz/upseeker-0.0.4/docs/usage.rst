=====
Usage
=====

To use test-seeker in a project::

    import test_seeker
