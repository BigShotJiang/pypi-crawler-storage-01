.. include:: /../common/unsafe.rst

Types
==============

Imported with::

    import toy_crypto.types

.. automodule:: toy_crypto.types
    :synopsis: Helpful(?) type definitions and guards.
    :members: