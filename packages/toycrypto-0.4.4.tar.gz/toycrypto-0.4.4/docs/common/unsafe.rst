.. DANGER::
  Nothing here should be used for any security purposes.
  
  - If you need cryptographic tools in a Python environment use `pyca`_ or `PyNaCl`_.
  - If you need efficient and reliable abstract math utilities in a Python-like environment consider using `SageMath`_.
  