"""The pyepggrab package providing base functionality for grabbers.

Grabbers are in the `grabbers` package.
"""
