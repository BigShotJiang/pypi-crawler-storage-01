from __future__ import annotations

from ..statement import BlockStatement, SimpleStatement


class JavaSimpleStatement(SimpleStatement): ...


class JavaBlockStatement(BlockStatement): ...
