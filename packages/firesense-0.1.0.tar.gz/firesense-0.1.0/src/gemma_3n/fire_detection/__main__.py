"""Fire detection CLI entry point."""

from gemma_3n.fire_detection.cli import app

if __name__ == "__main__":
    app()