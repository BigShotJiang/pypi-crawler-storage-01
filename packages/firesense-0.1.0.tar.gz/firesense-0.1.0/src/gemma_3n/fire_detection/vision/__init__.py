"""Vision processing utilities for fire detection."""

from gemma_3n.fire_detection.vision.processor import VisionProcessor

__all__ = ["VisionProcessor"]