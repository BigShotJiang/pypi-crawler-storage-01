"""Gemma 3N - A modern Python project managed with uv."""

__version__ = "0.1.0"
__author__ = "Gregory Mulla"
__email__ = "gregory.cr.mulla@gmail.com"