from .hifitime import *

__doc__ = hifitime.__doc__
if hasattr(hifitime, "__all__"):
    __all__ = hifitime.__all__