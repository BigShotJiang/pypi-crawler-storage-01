from llama_index.readers.zendesk.base import ZendeskReader

__all__ = ["ZendeskReader"]
