from MCQuantLib.Path.path import Path

class Barrier(Path):
    pass
