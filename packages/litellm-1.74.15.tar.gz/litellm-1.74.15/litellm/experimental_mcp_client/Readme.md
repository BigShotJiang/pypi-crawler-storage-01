# LiteLLM MCP Client

LiteLLM MCP Client is a client that allows you to use MCP tools with LiteLLM.



