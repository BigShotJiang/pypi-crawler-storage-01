"""InfraNinja - Infrastructure automation toolkit"""

__version__ = "1.0.0"
