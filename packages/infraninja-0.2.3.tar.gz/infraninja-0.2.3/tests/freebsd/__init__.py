# FreeBSD-specific tests for infraninja
