#! /usr/bin/env python3
# -*- coding: utf-8 -*-
"""
# File          : __init__.py
# Author        : Sun YiFan-Movoid
# Time          : 2024/8/23 0:21
# Description   : 
"""
from .common import BasicCommon


class Basic(BasicCommon):
    pass
