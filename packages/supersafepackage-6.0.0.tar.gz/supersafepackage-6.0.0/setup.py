from setuptools import setup, find_packages

setup(
    name='supersafepackage',
    version='6.0.0',  # Higher than internal/private version
    author='Red Team',
    description='Fake package for dependency confusion PoC',
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.6',
)
