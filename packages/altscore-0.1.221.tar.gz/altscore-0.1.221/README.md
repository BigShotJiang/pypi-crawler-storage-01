# AltScore Python SDK

This is the Python SDK for AltScore. It provides a simple interface to the AltScore API.
