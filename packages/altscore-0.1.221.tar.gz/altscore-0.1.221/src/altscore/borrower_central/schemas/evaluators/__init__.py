from altscore.borrower_central.model.evaluators import EvaluatorInput, Instance, Entity
