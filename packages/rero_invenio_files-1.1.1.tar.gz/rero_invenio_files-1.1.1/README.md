<!-- RERO-Invenio-Files
Copyright (C) 2024 RERO.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, version 3 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>. -->

<!-- PROJECT SHIELDS -->
[![Github actions
status](https://github.com/rero/rero-invenio-files/actions/workflows/continuous-integration-test.yml/badge.svg)](https://github.com/rero/rero-invenio-files/actions/workflows/continuous-integration-test.yml)
[![Release
Number](https://img.shields.io/github/tag/rero/rero-invenio-files.svg)](https://github.com/rero/rero-invenio-files/releases/latest)
[![Downloads](https://img.shields.io/pypi/dm/rero-invenio-files.svg)](https://pypi.python.org/pypi/rero-invenio-files)
[![License](https://img.shields.io/badge/License-AGPL%20v3-blue.svg)](http://www.gnu.org/licenses/agpl-3.0.html)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)

Files support for the RERO invenio instances.
