from algopython_com import algopython_init
from algopython_cmd import * 

__all__ = ['move', 'light', 'playSound', 'wait', 'listAvailableSounds','moveStop','wait_sensor',
           'lightStop','soundStop','rotations','get_sensor_value','FOREVER','algopython_init']