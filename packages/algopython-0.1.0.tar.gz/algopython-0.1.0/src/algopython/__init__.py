from algopython_com import algopython_init
from algopython_cmd import * 