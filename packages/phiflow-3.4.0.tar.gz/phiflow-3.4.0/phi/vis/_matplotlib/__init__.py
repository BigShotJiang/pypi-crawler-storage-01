from ._matplotlib_plots import MATPLOTLIB, savefig
from ._scalars import plot_scalars, smooth_uniform_curve
