"""
Alias for [`phiml.math.extrapolation`](https://tum-pbs.github.io/PhiML/phiml/math/extrapolation.html).
"""
from phiml.math.extrapolation import *
