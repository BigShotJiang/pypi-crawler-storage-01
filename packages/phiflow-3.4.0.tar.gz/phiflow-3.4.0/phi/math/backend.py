"""
Alias for [`phiml.backend`](https://tum-pbs.github.io/PhiML/phiml/backend/index.html).
"""
from phiml.backend import *
