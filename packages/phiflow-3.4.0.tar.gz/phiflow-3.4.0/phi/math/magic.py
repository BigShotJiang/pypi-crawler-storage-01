"""
Alias for [`phiml.math.magic`](https://tum-pbs.github.io/PhiML/phiml/math/magic.html).
"""
from phiml.math.magic import *
