"""Streamlit api for generic-helpers application"""

from st_pages import show_pages_from_config

show_pages_from_config()
