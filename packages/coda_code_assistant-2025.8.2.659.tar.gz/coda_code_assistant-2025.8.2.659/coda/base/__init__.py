"""🧱 BASE MODULES
Core foundation modules that implement fundamental functionality.

All base modules are standalone and do not depend on other Coda modules.
"""
