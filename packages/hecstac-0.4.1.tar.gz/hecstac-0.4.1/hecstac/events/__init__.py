"""HEC event stac items."""
