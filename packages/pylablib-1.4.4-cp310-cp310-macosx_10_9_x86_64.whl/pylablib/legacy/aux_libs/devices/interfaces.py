from ...core.devio.interface import IDevice

class ITranslationStage(IDevice):
    pass