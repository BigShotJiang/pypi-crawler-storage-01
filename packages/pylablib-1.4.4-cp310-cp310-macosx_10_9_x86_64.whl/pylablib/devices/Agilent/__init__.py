from .base import AgilentError
from .pressure import XGS600