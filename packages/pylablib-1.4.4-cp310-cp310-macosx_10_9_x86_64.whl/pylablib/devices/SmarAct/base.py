from ...core.devio.comm_backend import DeviceError

class SmarActError(DeviceError):
    """Generic SmarAct error"""