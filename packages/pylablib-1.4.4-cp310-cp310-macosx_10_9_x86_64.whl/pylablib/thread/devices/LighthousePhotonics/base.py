from ..generic import lasers


class SproutGThread(lasers.IPumpLaserThread):
    _device_class="LighthousePhotonics.SproutG"