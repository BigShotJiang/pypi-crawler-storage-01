"""
code2md - Convert code directory structure and contents to markdown
"""

import importlib.metadata

__version__ = importlib.metadata.version("code2md")
