"""MkDocs plugin for LLM-friendly documentation."""

__version__ = "0.2.0"

from .plugin import LlmsTxtPlugin

__all__ = ["LlmsTxtPlugin"]
