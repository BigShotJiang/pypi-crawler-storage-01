from django.apps import AppConfig


class ChibiDjangoConfig(AppConfig):
    name = 'chibi_django'
