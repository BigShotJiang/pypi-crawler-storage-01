import logging


logger = logging.getLogger( 'chibi_django.manager.base_64_pk' )
