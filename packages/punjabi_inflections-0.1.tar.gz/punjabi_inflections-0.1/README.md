# Punjabi Verb Forms

![PyPI](https://img.shields.io/pypi/v/punjabi-verb-forms)
![Downloads](https://img.shields.io/pypi/dm/punjabi-verb-forms)
![Python Versions](https://img.shields.io/pypi/pyversions/punjabi-verb-forms)
![License](https://img.shields.io/pypi/l/punjabi-verb-forms)

> A Python package for generating inflections of Punjabi verbs written in Shahmukhi script.

---

## 🚀 Installation

```bash
pip install punjabi-verb-forms