# DataLoaders Heavy

These DataLoader Classes are intended to load larger dataset into AWS. For large data we need to use AWS Glue Jobs/Batch Jobs and in general the process is a bit more complicated and has less features.

If you have smaller data please see [DataLoaders Light](data_loaders_light.md)

::: workbench.core.transforms.data_loaders.heavy