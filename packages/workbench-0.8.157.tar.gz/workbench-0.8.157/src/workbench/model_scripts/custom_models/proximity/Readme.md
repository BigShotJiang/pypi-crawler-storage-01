# Proximity Model Scripts
Welcome to the set of model scripts related to proximity queries (Neighborhood queries). These models are focused on providing closest neighbors either from a Feature Set perspective or from a fingerprint similarity perspective (both are useful)


### References
