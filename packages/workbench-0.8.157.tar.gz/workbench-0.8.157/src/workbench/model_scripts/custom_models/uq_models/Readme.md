# Confidence Model Scripts
Welcome to the set of model scripts related to confidence metrics. Right now we just have:

- Bayesian Regression
- Gaussian Process Regression


### References
