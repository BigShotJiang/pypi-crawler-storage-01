# AWS EMR Serverless
- See: <https://aws.amazon.com/emr/serverless/>