# CHANGELOG

<!-- version list -->

## v1.3.1 (2025-08-03)

### Bug Fixes

- **ci**: Resolve PyPI publishing workflow
  ([`7a11c53`](https://github.com/matonb/anovable/commit/7a11c53a73d8b943439ec4b7f0f5c95ffd7bda73))


## v1.3.0 (2025-08-02)

### Features

- Enable shell completion for CLI commands
  ([`6e66dfb`](https://github.com/matonb/anovable/commit/6e66dfbb6a15ae48950854e0d43550bf294aeb31))


## v1.2.1 (2025-08-02)

### Bug Fixes

- Prevent timer auto-start when cooker is not running
  ([`d038a1f`](https://github.com/matonb/anovable/commit/d038a1f70bdc49576cab46e3d2979c42ea8f8285))


## v1.2.0 (2025-08-02)

### Features

- Improve timer functionality
  ([`5ab9e6e`](https://github.com/matonb/anovable/commit/5ab9e6ebad9e3dd6c95e557a7eb80c897a5db1d5))


## v1.1.0 (2025-08-02)

### Features

- Add retry logic for timer reading to improve reliability
  ([`cb77a16`](https://github.com/matonb/anovable/commit/cb77a16404380610dd9140b267c34bba63136ce4))


## v1.0.0 (2025-08-01)

- Initial Release

## v1.0.0 (2025-08-01)

- Initial Release
