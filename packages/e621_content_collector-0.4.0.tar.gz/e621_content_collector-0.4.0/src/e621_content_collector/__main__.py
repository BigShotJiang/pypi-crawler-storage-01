if __name__ == "__main__":
    from e621_content_collector import tool
    tool()
