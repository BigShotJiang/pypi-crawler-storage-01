def assert_eq(received, expected):
    assert received == expected, f"Expected {expected}, but got {received}"
