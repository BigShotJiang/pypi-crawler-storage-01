# BeyondDesk gRPC Protocols (Go)

Protocol Buffer definitions and generated Go gRPC code for BeyondDesk backend services.

## Installation

```bash
go get github.com/beyond-desk/beyonddesk-grpc-protocols