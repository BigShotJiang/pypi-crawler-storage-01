"""Configuration module for mcp-this-openapi."""
