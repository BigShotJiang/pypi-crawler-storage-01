"""MCP Server that creates tools from OpenAPI/Swagger specifications."""

__version__ = "0.0.1"
