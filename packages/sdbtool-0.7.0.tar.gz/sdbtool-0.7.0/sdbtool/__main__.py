from sdbtool.cli import sdbtool_command  # pragma: no cover

if __name__ == "__main__":
    sdbtool_command()
