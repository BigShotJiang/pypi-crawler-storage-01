# asad-websearch

A DuckDuckGo-based web search tool you can use in OpenAI Agents SDK.

## Usage

```python
from asad_websearch import duckduckgo_search
result = await duckduckgo_search("latest news")
print(result)
