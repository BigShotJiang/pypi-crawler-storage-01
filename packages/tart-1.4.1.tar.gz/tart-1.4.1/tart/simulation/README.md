# Simulation Code #

Type python correlate_simulated_signal.py and see what happens!


## Simulation of TART operation ##

Files in this directory are designed to simulate the sampling of a point noise source by a MAX2769B.

Samples are to be output in NRZ binary format for testing of the correlation software.

The aim is to answer the question "What output do we expect, and is everything working"

This is a work in progress and detailed instructions will be posted in due course.


