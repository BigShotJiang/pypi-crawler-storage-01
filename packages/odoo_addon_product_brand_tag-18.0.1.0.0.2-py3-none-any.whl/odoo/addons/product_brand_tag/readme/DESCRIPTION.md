Add tags to product brands.

Inspired by product_template_tags by ACSONE.
