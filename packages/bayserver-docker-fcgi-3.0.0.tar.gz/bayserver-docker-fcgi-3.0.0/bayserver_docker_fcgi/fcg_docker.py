from bayserver_core.docker.docker import Docker

class FcgDocker(Docker):
    PROTO_NAME = "fcgi"