=====
Usage
=====

to VxCi in a project::

	import vxci
