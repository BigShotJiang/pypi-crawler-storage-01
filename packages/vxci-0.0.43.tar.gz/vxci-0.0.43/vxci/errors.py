class DuplicateBuilderError(Exception):
    pass


class NotImplementedError(Exception):
    pass
