# DashFrame

A quick builder for dash application.

## Usage

```bash

pdm add dashframe
# or
uv add dashframe

```

## Supported Project

1.  high-energy: <https://github.com/Svtter/high-energy.git>
2.  artificial-joints: <https://github.com/Svtter/artificial-joints>

## Related Projects

1.  <https://dash-bootstrap-components.opensource.faculty.ai/docs/components/button/>
