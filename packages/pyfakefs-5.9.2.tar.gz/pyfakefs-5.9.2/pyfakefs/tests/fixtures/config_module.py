configurable_value = "another value"
