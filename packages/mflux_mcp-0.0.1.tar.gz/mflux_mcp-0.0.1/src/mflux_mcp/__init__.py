def hello() -> str:
    return "Hello from mflux-mcp!"
