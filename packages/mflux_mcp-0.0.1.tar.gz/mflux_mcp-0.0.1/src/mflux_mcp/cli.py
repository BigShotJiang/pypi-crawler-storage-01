#!/usr/bin/env python3

def main():
    print("hello world - this library is coming soon to enable MCP on MLX-powered Flux image generation")


if __name__ == "__main__":
    main()