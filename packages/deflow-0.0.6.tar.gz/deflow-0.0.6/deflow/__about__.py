__version__: str = "0.0.6"
__version_tuple__: tuple[int, ...] = tuple(map(int, __version__.split(".")[:3]))
