from ....errors import BaseDeFlowError


class BaseV3Error(BaseDeFlowError): ...
