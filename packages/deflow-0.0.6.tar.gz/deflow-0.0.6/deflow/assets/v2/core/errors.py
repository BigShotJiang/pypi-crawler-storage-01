from ....errors import BaseDeFlowError


class BaseV2Error(BaseDeFlowError): ...
