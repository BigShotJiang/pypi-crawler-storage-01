from ....errors import BaseDeFlowError


class BaseV1Error(BaseDeFlowError): ...
