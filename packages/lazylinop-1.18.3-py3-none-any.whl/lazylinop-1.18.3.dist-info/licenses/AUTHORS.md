## Authors

- Pascal Carrivain
- Simon Delamare
- Hakim Hadj-Djilani
- Remi Gribonval
