# 处理关于样式的模块，包含颜色等
from .color import Color, color
from .font import Font, font, default_font