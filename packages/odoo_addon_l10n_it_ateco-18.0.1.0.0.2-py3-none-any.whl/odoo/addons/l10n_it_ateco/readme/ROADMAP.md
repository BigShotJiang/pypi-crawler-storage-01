This module needs a method to import una-tantum ateco codes from ISTAT
web site in order maintain them up to date.

See:

- <https://www.istat.it/it/archivio/17888>
