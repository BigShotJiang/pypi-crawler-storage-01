**Italiano**

> Per aggiornare la lista dei codici ATECO:
> - *Contatti → Configurazione → Categorie Ateco*
> - Imposta le categorie ATECO sulla form del contatto nella nuova tab "Ateco"

**Inglese**

> To set up ATECO categories
> - Go to *Contacts → Configuration → Ateco Categories* to create or edit categories
> - Set the categories on the partner form there on the new tab "Ateco"
