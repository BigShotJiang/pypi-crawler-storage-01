def hello() -> str:
    return "Hello from infusedb-py!"
