"""Plots for sensitivity analysis."""
