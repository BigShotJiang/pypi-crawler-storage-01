"""Doubly robust DiD estimators."""
