"""Bootstrap methods for doubly robust DiD estimators."""
