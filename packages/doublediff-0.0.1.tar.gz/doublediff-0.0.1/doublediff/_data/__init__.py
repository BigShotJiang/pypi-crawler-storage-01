"""Datasets for doublediff."""
