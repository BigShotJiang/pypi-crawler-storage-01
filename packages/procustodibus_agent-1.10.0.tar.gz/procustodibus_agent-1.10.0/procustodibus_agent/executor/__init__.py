"""Executor."""

from procustodibus_agent.executor.execution import execute_desired  # noqa: F401
