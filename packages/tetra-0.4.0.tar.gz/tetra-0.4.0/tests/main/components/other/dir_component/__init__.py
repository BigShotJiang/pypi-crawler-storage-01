from tetra import Component


class DirComponent(Component):
    pass
