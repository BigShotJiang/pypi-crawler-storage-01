# Python cookietools.

## Installation

You can install from [pypi](https://pypi.org/project/python-cookietools/)

```console
pip install -U python-cookietools
```

## Usage

```python
import cookietools
```
