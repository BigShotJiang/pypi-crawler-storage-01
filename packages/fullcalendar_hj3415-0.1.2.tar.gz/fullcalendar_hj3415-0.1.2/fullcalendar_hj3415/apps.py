from django.apps import AppConfig


class FullcalendarHj3415Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fullcalendar_hj3415'
