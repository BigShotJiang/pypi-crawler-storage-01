See https://repo2docker.readthedocs.io/en/latest/contributing/tasks.html#creating-a-release
