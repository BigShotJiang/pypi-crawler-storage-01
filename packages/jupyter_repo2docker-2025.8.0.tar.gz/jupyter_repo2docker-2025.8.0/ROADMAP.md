The repo2docker roadmap is hosted in the repo2docker documentation.
You can access it at the following link:

https://repo2docker.readthedocs.io/en/latest/contributing/roadmap.html
