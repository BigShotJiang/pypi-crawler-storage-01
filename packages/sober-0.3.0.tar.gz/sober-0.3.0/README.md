<picture>
    <source media="(prefers-color-scheme: dark)" srcset="doc/source/logo/sober_logo_white.svg">
    <source media="(prefers-color-scheme: light)" srcset="doc/source/logo/sober_logo_black.svg">
    <img alt="sober logo" src="doc/source/logo/sober_logo_black.svg" width="300">
</picture>

**sober** **o**ptimises **b**uilt **e**nvironment **r**obustly

---

## Installation

**sober** can be installed via either `conda`:

```zsh
conda install -c conda-forge sober
```

or `pip`:

```zsh
pip install sober
```
