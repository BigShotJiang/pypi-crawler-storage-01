# TODO: add a test for switching between parametrics and optimisation fixed in 8eb8b93
