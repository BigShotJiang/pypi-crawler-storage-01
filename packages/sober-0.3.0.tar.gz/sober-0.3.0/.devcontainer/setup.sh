uv sync --all-extras --all-groups
