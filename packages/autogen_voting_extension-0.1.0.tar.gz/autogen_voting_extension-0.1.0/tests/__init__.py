"""Tests for autogen-voting-extension."""
