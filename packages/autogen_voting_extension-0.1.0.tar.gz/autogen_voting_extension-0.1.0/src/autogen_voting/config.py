"""Configuration settings for autogen-voting."""

# Model configuration
MODEL = "gpt-4o-mini"
