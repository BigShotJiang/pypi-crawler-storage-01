API reference
=============

The following document outlines betterproto's api. These classes should not be extended manually.


## Message

::: betterproto2.Message

::: betterproto2.which_one_of


## Enumerations

::: betterproto2.Enum

::: betterproto2.Casing
