API Reference
=============

.. autosummary::
   :toctree: api
   :template: autosummary-module-template.rst
   :recursive:

   exa.common
