# - Flat is better than nested.
# - Try not to make new stuffs.
# - Printability is a great feature.
# - Secretly handling errors for users is arrogant.
# - Making variable names long does not hurt anyone.
# - Don't make things too fancy; it kills possibilities.
# - Any single type should be fully functional on its own.
