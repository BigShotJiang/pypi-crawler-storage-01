from importlib.metadata import version as get_version

__version__ = get_version("animepahe-dl")
