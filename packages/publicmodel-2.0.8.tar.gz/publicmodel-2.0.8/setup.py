from setuptools import setup, find_packages

setup(
    name="publicmodel",
    version="2.0.8",
    packages=find_packages(),
    install_requires=[
    ],
    author="YanXinle",
    author_email="1020121123@qq.com",
    description="作者: YanXinle",
    url="https://github.com/Yanxinle1123/LeleComm",
)
