# ruff: noqa: D100

import hypothesis

hypothesis.settings.register_profile("default", print_blob=True)
