from __future__ import annotations

from dpdata.cli import dpdata_cli

if __name__ == "__main__":
    dpdata_cli()
