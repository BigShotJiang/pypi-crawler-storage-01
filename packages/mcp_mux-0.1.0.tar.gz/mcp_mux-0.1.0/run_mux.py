#!/usr/bin/env python3
"""Entry point for the mux command."""

from mux.__main__ import main

if __name__ == "__main__":
    main()
