"""This module contains utility functions for the chatbot explorer."""
