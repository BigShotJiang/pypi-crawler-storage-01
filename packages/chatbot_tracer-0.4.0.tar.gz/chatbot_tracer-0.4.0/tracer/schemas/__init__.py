"""This package contains schemas for the chatbot explorer."""
