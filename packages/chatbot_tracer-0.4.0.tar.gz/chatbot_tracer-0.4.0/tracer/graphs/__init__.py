"""Module to create the LangGraph for user profile generation and workflow structurer."""
