jgtml
====

JGTML Services


Installation
------------

::

    pip install -U jgtml

Example
-------

::


    >>> import pandas as pd
    >>> import jgtml
    >>> df=jgtml.calc_targets('EUR/USD','H4')
    >>>

