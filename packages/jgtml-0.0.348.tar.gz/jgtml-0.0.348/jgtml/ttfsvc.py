"""
@STCGoal Wrap what TTF does as Services

- Create TTF
- Read TTF (and create if doesn't exist)
- Update TTF
- Create TTF Patterns (data:  PatternName, PatternsColumns)

Dependencies:
- TTFRequest
- CDS,PDS
"""