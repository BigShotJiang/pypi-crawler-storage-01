#%%
from jgtutils import jgtpov

# %%
jgtpov.get_higher_tf_by_level("H1",1)

# %%

jgtpov.get_higher_tf_by_level("m15",1)
# %%
