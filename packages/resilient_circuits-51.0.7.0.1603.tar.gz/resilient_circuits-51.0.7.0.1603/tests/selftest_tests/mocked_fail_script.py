
def selftest(args):

    raise Exception()