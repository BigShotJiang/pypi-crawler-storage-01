#!/usr/bin/env python
# -*- coding: utf-8 -*-
# (c) Copyright IBM Corp. 2010, 2018. All Rights Reserved.

"""Argument parse helper, for values stored in keyring or file"""

import resilient


class ArgumentParser(resilient.ArgumentParser):
    """Nothing here.  All this functionality is now in the base class"""
