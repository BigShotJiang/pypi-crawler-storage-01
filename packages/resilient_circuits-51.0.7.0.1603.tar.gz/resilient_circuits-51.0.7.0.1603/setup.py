#!/usr/bin/env python
# -*- coding: utf-8 -*-
# (c) Copyright IBM Corp. 2010, 2023. All Rights Reserved.

""" setup.py for resilient-circuits Python module """

from setuptools import setup

setup()
