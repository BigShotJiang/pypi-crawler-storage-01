## [v0.5.5](https://pypi.org/project/amsdal_server/0.5.5/) - 2025-07-31

### Changes

- Switched to uv package manager
