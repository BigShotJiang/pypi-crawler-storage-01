# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.

"""Module that helps waiting for conditions"""

import time
import logging

_LOG = logging.getLogger(__file__)


def wait_for(func, timeout, first=0.0, step=1.0, text=None):
    """
    Wait until func() evaluates to True.

    If func() evaluates to True before timeout expires, return the
    value of func(). Otherwise return None.

    :param func: Function to be evaluated
    :param timeout: Timeout in seconds
    :param first: Time to sleep before first attempt
    :param step: Time to sleep between attempts in seconds
    :param text: Text to print while waiting, for debug purposes
    """
    start_time = time.monotonic()
    end_time = time.monotonic() + timeout

    time.sleep(first)

    while time.monotonic() < end_time:
        if text:
            _LOG.debug("%s (%f secs)", text, (time.monotonic() - start_time))

        output = func()
        if output:
            return output

        time.sleep(step)

    return None
