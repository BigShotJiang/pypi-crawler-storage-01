# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.
#
# This code was imported from the avocado-vt project,
#
# virttest/remote.py
# Original author: Michael Goldish <mgoldish@redhat.com>
#
# Copyright: 2016 IBM
# Authors : Michael Goldish <mgoldish@redhat.com>

"""
Functions and classes used for logging into guests and transferring files.

Example usage:

::

    import aexpect
    import aexpect.remote

    with aexpect.ShellSession("sh") as b:
        b.cmd("echo asdf > /tmp/bbb")

    with aexpect.remote.remote_login("ssh", "127.0.0.1", 5000, "root", "123456",
                                    aexpect.remote.PROMPT_LINUX) as a:
        a.cmd("rm /tmp/aaa -Rf")
        aexpect.remote.scp_to_session(a, "/tmp/bbb", "/tmp/aaa")
        aexpect.remote.scp_from_session(a, "/tmp/aaa", "/tmp/ccc")

.. warning:: Some of this API is freshly migrated and might still be experimental.
"""

# disable too-many-* as we need them pylint: disable=R0912,R0913,R0914,R0915,C0302
# ..todo:: we could reduce the disabled issues after more significant refactoring

from __future__ import division
import logging
import time
import re
import shlex

from aexpect.client import Expect
from aexpect.client import RemoteSession
from aexpect.exceptions import ExpectTimeoutError
from aexpect.exceptions import ExpectProcessTerminatedError
from aexpect import rss_client

LOG = logging.getLogger(__name__)

#: prompt to be used for shell sessions on linux machines (default)
PROMPT_LINUX = r"^\[.*\][\#\$]\s*$"
#: prompt to be used for shell sessions on Windows machines
PROMPT_WINDOWS = r"^\w:\\.*>\s*$"


class RemoteError(Exception):
    """Base class for any remote error raised here."""


class LoginError(RemoteError):
    """Base class for any remote error related to logins and session creation."""

    def __init__(self, msg, output=""):
        super().__init__()
        self.msg = msg
        self.output = output

    def __str__(self):
        return f"{self.msg}    (output: {self.output!r})"


class LoginAuthenticationError(LoginError):
    """Remote error related to login authentication problems."""


class LoginTimeoutError(LoginError):
    """Remote error related to login timeout expiration."""

    def __init__(self, output=""):
        super().__init__("Login timeout expired", output)


class LoginProcessTerminatedError(LoginError):
    """Remote error related to login process termination."""

    def __init__(self, status, output=""):
        super().__init__("Client process terminated", output)
        self.status = status

    def __str__(self):
        return (
            f"{self.msg}    (status: {self.status},    "
            f"output: {self.output!r})"
        )


class LoginBadClientError(LoginError):
    """Remote error related to unknown remote shell client."""

    def __init__(self, client):
        super().__init__("Unknown remote shell client")
        self.client = client

    def __str__(self):
        return f"{self.msg}    (value: {self.client!r})"


class TransferError(RemoteError):
    """Base class for any remote error related to data transfer."""

    def __init__(self, msg, output):
        super().__init__()
        self.msg = msg
        self.output = output

    def __str__(self):
        return f"{self.msg}    (output: {self.output!r})"


class TransferBadClientError(RemoteError):
    """Remote error related to unknown transfer client."""

    def __init__(self, client):
        super().__init__()
        self.client = client

    def __str__(self):
        return (
            f"Unknown file copy client: '{self.client}', "
            "valid values are scp and rss"
        )


class SCPError(TransferError):
    """Remote error related to transfer using SCP."""


class RsyncError(TransferError):
    """Remote error related to transfer using rsync."""


class AuthenticationError(SCPError):
    """Remote error related to transfer authentication using SCP."""


class AuthenticationTimeoutError(AuthenticationError):
    """Remote error related to transfer authentication timeout using SCP."""

    def __init__(self, output):
        super().__init__("Authentication timeout expired", output)


class TransferTimeoutError(SCPError):
    """Remote error related to transfer timeout using SCP."""

    def __init__(self, output):
        super().__init__("Transfer timeout expired", output)


class TransferFailedError(SCPError):
    """Remote error related to transfer failure using SCP."""

    def __init__(self, status, output):
        super().__init__(None, output)
        self.status = status

    def __str__(self):
        return (
            f"SCP transfer failed    (status: {self.status},    "
            f"output: {self.output!r})"
        )


class NetcatError(TransferError):
    """Remote error related to transfer using netcat."""


class NetcatTransferTimeoutError(NetcatError):
    """Remote error related to transfer timeout using netcat."""

    def __init__(self, output):
        super().__init__("Transfer timeout expired", output)


class NetcatTransferFailedError(NetcatError):
    """Remote error related to transfer failure using netcat."""

    def __init__(self, status, output):
        super().__init__(None, output)
        self.status = status

    def __str__(self):
        return (
            f"Netcat transfer failed    (status: {self.status},    "
            f"output: {self.output!r})"
        )


class NetcatTransferIntegrityError(NetcatError):
    """Remote error related to transfer integrity failure using netcat."""

    def __init__(self, output):
        super().__init__("Transfer integrity failed", output)


class UDPError(TransferError):
    """Remote error related to transfer using UDP."""

    def __init__(self, output):
        super().__init__("UDP transfer failed", output)


def quote_path(path):
    """
    Produce shell escaped version of string item or of list items, which are
    then joined by space.

    :param path: List or string
    :return: Shell escaped version
    """
    if isinstance(path, list):
        return " ".join(map(shlex.quote, path))
    return shlex.quote(path)


def handle_prompts(
    session, username, password, prompt=PROMPT_LINUX, timeout=10, debug=False
):
    """
    Connect to a remote host (guest) using SSH or Telnet or else.

    Wait for questions and provide answers.  If timeout expires while
    waiting for output from the child (e.g. a password prompt or
    a shell prompt) -- fail.

    :param session: An Expect or RemoteSession instance to operate on
    :param username: The username to send in reply to a login prompt
    :param password: The password to send in reply to a password prompt
    :param prompt: The shell prompt that indicates a successful login
    :param timeout: The maximal time duration (in seconds) to wait for each
            step of the login procedure (i.e. the "Are you sure" prompt, the
            password prompt, the shell prompt, etc)
    :param debug: Whether to add extra debugging output
    :raise LoginTimeoutError: If timeout expires
    :raise LoginAuthenticationError: If authentication fails
    :raise LoginProcessTerminatedError: If the client terminates during login
    :raise LoginError: If some other error occurs
    :return: If connect succeed return the output text to script for further
             debug.
    """
    password_prompt_count = 0
    login_prompt_count = 0
    last_chance = False

    output = ""
    while True:
        try:
            match, text = session.read_until_last_line_matches(
                [
                    r"[Aa]re you sure",
                    r"[Pp]assword:\s*",
                    # Prompt of rescue mode for Red Hat.
                    r"\(or (press|type) Control-D to continue\):\s*$",
                    # Prompt of rescue mode for SUSE.
                    r"[Gg]ive.*[Ll]ogin:\s*$",
                    r"(?<![Ll]ast )[Ll]ogin:\s*$",  # Don't match "Last Login:"
                    r"[Cc]onnection.*closed",
                    r"[Cc]onnection.*refused",
                    r"[Pp]lease wait",
                    r"[Ww]arning",
                    r"[Ee]nter.*username",
                    r"[Ee]nter.*password",
                    r"[Cc]onnection timed out",
                    prompt,
                    r"Escape character is.*",
                    r"Command>",
                    r"[Ll]ost connection",
                ],
                timeout=timeout,
                internal_timeout=0.5,
            )
            output += text
            if match == 0:  # "Are you sure you want to continue connecting"
                if debug:
                    LOG.debug("Got 'Are you sure...', sending 'yes'")
                session.sendline("yes")
            elif match in [1, 2, 3, 10]:  # "password:"
                if password_prompt_count == 0:
                    if debug:
                        LOG.debug(
                            "Got password prompt, sending '%s'", password
                        )
                    session.sendline(password)
                    password_prompt_count += 1
                else:
                    raise LoginAuthenticationError(
                        "Got password prompt twice", text
                    )
            elif match in [4, 9]:  # "login:"
                if login_prompt_count == 0 and password_prompt_count == 0:
                    if debug:
                        LOG.debug(
                            "Got username prompt; sending '%s'", username
                        )
                    session.sendline(username)
                    login_prompt_count += 1
                else:
                    if login_prompt_count > 0:
                        msg = "Got username prompt twice"
                    else:
                        msg = "Got username prompt after password prompt"
                    raise LoginAuthenticationError(msg, text)
            elif match == 5:  # "Connection closed"
                raise LoginError("Client said 'connection closed'", text)
            elif match == 6:  # "Connection refused"
                raise LoginError("Client said 'connection refused'", text)
            elif match == 11:  # Connection timeout
                raise LoginError("Client said 'connection timeout'", text)
            elif match == 15:  # Connection lost
                raise LoginError("Disconnected to vm on remote host", text)
            elif match == 7:  # "Please wait"
                if debug:
                    LOG.debug("Got 'Please wait'")
                timeout = 30
            elif match == 8:  # "Warning added RSA"
                if debug:
                    LOG.debug("Got 'Warning added RSA to known host list")
            elif match == 12:  # prompt
                if debug:
                    LOG.debug("Got shell prompt -- logged in")
                break
            elif match == 13:  # console prompt
                LOG.debug("Got console prompt, send return to show login")
                session.sendline()
            elif match == 14:  # VMware vCenter command prompt
                # Some old vsphere version (e.x. 6.0.0) needs to enable first.
                cmd = "shell.set --enabled True"
                LOG.debug(
                    "Got VMware VCenter prompt, "
                    "send '%s' to enable shell first",
                    cmd,
                )
                session.sendline(cmd)
                LOG.debug(
                    "Got VMware VCenter prompt, send 'shell' to launch bash"
                )
                session.sendline("shell")
        except ExpectTimeoutError as error:
            # sometimes, linux kernel print some message to console
            # the message maybe impact match login pattern, so send
            # an empty line to avoid unexpected login timeout
            if not last_chance:
                time.sleep(0.5)
                session.sendline()
                last_chance = True
            else:
                raise LoginTimeoutError(error.output) from error
        except ExpectProcessTerminatedError as error:
            raise LoginProcessTerminatedError(
                error.status, error.output
            ) from error

    return output


def remote_login(
    client,
    host,
    port,
    username,
    password,
    prompt,
    linesep="\n",
    log_filename=None,
    log_function=None,
    timeout=10,
    interface=None,
    identity_file=None,
    status_test_command="echo $?",
    verbose=False,
    bind_ip=None,
    preferred_authentication="password",
    user_known_hosts_file="/dev/null",
    extra_cmdline="",
):
    """
    Log into a remote host (guest) using SSH/Telnet/Netcat.

    :param client: The client to use ('ssh', 'telnet' or 'nc')
    :param host: Hostname or IP address
    :param port: Port to connect to
    :param username: Username (if required)
    :param password: Password (if required)
    :param prompt: Shell prompt (regular expression)
    :param linesep: The line separator to use when sending lines
            (e.g. '\\n' or '\\r\\n')
    :param log_filename: If specified, log all output to this file
    :param log_function: If specified, log all output using this function
    :param timeout: The maximal time duration (in seconds) to wait for
            each step of the login procedure (i.e. the "Are you sure" prompt
            or the password prompt)
    :param interface: The interface the neighbours attach to (only use when
                      using ipv6 linklocal address.)
    :param identity_file: Selects a file from which the identity (private key)
                          for public key authentication is read
    :param status_test_command: Command to be used for getting the last
            exit status of commands run inside the shell (used by
            cmd_status_output() and friends).
    :param verbose: If True, log some stats using LOG.debug (RSS only), only
            valid when client is ssh or nc.
    :param bind_ip: ssh through specific interface on
                    client(specify interface ip)
    :param preferred_authentication: Given value of PreferredAuthentications in ssh
    :param user_known_hosts_file: Given value of UserKnownHostsFile in ssh
    :param extra_cmdline: Additional params for the session, like -X for SSH.
    :raise LoginError: If using ipv6 linklocal but not assign an interface that
                       the neighbour attached
    :raise LoginBadClientError: If an unknown client is requested
    :return: A RemoteSession object.
    """
    extra_params = []
    if verbose:
        extra_params.append("-vv")
    if extra_cmdline:
        extra_params.append(extra_cmdline)
    if host and host.lower().startswith("fe80"):
        if not interface:
            raise RemoteError(
                "When using ipv6 linklocal an interface must be assigned"
            )
        host = f"{host}%{interface}"
    if client == "ssh":
        cmd = (
            f"ssh {' '.join(extra_params)} -o UserKnownHostsFile={user_known_hosts_file} "
            f"-o StrictHostKeyChecking=no -p {port}"
        )
        if bind_ip:
            cmd += f" -b {bind_ip}"
        if identity_file:
            cmd += f" -i {identity_file}"
        else:
            cmd += f" -o PreferredAuthentications={preferred_authentication}"
        cmd += f" {username}@{host}"
    elif client == "telnet":
        cmd = f"telnet -l {username} {host} {port}"
    elif client == "nc":
        cmd = f"nc {' '.join(extra_params)} {host} {port}"
    else:
        raise LoginBadClientError(client)
    output_params = ()
    if log_filename:
        output_params = (log_filename,)

    if verbose:
        LOG.debug("Login command: '%s'", cmd)
    session = RemoteSession(
        cmd,
        linesep=linesep,
        output_func=log_function,
        output_params=output_params,
        output_prefix=host,
        prompt=prompt,
        status_test_command=status_test_command,
        client=client,
        host=host,
        port=port,
        username=username,
        password=password,
    )
    try:
        handle_prompts(session, username, password, prompt, timeout)
    except Exception:
        session.close()
        raise
    return session


def wait_for_login(
    client,
    host,
    port,
    username,
    password,
    prompt,
    linesep="\n",
    log_filename=None,
    log_function=None,
    timeout=240,
    internal_timeout=10,
    interface=None,
    preferred_authentication="password",
    user_known_hosts_file="/dev/null",
):
    """
    Make multiple attempts to log into a guest until one succeeds or timeouts.

    :param client: aexpect client
    :param host: Hostname or IP of host
    :param port: Hostname port
    :param username: Username for host
    :param password: Password for host
    :param prompt: Hostname prompt string
    :param linesep: Line separator
    :param log_filename: Filename for logging
    :param log_function: Function that will perform logging
    :param interface: The interface the neighbours attach to (only use when
                      using ipv6 linklocal address).
    :param timeout: Total time duration to wait for a successful login
    :param internal_timeout: The maximum time duration (in seconds) to wait for
                             each step of the login procedure (e.g. the
                             "Are you sure" prompt or the password prompt)
    :param preferred_authentication: Given value of PreferredAuthentications in ssh
    :param user_known_hosts_file: Given value of UserKnownHostsFile in ssh
    :interface: The interface the neighbours attach to
                (only use when using ipv6 linklocal address.)
    :see: remote_login()
    :return: A RemoteSession object.
    """
    LOG.debug(
        "Attempting to log into %s:%s using %s (timeout %ds)",
        host,
        port,
        client,
        timeout,
    )
    end_time = time.monotonic() + timeout
    verbose = False
    while time.monotonic() < end_time:
        try:
            return remote_login(
                client,
                host,
                port,
                username,
                password,
                prompt,
                linesep,
                log_filename,
                log_function,
                internal_timeout,
                interface,
                verbose=verbose,
                preferred_authentication=preferred_authentication,
                user_known_hosts_file=user_known_hosts_file,
            )
        except LoginError as error:
            LOG.debug(error)
            verbose = True
        time.sleep(2)
    # Timeout expired; try one more time but don't catch exceptions
    return remote_login(
        client,
        host,
        port,
        username,
        password,
        prompt,
        linesep,
        log_filename,
        log_function,
        internal_timeout,
        interface,
        preferred_authentication=preferred_authentication,
        user_known_hosts_file=user_known_hosts_file,
    )


def _remote_copy(
    session,
    password_list,
    transfer_timeout=600,
    login_timeout=300,
    method="scp",
):
    """
    Transfer files using SCP or rsync, given a command line.

    Transfer file(s) to a remote host (guest) using SCP or rsync. Wait for questions
    and provide answers. If login_timeout expires while waiting for output
    from the child (e.g. a password prompt), fail. If transfer_timeout expires
    while waiting for the transfer to complete, fail.

    :param session: An Expect or RemoteSession instance to operate on
    :param password_list: Password list to send in reply to the password prompt
    :param transfer_timeout: The time duration (in seconds) to wait for the
            transfer to complete.
    :param login_timeout: The maximal time duration (in seconds) to wait for
            each step of the login procedure (i.e. the "Are you sure" prompt or
            the password prompt)
    :param method: The method to use for transfer ("scp" or "rsync")
    :raise AuthenticationError: If authentication fails
    :raise TransferTimeoutError: If the transfer fails to complete in time
    :raise TransferFailedError: If the process terminates with a nonzero
            exit code
    :raise SCPError: If some other error occurs
    """
    password_prompt_count = 0
    timeout = login_timeout
    authentication_done = False

    transfer_type = len(password_list)

    while True:
        try:
            match, text = session.read_until_last_line_matches(
                [r"[Aa]re you sure", r"[Pp]assword:\s*$", r"lost connection"],
                timeout=timeout,
                internal_timeout=0.5,
            )
            if match == 0:  # "Are you sure you want to continue connecting"
                LOG.debug("Got 'Are you sure...', sending 'yes'")
                session.sendline("yes")
            elif match == 1:  # "password:"
                if password_prompt_count == 0:
                    LOG.debug(
                        "Got password prompt, sending '%s'",
                        password_list[password_prompt_count],
                    )
                    session.sendline(password_list[password_prompt_count])
                    password_prompt_count += 1
                    timeout = transfer_timeout
                    if transfer_type == 1:
                        authentication_done = True
                elif password_prompt_count == 1 and transfer_type == 2:
                    LOG.debug(
                        "Got password prompt, sending '%s'",
                        password_list[password_prompt_count],
                    )
                    session.sendline(password_list[password_prompt_count])
                    password_prompt_count += 1
                    timeout = transfer_timeout
                    authentication_done = True
                else:
                    raise AuthenticationError(
                        "Got password prompt twice", text
                    )
            elif match == 2:  # "lost connection"
                raise SCPError("SCP client said 'lost connection'", text)
        except ExpectTimeoutError as error:
            if authentication_done:
                raise TransferTimeoutError(error.output) from error
            raise AuthenticationTimeoutError(error.output) from error
        except ExpectProcessTerminatedError as error:
            if error.status == 0:
                LOG.debug("The %s process terminated with status 0", method)
                break
            raise TransferFailedError(error.status, error.output) from error


def remote_copy(
    command,
    password_list,
    log_filename=None,
    log_function=None,
    transfer_timeout=600,
    login_timeout=300,
):
    """
    Transfer files using rsync or SCP, given a command line.

    :param command: The command to execute
        (e.g. "rsync -avz -e 'ssh -p 22' /local/path user@host:/remote/path"
        or "scp -r foobar root@localhost:/tmp/").
    :param password_list: Password list to send in reply to a password prompt.
    :param log_filename: If specified, log all output to this file
    :param log_function: If specified, log all output using this function
    :param transfer_timeout: The time duration (in seconds) to wait for the
            transfer to complete.
    :param login_timeout: The maximal time duration (in seconds) to wait for
            each step of the login procedure (i.e. the "Are you sure" prompt
            or the password prompt)
    """
    LOG.debug(
        "Trying to copy with command '%s', timeout %ss",
        command,
        transfer_timeout,
    )
    if log_filename:
        output_func = log_function
        output_params = (log_filename,)
    else:
        output_func = None
        output_params = ()
    method = "rsync" if "rsync" in command else "scp"
    with Expect(
        command, output_func=output_func, output_params=output_params
    ) as session:
        _remote_copy(
            session, password_list, transfer_timeout, login_timeout, method
        )


def scp_to_remote(
    host,
    port,
    username,
    password,
    local_path,
    remote_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    timeout=600,
    interface=None,
):
    """
    Copy files to a remote host (guest) through scp.

    :param host: Hostname or IP address
    :param port: Port
    :param username: Username (if required)
    :param password: Password (if required)
    :param local_path: Path on the local machine where we are copying from
    :param remote_path: Path on the remote machine where we are copying to
    :param directory: True to copy recursively if the directory to scp
    :param limit: Speed limit of file transfer.
    :param log_filename: If specified, log all output to this file
    :param log_function: If specified, log all output using this function
    :param timeout: The time duration (in seconds) to wait for the transfer
                    to complete.
    :param interface: The interface the neighbours attach to (only use when using
                      ipv6 linklocal address).
    """
    if limit:
        limit = f"-l {limit}"

    if host and host.lower().startswith("fe80"):
        if not interface:
            raise SCPError(
                "When using ipv6 linklocal address must assign",
                "the interface the neighbour attache",
            )
        host = f"{host}%{interface}"

    command = "scp"
    if directory:
        command += " -r"
    command += (
        r" -v -o UserKnownHostsFile=/dev/null "
        r"-o StrictHostKeyChecking=no "
        rf"-o PreferredAuthentications=password {limit} "
        rf"-P {port} {quote_path(local_path)} {username}@\[{host}\]:"
        rf"{shlex.quote(remote_path)}"
    )
    password_list = [password]
    return remote_copy(
        command, password_list, log_filename, log_function, timeout
    )


def scp_from_remote(
    host,
    port,
    username,
    password,
    remote_path,
    local_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    timeout=600,
    interface=None,
):
    """
    Copy files from a remote host (guest).

    :param host: Hostname or IP address
    :param port: Port
    :param username: Username (if required)
    :param password: Password (if required)
    :param remote_path: Path on the remote machine where we are copying to
    :param local_path: Path on the local machine where we are copying from
    :param directory: True to copy recursively if the directory to scp
    :param limit: Speed limit of file transfer.
    :param log_filename: If specified, log all output to this file
    :param log_function: If specified, log all output using this function
    :param timeout: The time duration (in seconds) to wait for the transfer
                    to complete.
    :param interface: The interface the neighbours attach to (only use when
                      using ipv6 linklocal address).
    """
    if limit:
        limit = f"-l {limit}"
    if host and host.lower().startswith("fe80"):
        if not interface:
            raise SCPError(
                "When using ipv6 linklocal address must assign, ",
                "the interface the neighbour attache",
            )
        host = f"{host}%{interface}"

    command = "scp"
    if directory:
        command += " -r"
    command += (
        r" -v -o UserKnownHostsFile=/dev/null "
        r"-o StrictHostKeyChecking=no "
        rf"-o PreferredAuthentications=password {limit} "
        rf"-P {port} {username}@\[{host}\]:{quote_path(remote_path)} "
        rf"{shlex.quote(local_path)}"
    )
    password_list = [password]
    remote_copy(command, password_list, log_filename, log_function, timeout)


def scp_between_remotes(
    src,
    dst,
    port,
    s_passwd,
    d_passwd,
    s_name,
    d_name,
    s_path,
    d_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    timeout=600,
    src_inter=None,
    dst_inter=None,
):
    """
    Copy files from a remote host (guest) to another remote host (guest).

    :param src: Hostname or IP address of source
    :param dst: Hostname or IP address of destination
    :param port: Port
    :param s_name: Source username (if required)
    :param d_name: Destination username (if required)
    :param s_passwd: Source password (if required)
    :param d_passwd: Destination password (if required)
    :param s_path: Path on the source remote machine
    :param d_path: Path on the destination remote machine
    :param directory: True to copy recursively if the directory to scp
    :param limit: Speed limit of file transfer.
    :param log_filename: If specified, log all output to this file
    :param log_function: If specified, log all output using this function
    :param timeout: The time duration (in seconds) to wait for the transfer
                    to complete.
    :param src_inter: The interface on local that the src neighbour attached
    :param dst_inter: The interface on the src that the dst neighbour attached

    :return: True on success and False on failure.
    """
    if limit:
        limit = f"-l {limit}"
    if src and src.lower().startswith("fe80"):
        if not src_inter:
            raise SCPError(
                "When using ipv6 linklocal address must assign ",
                "the interface the neighbour attache",
            )
        src = f"{src}%{src_inter}"
    if dst and dst.lower().startswith("fe80"):
        if not dst_inter:
            raise SCPError(
                "When using ipv6 linklocal address must assign ",
                "the interface the neighbour attache",
            )
        dst = f"{dst}%{dst_inter}"

    command = "scp"
    if directory:
        command += " -r"
    command += (
        r" -v -o UserKnownHostsFile=/dev/null "
        r"-o StrictHostKeyChecking=no "
        rf"-o PreferredAuthentications=password {limit} -P {port}"
        rf" {s_name}@\[{src}\]:{quote_path(s_path)} {d_name}@\[{dst}\]"
        rf":{shlex.quote(d_path)}"
    )
    password_list = [s_passwd, d_passwd]
    return remote_copy(
        command, password_list, log_filename, log_function, timeout
    )


def rsync_to_remote(
    host,
    port,
    username,
    password,
    local_path,
    remote_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    timeout=600,
    interface=None,
):
    """
    Copy files to a remote host (guest) through rsync.

    :param host: Hostname or IP address
    :param port: Port
    :param username: Username (if required)
    :param password: Password (if required)
    :param local_path: Path on the local machine where we are copying from
    :param remote_path: Path on the remote machine where we are copying to
    :param directory: True to copy recursively if the directory to rsync
    :param limit: Speed limit of file transfer.
    :param log_filename: If specified, log all output to this file
    :param log_function: If specified, log all output using this function
    :param timeout: The time duration (in seconds) to wait for the transfer
                    to complete.
    :param interface: The interface the neighbours attach to (only use when using
                      ipv6 linklocal address).
    :raise: Whatever remote_rsync() raises
    """
    if limit:
        limit = f"--bwlimit={limit}"

    if host and host.lower().startswith("fe80"):
        if not interface:
            raise RsyncError(
                "When using ipv6 linklocal address must assign",
                "the interface the neighbour attache",
            )
        host = f"{host}%{interface}"

    command = "rsync"
    if directory:
        command += " -r"
    command += (
        f" -avz -e 'ssh -p {port} -o UserKnownHostsFile=/dev/null "
        f"-o StrictHostKeyChecking=no' {limit} "
        f"{quote_path(local_path)} {username}@{host}:{shlex.quote(remote_path)}"
    )
    password_list = [password]
    return remote_copy(
        command, password_list, log_filename, log_function, timeout
    )


def rsync_from_remote(
    host,
    port,
    username,
    password,
    remote_path,
    local_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    timeout=600,
    interface=None,
):
    """
    Copy files from a remote host (guest) through rsync.

    :param host: Hostname or IP address
    :param port: Port
    :param username: Username (if required)
    :param password: Password (if required)
    :param remote_path: Path on the remote machine where we are copying to
    :param local_path: Path on the local machine where we are copying from
    :param directory: True to copy recursively if the directory to rsync
    :param limit: Speed limit of file transfer.
    :param log_filename: If specified, log all output to this file
    :param log_function: If specified, log all output using this function
    :param timeout: The time duration (in seconds) to wait for the transfer
                    to complete.
    :param interface: The interface the neighbours attach to (only use when
                      using ipv6 linklocal address).
    :raise: Whatever remote_rsync() raises
    """
    if limit:
        limit = f"--bwlimit={limit}"
    if host and host.lower().startswith("fe80"):
        if not interface:
            raise RsyncError(
                "When using ipv6 linklocal address must assign, ",
                "the interface the neighbour attache",
            )
        host = f"{host}%{interface}"

    command = "rsync"
    if directory:
        command += " -r"
    command += (
        f" -avz -e 'ssh -p {port} -o UserKnownHostsFile=/dev/null "
        f"-o StrictHostKeyChecking=no' {limit} "
        f"{username}@{host}:{quote_path(remote_path)} {shlex.quote(local_path)}"
    )
    password_list = [password]
    remote_copy(command, password_list, log_filename, log_function, timeout)


# noinspection PyBroadException
def nc_copy_between_remotes(
    src,
    dst,
    s_port,
    s_passwd,
    d_passwd,
    s_name,
    d_name,
    s_path,
    d_path,
    c_type="ssh",
    c_prompt="\n",
    d_port="8888",
    d_protocol="tcp",
    timeout=2,
    check_sum=True,
    s_session=None,
    d_session=None,
    file_transfer_timeout=600,
):
    """
    Copy files from guest to guest using netcat.

    This method only supports linux guest OS.

    :param src: Hostname or IP address of source
    :param dst: Hostname or IP address of destination
    :param s_port: Hostname port
    :param s_name: Source username (if required)
    :param d_name: Destination username (if required)
    :param s_passwd: Source password (if required)
    :param d_passwd: Destination password (if required)
    :param s_path: Path on the source remote machine
    :param d_path: Path on the destination remote machine
    :param c_type: Login method to remote host(guest).
    :param c_prompt: command line prompt of remote host(guest)
    :param d_port:  the port data transfer
    :param d_protocol: nc protocol use (tcp or udp)
    :param timeout: If a connection and stdin are idle for more than timeout
                    seconds, then the connection is silently closed.
    :param s_session: A shell session object for source or None.
    :param d_session: A shell session object for dst or None.
    :param check_sum: Whether to run checksum for the operation.
    :param file_transfer_timeout: Timeout for file transfer.

    :return: True on success and False on failure.
    """
    check_string = "NCFT"
    if not s_session:
        s_session = remote_login(
            c_type, src, s_port, s_name, s_passwd, c_prompt
        )
    if not d_session:
        d_session = remote_login(
            c_type, dst, s_port, d_name, d_passwd, c_prompt
        )

    try:
        s_session.cmd(f"iptables -I INPUT -p {d_protocol} -j ACCEPT")
        d_session.cmd(f"iptables -I OUTPUT -p {d_protocol} -j ACCEPT")
    except Exception:  # pylint: disable=W0703
        pass

    LOG.info("Transfer data using netcat from %s to %s", src, dst)
    cmd = f"nc -w {timeout}"
    if d_protocol == "udp":
        cmd += " -u"
    receive_cmd = f"echo {check_string} | {cmd} -l {d_port} > {d_path}"
    d_session.sendline(receive_cmd)
    send_cmd = f"{cmd} {dst} {d_port} < {s_path}"
    status, output = s_session.cmd_status_output(
        send_cmd, timeout=file_transfer_timeout
    )
    if status:
        err = f"Fail to transfer file between {src} -> {dst}."
        if check_string not in output:
            err += (
                "src did not receive check "
                f"string {check_string} sent by dst."
            )
        err += f"send nc command {send_cmd}, output {output}"
        err += f"Receive nc command {receive_cmd}."
        raise NetcatTransferFailedError(status, err)

    if check_sum:
        LOG.info("md5sum cmd = md5sum %s", s_path)
        output = s_session.cmd(f"md5sum {s_path}")
        src_md5 = output.split()[0]
        dst_md5 = d_session.cmd(f"md5sum {d_path}").split()[0]
        if src_md5.strip() != dst_md5.strip():
            err_msg = (
                "Files md5sum mismatch, "
                f"file {s_path} md5sum is '{src_md5}', "
                f"but the file {d_path} md5sum is {dst_md5}"
            )
            raise NetcatTransferIntegrityError(err_msg)
    return True


def udp_copy_between_remotes(
    src,
    dst,
    s_port,
    s_passwd,
    d_passwd,
    s_name,
    d_name,
    s_path,
    d_path,
    c_type="ssh",
    c_prompt="\n",
    d_port="9000",
    timeout=600,
):
    """
    Copy files from guest to guest using udp.

    :param src: Hostname or IP address of source
    :param dst: Hostname or IP address of destination
    :param s_port: Hostname port
    :param s_name: Source username (if required)
    :param d_name: Destination username (if required)
    :param s_passwd: Source password (if required)
    :param d_passwd: Destination password (if required)
    :param s_path: Path on the source remote machine
    :param d_path: Path on the destination remote machine
    :param c_type: Login method to remote host(guest).
    :param c_prompt: command line prompt of remote host(guest)
    :param d_port:  the port data transfer
    :param timeout: data transfer timeout
    """
    s_session = remote_login(c_type, src, s_port, s_name, s_passwd, c_prompt)
    d_session = remote_login(c_type, dst, s_port, d_name, d_passwd, c_prompt)

    def get_abs_path(session, filename, extension):
        """Return file path drive+path."""
        cmd_tmp = "wmic datafile where \"Filename='%s' and "
        cmd_tmp += "extension='%s'\" get drive^,path"
        cmd = cmd_tmp % (filename, extension)
        info = session.cmd_output(cmd, timeout=360).strip()
        drive_path = re.search(r"(\w):\s+(\S+)", info, re.M)
        if not drive_path:
            raise UDPError(
                f"Not found file {filename}.{extension} in your guest"
            )
        return ":".join(drive_path.groups())

    def get_file_md5(session, file_path):
        """Get files md5sums."""
        if c_type == "ssh":
            md5_cmd = f"md5sum {file_path}"
            md5_reg = rf"(\w+)\s+{file_path}.*"
        else:
            drive_path = get_abs_path(session, "md5sums", "exe")
            filename = file_path.split("\\")[-1]
            md5_reg = rf"{filename}\s+(\w+)"
            md5_cmd = (
                f"{drive_path}md5sums.exe {file_path} | " f'find "{filename}"'
            )
        output = session.cmd_output(md5_cmd)
        file_md5 = re.findall(md5_reg, output)
        if not output:
            raise UDPError(f"Get file {file_path} md5sum error")
        return file_md5

    def server_alive(session):
        """Check if server is alive."""
        if c_type == "ssh":
            check_cmd = "ps aux"
        else:
            check_cmd = "tasklist"
        output = session.cmd_output(check_cmd)
        if not output:
            raise UDPError("Can not get the server status")
        if "sendfile" in output.lower():
            return True
        return False

    def start_server(session):
        """Start the server."""
        if c_type == "ssh":
            start_cmd = f"sendfile {d_port} &"
        else:
            drive_path = get_abs_path(session, "sendfile", "exe")
            start_cmd = f"start /b {drive_path}sendfile.exe {d_port}"
        session.cmd_output_safe(start_cmd)
        if not server_alive(session):
            raise UDPError("Start udt server failed")

    def start_client(session):
        """Start the client."""
        if c_type == "ssh":
            client_cmd = f"recvfile {src} {d_port} {s_path} {d_path}"
        else:
            drive_path = get_abs_path(session, "recvfile", "exe")
            client_cmd_tmp = "%srecvfile.exe %s %s %s %s"
            client_cmd = client_cmd_tmp % (
                drive_path,
                src,
                d_port,
                s_path.split("\\")[-1],
                d_path.split("\\")[-1],
            )
        session.cmd_output_safe(client_cmd, timeout)

    def stop_server(session):
        """Stop the server."""
        if c_type == "ssh":
            stop_cmd = "killall sendfile"
        else:
            stop_cmd = "taskkill /F /IM sendfile.exe"
        if server_alive(session):
            session.cmd_output_safe(stop_cmd)

    try:
        src_md5 = get_file_md5(s_session, s_path)
        if not server_alive(s_session):
            start_server(s_session)
        start_client(d_session)
        dst_md5 = get_file_md5(d_session, d_path)
        if src_md5 != dst_md5:
            err_msg = (
                "Files md5sum mismatch, "
                f"file {s_path} md5sum is '{src_md5}', "
                f"but the file {d_path} md5sum is {dst_md5}"
            )
            raise UDPError(err_msg)
    finally:
        stop_server(s_session)
        s_session.close()
        d_session.close()


def login_from_session(
    session,
    log_filename=None,
    log_function=None,
    timeout=240,
    internal_timeout=10,
    interface=None,
):
    """
    Log in remotely and return a session for the connection with the same
    configuration as a previous session.

    :param session: an SSH session whose configuration will be reused
    :param log_filename: Log filename
    :param log_function: Function for logging
    :param timeout: Timeout for login
    :param internal_timeout: Internal timeout for the login loop
    :param interface: Interface to be used
    :type session: RemoteSession object
    :returns: connection session
    :rtype: RemoteSession object

    The rest of the arguments are identical to wait_for_login().
    """
    return wait_for_login(
        session.client,
        session.host,
        session.port,
        session.username,
        session.password,
        session.prompt,
        session.linesep,
        log_filename,
        log_function,
        timeout,
        internal_timeout,
        interface,
    )


def scp_to_session(
    session,
    local_path,
    remote_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    timeout=600,
    interface=None,
):
    """
    Secure copy a filepath (w/o wildcard) to a remote location with the same
    configuration as a previous session.

    :param session: an SSH session whose configuration will be reused
    :type session: RemoteSession object
    :param str local_path: local filepath to copy from
    :param str remote_path: remote filepath to copy to
    :param directory: Whether the path is a directory
    :param limit: Limit
    :param log_filename: Filename for the log
    :param log_function: Function to perform logging
    :param timeout: Timeout for the scp operation
    :param interface: Interface used for the transfer

    The rest of the arguments are identical to scp_to_remote().
    """
    scp_to_remote(
        session.host,
        session.port,
        session.username,
        session.password,
        local_path,
        remote_path,
        directory,
        limit,
        log_filename,
        log_function,
        timeout,
        interface,
    )


def scp_from_session(
    session,
    remote_path,
    local_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    timeout=600,
    interface=None,
):
    """
    Secure copy a filepath (w/o wildcard) from a remote location with the same
    configuration as a previous session.

    :param session: an SSH session whose configuration will be reused
    :type session: RemoteSession object
    :param str remote_path: remote filepath to copy from
    :param str local_path: local filepath to copy to
    :param directory: Whether the path is a directory
    :param limit: Limit
    :param log_filename: Filename for the log
    :param log_function: Function to perform logging
    :param timeout: Timeout for the scp operation
    :param interface: Interface used for the transfer

    The rest of the arguments are identical to scp_from_remote().
    """
    scp_from_remote(
        session.host,
        session.port,
        session.username,
        session.password,
        remote_path,
        local_path,
        directory,
        limit,
        log_filename,
        log_function,
        timeout,
        interface,
    )


def throughput_transfer(func):
    """
    wrapper function for copy_files_to/copy_files_from function, will
    print throughput if file size is not none, else will print elapsed time
    """

    def transfer(*args, **kwargs):
        """Wrapper transfer function."""
        if "from" in func.__name__:
            msg = f"Copy file from {args[0]}:{args[5]} to {args[6]}, "
        else:
            msg = f"Copy file from {args[5]} to {args[0]}:{args[6]}, "
        start_time = time.monotonic()
        ret = func(*args, **kwargs)
        elapsed_time = time.monotonic() - start_time
        if kwargs.get("filesize", None) is not None:
            throughput = kwargs["filesize"] / elapsed_time
            msg += f"estimated throughput: {throughput:.2f} MB/s"
        else:
            msg += f"elapsed time: {elapsed_time}"
        LOG.info(msg)
        return ret

    return transfer


# noinspection PyUnusedLocal
@throughput_transfer
def copy_files_to(
    address,
    client,
    username,
    password,
    port,
    local_path,
    remote_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    verbose=False,
    timeout=600,
    interface=None,
    filesize=None,  # pylint: disable=unused-argument
):
    """
    Copy files to a remote host (guest) using the selected client.

    :param address: Address of remote host(guest)
    :param client: Type of transfer client
    :param username: Username (if required)
    :param password: Password (if required)
    :param port: Hostname port
    :param local_path: Path on the local machine where we are copying from
    :param remote_path: Path on the remote machine where we are copying to
    :param directory: True to copy recursively if the directory to scp
    :param limit: Speed limit of file transfer.
    :param log_filename: If specified, log all output to this file (SCP only)
    :param log_function: If specified, log all output using this function
    :param verbose: If True, log some stats using LOG.debug (RSS only)
    :param timeout: The time duration (in seconds) to wait for the transfer to
            complete.
    :param interface: The interface the neighbours attach to (only use when
                      using ipv6 linklocal address.)
    :param filesize: size of file will be transferred
    """
    if client == "scp":
        scp_to_remote(
            address,
            port,
            username,
            password,
            local_path,
            remote_path,
            directory,
            limit,
            log_filename,
            log_function,
            timeout,
            interface=interface,
        )
    elif client == "rsync":
        rsync_to_remote(
            address,
            port,
            username,
            password,
            local_path,
            remote_path,
            directory,
            limit,
            log_filename,
            log_function,
            timeout,
            interface=interface,
        )
    elif client == "rss":
        log_func = None
        if verbose:
            log_func = LOG.debug
        if interface:
            address = f"{address}%{interface}"
        fdclient = rss_client.FileUploadClient(address, port, log_func)
        fdclient.upload(local_path, remote_path, timeout)
        fdclient.close()
    else:
        raise TransferBadClientError(client)


# noinspection PyUnusedLocal
@throughput_transfer
def copy_files_from(
    address,
    client,
    username,
    password,
    port,
    remote_path,
    local_path,
    directory=True,
    limit="",
    log_filename=None,
    log_function=None,
    verbose=False,
    timeout=600,
    interface=None,
    filesize=None,  # pylint: disable=unused-argument
):
    """
    Copy files from a remote host (guest) using the selected client.

    :param address: Address of remote host(guest)
    :param client: Type of transfer client
    :param username: Username (if required)
    :param password: Password (if required)
    :param port: Host port
    :param remote_path: Path on the remote machine where we are copying from
    :param local_path: Path on the local machine where we are copying to
    :param directory: True to copy recursively if the directory to scp
    :param limit: Speed limit of file transfer.
    :param log_filename: If specified, log all output to this file (SCP only)
    :param log_function: If specified, log all output using this function
    :param verbose: If True, log some stats using ``LOG.debug`` (RSS only)
    :param timeout: The time duration (in seconds) to wait for the transfer to
                    complete.
    :param interface: The interface the neighbours attach to (only
                      use when using ipv6 linklocal address.)
    :param filesize: size of file will be transferred
    """
    if client == "scp":
        scp_from_remote(
            address,
            port,
            username,
            password,
            remote_path,
            local_path,
            directory,
            limit,
            log_filename,
            log_function,
            timeout,
            interface=interface,
        )
    elif client == "rsync":
        rsync_from_remote(
            address,
            port,
            username,
            password,
            remote_path,
            local_path,
            directory,
            limit,
            log_filename,
            log_function,
            timeout,
            interface=interface,
        )
    elif client == "rss":
        log_func = None
        if verbose:
            log_func = LOG.debug
        if interface:
            address = f"{address}%{interface}"
        fdclient = rss_client.FileDownloadClient(address, port, log_func)
        fdclient.download(remote_path, local_path, timeout)
        fdclient.close()
    else:
        raise TransferBadClientError(client)
