async def test_demo():
    assert 2 + 2 == 4, "Simple arithmetic test failed"
