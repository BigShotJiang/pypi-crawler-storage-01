from fastmcp import FastMCP

mcp = FastMCP(
    "open-data-mcp",
    "공공 데이터 포털 API 검색 MCP공공 데이터 포털 API 검색 MCP",
)
