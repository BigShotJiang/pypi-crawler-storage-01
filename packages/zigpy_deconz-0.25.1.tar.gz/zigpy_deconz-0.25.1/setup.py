"""Setup stub for legacy builds."""

import setuptools

if __name__ == "__main__":
    setuptools.setup()
