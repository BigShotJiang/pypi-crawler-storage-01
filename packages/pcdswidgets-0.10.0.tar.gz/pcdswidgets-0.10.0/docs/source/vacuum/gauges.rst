========
Gauges
========

Rough Gauge
---------------

.. autoclass:: pcdswidgets.vacuum.gauges.RoughGauge
   :members:

Hot Cathode Gauge
-----------------

.. autoclass:: pcdswidgets.vacuum.gauges.HotCathodeGauge
   :members:

Cold Cathode Gauge
------------------

.. autoclass:: pcdswidgets.vacuum.gauges.ColdCathodeGauge
   :members:
