========
Pumps
========

Ion Pump
--------

.. autoclass:: pcdswidgets.vacuum.pumps.IonPump
   :members:

Turbo Pump
----------

.. autoclass:: pcdswidgets.vacuum.pumps.TurboPump
   :members:

Scroll Pump
-----------

.. autoclass:: pcdswidgets.vacuum.pumps.ScrollPump
   :members:

Getter Pump
-----------

.. autoclass:: pcdswidgets.vacuum.pumps.GetterPump
   :members:
