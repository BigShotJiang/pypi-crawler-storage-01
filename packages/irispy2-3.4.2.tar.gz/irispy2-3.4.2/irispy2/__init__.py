__version__ = "3.4.0"

from irispy2.bot import Bot
from irispy2.bot.models import ChatContext, Message, Room, User
