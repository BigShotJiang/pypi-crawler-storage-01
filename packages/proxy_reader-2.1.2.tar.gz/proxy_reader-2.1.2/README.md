


# proxy-reader - A simple but useful bulk proxies reader and checker.

This is useful when you are working with multiple proxies and want to bulk check
these proxies before using them.
It has iterators to iterate the proxies for easy reading.


## Installation

```
pip install proxy-reader
```

## Changelogs

### [v0.3.0]
*   Add load_list class method to load proxies from list
*   MAJOR: auto detect the proxies format
*   Use new logging config to disable logs and prevent proxy_reader.log from creating
*   Logs can be enabled from user-side
*   Add option to disable proxies checking from __init__


### [v0.2.0] - 2024-10-21

*   Previous unrecorded changes


For more info/queries Telegram: [@runetech](https://t.me/runetech)
