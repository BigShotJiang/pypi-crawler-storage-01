"""
EMBODIOS CLI - Command Line Interface
"""

from .main import cli, main

__all__ = ["cli", "main"]