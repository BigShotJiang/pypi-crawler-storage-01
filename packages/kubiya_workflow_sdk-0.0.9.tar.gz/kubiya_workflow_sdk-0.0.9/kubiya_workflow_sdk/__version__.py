"""Kubiya Workflow SDK version information."""

__version__ = "0.0.9"
__author__ = "Kubiya"
__email__ = "sdk@kubiya.ai"
__license__ = "MIT"
