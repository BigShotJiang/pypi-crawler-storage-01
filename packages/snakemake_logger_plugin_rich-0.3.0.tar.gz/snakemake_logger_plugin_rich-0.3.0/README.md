# Snakemake Rich Logger Plugin

**As of May 15 2025, this plugin does not work. I will update this when I have time!**

Proof of concept logger plugin that uses [rich](https://github.com/Textualize/rich) for terminal styling and progress bar. 

Log formatting still needs lots of work but the progress bar works well.
