class MpicRequestValidationException(Exception):
    pass
