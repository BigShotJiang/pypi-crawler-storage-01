from enum import StrEnum


class CheckType(StrEnum):
    CAA = 'caa'
    DCV = 'dcv'
