'''This file is included as a workaround for a limitation in Setuptools support for PEP 660.'''

from setuptools import setup

setup()