import pytest


@pytest.fixture
def base_url():
    return "http://example.com"
