from codemie_tools.base.models import ToolMetadata

TEXT_TOOL = ToolMetadata(
    name="text_tool",
    description="Tool for working with data from Plain Text files.",
    label="Text File Interpretation",
)
