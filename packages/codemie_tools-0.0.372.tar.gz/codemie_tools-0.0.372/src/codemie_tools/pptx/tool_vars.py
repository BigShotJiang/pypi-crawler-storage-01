from codemie_tools.base.models import ToolMetadata

PPTX_TOOL = ToolMetadata(
    name="pptx_tool",
    description="A tool for extracting content from PPTX documents.",
    label="PPTX Processing Tool",
)