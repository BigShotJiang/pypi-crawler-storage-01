This is a simple generated SPL project to get you started.

Install project dependencies:

```powershell
.\build.ps1 -install
```

Build:

```powershell
.\build.ps1 -build
```

See more information [here](https://spl-core.readthedocs.io/en/latest/getting_started/generate_example_project.html).
