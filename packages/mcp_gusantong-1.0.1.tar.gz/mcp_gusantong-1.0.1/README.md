# Quick Start

### 1、进入到魔塔社区 
https://www.modelscope.cn/

#### 搜索: 股三通

#### 点击服务详情 进行部署

### 2、下载Cherry Studio客户端

#### 点击MCP设置-添加服务

##### 例如：
```JSON
{
  "mcpServers": {
    "mcp-gusantong-data": {
      "type": "sse",
      "url": "服务地址"
    }
  }
}
```