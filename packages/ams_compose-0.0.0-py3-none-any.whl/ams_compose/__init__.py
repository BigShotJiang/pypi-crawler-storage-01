"""ams-compose: Dependency management for analog IC design repositories."""

__version__ = "0.0.0"
__author__ = "ams-compose contributors"
__description__ = "Dependency management tool for analog/mixed-signal IC design repositories"