"""Core functionality for Easy LLM"""
