
PROVIDER_TABLE = {
    "doubao": "https://ark.cn-beijing.volces.com/api/v3/",
    "deepseek": "https://api.deepseek.com/v1",
    "kimi": "https://api.moonshot.ai/v1"
}