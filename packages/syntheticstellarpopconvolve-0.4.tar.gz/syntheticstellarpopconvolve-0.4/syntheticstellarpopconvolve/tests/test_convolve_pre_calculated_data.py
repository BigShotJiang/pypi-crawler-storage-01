"""
This is the unittest file for the convolve_pre_calculated_data.py source file
"""

import unittest

if __name__ == "__main__":
    unittest.main()
