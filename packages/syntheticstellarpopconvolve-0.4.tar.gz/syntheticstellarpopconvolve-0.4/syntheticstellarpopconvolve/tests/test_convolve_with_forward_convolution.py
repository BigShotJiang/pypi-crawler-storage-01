"""
Tests for forward convolution of binned data.

TODO:
- test integrate
- test sample
"""
