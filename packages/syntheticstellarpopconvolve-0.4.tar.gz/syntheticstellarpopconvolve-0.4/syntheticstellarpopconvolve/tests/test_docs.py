"""
This is the unittest file for the docs.py source file
"""

import unittest

if __name__ == "__main__":
    unittest.main()
