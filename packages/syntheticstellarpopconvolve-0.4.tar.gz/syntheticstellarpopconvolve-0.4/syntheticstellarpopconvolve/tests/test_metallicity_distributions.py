"""
This is the unittest file for the metallicity_distributions.py source file
"""

import unittest

if __name__ == "__main__":
    unittest.main()
