from __future__ import absolute_import, unicode_literals

# TODO: Dustri Dance
# Dustri: see http://www.dustri.com/journals-in-english.html
dustri_journals = (
    'Clin Nephrol' 
    'Int J Clin Pharmacol Ther' 
    'Clin Neuropathol',
    )
