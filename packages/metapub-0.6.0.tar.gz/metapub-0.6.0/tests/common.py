from __future__ import absolute_import, unicode_literals

import os 
CWD = os.path.dirname(os.path.realpath(__file__))

TEST_CACHEDIR = 'tests/cachedir'