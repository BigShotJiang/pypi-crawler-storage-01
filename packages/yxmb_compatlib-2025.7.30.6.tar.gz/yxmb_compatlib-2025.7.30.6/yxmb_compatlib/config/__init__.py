from .merge_config import load_config

__all__ = [
    "load_config",
]
