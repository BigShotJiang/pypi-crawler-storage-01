'''
Created on Jul 17, 2025

@author: ahypki
'''
import gima
from gima.gima import main

if __name__ == '__main__':
    main()
    pass