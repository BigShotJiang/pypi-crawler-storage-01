"""
This package includes definitions of mandatory and optional parameters to be defined for each object of pyHarm.
This information is only used by the CLI capabilities of pyHarm, this introduces for now a bit of code duplication by allows for better separation of pyHarm package and its CLI tools.
"""

