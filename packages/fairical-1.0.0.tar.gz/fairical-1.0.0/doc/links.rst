.. SPDX-FileCopyrightText: Copyright © 2025 Idiap Research Institute <contact@idiap.ch>
..
.. SPDX-License-Identifier: GPL-3.0-or-later

.. place re-used URLs here, then include this file
.. on your other RST sources.

.. _idiap: http://www.idiap.ch
.. _python: http://www.python.org
.. _uv: https://docs.astral.sh/uv/
.. _pixi: https://pixi.sh
.. _pydantic: https://docs.pydantic.dev/latest/
