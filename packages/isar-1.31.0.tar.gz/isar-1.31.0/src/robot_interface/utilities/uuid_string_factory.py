from uuid import uuid4


def uuid4_string() -> str:
    return str(uuid4())
