class QueueTimeoutError(Exception):
    pass
