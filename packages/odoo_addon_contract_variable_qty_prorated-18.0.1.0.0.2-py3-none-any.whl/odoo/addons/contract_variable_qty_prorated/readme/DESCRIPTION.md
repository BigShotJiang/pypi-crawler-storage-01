This module adds a formula to compute prorated quantity to invoice as
extension of the module contract_variable_quantity.
