"""
darkfield CLI - ML Safety Platform Command Line Interface
"""

__version__ = "0.1.0"