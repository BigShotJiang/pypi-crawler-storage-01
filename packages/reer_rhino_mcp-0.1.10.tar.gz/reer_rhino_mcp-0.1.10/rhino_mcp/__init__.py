"""
Rhino Model Context Protocol (MCP) Integration
----------------------------------------------
A package that allows Claude to interact with Rhino through the Model Context Protocol
"""

__version__ = "0.1.10" 