from wyrmx_cli.commands.build import build
from wyrmx_cli.commands.new import new
from wyrmx_cli.commands.test import test
from wyrmx_cli.commands.run import run
from wyrmx_cli.commands.version import version