#define APSW_VERSION "3.50.4.0"
