# Dony for dony lib itself

Uses '_dony' directory for commands because of the conflict with the original package directory