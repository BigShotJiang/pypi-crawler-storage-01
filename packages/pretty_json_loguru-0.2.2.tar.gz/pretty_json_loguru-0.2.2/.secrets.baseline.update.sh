#pipx install detect-secrets
detect-secrets scan > .secrets.baseline