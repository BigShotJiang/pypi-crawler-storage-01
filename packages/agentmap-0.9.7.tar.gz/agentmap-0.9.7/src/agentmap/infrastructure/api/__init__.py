"""
Infrastructure API Package

This package contains all API infrastructure implementations,
keeping framework-specific code separate from core business logic.
"""
