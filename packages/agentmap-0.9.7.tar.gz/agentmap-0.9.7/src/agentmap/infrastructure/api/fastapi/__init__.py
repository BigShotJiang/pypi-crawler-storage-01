"""
FastAPI Infrastructure

This package contains FastAPI-specific implementations including routes,
middleware, and framework adapters following clean architecture principles.
"""
