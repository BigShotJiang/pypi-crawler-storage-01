# Template package for agent and function scaffolding
