from .stt import FalWizperSTT

__all__ = ["FalWizperSTT"]
