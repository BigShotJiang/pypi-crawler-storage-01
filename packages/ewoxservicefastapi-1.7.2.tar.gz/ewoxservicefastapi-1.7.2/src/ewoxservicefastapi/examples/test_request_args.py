from typing import Any, Callable, List, Dict, Text, Optional, Tuple, Union, Awaitable, TypeVar, Type
from datetime import date, datetime, timedelta


class TestRequestArgs():
    def __init__(self):
        self.name:str = "Dude"