"""
AWS Session TX CLI

A per-session "begin → plan → rollback" tool for AWS sandboxes.
"""

__version__ = "0.1.0"
__author__ = "Session TX Team" 