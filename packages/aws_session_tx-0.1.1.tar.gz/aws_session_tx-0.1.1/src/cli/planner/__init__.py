"""
Resource planning and dependency resolution for AWS Session TX
""" 