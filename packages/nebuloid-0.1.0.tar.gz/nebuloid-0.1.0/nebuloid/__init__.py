def hello():
    return "Nebuloid is alive!"
