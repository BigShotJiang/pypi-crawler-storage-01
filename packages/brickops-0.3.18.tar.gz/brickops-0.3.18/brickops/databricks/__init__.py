"""Databricks related functionality."""

import logging

logger = logging.getLogger(__name__)
