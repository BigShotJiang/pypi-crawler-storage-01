import logging

logging.getLogger("brickops").addHandler(logging.NullHandler())
