"""Module to build the configuration for the deployment of the jobs."""

from .build import build_pipeline_config

__all__ = ["build_pipeline_config"]
