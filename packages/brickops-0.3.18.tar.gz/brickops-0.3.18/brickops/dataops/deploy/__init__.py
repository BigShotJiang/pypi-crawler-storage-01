"""Module for the deployment of the jobs."""
