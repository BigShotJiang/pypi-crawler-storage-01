"""Module to build the configuration for the deployment of the jobs."""

from .build import build_job_config

__all__ = ["build_job_config"]
