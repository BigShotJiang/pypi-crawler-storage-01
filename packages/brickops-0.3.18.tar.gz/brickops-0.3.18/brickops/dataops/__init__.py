"""Module for dataops."""
