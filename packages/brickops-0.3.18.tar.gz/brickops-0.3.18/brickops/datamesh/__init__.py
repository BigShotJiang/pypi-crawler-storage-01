"""Main package for the project."""
