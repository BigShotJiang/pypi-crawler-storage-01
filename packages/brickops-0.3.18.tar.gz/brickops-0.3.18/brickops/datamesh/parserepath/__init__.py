# new module for configurable path parsing
from .parse import parsepath

__all__ = ["parsepath"]
