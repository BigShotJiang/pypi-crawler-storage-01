# Backup-chan client connection configuration changelog

See what's changed between versions!

## 0.1.0

The first stable version.
