from tunnelgraf import cli

cli(auto_envvar_prefix="TUNNELGRAF", prog_name="tunnelgraf")
