# Tunnelgraf - Hierarchical SSH tunnel management

---

Tunnelgraf is a CLI tool for connecting through a variable number of Bastion
hosts to many remote server endpoints, exposing them all as local ports. Its
intuitive YAML definitions enable version-controlled management of complex
hierarchical connections.

Tunnelgraf supports the lookup of credentials and hostname/IP endpoints via your
local ssh config file (~/.ssh/config) or Lastpass, making sharing connection
schemes more secure.

Tunnelgraf supports including one config file into another to keep the
connection profiles DRY when managing many similar environments, which is common
in most SDLCs.

Finally, it can also populate host file entries to redirect DNS names to
localhost.

## Table of Contents

- [Advantages](#advantages)
- [Getting Started](#getting-started)
- [Example Config File](#example-config-file)
- [Includes](#includes)
- [Configuration Precedence](#configuration-precedence)
- [Print the Resulting Local Configuration in JSON](#print-the-resulting-local-configuration-in-json)
- [Print URLs](#print-urls)
- [Resolve Remote DNS](#resolve-remote-dns)
- [Running Commands on the Remote Host](#running-commands-on-the-remote-host)
- [File Copying (SCP)](#file-copying-scp)
- [Shell into a Node](#shell-into-a-tunnel)
- [Contributing](#contributing)

## Advantages

- Connect to arrays of sibling endpoints at any level, e.g. application servers,
  databases, etc.
- Hide credentials and hostnames so connection schemas can be securely shared
  with peers.
- Look up local bind ports in external automation tooling.
- Populate hosts file entries in /etc/hosts and access endpoints requiring
  domain names in request headers.

## Getting Started

---

1. Install tunnelgraf with pip `pip3 install tunnelgraf`. If you run into
   dependency conflicts with other packages, use pipx insteadi, e.g.
   `pipx install tunnelgraf`.
1. Create a yaml file describing the connection hierarchy (reference the config
   example below).
1. Recommended: For personal computers, change the permissions of the hosts file
   to make it writeable by your user, e.g. `sudo chown $(whoami) /etc/hosts`.
   Also, make a backup copy of your hosts file, as this is early software.
1. Optional: If you want to use Lastpass for secrets management, install
   lastpass-cli. e.g. `brew install lastpass-cli`
1. Run `tunnelgraf -p [your config].yml connect`

Tunnelgraf will occupy the session until ctrl-c is pressed.

## Example Config File

---

```yaml
---
id: primary_bastion
port: 22
# Retrieves the hostname, user, and password
lastpass: primary_bastion
localbindport: 2222
nexthop:
  id: secondary_bastion
  port: 22
  sshuser: <A User>
  sshpass: <A password>
  localbindport: 2223
  nexthop:
    id: tertiary_bastion
    port: 22
    lastpass: tertiary_bastion
    localbindport: 2224
    hosts_file_entry: this.fqdn.domain.local
    nexthops:
      - id: node1
        # Example using specific credentials
        host: node1
        sshuser: <some user>
        sshpass: <some pass>
        port: 22
        localbindport: 2225
      - id: baseline_node
        host: baseline_node
        lastpass: baseline_node
        port: 22
        localbindport: 2226
      - id: another_endpoint
        host: gw-service.local
        hosts_file_entries:
          - gw-service.local
          - thisother.fqdn.domain.local
        port: 443
        localbindport: 8443
```

In the above example tunnelgraf opens nested ssh tunnels for the primary,
secondary, and tertiary bastion hosts. It then connects to the final 3 endpoints
through the tertiary endpoint.

## Includes

When working across SDLC environments, nexthop values are often the same or very
similar. Config files can include one another to make standardization DRY and
easier to manage.

Given the following two files:

staging_env.yml

```yaml
---
id: staging_env_bastion
port: 22
sshuser: <some user>
sshkeyfile: <path to some key file>
localbindport: 2223
include: defaults.yml
```

defaults.yml

```yaml
---
localbindport: 2224 #illustrating override logic
nexthops:
  - id: an_app_node
    host: <some fqdn>
    port: 443
    localbindport: 8443
    hosts_file_entry: <some fqdn>
```

the resulting configuration is

```yaml
---
id: staging_env_bastion
port: 22
sshuser: <some user>
sshkeyfile: <path to some key file>
localbindport: 2223 # top layer takes precedence
nexthops:
  - id: an_app_node
    host: <some fqdn>
    port: 443
    localbindport: 8443
    hosts_file_entry: <some fqdn>
```

## Configuration Precedence

Configuration data is merged from three data sources with the following
precedence.

1. The yml file data has the top priority.
2. Any included yml files have the second priority.
3. The ssh config file has the third priority.
4. Data from Lastpass has the last priority.

An example scenario where credential come from lastpass, the host comes from the
ssh config even though it is also in lastpass, and the port is overridden in the
yml file.

Separately, if an sshkey file is specified, it takes priority over the password.

## Print the Resulting Local Configuration in JSON

The resulting configuration can be printed to json by running the "show"
subcommand. This is useful for dynamically looking up connection details from
scripts or orchestration tools.

`tunnelgraf -p <config_file> -t <tunnel id> show`

```json
[
  {
    "id": "an_app_node",
    "host": "127.0.0.1",
    "port": 8443,
    "hosts_file_entry": "<some fqdn>"
  }
]
```

If no tunnel id is specified, all tunnels are displayed.

If `--show-credentials` is added, the credentials used when connecting are also
printed.

## Print URLs

To get json dump of the resulting URLs, run `tunnelgraf -p <config_file> urls`.
This will show a default prefix of "ssh://" unless a "protocol" value is
specified in the data. It will show the dns provided in hosts_file_entry or
hosts_file_entries if provided, otherwise, the IP address is shown.

```json
{
  "jumpbox": ["ssh://<ip address>:22"],
  "jumpbox2": ["ssh://<domain name>:2224"],
  "load_balancer": ["https://<fqdn>.local:8443", "https://<fqdn2>:8443"]
}
```

## Resolve Remote DNS

Often, especially in cloud/kubernetes environments, the remote IP is unknown and
the nameserver to resolve it with (e.g. coredns) is not configured in the remote
host's dns client configuration. In such examples, use "hostlookup" and
"nameserver" to dynamically fetch the remote IP address of the endpoint.

```yaml
---
id: staging_env_bastion
port: 22
sshuser: <some user>
sshkeyfile: <path to some key file>
localbindport: 2223 # top layer takes precedence
nexthops:
  - id: an_app_node
    hostlookup: <some fqdn>
    nameserver: <an address of the nameserver>
    port: 443
    localbindport: 8443
    hosts_file_entry: <some fqdn>
```

## Running Commands on the Remote Host

Tunnelgraf supports running commands on the remote host defined in the
connection profile.

`tunnelgraf -p <config_file> -t <tunnel id> command <command>`

This will run the command on the remote host and print the output.

## File Copying (SCP)

Tunnelgraf supports copying files and directories to/from remote hosts using SCP (Secure Copy Protocol). The scp command uses the same tunnel configurations and credentials as other commands.

To copy files, use the `scp` command with source and destination paths. At least one path must include a tunnel ID prefix to specify the remote location:

```bash
# Upload a local file or directory to remote host
tunnelgraf -p <config_file> scp ./local/path m001:/remote/path

# Download from remote host to local
tunnelgraf -p <config_file> scp m001:/remote/path.txt ./local/directory/

# Upload an entire directory recursively
tunnelgraf -p <config_file> scp ./local/directory/ m001:/remote/path/
```

The tunnel ID (e.g. 'm001') must match an ID defined in your connection profile. The remote path is relative to the user's home directory unless an absolute path is specified.

Some examples:

```bash
# Upload a local directory to remote home directory
tunnelgraf -p staging.yml scp ./configs/ app1:./

# Download a remote file to current directory  
tunnelgraf -p prod.yml scp db1:/etc/mysql/my.cnf ./

# Upload to a specific remote location
tunnelgraf -p dev.yml scp ./deploy.sh web1:/opt/app/
```

The scp command will:

- Recursively copy directories and their contents
- Preserve the directory structure and file timestamps (`-p` flag)
- Create remote directories as needed
- Show verbose progress output (`-v` flag)
- Use compression for better performance over slow connections (`-C` flag)
- Validate local paths before upload operations
- Use the same authentication (SSH keys or passwords) as defined in the tunnel config
- Provide detailed error messages and success confirmations

Note: Direct transfers between two remote hosts are not supported - files must be transferred through the local system.

**Requirements:**
- SCP must be installed (usually comes with OpenSSH client)
- sshpass is required if using password authentication
- Both tools must be available in the system PATH

## Shell into a tunnel

`tunnelgraf -p <config_file> -t <tunnel id> shell`

This will open an interactive shell into the tunnel.

## Contributing

Integration tests depend on Docker and docker-compose.

Fork repo. Run tests `make test`. Open PR once tests pass.
