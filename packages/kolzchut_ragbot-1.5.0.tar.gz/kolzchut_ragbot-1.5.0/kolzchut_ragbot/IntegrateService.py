class IntegrateService:

    def on_update_docs(self, _docs):
        raise NotImplementedError
