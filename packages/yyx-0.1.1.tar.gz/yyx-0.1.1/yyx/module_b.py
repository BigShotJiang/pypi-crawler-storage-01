def function_b():
    return "Hello from module B"