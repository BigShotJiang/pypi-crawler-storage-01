"""Client API for results in Nexus."""

# https://staging.myqos.com/api-docs#/results


# def get():
#     pass


# def get_only():
#     pass


# def _fetch_by_id():
#     pass


# def update():
#     pass
