"""Client API for backend snapshots in Nexus."""
# Work in progress

# https://staging.myqos.com/api-docs#/backend_snapshots


# def get():
#     pass


# def get_only():
#     pass


# def _fetch_by_id():
#     pass


# def update():
#     pass
