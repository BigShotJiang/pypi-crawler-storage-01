import webbrowser
print("activating the default browser...")
webbrowser.open("https://gguf.io")
print("note: if you are encountering restricted access problem with this domain; visit https://gguf.us instead; same content")