.. automodule:: vivarium_public_health.exposure.effect
