.. automodule:: vivarium_public_health.mslt.magic_wand_components
