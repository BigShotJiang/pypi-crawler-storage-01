# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

from deadline.unreal_logger.logger import get_logger

__all__ = ["get_logger"]
