"""Test package for elastic-zeroentropy library."""
