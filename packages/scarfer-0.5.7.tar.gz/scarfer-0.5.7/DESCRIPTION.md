Scarfer outputs compliance related information from a scan report.

A scan report contain lots of information about a file and it is
sometimes cumbersome to open with an editor to extract the information
wanted. Scarfer provides a command line access to scan reports.
