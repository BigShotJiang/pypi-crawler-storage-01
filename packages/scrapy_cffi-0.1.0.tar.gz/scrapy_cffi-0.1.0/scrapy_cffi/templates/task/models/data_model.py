from scrapy_cffi.models import BaseValidatedModel
"""
add your data model here, examples from scrapy_cffi path: scrapy_cffi.models.media.MediaInfo
"""