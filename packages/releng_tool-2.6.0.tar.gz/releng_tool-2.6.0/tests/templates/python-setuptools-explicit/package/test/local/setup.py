from setuptools import find_packages
from setuptools import setup

setup(
    description='hello world description',
    name='hello world',
    packages=find_packages(),
    version='1.0',
)
