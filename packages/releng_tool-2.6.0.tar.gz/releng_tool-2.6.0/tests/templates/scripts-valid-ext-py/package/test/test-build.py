file_flag = TARGET_DIR / 'invoked-build'
releng_touch(file_flag)
