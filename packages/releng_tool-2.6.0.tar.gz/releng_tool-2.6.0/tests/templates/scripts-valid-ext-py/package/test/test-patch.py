file_flag = TARGET_DIR / 'invoked-patch'
releng_touch(file_flag)
