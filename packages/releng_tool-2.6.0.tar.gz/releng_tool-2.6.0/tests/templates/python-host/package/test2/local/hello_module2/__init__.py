def hello_world2():
    print('hello world2')
