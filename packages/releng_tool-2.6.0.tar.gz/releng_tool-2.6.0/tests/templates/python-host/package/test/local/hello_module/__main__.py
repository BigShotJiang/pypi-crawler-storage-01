from hello_module import hello_world

def main():
    hello_world()

if __name__ == "__main__":
    main()
