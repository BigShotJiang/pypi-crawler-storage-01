def hello_world():
    print('hello world')
