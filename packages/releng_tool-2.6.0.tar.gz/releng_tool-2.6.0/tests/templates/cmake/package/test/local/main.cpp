#include "lib.h"

int main() {
    process();

    return 0;
}
