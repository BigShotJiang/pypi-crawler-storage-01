# sample extension will should load since the the required version
# number is older than the current version
def releng_setup(app):
    app.require_version('0.0')
