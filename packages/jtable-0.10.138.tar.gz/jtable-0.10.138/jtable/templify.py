#!/usr/bin/env python3

def main():
    from . import jtable
    jtable.main()