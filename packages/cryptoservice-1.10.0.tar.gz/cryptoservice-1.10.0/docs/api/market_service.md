# 市场数据服务

::: cryptoservice.services.market_service.MarketDataService
    options:
      show_root_heading: true
      show_source: true
