# 枚举类型

## 频率枚举

::: cryptoservice.models.Freq
    options:
        show_root_heading: true
        show_source: true
        heading_level: 3

## 排序方式

::: cryptoservice.models.SortBy
    options:
        show_root_heading: true
        show_source: true
        heading_level: 3

## K线类型

::: cryptoservice.models.HistoricalKlinesType
    options:
        show_root_heading: true
        show_source: true
        heading_level: 3
