"""This is the initialization file for the 'fabricatio_core.models' package.

It is used to initialize the package and expose its contents.
"""
