"""Init for ReadSam."""
from __future__ import absolute_import
from .beta_dist2 import *