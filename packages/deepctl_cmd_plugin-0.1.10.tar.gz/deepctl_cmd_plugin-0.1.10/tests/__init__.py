"""Tests for deepctl-cmd-plugin."""
