"""Unit tests for deepctl-cmd-plugin."""
