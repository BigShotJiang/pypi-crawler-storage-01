"""Plugin management command for deepctl."""

from .command import PluginCommand

__all__ = ["PluginCommand"]
