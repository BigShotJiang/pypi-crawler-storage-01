# Original Sources of Data

- `combined_PubMedQA_test.jsonl` and `combined_PubMedQA_train.jsonl`: https://pubmedqa.github.io/
- `session_based_next_item_selection_dataset.csv` and `multilingual_session_based_recommendation_dataset.csv`: https://amazon-kddcup24.github.io/