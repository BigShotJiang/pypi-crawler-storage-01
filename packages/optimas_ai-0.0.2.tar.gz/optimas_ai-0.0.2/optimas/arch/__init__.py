from .base import BaseComponent
from .system import CompoundAISystem