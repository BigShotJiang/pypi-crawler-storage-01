from typing import Final

class AthenaDefaultThreeColorsPuzzle:
    class Square5:
        UUID: Final[str] = "8a289f34-12d0-4844-92da-cb51eb5371de"
    class Square6:
        UUID: Final[str] = "9440be59-6965-4279-9dee-504bc8056b75"
    class Square7:
        UUID: Final[str] = "bbeb7551-fd00-4542-b096-17ad8d4c97b8"
    class Square8:
        UUID: Final[str] = "7662b250-7d1b-4d05-9448-69aca320b0da"
    class Square9:
        UUID: Final[str] = "1f1a888c-f3b5-42aa-b17c-93658bd6d638"

class AthenaDefaultFourColorsPuzzle:
    class Square5:
        UUID: Final[str] = "db7af395-4e5a-48da-90f3-139c3aaf8185"
    class Square6:
        UUID: Final[str] = "c25bafc1-2e2f-4ecb-adbb-d93e5e940edc"
    class Square7:
        UUID: Final[str] = "e1baf85b-20dd-4e49-94ba-a50787212c8c"
    class Square8:
        UUID: Final[str] = "a84fa989-265e-4258-844b-de1e48421424"
    class Square9:
        UUID: Final[str] = "e1baf85b-20dd-4e49-94ba-a50787212c8c"


