from enum import IntEnum


class TrackTerminalType(IntEnum):

    SkyCompass = 11,
    GodStatue = 12,

