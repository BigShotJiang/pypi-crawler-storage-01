from enum import IntEnum

class UserTitleType(IntEnum):
    VoiceTouched = 1,
    NewbornHero = 2,
