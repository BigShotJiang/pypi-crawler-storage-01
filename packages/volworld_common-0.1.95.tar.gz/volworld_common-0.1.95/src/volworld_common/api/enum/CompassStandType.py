from enum import IntEnum

class CompassStandType(IntEnum):

    Copper = 11,
    Circle = 12,
    Medicine = 13,
    SmallGarden = 14,
    Temple = 15,

