from aenum import IntEnum


class AuthRole(IntEnum):

    User = 0
    Tester = 8
    Administrator = 66
    Root = 99
