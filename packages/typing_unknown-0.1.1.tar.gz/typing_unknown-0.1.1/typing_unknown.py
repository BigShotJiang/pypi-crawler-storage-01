class Unknown:
    pass
