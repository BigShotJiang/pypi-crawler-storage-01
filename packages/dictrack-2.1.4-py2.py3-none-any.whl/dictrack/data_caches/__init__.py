from dictrack.data_caches.base import BaseDataCache
from dictrack.utils.utils import GLOBAL_DEFINES

GLOBAL_DEFINES.update({"data_cache": BaseDataCache})
