from dictrack.limiters.base import BaseLimiter
from dictrack.utils.utils import GLOBAL_DEFINES

GLOBAL_DEFINES.update({"limiter": BaseLimiter})
