from dictrack.trackers.base import BaseTracker, ResetPolicy  # noqa: F401
from dictrack.utils.utils import GLOBAL_DEFINES

GLOBAL_DEFINES.update({"tracker": BaseTracker})
