from dictrack.data_stores.base import BaseDataStore
from dictrack.utils.utils import GLOBAL_DEFINES

GLOBAL_DEFINES.update({"data_store": BaseDataStore})
