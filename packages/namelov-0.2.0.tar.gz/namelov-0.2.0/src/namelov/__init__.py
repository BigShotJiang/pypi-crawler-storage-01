from .hello import hello

def goodbye() -> str:
    return "Goodbye love! \n See you again in the world of love!"



__all__ = [
    "hello",
    "goodbye",
]