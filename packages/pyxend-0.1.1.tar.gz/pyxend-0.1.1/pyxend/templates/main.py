from pyxend import Extension

ext = Extension()

# create commands like this:
# @ext.command('COMMAND_NAME')
# def COMMAND_NAME(context):
#     ext.show_modal(context['selected_text'])

ext.run()