"""Async pipelines resource - placeholder for async implementation."""

from typing import Any


class AsyncPipelines:
    def __init__(self, client: Any) -> None:
        self._client = client
