"""Async users resource - placeholder for async implementation."""

# This would be the async version of the Users resource
# For now, this is a placeholder to prevent import errors

from typing import Any


class AsyncUsers:
    def __init__(self, client: Any) -> None:
        self._client = client
