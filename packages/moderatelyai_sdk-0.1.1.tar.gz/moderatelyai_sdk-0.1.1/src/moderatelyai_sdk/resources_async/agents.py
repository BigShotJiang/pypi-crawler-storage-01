"""Async agents resource - placeholder for async implementation."""

from typing import Any


class AsyncAgents:
    def __init__(self, client: Any) -> None:
        self._client = client
