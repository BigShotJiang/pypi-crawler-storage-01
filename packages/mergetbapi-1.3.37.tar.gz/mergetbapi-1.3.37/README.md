# mergetbapi

This package contains Python bindings for the GRPC client interface to the MergeTB API

