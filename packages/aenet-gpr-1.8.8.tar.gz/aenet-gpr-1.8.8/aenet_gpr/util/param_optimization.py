"""
Methods for optimizing kernel hyperparameters
1. Gradient-based optimization (PyTorch autograd)
2. Grid search
"""