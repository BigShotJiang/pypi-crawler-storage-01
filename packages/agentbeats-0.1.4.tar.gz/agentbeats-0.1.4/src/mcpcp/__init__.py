# MCP Control Panel Package

"""
MCP Control Panel - Interface for managing MCP servers and connections
"""

__version__ = "0.1.0"
