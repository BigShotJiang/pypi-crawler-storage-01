# -*- coding: utf-8 -*-
"""
Asset management utilities for AgentBeats SDK.
"""

from .assets import static_expose

__all__ = [
    'static_expose',
] 