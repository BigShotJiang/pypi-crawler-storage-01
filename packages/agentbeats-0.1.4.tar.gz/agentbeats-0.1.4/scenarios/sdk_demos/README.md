# Run template agent

See the README.md in each template agent, either you prefer.