# Template Agent 1 Using Python Files

First, fill in the agent card.
Then, register everything inside "main.py", including mcps and tools.
Finally, use agent.run() to server forever