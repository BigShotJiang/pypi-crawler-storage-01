## Support

Our support is very limited. For any concerns or inquiries, please contact us at [derek.loots@amsterdam.msf.org](mailto:derek.loots@amsterdam.msf.org).

Please note that we rely on our BSD 3-Clause License, which provides the software "as is" without any warranties. We appreciate your understanding and cooperation.