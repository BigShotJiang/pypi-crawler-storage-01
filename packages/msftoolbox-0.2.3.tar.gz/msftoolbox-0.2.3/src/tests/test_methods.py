def test_file_is_picked_up():
    assert True