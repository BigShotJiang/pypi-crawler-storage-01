This module depends on modules ``base``, ``mail``, ``sale`` and ``multi_pms_properties``.
Ensure yourself to have all them in your addons list.
