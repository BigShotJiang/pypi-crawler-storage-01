#!/usr/bin/env python3
"""
Entry point for xopt CLI when called as `python -m xopt`
"""

from xopt.cli import main

if __name__ == "__main__":
    main()