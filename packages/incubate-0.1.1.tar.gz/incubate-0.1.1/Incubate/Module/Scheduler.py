
def Lunch() -> None :
    
    print(123)