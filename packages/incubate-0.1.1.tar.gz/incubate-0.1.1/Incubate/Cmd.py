import sys as Sys;
import os as Os;
from .Module import Scheduler;

def Lunch() -> None :
    
    
    
    print(Sys.argv)
    print(Os.getcwd())
    
    print(Scheduler.Lunch())