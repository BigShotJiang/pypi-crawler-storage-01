class InlineSnapshotSyntaxWarning(Warning):
    pass


class InlineSnapshotInfo(Warning):
    pass
