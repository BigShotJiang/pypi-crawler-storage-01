# -*- coding: utf-8 -*-
import datetime
import scrapy
from ..src.output import output
from ..pipelines.formatters import AZsPipeline, DatesPipeline, CourtsPipeline
from ..pipelines.texts import TextsPipeline
from ..pipelines.exporters import ExportAsHtmlPipeline, FingerprintExportPipeline, RawExporter

class SpdrNW(scrapy.Spider):
    name = "spider_nw"
    base_url = "https://nrwesuche.justiz.nrw.de/index.php"
    custom_settings = {
        "DOWNLOAD_DELAY": 0.5, # minimum download delay 
        "AUTOTHROTTLE_ENABLED": False,
        "ITEM_PIPELINES": { 
            AZsPipeline: 100,
            DatesPipeline: 200,
            CourtsPipeline: 300,
            TextsPipeline: 400,
            ExportAsHtmlPipeline: 500,
            FingerprintExportPipeline: 600,
            RawExporter: 900
        }
    }

    def __init__(self, path, courts="", states="", fp=False, domains="", store_docId=False, postprocess=False, wait=False, **kwargs):
        self.path = path
        self.courts = courts
        self.states = states
        self.fp = fp
        self.domains = domains
        self.store_docId = store_docId
        self.postprocess = postprocess
        self.wait = wait
        super().__init__(**kwargs)

    async def start(self):
        start_req_bodies = []
        self.headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "de,en;q=0.9",
            "Cache-Control": "max-age=0",
            "Connection": "keep-alive",
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": "https://nrwesuche.justiz.nrw.de",
            "Referer": "https://nrwesuche.justiz.nrw.de/index.php",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
            "sec-ch-ua": "\"Not.A/Brand\";v=\"99\", \"Chromium\";v=\"136\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Linux\""
        }
        date_from = "23.5.1949"
        date_until = datetime.datetime.today().strftime("%d.%m.%Y")
        body = "gerichtstyp={}&gerichtsbarkeit={}&gerichtsort=&entscheidungsart=&date=&von={}&bis={}&validFrom=&von2=&bis2=&aktenzeichen=&schlagwoerter=&q=&method=stem&qSize=100&sortieren_nach=datum_absteigend&absenden=Suchen&advanced_search=false"
        if self.courts:
            if "ag" in self.courts:
                start_req_bodies.append(body.format("Amtsgericht", "Ordentliche+Gerichtsbarkeit", date_from, date_until))
            if "arbg" in self.courts:
                start_req_bodies.append(body.format("Arbeitsgericht", "Arbeitsgerichtsbarkeit", date_from, date_until))
            if "fg" in self.courts:
                start_req_bodies.append(body.format("Finanzgericht", "Finanzgerichtsbarkeit", date_from, date_until))
            if "lag" in self.courts:
                start_req_bodies.append(body.format("Landesarbeitsgericht", "Arbeitsgerichtsbarkeit", date_from, date_until))
            if "lg" in self.courts:
                start_req_bodies.append(body.format("Landgericht", "Ordentliche+Gerichtsbarkeit", date_from, date_until))
            if "lsg" in self.courts:
                start_req_bodies.append(body.format("Landessozialgericht", "Sozialgerichtsbarkeit", date_from, date_until))
            if "olg" in self.courts:
                start_req_bodies.append(body.format("Oberlandesgericht", "Ordentliche+Gerichtsbarkeit", date_from, date_until))
            if "ovg" in self.courts:
                start_req_bodies.append(body.format("Oberverwaltungsgericht", "Verwaltungsgerichtsbarkeit", date_from, date_until))
            if "sg" in self.courts:
                start_req_bodies.append(body.format("Sozialgericht", "Sozialgerichtsbarkeit", date_from, date_until))
            if "vg" in self.courts:
                start_req_bodies.append(body.format("Verwaltungsgericht", "Verwaltungsgerichtsbarkeit", date_from, date_until))
        else:
            start_req_bodies.append(body.format("","", date_from, date_until))
        for start_req_body in start_req_bodies:
            yield scrapy.Request(url=self.base_url, method="POST", headers=self.headers, body=start_req_body, meta={"body":start_req_body, "page":1}, dont_filter=True, callback=self.parse)
    
    def parse(self, response):
        for result in self.extract_data(response):
            yield result
        if response.xpath("//input[@value='>']"): # Button für nächste Seite
            page = response.meta["page"] + 1
            body = "page" + str(page) + "=%3E&" + response.meta["body"]
            yield scrapy.Request(url=self.base_url, method="POST", headers=self.headers, body=body, meta={"body":response.meta["body"], "page":page}, dont_filter=True, callback=self.parse)

    def extract_data(self, response):
        if response.xpath("//div[@class='alleErgebnisse']"):
            for res_div in response.xpath("//div[@class='einErgebnis']"):
                link = res_div.xpath(".//a/@href").get()
                court, date, az, = "", "", ""
                for el in res_div.xpath("text()"):
                    if el.get().strip()[:len("Gericht")] == "Gericht":
                        court = el.get().strip()[9:]
                    if el.get().strip()[:len("Entscheidungsdatum")] == "Entscheidungsdatum":
                        date = el.get().strip()[21:]
                    if el.get().strip()[:len("Aktenzeichen")] == "Aktenzeichen":
                        az = el.get().strip()[14:]
                yield {
                    "postprocess": self.postprocess,
                    "wait": self.wait,
                    "court": court,
                    "date": date,
                    "az": az,
                    "link": link,
                }
        else:
            output(f"blank search results page {response.url}", "warn")
