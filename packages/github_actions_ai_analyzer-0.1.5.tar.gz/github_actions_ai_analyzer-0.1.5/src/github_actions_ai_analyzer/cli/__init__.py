"""
CLI パッケージ

GitHub Actions AI Analyzerのコマンドラインインターフェースを提供します。
"""

from .main import main

__all__ = ["main"]
