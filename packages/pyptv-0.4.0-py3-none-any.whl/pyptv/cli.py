def cli():
    return "CLI template"
