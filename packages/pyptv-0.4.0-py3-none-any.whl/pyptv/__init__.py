from .__version__ import __version__ as __version__
from traits.etsconfig.etsconfig import ETSConfig
ETSConfig.toolkit = "qt"

