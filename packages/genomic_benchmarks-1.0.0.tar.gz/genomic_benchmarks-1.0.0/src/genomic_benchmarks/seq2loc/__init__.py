from .seq2loc import fasta2loc
