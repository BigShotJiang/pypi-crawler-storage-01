# __init__.py
from .inference import ezscore