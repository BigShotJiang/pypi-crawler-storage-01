"""Help Pyright find types.

:author: Shay Hill
:created: 2023-02-02
"""
