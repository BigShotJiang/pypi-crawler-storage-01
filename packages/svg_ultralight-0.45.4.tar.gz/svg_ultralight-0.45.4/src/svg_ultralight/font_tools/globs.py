"""Global values for working with fonts.

:author: Shay Hill
:created: 2025-06-09
"""

DEFAULT_FONT_SIZE = 12.0
