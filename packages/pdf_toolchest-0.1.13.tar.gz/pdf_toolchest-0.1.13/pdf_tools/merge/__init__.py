from .service import merge_pdfs

__all__ = ["merge_pdfs"]
