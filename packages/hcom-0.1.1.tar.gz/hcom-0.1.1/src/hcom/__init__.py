"""Claude Hook Comms - Real-time messaging between Claude Code agents."""

__version__ = "0.1.0"