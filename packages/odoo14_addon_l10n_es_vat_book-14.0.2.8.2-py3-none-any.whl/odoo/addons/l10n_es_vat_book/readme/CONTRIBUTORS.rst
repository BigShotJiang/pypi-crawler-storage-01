* Daniel Rodriguez <drl.9319@gmail.com>
* Jordi Ballester (ForgeFlow) <jordi.ballester@forgeflow.com>
* Luis M. Ontalba <luismaront@gmail.com>
* `Tecnativa <https://www.tecnativa.com/>`_:

  * Pedro M. Baeza
  * Carlos Dauden
  * Ernesto Tejeda
* Omar Castiñeira <omar@comunitea.com>
* Eduardo de miguel <edu@moduon.team>
