Módulo que calcula el libro de IVA español.

Esto módulo introduce el menú "Libro de IVA" en Contabilidad -> Informe ->
Declaraciones AEAT -> Libro de IVA.

Es posible visualizar e imprimir por separado:

* Libro Registro de Facturas Emitidas
* Libro Registro de Facturas Recibidas

Es posible exportar los registros a archivo con extensión xlsx.

En el modo de visualización de los informes es posible navegar a los asientos
contables relacionados con la factura.
