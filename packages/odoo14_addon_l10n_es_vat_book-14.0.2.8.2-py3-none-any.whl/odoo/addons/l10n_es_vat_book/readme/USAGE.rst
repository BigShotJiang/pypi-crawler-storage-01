#. Ve a *Contabilidad > Declaraciones AEAT > Libro de IVA*.
#. Crea un nuevo registro.
#. Escoge el periodo de tiempo para el libro.
#. Pulsa en "Calcular".
#. Escoge la opción de visualización o impresión preferida.
