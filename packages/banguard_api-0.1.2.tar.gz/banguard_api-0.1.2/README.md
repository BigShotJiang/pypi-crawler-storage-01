# [BanGuard](https://banguard.uk) API
BanGuard API python wrapper

Based on this [API documentation](https://banguard.uk/api-docs)
