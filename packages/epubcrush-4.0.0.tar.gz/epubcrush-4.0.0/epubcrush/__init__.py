name = "epubcrush"

from .epubcrush import main, crush_epub