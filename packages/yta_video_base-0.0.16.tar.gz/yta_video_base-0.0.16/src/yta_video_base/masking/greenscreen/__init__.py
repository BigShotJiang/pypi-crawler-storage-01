# TODO: By now I'm creating a new category apart from 'video', 
# 'audio' and 'image' because I don't know where can I put this
# code as green screens could be videos or images and they can
# also have images or videos inside