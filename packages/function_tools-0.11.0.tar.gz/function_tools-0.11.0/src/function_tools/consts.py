# Пустое значение полного наименования
EMPTY_VERBOSE_NAME = 'Empty verbose name'

ALL = '*'
