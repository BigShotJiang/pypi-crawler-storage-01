# sage_setup: distribution = sagemath-flint
from sage.rings.complex_interval_field import ComplexIntervalField

CIF = ComplexIntervalField()
