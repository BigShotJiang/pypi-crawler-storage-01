__version__: str = "10.0.1"  # Must be "<major>.<minor>.<patch>", all numbers
