# pyg_rnn/utils/pack.py
def sequence_ptr_from_edge_index(edge_index):
    # temporary placeholder for testing
    return edge_index
