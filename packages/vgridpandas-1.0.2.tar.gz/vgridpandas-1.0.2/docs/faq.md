# FAQ

## How do I report an issue or make a feature request

Please go to <https://github.com/opengeoshub/vgridpandas/issues>.

Alternatively, you can run vgridpandas directly using binder:

-   <https://mybinder.org/v2/gh/opengeoshub/vgridpandas/HEAD>