
**What's Changed**


**Full Changelog**: [v1.1.1...v1.0.0](https://github.com/opengeoshub/vgridpandas/compare/v1.1.1...v1.0.0)
