# Aggregates Reconcile Table Metrics
### It provides the following information:

* Mismatch
* Missing in Source
* Missing in Target
