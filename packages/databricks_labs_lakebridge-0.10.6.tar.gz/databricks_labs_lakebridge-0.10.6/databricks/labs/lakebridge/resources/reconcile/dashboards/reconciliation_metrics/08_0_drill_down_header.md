# Drill Down

### The details table contains all the sample records for mismatches and missing entries, providing users with exact details to pinpoint the issues.
