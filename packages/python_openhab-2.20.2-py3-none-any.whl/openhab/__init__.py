"""Module entry point."""

from .client import OpenHAB

__all__ = ['OpenHAB']
