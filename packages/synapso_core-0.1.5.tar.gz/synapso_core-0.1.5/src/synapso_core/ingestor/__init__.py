# Ingestor module for Synapso Core

from .document_ingestor import ingest_file

__all__ = ["ingest_file"]
