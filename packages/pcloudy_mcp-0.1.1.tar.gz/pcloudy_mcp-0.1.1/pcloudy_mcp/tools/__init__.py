"""Tools package for FastMCP server."""

from ..utils.tools_auto_registry import register_tools_with_config

__all__ = ["register_tools_with_config"]
