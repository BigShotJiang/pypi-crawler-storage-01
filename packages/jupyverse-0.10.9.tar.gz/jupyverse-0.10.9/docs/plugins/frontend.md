`fps-frontend` implements the common frontend configuration.
