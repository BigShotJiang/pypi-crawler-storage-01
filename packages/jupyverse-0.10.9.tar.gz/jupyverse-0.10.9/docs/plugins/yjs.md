`fps-yjs` implements the [Yjs](https://docs.yjs.dev) API, i.e. everything related to collaborative editing.
