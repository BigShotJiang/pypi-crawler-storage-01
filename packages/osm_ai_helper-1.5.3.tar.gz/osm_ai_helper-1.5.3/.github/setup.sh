python -m pip install torch torchvision
python -m pip install -e ".[demo]"
python -m pip install --upgrade streamlit
sudo apt-get update && sudo apt-get install libgl1 -y
