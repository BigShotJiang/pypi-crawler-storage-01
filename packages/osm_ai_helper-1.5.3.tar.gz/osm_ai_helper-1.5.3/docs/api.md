# API Reference

::: osm_ai_helper.download_osm

::: osm_ai_helper.group_elements_and_download_tiles

::: osm_ai_helper.convert_to_yolo_dataset

::: osm_ai_helper.run_inference

::: osm_ai_helper.export_osm

::: osm_ai_helper.utils.inference

::: osm_ai_helper.utils.osm

::: osm_ai_helper.utils.plots

::: osm_ai_helper.utils.tiles
