def enum_stringify(enum):
    return enum.value
