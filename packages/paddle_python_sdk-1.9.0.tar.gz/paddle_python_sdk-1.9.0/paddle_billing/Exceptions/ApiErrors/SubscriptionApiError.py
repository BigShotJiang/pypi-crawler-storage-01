from paddle_billing.Exceptions.ApiError import ApiError


class SubscriptionApiError(ApiError):
    pass
