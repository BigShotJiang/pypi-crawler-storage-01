from paddle_billing.Exceptions.ApiError import ApiError


class AdjustmentApiError(ApiError):
    pass
