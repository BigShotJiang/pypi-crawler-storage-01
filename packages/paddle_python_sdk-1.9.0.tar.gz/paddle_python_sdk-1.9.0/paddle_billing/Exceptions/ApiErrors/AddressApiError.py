from paddle_billing.Exceptions.ApiError import ApiError


class AddressApiError(ApiError):
    pass
