from paddle_billing.Exceptions.ApiError import ApiError


class DiscountApiError(ApiError):
    pass
