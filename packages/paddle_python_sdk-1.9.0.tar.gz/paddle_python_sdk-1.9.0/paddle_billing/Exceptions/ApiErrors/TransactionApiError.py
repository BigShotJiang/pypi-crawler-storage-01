from paddle_billing.Exceptions.ApiError import ApiError


class TransactionApiError(ApiError):
    pass
