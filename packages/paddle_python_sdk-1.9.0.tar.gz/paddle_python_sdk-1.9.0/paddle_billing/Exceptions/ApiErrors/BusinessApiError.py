from paddle_billing.Exceptions.ApiError import ApiError


class BusinessApiError(ApiError):
    pass
