__version__ = "16.0.0"

year = 2025
location = "Nimhans, Bengaluru, India"
cfp = "Submit your proposal: https://cfp.in.pycon.org/2025/cfp"
