"""
Castlecraft Engineer: A Python framework for building robust, scalable applications
with Domain-Driven Design (DDD), CQRS, and Event Sourcing principles.
"""
