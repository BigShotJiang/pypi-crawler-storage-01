# SetPropertyMode

The behavior if the property key already exists. - OVERWRITE (default): overwrite the existing value with the provided value - FAIL: fail the entire operation - SKIP: keep the existing value and skip setting the provided value 

## Enum

* `OVERWRITE` (value: `'OVERWRITE'`)

* `FAIL` (value: `'FAIL'`)

* `SKIP` (value: `'SKIP'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


