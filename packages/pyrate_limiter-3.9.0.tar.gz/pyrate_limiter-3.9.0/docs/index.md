# PyrateLimiter
```{include} ../README.md
:start-line: 3
:end-before: '## Contents'
```
<!-- Exclude markdown ToC and use Sphinx sidebar ToC instead -->
## Features
```{include} ../README.md
:start-after: '## Features'
```

# Reference Documentation
```{toctree}
:maxdepth: 2
reference
changelog
contributing
```
