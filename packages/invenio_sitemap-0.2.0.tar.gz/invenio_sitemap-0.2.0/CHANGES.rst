..
    Copyright (C) 2025 Northwestern University.

    invenio-sitemap is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Changes
=======

Version v0.2.0 (released 2025-08-01)

- views: add configurable global `/sitemap.xml` view

Version 0.1.2 (2025-06-13)

- content-type: set to application/xml

Version 0.1.1 (2025-05-15)

- entrypoint: fix path to InvenioSitemap in pyproject.toml

Version 0.1.0 (2025-03-25)

- Initial public release.
