..
    Copyright (C) 2025 Northwestern University.

    invenio-sitemap is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

Sitemap indices and sitemaps for InvenioRDM

- Northwestern University <DL_FSM_GDS@e.northwestern.edu>
