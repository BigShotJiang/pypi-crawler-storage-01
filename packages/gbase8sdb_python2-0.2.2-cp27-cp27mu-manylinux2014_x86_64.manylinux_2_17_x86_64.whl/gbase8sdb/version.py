# coding: utf8
"""
The version of the driver.
"""

__version__ = ".".join(map(str, (0, 2, 2)))

