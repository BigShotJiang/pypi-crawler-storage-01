import coverup

if __name__ == "__main__":
    coverup.main()
