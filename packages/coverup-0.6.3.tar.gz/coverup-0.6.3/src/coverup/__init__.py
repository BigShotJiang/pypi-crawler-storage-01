from .version import __version__
from .coverup import main
