from __future__ import annotations

from .proteus import Proteus

__version__ = '25.07.31'

__all__ = ['Proteus']
