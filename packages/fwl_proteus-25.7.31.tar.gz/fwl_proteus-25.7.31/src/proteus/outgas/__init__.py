from __future__ import annotations

from .wrapper import run_outgassing

__all__ = [
    'run_outgassing',
]
