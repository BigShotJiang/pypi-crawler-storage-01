from __future__ import annotations

from proteus import __version__


def test_version():
    assert __version__
