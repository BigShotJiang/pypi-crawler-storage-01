# CLI command modules for app management
