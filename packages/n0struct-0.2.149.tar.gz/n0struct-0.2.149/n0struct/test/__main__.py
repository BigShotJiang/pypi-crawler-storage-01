import sys
import os

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))

from test_n0struct01 import main as main1
main1()
from test_n0struct02 import main as main2
main2()
from test_n0struct03 import main as main3
main3()
from test_n0struct04 import main as main4
main4()
from test_n0struct05 import main as main5
main5()
# from test_n0struct06 import main as main6
# main6()
from test_n0struct07 import main as main7
main7()
from test_n0struct08 import main as main8
main8()
from test_n0struct09 import main as main9
main9()
from test_n0struct10 import main as main10
main10()
from test_n0struct11 import main as main11
main11()
