> [!NOTE]
> Bitte [klicken Sie hier](https://funstory-ai.github.io/BabelDOC/supported_languages/), um zur Seite *BabelDOC Unterstützte Sprachen* zu navigieren. Die dortigen Informationen gelten auch für pdf2zh.

<div align="right"> 
<h6><small>Ein Teil des Inhalts dieser Seite wurde von GPT übersetzt und kann Fehler enthalten.</small></h6>