> [!NOTE]
> 请[点击此处](https://funstory-ai.github.io/BabelDOC/supported_languages/)跳转至*BabelDOC 支持的语言*页面。该页面信息同样适用于 pdf2zh。

<div align="right"> 
<h6><small>本页面的部分内容由 GPT 翻译，可能包含错误。</small></h6>