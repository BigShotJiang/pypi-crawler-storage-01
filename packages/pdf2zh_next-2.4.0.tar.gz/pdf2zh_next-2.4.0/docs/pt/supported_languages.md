> [!NOTE]
> Por favor, [clique aqui](https://funstory-ai.github.io/BabelDOC/supported_languages/) para navegar até a página *Idiomas suportados pelo BabelDOC*. As informações lá também se aplicam ao pdf2zh.

<div align="right"> 
<h6><small>Parte do conteúdo desta página foi traduzida pelo GPT e pode conter erros.</small></h6>