from django.apps import AppConfig


class SnappeaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'snappea'
