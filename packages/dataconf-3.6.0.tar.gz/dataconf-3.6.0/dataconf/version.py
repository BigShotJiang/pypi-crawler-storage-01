import sys

__version__ = "3.6.0"

PY310up = sys.version_info >= (3, 10)
PY311up = sys.version_info >= (3, 11)
