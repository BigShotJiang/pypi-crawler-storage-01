# 8b    d8 Yb  dP 88""Yb    db     dP""b8 88  dP    db     dP""b8 888888
# 88b  d88  YbdP  88__dP   dPYb   dP   `" 88odP    dPYb   dP   `" 88__
# 88YbdP88   8P   88"""   dP__Yb  Yb      88"Yb   dP__Yb  Yb  "88 88""
# 88 YY 88  dP    88     dP""""Yb  YboodP 88  Yb dP""""Yb  YboodP 888888

VERSION = (5, 2, 0)

__version__ = '.'.join(map(str, VERSION))
