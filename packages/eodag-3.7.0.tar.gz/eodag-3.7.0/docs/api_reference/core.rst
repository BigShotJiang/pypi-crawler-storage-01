.. module:: eodag.api.core

===================
EODataAccessGateway
===================

Constructor
-----------
.. autosummary::

   EODataAccessGateway

Configuration
-------------

.. autosummary::

   EODataAccessGateway.add_provider
   EODataAccessGateway.set_preferred_provider
   EODataAccessGateway.get_preferred_provider
   EODataAccessGateway.update_providers_config
   EODataAccessGateway.update_product_types_list

Catalog
-------

.. autosummary::

   EODataAccessGateway.available_providers
   EODataAccessGateway.list_product_types
   EODataAccessGateway.guess_product_type
   EODataAccessGateway.fetch_product_types_list
   EODataAccessGateway.discover_product_types

Search
------

.. autosummary::

   EODataAccessGateway.search
   EODataAccessGateway.search_all
   EODataAccessGateway.search_iter_page

Crunch
------

.. autosummary::

   EODataAccessGateway.crunch
   EODataAccessGateway.get_cruncher

Download
--------

.. autosummary::

   EODataAccessGateway.download
   EODataAccessGateway.download_all

Serialize/Deserialize
---------------------

.. autosummary::

   EODataAccessGateway.serialize
   EODataAccessGateway.deserialize
   EODataAccessGateway.deserialize_and_register


Misc
----

.. autosummary::

   EODataAccessGateway.group_by_extent
   EODataAccessGateway.guess_product_type
   EODataAccessGateway.list_queryables
   EODataAccessGateway.available_sortables
   EODataAccessGateway.import_stac_items

.. autoclass:: eodag.api.core.EODataAccessGateway
   :members: add_provider, set_preferred_provider, get_preferred_provider, update_providers_config, list_product_types,
             available_providers, search, search_all, search_iter_page, crunch, download, download_all, serialize,
             deserialize, deserialize_and_register, load_stac_items, group_by_extent, guess_product_type, get_cruncher,
             update_product_types_list, fetch_product_types_list, discover_product_types, list_queryables,
             available_sortables, import_stac_items
