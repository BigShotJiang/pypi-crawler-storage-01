==========
Exceptions
==========

.. automodule:: eodag.utils.exceptions
   :members:

.. warning::

   The following classes will only be available with `eodag-cube <https://github.com/CS-SI/eodag-cube>`__ installed.

.. automodule:: eodag_cube.utils.exceptions
   :members:
