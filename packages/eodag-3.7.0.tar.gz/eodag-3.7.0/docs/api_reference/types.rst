=====
Types
=====

.. automodule:: eodag.types.__init__
   :members:

.. automodule:: eodag.types.download_args
   :members:

.. autoclass:: eodag_cube.types.XarrayDict
   :members:
