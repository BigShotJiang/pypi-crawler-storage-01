"""Initialize the CLI module."""
