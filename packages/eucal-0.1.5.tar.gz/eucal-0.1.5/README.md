# EUCAL tool

Evaluation & Utilization of Clocked Activity Logs

Execute with

```bash
eucal ./path/to/table.pdf
```
