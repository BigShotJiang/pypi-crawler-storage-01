from . import eucal

def main():
    eucal.main()