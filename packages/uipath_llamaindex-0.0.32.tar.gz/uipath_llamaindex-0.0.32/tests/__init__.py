"""
Test suite for UiPath LlamaIndex SDK.
Contains test cases for all CLI commands and utilities.
"""
