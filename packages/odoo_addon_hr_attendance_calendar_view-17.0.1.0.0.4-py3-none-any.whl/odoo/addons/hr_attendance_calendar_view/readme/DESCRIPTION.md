Calendar view for attendances.
