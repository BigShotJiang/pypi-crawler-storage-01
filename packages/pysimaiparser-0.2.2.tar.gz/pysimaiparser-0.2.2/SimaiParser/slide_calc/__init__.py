__version__ = "2.0.0"

from .slide_length import SimaiSlideCalculator

__all__ = [
    'SimaiSlideCalculator'
]
