
# Change Log

## 0.1.5 (July 30, 2025)

Notes: 
* Added formatting to select messages to make the messages purpose clearer.

BUG FIXES:
* Fixed issue getting books from libro and chirp too aggressively
* User must now track deals for at least one retailer 

