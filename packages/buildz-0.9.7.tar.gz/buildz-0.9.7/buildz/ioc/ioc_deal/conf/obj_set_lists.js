[
    {
        nullable: 0,
        key: key
    },
    {
        nullable: 0,
        key: val
    }
]