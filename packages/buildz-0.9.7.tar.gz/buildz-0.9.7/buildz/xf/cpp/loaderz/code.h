char* do_translate(const char* s);
