#coding=utf-8
from buildz.base import Base, WBase, With
@With(False)
class Getch(Base):
    pass

pass
