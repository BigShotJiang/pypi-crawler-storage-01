{
    request: {
        debug: false
    },
    host: www.baidu.com,
    test: {
        url: tmpurl,
        val: 1,
        code: 1.99
    },
}