#coding=utf-8
from .demo.test import test
if __name__=="__main__":
    test()

pass
