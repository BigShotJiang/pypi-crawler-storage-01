

dp: ''
fps: [x.py, inc.py]
run: x.test
args: []
stdin: std // std, [file, ...], [str, ....]
stdout: std//[file, out.txt] // std, [file, ...]
stderr: std//[file, out.txt]