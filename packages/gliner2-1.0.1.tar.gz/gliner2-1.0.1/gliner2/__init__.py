__version__ = "1.0.1"

from .inference.engine import GLiNER2
from .model import Extractor, ExtractorConfig