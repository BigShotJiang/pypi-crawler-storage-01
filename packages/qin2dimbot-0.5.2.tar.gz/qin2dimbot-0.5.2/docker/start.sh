docker compose pull
docker compose down
docker compose up -d
docker compose logs telegram-dify-bot -f --no-log-prefix