from yapp import YApp

# this is a dummy example on how the user should use the yapp module


yapp = YApp()


@yapp.run
def run()
    pass


@yapp.expose
def expose():
    return
    pass
