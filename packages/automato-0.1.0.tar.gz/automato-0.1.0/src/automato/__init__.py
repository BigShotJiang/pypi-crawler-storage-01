from .automato import Automato

__all__ = ["Automato"]
