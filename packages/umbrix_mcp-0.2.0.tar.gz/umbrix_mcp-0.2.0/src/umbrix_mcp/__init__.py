"""Umbrix MCP Server - AI-powered Cyber Threat Intelligence"""

__version__ = "0.1.0"
__author__ = "Umbrix Team"
__email__ = "support@umbrix.dev"
