---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# embeddings

`embeddings` 提供了一系列预定义的位置编码。
