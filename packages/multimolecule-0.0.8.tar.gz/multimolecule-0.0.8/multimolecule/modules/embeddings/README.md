---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# embeddings

`embeddings` provide a collection of pre-defined positional embeddings.
