---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# datasets

`datasets` provide a collection of widely used datasets.

## Usage

### Load with [MultiMolecule][multimolecule.Dataset]

```python
--8<-- "examples/data/huggingface-datasets.py:23:"
```
