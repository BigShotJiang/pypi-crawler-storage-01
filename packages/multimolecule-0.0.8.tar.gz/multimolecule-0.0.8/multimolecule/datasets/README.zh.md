---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# datasets

`datasets` 提供了一系列广泛使用的数据集。

## 使用

### 使用 [MultiMolecule][multimolecule.Dataset] 加载

```python
--8<-- "examples/data/huggingface-datasets.py:23:"
```
