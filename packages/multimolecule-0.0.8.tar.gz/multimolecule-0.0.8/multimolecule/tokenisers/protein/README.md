---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# ProteinTokenizer

ProteinTokenizer is smart, it tokenizes raw amino acids into tokens, no matter if the input is in uppercase or lowercase, and with or without special tokens.

By default, `ProteinTokenizer` uses the [standard alphabet](#standard-alphabet).
