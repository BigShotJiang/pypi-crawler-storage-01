---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# ERNIE-RNA

--8<-- "multimolecule/models/ernierna/README.md:42:"

::: multimolecule.models.ernierna
