---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# RibonanzaNet

--8<-- "multimolecule/models/ribonanzanet/README.md:13:"

::: multimolecule.models.ribonanzanet
