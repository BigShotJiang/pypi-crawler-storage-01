---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# 3UTRBERT

--8<-- "multimolecule/models/utrbert/README.md:42:"

::: multimolecule.models.utrbert
