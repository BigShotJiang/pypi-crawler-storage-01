---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# CaLM

--8<-- "multimolecule/models/calm/README.md:29:"

::: multimolecule.models.calm
