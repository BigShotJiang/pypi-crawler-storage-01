---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# RNAErnie

--8<-- "multimolecule/models/rnaernie/README.md:42:"

::: multimolecule.models.rnaernie
