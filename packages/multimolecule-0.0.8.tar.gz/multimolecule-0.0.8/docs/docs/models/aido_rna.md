---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# AIDO.RNA

--8<-- "multimolecule/models/aido_rna/README.md:42:"

::: multimolecule.models.aido_rna
