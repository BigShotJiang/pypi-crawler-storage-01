---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# RNA-FM

--8<-- "multimolecule/models/rnafm/README.md:42:"

::: multimolecule.models.rnafm
