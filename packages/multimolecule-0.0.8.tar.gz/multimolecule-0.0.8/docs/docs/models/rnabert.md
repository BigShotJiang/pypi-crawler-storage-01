---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# RNABERT

--8<-- "multimolecule/models/rnabert/README.md:42:"

::: multimolecule.models.rnabert
