---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# RiNALMo

--8<-- "multimolecule/models/rinalmo/README.md:45:"

::: multimolecule.models.rinalmo
