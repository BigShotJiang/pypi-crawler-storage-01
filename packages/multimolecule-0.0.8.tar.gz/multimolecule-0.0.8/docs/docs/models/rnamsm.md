---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# RNA-MSM

--8<-- "multimolecule/models/rnamsm/README.md:42:"

::: multimolecule.models.rnamsm
