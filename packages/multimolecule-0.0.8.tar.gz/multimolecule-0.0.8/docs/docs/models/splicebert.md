---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# SpliceBERT

--8<-- "multimolecule/models/splicebert/README.md:42:"

::: multimolecule.models.splicebert
