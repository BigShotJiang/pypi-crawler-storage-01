---
summary: 不作意 任自然 即此语 是灵丹
authors:
  - Zhiyuan Chen
date: 2022-05-04
---

# MultiMolecule

--8<-- "README.zh.md:2:"
