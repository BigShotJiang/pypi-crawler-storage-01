---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# RnaTokenizer

--8<-- "multimolecule/tokenisers/rna/README.md:8:"

::: multimolecule.tokenisers.RnaTokenizer

--8<-- "multimolecule/tokenisers/rna/ALPHABET.md:8:"
