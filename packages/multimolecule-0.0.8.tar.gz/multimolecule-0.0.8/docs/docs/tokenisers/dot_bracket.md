---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# DotBracketTokenizer

--8<-- "multimolecule/tokenisers/dot_bracket/README.md:8:"

::: multimolecule.tokenisers.DotBracketTokenizer

--8<-- "multimolecule/tokenisers/dot_bracket/ALPHABET.md:8:"
