---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# functional

::: multimolecule.data.functional
