---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# embeddings

--8<-- "multimolecule/modules/embeddings/README.md:8:"

::: multimolecule.modules.embeddings
