---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# heads

--8<-- "multimolecule/modules/heads/README.zh.md:8:"

::: multimolecule.modules.heads.config

::: multimolecule.modules.heads.sequence

::: multimolecule.modules.heads.token

::: multimolecule.modules.heads.contact

::: multimolecule.modules.heads.pretrain

::: multimolecule.modules.heads.generic

::: multimolecule.modules.heads.output
