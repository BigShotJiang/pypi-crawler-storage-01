---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# EternaBench-CM

--8<-- "multimolecule/datasets/eternabench_cm/README.md:21:"
