---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# GENCODE

--8<-- "multimolecule/datasets/gencode/README.md:21:"
