---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# EternaBench-External

--8<-- "multimolecule/datasets/eternabench_external/README.md:21:"
