---
authors:
  - Zhiyuan Chen
date: 2024-05-04
---

# EternaBench-Switch

--8<-- "multimolecule/datasets/eternabench_switch/README.md:21:"
