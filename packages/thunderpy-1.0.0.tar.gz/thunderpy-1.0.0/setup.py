from setuptools import setup, find_packages

setup(
    name="thunderpy",
    version="1.0.0",
    packages=find_packages(),
    author="whyraze",
    description="Testlibrarry",
    python_requires=">=3.6",
)