"""Init for Data."""
from __future__ import absolute_import

from .import_data import get_data_file