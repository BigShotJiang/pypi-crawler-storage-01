# SPDX-FileCopyrightText: NONE
# SPDX-License-Identifier: CC0-1.0

from setuptools import setup

setup()
