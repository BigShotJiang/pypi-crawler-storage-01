.. This file is part of pdfposter.
   Copyright (C) 2008-2025 Hartmut Goebel
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   SPDX-License-Identifier: GFDL-1.3-or-later

==============
Usage
==============

.. include:: _description.txt


Options
========

.. include:: _options.txt

.. include:: _box-definitions.txt
