# -*- coding: utf-8 -*-


class BindException(Exception):
    pass
