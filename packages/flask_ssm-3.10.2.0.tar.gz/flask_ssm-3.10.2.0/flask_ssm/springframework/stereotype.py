# -*- coding: utf-8 -*-


class Controller:
    """
    接口\n
    """
    pass


class Service:
    """
    业务逻辑\n
    """
    pass


class Repository:
    """
    数据交互\n
    """
    pass
