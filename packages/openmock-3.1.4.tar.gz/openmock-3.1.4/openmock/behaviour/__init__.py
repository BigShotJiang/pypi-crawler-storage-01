from openmock.behaviour import server_failure


def disable_all():
    server_failure.disable()
