"""Setup script for backward compatibility with older tools."""

from setuptools import setup

if __name__ == "__main__":
    setup() 