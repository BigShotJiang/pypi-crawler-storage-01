from zaturn.studio.app import app


def main():
    app.run(port=6066, debug=True)
