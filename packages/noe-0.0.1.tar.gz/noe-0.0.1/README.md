# noe

[![PyPI - Version](https://img.shields.io/pypi/v/noe.svg)](https://pypi.org/project/noe)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/noe.svg)](https://pypi.org/project/noe)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install noe
```

## License

`noe` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
