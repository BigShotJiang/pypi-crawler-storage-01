# SPDX-FileCopyrightText: 2025-present Rohit Goswami <rog32@hi.is>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
