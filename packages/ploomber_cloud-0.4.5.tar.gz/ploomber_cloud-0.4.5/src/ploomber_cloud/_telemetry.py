from ploomber_core.telemetry import Telemetry

telemetry = Telemetry.from_package(
    package_name="ploomber-cloud",
    print_cloud_message=False,
    api_key="phc_q3bxtaHQDL6WQg4zM7NfsXgTmyXfl4OksFiL6X4N74H",
)
