# ploomber-cloud

Source code for `ploomber-cloud` CLI.

Set up dev env (requires conda):

```sh
pip install invoke
invoke setup
```


Public-facing documentation [available here](https://docs.cloud.ploomber.io). To
document changes, please opena PR to the [`ploomber/doc`](https://github.com/ploomber/doc)
repository.