from setuptools import setup, find_packages

setup(
    name='lovepackage',
    version='0.1',
    description='A lovely message from Harshith to Mushaib',
    author='Harshith',
    packages=find_packages(),
    python_requires='>=3.6',
)
