from .love import LoveNote
note = LoveNote()
