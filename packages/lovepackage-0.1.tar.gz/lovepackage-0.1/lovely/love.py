class LoveNote:
    def __str__(self):
        return "harshith loves mushaib"
