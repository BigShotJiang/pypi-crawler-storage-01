# -*-coding:utf-8-*-

""" 队列配置 """
rabbitmq = {
    'connector':'Amqp',
    'expire':60,
    'default':'default',
    'host':'106.52.213.169',
    'username':'admin',
    'password':'BREMdL8N',
    'port':5672,
    'vhost':'/',
    'select':0,
    'timeout':0,
    'persistent':False,
}