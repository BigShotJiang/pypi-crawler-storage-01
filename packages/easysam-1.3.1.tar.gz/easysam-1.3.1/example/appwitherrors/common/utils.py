def my_common_function():
    return 'Hello, world!'
