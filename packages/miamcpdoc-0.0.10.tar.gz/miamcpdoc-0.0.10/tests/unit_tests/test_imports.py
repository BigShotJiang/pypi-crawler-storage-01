def test_imports():
    """Test that main modules can be imported."""
    from mcpdoc import main  # noqa
    from mcpdoc import cli  # noqa
    from mcpdoc import langgraph  # noqa

    assert True
