# FastClean

FastAPI clean architecture implementation


## Contribution

```
git clone git@github.com:Luferov/fast-clean.git
uv sync
uv run pre-commit install
```
