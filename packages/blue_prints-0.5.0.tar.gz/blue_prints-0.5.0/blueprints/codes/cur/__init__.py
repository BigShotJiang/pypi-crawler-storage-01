"""CUR guidelines."""
