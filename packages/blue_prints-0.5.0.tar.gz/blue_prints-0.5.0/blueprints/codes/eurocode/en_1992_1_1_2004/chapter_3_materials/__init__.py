"""Package containing all formulas from EN 1992-1-1:2004: Chapter 3 - Materials."""
