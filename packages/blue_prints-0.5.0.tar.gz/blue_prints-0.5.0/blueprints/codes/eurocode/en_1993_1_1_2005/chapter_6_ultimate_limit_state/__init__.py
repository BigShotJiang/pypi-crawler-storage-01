"""Module containing all formulas from 1993-1-1+C2+A1:2016: Chapter 6 - Ultimate limit state."""
