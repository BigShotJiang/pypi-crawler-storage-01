"""Module containing all formulas from EN 1993-1-1:2005: Chapter 5 - Structural analysis."""
