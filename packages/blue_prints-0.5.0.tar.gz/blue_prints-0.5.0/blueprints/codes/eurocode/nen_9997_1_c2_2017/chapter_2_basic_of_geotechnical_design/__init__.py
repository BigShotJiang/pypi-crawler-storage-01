"""Package contains the formulas from chapter 2: Basic of geotechnical design of NEN 9997-1+C2:2017."""
