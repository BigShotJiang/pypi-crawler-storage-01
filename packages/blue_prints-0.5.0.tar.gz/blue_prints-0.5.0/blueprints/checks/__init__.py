"""Collection of common civil engineering checks."""
