"""Contains tests for the nominal concrete cover check."""
