def hello() -> str:
    return "Hello from notion-to-llms-txt!"
