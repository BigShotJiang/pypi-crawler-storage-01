import { m as a, u as i, a as r } from "./index-Cu1EQZGJ.js";
function u(n) {
  if (n === null || a(n) || i(n))
    return 1;
  if (r(n))
    return 2;
}
export {
  u as c
};
