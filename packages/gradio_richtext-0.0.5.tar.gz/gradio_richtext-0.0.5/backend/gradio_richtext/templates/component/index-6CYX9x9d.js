import { s as O, f as _, b as D, c as T, h as U } from "./index-XASQ8rxc.js";
import { z as j } from "./index-qZRjazc5.js";
import { c as x } from "./index-uEBo76nn.js";
import { w as y } from "./index-qIqGBAea.js";
const F = [
  "area",
  "base",
  "basefont",
  "bgsound",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "image",
  "img",
  "input",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
], P = /["&'<>`]/g, k = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, z = (
  // eslint-disable-next-line no-control-regex, unicorn/no-hex-escape
  /[\x01-\t\v\f\x0E-\x1F\x7F\x81\x8D\x8F\x90\x9D\xA0-\uFFFF]/g
), B = /[|\\{}()[\]^$+*?.]/g, C = /* @__PURE__ */ new WeakMap();
function H(n, a) {
  if (n = n.replace(
    a.subset ? I(a.subset) : P,
    e
  ), a.subset || a.escapeOnly)
    return n;
  return n.replace(k, t).replace(z, e);
  function t(r, s, o) {
    return a.format(
      (r.charCodeAt(0) - 55296) * 1024 + r.charCodeAt(1) - 56320 + 65536,
      o.charCodeAt(s + 2),
      a
    );
  }
  function e(r, s, o) {
    return a.format(
      r.charCodeAt(0),
      o.charCodeAt(s + 1),
      a
    );
  }
}
function I(n) {
  let a = C.get(n);
  return a || (a = $(n), C.set(n, a)), a;
}
function $(n) {
  const a = [];
  let t = -1;
  for (; ++t < n.length; )
    a.push(n[t].replace(B, "\\$&"));
  return new RegExp("(?:" + a.join("|") + ")", "g");
}
const L = /[\dA-Fa-f]/;
function Y(n, a, t) {
  const e = "&#x" + n.toString(16).toUpperCase();
  return t && a && !L.test(String.fromCharCode(a)) ? e : e + ";";
}
const G = /\d/;
function M(n, a, t) {
  const e = "&#" + String(n);
  return t && a && !G.test(String.fromCharCode(a)) ? e : e + ";";
}
const Z = [
  "AElig",
  "AMP",
  "Aacute",
  "Acirc",
  "Agrave",
  "Aring",
  "Atilde",
  "Auml",
  "COPY",
  "Ccedil",
  "ETH",
  "Eacute",
  "Ecirc",
  "Egrave",
  "Euml",
  "GT",
  "Iacute",
  "Icirc",
  "Igrave",
  "Iuml",
  "LT",
  "Ntilde",
  "Oacute",
  "Ocirc",
  "Ograve",
  "Oslash",
  "Otilde",
  "Ouml",
  "QUOT",
  "REG",
  "THORN",
  "Uacute",
  "Ucirc",
  "Ugrave",
  "Uuml",
  "Yacute",
  "aacute",
  "acirc",
  "acute",
  "aelig",
  "agrave",
  "amp",
  "aring",
  "atilde",
  "auml",
  "brvbar",
  "ccedil",
  "cedil",
  "cent",
  "copy",
  "curren",
  "deg",
  "divide",
  "eacute",
  "ecirc",
  "egrave",
  "eth",
  "euml",
  "frac12",
  "frac14",
  "frac34",
  "gt",
  "iacute",
  "icirc",
  "iexcl",
  "igrave",
  "iquest",
  "iuml",
  "laquo",
  "lt",
  "macr",
  "micro",
  "middot",
  "nbsp",
  "not",
  "ntilde",
  "oacute",
  "ocirc",
  "ograve",
  "ordf",
  "ordm",
  "oslash",
  "otilde",
  "ouml",
  "para",
  "plusmn",
  "pound",
  "quot",
  "raquo",
  "reg",
  "sect",
  "shy",
  "sup1",
  "sup2",
  "sup3",
  "szlig",
  "thorn",
  "times",
  "uacute",
  "ucirc",
  "ugrave",
  "uml",
  "uuml",
  "yacute",
  "yen",
  "yuml"
], p = {
  nbsp: " ",
  iexcl: "¡",
  cent: "¢",
  pound: "£",
  curren: "¤",
  yen: "¥",
  brvbar: "¦",
  sect: "§",
  uml: "¨",
  copy: "©",
  ordf: "ª",
  laquo: "«",
  not: "¬",
  shy: "­",
  reg: "®",
  macr: "¯",
  deg: "°",
  plusmn: "±",
  sup2: "²",
  sup3: "³",
  acute: "´",
  micro: "µ",
  para: "¶",
  middot: "·",
  cedil: "¸",
  sup1: "¹",
  ordm: "º",
  raquo: "»",
  frac14: "¼",
  frac12: "½",
  frac34: "¾",
  iquest: "¿",
  Agrave: "À",
  Aacute: "Á",
  Acirc: "Â",
  Atilde: "Ã",
  Auml: "Ä",
  Aring: "Å",
  AElig: "Æ",
  Ccedil: "Ç",
  Egrave: "È",
  Eacute: "É",
  Ecirc: "Ê",
  Euml: "Ë",
  Igrave: "Ì",
  Iacute: "Í",
  Icirc: "Î",
  Iuml: "Ï",
  ETH: "Ð",
  Ntilde: "Ñ",
  Ograve: "Ò",
  Oacute: "Ó",
  Ocirc: "Ô",
  Otilde: "Õ",
  Ouml: "Ö",
  times: "×",
  Oslash: "Ø",
  Ugrave: "Ù",
  Uacute: "Ú",
  Ucirc: "Û",
  Uuml: "Ü",
  Yacute: "Ý",
  THORN: "Þ",
  szlig: "ß",
  agrave: "à",
  aacute: "á",
  acirc: "â",
  atilde: "ã",
  auml: "ä",
  aring: "å",
  aelig: "æ",
  ccedil: "ç",
  egrave: "è",
  eacute: "é",
  ecirc: "ê",
  euml: "ë",
  igrave: "ì",
  iacute: "í",
  icirc: "î",
  iuml: "ï",
  eth: "ð",
  ntilde: "ñ",
  ograve: "ò",
  oacute: "ó",
  ocirc: "ô",
  otilde: "õ",
  ouml: "ö",
  divide: "÷",
  oslash: "ø",
  ugrave: "ù",
  uacute: "ú",
  ucirc: "û",
  uuml: "ü",
  yacute: "ý",
  thorn: "þ",
  yuml: "ÿ",
  fnof: "ƒ",
  Alpha: "Α",
  Beta: "Β",
  Gamma: "Γ",
  Delta: "Δ",
  Epsilon: "Ε",
  Zeta: "Ζ",
  Eta: "Η",
  Theta: "Θ",
  Iota: "Ι",
  Kappa: "Κ",
  Lambda: "Λ",
  Mu: "Μ",
  Nu: "Ν",
  Xi: "Ξ",
  Omicron: "Ο",
  Pi: "Π",
  Rho: "Ρ",
  Sigma: "Σ",
  Tau: "Τ",
  Upsilon: "Υ",
  Phi: "Φ",
  Chi: "Χ",
  Psi: "Ψ",
  Omega: "Ω",
  alpha: "α",
  beta: "β",
  gamma: "γ",
  delta: "δ",
  epsilon: "ε",
  zeta: "ζ",
  eta: "η",
  theta: "θ",
  iota: "ι",
  kappa: "κ",
  lambda: "λ",
  mu: "μ",
  nu: "ν",
  xi: "ξ",
  omicron: "ο",
  pi: "π",
  rho: "ρ",
  sigmaf: "ς",
  sigma: "σ",
  tau: "τ",
  upsilon: "υ",
  phi: "φ",
  chi: "χ",
  psi: "ψ",
  omega: "ω",
  thetasym: "ϑ",
  upsih: "ϒ",
  piv: "ϖ",
  bull: "•",
  hellip: "…",
  prime: "′",
  Prime: "″",
  oline: "‾",
  frasl: "⁄",
  weierp: "℘",
  image: "ℑ",
  real: "ℜ",
  trade: "™",
  alefsym: "ℵ",
  larr: "←",
  uarr: "↑",
  rarr: "→",
  darr: "↓",
  harr: "↔",
  crarr: "↵",
  lArr: "⇐",
  uArr: "⇑",
  rArr: "⇒",
  dArr: "⇓",
  hArr: "⇔",
  forall: "∀",
  part: "∂",
  exist: "∃",
  empty: "∅",
  nabla: "∇",
  isin: "∈",
  notin: "∉",
  ni: "∋",
  prod: "∏",
  sum: "∑",
  minus: "−",
  lowast: "∗",
  radic: "√",
  prop: "∝",
  infin: "∞",
  ang: "∠",
  and: "∧",
  or: "∨",
  cap: "∩",
  cup: "∪",
  int: "∫",
  there4: "∴",
  sim: "∼",
  cong: "≅",
  asymp: "≈",
  ne: "≠",
  equiv: "≡",
  le: "≤",
  ge: "≥",
  sub: "⊂",
  sup: "⊃",
  nsub: "⊄",
  sube: "⊆",
  supe: "⊇",
  oplus: "⊕",
  otimes: "⊗",
  perp: "⊥",
  sdot: "⋅",
  lceil: "⌈",
  rceil: "⌉",
  lfloor: "⌊",
  rfloor: "⌋",
  lang: "〈",
  rang: "〉",
  loz: "◊",
  spades: "♠",
  clubs: "♣",
  hearts: "♥",
  diams: "♦",
  quot: '"',
  amp: "&",
  lt: "<",
  gt: ">",
  OElig: "Œ",
  oelig: "œ",
  Scaron: "Š",
  scaron: "š",
  Yuml: "Ÿ",
  circ: "ˆ",
  tilde: "˜",
  ensp: " ",
  emsp: " ",
  thinsp: " ",
  zwnj: "‌",
  zwj: "‍",
  lrm: "‎",
  rlm: "‏",
  ndash: "–",
  mdash: "—",
  lsquo: "‘",
  rsquo: "’",
  sbquo: "‚",
  ldquo: "“",
  rdquo: "”",
  bdquo: "„",
  dagger: "†",
  Dagger: "‡",
  permil: "‰",
  lsaquo: "‹",
  rsaquo: "›",
  euro: "€"
}, K = [
  "cent",
  "copy",
  "divide",
  "gt",
  "lt",
  "not",
  "para",
  "times"
], w = {}.hasOwnProperty, h = {};
let g;
for (g in p)
  w.call(p, g) && (h[p[g]] = g);
const Q = /[^\dA-Za-z]/;
function V(n, a, t, e) {
  const r = String.fromCharCode(n);
  if (w.call(h, r)) {
    const s = h[r], o = "&" + s;
    return t && Z.includes(s) && !K.includes(s) && (!e || a && a !== 61 && Q.test(String.fromCharCode(a))) ? o : o + ";";
  }
  return "";
}
function W(n, a, t) {
  let e = Y(n, a, t.omitOptionalSemicolons), r;
  if ((t.useNamedReferences || t.useShortestReferences) && (r = V(
    n,
    a,
    t.omitOptionalSemicolons,
    t.attribute
  )), (t.useShortestReferences || !r) && t.useShortestReferences) {
    const s = M(n, a, t.omitOptionalSemicolons);
    s.length < e.length && (e = s);
  }
  return r && (!t.useShortestReferences || r.length < e.length) ? r : e;
}
function u(n, a) {
  return H(n, Object.assign({ format: W }, a));
}
const X = /^>|^->|<!--|-->|--!>|<!-$/g, J = [">"], ee = ["<", ">"];
function te(n, a, t, e) {
  return e.settings.bogusComments ? "<?" + u(
    n.value,
    Object.assign({}, e.settings.characterReferences, {
      subset: J
    })
  ) + ">" : "<!--" + n.value.replace(X, r) + "-->";
  function r(s) {
    return u(
      s,
      Object.assign({}, e.settings.characterReferences, {
        subset: ee
      })
    );
  }
}
function ae(n, a, t, e) {
  return "<!" + (e.settings.upperDoctype ? "DOCTYPE" : "doctype") + (e.settings.tightDoctype ? "" : " ") + "html>";
}
const c = v(1), S = v(-1), ne = [];
function v(n) {
  return a;
  function a(t, e, r) {
    const s = t ? t.children : ne;
    let o = (e || 0) + n, i = s[o];
    if (!r)
      for (; i && y(i); )
        o += n, i = s[o];
    return i;
  }
}
const re = {}.hasOwnProperty;
function q(n) {
  return a;
  function a(t, e, r) {
    return re.call(n, t.tagName) && n[t.tagName](t, e, r);
  }
}
const N = q({
  body: oe,
  caption: d,
  colgroup: d,
  dd: ue,
  dt: le,
  head: d,
  html: se,
  li: ce,
  optgroup: me,
  option: ge,
  p: ie,
  rp: A,
  rt: A,
  tbody: pe,
  td: E,
  tfoot: de,
  th: E,
  thead: fe,
  tr: he
});
function d(n, a, t) {
  const e = c(t, a, !0);
  return !e || e.type !== "comment" && !(e.type === "text" && y(e.value.charAt(0)));
}
function se(n, a, t) {
  const e = c(t, a);
  return !e || e.type !== "comment";
}
function oe(n, a, t) {
  const e = c(t, a);
  return !e || e.type !== "comment";
}
function ie(n, a, t) {
  const e = c(t, a);
  return e ? e.type === "element" && (e.tagName === "address" || e.tagName === "article" || e.tagName === "aside" || e.tagName === "blockquote" || e.tagName === "details" || e.tagName === "div" || e.tagName === "dl" || e.tagName === "fieldset" || e.tagName === "figcaption" || e.tagName === "figure" || e.tagName === "footer" || e.tagName === "form" || e.tagName === "h1" || e.tagName === "h2" || e.tagName === "h3" || e.tagName === "h4" || e.tagName === "h5" || e.tagName === "h6" || e.tagName === "header" || e.tagName === "hgroup" || e.tagName === "hr" || e.tagName === "main" || e.tagName === "menu" || e.tagName === "nav" || e.tagName === "ol" || e.tagName === "p" || e.tagName === "pre" || e.tagName === "section" || e.tagName === "table" || e.tagName === "ul") : !t || // Confusing parent.
  !(t.type === "element" && (t.tagName === "a" || t.tagName === "audio" || t.tagName === "del" || t.tagName === "ins" || t.tagName === "map" || t.tagName === "noscript" || t.tagName === "video"));
}
function ce(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && e.tagName === "li";
}
function le(n, a, t) {
  const e = c(t, a);
  return !!(e && e.type === "element" && (e.tagName === "dt" || e.tagName === "dd"));
}
function ue(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && (e.tagName === "dt" || e.tagName === "dd");
}
function A(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && (e.tagName === "rp" || e.tagName === "rt");
}
function me(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && e.tagName === "optgroup";
}
function ge(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && (e.tagName === "option" || e.tagName === "optgroup");
}
function fe(n, a, t) {
  const e = c(t, a);
  return !!(e && e.type === "element" && (e.tagName === "tbody" || e.tagName === "tfoot"));
}
function pe(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && (e.tagName === "tbody" || e.tagName === "tfoot");
}
function de(n, a, t) {
  return !c(t, a);
}
function he(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && e.tagName === "tr";
}
function E(n, a, t) {
  const e = c(t, a);
  return !e || e.type === "element" && (e.tagName === "td" || e.tagName === "th");
}
const ye = q({
  body: xe,
  colgroup: Ce,
  head: be,
  html: Ne,
  tbody: Ae
});
function Ne(n) {
  const a = c(n, -1);
  return !a || a.type !== "comment";
}
function be(n) {
  const a = /* @__PURE__ */ new Set();
  for (const e of n.children)
    if (e.type === "element" && (e.tagName === "base" || e.tagName === "title")) {
      if (a.has(e.tagName)) return !1;
      a.add(e.tagName);
    }
  const t = n.children[0];
  return !t || t.type === "element";
}
function xe(n) {
  const a = c(n, -1, !0);
  return !a || a.type !== "comment" && !(a.type === "text" && y(a.value.charAt(0))) && !(a.type === "element" && (a.tagName === "meta" || a.tagName === "link" || a.tagName === "script" || a.tagName === "style" || a.tagName === "template"));
}
function Ce(n, a, t) {
  const e = S(t, a), r = c(n, -1, !0);
  return t && e && e.type === "element" && e.tagName === "colgroup" && N(e, t.children.indexOf(e), t) ? !1 : !!(r && r.type === "element" && r.tagName === "col");
}
function Ae(n, a, t) {
  const e = S(t, a), r = c(n, -1);
  return t && e && e.type === "element" && (e.tagName === "thead" || e.tagName === "tbody") && N(e, t.children.indexOf(e), t) ? !1 : !!(r && r.type === "element" && r.tagName === "tr");
}
const f = {
  // See: <https://html.spec.whatwg.org/#attribute-name-state>.
  name: [
    [`	
\f\r &/=>`.split(""), `	
\f\r "&'/=>\``.split("")],
    [`\0	
\f\r "&'/<=>`.split(""), `\0	
\f\r "&'/<=>\``.split("")]
  ],
  // See: <https://html.spec.whatwg.org/#attribute-value-(unquoted)-state>.
  unquoted: [
    [`	
\f\r &>`.split(""), `\0	
\f\r "&'<=>\``.split("")],
    [`\0	
\f\r "&'<=>\``.split(""), `\0	
\f\r "&'<=>\``.split("")]
  ],
  // See: <https://html.spec.whatwg.org/#attribute-value-(single-quoted)-state>.
  single: [
    ["&'".split(""), "\"&'`".split("")],
    ["\0&'".split(""), "\0\"&'`".split("")]
  ],
  // See: <https://html.spec.whatwg.org/#attribute-value-(double-quoted)-state>.
  double: [
    ['"&'.split(""), "\"&'`".split("")],
    ['\0"&'.split(""), "\0\"&'`".split("")]
  ]
};
function Ee(n, a, t, e) {
  const r = e.schema, s = r.space === "svg" ? !1 : e.settings.omitOptionalTags;
  let o = r.space === "svg" ? e.settings.closeEmptyElements : e.settings.voids.includes(n.tagName.toLowerCase());
  const i = [];
  let l;
  r.space === "html" && n.tagName === "svg" && (e.schema = O);
  const m = Oe(e, n.properties), b = e.all(
    r.space === "html" && n.tagName === "template" ? n.content : n
  );
  return e.schema = r, b && (o = !1), (m || !s || !ye(n, a, t)) && (i.push("<", n.tagName, m ? " " + m : ""), o && (r.space === "svg" || e.settings.closeSelfClosing) && (l = m.charAt(m.length - 1), (!e.settings.tightSelfClosing || l === "/" || l && l !== '"' && l !== "'") && i.push(" "), i.push("/")), i.push(">")), i.push(b), !o && (!s || !N(n, a, t)) && i.push("</" + n.tagName + ">"), i.join("");
}
function Oe(n, a) {
  const t = [];
  let e = -1, r;
  if (a) {
    for (r in a)
      if (a[r] !== null && a[r] !== void 0) {
        const s = we(n, r, a[r]);
        s && t.push(s);
      }
  }
  for (; ++e < t.length; ) {
    const s = n.settings.tightAttributes ? t[e].charAt(t[e].length - 1) : void 0;
    e !== t.length - 1 && s !== '"' && s !== "'" && (t[e] += " ");
  }
  return t.join("");
}
function we(n, a, t) {
  const e = _(n.schema, a), r = n.settings.allowParseErrors && n.schema.space === "html" ? 0 : 1, s = n.settings.allowDangerousCharacters ? 0 : 1;
  let o = n.quote, i;
  if (e.overloadedBoolean && (t === e.attribute || t === "") ? t = !0 : (e.boolean || e.overloadedBoolean) && (typeof t != "string" || t === e.attribute || t === "") && (t = !!t), t == null || t === !1 || typeof t == "number" && Number.isNaN(t))
    return "";
  const l = u(
    e.attribute,
    Object.assign({}, n.settings.characterReferences, {
      // Always encode without parse errors in non-HTML.
      subset: f.name[r][s]
    })
  );
  return t === !0 || (t = Array.isArray(t) ? (e.commaSeparated ? D : T)(t, {
    padLeft: !n.settings.tightCommaSeparatedLists
  }) : String(t), n.settings.collapseEmptyAttributes && !t) ? l : (n.settings.preferUnquoted && (i = u(
    t,
    Object.assign({}, n.settings.characterReferences, {
      attribute: !0,
      subset: f.unquoted[r][s]
    })
  )), i !== t && (n.settings.quoteSmart && x(t, o) > x(t, n.alternative) && (o = n.alternative), i = o + u(
    t,
    Object.assign({}, n.settings.characterReferences, {
      // Always encode without parse errors in non-HTML.
      subset: (o === "'" ? f.single : f.double)[r][s],
      attribute: !0
    })
  ) + o), l + (i && "=" + i));
}
const Se = ["<", "&"];
function R(n, a, t, e) {
  return t && t.type === "element" && (t.tagName === "script" || t.tagName === "style") ? n.value : u(
    n.value,
    Object.assign({}, e.settings.characterReferences, {
      subset: Se
    })
  );
}
function ve(n, a, t, e) {
  return e.settings.allowDangerousHtml ? n.value : R(n, a, t, e);
}
function qe(n, a, t, e) {
  return e.all(n);
}
const Re = j("type", {
  invalid: _e,
  unknown: De,
  handlers: { comment: te, doctype: ae, element: Ee, raw: ve, root: qe, text: R }
});
function _e(n) {
  throw new Error("Expected node, not `" + n + "`");
}
function De(n) {
  const a = (
    /** @type {Nodes} */
    n
  );
  throw new Error("Cannot compile unknown node `" + a.type + "`");
}
const Te = {}, Ue = {}, je = [];
function Fe(n, a) {
  const t = a || Te, e = t.quote || '"', r = e === '"' ? "'" : '"';
  if (e !== '"' && e !== "'")
    throw new Error("Invalid quote `" + e + "`, expected `'` or `\"`");
  return {
    one: Pe,
    all: ke,
    settings: {
      omitOptionalTags: t.omitOptionalTags || !1,
      allowParseErrors: t.allowParseErrors || !1,
      allowDangerousCharacters: t.allowDangerousCharacters || !1,
      quoteSmart: t.quoteSmart || !1,
      preferUnquoted: t.preferUnquoted || !1,
      tightAttributes: t.tightAttributes || !1,
      upperDoctype: t.upperDoctype || !1,
      tightDoctype: t.tightDoctype || !1,
      bogusComments: t.bogusComments || !1,
      tightCommaSeparatedLists: t.tightCommaSeparatedLists || !1,
      tightSelfClosing: t.tightSelfClosing || !1,
      collapseEmptyAttributes: t.collapseEmptyAttributes || !1,
      allowDangerousHtml: t.allowDangerousHtml || !1,
      voids: t.voids || F,
      characterReferences: t.characterReferences || Ue,
      closeSelfClosing: t.closeSelfClosing || !1,
      closeEmptyElements: t.closeEmptyElements || !1
    },
    schema: t.space === "svg" ? O : U,
    quote: e,
    alternative: r
  }.one(
    Array.isArray(n) ? { type: "root", children: n } : n,
    void 0,
    void 0
  );
}
function Pe(n, a, t) {
  return Re(n, a, t, this);
}
function ke(n) {
  const a = [], t = n && n.children || je;
  let e = -1;
  for (; ++e < t.length; )
    a[e] = this.one(t[e], e, n);
  return a.join("");
}
function $e(n) {
  const a = this, t = { ...a.data("settings"), ...n };
  a.compiler = e;
  function e(r) {
    return Fe(r, t);
  }
}
export {
  $e as default
};
