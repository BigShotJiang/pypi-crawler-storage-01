const T = typeof self == "object" ? self : globalThis, O = (s, c) => {
  const n = (r, u) => (s.set(u, r), r), i = (r) => {
    if (s.has(r))
      return s.get(r);
    const [u, t] = c[r];
    switch (u) {
      case 0:
      case -1:
        return n(t, r);
      case 1: {
        const e = n([], r);
        for (const o of t)
          e.push(i(o));
        return e;
      }
      case 2: {
        const e = n({}, r);
        for (const [o, R] of t)
          e[i(o)] = i(R);
        return e;
      }
      case 3:
        return n(new Date(t), r);
      case 4: {
        const { source: e, flags: o } = t;
        return n(new RegExp(e, o), r);
      }
      case 5: {
        const e = n(/* @__PURE__ */ new Map(), r);
        for (const [o, R] of t)
          e.set(i(o), i(R));
        return e;
      }
      case 6: {
        const e = n(/* @__PURE__ */ new Set(), r);
        for (const o of t)
          e.add(i(o));
        return e;
      }
      case 7: {
        const { name: e, message: o } = t;
        return n(new T[e](o), r);
      }
      case 8:
        return n(BigInt(t), r);
      case "BigInt":
        return n(Object(BigInt(t)), r);
      case "ArrayBuffer":
        return n(new Uint8Array(t).buffer, t);
      case "DataView": {
        const { buffer: e } = new Uint8Array(t);
        return n(new DataView(e), t);
      }
    }
    return n(new T[u](t), r);
  };
  return i;
}, w = (s) => O(/* @__PURE__ */ new Map(), s)(0), p = "", { toString: S } = {}, { keys: h } = Object, y = (s) => {
  const c = typeof s;
  if (c !== "object" || !s)
    return [0, c];
  const n = S.call(s).slice(8, -1);
  switch (n) {
    case "Array":
      return [1, p];
    case "Object":
      return [2, p];
    case "Date":
      return [3, p];
    case "RegExp":
      return [4, p];
    case "Map":
      return [5, p];
    case "Set":
      return [6, p];
    case "DataView":
      return [1, n];
  }
  return n.includes("Array") ? [1, n] : n.includes("Error") ? [7, n] : [2, n];
}, I = ([s, c]) => s === 0 && (c === "function" || c === "symbol"), m = (s, c, n, i) => {
  const r = (t, e) => {
    const o = i.push(t) - 1;
    return n.set(e, o), o;
  }, u = (t) => {
    if (n.has(t))
      return n.get(t);
    let [e, o] = y(t);
    switch (e) {
      case 0: {
        let f = t;
        switch (o) {
          case "bigint":
            e = 8, f = t.toString();
            break;
          case "function":
          case "symbol":
            if (s)
              throw new TypeError("unable to serialize " + o);
            f = null;
            break;
          case "undefined":
            return r([-1], t);
        }
        return r([e, f], t);
      }
      case 1: {
        if (o) {
          let a = t;
          return o === "DataView" ? a = new Uint8Array(t.buffer) : o === "ArrayBuffer" && (a = new Uint8Array(t)), r([o, [...a]], t);
        }
        const f = [], E = r([e, f], t);
        for (const a of t)
          f.push(u(a));
        return E;
      }
      case 2: {
        if (o)
          switch (o) {
            case "BigInt":
              return r([o, t.toString()], t);
            case "Boolean":
            case "Number":
            case "String":
              return r([o, t.valueOf()], t);
          }
        if (c && "toJSON" in t)
          return u(t.toJSON());
        const f = [], E = r([e, f], t);
        for (const a of h(t))
          (s || !I(y(t[a]))) && f.push([u(a), u(t[a])]);
        return E;
      }
      case 3:
        return r([e, t.toISOString()], t);
      case 4: {
        const { source: f, flags: E } = t;
        return r([e, { source: f, flags: E }], t);
      }
      case 5: {
        const f = [], E = r([e, f], t);
        for (const [a, A] of t)
          (s || !(I(y(a)) || I(y(A)))) && f.push([u(a), u(A)]);
        return E;
      }
      case 6: {
        const f = [], E = r([e, f], t);
        for (const a of t)
          (s || !I(y(a))) && f.push(u(a));
        return E;
      }
    }
    const { message: R } = t;
    return r([e, { name: o, message: R }], t);
  };
  return u;
}, b = (s, { json: c, lossy: n } = {}) => {
  const i = [];
  return m(!(c || n), !!c, /* @__PURE__ */ new Map(), i)(s), i;
}, M = typeof structuredClone == "function" ? (
  /* c8 ignore start */
  (s, c) => c && ("json" in c || "lossy" in c) ? w(b(s, c)) : structuredClone(s)
) : (s, c) => w(b(s, c)), B = g("end"), P = g("start");
function g(s) {
  return c;
  function c(n) {
    const i = n && n.position && n.position[s] || {};
    if (typeof i.line == "number" && i.line > 0 && typeof i.column == "number" && i.column > 0)
      return {
        line: i.line,
        column: i.column,
        offset: typeof i.offset == "number" && i.offset > -1 ? i.offset : void 0
      };
  }
}
function D(s) {
  const c = P(s), n = B(s);
  if (c && n)
    return { start: c, end: n };
}
export {
  B as a,
  D as b,
  P as p,
  M as s
};
