import { m as g, e as y, p as v } from "./index-CqUzoIk5.js";
import { v as b, S as k } from "./index-DPVDNjDQ.js";
import { w as u } from "./index-qIqGBAea.js";
const x = [
  "pre",
  "script",
  "style",
  "textarea"
], N = {};
function w(r, t) {
  const p = t || N, i = {
    blanks: p.blanks || [],
    head: !1,
    indentInitial: p.indentInitial !== !1,
    indent: typeof p.indent == "number" ? " ".repeat(p.indent) : typeof p.indent == "string" ? p.indent : "  "
  };
  g(r, { newlines: !0 }), b(r, d);
  function d(e, c) {
    if (!("children" in e))
      return;
    if (e.type === "element" && e.tagName === "head" && (i.head = !0), i.head && e.type === "element" && e.tagName === "body" && (i.head = !1), e.type === "element" && x.includes(e.tagName))
      return k;
    if (e.children.length === 0 || !h(i, e))
      return;
    let f = c.length;
    i.indentInitial || f--;
    let n = !1;
    for (const l of e.children)
      (l.type === "comment" || l.type === "text") && (l.value.includes(`
`) && (n = !0), l.value = l.value.replace(
        / *\n/g,
        "$&" + i.indent.repeat(f)
      ));
    const s = [];
    let a;
    for (const l of e.children)
      (h(i, l) || n && !a) && (m(s, f, l), n = !0), a = l, s.push(l);
    a && (n || h(i, a)) && (u(a) && (s.pop(), a = s[s.length - 1]), m(s, f - 1)), e.children = s;
  }
  function m(e, c, f) {
    const n = e[e.length - 1], s = n && u(n) ? e[e.length - 2] : n, a = (o(i, s) && o(i, f) ? `

` : `
`) + i.indent.repeat(Math.max(c, 0));
    n && n.type === "text" ? n.value = u(n) ? a : n.value + a : e.push({ type: "text", value: a });
  }
}
function o(r, t) {
  return !!(t && t.type === "element" && r.blanks.length > 0 && r.blanks.includes(t.tagName));
}
function h(r, t) {
  return t.type === "root" || (t.type === "element" ? r.head || t.tagName === "script" || y(t) || !v(t) : !1);
}
function P(r) {
  return function(t) {
    w(t, r);
  };
}
export {
  P as default
};
