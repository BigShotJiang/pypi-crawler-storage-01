import { I as f } from "./Index-Bo5_uwJz.js";
export {
  f as default
};
