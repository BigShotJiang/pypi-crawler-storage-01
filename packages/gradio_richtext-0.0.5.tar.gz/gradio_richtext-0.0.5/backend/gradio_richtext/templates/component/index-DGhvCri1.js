import { f as A, p, a as y, n as d, h as w, s as j } from "./index-XASQ8rxc.js";
const h = /[#.]/g;
function x(r, e) {
  const n = r || "", t = {};
  let s = 0, o, f;
  for (; s < n.length; ) {
    h.lastIndex = s;
    const a = h.exec(n), i = n.slice(s, a ? a.index : n.length);
    i && (o ? o === "#" ? t.id = i : Array.isArray(t.className) ? t.className.push(i) : t.className = [i] : f = i, s += i.length), a && (o = a[0], s++);
  }
  return {
    type: "element",
    // @ts-expect-error: tag name is parsed.
    tagName: f || e || "div",
    properties: t,
    children: []
  };
}
function g(r, e, n) {
  const t = n ? G(n) : void 0;
  function s(o, f, ...a) {
    let i;
    if (o == null) {
      i = { type: "root", children: [] };
      const c = (
        /** @type {Child} */
        f
      );
      a.unshift(c);
    } else {
      i = x(o, e);
      const c = i.tagName.toLowerCase(), u = t ? t.get(c) : void 0;
      if (i.tagName = u || c, C(f))
        a.unshift(f);
      else
        for (const [N, b] of Object.entries(f))
          S(r, i.properties, N, b);
    }
    for (const c of a)
      l(i.children, c);
    return i.type === "element" && i.tagName === "template" && (i.content = { type: "root", children: i.children }, i.children = []), i;
  }
  return s;
}
function C(r) {
  if (r === null || typeof r != "object" || Array.isArray(r))
    return !0;
  if (typeof r.type != "string") return !1;
  const e = (
    /** @type {Record<string, unknown>} */
    r
  ), n = Object.keys(r);
  for (const t of n) {
    const s = e[t];
    if (s && typeof s == "object") {
      if (!Array.isArray(s)) return !0;
      const o = (
        /** @type {ReadonlyArray<unknown>} */
        s
      );
      for (const f of o)
        if (typeof f != "number" && typeof f != "string")
          return !0;
    }
  }
  return !!("children" in r && Array.isArray(r.children));
}
function S(r, e, n, t) {
  const s = A(r, n);
  let o;
  if (t != null) {
    if (typeof t == "number") {
      if (Number.isNaN(t)) return;
      o = t;
    } else typeof t == "boolean" ? o = t : typeof t == "string" ? s.spaceSeparated ? o = p(t) : s.commaSeparated ? o = y(t) : s.commaOrSpaceSeparated ? o = p(y(t).join(" ")) : o = m(s, s.property, t) : Array.isArray(t) ? o = [...t] : o = s.property === "style" ? M(t) : String(t);
    if (Array.isArray(o)) {
      const f = [];
      for (const a of o)
        f.push(
          /** @type {number | string} */
          m(s, s.property, a)
        );
      o = f;
    }
    s.property === "className" && Array.isArray(e.className) && (o = e.className.concat(
      /** @type {Array<number | string> | number | string} */
      o
    )), e[s.property] = o;
  }
}
function l(r, e) {
  if (e != null) if (typeof e == "number" || typeof e == "string")
    r.push({ type: "text", value: String(e) });
  else if (Array.isArray(e))
    for (const n of e)
      l(r, n);
  else if (typeof e == "object" && "type" in e)
    e.type === "root" ? l(r, e.children) : r.push(e);
  else
    throw new Error("Expected node, nodes, or string, got `" + e + "`");
}
function m(r, e, n) {
  if (typeof n == "string") {
    if (r.number && n && !Number.isNaN(Number(n)))
      return Number(n);
    if ((r.boolean || r.overloadedBoolean) && (n === "" || d(n) === d(e)))
      return !0;
  }
  return n;
}
function M(r) {
  const e = [];
  for (const [n, t] of Object.entries(r))
    e.push([n, t].join(": "));
  return e.join("; ");
}
function G(r) {
  const e = /* @__PURE__ */ new Map();
  for (const n of r)
    e.set(n.toLowerCase(), n);
  return e;
}
const L = [
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feDropShadow",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "solidColor",
  "textArea",
  "textPath"
], k = g(w, "div"), D = g(j, "g", L), F = {
  html: "http://www.w3.org/1999/xhtml",
  svg: "http://www.w3.org/2000/svg"
};
export {
  k as h,
  D as s,
  F as w
};
