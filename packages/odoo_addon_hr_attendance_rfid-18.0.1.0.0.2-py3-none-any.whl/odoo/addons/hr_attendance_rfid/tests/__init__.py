from . import test_hr_attendance_rfid_process
