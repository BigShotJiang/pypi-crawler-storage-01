This module extends the functionality of HR Attendance in order to allow
the logging of employee attendances using an RFID based employee
attendance system.
