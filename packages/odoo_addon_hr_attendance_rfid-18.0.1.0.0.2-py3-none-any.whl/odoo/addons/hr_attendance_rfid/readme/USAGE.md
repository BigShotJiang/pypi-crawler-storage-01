1.  The HR employee responsible to set up new employees should go to
    'Attendances -\> Manage Attendances -\> Employees' and register the
    RFID card code of each of your employees. You can use an USB plugged
    RFID reader connected to your computer for this purpose.
2.  The employee should put his/her card to the RFID based employee
    attendance system. It is expected that the system will provide some
    form of output of the registration event.
