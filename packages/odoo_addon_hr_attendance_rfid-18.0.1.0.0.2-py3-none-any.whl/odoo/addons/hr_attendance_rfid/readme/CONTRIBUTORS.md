- Omar Catiñeira Saavedra \<<omar@comunitea.com>\>

- Héctor Villarreal Ortega \<<hector.villarreal@forgeflow.com>\>

- Jordi Ballester Alomar \<<jordi.ballester@forgeflow.com>\>

- Brian McMaster \<<brian@mcmpest.com>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Víctor Martínez
  > - David Bañón Gil


- Juany Davila \<<juany.davila@forgeflow.com>\>
