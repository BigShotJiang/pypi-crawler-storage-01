#
#
#
from python_byzatic_commons.singleton.Singleton import Singleton

__all__ = [
    'Singleton'
]
