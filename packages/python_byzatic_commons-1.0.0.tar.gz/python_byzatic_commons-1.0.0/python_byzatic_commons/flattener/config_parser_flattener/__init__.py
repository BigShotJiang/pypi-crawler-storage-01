#
#
#

# interfaces
from python_byzatic_commons.flattener.config_parser_flattener.ConfigParserFlattener import ConfigParserFlattener

__all__ = [
    'ConfigParserFlattener'
]
