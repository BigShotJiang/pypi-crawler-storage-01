"""
Issues plugin for yaapp framework.
Provides comprehensive issue management with review workflows.
"""