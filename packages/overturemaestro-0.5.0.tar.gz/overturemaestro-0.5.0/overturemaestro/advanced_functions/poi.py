"""Functions for retrieving Overture Maps places data."""
