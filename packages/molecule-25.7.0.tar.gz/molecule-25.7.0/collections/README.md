These collections are here for ansible-lint so the ansible-lint pre-commit action can install them prior to linting the repository.
