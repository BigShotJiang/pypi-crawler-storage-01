from pathlib import Path

serve_path = str(Path(__file__).parent.resolve())
serve = {"__pan3d_css": serve_path}
