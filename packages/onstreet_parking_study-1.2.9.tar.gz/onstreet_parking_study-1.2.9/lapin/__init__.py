""" Init LAPIN """

from lapin.configs.user_conf import UserConfig

__all__ = ["UserConfig"]

__version__ = "1.2.4"
