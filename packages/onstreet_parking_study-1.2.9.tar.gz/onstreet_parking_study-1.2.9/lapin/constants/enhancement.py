# Columns
## Enhancer
SEGMENT = 'segment'
POINT_ON_STREET = 'point_on_segment_s'
SIDE_OF_STREET = 'side_of_street'
SIDE_OF_STREET_VIZ = 'side_of_street_viz'
LAP = 'lap'
LAP_TIME = 'lap_time'
LAT_SMOOTH = 'lat_s'
LNG_SMOOTH = 'lng_s'
