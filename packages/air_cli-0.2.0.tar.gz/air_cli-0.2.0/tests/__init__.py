"""Unit test package for air_cli."""
