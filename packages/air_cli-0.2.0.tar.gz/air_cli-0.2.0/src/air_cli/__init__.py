"""Top-level package for air-cli."""

__author__ = """Audrey M. Roy Greenfeld"""
__email__ = "audrey@feldroy.com"
