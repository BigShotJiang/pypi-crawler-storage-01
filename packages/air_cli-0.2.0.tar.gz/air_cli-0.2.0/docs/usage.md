# Usage

To use air-cli in a project:

```python
import air_cli
```
