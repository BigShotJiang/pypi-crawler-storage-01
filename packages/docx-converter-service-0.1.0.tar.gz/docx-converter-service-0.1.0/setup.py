from setuptools import setup, find_packages

setup(
    name='docx-converter-service',
    version='0.1.0',
    description='文本到DOCX转换服务',
    author='meteor-shower-l',
    author_email='1637624038@qq.com',
    packages=find_packages(),
    install_requires=[
        'flask==2.3.2',
        'requests==2.31.0',
        'python-docx==0.8.11'
    ],
    entry_points={
        'console_scripts': [
            'start-docx-service = src.main:app'
        ]
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)