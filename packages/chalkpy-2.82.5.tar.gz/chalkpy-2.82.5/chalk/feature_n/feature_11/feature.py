# AUTO-GENERATED FILE.
# Re-run /chalk/feature_n/codegen.py to regenerate contents.
from typing import TypeVar, Generic, Optional, Dict
from chalk.features.dataframe import DataFrameMeta


T1 = TypeVar("T1")
T2 = TypeVar("T2")
T3 = TypeVar("T3")
T4 = TypeVar("T4")
T5 = TypeVar("T5")
T6 = TypeVar("T6")
T7 = TypeVar("T7")
T8 = TypeVar("T8")
T9 = TypeVar("T9")
T10 = TypeVar("T10")
T11 = TypeVar("T11")


class Features(Generic[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11]):
    pass


class DataFrame(Generic[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11], metaclass=DataFrameMeta):
    def __getitem__(self, item):
        pass
