# This file makes the static directory a Python package for
# importlib.resources compatibility
