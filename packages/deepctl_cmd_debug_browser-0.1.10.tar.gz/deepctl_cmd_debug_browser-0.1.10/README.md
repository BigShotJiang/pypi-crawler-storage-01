# deepctl-cmd-debug-browser

Browser debug subcommand for the Deepgram CLI (deepctl). This package provides the `browser` subcommand under the `debug` command group, allowing users to debug browser-related issues when using Deepgram's web-based features
