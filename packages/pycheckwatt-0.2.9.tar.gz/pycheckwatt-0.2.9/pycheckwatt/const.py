"""Docstring."""

SENSOR = "SENSOR"


class Device:
    """Docstring."""

    def __init__(self, name, device_type) -> None:
        """Docstring."""
        self.name = name
        self.type = device_type
