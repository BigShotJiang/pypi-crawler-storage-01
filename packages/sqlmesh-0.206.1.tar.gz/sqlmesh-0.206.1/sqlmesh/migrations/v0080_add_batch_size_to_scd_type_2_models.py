"""Add batch_size to SCD Type 2 models and add updated_at_name to by time which changes their data hash."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
