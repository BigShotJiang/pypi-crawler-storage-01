"""Module to hold the SubscriptionIntent resource."""

from fintoc.mixins import ResourceMixin


class SubscriptionIntent(ResourceMixin):
    """Represents a Fintoc Subscription Intent."""
