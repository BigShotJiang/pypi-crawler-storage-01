"""Module to hold the Transfer resource."""

from fintoc.mixins import ResourceMixin


class Transfer(ResourceMixin):
    """Represents a Fintoc Transfer."""
