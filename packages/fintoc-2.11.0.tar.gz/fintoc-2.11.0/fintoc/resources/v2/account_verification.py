"""Module to hold the AccountNumber resource."""

from fintoc.mixins import ResourceMixin


class AccountVerification(ResourceMixin):
    """Represents a Fintoc AccountVerification."""
