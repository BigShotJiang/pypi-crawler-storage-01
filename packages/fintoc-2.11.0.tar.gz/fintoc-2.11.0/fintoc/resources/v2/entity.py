"""Module to hold the Entity resource."""

from fintoc.mixins import ResourceMixin


class Entity(ResourceMixin):
    """Represents a Fintoc Entity."""
