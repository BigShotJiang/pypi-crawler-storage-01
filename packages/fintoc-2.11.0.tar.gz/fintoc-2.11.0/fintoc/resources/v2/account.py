"""Module to hold the Account resource."""

from fintoc.mixins import ResourceMixin


class Account(ResourceMixin):
    """Represents a Fintoc Account."""
