"""Module to hold the InstitutionTaxReturn resource."""

from fintoc.mixins import ResourceMixin


class InstitutionTaxReturn(ResourceMixin):
    """Represents a Fintoc Institution Tax Return."""
