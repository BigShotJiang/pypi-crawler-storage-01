"""Module to hold the Charge resource."""

from fintoc.mixins import ResourceMixin


class Charge(ResourceMixin):
    """Represents a Fintoc Charge."""
