"""Module to hold the InstitutionInvoice resource."""

from fintoc.mixins import ResourceMixin


class InstitutionInvoice(ResourceMixin):
    """Represents a Fintoc Institution Invoice."""
