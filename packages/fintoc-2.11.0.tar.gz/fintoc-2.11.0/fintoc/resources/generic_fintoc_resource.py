"""Module to hold a generic resource."""

from fintoc.mixins import ResourceMixin


class GenericFintocResource(ResourceMixin):
    """Represents a Generic Fintoc Resource."""
