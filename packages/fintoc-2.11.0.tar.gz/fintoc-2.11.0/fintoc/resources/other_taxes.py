"""Module to hold the OtherTaxes resource."""

from fintoc.mixins import ResourceMixin


class OtherTaxes(ResourceMixin):
    """Represents a Fintoc Other Taxes."""
