"""Module to hold the RefreshIntent resource."""

from fintoc.mixins import ResourceMixin


class RefreshIntent(ResourceMixin):
    """Represents a Fintoc Refresh Intent."""
