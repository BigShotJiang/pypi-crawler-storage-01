"""Module to hold the Balance resource."""

from fintoc.mixins import ResourceMixin


class Balance(ResourceMixin):
    """Represents a Fintoc Balance."""
