def main():
    return 1


main()
