
from setuptools import setup

setup(package_data={'uwsgi-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed'], 'uwsgidecorators-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
