_instruments = ("llama-index-core >= 0.10.43",)
_supports_metrics = False
