#!/usr/bin/env python3
"""Entry point for running tiktok_ads_mcp as a module"""

from .main import cli
 
if __name__ == "__main__":
    cli() 