[![GitHub release; latest by date](https://img.shields.io/github/v/release/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/releases)
[![GitHub Release Date](https://img.shields.io/github/release-date/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/releases)
[![Test Status](https://img.shields.io/github/actions/workflow/status/SETI/rms-pdstable/run-tests.yml?branch=main)](https://github.com/SETI/rms-pdstable/actions)
[![Code coverage](https://img.shields.io/codecov/c/github/SETI/rms-pdstable/main?logo=codecov)](https://codecov.io/gh/SETI/rms-pdstable)
<br />
[![PyPI - Version](https://img.shields.io/pypi/v/rms-pdstable)](https://pypi.org/project/rms-pdstable)
[![PyPI - Format](https://img.shields.io/pypi/format/rms-pdstable)](https://pypi.org/project/rms-pdstable)
[![PyPI - Downloads](https://img.shields.io/pypi/dm/rms-pdstable)](https://pypi.org/project/rms-pdstable)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/rms-pdstable)](https://pypi.org/project/rms-pdstable)
<br />
[![GitHub commits since latest release](https://img.shields.io/github/commits-since/SETI/rms-pdstable/latest)](https://github.com/SETI/rms-pdstable/commits/main/)
[![GitHub commit activity](https://img.shields.io/github/commit-activity/m/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/commits/main/)
[![GitHub last commit](https://img.shields.io/github/last-commit/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/commits/main/)
<br />
[![Number of GitHub open issues](https://img.shields.io/github/issues-raw/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/issues)
[![Number of GitHub closed issues](https://img.shields.io/github/issues-closed-raw/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/issues)
[![Number of GitHub open pull requests](https://img.shields.io/github/issues-pr-raw/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/pulls)
[![Number of GitHub closed pull requests](https://img.shields.io/github/issues-pr-closed-raw/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/pulls)
<br />
![GitHub License](https://img.shields.io/github/license/SETI/rms-pdstable)
[![Number of GitHub stars](https://img.shields.io/github/stars/SETI/rms-pdstable)](https://github.com/SETI/rms-pdstable/stargazers)
![GitHub forks](https://img.shields.io/github/forks/SETI/rms-pdstable)

# rms-pdstable

pdstable Python module
