"""cubicweb-rqlcontroller application package

restfull rql edition capabilities
"""
