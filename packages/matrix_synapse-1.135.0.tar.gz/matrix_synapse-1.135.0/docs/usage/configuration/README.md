# Configuration

This section contains information on tweaking Synapse via the various options in the configuration file. A configuration
file should have been generated when you [installed Synapse](../../setup/installation.html).
