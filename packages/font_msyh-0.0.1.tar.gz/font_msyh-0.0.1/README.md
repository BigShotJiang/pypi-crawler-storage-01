# font_msyh
Microsoft YaHei font file, version 0.75. This font has been repackaged for the Python Fonts module: https://pypi.org/project/fonts/ 
