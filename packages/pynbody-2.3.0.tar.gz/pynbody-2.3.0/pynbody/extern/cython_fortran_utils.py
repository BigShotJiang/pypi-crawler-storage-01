from . import _cython_fortran_utils

FortranFile = _cython_fortran_utils.FortranFile
