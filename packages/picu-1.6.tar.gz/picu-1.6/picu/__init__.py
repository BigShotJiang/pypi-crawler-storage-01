from picu.loader import icu_load, wide_unichr
