from .panopticml.panoptic_ml import PanopticML

plugin_class = PanopticML
