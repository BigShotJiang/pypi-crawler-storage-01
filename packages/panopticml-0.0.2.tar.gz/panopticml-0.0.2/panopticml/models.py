from enum import Enum


class VectorType(Enum):
    rgb = 'rgb'
    greyscale = 'greyscale'
