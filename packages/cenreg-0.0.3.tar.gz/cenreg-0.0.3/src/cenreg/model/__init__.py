from .cjd2F_np import cjd2surv

__all__ = ["cjd2surv"]
