-- Fetch database information
WITH ids AS (
    SELECT DISTINCT
        table_catalog,
        table_schema
    FROM {database}.information_schema.tables
)

SELECT
    d.database_id,
    database_name = i.table_catalog,
    schema_name = s.name,
    schema_id = CAST(d.database_id AS VARCHAR(10)) + '_' + CAST(s.schema_id AS VARCHAR(10)),
    schema_owner = u.name,
    schema_owner_id = u.uid
FROM {database}.sys.schemas AS s
INNER JOIN ids AS i
    ON s.name = i.table_schema
LEFT JOIN {database}.sys.sysusers AS u
    ON s.principal_id = u.uid
LEFT JOIN {database}.sys.databases AS d
    ON i.table_catalog = d.name
