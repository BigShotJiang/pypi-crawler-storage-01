SELECT
    created_on,
    deleted_on,
    name,
    comment
FROM snowflake.account_usage.roles
