NodeIDToNamesMapping = dict[str, set[str]]
