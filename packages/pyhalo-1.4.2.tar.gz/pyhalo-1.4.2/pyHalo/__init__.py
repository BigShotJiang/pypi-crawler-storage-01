# -*- coding: utf-8 -*-

"""Top-level package for pyHalo."""

__author__ = """Daniel Gilman"""
__email__ = 'daniel.gilman@utoronto.ca'
__version__ = '0.2.8'
