=====
Usage
=====

To use pyHalo in a project::

    import pyhalo
