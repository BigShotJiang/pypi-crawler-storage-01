def setup():
    print("loma")