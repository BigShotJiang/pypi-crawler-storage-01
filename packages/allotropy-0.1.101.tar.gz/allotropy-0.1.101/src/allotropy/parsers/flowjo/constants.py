DISPLAY_NAME = "FlowJo"
DEVICE_IDENTIFIER = "cytometer"
SOFTWARE_NAME = "FlowJo"
DEVICE_TYPE = "Flow Cytometer"
