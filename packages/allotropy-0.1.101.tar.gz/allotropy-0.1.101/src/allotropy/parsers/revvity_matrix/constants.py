DISPLAY_NAME = "Revvity Matrix"
DEVICE_TYPE = "cell counter"
