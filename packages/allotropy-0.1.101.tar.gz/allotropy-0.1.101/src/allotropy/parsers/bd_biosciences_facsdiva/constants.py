DISPLAY_NAME = "BD Biosciences FACSDiva"
DEVICE_IDENTIFIER = "cytometer"
SOFTWARE_NAME = "BD FACSDiva"
DEVICE_TYPE = "Flow Cytometer"
