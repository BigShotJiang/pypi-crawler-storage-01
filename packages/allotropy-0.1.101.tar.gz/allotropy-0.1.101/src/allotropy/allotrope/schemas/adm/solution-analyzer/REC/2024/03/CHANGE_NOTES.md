Base schema: http://purl.allotrope.org/json-schemas/adm/solution-analyzer/REC/2024/03/solution-analyzer.schema

Changes:

* Added "data system document" to "solution analyzer aggregate document"
  * Reasoning: Extension adopted in order to capture metadata about the originating computer system, software, file, and ASM conversion
  * Proposal: add "data system document" to ASM technique documents