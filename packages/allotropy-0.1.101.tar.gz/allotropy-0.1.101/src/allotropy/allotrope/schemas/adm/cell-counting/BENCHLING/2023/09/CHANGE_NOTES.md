DEPRECATED - DO NOT USE. This is replaced by cell-counting/BENCHLING/2023/11/cell-counting.json

Base schema: http://purl.allotrope.org/json-schemas/adm/cell-counting/REC/2023/09/cell-counting.schema
