# back trading bot

A Python package that decodes and executes base64 code from a remote source.
