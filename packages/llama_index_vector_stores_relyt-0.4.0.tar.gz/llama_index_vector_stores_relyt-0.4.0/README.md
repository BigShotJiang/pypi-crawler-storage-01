# LlamaIndex Vector_Stores Integration: Relyt
