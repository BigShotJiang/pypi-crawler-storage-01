from django.apps import AppConfig


class ModalHj3415Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'modal_hj3415'
