# __init__.py
from llama_index.tools.database.base import (
    DatabaseToolSpec,
)

__all__ = ["DatabaseToolSpec"]
