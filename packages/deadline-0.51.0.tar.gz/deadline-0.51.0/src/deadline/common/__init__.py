# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

"""
Common utilities for the Deadline Cloud project.
"""
