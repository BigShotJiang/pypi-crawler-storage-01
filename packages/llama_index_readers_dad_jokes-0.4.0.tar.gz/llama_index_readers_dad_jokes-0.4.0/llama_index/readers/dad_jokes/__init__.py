"""Init file."""

from llama_index.readers.dad_jokes.base import DadJokesReader

__all__ = ["DadJokesReader"]
