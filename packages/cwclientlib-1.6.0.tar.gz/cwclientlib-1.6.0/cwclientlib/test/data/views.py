#

from cubicweb_web.views.basecontrollers import ViewController


class TestController(ViewController):
    __regid__ = "test-controller"

    def publish(self, rset=None):
        return b"coucou"
