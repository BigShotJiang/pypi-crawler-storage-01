# Github mirror

This repository is a mirror that does not accept pull requests!
Please see contribution instructions at
<https://git.sr.ht/~gotmax23/tomcli/tree/main/item/CONTRIBUTING.md>.
