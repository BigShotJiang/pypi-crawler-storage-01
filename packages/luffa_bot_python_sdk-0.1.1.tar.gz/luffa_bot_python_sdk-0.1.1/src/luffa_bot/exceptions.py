class LuffaError(Exception):
    """Generic Luffa SDK error."""
    pass
