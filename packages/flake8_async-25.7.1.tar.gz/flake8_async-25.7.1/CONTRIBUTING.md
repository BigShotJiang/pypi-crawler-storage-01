The flake8-async contributor guide can be seen at https://flake8-async.readthedocs.io/en/latest/contributing.html
