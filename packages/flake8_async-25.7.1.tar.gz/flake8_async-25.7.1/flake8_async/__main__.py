"""Entry file when executed with `python -m`."""

import sys

from . import main

sys.exit(main())
