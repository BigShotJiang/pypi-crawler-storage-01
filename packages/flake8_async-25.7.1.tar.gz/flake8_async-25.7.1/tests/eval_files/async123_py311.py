try:
    ...
except* Exception as e:
    raise e.exceptions[0]  # error: 4
