The flake8-async changelog can now be seen at https://flake8-async.readthedocs.io/en/latest/changelog.html
