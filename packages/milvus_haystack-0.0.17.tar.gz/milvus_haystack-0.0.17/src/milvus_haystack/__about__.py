# SPDX-FileCopyrightText: 2023-present Tuana Celik <tuana.celik@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0
__version__ = "0.0.17"
