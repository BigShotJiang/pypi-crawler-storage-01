def hello():
    return f"Salut les gens 123 !"


def bye():
    return f"Bye-bye les gens !"


if __name__ == "__main__":
    print(hello(), "\n" + bye())
