from llama_index.indices.managed.dashscope.base import DashScopeCloudIndex
from llama_index.indices.managed.dashscope.retriever import DashScopeCloudRetriever


__all__ = ["DashScopeCloudIndex", "DashScopeCloudRetriever"]
