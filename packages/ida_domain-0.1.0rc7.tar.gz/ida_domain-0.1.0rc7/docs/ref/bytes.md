# `Bytes`

::: ida_domain.bytes
