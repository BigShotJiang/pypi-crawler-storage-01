# `Basic Blocks`

::: ida_domain.basic_blocks
