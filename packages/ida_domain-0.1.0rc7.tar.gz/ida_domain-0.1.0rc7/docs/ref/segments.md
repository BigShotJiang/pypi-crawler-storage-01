# `Segments`

::: ida_domain.segments
