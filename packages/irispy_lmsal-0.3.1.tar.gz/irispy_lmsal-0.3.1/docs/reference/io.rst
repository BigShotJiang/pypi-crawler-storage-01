****************
IO (`irispy.io`)
****************

The `irispy.io` module provides tools to read level 2 files.

.. automodapi:: irispy.io
