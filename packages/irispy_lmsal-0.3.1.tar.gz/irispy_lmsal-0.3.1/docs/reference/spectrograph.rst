************************************
Spectrograph (`irispy.spectrograph`)
************************************

The `irispy.spectrograph` module provides tools to read and work with level 2 spectrograph data.

.. automodapi:: irispy.spectrograph
    :inherited-members:
