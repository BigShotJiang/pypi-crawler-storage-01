**********
``irispy``
**********

The ``irispy-lmsal`` library provides tools to read and work with IRIS data.
The import for the library is just ``irispy`` and not ``irispy-lmsal``.

.. automodapi:: irispy
