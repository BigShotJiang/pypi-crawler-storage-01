******************
SJI (`irispy.sji`)
******************

The `irispy.sji` module provides tools to read and work with level 2 SJI data.

.. automodapi:: irispy.sji
    :inherited-members:
