**********************
utils (`irispy.utils`)
**********************

The `irispy.utils` module provides functions useful for development of ``irispy-lmsal``.

.. automodapi:: irispy.utils
