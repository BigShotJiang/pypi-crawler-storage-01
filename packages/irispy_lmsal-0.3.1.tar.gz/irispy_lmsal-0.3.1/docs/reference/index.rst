.. _api:

*************
API Reference
*************

.. toctree::
   :maxdepth: 2

   irispy
   sji
   spectrograph
   io
   utils
