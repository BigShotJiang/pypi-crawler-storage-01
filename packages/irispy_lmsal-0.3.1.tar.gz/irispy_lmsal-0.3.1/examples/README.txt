********
Examples
********

This gallery contains examples of how to use ``irispy-lmsal``.

Please be aware that the examples have lines of code which are designed to ensure that the plots or animations work within the online documentation.
These are not needed for use in notebooks or local scripts.