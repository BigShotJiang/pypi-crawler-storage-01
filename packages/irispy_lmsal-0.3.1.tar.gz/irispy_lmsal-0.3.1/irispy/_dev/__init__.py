"""
This subpackage contains utilities that are only used when developing muse in a
copy of the source repository.

These files are not installed, and should not be assumed to exist at
runtime.
"""
