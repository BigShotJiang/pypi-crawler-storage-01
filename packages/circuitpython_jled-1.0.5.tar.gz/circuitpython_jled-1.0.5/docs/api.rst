jled
====

.. py:currentmodule:: jled

.. autoclass:: JLed
    :members:
.. autoclass:: JLedSequence
    :members:
.. autofunction:: play
