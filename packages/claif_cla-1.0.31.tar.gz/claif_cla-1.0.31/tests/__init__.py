"""Test package for claif_cla."""
