from .ientities_extractor import iEntitiesExtractor
__all__ = ["iEntitiesExtractor"]