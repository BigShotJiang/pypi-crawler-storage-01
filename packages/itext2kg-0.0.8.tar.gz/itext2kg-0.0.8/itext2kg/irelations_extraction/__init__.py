from .irelations_extractor import iRelationsExtractor
from .simple_direct_irelations_extractor import SimpleDirectiRelationsExtractor
__all__ = ["iRelationsExtractor", "SimpleDirectiRelationsExtractor"]