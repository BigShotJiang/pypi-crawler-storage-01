# Swapsies

python is excellent for processing and transforming data, so this library captures some of my most used conversion scripts

