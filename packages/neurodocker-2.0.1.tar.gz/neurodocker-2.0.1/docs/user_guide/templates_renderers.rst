Templates and Renderers
=======================

.. todo:: include information about :code:`neurodocker.reproenv` templates and renderers.
