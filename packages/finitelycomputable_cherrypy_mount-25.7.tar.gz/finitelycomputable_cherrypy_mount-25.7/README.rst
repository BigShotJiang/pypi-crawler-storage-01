==============
CherryPy-Mount
==============

This application provides a /wsgi_info/ endpoint and uses tree.mount() to
combine all of the CherryPy modules that it finds in the virtual environment.
