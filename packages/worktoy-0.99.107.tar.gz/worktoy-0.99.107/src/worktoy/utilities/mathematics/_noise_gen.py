"""
The 'noiseGen' function creates a white noise signal by applying an ifft
to a constant valued input signal.
"""
#  AGPL-3.0 license
#  Copyright (c) 2025 Asger Jon Vistisen
