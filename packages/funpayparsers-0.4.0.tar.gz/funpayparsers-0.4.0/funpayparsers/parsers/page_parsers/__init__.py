from __future__ import annotations

from .chat_page_parser import *
from .main_page_parser import *
from .order_page_parser import *
from .profile_page_parser import *
from .subcategory_page_parser import *
from .transactions_page_parser import *
