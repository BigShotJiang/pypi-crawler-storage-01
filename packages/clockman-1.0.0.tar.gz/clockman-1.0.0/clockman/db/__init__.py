"""Database layer for Clockman."""
