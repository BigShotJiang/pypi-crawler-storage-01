"""Tests for Clockman time tracking application."""
