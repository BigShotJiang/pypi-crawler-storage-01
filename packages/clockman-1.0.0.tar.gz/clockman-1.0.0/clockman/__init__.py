"""
Clockman: Terminal-based time tracking for developers.

A privacy-focused, offline-first time tracking CLI application.
"""

__version__ = "1.0.0"
__author__ = "Clockman Team"
__email__ = "epicrr001@gmail.com"
