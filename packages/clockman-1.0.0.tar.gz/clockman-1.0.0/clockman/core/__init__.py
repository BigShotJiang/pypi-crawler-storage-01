"""Core business logic for Clockman."""
