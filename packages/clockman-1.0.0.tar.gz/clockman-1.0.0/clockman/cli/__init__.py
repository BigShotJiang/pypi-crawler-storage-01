"""CLI module for Clockman."""
