from snaptrade_client.paths.accounts_account_id_trading_simple.post import ApiForpost


class AccountsAccountIdTradingSimple(
    ApiForpost,
):
    pass
