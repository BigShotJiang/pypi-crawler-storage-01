from snaptrade_client.paths.brokerage_authorization_types.get import ApiForget


class BrokerageAuthorizationTypes(
    ApiForget,
):
    pass
