from snaptrade_client.paths.accounts_account_id_trading_simple_brokerage_order_id_replace.patch import ApiForpatch


class AccountsAccountIdTradingSimpleBrokerageOrderIdReplace(
    ApiForpatch,
):
    pass
