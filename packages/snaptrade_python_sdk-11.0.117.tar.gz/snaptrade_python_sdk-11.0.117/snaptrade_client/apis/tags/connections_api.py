# coding: utf-8

from snaptrade_client.apis.tags.connections_api_generated import ConnectionsApiGenerated

class ConnectionsApi(ConnectionsApiGenerated):
    pass
