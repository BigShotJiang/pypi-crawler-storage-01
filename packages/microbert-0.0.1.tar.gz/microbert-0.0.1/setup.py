from setuptools import setup; setup(name='microBERT', version='0.0.1')
