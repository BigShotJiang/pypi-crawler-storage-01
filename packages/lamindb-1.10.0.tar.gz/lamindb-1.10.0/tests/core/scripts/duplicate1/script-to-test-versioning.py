import lamindb as ln

ln.context.version = "1"
ln.track("Ro1gl7n8YrdH0001")
