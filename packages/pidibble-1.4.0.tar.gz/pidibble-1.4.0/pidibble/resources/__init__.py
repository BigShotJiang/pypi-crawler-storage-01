"""
Resources for the pidibble package.

- pdb_format.yaml -- YAML file defining the PDB format.
- mmcif_format.yaml -- YAML file defining the mmCIF format.
"""