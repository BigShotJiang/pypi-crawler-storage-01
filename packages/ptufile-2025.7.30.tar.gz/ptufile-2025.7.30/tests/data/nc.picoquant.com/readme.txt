Obtained from PicoQuant GmbH

+---nc.picoquant.com
|       DaisyPollen1.ptu
|       GattaQuant_Cells.ptu
|       HYPO  1ml of water in 500 medium 2.ptu
