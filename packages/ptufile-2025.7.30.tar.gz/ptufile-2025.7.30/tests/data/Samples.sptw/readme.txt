Obtained from https://www.picoquant.com/dl_software/SPT64/Demo_workspace_SPT64.zip

+---Samples.sptw
|       AnisotropyImage.pqres
|       Atto488_485nm_pulsed.pco
|       Atto488_485nm_pulsed.ptu
|       Atto488_diff_cw_total_correlation.pco
|       Atto488_diff_cw_total_correlation.ptu
|       ATTO488_FCS.pqres
|       ATTO488_FCS_Calibration.pqres
|       ATTO488_FCS_Fitting.pqres
|       Atto655+Cy5_diff_FCS+FLCS.pco
|       Atto655+Cy5_diff_FCS+FLCS.ptu
|       Atto655_diff_2FFCS.pco
|       Atto655_diff_2FFCS.ptu
|       Atto655_diff_FLCS-pattern.pco
|       Atto655_diff_FLCS-pattern.ptu
|       Atto655_focus1_horz_exc.pqres
|       Atto655_focus1_X_focus2.pqres
|       Atto655_focus2_perp_exc.pqres
|       Atto655_immo_On-Off-Analysis.pco
|       Atto655_immo_On-Off-Analysis.ptu
|       Atto655_TCSPC_Fitting.pqres
|       Blinking_FCS.pqres
|       Blinking_LifetimeTrace.pqres
|       Blinking_TimeTrace.pqres
|       CENP-FLIM.pqres
|       CENP-labelled_cells_for_FRET.pco
|       CENP-labelled_cells_for_FRET.ptu
|       CENP-labelled_cells_for_FRET_IRF_Det1.pco
|       CENP-labelled_cells_for_FRET_IRF_Det1.ptu
|       CENP-labelled_cells_for_FRET_IRF_Det2.pco
|       CENP-labelled_cells_for_FRET_IRF_Det2.ptu
|       CENP_FRET_Image.pqres
|       CENP_LT-FRET_2.pqres
|       Classical_FCS.pqres
|       CW_Antibunching.pqres
|       Cy3+Cy5_diff_PIE-FRET.pco
|       Cy3+Cy5_diff_PIE-FRET.ptu
|       Cy3+Cy5_FRET_TimeTrace.pqres
|       Cy3+Cy5_PIE_FRET_TimeTrace.pqres
|       Cy5_diff_IRF+FLCS-pattern.pco
|       Cy5_diff_IRF+FLCS-pattern.ptu
|       Cy5_immo_FLIM+Pol-Imaging.pco
|       Cy5_immo_FLIM+Pol-Imaging.ptu
|       Cy5_immo_Lifetime_Trace.pco
|       Cy5_immo_Lifetime_Trace.ptu
|       cy5_immo_TimeTrace.pqres
|       DaisyPollen_cells_FLIM.pco
|       DaisyPollen_cells_FLIM.ptu
|       Fast_FLIM.pqres
|       FLCS_Atto655_ONLY.pqres
|       FLCS_Cy5_ONLY.pqres
|       FLCS_Cy5_ONLY_1.pqres
|       FLIM non-FRET sample.pqres
|       FLIM_1_expon.pqres
|       FLIM_2.pqres
|       FLIM_3_expon.pqres
|       FLIM_dual_expon.pqres
|       FLIM_FRET_GFP_and_mRFP.pqres
|       FocalWidthEstimation.pqres
|       FRET_GFP and mRFP.pco
|       FRET_GFP_and_mRFP.ptu
|       FRET_Image.pqres
|       GFP_RFP_cells_FLIM-FRET.pco
|       GFP_RFP_cells_FLIM-FRET.ptu
|       Grouped_TCSPC_Fitting.pqres
|       GUVs.pco
|       GUVs.ptu
|       GUVs_MFLIM.pqres
|       IBA488+547_crosslinked.pco
|       IBA488+547_crosslinked.ptu
|       IBA488+547_FCCS_Grouped_1.pqres
|       IBA488+IBA547_unlinked_FCCS_grouped.pqres
|       IBA488+IBA547_unlinked_mix.pco
|       IBA488+IBA547_unlinked_mix.ptu
|       Left_Focus.pqres
|       LT-FRET.pqres
|       LT-FRET_1.pqres
|       LT-FRET_Binding.pqres
|       MFLIM.pqres
|       non-FRET sample.pco
|       non-FRET sample.ptu
|       NV-Center_for_Antibunching_1.pco
|       NV-Center_for_Antibunching_1.ptu
|       NV-Center_for_Antibunching_2.pco
|       NV-Center_for_Antibunching_2.ptu
|       NV-Center_for_Antibunching_several.pco
|       NV-Center_for_Antibunching_several.ptu
|       NV_Antibunching_1.pqres
|       NV_Antibunching_2.pqres
|       NV_Antibunching_several.pqres
|       OnOffHistogram.pqres
|       PatternMatching_non-FRET pattern from additional sample.pqres
|       PatternMatching_Patterns from DDM.pqres
|       PatternMatching_Patterns from Image.pqres
|       PatternMatching_with_Background.pqres
|       Pat_FRET_GFP and mRFP.pqres
|       Pat_FRET_GFP_and_mRFP.pqres
|       Pat_non-FRET sample.pqres
|       Right_Focus.pqres
|       TCSPC_Decay.pqres
|       TotalCorrelation.pqres
|       TS-Bead_immo_xy-scan_Dual Focus.pco
|       TS-Bead_immo_xy-scan_Dual Focus.ptu
|       TS-Bead_immo_xz-scan.pco
|       TS-Bead_immo_xz-scan.ptu
|       WSLogfile.sptl
