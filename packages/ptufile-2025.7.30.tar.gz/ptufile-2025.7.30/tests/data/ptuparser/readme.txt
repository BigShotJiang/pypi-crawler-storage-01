Obtained from https://pypi.org/project/ptuparser/

+---ptuparser
|       default_007.ptu
