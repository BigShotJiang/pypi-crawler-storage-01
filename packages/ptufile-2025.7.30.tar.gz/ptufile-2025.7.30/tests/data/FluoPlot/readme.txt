Obtained from PicoQuant FluoPlot installer

+---FluoPlot
|       C6_Rubrene_TRES.hhd
|       Correction_Device1.scd
|       Naphtal_BuOH_TRES.phd
|       Naphtal_BuOH_TRES.phu
|       Sensitivity_Device1.scd
|       TRES_spectrum.thd
