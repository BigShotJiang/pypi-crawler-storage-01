Obtained from https://www.picoquant.com/dl_software/QuCoa/QuCoa_v1_4_0_5818.zip

+---QuCoa
|       Antibunching_1.pqres
|       AtB_Fitting_1.pqres
|       AtB_Fitting_2.pqres
|       CW_Shelved.ptu
|       Pulsed.ptu
|       Pulsed_OAtB.pqres
