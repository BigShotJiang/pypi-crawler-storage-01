Obtained from https://github.com/tsbischof/picoquant-sample-data

+---picoquant-sample-data
|   |   LICENSE
|   |
|   +---hydraharp
|   |       v10.hhd
|   |       v10.ht2
|   |       v10.ht3
|   |       v10_t2.ptu
|   |       v10_t3.ptu
|   |       v20.hhd
|   |       v20.ht2
|   |       v20.ht3
|   |       v20_t2.ptu
|   |       v20_t3.ptu
|   |
|   +---picoharp
|   |       v20.phd
|   |       v20.pt2
|   |       v20.pt3
|   |       v30.cor
|   |       v30_t2.ptu
|   |
|   \---timeharp
|           v20.thd
|           v30.t3r
|           v30.thd
|           v50.t3r
|           v50.thd
|           v60.thd
