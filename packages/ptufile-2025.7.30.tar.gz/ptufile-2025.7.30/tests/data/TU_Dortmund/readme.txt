Obtained by email on 2025.5.21

+---TU_Dortmund
|       13_7_5.ptu
|       daisy1.ptu
|       fluorescein_ref_4ns.ptu
|       Pollen.ptu