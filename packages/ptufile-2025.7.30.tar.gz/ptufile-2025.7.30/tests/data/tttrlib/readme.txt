Obtained from https://github.com/Fluorescence-Tools/tttrlib/issues/24#issuecomment-864879721

+---tttrlib
|       5kDa_1st_1_1_1.ptu
