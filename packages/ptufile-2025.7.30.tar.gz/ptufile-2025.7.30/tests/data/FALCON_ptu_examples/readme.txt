Obtained from https://github.com/dwaithe/FCS_point_correlator/issues/20

+---FALCON_ptu_examples
|       40MHz_example.ptu
|       80MHz_cy3_example.ptu
