Obtained from https://figshare.com/s/4957fcfa684daef86c23

+---Tutorials.sptw
|       Hyperosmotic_Shock_MDCK_Cell.pco
|       Hyperosmotic_Shock_MDCK_Cells.ptu
|       IRF_Fluorescein.pck
|       IRF_Fluorescein.pco
|       IRF_Fluorescein.ptu
|       Kidney _Cell_FLIM.pco
|       Kidney _Cell_FLIM.ptu
|       MicroBeads.pck
|       MicroBeads.pco
|       MicroBeads.ptu
|       WSLogfile.sptl
