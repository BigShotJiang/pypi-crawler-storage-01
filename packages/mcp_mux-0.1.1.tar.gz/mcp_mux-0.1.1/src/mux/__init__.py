"""MCP Mux - A Model Context Protocol router with semantic search."""

__version__ = "0.1.0"
