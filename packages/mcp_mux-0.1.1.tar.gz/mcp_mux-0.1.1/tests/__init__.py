"""Test suite for MCP Mux."""
