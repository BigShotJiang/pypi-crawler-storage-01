"""Unit tests for MCP Mux."""
