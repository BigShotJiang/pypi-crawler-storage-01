"""Integration tests for MCP Mux."""
