class AnyParser:
    parser_type = "any"


class DocumentParser:
    parser_type = "document"


class EmailParser:
    parser_type = "email"


class MediaParser:
    parser_type = "media"


class PdfParser:
    parser_type = "pdf"


class PptxParser:
    parser_type = "pptx"


class XlsxParser:
    parser_type = "xlsx"


class WebParser:
    parser_type = "web"
