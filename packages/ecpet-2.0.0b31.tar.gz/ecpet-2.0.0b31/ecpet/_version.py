#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Module stub that keeps the one centraliced variable that gives
the current version number.

It is read by multiple build scripts, too.
"""

__title__ = 'ecpet'
__release__ = '2.0.0-beta31'

