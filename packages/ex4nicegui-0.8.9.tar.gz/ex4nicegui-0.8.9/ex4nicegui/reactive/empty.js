export default {
    template: '<slot></slot>'
}