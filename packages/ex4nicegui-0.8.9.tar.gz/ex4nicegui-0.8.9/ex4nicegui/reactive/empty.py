from __future__ import annotations
from nicegui.element import Element


class Empty(Element, component="empty.js"):
    pass
