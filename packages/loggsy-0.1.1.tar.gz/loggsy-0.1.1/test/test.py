import sys
import os
sys.path.append('/home/kimyh/library/logsy')
import logsy as lo

def main():
    log = lo.get_logger()
    pass

if __name__ == '__main__':
    main()