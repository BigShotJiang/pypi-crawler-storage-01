from popdf.api.pdf import *

__version__ = '1.0.6'

__doc__ = "podf docs:https://www.python-office.com/office/pdf.html"
