'''
    Module to access MeasurementSet data using MsData class.
'''

from ._ms_data import (
    MsData
)
