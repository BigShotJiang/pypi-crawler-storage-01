from .router import NetworkNinja


__all__ = (
    'NetworkNinja',
)
