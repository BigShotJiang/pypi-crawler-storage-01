Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ssd1680_simpletest.py
    :caption: examples/ssd1680_simpletest.py
    :linenos:

2.13 ePaper Display FeatherWing Simple test
---------------------------------------------

Ensure your 2.13 ePaper Display FeatherWing works with this simple test.

.. literalinclude:: ../examples/ssd1680_2.13_featherwing.py
    :caption: examples/ssd1680_2.13_featherwing.py
    :linenos:

2.13 TriColor Breakout Simple test
---------------------------------------

Ensure your 2.13 ePaper TriColor breakout Display works with this simple test.

.. literalinclude:: ../examples/ssd1680_2.13_tricolor_breakout.py
    :caption: examples/ssd1680_2.13_tricolor_breakout.py
    :linenos:
