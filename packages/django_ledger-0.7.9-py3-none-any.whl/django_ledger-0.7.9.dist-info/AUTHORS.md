![django ledger logo](https://us-east-1.linodeobjects.com/django-ledger/logo/django-ledger-logo@2x.png)

Django Ledger was created by [Miguel Sanda](https://github.com/elarroba).

# __Authors & Contributors of Django Ledger__

### Project Maintainers
* Miguel Sanda [@elarroba](https://github.com/elarroba)

### Developers
* Miguel Sanda [@elarroba](https://github.com/elarroba)

### Contributors
* Michael Noel [@mnooel](https://github.com/mnooel)
* Eric Owuor [@Ericpaul](https://github.com/25-do)
* Pranav P Tulshyan

### Accountants, CPAs & Bookkeepers
* Miguel Sanda [@elarroba](https://github.com/elarroba)
* Albert Salazar [@Beachwood619](https://github.com/Beachwood619)
* Michael Noel, CPA [@mnooel](https://github.com/mnooel) 

### Documentation Contributors
* Miguel Sanda [@elarroba](https://github.com/elarroba)