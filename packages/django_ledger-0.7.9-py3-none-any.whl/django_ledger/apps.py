from django.apps import AppConfig


class DjangoLedgerConfig(AppConfig):
    name = 'django_ledger'
    label = 'django_ledger'
    verbose_name = 'Django Ledger'
