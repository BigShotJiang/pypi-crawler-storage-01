# tcvpigpiv 

# A python package to calculate the tropical cyclone ventilated Potential Intensity (vPI) and the Genesis Potential Index using vPI (GPIv) from gridded datafiles. See Chavas Camargo Tippett (2025, J. Clim.) for details.
#### Author: Dan Chavas (2025)

