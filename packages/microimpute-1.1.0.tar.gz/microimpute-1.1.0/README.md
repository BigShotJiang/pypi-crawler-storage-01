# MicroImpute

MicroImpute enables variable imputation through different statistical methods. It facilitates comparison and benchmarking across methods through quantile loss calculations.

To install, run pip install microimpute.

For image export functionality (PNG/JPG), install with: pip install microimpute[images]
