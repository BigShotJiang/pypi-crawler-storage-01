"""
aidesk - A simple web service to generate files via API
"""

__version__ = "0.1.0"
