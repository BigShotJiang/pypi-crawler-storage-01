<!--
SPDX-FileCopyrightText: 2022 Genome Research Ltd.

SPDX-License-Identifier: MIT
-->

# ToL SDK

A Python SDK for ToL services. Full documentation is available:
https://ssg-confluence.internal.sanger.ac.uk/display/TOL/ToL+SDK
