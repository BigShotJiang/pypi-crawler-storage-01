# DBType
POSTGRES = "postgres"
MONGODB = "mongodb"
MYSQL = "mysql"
REDIS = "redis"
SQLITE = "sqlite"