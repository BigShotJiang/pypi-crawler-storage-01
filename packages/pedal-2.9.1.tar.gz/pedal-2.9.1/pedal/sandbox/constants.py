""" Defines constants available for Sandbox. """

TOOL_NAME = 'sandbox'
