

"""
assert_drafter_started()

assert_routes([])

assert_route("index", "index")

assert_state("State", ["username", "password"])

assert_page("index", ["Header", "Button"])

"""