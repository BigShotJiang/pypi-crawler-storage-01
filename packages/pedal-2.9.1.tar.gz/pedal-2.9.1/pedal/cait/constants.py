"""
Module-wide constants for CAIT.
"""
TOOL_NAME = "cait"
