""" Defines constants available for TIFA. """

__all__ = ['TOOL_NAME']

TOOL_NAME = "tifa"
