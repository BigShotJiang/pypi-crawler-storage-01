"""
Constants related to the Source tool, such as the default student filename.
"""

TOOL_NAME = 'source'
DEFAULT_STUDENT_FILENAME = "answer.py"
