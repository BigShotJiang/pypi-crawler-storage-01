from typing import Union

from .code import Code

CodeRegistry = dict[str, Union[Code, str]]
