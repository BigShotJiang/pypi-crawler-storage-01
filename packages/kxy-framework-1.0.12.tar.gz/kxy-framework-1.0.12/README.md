## 使用方法：
pip install kxy-framework
```python
from kxy.framework.context import SUtil


```