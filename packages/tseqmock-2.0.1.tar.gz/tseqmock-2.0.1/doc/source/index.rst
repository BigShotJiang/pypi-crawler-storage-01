`TSeqMock <https://gitlab.inria.fr/tanat/core/tseqmock>`_ Documentation
================================================================================================

``TSeqMock`` is an open library for Temporal Sequence Mocking. It allows flexible temporal sequence simulation.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`