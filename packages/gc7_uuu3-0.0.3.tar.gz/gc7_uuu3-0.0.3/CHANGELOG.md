# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-08-03)

### Bug Fixes

- Reset v0.0.2
  ([`93b91ea`](https://github.com/PyMoX-fr/GC7/commit/93b91ea5d002c5408d81a20f2a2192585e386422))

- Set v.0.2
  ([`32e8cf0`](https://github.com/PyMoX-fr/GC7/commit/32e8cf0c38b70126e5835e072e7b087713ad6799))


## v0.0.0 (2025-08-03)

- Initial Release
