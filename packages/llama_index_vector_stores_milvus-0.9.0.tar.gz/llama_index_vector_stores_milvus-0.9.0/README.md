# LlamaIndex Vector_Stores Integration: Milvus
