"""
Constants used throughout the application.
"""

# NO_RESPONSE_ID is used to represent an endpoint response that does not define a content schema.
NO_RESPONSE_ID = "<NoResponse>"
