## Utility package

Utility package for common dependencies for web developing of personal web applications