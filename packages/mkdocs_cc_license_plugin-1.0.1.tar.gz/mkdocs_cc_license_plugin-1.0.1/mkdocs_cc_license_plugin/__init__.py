"""
MkDocs Creative Commons License Plugin

A plugin that automatically adds Creative Commons license icons and links
based on the 'license' property in page metadata.
"""

__version__ = "1.0.0"
