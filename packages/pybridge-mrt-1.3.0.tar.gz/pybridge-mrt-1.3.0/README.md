
THIS LIBRARY IS FOR SHARING DATA BETWEEN TWO OR MORE THAN
TWO SCRIPTS WITH 'SQL' DATABASE,
BUT YOU CAN USE 'pybridge' AS A SIMPLE DATABASE LIBRARY

:::::::::::::::::::::::::::::::::::::::::::::::;

The main class of library is 'bridge' with some methods:

send_to_bridge() => for saving and sharing data with SQL database

receive_from_bridge(self, all=True, find_key=None, on_delete=False) =>
for getting datas from selected bridge by built object,
The type of received keys and values id 'string' 

***args:
all : RETURNS ALL RECORDS

find_key : YOU CAN FILTER RECORDS BASED ON THEIR KEYS

on_delete : DELETES ALL FOUNDED RECORDS WHEN IT IS 'TRUE'

delete_bridge_data(find_key=None) => delete records from databse with filtering by 'KEYS'

get_bridge_record_count() => RETURNS RECORDS COUNT IN BRIDGE

raw_sql(query: str, entry: tuple = ()) => RUNNING SQL IN BRIDGE

***args:

query: SQL query for command

entry: inputs for query, every item in this tuple must be tuple!


raw_query_select(query: str, entry: tuple = ()) => SELECTING WITH RAW SQL QUERY

***args:

query: SQL query for command

entry: inputs for query, every item in this tuple must be tuple!

This function returns tuple data

send_dict_data(data: dict) => SEND DATA WITH DICTIONARY

add_bridge_listener() => MAKE A LISTENER FOR BRIDGE EVENTS

It waits for events and after each event you have to call it again
and because of that you can usually use it in 'while True' Loops

the built object of 'bridge' has new_event and event_list

new_event ==> It shows the last event that happended to bridge and database

event_list ==> list of saved events by listener



:::::::::::::::::::::::::::::::::::::::::::::::;

THIS PACAKGE IS DEVELOPED BY 'MRT' => (MOHAMMAD REZA TAGHDIRI) A PERSIAN PROGRAMER.

I HOPE THAT 'pybridge' MAKE SOME WORKS EASIER FOR YOU....