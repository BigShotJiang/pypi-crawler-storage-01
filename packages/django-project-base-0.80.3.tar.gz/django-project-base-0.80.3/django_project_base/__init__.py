__title__ = "django project base"
# __version__ = "{version-string}"  #TODO: Switch back to version string when merging to main
__version__ = '0.80.3'
default_app_config = "django_project_base.apps.DjangoProjectBaseConfig"

VERSION = __version__
