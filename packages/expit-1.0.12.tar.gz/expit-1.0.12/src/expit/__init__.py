from expit.core import *
from expit.tests import *

if __name__ == "__main__":
    main()
