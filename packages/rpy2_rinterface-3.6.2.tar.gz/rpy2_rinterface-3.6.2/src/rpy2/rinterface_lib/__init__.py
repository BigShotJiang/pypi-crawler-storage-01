__version_vector__ = (3, 6, 2)

__version__ = '.'.join(str(x) for x in __version_vector__)
