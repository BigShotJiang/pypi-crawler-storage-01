To use this module, you need to:

1.  Define the brand use level (see brand module documentation)

2.  Go to Settings \> Users & Companies \> Brands

3.  Select a brand

4.  Define allowed payment modes

5.  Create a new invoice  
    1.  Select the brand
    2.  Select a payment mode

The payment mode list is filtered with the brand allowed payment modes.
