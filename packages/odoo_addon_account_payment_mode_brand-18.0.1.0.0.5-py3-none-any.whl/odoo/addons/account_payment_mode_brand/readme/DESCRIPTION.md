This addon define allowed payment mode per brand.
