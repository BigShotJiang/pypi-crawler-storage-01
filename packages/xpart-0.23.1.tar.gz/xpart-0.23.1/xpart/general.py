# copyright ############################### #
# This file is part of the Xpart Package.   #
# Copyright (c) CERN, 2021.                 #
# ######################################### #

from pathlib import Path
from xobjects.general import _print

_pkg_root = Path(__file__).parent.absolute()
