# LlamaIndex Index_Store Integration: Firestore Indexstore
