import uuid

test_prefix = f"pytest-{uuid.uuid1()}-"
