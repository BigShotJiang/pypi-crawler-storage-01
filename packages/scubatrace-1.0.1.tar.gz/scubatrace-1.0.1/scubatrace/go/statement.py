from __future__ import annotations

from ..statement import BlockStatement, SimpleStatement


class GoSimpleStatement(SimpleStatement): ...


class GoBlockStatement(BlockStatement): ...
