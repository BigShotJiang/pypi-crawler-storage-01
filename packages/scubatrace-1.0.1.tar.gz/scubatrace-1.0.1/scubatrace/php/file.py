from ..file import File


class PHPFile(File): ...
