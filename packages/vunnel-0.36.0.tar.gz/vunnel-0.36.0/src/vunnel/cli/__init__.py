from .cli import cli


def run() -> None:
    cli()
