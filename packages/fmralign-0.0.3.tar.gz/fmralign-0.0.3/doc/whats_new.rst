
.. _whats_new:

==========
What's new
==========

0.1
===

First release of fmralign.
