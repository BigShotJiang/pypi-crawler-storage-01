########
Examples
########

.. warning::

    If you want to run the examples, make sure you execute them in a directory
    where you have write permissions, or you copy the examples into such a
    directory. If you install fmralign manually, make sure you have followed
    the instructions.
