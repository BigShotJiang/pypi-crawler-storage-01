Flags
=====

.. currentmodule:: terminusgps.wialon.flags

.. autoclass:: AccessFlag
    :members:

.. autoclass:: DataFlag
    :members:

.. autoclass:: SettingsFlag
    :members:

.. autoclass:: TokenFlag
    :members:
