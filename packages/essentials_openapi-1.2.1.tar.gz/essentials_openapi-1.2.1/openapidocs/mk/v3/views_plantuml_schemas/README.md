# Views to generate PlantUML schemas

This folder contains views to generate a class diagram from components schemas,
for [PlantUML](https://plantuml.com).
