class VersionConsts(object):
    VERSION1 = "version1"
    VERSION2 = "version2"
    VERSION3 = "version3"
