class CruiseProject(object):
    def __init__(self, project_name, id=None):
        self.project_name = project_name
        self.id = id
