class CruiseFileFormat(object):
    def __init__(self, format_name, format_description, id=None, alt_id=None):
        self.format_name = format_name
        self.format_description = format_description
        self.id = id
        self.alt_id = alt_id
