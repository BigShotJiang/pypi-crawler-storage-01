class CruiseDatasetType(object):
    def __init__(self, type_name, type_description, id=None):
        self.type_name = type_name
        self.type_description = type_description
        self.id = id
