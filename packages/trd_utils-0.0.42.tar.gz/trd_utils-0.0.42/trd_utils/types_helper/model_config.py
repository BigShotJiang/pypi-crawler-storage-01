

class ModelConfig:
    ignored_fields: list[str] = None


