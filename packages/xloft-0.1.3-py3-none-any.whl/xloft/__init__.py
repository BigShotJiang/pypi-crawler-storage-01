"""(XLOFT) X-Library of tools."""

__all__ = ("NamedTuple",)

from xloft.namedtuple import NamedTuple
