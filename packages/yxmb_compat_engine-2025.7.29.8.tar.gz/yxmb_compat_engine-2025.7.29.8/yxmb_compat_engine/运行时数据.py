from kapybara.runtime_counter import Counter

已完成数量 = Counter()

# 等待时间设置为10秒，或根据需要调整
等待时间 = 10
