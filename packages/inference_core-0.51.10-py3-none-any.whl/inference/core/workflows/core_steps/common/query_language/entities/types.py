from typing import TypeVar

T = TypeVar("T")
V = TypeVar("V")
