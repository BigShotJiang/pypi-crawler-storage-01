# pytest-plugin: crosszip_parametrize

::: crosszip.plugin
