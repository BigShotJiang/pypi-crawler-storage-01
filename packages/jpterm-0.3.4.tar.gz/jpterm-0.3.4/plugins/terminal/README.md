# TXL plugin for a terminal widget
