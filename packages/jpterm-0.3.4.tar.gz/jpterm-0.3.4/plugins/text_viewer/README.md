# TXL plugin for a text viewer
