# !/usr/bin/python3
# -*- coding:utf-8 -*-
"""
@Author: xiaodong.li
@Time: 7/28/2025 2:12 PM
@Description: Description
@File: __init__.py
"""
__version__ = "1.0.17"
