
        "BRIDGE OBJECT DEFINITIONS 06 - ABUTMENTS",

        "JOINT BRIDGE OBJECT FLAGS",
        BOItemType=="Abutment"
