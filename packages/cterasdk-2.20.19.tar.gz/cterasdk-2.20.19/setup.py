import setuptools

setuptools.setup(
    pbr=True,
    install_requires=[
        'aiohttp>=3.8.0',
        'munch>=2.5.0',
    ],
)
