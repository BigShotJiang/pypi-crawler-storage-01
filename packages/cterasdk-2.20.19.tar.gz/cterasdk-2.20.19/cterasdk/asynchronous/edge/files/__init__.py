from .browser import FileBrowser  # noqa: E402, F401
