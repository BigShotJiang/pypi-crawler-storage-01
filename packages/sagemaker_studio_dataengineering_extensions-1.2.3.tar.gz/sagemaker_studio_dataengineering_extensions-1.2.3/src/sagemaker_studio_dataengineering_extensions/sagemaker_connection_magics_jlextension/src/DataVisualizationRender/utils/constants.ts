export const packageName = '@amzn/maxdome-data-visualization-widget';
export const majorVersion = 1;
