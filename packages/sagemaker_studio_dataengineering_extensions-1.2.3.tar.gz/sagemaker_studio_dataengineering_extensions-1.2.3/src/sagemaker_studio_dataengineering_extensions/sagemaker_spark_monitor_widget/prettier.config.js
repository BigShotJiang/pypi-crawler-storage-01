module.exports = {
  printWidth: 120,
  singleQuote: true,
  tabWidth: 4,
  trailingComma: 'all'
};
