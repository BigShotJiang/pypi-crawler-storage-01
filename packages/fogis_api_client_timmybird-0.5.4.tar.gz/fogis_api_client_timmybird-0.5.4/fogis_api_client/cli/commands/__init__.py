"""
CLI commands for the mock server.

This package contains the commands for the mock server CLI.
"""
