"""
Integration tests package for the FOGIS API client.
"""
