"""Neuro-API-Tony module CLI runner."""

from .cli import cli_run

if __name__ == "__main__":
    cli_run()
