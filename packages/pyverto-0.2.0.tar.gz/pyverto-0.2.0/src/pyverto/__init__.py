# SPDX-FileCopyrightText: 2025-present phdenzel <phdenzel@gmail.com>
# SPDX-FileNotice: Part of pyverto
# SPDX-License-Identifier: MIT
"""pyverto module."""
