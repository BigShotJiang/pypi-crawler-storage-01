DEF_FOR( acp, PyConvexPolyhedraAssembly, std::string              )
DEF_FOR( img, PyScaledImage            , std::string              )
DEF_FOR( arf, PyConvexPolyhedraAssembly, sdot::FunctionEnum::Arfd )
