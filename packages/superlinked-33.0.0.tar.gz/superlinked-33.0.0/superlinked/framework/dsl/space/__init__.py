"""
Space module contains components that let you describe how you want to embed your data.
It encapsulated the vector creation logic to be reused at ingestion and at query time.
"""
