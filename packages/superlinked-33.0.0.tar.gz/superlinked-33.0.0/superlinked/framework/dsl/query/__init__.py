"""
Query module has components that allow you to define queries on top of your indices.
Queries can have parameters and weights that you can provide at query time to control your search.
"""
