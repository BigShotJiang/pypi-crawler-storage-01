# Ragbits Agents

Ragbits Agents contains primitives for building agentic systems.

The package is in the experimental phase, the API may change in the future.

## Installation

To install the Ragbits Agents package, run:

```sh
pip install ragbits-agents
```

<!--
TODO: Add a minimalistic example inspired by the Quickstart chapter on Ragbits Evaluate once it is ready.
-->

<!--
TODO:
* Add link to the Quickstart chapter on Ragbits Evaluate once it is ready.
* Add link to API Reference once classes from the Evaluate package are added to the API Reference.
-->
