import os

OCTUE_SERVICES_TOPIC_NAME = os.environ.get("OCTUE_SERVICES_TOPIC_NAME", "main.octue.services")
