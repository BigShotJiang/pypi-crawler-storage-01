from dataclasses import dataclass

__all__ = ["Resource"]


@dataclass
class Resource:
    """
    Base class for all resources.
    """
