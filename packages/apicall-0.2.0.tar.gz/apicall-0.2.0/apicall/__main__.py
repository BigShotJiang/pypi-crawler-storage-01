from . import main
exit(main.main())
