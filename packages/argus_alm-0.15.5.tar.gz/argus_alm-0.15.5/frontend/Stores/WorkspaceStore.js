import {
    readable
} from "svelte/store";

export const allReleases = readable(undefined, function (set) {

});

export const allGroups = readable(undefined, function (set) {

});


export const allTests = readable(undefined, function (set) {

});
