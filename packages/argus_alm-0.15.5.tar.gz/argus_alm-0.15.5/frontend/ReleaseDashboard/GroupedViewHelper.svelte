<div>
    <slot><!-- optional fallback --></slot>
</div>
