<div class="p-2 shadow mb-2 rounded bg-main">
    <div class="my-2 d-flex flex-wrap bg-lighter rounded shadow-sm">
        <slot><!-- optional fallback --></slot>
    </div>
</div>
