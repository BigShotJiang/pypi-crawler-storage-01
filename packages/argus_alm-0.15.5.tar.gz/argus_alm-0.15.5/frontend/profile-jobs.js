import ProfileJobs from "./Profile/ProfileJobs.svelte";

const app = new ProfileJobs({
    target: document.querySelector("#jobsContainer"),
    props: {}
});
