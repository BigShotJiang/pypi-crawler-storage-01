<div class="d-flex align-items-center justify-content-center h-100">
    <div class="text-muted rounded bg-main shadow-sm p-4">
        Welcome to admin area! Select a category you wish to manage on the left side.
    </div>
</div>
