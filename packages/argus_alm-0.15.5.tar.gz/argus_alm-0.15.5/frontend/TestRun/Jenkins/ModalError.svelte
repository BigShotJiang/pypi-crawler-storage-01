<script>
    /**
     * @type {{
     *  message: string,
     * }}
     */
    export let args;
</script>

<div class="alert alert-danger">
    <pre style="white-space: pre-wrap;">{args.message}</pre>
</div>
