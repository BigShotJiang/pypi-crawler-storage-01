<script>
    /**
     * @type {Object} args
     */
    export let args;
</script>

<div>
    <span class="spinner-border spinner-border-sm"></span> Starting next build...
</div>
