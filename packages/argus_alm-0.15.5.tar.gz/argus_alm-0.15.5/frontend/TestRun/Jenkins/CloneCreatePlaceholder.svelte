<script>
    /**
     * @type {{
     * currentTestId: string,
     * newName: string,
     * target: string,
     * group: string,
     * advancedSettings: boolean | { [string]: string },
     * }} args
     */
    export let args;

</script>

<div>
    <span class="spinner-border spinner-border-sm"></span> Cloning...
</div>
