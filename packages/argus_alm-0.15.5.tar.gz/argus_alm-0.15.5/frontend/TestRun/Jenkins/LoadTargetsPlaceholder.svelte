<script>
    /**
     * @type {{testId: string}} args
     */
    export let args;
</script>

<div>
    <span class="spinner-border spinner-border-sm"></span> Loading targets...
</div>
