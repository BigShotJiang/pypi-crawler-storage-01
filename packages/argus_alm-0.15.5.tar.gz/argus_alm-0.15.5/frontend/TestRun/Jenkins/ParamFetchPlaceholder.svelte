<script>
    /**
     * @type {{buildId: string, buildNumber: string}} args
     */
    export let args;
</script>

<div>
    <span class="spinner-border spinner-border-sm"></span> Fetching parameters from {args.buildId}#{args.buildNumber}...
</div>
