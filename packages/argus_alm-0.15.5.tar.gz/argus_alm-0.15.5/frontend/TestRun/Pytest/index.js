import PytestTab from "../Pytest/PytestTab.svelte";
import PytestRun from "../Pytest/PytestRun.svelte";

export {
    PytestTab,
    PytestRun
};
