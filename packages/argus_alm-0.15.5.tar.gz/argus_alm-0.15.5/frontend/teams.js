import TeamManager from "./Teams/TeamManager.svelte";

const app = new TeamManager({
    target: document.querySelector("#teamsContainer")
});
