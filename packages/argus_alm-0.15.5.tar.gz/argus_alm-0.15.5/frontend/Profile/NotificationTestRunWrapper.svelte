<script>
    export let supportData;
</script>

<div>
    <!-- Placeholder -->
</div>
