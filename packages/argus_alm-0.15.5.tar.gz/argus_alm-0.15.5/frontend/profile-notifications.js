import NotificationsReader from "./Profile/NotificationsReader.svelte";

const app = new NotificationsReader({
    target: document.querySelector("#notificationsContainer")
});
