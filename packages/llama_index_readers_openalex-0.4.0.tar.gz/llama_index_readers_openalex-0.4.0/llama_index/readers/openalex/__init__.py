"""Init file."""

from llama_index.readers.openalex.base import OpenAlexReader

__all__ = ["OpenAlexReader"]
