# Changelog

## 0.0.1

Skeletal package release. 

The package's contents are based on Appendix C in _Signal Processing for Algorithmic Trading_ (to be published) by Jay Damask. 



