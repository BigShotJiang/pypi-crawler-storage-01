"""
-------------------------------------------------------------------------------

Simple module for the elliptical-distribution-toolkit package

-------------------------------------------------------------------------------
"""


def print_toolkit_name():
    """
    Print the name of the toolkit to stdout.

    Returns:
        None
    """
    print("I am the elliptical-distribution-toolkit")

