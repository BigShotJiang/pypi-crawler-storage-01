"""
-------------------------------------------------------------------------------

`elliptical_distribution_toolkit` package top-level import

-------------------------------------------------------------------------------
"""

# AUTO-GENERATED version
__version__ = "0.0.1"

# Import the toolkit function
from .toolkit import print_toolkit_name

