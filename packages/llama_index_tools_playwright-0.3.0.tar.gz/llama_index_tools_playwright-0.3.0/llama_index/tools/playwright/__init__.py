from llama_index.tools.playwright.base import PlaywrightToolSpec


__all__ = ["PlaywrightToolSpec"]
