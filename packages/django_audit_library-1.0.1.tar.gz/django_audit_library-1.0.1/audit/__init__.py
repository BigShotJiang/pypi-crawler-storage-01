__version__ = '1.0.0'
__author__ = 'Your Name'
__email__ = 'your.email@example.com'

default_app_config = 'audit.apps.AuditConfig'