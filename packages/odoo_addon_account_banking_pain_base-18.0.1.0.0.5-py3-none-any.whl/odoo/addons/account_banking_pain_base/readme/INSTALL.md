This module depends on :

- account_payment_order

This module is part of the OCA/bank-payment suite.
