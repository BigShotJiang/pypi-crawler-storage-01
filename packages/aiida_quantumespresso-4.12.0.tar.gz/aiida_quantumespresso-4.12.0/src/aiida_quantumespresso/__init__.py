# -*- coding: utf-8 -*-
"""The official AiiDA plugin for Quantum ESPRESSO."""
__version__ = '4.12.0'
