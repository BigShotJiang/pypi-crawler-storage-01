# -*- coding: utf-8 -*-
"""Common modules to be shared with other aiida plugins."""
