__all__ = ["lib_template"]

def lib_template():
    print("lib_template")

def hidden_lib_template():
    print("hidden_lib_template")
