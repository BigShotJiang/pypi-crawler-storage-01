"""Module contains version and other package information."""

__version__ = "1.4"
