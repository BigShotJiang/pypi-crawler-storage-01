```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

api.md
changelog.md
template_usage.md
contributing.md
references.md

notebooks/example
```
