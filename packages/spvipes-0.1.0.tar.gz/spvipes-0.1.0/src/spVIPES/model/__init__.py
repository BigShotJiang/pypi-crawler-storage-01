from .spvipes import spVIPES as spVIPES

__all__ = ["spVIPES"]
