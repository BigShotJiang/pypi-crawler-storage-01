def foo():
    pass
