__author__ = {
    "jackzzs": "jackzzs@outlook.com",
}
__version__ = "7.4.14"
__url__ = "https://emby-keeper.github.io"
