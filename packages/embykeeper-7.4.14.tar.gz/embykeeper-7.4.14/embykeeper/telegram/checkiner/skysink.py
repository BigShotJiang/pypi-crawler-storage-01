from ._templ_a import TemplateACheckin

__ignore__ = True


class SkysinkCheckin(TemplateACheckin):
    name = "尘烬"
    bot_username = "kyououbot"
