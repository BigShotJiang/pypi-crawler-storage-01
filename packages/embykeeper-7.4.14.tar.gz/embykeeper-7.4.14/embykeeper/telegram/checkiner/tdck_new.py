from ._templ_a import TemplateACheckin


class TdckNewCheckin(TemplateACheckin):
    name = "起点站"
    bot_username = "tdck_emby_create_bot"
