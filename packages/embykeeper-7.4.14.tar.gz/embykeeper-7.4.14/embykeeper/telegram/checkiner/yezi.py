from ._templ_a import TemplateACheckin


class YeziCheckin(TemplateACheckin):
    name = "叶子"
    bot_username = "yeziemby_bot"
