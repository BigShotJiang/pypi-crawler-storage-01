from ._templ_a import TemplateACheckin

__ignore__ = True


class LilyCheckin(TemplateACheckin):
    name = "Lily"
    bot_username = "lilyembybot"
    bot_use_captcha = False
