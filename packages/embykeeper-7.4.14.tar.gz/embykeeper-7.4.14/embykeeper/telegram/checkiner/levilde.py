from ._templ_a import TemplateACheckin

__ignore__ = True


class LevildeCheckin(TemplateACheckin):
    name = "Levilde Luminia"
    bot_username = "Levilde_Luminia_Bot"
