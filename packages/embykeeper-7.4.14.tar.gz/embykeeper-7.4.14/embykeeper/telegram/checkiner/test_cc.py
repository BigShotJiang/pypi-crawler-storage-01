from .cc import CCCheckin

__ignore__ = True


class TestCCCheckin(CCCheckin):
    name = "CC 签到测试"
    bot_username = "embykeeper_test_bot"
