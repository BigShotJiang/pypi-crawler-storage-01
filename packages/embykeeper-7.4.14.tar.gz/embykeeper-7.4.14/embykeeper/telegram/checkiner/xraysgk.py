from . import BotCheckin

__ignore__ = True


class XraySGKCheckin(BotCheckin):
    name = "Xray 社工库"
    bot_username = "Zonesgk_bot"
    bot_checkin_cmd = "/qd"
