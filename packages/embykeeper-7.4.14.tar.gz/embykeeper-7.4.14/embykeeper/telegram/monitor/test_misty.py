from .misty import MistyMonitor

__ignore__ = True


class TestMistyMonitor(MistyMonitor):
    name = "Misty 测试"
    chat_name = "api_group"
