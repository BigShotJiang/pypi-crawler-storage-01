"""CLI package for Bub."""

from .app import app

__all__ = ["app"]
