from .contracts import JobVacancy, AbstractIntegration, SalaryRange
from .integrations import *
