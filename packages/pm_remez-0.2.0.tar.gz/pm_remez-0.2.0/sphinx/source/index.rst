pm-remez documentation
======================

.. automodule:: pm_remez
   :members:
