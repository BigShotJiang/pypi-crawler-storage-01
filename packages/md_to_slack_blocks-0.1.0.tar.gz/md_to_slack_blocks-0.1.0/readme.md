### md-to-slack-blocks

A simple python library to convert markdown to the Slack blocks.





