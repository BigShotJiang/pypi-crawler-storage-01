"""
Storage plugin for YAAPP framework.
Provides unified data persistence capabilities configured through yaapp config.
"""