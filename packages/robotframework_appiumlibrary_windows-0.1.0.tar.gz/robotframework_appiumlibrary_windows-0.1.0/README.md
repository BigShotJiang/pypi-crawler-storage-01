# Robot Framework AppiumLibrary update
Update to new appium python client version

Add win32dll interaction via powershell

