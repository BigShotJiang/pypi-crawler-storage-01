__author__ = '{{cookiecutter.full_name}}'
__email__ = '{{cookiecutter.email}}'