"""Test package for {{cookiecutter.project_slug}}."""
