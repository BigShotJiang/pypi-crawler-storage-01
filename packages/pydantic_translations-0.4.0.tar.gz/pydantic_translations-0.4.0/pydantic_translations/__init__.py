"""Translations for pydantic errors.
"""
from ._translator import Translator


__version__ = '0.4.0'
__all__ = ['Translator']
