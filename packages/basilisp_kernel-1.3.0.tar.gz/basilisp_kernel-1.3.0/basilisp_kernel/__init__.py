"""The Basilisp Jupyter kernel"""

__version__ = '1.3.0'

from .kernel import BasilispKernel
