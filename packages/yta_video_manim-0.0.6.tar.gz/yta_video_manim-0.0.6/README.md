# Youtube Autonomous Video Manim Module

The way to generate videos with Manim