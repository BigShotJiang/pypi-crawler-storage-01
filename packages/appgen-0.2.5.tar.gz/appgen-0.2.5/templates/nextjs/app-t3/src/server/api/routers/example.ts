import { createTRPCRouter, publicProcedure } from "~/server/api/root";

export const exampleRouter = createTRPCRouter({
  // Add your procedures here
});
