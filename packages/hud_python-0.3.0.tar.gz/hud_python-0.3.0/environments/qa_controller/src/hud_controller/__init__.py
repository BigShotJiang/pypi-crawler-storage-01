"""Initialize the local-qa environment package."""
from __future__ import annotations

