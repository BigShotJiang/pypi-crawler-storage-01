# Tests for hud.adapters.operator module
