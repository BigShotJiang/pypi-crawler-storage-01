"""MCP instrumentation for telemetry collection."""

from __future__ import annotations
