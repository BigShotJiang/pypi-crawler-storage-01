from logging import getLogger, DEBUG

LOG = getLogger("dependency-injection")
LOG.setLevel(DEBUG)