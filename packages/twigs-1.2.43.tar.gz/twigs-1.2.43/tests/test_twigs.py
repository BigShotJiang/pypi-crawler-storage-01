#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `twigs` package."""


import unittest

from twigs import twigs


class TestTwigs(unittest.TestCase):
    """Tests for `twigs` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
