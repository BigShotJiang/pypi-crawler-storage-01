=======
Credits
=======

Development Lead
----------------

* Paresh Borkar <opensource@threatwatch.io>

Contributors
------------

None yet. Why not be the first?
