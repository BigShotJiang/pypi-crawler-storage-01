from oarepo_oaipmh_harvester.common.resources.records.harvester_resource import (
    OaiHarvesterBaseResource,
)


class OaiHarvesterResource(OaiHarvesterBaseResource):
    """OaiHarvesterRecord resource."""

    # here you can for example redefine
    # create_url_rules function to add your own rules
