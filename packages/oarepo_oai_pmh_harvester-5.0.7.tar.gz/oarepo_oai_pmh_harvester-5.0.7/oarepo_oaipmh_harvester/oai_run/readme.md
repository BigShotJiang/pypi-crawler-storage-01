# OAI Run

OAI Run is stored directly in the database. This module is a record compatibility layer,
modelled after the invenio-users-resources module.

It provides a mapping for the opensearch and periodic tasks to synchronize the database
oai run to the opensearch index.
