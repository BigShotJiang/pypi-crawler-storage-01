# Torizon Templates Utils

This package contains a set of utilities to help the scripts that generate the Torizon OS applications and containers.

If you want to know more about check [Toradex developer website](https://developer.toradex.com/torizon/application-development/ide-extension/).
