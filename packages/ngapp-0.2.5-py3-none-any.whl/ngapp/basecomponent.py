# for backward compatility
print(
    "WARNING: Using webapp.basecomponent is deprecated. Module has been moved to webapp.components.basecomponent"
)
from .components.basecomponent import *
