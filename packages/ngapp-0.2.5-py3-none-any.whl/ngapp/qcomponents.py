# for backward compatility
print(
    "WARNING: Using webapp.visualization is deprecated. Module has been moved to webapp.components.qcomponents"
)
from .components.qcomponents import *
