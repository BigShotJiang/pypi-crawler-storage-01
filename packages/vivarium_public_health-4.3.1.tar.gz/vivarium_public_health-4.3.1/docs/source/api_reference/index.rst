API Reference
=============

.. automodule:: vivarium_public_health

.. toctree::
   :maxdepth: 2
   :glob:

   *
   */index
