from .core import search_torrents_async
from .core import search_torrents

__all__ = ["search_torrents_async", "search_torrents"]