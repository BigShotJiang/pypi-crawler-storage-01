class ResParserError(Exception):
    """Exception for the parsers"""

    pass