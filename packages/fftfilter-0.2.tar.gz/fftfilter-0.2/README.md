# FFT-Filter

This package provides an interactive program to remove periodic baselines from measurements by FFT-filtering the data.