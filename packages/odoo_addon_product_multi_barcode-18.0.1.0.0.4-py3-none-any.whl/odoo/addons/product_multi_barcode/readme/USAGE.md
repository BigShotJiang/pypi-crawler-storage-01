A list of barcodes is available for each product with a priority, so a
main barcode code is defined.
