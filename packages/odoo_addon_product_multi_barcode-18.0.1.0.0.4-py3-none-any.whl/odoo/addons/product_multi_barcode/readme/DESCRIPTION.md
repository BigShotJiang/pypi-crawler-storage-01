This module allows you to define multiple barcodes on products.
