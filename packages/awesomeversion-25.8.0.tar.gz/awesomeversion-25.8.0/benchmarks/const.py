"""Benchmark constants."""

DEFAULT_RUNS = 1_000
