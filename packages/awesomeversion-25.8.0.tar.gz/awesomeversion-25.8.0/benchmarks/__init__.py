"""Init benchmarks package."""
