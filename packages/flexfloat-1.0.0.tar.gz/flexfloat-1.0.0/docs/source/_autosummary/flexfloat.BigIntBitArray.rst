﻿flexfloat.BigIntBitArray
========================

.. currentmodule:: flexfloat

.. autoclass:: BigIntBitArray