﻿flexfloat.math
==============

.. currentmodule:: flexfloat

.. automodule:: math