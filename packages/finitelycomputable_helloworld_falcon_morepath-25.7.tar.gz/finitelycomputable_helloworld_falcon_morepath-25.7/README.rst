==========================
HelloWorld-Falcon-Morepath
==========================

This application adapts the hello_world endpoint provided in
finitelycomputable.helloworld_morepath to be provided in
finitelycomputable.helloworld_falcon using the Falcon framework.
