patentes-vehiculares-chile/
├── src/
│   └── patentes_vehiculares_chile/
│       ├── __init__.py
│       ├── tipos.py
│       └── validador.py
├── .gitignore
├── CHANGELOG.md
├── DESARROLLO.md
├── ESTRUCTURA.md
├── LICENSE
├── MANIFEST.in
├── pyproject.toml
└── README.md