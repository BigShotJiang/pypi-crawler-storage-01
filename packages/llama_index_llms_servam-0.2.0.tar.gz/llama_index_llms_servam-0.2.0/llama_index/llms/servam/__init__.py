from llama_index.llms.servam.base import Servam

__all__ = ["Servam"]
