### Installation
```bash
 pip install -U git+https://github.com/link-yundi/quda.git
```