export const ApplicationColors = {
  logging: {
    debug: "var(--bs-secondary)",
    info: "var(--bs-blue)",
    warning: "var(--bs-warning)",
    error: "var(--bs-danger)",
    critical: "var(--bs-danger)",
  },
};
