# sage_setup: distribution = sagemath-msolve
