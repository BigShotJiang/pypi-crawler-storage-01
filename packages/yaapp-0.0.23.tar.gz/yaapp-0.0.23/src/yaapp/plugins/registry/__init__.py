"""
Registry Plugin - Service Registry for Microservices
"""

from .plugin import Registry

__all__ = ['Registry']