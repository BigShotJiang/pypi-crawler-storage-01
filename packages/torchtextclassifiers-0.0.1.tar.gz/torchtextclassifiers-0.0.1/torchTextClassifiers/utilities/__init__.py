"""
Init script.
"""
