class ParsingError(Exception):
    """Custom exception for errors during HTML parsing."""

    pass
