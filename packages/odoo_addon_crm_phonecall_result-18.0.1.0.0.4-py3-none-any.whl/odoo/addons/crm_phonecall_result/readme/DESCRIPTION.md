Adds a field to set the result of CRM phone calls, allows creating new result options, and enables filtering and grouping by call result.
