TRAINER_STATUS_NAME = 'train_status.pt'
