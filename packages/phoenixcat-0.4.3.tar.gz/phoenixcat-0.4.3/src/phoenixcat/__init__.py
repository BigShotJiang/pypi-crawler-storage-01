from ._init import _init_fn


__version__ = "0.4.3"


def init():
    _init_fn()
