"""vec2tidb - A CLI tool for migrating data from third-party vector databases to TiDB."""

__version__ = "0.0.1"
