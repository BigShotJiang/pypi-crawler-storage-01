"""The ansible-creator application."""
