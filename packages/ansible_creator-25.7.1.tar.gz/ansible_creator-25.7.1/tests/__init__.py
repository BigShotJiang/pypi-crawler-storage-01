"""Tests for ansible-creator."""
