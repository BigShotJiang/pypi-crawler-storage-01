"""Simply the GDSFactory+ version."""

__version__ = "0.55.5"
