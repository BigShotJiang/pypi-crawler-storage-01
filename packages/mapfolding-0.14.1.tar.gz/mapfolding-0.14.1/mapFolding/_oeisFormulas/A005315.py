from mapFolding._oeisFormulas.A005316 import A005316

def A005315(n: int) -> int:
	return A005316(2 * n - 1)
