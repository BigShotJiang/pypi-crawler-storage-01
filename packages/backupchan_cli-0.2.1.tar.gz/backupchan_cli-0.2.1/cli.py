#!/usr/bin/python3

from backupchan_cli.main import main

if __name__ == "__main__":
    main()
