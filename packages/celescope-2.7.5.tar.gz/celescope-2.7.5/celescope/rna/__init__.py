STEPS = [
    "mkref",
    "sample",
    "starsolo",
    "analysis",
    "cells",
]
__ASSAY__ = "rna"
REMOVE_FROM_MULTI = {
    "mkref",
    "cells",
}
