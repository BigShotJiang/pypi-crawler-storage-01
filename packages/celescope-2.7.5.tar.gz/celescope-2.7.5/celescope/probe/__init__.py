STEPS = [
    "sample",
    "barcode",
]
__ASSAY__ = "probe"
