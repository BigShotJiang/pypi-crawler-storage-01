# Authors: scikit-learn-contrib developers
# License: BSD 3 clause
