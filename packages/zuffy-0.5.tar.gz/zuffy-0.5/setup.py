from setuptools import setup, find_packages

setup(
    name="zuffy",
    version="0.5",
    description="Use GP to induce Fuzzy Pattern Trees",
    author="PXOM",
    packages=find_packages(),
    install_requires=[
     ],
    )