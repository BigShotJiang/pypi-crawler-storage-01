"""A module for simply-defined analysis calculation functions."""
