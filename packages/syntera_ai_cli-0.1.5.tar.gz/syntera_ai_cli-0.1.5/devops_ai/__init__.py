"""
Agentic DevOps AI CLI - An intelligent CLI tool for DevOps engineers
"""

__version__ = "0.1.0" 