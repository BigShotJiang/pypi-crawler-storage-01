"""Servidor REST principal de AGIX."""

from .api import app

__all__ = ["app"]
