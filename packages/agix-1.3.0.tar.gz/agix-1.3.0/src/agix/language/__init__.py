"""Funciones y herramientas lingüísticas."""

from .emotional_translator import SemanticEmotionalTranslator

__all__ = ["SemanticEmotionalTranslator"]
