"""Motores lógicos disponibles."""

from .base import LogicEngine

__all__ = ["LogicEngine"]
