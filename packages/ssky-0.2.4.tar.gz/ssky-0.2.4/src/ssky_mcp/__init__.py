"""
Ssky MCP (Model Context Protocol) Server Package

This package provides MCP server functionality for the ssky Bluesky client.
"""