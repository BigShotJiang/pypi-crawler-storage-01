#coding=utf-8

__version__="0.1.7"
__author__ = "Zzz, emails: 1174534295@qq.com, 1309458652@qq.com"
__doc__="""
key_musicz.keyz 通过pynput库监听按键
key_musicz.sourcez 通过pyfluidsynth读取sf2文件和生成音频数据
key_musicz.soundz 通过pyaudio播放声音
key_musicz.playz 调用其他模块，监听按键，读取sf2文件，播放音乐
"""
