__version__ = "0.7.0"

from jupytergis_lab import GISDocument, explore  # noqa
