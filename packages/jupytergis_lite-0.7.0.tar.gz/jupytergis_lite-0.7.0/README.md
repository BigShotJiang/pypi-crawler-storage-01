# JupyterGIS meta-package for JupyterLite
