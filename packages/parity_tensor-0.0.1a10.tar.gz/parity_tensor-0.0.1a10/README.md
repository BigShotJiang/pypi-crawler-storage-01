# A parity tensor package.
