__author__ = 'Bing Ads SDK Team'
__email__ = 'bing_ads_sdk@microsoft.com'

from .extensions import *
