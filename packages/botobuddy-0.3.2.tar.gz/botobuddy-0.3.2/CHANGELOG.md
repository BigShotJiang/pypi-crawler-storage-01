# 0.3.2

- Downgraded rich to 13.0.0 to fix compatibility issues with `aws-sam-cli`
- Added `botobuddy --version` option

# 0.3.1

- Fixed fast download concurrency issue
- Added support for default session config values

# 0.3.0

- Add `botobuddy.s3.S3Uri` class
- Add `botobuddy.utils.dslice` function
- Add `botobuddy.sagemaker.analyse_human_effort` function

# 0.2.0

- Some interface refactoring
