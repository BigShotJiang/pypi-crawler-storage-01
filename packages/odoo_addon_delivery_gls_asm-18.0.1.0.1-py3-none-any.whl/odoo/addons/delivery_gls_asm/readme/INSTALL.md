Este módulo necesita la librería python suds-py3 y depende igualmente de
los módulos de OCA/delivery-carrier delivery_package_number y
delivery_state.

La API de GLS/ASM no provee métodos de cálculo de precio, de modo que
para poder calcular los costes de envío sería recomendable instalar el
módulo delivery_price_method.
