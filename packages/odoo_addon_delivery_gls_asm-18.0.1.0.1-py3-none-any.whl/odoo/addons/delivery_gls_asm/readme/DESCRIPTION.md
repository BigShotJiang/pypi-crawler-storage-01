Este módulo integra la API de GLS España (antigua API de ASM) con Odoo.
No es válido para integraciones de GLS en otros países, que podrían usar
otras APIs.
