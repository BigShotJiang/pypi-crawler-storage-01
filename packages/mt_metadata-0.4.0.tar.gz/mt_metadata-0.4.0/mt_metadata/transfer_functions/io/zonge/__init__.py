# package file

from .zonge import ZongeMTAvg

__all__ = ["ZongeMTAvg"]
