# package file

from .edi import EDI

__all__ = ["EDI"]
