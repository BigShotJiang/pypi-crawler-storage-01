"""
Example Data
"""

from pathlib import Path

data_dir = Path(__file__)

STATIONXML_01 = data_dir.joinpath("fdsn-station_2021-02-12T23_28_49.xml")
STATIONXML_02 = data_dir.joinpath("StationXML_REW09.xml")
