mt\_metadata.transfer\_functions.tf package
===========================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.tf.standards

Submodules
----------

mt\_metadata.transfer\_functions.tf.comment module
--------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.tf.comment
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.tf.station module
--------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.tf.station
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.tf.statistical\_estimate module
----------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.tf.statistical_estimate
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.tf.transfer\_function module
-------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.tf.transfer_function
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.tf
    :members:
    :undoc-members:
    :show-inheritance:
