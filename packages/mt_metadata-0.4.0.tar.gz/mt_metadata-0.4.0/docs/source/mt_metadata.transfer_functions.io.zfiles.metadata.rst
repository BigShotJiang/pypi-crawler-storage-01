mt\_metadata.transfer\_functions.io.zfiles.metadata package
===========================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.zfiles.metadata.standards

Submodules
----------

mt\_metadata.transfer\_functions.io.zfiles.metadata.channel module
------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zfiles.metadata.channel
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.zfiles.metadata
    :members:
    :undoc-members:
    :show-inheritance:
