mt\_metadata.transfer\_functions.io package
===========================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.edi
    mt_metadata.transfer_functions.io.emtfxml
    mt_metadata.transfer_functions.io.jfiles
    mt_metadata.transfer_functions.io.zfiles
    mt_metadata.transfer_functions.io.zonge

Submodules
----------

mt\_metadata.transfer\_functions.io.tools module
------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.tools
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io
    :members:
    :undoc-members:
    :show-inheritance:
