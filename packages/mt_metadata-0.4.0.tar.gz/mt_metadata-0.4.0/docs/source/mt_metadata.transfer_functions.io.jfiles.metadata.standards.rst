mt\_metadata.transfer\_functions.io.jfiles.metadata.standards package
=====================================================================

Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles.metadata.standards
    :members:
    :undoc-members:
    :show-inheritance:
