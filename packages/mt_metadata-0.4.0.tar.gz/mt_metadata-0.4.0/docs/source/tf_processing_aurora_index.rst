.. role:: red
.. role:: blue
.. role:: navy
Aurora
==============================

.. toctree::
    :maxdepth: 1
    :caption: Metadata Definitions

    tf_processing_aurora_band
    tf_processing_aurora_channel
    tf_processing_aurora_channel_nomenclature
    tf_processing_aurora_decimation
    tf_processing_aurora_decimation_level
    tf_processing_aurora_estimator
    tf_processing_aurora_processing
    tf_processing_aurora_regression
    tf_processing_aurora_run
    tf_processing_aurora_station
    tf_processing_aurora_stations
    tf_processing_aurora_window
