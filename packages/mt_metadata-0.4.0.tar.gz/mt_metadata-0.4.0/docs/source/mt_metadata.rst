mt\_metadata package
====================

Subpackages
-----------

.. toctree::

    mt_metadata.base
    mt_metadata.data
    mt_metadata.timeseries
    mt_metadata.transfer_functions
    mt_metadata.utils

Module contents
---------------

.. automodule:: mt_metadata
    :members:
    :undoc-members:
    :show-inheritance:
