mt\_metadata.transfer\_functions.io.edi package
===============================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.edi.metadata

Submodules
----------

mt\_metadata.transfer\_functions.io.edi.edi module
--------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.edi.edi
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.edi
    :members:
    :undoc-members:
    :show-inheritance:
