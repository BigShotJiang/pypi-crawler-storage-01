mt\_metadata.transfer\_functions.io.edi.metadata package
========================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.edi.metadata.standards

Submodules
----------

mt\_metadata.transfer\_functions.io.edi.metadata.data\_section module
---------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.edi.metadata.data_section
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.edi.metadata.define\_measurement module
---------------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.edi.metadata.define_measurement
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.edi.metadata.emeasurement module
--------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.edi.metadata.emeasurement
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.edi.metadata.header module
--------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.edi.metadata.header
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.edi.metadata.hmeasurement module
--------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.edi.metadata.hmeasurement
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.edi.metadata.information module
-------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.edi.metadata.information
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.edi.metadata
    :members:
    :undoc-members:
    :show-inheritance:
