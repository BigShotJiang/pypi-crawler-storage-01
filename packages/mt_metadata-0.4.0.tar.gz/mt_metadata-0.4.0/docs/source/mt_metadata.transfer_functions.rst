mt\_metadata.transfer\_functions package
========================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io
    mt_metadata.transfer_functions.tf

Submodules
----------

mt\_metadata.transfer\_functions.core module
--------------------------------------------

.. automodule:: mt_metadata.transfer_functions.core
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions
    :members:
    :undoc-members:
    :show-inheritance:
