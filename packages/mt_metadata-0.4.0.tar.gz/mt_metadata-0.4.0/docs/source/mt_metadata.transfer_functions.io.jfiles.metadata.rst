mt\_metadata.transfer\_functions.io.jfiles.metadata package
===========================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.jfiles.metadata.standards

Submodules
----------

mt\_metadata.transfer\_functions.io.jfiles.metadata.birrp\_angles module
------------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles.metadata.birrp_angles
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.jfiles.metadata.birrp\_block module
-----------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles.metadata.birrp_block
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.jfiles.metadata.birrp\_parameters module
----------------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles.metadata.birrp_parameters
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.jfiles.metadata.header module
-----------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles.metadata.header
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles.metadata
    :members:
    :undoc-members:
    :show-inheritance:
