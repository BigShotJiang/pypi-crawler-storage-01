mt\_metadata.transfer\_functions.io.emtfxml package
===================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.emtfxml.metadata

Submodules
----------

mt\_metadata.transfer\_functions.io.emtfxml.emtfxml module
----------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.emtfxml.emtfxml
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.emtfxml
    :members:
    :undoc-members:
    :show-inheritance:
