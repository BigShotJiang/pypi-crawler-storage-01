.. role:: red
.. role:: blue
.. role:: navy
Time Series Filters
==============================

.. toctree::
    :maxdepth: 1
    :caption: Metadata Definitions

    ts_filter_channel_response_filter
    ts_filter_coefficient_filter
    ts_filter_f_i_r_filter
    ts_filter_frequency_response_table_filter
    ts_filter_pole_zero_filter
    ts_filter_time_delay_filter
