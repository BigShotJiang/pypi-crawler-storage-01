.. role:: red
.. role:: blue
.. role:: navy
J-Files
==============================

.. toctree::
    :maxdepth: 1
    :caption: Metadata Definitions

    tf_jfile_birrp_angles
    tf_jfile_birrp_block
    tf_jfile_birrp_parameters
    tf_jfile_header
