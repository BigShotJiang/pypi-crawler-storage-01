.. role:: red
.. role:: blue
.. role:: navy

Experiment
==========

