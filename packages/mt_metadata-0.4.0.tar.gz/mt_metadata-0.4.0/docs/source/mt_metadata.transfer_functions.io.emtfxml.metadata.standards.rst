mt\_metadata.transfer\_functions.io.emtfxml.metadata.standards package
======================================================================

Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.emtfxml.metadata.standards
    :members:
    :undoc-members:
    :show-inheritance:
