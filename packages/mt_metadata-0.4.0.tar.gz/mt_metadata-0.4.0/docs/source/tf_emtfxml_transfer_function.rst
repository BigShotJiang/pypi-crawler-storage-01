.. role:: red
.. role:: blue
.. role:: navy

TransferFunction
================

