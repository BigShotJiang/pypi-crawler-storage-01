mt\_metadata.transfer\_functions.io.zfiles.metadata.standards package
=====================================================================

Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.zfiles.metadata.standards
    :members:
    :undoc-members:
    :show-inheritance:
