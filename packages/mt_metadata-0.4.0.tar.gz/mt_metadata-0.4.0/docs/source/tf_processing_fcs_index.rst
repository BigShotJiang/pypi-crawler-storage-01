.. role:: red
.. role:: blue
.. role:: navy
Fourier Coefficients
==============================

.. toctree::
    :maxdepth: 1
    :caption: Metadata Definitions

    tf_processing_fcs_channel
    tf_processing_fcs_decimation
    tf_processing_fcs_f_c
