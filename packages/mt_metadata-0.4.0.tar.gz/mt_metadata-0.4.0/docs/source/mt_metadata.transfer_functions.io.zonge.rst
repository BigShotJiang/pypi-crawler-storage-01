mt\_metadata.transfer\_functions.io.zonge package
=================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.zonge.metadata

Submodules
----------

mt\_metadata.transfer\_functions.io.zonge.zonge module
------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.zonge
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.zonge
    :members:
    :undoc-members:
    :show-inheritance:
