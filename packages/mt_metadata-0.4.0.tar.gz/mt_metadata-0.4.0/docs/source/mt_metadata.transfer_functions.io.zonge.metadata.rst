mt\_metadata.transfer\_functions.io.zonge.metadata package
==========================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.zonge.metadata.standards

Submodules
----------

mt\_metadata.transfer\_functions.io.zonge.metadata.auto module
--------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.auto
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.d\_plus module
-----------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.d_plus
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.gps module
-------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.gps
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.header module
----------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.header
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.mt\_edit module
------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.mt_edit
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.phase\_slope module
----------------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.phase_slope
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.rx module
------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.rx
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.survey module
----------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.survey
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.tx module
------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.tx
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.transfer\_functions.io.zonge.metadata.unit module
--------------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata.unit
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.zonge.metadata
    :members:
    :undoc-members:
    :show-inheritance:
