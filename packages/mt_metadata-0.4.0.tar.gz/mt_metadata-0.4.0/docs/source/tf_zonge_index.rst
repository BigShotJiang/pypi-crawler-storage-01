.. role:: red
.. role:: blue
.. role:: navy
Zonge AVG
==============================

.. toctree::
    :maxdepth: 1
    :caption: Metadata Definitions

    tf_zonge_auto
    tf_zonge_c_h
    tf_zonge_d_plus
    tf_zonge_g_d_p
    tf_zonge_g_p_s
    tf_zonge_header
    tf_zonge_job
    tf_zonge_line
    tf_zonge_m_t_edit
    tf_zonge_m_t_f_t24
    tf_zonge_phase_slope
    tf_zonge_rx
    tf_zonge_s_t_n
    tf_zonge_survey
    tf_zonge_tx
    tf_zonge_unit
