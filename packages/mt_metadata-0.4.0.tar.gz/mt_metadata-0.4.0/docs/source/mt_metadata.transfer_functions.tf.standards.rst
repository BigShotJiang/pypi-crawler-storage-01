mt\_metadata.transfer\_functions.tf.standards package
=====================================================

Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.tf.standards
    :members:
    :undoc-members:
    :show-inheritance:
