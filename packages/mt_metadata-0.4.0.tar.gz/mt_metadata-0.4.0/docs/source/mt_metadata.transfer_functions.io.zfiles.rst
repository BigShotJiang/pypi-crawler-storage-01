mt\_metadata.transfer\_functions.io.zfiles package
==================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.zfiles.metadata

Submodules
----------

mt\_metadata.transfer\_functions.io.zfiles.zmm module
-----------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.zfiles.zmm
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.zfiles
    :members:
    :undoc-members:
    :show-inheritance:
