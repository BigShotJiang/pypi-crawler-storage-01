.. role:: red
.. role:: blue
.. role:: navy
EDI
==============================

.. toctree::
    :maxdepth: 1
    :caption: Metadata Definitions

    tf_edi_data_section
    tf_edi_define_measurement
    tf_edi_e_measurement
    tf_edi_h_measurement
    tf_edi_header
    tf_edi_information
