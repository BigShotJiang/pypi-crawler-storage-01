mt\_metadata.transfer\_functions.io.jfiles package
==================================================

Subpackages
-----------

.. toctree::

    mt_metadata.transfer_functions.io.jfiles.metadata

Submodules
----------

mt\_metadata.transfer\_functions.io.jfiles.jfile module
-------------------------------------------------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles.jfile
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.transfer_functions.io.jfiles
    :members:
    :undoc-members:
    :show-inheritance:
