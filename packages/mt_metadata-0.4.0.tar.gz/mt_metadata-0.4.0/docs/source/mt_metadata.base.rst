mt\_metadata.base package
=========================

Submodules
----------

mt\_metadata.base.helpers module
--------------------------------

.. automodule:: mt_metadata.base.helpers
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.base.metadata module
---------------------------------

.. automodule:: mt_metadata.base.metadata
    :members:
    :undoc-members:
    :show-inheritance:

mt\_metadata.base.schema module
-------------------------------

.. automodule:: mt_metadata.base.schema
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: mt_metadata.base
    :members:
    :undoc-members:
    :show-inheritance:
