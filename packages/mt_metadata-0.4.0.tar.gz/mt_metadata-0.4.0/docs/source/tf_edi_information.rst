.. role:: red
.. role:: blue
.. role:: navy

Information
===========

