=======
Credits
=======

This project is in cooperation with the Incorporated Research Institutes of Seismology (IRIS), the U.S. Geological Survey (USGS), and other collaborators.  Facilities of the IRIS Consortium are supported by the National Science Foundation’s Seismological Facilities for the Advancement of Geoscience (SAGE) Award under Cooperative Support Agreement EAR-1851048.  USGS is partially funded through the Community for Data Integration and IMAGe through the Minerals Resources Program.  

Development Lead
----------------

* Jared Peacock <jpeacock@usgs.gov>

Contributors
------------

* Anna Kelbert
* Karl Kappler
* Lindsey Heagy
* Andy Frassetto
* Tim Ronan

