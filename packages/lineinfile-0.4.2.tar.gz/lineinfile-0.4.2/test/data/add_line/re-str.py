line = "gnusto=cleesh"
args = {"regexp": r"^bar="}
options = ["-e", "^bar="]
