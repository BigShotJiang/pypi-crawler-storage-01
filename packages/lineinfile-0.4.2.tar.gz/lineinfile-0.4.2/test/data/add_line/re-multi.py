line = "gnusto=cleesh"
args = {"regexp": r"^foo="}
options = ["-e", "^foo="]
