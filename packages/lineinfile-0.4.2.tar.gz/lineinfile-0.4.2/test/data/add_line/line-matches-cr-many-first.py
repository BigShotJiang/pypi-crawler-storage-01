input_file = "input-repeat.txt"
line = "foo=bar\r"
args = {"match_first": True}
options = ["--match-first"]
nonuniversal_lines = True
