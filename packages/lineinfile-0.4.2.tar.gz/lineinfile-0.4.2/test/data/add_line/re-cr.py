input_file = "input-cr-diff.txt"
line = "gnusto=cleesh"
args = {"regexp": r"=stuff$"}
options = ["-e", "=stuff$"]
nonuniversal_lines = True
