input_file = "input-empty.txt"
line = "gnusto=cleesh"
args = {}
options = []
