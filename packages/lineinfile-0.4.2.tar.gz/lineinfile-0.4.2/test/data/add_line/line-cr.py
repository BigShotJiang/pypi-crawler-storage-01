line = "gnusto=cleesh\r"
args = {}
options = []
nonuniversal_lines = True
