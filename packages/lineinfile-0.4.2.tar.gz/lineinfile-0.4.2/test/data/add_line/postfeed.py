line = "gnusto=cleesh"
args = {"regexp": r"^postfeed="}
options = ["-e", "^postfeed="]
