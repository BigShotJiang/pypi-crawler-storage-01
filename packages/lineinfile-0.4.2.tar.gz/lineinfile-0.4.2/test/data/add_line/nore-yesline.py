line = "bar=quux"
args = {"regexp": "notinfile"}
options = ["-e", "notinfile"]
