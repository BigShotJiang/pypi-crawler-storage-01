regexp = r"^foo="
