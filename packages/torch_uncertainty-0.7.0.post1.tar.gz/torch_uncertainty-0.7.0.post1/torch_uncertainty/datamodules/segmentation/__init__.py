# ruff: noqa: F401
from .camvid import CamVidDataModule
from .cityscapes import CityscapesDataModule
from .muad import MUADDataModule
