# ruff: noqa: F401
from .deeplab import DeepLabBaseline
from .segformer import SegFormerBaseline
