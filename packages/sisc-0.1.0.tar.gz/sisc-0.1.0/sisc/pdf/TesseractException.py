class TesseractException(Exception):
    pass
