class NotSupportedException(Exception):
    pass