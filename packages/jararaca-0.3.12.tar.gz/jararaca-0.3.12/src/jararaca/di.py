from jararaca.microservice import Container

__all__ = [
    "Container",
]
