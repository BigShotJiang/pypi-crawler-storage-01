def hello():
    return f"Salut les gens !"

if __name__ == "__main__":
    print(hello())
