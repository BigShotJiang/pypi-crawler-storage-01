agentle.agents.a2a.message\_parts.data\_part
============================================

.. automodule:: agentle.agents.a2a.message_parts.data_part

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      Any
      BaseModel
      DataPart
   