agentle.agents.a2a.a2a\_interface
=================================

.. automodule:: agentle.agents.a2a.a2a_interface

   
   .. rubric:: Functions

   .. autosummary::
   
      cast
   
   .. rubric:: Classes

   .. autosummary::
   
      A2AInterface
      A2AInterfaceOptions
      Any
      Coroutine
      PushNotificationResource
      Task
      TaskGetResult
      TaskManager
      TaskQueryParams
      TaskResource
      TaskSendParams
      TasksWrapper
   