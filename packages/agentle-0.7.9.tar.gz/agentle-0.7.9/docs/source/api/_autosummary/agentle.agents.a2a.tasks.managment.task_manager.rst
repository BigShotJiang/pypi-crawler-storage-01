agentle.agents.a2a.tasks.managment.task\_manager
================================================

.. automodule:: agentle.agents.a2a.tasks.managment.task_manager

   
   .. rubric:: Functions

   .. autosummary::
   
      abstractmethod
   
   .. rubric:: Classes

   .. autosummary::
   
      ABC
      Any
      JSONRPCResponse
      Task
      TaskGetResult
      TaskManager
      TaskQueryParams
      TaskSendParams
   