agentle.agents.a2a.models.json\_rpc\_error
==========================================

.. automodule:: agentle.agents.a2a.models.json_rpc_error

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      Any
      BaseModel
      JSONRPCError
   