agentle.agents.a2a.tasks
========================

.. automodule:: agentle.agents.a2a.tasks

   
   .. rubric:: Classes

   .. autosummary::
   
      SendTaskResponse
      Task
      TaskArtifactUpdateEvent
      TaskGetResult
      TaskQueryParams
      TaskSendParams
      TaskState
      TaskStatus
      TaskStatusUpdateEvent
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   managment
   send_task_request
   send_task_response
   task
   task_artifact_update_event
   task_get_result
   task_query_params
   task_send_params
   task_state
   task_status
   task_status_update_event
