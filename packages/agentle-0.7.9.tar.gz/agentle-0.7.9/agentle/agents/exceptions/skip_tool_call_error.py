class SkipToolCallError(Exception):
    """
    Exception raised when a tool call should be skipped.
    """

    pass
