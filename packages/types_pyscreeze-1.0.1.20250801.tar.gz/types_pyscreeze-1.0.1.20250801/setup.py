
from setuptools import setup

setup(package_data={'pyscreeze-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
