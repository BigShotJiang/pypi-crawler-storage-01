# src/prof/start.py

from .main import main  # يستدعي الدالة المشفرة داخل main.pyd

if __name__ == "__main__":
    main()
