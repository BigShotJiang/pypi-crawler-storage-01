# -*- coding: utf-8 -*-

QUOTE = 'quote'
QUOTE_DEPTH = 'quotedepth'
QUOTE_FUTURE = 'future'
QUOTE_OPTION = 'option'
TRADE_TICK = 'tradetick'

TRADE_ASSET = 'trade/asset'
TRADE_POSITION = 'trade/position'
TRADE_ORDER = 'trade/order'
TRADE_TRANSACTION = 'trade/transaction'
