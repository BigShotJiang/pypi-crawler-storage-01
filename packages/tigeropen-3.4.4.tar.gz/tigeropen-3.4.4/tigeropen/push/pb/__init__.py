import os

# disable protobuf version check
os.environ.setdefault('TEMORARILY_DISABLE_PROTOBUF_VERSION_CHECK', 'true')
