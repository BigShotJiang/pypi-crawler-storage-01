.. :changelog:

History
-------

0.2.0 (2025-01-15)
++++++++++++++++++

* Add compatibility patches for sklearn 1.6+.

0.1.1 (2024-12-13)
++++++++++++++++++

* Fix in saving tensorflow models to disk.

0.1.0 (2024-11-18)
++++++++++++++++++

* First release on PyPI.
