from volworld_aws_api_common.api.enum.ProjectModeType import ProjectModeType


class ProjectMode:
    type = ProjectModeType.Combined
    testUrlPrefix = ''