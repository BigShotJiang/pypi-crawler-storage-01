class ATestRequest:
    def __init__(self, print_url_params):
        self.print_url_params = print_url_params
        self.print_long_att = True
