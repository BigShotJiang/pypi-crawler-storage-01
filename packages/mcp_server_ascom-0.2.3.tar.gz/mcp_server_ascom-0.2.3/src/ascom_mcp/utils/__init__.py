"""Utility modules for ASCOM MCP server."""
