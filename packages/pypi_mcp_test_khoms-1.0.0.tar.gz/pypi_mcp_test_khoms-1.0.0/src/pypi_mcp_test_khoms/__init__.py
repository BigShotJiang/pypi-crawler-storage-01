from .pypi_mcp_test_khoms import mcp

def main() -> None:
    mcp.run()