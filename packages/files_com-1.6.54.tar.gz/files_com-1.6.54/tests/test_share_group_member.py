import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import ShareGroupMember
from files_sdk import share_group_member

class ShareGroupMemberTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()