
# hyperpod-pytorch-job-template

## Installation
`pip install hyperpod-pytorch-job-template`

## Overview 
This package provides the configuration schema for HyperpodPytorchJobOperator.

