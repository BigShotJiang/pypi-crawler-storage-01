::: abstract_dataloader.generic
    options:
        heading: "Generic Component Implementations"
        show_root_toc_entry: true
        show_root_heading: true
        heading_level: 1
