#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tests of Automation Library for Denon AVR receivers.

:copyright: (c) 2023 by Oliver Goetz.
:license: MIT, see LICENSE for more details.
"""
