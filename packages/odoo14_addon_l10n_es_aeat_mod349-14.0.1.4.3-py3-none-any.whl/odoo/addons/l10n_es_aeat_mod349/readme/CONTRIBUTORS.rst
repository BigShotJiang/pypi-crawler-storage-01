* Luis Manuel Angueira Blanco (Pexego)
* Omar Castiñeira Saavedra<omar@pexego.es>
* Miguel López (Top Consultant)
* Ignacio Martínez (Top Consultant)
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Ángel Moya
  * Luis M. Ontalba
  * Carlos Daudén

* ForgeFlow (http://www.forgeflow.com)

  * Jordi Ballester <jordi.ballester@forgeflow.com>
  * Aarón Henríquez

* Aitor Bouzas <aitor.bouzas@adaptivecity.com>
* Acysos:

  * Ignacio Ibeas
* Manuel Regidor <manuel.regidor@sygel.es>

* NuoBiT (http://www.nuobit.com)

  * Eric Antones <eantones@nuobit.com>
