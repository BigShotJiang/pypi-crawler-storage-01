__all__ = [
    'api_exception',
    'error_exception',
    'validation_error_exception',
]
