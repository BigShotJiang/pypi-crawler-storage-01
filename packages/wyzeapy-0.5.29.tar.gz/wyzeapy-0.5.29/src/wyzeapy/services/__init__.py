"""
This module provides the services for interacting with Wyze devices.
"""
