- When could have several lines from the same template with different secondary units.
  In that case, the use of the matrix is discarded to avoid missmatching values. From
  that moment, the products are forced to be configured with the regular product
  configurator.
- The client side is roughly implemented right now. Probably we'll fix some of the
  most obvious bugs but our roadmap is headed to v17 with the Owl webclient.
