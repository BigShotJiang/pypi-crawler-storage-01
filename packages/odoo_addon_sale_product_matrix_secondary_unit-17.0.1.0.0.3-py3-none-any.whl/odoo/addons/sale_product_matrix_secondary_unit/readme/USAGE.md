To use this module, you need to:

1. Go to a sales order and add the configured product.
2. The matrix dialog will show up and there you'll be able to select the available
   secondary units.
3. If a default sale secondary unit is set, it will selected in the dialog already.
