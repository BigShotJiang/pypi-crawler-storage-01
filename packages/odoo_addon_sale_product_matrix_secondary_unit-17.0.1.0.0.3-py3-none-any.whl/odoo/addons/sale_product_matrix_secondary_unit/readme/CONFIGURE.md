To configure this module, you need to:

- Go to a product with variants or create one.
- In the *Attributes and variants* tab, *Sales Variant Selection* section, select
  **Order grid entry**.
- In the *General information* tab, *Secondary unit of measure* section, add one or
  several secondary units.
- You can also set a default **Sale secondary unit**.
