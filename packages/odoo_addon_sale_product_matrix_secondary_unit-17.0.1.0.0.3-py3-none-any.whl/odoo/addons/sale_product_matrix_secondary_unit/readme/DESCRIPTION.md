With this module we'll be able to set the secondary units in the product matrix for
a quick quotation for those products using this kind of configurator.
