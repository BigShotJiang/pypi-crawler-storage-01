# This file is now obsolete. All functionality has been replaced by
# ObjectiveValueRecorder and ObjectiveBoundRecorder in mbls.cpsat.callbacks.
#
# See those classes for modern, extensible, and type-safe progress logging utilities.
#
# This file is retained only for reference and will be removed in a future release.
