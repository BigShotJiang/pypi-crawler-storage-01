Alas Ce0 Client API
=======================

A project for developing a client to access the Alas.Ce0 API

----

This is the README file for the project.

"generate dist and wheel"
python setup.py sdist bdist_wheel

"upload to pypi project"
twine upload dist/*