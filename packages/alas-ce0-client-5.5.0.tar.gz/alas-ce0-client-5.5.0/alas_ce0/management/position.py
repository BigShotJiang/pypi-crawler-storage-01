from alas_ce0.common.client_base import EntityClientBase


class PositionClient(EntityClientBase):
    entity_endpoint_base_url = '/management/positions/'
