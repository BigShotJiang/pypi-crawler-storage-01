from alas_ce0.common.client_base import EntityClientBase


class RoleClient(EntityClientBase):
    entity_endpoint_base_url = '/management/roles/'
