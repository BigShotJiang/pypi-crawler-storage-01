from alas_ce0.common.client_base import EntityClientBase


class FeatureClient(EntityClientBase):
    entity_endpoint_base_url = '/management/features/'
