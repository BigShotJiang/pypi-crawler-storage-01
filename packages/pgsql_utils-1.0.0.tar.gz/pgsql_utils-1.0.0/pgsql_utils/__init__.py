"""
PgSQL Utils 包初始化文件
"""

from .postgresql_utils import PostgreSQLUtils, db

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__license__ = "MIT"

__all__ = ["PostgreSQLUtils", "db"]
