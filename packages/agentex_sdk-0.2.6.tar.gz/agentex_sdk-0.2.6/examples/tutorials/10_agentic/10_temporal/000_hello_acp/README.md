# [Agentic] Hello ACP with Temporal

This tutorial demonstrates how to implement the agentic ACP type with Temporal workflows in AgentEx agents.

## Official Documentation

[000 Hello Temporal Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/temporal/hello_acp/)