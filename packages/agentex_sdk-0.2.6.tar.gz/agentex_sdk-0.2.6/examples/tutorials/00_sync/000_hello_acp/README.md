# [Sync] Hello ACP

This is a simple AgentEx agent that just says hello and acknowledges the user's message to show which ACP methods need to be implemented for the sync ACP type.

## Official Documentation

[000 Hello ACP](https://dev.agentex.scale.com/docs/tutorials/sync/000_hello_acp)
