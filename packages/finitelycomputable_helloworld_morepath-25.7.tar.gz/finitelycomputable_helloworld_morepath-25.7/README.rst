===================
HelloWorld-Morepath
===================

finitelycomputable.helloworld_morepath provides a hello_world endpoint using
the Morepath framework wherever it is mounted.
