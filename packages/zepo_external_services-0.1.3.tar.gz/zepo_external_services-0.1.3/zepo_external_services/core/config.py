from pydantic import BaseModel


class BaseConfig(BaseModel):
    """Base configuration class for providers."""

    pass
