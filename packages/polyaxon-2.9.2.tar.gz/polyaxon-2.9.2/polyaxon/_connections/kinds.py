from vents.providers.kinds import ProviderKind

V1ConnectionKind = ProviderKind
