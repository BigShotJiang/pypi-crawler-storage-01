class ContainerStatuses:
    RUNNING = "running"
    WAITING = "waiting"
    TERMINATED = "terminated"
