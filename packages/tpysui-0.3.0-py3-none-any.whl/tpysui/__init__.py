#    Copyright Frank V. Castellucci
#    SPDX-License-Identifier: Apache-2.0

# -*- coding: utf-8 -*-

"""TermPysui central."""

from .screens import PyCfgScreen, MystenCfgScreen
from .modals import *
