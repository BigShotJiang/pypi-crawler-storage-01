#    Copyright Frank V. Castellucci
#    SPDX-License-Identifier: Apache-2.0

# -*- coding: utf-8 -*-

"""Version information for tpysui."""

# Read in command line and posting to PyPi
__version__ = "0.3.0"
"""tpysui Version."""
