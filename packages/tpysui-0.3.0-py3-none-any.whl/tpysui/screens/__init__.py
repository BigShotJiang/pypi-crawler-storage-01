#    Copyright Frank V. Castellucci
#    SPDX-License-Identifier: Apache-2.0

# -*- coding: utf-8 -*-

"""Screens central."""

from .configs import PyCfgScreen
from .sui_config import MystenCfgScreen
