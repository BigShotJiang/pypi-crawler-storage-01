from __future__ import annotations

from datetime import datetime


def now():
    return datetime.now()
