# python 工作依赖库
``` shell
# init
uv sync

# install pip or uv
pip install -U fyuneru
uv add -U fyuneru
```