"""Metrics collection and processing package."""
