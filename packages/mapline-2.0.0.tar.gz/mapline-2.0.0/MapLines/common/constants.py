import numpy as np
"""This module contains definition of MapLine.common.constants to be used
globally across the MapLine modules
"""

__version__ = 'MapLine v2.0.0'

