from django.contrib import admin

from .models import Dialog, Exchange

admin.site.register(Dialog)
admin.site.register(Exchange)
