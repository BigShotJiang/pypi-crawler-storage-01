# Retrophase

This package provides an interactive program to retrospectively change the phase of measurements.
Its intended usecase are measurements performed with lock-in amplifiers.
If the X and Y components are recorded, the program allows to change the phase in hindsight.