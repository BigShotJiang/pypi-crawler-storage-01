"""
Main entry point for the letterhead_pdf package.

This allows the package to be executed with: python -m letterhead_pdf
"""

from letterhead_pdf.main import main

if __name__ == "__main__":
    main()
