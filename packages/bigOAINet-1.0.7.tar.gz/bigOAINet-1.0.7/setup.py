from setuptools import setup, find_packages

setup(
    name="bigOAINet",
    version="1.0.7",
    description="bigO AI Network",
    author="jerry1979",
    author_email="6018421@qq.com",
    url="http://www.xtbeiyi.com/",
    packages=find_packages(),
)
# .\py310\python.exe -m pip install twine
# .\py310\python.exe setup.py sdist bdist_wheel
# .\py310\python.exe -m twine upload dist/*
