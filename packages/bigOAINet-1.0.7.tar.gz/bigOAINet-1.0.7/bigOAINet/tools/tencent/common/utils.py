# -*- coding: utf-8 -*-
import sys

def is_python3():
    if sys.version > '3':
        return True
    return False