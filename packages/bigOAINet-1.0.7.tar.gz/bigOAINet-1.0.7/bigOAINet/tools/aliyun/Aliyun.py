        
base_url = 'https://dashscope.aliyuncs.com/compatible-mode/v1'
# 向量配置
vector_api_key = 'XXXXXX'
vector_api_url = 'XXXXXX'
    
if __name__ == '__main__':

    a = 1
    
    # import pkgutil

    # packages = [name for _, name, _ in pkgutil.walk_packages()]
    # print(packages)

    
    # import py_compile
    # py_compile.compile('Vector.py')
    # print('ddd')
    
    # import numpy as np
    # import pandas as pd
    # import matplotlib.pyplot as plt

    # data = np.random.randn(100, 2)
    # df = pd.DataFrame(data, columns=['A', 'B'])
    # df.plot()
    # plt.show()
    
    # import pkgutil

    # packages = [name for _, name, _ in pkgutil.walk_packages()]
    # print(packages)