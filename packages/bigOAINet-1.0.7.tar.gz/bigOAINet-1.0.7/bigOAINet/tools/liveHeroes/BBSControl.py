import mxupy as mu

from liveheroes.m.Models import *

class BBSControl(mu.EntityXControl):

    class Meta:
        model_class = BBS
