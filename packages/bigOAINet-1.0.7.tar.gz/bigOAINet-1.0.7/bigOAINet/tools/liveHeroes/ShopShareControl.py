import mxupy as mu

from liveheroes.m.Models import *

class ShopShareControl(mu.EntityXControl):

    class Meta:
        model_class = ShopShare

    


