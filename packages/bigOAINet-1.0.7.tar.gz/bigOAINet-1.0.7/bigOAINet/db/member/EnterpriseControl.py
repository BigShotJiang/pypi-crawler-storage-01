import mxupy as mu
import bigOAINet as bigo

class EnterpriseControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.Enterprise
        
        
        