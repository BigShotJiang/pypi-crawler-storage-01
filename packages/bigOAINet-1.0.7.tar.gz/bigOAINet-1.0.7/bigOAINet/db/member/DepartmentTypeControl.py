import mxupy as mu
import bigOAINet as bigo

class DepartmentTypeControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.DepartmentType
        
        
        
        