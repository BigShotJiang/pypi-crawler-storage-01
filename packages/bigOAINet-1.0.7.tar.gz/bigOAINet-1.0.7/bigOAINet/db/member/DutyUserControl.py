import mxupy as mu
import bigOAINet as bigo

class DutyUserControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.DutyUser
        
        
        
        
        