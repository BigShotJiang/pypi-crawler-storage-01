import mxupy as mu
import bigOAINet as bigo

class DepartmentUserControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.DepartmentUser
        
        
        
        