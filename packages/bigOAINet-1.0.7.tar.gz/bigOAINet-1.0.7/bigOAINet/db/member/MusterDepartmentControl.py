import mxupy as mu
import bigOAINet as bigo

class MusterDepartmentControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.MusterDepartment
        
        
 