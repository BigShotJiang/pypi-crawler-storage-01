import mxupy as mu
import bigOAINet as bigo

class FriendControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.Friend
        
        
        
        