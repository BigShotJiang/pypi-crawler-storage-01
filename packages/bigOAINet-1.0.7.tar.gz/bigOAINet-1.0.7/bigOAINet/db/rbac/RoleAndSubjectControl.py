import mxupy as mu
import bigOAINet as bigo

class RoleAndSubjectControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.RoleAndSubject
