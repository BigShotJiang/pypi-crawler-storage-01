import mxupy as mu
import bigOAINet as bigo

class RightAndDataControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.RightAndData
        