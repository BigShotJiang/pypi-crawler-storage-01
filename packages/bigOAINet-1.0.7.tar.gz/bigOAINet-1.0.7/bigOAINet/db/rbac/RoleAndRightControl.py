import mxupy as mu
import bigOAINet as bigo

class RoleAndRightControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.RoleAndRight
