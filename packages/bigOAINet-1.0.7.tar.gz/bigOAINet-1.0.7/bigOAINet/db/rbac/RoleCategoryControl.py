import mxupy as mu
import bigOAINet as bigo

class RoleCategoryControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.RoleCategory
