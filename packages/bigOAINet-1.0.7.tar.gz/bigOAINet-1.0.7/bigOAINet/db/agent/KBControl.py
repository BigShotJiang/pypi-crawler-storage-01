import mxupy as mu
import bigOAINet as bigo


class KBControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.KB
