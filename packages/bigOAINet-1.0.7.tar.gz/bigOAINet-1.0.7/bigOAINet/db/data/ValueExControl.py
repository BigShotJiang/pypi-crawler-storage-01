import mxupy as mu
import bigOAINet as bigo

class ValueExControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.ValueEx
        
        
        
        
        
        
