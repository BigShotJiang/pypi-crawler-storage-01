import mxupy as mu
import bigOAINet as bigo

class KeyValueControl(mu.EntityXControl):
    class Meta:
        model_class = bigo.KeyValue
        
        
        
        
