def ping():
    """ 测试网络响应

    Returns:
        str: 响应结果
    """
    return "pong"

def hello():
    """ 欢迎

    Returns:
        str: 欢迎结果
    """
    return "HI, I am bigOAINet!"
