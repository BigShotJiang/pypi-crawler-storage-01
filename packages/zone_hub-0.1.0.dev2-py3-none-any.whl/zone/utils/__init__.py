from .decorator import retry, singleton
