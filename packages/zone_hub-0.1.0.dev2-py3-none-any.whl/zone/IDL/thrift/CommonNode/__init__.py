from .ttypes import result as Result

__all__ = ["ttypes", "constants"]
