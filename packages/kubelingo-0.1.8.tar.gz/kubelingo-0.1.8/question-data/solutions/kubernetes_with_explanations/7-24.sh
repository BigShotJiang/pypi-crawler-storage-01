kubectl create configmap app-config --from-file=config.yaml
