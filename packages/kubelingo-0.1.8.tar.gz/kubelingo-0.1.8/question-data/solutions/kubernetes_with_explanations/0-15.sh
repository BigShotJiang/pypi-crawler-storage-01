k get ing
