kubectl scale deployment frontend --replicas=5
