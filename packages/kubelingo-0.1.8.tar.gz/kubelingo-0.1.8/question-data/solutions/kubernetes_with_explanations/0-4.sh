alias ke='kubectl explain'
