alias kc='kubectl create'
