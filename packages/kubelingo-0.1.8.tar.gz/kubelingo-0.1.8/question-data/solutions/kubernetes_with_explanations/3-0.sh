kubectl create namespace development
