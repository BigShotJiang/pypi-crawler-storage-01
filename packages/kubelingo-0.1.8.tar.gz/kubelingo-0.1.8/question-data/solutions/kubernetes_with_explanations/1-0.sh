kubectl run nginx --image=nginx --port=80
