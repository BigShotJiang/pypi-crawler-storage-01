kubectl create cm env-config --from-env-file=config.env
