kubectl create secret tls my-tls --cert=path/to/cert.crt --key=path/to/key.key
