kubectl create namespace dev
