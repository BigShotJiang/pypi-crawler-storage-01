kubectl create deployment nginx --image=nginx --record
