k get sa
