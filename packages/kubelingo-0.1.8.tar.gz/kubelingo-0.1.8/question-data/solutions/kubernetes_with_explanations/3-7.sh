kubectl delete namespace testing
