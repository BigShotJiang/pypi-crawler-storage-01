kubectl rollout restart deployment frontend
