kubectl rollout undo deployment/webapp
