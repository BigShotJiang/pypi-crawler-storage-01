kubectl scale deployment frontend --replicas=3
