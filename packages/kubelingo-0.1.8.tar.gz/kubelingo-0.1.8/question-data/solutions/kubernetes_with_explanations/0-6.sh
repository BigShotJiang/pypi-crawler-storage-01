alias kgs='kubectl get svc'
