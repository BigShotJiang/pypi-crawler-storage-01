kubectl get cm app-config -o yaml > config.yaml
