kubectl run nginx --image=nginx --labels="app=web,tier=frontend"
