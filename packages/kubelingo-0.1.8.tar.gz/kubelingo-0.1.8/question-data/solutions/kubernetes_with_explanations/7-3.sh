export KUBECONFIG=/home/user/config
