kubectl create cm game-config --from-file=/configs/game.properties
