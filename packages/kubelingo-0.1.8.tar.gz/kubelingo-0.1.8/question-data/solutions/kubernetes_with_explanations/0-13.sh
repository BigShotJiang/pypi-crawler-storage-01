k get secret
