kubectl rollout pause deployment/frontend
