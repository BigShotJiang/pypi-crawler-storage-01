alias kgp='kubectl get pods'
