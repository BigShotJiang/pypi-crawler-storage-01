kubectl create deployment nginx --image=nginx --dry-run=client -o yaml > deploy.yaml
