kubectl create secret generic my-secrets --from-env-file=.env
