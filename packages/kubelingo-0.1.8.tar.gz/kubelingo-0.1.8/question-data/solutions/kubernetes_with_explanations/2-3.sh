kubectl set image deployment/webapp webapp=nginx:1.18
