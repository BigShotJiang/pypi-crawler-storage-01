echo -n 'encoded string...' | base64 --decode
