kubectl get ns testing --dry-run=client -o yaml
