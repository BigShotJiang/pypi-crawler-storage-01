kubectl get all -A
