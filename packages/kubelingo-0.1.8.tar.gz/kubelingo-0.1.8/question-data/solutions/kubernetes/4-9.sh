kubectl get secret regcred --type=kubernetes.io/dockerconfigjson
