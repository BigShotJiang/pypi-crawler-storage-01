kubectl rollout history deployment/webapp
