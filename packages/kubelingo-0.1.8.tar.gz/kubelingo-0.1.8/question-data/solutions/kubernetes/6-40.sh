kubectl apply -f deployment.yaml
