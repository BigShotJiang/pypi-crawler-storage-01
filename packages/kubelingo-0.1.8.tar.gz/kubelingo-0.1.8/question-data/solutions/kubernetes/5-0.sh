kubectl get sa deployment-sa
