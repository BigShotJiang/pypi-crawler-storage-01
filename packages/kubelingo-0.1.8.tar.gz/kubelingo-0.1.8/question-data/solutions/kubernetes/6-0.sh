echo 'Validation for this step is manual. Please verify the command works in your shell.'
