echo 'This is validated by the user running the command and observing the output.'
