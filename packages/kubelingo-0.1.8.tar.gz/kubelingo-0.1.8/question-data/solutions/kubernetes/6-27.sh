kubectl delete configmap app-config
