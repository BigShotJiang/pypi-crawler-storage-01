kubectl describe node worker-node-1
