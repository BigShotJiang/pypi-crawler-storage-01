kubectl rollout status deployment/frontend -w
