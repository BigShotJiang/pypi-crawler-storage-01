kubectl top pods
