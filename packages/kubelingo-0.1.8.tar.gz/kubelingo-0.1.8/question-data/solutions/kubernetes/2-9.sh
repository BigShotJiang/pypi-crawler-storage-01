kubectl get quota ns-quota -n development
