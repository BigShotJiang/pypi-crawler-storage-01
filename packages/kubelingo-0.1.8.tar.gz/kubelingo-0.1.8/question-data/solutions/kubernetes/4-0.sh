kubectl get secret db-creds
