kubectl config get-contexts
