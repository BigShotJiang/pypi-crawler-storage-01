kubectl get pods -w
