kubectl delete serviceaccount default-sa
