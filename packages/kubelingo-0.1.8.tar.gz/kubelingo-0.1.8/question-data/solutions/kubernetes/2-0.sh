kubectl get namespace development
