kubectl describe deployment frontend
