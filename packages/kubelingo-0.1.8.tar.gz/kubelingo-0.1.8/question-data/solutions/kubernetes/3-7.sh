kubectl get cm multi-config
