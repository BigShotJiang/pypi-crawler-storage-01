kubectl label pod busybox env=prod
