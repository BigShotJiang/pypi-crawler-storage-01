kubectl apply -f deployment.yaml --dry-run=client
