kubectl delete service frontend-svc
