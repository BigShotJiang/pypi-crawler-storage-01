! kubectl get namespace dev
