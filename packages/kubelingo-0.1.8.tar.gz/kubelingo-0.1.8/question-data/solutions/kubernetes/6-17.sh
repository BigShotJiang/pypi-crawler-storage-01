kubectl get pods
