kubectl get secret my-secrets
