kubectl get cm game-config
