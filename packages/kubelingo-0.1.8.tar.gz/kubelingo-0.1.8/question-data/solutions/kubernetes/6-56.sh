kubectl top nodes
