kubectl get secrets
