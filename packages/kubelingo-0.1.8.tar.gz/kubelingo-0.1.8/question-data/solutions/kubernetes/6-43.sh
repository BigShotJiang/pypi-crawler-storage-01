kubectl edit deployment frontend
