kubectl edit cm app-config
