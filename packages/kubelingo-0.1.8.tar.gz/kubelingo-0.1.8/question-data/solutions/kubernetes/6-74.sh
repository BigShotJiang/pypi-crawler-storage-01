kubectl autoscale deployment frontend --min=2 --max=5 --cpu-percent=80
