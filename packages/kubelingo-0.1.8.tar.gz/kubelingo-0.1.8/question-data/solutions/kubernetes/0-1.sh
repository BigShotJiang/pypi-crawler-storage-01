kubectl get pod busybox
