kubectl annotate deployment frontend description-
