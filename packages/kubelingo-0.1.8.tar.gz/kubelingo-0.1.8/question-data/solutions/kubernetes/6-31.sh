kubectl delete secret db-secret
