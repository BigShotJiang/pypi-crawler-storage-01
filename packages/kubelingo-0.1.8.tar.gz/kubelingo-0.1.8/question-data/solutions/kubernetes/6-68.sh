kubectl create deployment test --image=nginx --dry-run=client -o yaml
