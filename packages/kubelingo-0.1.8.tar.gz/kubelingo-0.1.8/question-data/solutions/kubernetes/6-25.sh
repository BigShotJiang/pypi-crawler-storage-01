kubectl get configmaps
