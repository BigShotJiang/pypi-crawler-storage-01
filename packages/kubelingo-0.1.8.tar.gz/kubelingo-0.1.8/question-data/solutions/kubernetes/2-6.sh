kubectl get pod nginx -n development
