kubectl rollout status deployment/frontend
