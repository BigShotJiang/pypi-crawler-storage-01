kubectl get pods -l app=frontend
