kubectl api-resources
