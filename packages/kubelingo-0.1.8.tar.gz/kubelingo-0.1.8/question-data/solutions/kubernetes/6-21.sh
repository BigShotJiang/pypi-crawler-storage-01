kubectl get services
