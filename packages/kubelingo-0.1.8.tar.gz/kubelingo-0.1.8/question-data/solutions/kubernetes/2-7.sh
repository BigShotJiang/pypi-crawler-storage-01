! kubectl get ns testing
