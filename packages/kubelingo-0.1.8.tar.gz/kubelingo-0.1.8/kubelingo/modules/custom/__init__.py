"""
Custom study session plugin package.
"""
__all__ = []  # No top-level imports; use the 'session' submodule
