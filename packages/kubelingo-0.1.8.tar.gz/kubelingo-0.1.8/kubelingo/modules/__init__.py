"""
modules package for kubelingo CLI components
"""
# This package contains submodules for kubelingo, e.g., vim_yaml_editor