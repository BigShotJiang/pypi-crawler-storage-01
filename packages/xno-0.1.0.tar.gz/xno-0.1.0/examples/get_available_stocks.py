from xno.platform.ta.stocks import get_available_stocks

if __name__ == "__main__":
    print(get_available_stocks())