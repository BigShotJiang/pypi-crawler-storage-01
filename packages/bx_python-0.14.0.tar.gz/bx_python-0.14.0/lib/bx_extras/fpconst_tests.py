import bx_extras.fpconst as fp


def test_all():
    fp.test()
