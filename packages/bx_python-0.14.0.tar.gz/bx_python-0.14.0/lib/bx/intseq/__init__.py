"""
Tools for working with strings over interger alphabets efficiently.
"""
