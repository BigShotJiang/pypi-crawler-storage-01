
int symbol_match( char, char);
int pattern_match( char*, char*, int);
