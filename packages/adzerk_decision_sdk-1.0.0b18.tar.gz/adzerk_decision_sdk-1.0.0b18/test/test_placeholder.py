import unittest


class TestPlaceholder(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testPlaceholder(self):
        self.assertTrue(True)
