#init
from .main import run
print("Discord chinese bot v1.8 ok")
print("by I_am_from_taiwan")
run()