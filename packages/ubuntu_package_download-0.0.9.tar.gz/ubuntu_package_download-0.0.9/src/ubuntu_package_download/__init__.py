"""Top-level package for Ubuntu Package Download."""

__author__ = """Philip Roche"""
__email__ = 'phil.roche@canonical.com'
__version__ = '0.0.9'
