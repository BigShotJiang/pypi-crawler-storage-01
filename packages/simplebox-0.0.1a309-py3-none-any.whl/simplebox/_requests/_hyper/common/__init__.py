# -*- coding: utf-8 -*-
"""
_hyper/common
~~~~~~~~~~~~

Common code in _hyper.
"""
