# -*- coding: utf-8 -*-
"""
_hyper/http20
~~~~~~~~~~~~

The HTTP/2 submodule that powers _hyper.
"""
