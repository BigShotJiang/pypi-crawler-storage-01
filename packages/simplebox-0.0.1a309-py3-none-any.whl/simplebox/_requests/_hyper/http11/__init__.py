# -*- coding: utf-8 -*-
"""
_hyper/http11
~~~~~~~~~~~~

The HTTP/1.1 submodule that powers _hyper.
"""
