import access
import mgwr
import spglm
import spint
import spreg
import tobler
import spopt
