from libpysal.examples import (get_path, available,
                               load_example, explain)
