Thank you for your interest in contributing! We work primarily on Github. Please
review the [contributing procedures](https://github.com/pysal/pysal/wiki/GitHub-Standard-Operating-Procedures) so that we can accept your contributions! Alternatively, contact someone in [PySAL's Discord channel](https://discord.gg/BxFTEPFFZn).
