from setuptools import setup, find_packages

setup(
    name="pymazebuilder",
    version="1.4.6",
    author="w4ffl35",
    description="Generate mazes and dungeons for RPG games",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    keywords="maze, builder, generator, rpg, game, development",
    license="Apache-2.0",
    author_email="contact@capsizegames.com",
    url="https://github.com/w4ffl35/PyMazeBuilder",
    packages=find_packages("src"),
    package_dir={"": "src"},
    entry_points={
        "console_scripts": [
            "pymazebuilder=pymazebuilder.src.pymazebuilder.main:main",
        ],
    },
    install_requires=[],
)
