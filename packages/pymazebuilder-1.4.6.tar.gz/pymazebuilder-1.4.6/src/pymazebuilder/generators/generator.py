class Generator:
    def __init__(self, *args, **kwargs):
        self.data = None

    def generate(self):
        pass
