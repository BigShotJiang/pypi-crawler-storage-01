def greet(name:str) -> str:
    """
    Greets the given name.
    """
    return f"Hello, {name} from my-awesome-library!"

def add(a:int, b:int) -> int:
    """add tow numbers"""
    return a +b

