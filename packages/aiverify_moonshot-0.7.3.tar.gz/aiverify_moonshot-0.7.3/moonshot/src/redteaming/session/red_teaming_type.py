from enum import Enum


class RedTeamingType(Enum):
    MANUAL = "manual"
    AUTOMATED = "automated"
