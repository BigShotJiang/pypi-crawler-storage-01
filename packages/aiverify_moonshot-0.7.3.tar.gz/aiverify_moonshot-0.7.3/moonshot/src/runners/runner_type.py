from enum import Enum


class RunnerType(Enum):
    BENCHMARK = "benchmark"
    REDTEAM = "redteam"
