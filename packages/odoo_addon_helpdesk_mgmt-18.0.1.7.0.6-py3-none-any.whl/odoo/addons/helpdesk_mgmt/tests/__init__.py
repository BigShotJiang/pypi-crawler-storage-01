from . import test_helpdesk_ticket
from . import test_helpdesk_ticket_team
from . import test_helpdesk_portal
from . import test_helpdesk_fetchmail
from . import test_res_partner
from . import test_helpdesk_category_hierarchy
