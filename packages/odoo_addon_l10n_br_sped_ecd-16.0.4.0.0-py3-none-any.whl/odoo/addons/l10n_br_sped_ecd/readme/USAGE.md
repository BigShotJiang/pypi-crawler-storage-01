1. Entre no menu SPED>ECD e crie uma Declaração do SPED para a empresa e o período desejado. Preenche os dados (se trata dos dados do registro 0000 na verdade)
2. clique no botão "Puxar os registros do Odoo" para popular os registros do SPED. Os novos registros aparecem no chatter e você pode clicar em cima deles para abri-los.
3. Finalmente, clique no botão "Gerar arquivo do SPED" e baixe o arquivo que foi adicionado no chatter. Você pode transmitir o arquivo com o validador gratuito da receita por exemplo. Você pode também usar a opção de separar o arquivo por bloco se você quiser.
