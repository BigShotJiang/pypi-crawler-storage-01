"""Define various utility functions for multipac_testbench library."""
