"""Make some trigger files accessible."""
