__all__ = [
    "Model",
    "relationship",
]
from .decorators import relationship
from .model import Model
