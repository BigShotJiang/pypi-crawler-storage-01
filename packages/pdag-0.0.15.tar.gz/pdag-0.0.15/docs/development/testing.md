# Testing

Run tests with:

```bash
uv run pytest tests
```
