
__version__ = "1.0.0"  # x-release-please-version
VERSION: str = __version__
