import os


BASE_URL = "https://api.netmind.ai"