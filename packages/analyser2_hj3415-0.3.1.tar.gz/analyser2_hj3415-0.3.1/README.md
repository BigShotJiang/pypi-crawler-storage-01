### analyser2-hj3415

#### Introduction 
Analysing the stock data

