var searchData=
[
  ['error_5foutput_0',['error_output',['../namespacepalmmeteo_1_1logging.html#aab026e66a88b82db9d38c8ef09e78c4b',1,'palmmeteo::logging']]],
  ['event_5fhooks_1',['event_hooks',['../namespacepalmmeteo_1_1plugins.html#a411bd08d3124af68f73ea906b5c07cc0',1,'palmmeteo::plugins']]]
];
