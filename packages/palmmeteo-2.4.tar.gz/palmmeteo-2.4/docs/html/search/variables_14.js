var searchData=
[
  ['validations_0',['validations',['../classpalmmeteo_1_1library_1_1QuantityCalculator.html#a2d37f7aae496e00b51e4be6df80b02d4',1,'palmmeteo::library::QuantityCalculator']]],
  ['verbose_1',['verbose',['../namespacepalmmeteo_1_1logging.html#acf947326156f27e6b7013ca25aab8f09',1,'palmmeteo::logging']]]
];
