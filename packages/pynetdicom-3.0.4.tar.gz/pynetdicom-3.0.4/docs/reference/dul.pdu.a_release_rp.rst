.. _api_dul_pdu_areleaserp:

A-RELEASE-RP PDU
================

.. currentmodule:: pynetdicom.pdu

An A-RELEASE-RP PDU is made of a sequence of mandatory fields.

PDU
---

.. autosummary::
   :toctree: generated/

   A_RELEASE_RP
