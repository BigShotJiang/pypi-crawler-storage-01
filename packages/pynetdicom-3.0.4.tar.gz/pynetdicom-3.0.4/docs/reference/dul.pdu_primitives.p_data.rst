.. _api_dul_primitives_pdata:

P-DATA
======

.. currentmodule:: pynetdicom.pdu_primitives

The P-DATA service is used by either Application Entity to cause the exchange
of application information (i.e. DICOM Messages).

.. autosummary::
   :toctree: generated/

   P_DATA
