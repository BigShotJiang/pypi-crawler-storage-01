.. _api_dul_provider:

.. py:module:: pynetdicom.dul

DUL Service Provider (:mod:`pynetdicom.dul`)
=============================================

.. currentmodule:: pynetdicom.dul

.. autosummary::
   :toctree: generated/

   DULServiceProvider
