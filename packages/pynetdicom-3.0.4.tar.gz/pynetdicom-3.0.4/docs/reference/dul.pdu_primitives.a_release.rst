.. _api_dul_primitives_arelease:

A-RELEASE
=========

.. currentmodule:: pynetdicom.pdu_primitives

The graceful release of an association between two Application Entities is
performed through ACSE A-RELEASE request, indication, response and
confirmation primitives.

.. autosummary::
   :toctree: generated/

   A_RELEASE
