.. _api_dul_pdu_aassociaterj:

A-ASSOCIATE-RJ PDU
==================

.. currentmodule:: pynetdicom.pdu

An A-ASSOCIATE-RJ PDU is made of a sequence of mandatory fields.

PDU
---

.. autosummary::
   :toctree: generated/

   A_ASSOCIATE_RJ
