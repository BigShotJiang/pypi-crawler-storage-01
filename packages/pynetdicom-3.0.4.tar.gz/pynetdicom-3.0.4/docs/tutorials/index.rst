=========
Tutorials
=========

New to *pynetdicom*? Then these tutorials should get you up and running.

.. toctree::
   :maxdepth: 1

   create_scu
   create_scp
