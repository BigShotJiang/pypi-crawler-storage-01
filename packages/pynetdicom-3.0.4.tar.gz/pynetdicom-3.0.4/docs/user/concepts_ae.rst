.. _concepts_ae:

Application Entities
--------------------
A DICOM *Application Entity* (AE) is an application that supports the DICOM
standard in general, and especially IODs, service classes and dataset
encoding/decoding.

In DICOM networking, AEs are identified by their *AE Title*.
