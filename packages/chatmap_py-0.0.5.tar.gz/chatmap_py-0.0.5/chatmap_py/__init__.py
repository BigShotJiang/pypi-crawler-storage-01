__version__ = '0.0.5'
__author__ = 'Emilio Mariscal'
__licence__ = 'AGNU'
