from llama_index.embeddings.azure_inference.base import AzureAIEmbeddingsModel


__all__ = [AzureAIEmbeddingsModel]
