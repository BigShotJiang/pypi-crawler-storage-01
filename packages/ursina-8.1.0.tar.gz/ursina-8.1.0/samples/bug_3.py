from ursina import *

app = Ursina()

TextField()

app.run()