blender
open obj
give vertex colors
add sun
bake light
export as obj with vertex colors
