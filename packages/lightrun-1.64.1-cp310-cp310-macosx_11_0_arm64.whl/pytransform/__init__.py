# Pyarmor 8.4.7 (basic), 004363, 2025-07-31T15:43:53.581187
from .pyarmor_runtime import __pyarmor__
