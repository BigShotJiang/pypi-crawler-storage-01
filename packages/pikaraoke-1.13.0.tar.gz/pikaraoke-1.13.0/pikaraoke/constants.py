LANGUAGES = {
    "en": "English",
    "es_VE": "Spanish (Venezuela)",
    "fi_FI": "Finnish",
    "zh_CN": "Chinese (Simplified)",
    "zh_TW": "Chinese (Traditional)",
    "pt_BR": "Brazilian Portuguese",
    "it_IT": "Italian",
}
