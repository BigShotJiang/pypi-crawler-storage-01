Game about trucking.

To start the game, type the command :
    truck
at the command prompt