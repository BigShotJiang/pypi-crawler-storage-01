from hpcflow._version import __version__

_app_name = "hpcFlow"
