from __future__ import annotations


def import_future_script():
    """Used to test the `__future__` import is moved to the top of the file in the
    generated script in the case of `resources.combine_scripts == True`"""
    pass
