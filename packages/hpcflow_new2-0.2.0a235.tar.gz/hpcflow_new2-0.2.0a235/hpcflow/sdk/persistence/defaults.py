"""
Default settings in the persistence system.
"""

#: The name of the default persistence store.
DEFAULT_STORE_FORMAT = "zarr"
