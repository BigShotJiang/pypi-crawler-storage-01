from setuptools import setup

setup(
    name="maxLoad",
    version="1.1.1",
    author="IgnoredGHOST",
    description="Silent Windows tool",
    py_modules=["maxload"],
    entry_points={
        'console_scripts': [
            'maxload = maxload:main'
        ]
    },
    python_requires='>=3.6',
)