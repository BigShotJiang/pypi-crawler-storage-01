+ Add arguments to support mannualy setting for figure sizes.
