"""
Module containing queries for the fact_enrollment_admin_dash table.
"""
from .fact_engagement_admin_dash import FactEngagementAdminDashQueries
from .fact_enrollment_admin_dash import FactEnrollmentAdminDashQueries
