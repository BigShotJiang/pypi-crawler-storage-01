"""

"""

from abc import ABC

from .instance_solution import InstanceSolutionCore


class SolutionCore(InstanceSolutionCore, ABC):
    """
    The solution template.
    """

    pass
