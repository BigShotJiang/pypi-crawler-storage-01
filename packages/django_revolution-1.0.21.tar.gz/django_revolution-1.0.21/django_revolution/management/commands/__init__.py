"""
Django Revolution Management Commands

Package containing Django management commands.
"""
