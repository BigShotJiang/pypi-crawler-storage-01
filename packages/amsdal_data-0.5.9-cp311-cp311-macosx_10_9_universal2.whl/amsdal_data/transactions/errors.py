from amsdal_utils.errors import AmsdalError


class AmsdalTransactionError(AmsdalError): ...
