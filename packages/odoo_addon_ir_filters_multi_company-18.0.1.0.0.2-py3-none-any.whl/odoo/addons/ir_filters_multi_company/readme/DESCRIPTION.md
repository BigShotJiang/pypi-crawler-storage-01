This module add multi-company management to user-defined filters
