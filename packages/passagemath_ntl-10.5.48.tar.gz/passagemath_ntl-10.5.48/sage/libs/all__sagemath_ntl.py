# sage_setup: distribution = sagemath-ntl

import sage.libs.ntl.all as ntl
