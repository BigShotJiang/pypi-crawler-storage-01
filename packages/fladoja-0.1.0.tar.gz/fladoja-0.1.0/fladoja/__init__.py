from .core import Fladoja

__version__ = "0.1.0"
__all__ = ["Fladoja"]