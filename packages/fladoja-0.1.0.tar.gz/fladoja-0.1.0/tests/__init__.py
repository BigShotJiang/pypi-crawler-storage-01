from ..core import Fladoja

__all__ = ['TestFladoja']