# LlamaIndex Vector_Stores Integration: Qdrant
