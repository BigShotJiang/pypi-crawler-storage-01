from llama_index.embeddings.oracleai.base import OracleEmbeddings


__all__ = ["OracleEmbeddings"]
