"""Module for glchat_plugin user service."""
