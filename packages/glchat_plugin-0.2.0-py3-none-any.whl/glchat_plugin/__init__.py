"""Main module for glchat_plugin."""
