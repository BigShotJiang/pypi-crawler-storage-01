see new docs [here](../../pkg/integration/README.md)
