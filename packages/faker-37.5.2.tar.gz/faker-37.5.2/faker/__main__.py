if __name__ == "__main__":
    from .cli import execute_from_command_line

    execute_from_command_line()
