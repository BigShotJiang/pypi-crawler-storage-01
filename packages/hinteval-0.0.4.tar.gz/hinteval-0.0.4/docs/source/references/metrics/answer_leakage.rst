Answer Leakage
=======

.. autoclass:: hinteval.cores.evaluation_metrics.answer_leakage.Lexical
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.evaluation_metrics.answer_leakage.ContextualEmbeddings
    :members:
    :inherited-members: