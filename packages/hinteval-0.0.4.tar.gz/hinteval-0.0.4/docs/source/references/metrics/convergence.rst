Convergence
=======

.. autoclass:: hinteval.cores.evaluation_metrics.convergence.Specificity
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.evaluation_metrics.convergence.NeuralNetworkBased
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.evaluation_metrics.convergence.LlmBased
    :members:
    :inherited-members: