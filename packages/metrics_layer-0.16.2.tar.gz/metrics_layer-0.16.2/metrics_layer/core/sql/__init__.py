from .resolve import SQLQueryResolver  # noqa
