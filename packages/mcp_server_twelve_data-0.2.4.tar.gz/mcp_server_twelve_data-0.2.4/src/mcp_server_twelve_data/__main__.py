from mcp_server_twelve_data import main

main()
