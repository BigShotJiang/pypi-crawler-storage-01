#include <stdlib.h>
#include <semaphore.h>

int main(void) { 
    sem_getvalue(NULL, NULL);
    return 0; 
}

