#include <stdio.h>
#include <limits.h>

int main(void) { 
    printf("%ld\n", (long)MQ_PRIO_MAX);
    
    return 0; 
}

