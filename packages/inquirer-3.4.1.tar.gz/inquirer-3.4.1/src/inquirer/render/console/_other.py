class OtherChoice:
    def __str__(self):
        return "Other"


GLOBAL_OTHER_CHOICE = OtherChoice()
