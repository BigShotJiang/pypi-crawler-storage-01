from inquirer.render.console._text import Text


class Path(Text):
    pass
