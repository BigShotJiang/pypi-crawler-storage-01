from .figure_data_properties import Image
