from .tabular_data_properties import CSVData
