"""cubicweb-calendar"""

from cubicweb import _

WORKING_DAYTYPES = (_('dt_working'), _('dt_working_am'), _('dt_working_pm'))
WORKING_AM = _('dt_working_am')
WORKING_PM = _('dt_working_pm')
WORKING = _('dt_working')
NON_WORKING = _('dt_nonworking')
