This cube models calendars with different types of days (working, non-working,
vacation, sick, etc) and time periods (from simple
"Aug 31st 2009 to Sep 4th 2009" to repetitive ones like "July 14th").
