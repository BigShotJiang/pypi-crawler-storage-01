__version__ = '0.0.1'
__author__ = 'Frederik H Gjørup'
__authors__ = ['Frederik H. Gjørup']
__email__ = 'fgjorup@chem.au.dk'
__date__ = '29.07.2025'
__year__ = '2025'