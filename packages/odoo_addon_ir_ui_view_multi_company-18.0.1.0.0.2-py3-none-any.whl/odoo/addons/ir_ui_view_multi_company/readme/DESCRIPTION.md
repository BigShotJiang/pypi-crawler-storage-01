This module allows companies operating in a multi-company environment to define
custom views for specific companies.
It extends the view model by introducing a company_ids field, allowing views
to be dedicated to specific companies.
