# Copyright 2025 Broadcom.
# SPDX-License-Identifier: Apache-2
from relenv.common import __version__
