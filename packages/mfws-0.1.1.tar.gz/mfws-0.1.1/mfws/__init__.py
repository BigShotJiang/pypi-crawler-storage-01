# -*- coding: utf-8 -*-
"""
🌟 Create Time  : 2024/12/27 15:14
🌟 Author  : CB🐂🐎 - lizepeng
🌟 File  : __init__.py.py
🌟 Description  : 
"""

appname = 'mfws'
version = '0.1.1'
