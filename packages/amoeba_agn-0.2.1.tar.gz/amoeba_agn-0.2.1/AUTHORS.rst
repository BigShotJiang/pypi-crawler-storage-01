=======
Credits
=======

Development Lead
----------------

* Henry James Best V <hbest@gradcenter.cuny.edu>


Contributors
------------

Joshua Fagin,
James H.H. Chan,
Matthew O'Dowd,
Narayan Khadka,
Simon Birrer


Beta Testers
------------

Bridget Ierace,
Padma Venkatraman,
Paras Sharma,
Jolie L'Heureux


