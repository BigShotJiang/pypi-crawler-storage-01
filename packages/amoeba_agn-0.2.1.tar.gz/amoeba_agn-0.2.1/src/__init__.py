"""Top-level package for Amoeba."""

__author__ = """Henry James Best V"""
__email__ = "hbest@gradcenter.cuny.edu"
__version__ = "0.2.0"
