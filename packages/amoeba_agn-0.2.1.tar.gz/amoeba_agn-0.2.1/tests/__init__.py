"""Unit test package for amoeba."""

from amoeba import *
