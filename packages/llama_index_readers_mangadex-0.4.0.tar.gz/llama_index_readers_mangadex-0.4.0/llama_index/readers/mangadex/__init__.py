"""Init file."""

from llama_index.readers.mangadex.base import MangaDexReader

__all__ = ["MangaDexReader"]
