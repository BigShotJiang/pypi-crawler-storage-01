from vartulz_compliance_sdk.paths.v1_bank_get_all.get import ApiForget


class V1BankGetAll(
    ApiForget,
):
    pass
