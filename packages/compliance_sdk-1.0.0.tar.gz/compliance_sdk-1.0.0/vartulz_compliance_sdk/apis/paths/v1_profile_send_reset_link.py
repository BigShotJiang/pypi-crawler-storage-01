from vartulz_compliance_sdk.paths.v1_profile_send_reset_link.get import ApiForget


class V1ProfileSendResetLink(
    ApiForget,
):
    pass
