from vartulz_compliance_sdk.paths.v1_barcode_get_signatory_details.get import ApiForget


class V1BarcodeGetSignatoryDetails(
    ApiForget,
):
    pass
