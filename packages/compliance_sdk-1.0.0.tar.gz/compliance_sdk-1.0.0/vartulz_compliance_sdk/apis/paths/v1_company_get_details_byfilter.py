from vartulz_compliance_sdk.paths.v1_company_get_details_byfilter.get import ApiForget


class V1CompanyGetDetailsByfilter(
    ApiForget,
):
    pass
