from vartulz_compliance_sdk.paths.v1_razor_create_payment_link.post import ApiForpost


class V1RazorCreatePaymentLink(
    ApiForpost,
):
    pass
