from vartulz_compliance_sdk.paths.v1_barcode_share_barcode.post import ApiForpost


class V1BarcodeShareBarcode(
    ApiForpost,
):
    pass
