from vartulz_compliance_sdk.paths.v1_nsdl_get_signatory_details_case_id.get import ApiForget


class V1NsdlGetSignatoryDetailsCaseId(
    ApiForget,
):
    pass
