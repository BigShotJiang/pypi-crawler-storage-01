from vartulz_compliance_sdk.paths.v1_biller_get_all_state.get import ApiForget


class V1BillerGetAllState(
    ApiForget,
):
    pass
