from vartulz_compliance_sdk.paths.v1_utility_get_details_gstin.get import ApiForget


class V1UtilityGetDetailsGstin(
    ApiForget,
):
    pass
