from vartulz_compliance_sdk.paths.v1_aadhar_delete_aadhar.get import ApiForget


class V1AadharDeleteAadhar(
    ApiForget,
):
    pass
