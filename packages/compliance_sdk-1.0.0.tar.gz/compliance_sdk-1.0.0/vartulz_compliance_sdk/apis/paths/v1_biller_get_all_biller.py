from vartulz_compliance_sdk.paths.v1_biller_get_all_biller.get import ApiForget


class V1BillerGetAllBiller(
    ApiForget,
):
    pass
