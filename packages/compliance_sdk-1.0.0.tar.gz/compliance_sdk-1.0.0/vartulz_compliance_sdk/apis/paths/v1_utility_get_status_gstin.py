from vartulz_compliance_sdk.paths.v1_utility_get_status_gstin.get import ApiForget


class V1UtilityGetStatusGstin(
    ApiForget,
):
    pass
