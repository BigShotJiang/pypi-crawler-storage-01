from vartulz_compliance_sdk.paths.v1_company_get_all.get import ApiForget


class V1CompanyGetAll(
    ApiForget,
):
    pass
