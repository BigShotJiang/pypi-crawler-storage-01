from vartulz_compliance_sdk.paths.v1_profile_update_password.post import ApiForpost


class V1ProfileUpdatePassword(
    ApiForpost,
):
    pass
