from vartulz_compliance_sdk.paths.v1_nsdl_update_signatory_details_case_id.post import ApiForpost


class V1NsdlUpdateSignatoryDetailsCaseId(
    ApiForpost,
):
    pass
