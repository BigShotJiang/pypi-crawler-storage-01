from vartulz_compliance_sdk.paths.v1_razor_get_all_payments_details.get import ApiForget


class V1RazorGetAllPaymentsDetails(
    ApiForget,
):
    pass
