from vartulz_compliance_sdk.paths.v1_utility_iec_details.post import ApiForpost


class V1UtilityIecDetails(
    ApiForpost,
):
    pass
