from vartulz_compliance_sdk.paths.v1_company_get_all_emailnotapproved.get import ApiForget


class V1CompanyGetAllEmailnotapproved(
    ApiForget,
):
    pass
