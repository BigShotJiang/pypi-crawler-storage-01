from vartulz_compliance_sdk.paths.v1_utility_company_ciin_lookup.post import ApiForpost


class V1UtilityCompanyCiinLookup(
    ApiForpost,
):
    pass
