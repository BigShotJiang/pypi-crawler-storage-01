from vartulz_compliance_sdk.paths.v1_company_get_all_forapproval.get import ApiForget


class V1CompanyGetAllForapproval(
    ApiForget,
):
    pass
