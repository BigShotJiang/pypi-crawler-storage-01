from vartulz_compliance_sdk.paths.v1_company_block_unblock.post import ApiForpost


class V1CompanyBlockUnblock(
    ApiForpost,
):
    pass
