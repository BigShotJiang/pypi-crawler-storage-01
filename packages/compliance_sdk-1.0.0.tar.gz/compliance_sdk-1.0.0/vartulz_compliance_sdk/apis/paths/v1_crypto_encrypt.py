from vartulz_compliance_sdk.paths.v1_crypto_encrypt.post import ApiForpost


class V1CryptoEncrypt(
    ApiForpost,
):
    pass
