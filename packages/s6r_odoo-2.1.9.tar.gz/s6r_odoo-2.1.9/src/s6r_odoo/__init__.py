from .odoo import OdooConnection
