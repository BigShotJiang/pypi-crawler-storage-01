"""
Utilities for CLI and formatting.
""" 