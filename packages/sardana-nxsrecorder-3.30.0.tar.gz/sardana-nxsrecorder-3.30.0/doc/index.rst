.. sardananxsrecorder documentation master file, created by
   sphinx-quickstart on Tue Apr 12 13:15:41 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 4

   sardananxsrecorder


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

