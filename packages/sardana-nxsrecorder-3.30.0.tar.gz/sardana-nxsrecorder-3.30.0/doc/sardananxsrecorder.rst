sardananxsrecorder package
==========================

Submodules
----------

sardananxsrecorder.nxsrecorder module
-------------------------------------

.. automodule:: sardananxsrecorder.nxsrecorder

.. autoclass:: sardananxsrecorder.nxsrecorder.NXS_FileRecorder
    :members: formats, getFormat, numpyEncoder, _startRecordList, _writeRecord, _endRecordList, _addCustomData
    :undoc-members:
    :show-inheritance:
    :private-members: 

	     
       
		   
Module contents
---------------

.. automodule:: sardananxsrecorder
    :members:
    :undoc-members:
    :show-inheritance:
