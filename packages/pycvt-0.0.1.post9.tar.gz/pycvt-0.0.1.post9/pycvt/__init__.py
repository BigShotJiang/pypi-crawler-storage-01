from importlib.resources import files

red_dog_base_path = files("pycvt")
