__VERSION__ = '1.2.7'
# file.load_txt - clean_lst

# __VERSION__ = '1.2.6'
# # Wtry context manager 
# # truncate middle by default

# __VERSION__ = '1.2.5'
# # Faster file.load_txt
# # Corrected comment typos
# # pyproject.toml

# __VERSION__ = '1.2.4'
# # !dir -> log_dir
# # const to default kwargs
# # Logger kwargs comments

# __VERSION__ = '1.2.3'
# # close_logger returns the closed logger object
# # no more strip('\n') in save_list
# # empty_log_every_buffer

# __VERSION__ = '1.2.2'
# # log_every

# __VERSION__ = '1.2.1'
# # log_dict + log_array - only one log_print -> better perfs
# # Improved check_log logs - name appears when nok

# __VERSION__ = '1.2.0'
# # logging - error handling

# __VERSION__ = '1.1.9'
# # check_log - name appears when check_log ok
# # u.g.logs

# __VERSION__ = '1.1.8'
# # check_log - in_list optional
# # strg - truncate

# __VERSION__ = '1.1.7'
# # log_array - char_tab arg
# # check_log - name arg

# __VERSION__ = '1.1.6'
# # exact arg for like, like_list and like_dict

# __VERSION__ = '1.1.5'
# # Fixed bug in log_dict / log_print (tab_char)

# __VERSION__ = '1.1.4'
# # settable tab char in log_dict

# __VERSION__ = '1.1.3'
# # recursive log_dict

# __VERSION__ = '1.1.2'
# # set_logger

# __VERSION__ = '1.1.1'
# # consistent dirs and path (/ -> \)

# __VERSION__ = '1.1.0'
# # save_csv quote

# __VERSION__ = '1.0.9'
# # csv quote
# # csv -> csvl, string -> strg (avoid Pylance pb)

# __VERSION__ = '1.0.8'
# # Fixed bug save_list (mode) + line break

# __VERSION__ = '1.0.7'
# # file.list_files => incl_root default value = True

# __VERSION__ = '1.0.6'
# # logging.get_logger
# # logging.update_logger
# # file.list_files => incl_root

# __VERSION__ = '1.0.5'
# # CWD log at init

# __VERSION__ = '1.0.4'
# # Improved ttry

# __VERSION__ = '1.0.3'
# # loging.close_logger()
# # test -> testing

# __VERSION__ = '1.0.2'
# # Removed tests from packaging

# __VERSION__ = '1.0.1'
# # Removed extract_doc

# __VERSION__ = '1.0.0'
# # Init
