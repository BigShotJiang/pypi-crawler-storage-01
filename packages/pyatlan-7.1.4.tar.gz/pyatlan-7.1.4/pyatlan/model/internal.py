# SPDX-License-Identifier: Apache-2.0
# Copyright 2022 Atlan Pte. Ltd.
from pyatlan.model.core import AtlanObject


class Internal(AtlanObject):
    """For internal usage"""


class AtlasServer(AtlanObject):
    """For internal usage"""
