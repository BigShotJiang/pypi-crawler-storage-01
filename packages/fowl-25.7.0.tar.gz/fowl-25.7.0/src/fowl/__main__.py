from .cli import fowld

if __name__ == "__main__":
    fowld()
