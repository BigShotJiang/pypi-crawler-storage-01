

#
# testing some ideas around storing + visualizing "bandwidth" data ... maybe any time-series data
#
# a while ago i played with "mutli-time-scale" things, e.g. say a
# 2-section one where the "oldest" section is 10x more time (or
# whatever). So e.g. 10 data-points in a row visually "collect" into a
# single roll-up (e.g. average .. or min/max) before proceeding
# through the second one.
#
# ...need a lot of history to "see" that though, so having a test-driver for this is good.
#
# ...for the rust thing, a full "fake fowl, that always opens a
# connection on ports you open" or something would be cool.
#

