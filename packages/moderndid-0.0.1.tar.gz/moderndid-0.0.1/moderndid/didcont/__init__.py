"""Difference-in-differences with a continuous treatment."""
