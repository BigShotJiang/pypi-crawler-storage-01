from enum import Enum


class BindingFlags(Enum):
    All = 1
    Public = 2
    Private = 3
