# lazy_shell

Lazy, optional imports for Python projects. Declare your dependencies once and defer importing until needed. Missing packages can be handled gracefully using sink proxies.
