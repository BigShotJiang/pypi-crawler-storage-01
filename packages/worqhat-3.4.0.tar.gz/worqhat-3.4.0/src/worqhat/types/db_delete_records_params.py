# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["DBDeleteRecordsParams"]


class DBDeleteRecordsParams(TypedDict, total=False):
    table: Required[str]
    """Table name to delete from"""

    where: Required[object]
    """Where conditions"""
