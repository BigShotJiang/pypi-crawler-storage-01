"""
COESI CLI - Command line interface for managing COESI Platform Docker
deployments.
"""

__version__ = "0.1.0"
__author__ = "Reza Taheri"
__email__ = "taheri.reza94@gmail.com"
