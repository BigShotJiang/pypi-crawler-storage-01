# -*-coding:utf-8-*-

""" 服务配置 """
servers = {
    "api": "http://dev.colordove.com",
}