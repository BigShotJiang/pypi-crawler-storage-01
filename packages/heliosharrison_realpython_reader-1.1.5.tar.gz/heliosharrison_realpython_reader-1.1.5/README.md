# practice-github-actions
This repo is my playground for Github actions.
