"""Module for benchmarks"""
