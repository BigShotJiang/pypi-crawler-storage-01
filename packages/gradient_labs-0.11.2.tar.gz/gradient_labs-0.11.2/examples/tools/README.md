# Tools example

## Run a server

1. Run `uv run python server.py`
2. Run `ngrok http 8000`

And run the platform locally.

## Create and update a tool

1. Run `uv run python create.py` (point it to your ngrok URL)
2. Run `uv run python update.py` (point it to your ngrok URL)

## Execute the tool

1. Run `uv run python execute.py`