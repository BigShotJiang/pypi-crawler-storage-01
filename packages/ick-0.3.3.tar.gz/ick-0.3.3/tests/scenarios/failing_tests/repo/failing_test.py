with open("foo.md", "w") as f:
    print("WRONG", file=f)
