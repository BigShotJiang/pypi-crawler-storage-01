from .collect import Group, collect
from .prepare import prepare
from .train import train
from .test import test
from .inference import inference