def main():
    print('Ran test entrypoint.')
