.. _netcdf:

NetCDF
---------

NetCDF (Network Common Data Form) is a binary format for array-oriented scientific data.
