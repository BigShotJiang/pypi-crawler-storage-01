from earthkit.data import config

v = config.get("number-of-download-threads")

config.autosave = False
