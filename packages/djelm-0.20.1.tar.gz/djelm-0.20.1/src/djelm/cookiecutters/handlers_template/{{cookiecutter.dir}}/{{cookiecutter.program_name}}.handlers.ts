// https://guide.elm-lang.org/interop/ports
export function handlePorts(ports): void {
  console.warn(
    "'handlePorts' Not implemented for '{{cookiecutter.program_name}}.elm'",
  );
}
