from django.apps import AppConfig


class ElmConfig(AppConfig):
    name = "djelm"
