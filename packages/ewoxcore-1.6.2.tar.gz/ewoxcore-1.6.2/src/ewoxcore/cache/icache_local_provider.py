from typing import Any, Callable, Generic, List, Dict, Text, Optional, Tuple, Union, TypeVar, Type
from datetime import date, datetime, timedelta
from ewoxcore.cache.icache_provider import ICacheProvider


class ICacheLocalProvider(ICacheProvider):
    pass
