﻿# xyzzy3

This is a placeholder package to reserve the name xyzzy3 and prevent dependency confusion attacks.

Do not install or use this package.
