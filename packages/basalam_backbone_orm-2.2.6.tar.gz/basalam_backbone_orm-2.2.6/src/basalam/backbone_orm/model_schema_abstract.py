class ModelSchemaAbstract:
    pass
