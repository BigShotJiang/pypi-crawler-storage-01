from enum import Enum

class AllelicRequirement(Enum):
    MONO_ALLELIC = "monoallelic"
    BI_ALLELIC = "biallelic"
