# hanifx/__init__.py
from .core import HanifxCore
