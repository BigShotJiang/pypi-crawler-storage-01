::: plotjs.main.MagicPlot
