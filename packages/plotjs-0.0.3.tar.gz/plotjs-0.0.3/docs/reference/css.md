`plotjs` offers a few utility functions to work with CSS, and a [guide](../guides/css/index.md) on how to work with CSS.

<br>

::: plotjs.css.from_dict

<br>

::: plotjs.css.from_file

<br>

::: plotjs.css.is_css_like
