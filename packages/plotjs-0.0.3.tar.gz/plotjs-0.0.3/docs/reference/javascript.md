`plotjs` offers a few utility functions to work with JavaScript, and a [guide](../guides/javascript/index.md) on how to work with JavaScript.

<br>

::: plotjs.javascript.from_file
