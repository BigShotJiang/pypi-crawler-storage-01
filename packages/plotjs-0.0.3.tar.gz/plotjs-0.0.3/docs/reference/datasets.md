# Built-in datasets

`plotjs` has a few datasets that you can load easily:

- iris
- mtcars
- titanic

<br>

::: plotjs.data.load_iris

<br>

::: plotjs.data.load_mtcars

<br>

::: plotjs.data.load_titanic
