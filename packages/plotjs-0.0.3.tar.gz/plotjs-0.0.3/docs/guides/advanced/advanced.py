import matplotlib.pyplot as plt
from plotjs import MagicPlot
