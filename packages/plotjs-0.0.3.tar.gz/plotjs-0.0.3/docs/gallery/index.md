

This page contains all the `plotjs` examples from this website.

**TODO: make this page less ugly and add more diverse examples.**

<div style="display: flex;">

<iframe width="100%" height="300" src="../iframes/quickstart8.html" style="flex: 1; border: none;">

</iframe>

<iframe width="100%" height="300" src="../iframes/quickstart.html" style="flex: 1; border: none;">

</iframe>

</div>

<div style="display: flex;">

<iframe width="100%" height="300" src="../iframes/quickstart4.html" style="flex: 1; border: none;">

</iframe>

<iframe width="100%" height="300" src="../iframes/quickstart5.html" style="flex: 1; border: none;">

</iframe>

</div>

<div style="display: flex;">

<iframe width="100%" height="300" src="../iframes/quickstart9.html" style="flex: 1; border: none;">

</iframe>

<iframe width="100%" height="300" src="../iframes/CSS.html" style="flex: 1; border: none;">

</iframe>

</div>

<div style="display: flex;">

<iframe width="100%" height="300" src="../iframes/quickstart2.html" style="flex: 1; border: none;">

</iframe>

<iframe width="100%" height="300" src="../iframes/javascript.html" style="flex: 1; border: none;">

</iframe>

</div>

<div style="display: flex;">

<iframe width="100%" height="300" src="../iframes/quickstart3.html" style="flex: 1; border: none;">

</iframe>

<iframe width="100%" height="300" src="../iframes/javascript2.html" style="flex: 1; border: none;">

</iframe>

</div>

<div style="display: flex;">

<iframe width="100%" height="300" src="../iframes/CSS-2.html" style="flex: 1; border: none;">

</iframe>

<iframe width="100%" height="300" src="../iframes/quickstart6.html" style="flex: 1; border: none;">

</iframe>

</div>

<div style="display: flex;">

<iframe width="100%" height="300" src="../iframes/quickstart7.html" style="flex: 1; border: none;">

</iframe>

</div>
