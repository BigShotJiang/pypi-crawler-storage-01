from .examples import example_configs

engine_test_configs = example_configs


__all__ = [
    "engine_test_configs",
]
