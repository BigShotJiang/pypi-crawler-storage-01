from .ex_config_000 import ex_config_000
from .ex_config_001 import ex_config_001
from .ex_config_002 import ex_config_002
from .ex_config_003 import ex_config_003
from .ex_config_004 import ex_config_004
from .ex_config_005 import ex_config_005
from .ex_config_006 import ex_config_006
from .ex_config_007 import ex_config_007
from .ex_config_008 import ex_config_008
from .ex_config_009 import ex_config_009
from .ex_config_010 import ex_config_010
from .ex_config_011 import ex_config_011
from .ex_config_012 import ex_config_012
from .ex_config_013 import ex_config_013
from .ex_config_014 import ex_config_014
from .ex_config_015 import ex_config_015
from .ex_config_016 import ex_config_016
from .ex_config_017 import ex_config_017
from .ex_config_018 import ex_config_018
from .ex_config_019 import ex_config_019
from .ex_config_020 import ex_config_020
from .ex_config_021 import ex_config_021
from .ex_config_022 import ex_config_022
from .ex_config_023 import ex_config_023
from .ex_config_024 import ex_config_024
from .ex_config_025 import ex_config_025
from .ex_config_026 import ex_config_026
from .ex_config_027 import ex_config_027
from .ex_config_028 import ex_config_028
from .ex_config_029 import ex_config_029
from .ex_config_030 import ex_config_030
from .ex_config_031 import ex_config_031
from .ex_config_032 import ex_config_032
from .ex_config_033 import ex_config_033
from .ex_config_034 import ex_config_034

example_configs = (
    ex_config_000,
    ex_config_001,
    ex_config_002,
    ex_config_003,
    ex_config_004,
    ex_config_005,
    ex_config_006,
    ex_config_007,
    ex_config_008,
    ex_config_009,
    ex_config_010,
    ex_config_011,
    ex_config_012,
    ex_config_013,
    ex_config_014,
    ex_config_015,
    ex_config_016,
    ex_config_017,
    ex_config_018,
    ex_config_019,
    ex_config_020,
    ex_config_021,
    ex_config_022,
    ex_config_023,
    ex_config_024,
    ex_config_025,
    ex_config_026,
    ex_config_027,
    ex_config_028,
    ex_config_029,
    ex_config_030,
    ex_config_031,
    ex_config_032,
    ex_config_033,
    ex_config_034,
)

__all__ = ["example_configs"]
