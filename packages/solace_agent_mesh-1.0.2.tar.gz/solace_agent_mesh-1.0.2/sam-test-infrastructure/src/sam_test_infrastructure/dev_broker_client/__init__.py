"""
This package contains the generic test client for interacting with the dev_mode broker.
It allows tests to publish messages to and capture messages from the in-memory
message bus, simulating an external application on the event mesh.
"""
