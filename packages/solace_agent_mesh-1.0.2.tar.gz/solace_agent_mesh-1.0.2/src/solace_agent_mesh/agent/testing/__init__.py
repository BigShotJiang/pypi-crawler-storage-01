"""
Contains utilities for testing the A2A agent framework.
"""
