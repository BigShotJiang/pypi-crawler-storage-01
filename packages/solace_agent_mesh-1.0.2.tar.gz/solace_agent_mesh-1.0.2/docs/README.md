# Solace Agent Mesh Documentation

## Local Run

To run the Solace Agent Mesh locally, follow these steps:

```sh
cd docs
npm install
npm start
```

## Build Pages

To build the Solace Agent Mesh documentation pages, follow these steps:

```sh
cd docs
npm install
npm run build
```