class SarvException(Exception):
    '''
    SarvCRM Server Exception
    '''