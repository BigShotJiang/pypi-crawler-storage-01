WHITELIST:
src/

OPTIONS:
output: llm-context-test.md
respect_gitignore: true
include_hidden: false
include_binary: false

