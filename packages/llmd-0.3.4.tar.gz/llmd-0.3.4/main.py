#!/usr/bin/env python
"""Entry point for llm-md CLI tool."""

from llmd.cli import main

if __name__ == '__main__':
    main()