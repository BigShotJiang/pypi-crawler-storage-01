def main():
    print("Hello from guardx!")


if __name__ == "__main__":
    main()
