from mcp_server_deepresearch import main

main()