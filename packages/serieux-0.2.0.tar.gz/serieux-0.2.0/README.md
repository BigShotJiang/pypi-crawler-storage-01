# serieux

**WIP**

Very extensible serialization library.
