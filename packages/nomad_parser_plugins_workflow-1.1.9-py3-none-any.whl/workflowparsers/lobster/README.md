This is a NOMAD parser for [LOBSTER](http://schmeling.ac.rwth-aachen.de/cohp/).
It will read LOBSTER input and output files and provide all information in NOMAD's
unified Metainfo based Archive format.

For LOBSTER please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):

|Input Filename| Description|
|--- | --- |
|`lobsterout` | **Mainfile** in LOBSTER specific plain-text |


