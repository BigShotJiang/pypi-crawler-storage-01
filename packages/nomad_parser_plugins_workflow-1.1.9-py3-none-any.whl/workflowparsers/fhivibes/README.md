This is a NOMAD parser for [FHI-vibes](https://vibes.fhi-berlin.mpg.de/). It will read FHI-vibes hdf output file and provide all information in NOMAD's unified Metainfo based Archive format.

For FHI-vibes, a single hdf file with file extension `.nc` is required:

