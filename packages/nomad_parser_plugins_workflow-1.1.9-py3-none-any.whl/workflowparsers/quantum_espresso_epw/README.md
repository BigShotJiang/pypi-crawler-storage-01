This is a NOMAD parser for [Quantum Espresso EPW](https://www.quantum-espresso.org/). It will read Quantum Espresso EPW input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For Quantum Espresso EPW please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



