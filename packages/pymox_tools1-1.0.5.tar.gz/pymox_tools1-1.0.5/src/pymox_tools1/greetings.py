def hello():
    return f"Salut les gens !"


def bye():
    return f"Bye-bye les gens 123 !"


if __name__ == "__main__":
    print(hello(), "\n" + bye())
