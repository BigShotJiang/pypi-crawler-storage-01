# This file is part of the faebryk project
# SPDX-License-Identifier: MIT

from faebryk.core.trait import Trait


class is_lazy(Trait.TraitT.decless()):
    pass
