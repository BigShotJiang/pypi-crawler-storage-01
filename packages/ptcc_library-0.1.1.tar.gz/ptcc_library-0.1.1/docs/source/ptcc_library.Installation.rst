Installation
============

This installs a package that can be used from Python (``import ptcc-library``).


From PyPI
---------
ptcc_library can be installed from PyPI::

    pip install ptcc-library



Download Page: https://pypi.org/project/ptcc-library

Requirements
------------
- Python 3.12 and newer


