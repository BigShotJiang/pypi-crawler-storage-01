1.  "Product Brands" menu is now accessible also under Purchase \>
    Configuration \> Products
