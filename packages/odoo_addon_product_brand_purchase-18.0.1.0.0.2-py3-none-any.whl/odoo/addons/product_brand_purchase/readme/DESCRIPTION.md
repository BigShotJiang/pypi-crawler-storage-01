This module allows to work with product_brand in purchase reports.
