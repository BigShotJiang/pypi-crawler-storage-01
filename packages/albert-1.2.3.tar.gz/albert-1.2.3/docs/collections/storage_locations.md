::: albert.collections.storage_locations.StorageLocationsCollection
