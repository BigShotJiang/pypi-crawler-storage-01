from dataclasses import dataclass
from .market_data import MarketData

@dataclass
class Futures(
  MarketData,
):
  ...