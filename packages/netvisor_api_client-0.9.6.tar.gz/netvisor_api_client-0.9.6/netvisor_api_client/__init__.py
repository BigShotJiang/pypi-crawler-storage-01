"""
Netvisor API Client
~~~~~~~~

:copyright: (c) 2013-2016 by Fast Monkeys Oy | 2019- by Heltti Oy
:license: MIT, see LICENSE for more details.
"""

__version__ = "0.9.6"

from .core import Netvisor  # noqa: F401
