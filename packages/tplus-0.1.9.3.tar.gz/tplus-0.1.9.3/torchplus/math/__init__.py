import torch

pi = torch.arctan(torch.tensor(1)) * 4
