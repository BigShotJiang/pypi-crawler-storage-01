from .federated import FederatedAverage

__all__ = "FederatedAverage"
