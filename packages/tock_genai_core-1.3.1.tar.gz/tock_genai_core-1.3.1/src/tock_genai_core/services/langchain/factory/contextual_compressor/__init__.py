# -*- coding: utf-8 -*-
"""Initialisation de module(s)."""

from .bloomz_compressor_factory import BloomzCompressorFactory
