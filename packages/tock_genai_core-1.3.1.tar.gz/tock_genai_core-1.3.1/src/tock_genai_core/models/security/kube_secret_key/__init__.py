# -*- coding: utf-8 -*-
from .kube_secret_key import KubernetesSecretKey
