# REST API version
AEGIS_REST_API_VERSION: str = "v1"
