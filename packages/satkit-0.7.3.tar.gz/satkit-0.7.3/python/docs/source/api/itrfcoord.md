# ITRF (International Terrestrial Reference Frame) Coordinate

```{eval-rst}
.. autoapiclass:: satkit.itrfcoord
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
```