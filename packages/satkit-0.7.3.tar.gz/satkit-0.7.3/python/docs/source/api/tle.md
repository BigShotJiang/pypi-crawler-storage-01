# Two-Line Element Sets and SGP-4


```{eval-rst}
.. autoapiclass:: satkit.TLE
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:

.. autoapiclass:: satkit.sgp4_opsmode
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

.. autoapiclass:: satkit.sgp4_gravconst
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

.. autoapifunction:: satkit.sgp4
```