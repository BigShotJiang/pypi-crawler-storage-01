from ENT3C.cli.main import run_get_entropy, run_get_similarity, run_all

__version__ = "2.0.0"
