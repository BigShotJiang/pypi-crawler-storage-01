# Generated from ./PlantUML.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,44,259,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,1,0,1,0,1,0,5,0,54,
        8,0,10,0,12,0,57,9,0,1,0,1,0,1,1,1,1,1,1,1,1,3,1,65,8,1,1,1,4,1,
        68,8,1,11,1,12,1,69,1,2,1,2,1,2,1,2,1,2,1,3,1,3,3,3,79,8,3,1,3,1,
        3,3,3,83,8,3,1,3,1,3,5,3,87,8,3,10,3,12,3,90,9,3,1,3,1,3,5,3,94,
        8,3,10,3,12,3,97,9,3,1,3,1,3,1,4,1,4,3,4,103,8,4,1,5,1,5,3,5,107,
        8,5,1,6,1,6,3,6,111,8,6,1,6,1,6,1,6,1,6,3,6,117,8,6,1,6,3,6,120,
        8,6,1,6,1,6,1,6,3,6,125,8,6,1,7,1,7,1,8,3,8,130,8,8,1,8,1,8,3,8,
        134,8,8,1,9,3,9,137,8,9,1,9,3,9,140,8,9,3,9,142,8,9,1,9,1,9,3,9,
        146,8,9,1,9,3,9,149,8,9,3,9,151,8,9,1,10,3,10,154,8,10,1,10,3,10,
        157,8,10,3,10,159,8,10,1,10,1,10,3,10,163,8,10,1,10,3,10,166,8,10,
        3,10,168,8,10,1,11,1,11,1,11,3,11,173,8,11,1,11,1,11,1,12,1,12,1,
        12,1,13,1,13,1,13,1,13,3,13,184,8,13,1,13,1,13,1,14,1,14,1,15,3,
        15,191,8,15,1,15,1,15,1,15,1,15,1,15,1,16,3,16,199,8,16,1,16,3,16,
        202,8,16,1,16,1,16,1,16,1,16,1,16,3,16,209,8,16,3,16,211,8,16,1,
        16,1,16,1,16,3,16,216,8,16,1,16,1,16,1,17,1,17,1,17,1,17,1,17,3,
        17,225,8,17,1,18,3,18,228,8,18,1,18,1,18,3,18,232,8,18,1,19,1,19,
        3,19,236,8,19,1,20,1,20,1,20,1,20,1,20,5,20,243,8,20,10,20,12,20,
        246,9,20,1,20,1,20,1,21,1,21,1,21,1,22,1,22,1,23,1,23,1,24,1,24,
        1,24,0,0,25,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,
        38,40,42,44,46,48,0,5,2,0,39,39,41,41,1,0,38,40,1,0,21,24,1,0,25,
        33,1,0,34,35,278,0,50,1,0,0,0,2,64,1,0,0,0,4,71,1,0,0,0,6,78,1,0,
        0,0,8,100,1,0,0,0,10,106,1,0,0,0,12,108,1,0,0,0,14,126,1,0,0,0,16,
        129,1,0,0,0,18,141,1,0,0,0,20,158,1,0,0,0,22,169,1,0,0,0,24,176,
        1,0,0,0,26,179,1,0,0,0,28,187,1,0,0,0,30,190,1,0,0,0,32,198,1,0,
        0,0,34,219,1,0,0,0,36,227,1,0,0,0,38,235,1,0,0,0,40,237,1,0,0,0,
        42,249,1,0,0,0,44,252,1,0,0,0,46,254,1,0,0,0,48,256,1,0,0,0,50,51,
        5,36,0,0,51,55,5,43,0,0,52,54,3,2,1,0,53,52,1,0,0,0,54,57,1,0,0,
        0,55,53,1,0,0,0,55,56,1,0,0,0,56,58,1,0,0,0,57,55,1,0,0,0,58,59,
        5,37,0,0,59,1,1,0,0,0,60,65,3,4,2,0,61,65,3,6,3,0,62,65,3,10,5,0,
        63,65,3,40,20,0,64,60,1,0,0,0,64,61,1,0,0,0,64,62,1,0,0,0,64,63,
        1,0,0,0,65,67,1,0,0,0,66,68,5,43,0,0,67,66,1,0,0,0,68,69,1,0,0,0,
        69,67,1,0,0,0,69,70,1,0,0,0,70,3,1,0,0,0,71,72,5,1,0,0,72,73,5,2,
        0,0,73,74,5,39,0,0,74,75,5,43,0,0,75,5,1,0,0,0,76,79,3,8,4,0,77,
        79,5,3,0,0,78,76,1,0,0,0,78,77,1,0,0,0,79,80,1,0,0,0,80,82,5,38,
        0,0,81,83,3,24,12,0,82,81,1,0,0,0,82,83,1,0,0,0,83,84,1,0,0,0,84,
        88,5,4,0,0,85,87,5,43,0,0,86,85,1,0,0,0,87,90,1,0,0,0,88,86,1,0,
        0,0,88,89,1,0,0,0,89,95,1,0,0,0,90,88,1,0,0,0,91,94,3,30,15,0,92,
        94,3,32,16,0,93,91,1,0,0,0,93,92,1,0,0,0,94,97,1,0,0,0,95,93,1,0,
        0,0,95,96,1,0,0,0,96,98,1,0,0,0,97,95,1,0,0,0,98,99,5,5,0,0,99,7,
        1,0,0,0,100,102,5,6,0,0,101,103,5,3,0,0,102,101,1,0,0,0,102,103,
        1,0,0,0,103,9,1,0,0,0,104,107,3,12,6,0,105,107,3,22,11,0,106,104,
        1,0,0,0,106,105,1,0,0,0,107,11,1,0,0,0,108,110,5,38,0,0,109,111,
        3,26,13,0,110,109,1,0,0,0,110,111,1,0,0,0,111,116,1,0,0,0,112,117,
        3,14,7,0,113,117,3,16,8,0,114,117,3,18,9,0,115,117,3,20,10,0,116,
        112,1,0,0,0,116,113,1,0,0,0,116,114,1,0,0,0,116,115,1,0,0,0,117,
        119,1,0,0,0,118,120,3,26,13,0,119,118,1,0,0,0,119,120,1,0,0,0,120,
        121,1,0,0,0,121,124,5,38,0,0,122,123,5,7,0,0,123,125,5,38,0,0,124,
        122,1,0,0,0,124,125,1,0,0,0,125,13,1,0,0,0,126,127,5,8,0,0,127,15,
        1,0,0,0,128,130,5,9,0,0,129,128,1,0,0,0,129,130,1,0,0,0,130,131,
        1,0,0,0,131,133,5,8,0,0,132,134,5,10,0,0,133,132,1,0,0,0,133,134,
        1,0,0,0,134,17,1,0,0,0,135,137,5,11,0,0,136,135,1,0,0,0,136,137,
        1,0,0,0,137,142,1,0,0,0,138,140,5,9,0,0,139,138,1,0,0,0,139,140,
        1,0,0,0,140,142,1,0,0,0,141,136,1,0,0,0,141,139,1,0,0,0,142,143,
        1,0,0,0,143,150,5,8,0,0,144,146,5,10,0,0,145,144,1,0,0,0,145,146,
        1,0,0,0,146,151,1,0,0,0,147,149,5,11,0,0,148,147,1,0,0,0,148,149,
        1,0,0,0,149,151,1,0,0,0,150,145,1,0,0,0,150,148,1,0,0,0,151,19,1,
        0,0,0,152,154,5,41,0,0,153,152,1,0,0,0,153,154,1,0,0,0,154,159,1,
        0,0,0,155,157,5,9,0,0,156,155,1,0,0,0,156,157,1,0,0,0,157,159,1,
        0,0,0,158,153,1,0,0,0,158,156,1,0,0,0,159,160,1,0,0,0,160,167,5,
        8,0,0,161,163,5,10,0,0,162,161,1,0,0,0,162,163,1,0,0,0,163,168,1,
        0,0,0,164,166,5,41,0,0,165,164,1,0,0,0,165,166,1,0,0,0,166,168,1,
        0,0,0,167,162,1,0,0,0,167,165,1,0,0,0,168,21,1,0,0,0,169,172,5,38,
        0,0,170,173,5,12,0,0,171,173,5,13,0,0,172,170,1,0,0,0,172,171,1,
        0,0,0,173,174,1,0,0,0,174,175,5,38,0,0,175,23,1,0,0,0,176,177,5,
        14,0,0,177,178,5,38,0,0,178,25,1,0,0,0,179,180,5,44,0,0,180,183,
        3,28,14,0,181,182,5,15,0,0,182,184,3,28,14,0,183,181,1,0,0,0,183,
        184,1,0,0,0,184,185,1,0,0,0,185,186,5,44,0,0,186,27,1,0,0,0,187,
        188,7,0,0,0,188,29,1,0,0,0,189,191,3,44,22,0,190,189,1,0,0,0,190,
        191,1,0,0,0,191,192,1,0,0,0,192,193,5,38,0,0,193,194,5,7,0,0,194,
        195,3,38,19,0,195,196,5,43,0,0,196,31,1,0,0,0,197,199,3,44,22,0,
        198,197,1,0,0,0,198,199,1,0,0,0,199,201,1,0,0,0,200,202,3,48,24,
        0,201,200,1,0,0,0,201,202,1,0,0,0,202,203,1,0,0,0,203,204,5,38,0,
        0,204,210,5,16,0,0,205,208,3,34,17,0,206,207,5,17,0,0,207,209,3,
        34,17,0,208,206,1,0,0,0,208,209,1,0,0,0,209,211,1,0,0,0,210,205,
        1,0,0,0,210,211,1,0,0,0,211,212,1,0,0,0,212,215,5,18,0,0,213,214,
        5,7,0,0,214,216,3,38,19,0,215,213,1,0,0,0,215,216,1,0,0,0,216,217,
        1,0,0,0,217,218,5,43,0,0,218,33,1,0,0,0,219,220,5,38,0,0,220,221,
        5,7,0,0,221,224,3,38,19,0,222,223,5,19,0,0,223,225,3,36,18,0,224,
        222,1,0,0,0,224,225,1,0,0,0,225,35,1,0,0,0,226,228,5,44,0,0,227,
        226,1,0,0,0,227,228,1,0,0,0,228,229,1,0,0,0,229,231,7,1,0,0,230,
        232,5,44,0,0,231,230,1,0,0,0,231,232,1,0,0,0,232,37,1,0,0,0,233,
        236,3,46,23,0,234,236,5,38,0,0,235,233,1,0,0,0,235,234,1,0,0,0,236,
        39,1,0,0,0,237,238,5,20,0,0,238,239,5,38,0,0,239,240,5,4,0,0,240,
        244,5,43,0,0,241,243,3,42,21,0,242,241,1,0,0,0,243,246,1,0,0,0,244,
        242,1,0,0,0,244,245,1,0,0,0,245,247,1,0,0,0,246,244,1,0,0,0,247,
        248,5,5,0,0,248,41,1,0,0,0,249,250,5,38,0,0,250,251,5,43,0,0,251,
        43,1,0,0,0,252,253,7,2,0,0,253,45,1,0,0,0,254,255,7,3,0,0,255,47,
        1,0,0,0,256,257,7,4,0,0,257,49,1,0,0,0,41,55,64,69,78,82,88,93,95,
        102,106,110,116,119,124,129,133,136,139,141,145,148,150,153,156,
        158,162,165,167,172,183,190,198,201,208,210,215,224,227,231,235,
        244
    ]

class PlantUMLParser ( Parser ):

    grammarFileName = "PlantUML.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'skinparam'", "'groupInheritance'", "'class'", 
                     "'{'", "'}'", "'abstract'", "':'", "'--'", "'<'", "'>'", 
                     "'o'", "'<|--'", "'--|>'", "'extends'", "'..'", "'('", 
                     "','", "')'", "'='", "'enum'", "'#'", "'-'", "'~'", 
                     "'+'", "'int'", "'float'", "'str'", "'string'", "'bool'", 
                     "'time'", "'date'", "'datetime'", "'timedelta'", "'{static}'", 
                     "'{abstract}'", "'@startuml'", "'@enduml'", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'*'", "<INVALID>", "<INVALID>", 
                     "'\"'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "Start", "End", "ID", "INT", "FLOAT", "ASTK", "WS", 
                      "NL", "D_QUOTE" ]

    RULE_domainModel = 0
    RULE_element = 1
    RULE_skinParam = 2
    RULE_class = 3
    RULE_abstract = 4
    RULE_relationship = 5
    RULE_association = 6
    RULE_bidirectional = 7
    RULE_unidirectional = 8
    RULE_aggregation = 9
    RULE_composition = 10
    RULE_inheritance = 11
    RULE_extends = 12
    RULE_cardinality = 13
    RULE_cardinalityVal = 14
    RULE_attribute = 15
    RULE_method = 16
    RULE_parameter = 17
    RULE_value = 18
    RULE_dType = 19
    RULE_enumeration = 20
    RULE_enumLiteral = 21
    RULE_visibility = 22
    RULE_primitiveData = 23
    RULE_modifier = 24

    ruleNames =  [ "domainModel", "element", "skinParam", "class", "abstract", 
                   "relationship", "association", "bidirectional", "unidirectional", 
                   "aggregation", "composition", "inheritance", "extends", 
                   "cardinality", "cardinalityVal", "attribute", "method", 
                   "parameter", "value", "dType", "enumeration", "enumLiteral", 
                   "visibility", "primitiveData", "modifier" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    Start=36
    End=37
    ID=38
    INT=39
    FLOAT=40
    ASTK=41
    WS=42
    NL=43
    D_QUOTE=44

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class DomainModelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Start(self):
            return self.getToken(PlantUMLParser.Start, 0)

        def NL(self):
            return self.getToken(PlantUMLParser.NL, 0)

        def End(self):
            return self.getToken(PlantUMLParser.End, 0)

        def element(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PlantUMLParser.ElementContext)
            else:
                return self.getTypedRuleContext(PlantUMLParser.ElementContext,i)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_domainModel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDomainModel" ):
                listener.enterDomainModel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDomainModel" ):
                listener.exitDomainModel(self)




    def domainModel(self):

        localctx = PlantUMLParser.DomainModelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_domainModel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 50
            self.match(PlantUMLParser.Start)
            self.state = 51
            self.match(PlantUMLParser.NL)
            self.state = 55
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 274878955594) != 0):
                self.state = 52
                self.element()
                self.state = 57
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 58
            self.match(PlantUMLParser.End)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def skinParam(self):
            return self.getTypedRuleContext(PlantUMLParser.SkinParamContext,0)


        def class_(self):
            return self.getTypedRuleContext(PlantUMLParser.ClassContext,0)


        def relationship(self):
            return self.getTypedRuleContext(PlantUMLParser.RelationshipContext,0)


        def enumeration(self):
            return self.getTypedRuleContext(PlantUMLParser.EnumerationContext,0)


        def NL(self, i:int=None):
            if i is None:
                return self.getTokens(PlantUMLParser.NL)
            else:
                return self.getToken(PlantUMLParser.NL, i)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_element

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElement" ):
                listener.enterElement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElement" ):
                listener.exitElement(self)




    def element(self):

        localctx = PlantUMLParser.ElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_element)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 64
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.state = 60
                self.skinParam()
                pass
            elif token in [3, 6]:
                self.state = 61
                self.class_()
                pass
            elif token in [38]:
                self.state = 62
                self.relationship()
                pass
            elif token in [20]:
                self.state = 63
                self.enumeration()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 67 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 66
                self.match(PlantUMLParser.NL)
                self.state = 69 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==43):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SkinParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(PlantUMLParser.INT, 0)

        def NL(self):
            return self.getToken(PlantUMLParser.NL, 0)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_skinParam

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSkinParam" ):
                listener.enterSkinParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSkinParam" ):
                listener.exitSkinParam(self)




    def skinParam(self):

        localctx = PlantUMLParser.SkinParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_skinParam)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 71
            self.match(PlantUMLParser.T__0)
            self.state = 72
            self.match(PlantUMLParser.T__1)
            self.state = 73
            self.match(PlantUMLParser.INT)
            self.state = 74
            self.match(PlantUMLParser.NL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def abstract(self):
            return self.getTypedRuleContext(PlantUMLParser.AbstractContext,0)


        def extends(self):
            return self.getTypedRuleContext(PlantUMLParser.ExtendsContext,0)


        def NL(self, i:int=None):
            if i is None:
                return self.getTokens(PlantUMLParser.NL)
            else:
                return self.getToken(PlantUMLParser.NL, i)

        def attribute(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PlantUMLParser.AttributeContext)
            else:
                return self.getTypedRuleContext(PlantUMLParser.AttributeContext,i)


        def method(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PlantUMLParser.MethodContext)
            else:
                return self.getTypedRuleContext(PlantUMLParser.MethodContext,i)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_class

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClass" ):
                listener.enterClass(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClass" ):
                listener.exitClass(self)




    def class_(self):

        localctx = PlantUMLParser.ClassContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_class)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 78
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [6]:
                self.state = 76
                self.abstract()
                pass
            elif token in [3]:
                self.state = 77
                self.match(PlantUMLParser.T__2)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 80
            self.match(PlantUMLParser.ID)
            self.state = 82
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==14:
                self.state = 81
                self.extends()


            self.state = 84
            self.match(PlantUMLParser.T__3)
            self.state = 88
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==43:
                self.state = 85
                self.match(PlantUMLParser.NL)
                self.state = 90
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 95
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 326448971776) != 0):
                self.state = 93
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                if la_ == 1:
                    self.state = 91
                    self.attribute()
                    pass

                elif la_ == 2:
                    self.state = 92
                    self.method()
                    pass


                self.state = 97
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 98
            self.match(PlantUMLParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AbstractContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PlantUMLParser.RULE_abstract

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAbstract" ):
                listener.enterAbstract(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAbstract" ):
                listener.exitAbstract(self)




    def abstract(self):

        localctx = PlantUMLParser.AbstractContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_abstract)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 100
            self.match(PlantUMLParser.T__5)
            self.state = 102
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==3:
                self.state = 101
                self.match(PlantUMLParser.T__2)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelationshipContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def association(self):
            return self.getTypedRuleContext(PlantUMLParser.AssociationContext,0)


        def inheritance(self):
            return self.getTypedRuleContext(PlantUMLParser.InheritanceContext,0)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_relationship

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelationship" ):
                listener.enterRelationship(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelationship" ):
                listener.exitRelationship(self)




    def relationship(self):

        localctx = PlantUMLParser.RelationshipContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_relationship)
        try:
            self.state = 106
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 104
                self.association()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 105
                self.inheritance()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssociationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.c_left = None # CardinalityContext
            self.c_right = None # CardinalityContext

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(PlantUMLParser.ID)
            else:
                return self.getToken(PlantUMLParser.ID, i)

        def bidirectional(self):
            return self.getTypedRuleContext(PlantUMLParser.BidirectionalContext,0)


        def unidirectional(self):
            return self.getTypedRuleContext(PlantUMLParser.UnidirectionalContext,0)


        def aggregation(self):
            return self.getTypedRuleContext(PlantUMLParser.AggregationContext,0)


        def composition(self):
            return self.getTypedRuleContext(PlantUMLParser.CompositionContext,0)


        def cardinality(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PlantUMLParser.CardinalityContext)
            else:
                return self.getTypedRuleContext(PlantUMLParser.CardinalityContext,i)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_association

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssociation" ):
                listener.enterAssociation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssociation" ):
                listener.exitAssociation(self)




    def association(self):

        localctx = PlantUMLParser.AssociationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_association)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 108
            self.match(PlantUMLParser.ID)
            self.state = 110
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==44:
                self.state = 109
                localctx.c_left = self.cardinality()


            self.state = 116
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.state = 112
                self.bidirectional()
                pass

            elif la_ == 2:
                self.state = 113
                self.unidirectional()
                pass

            elif la_ == 3:
                self.state = 114
                self.aggregation()
                pass

            elif la_ == 4:
                self.state = 115
                self.composition()
                pass


            self.state = 119
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==44:
                self.state = 118
                localctx.c_right = self.cardinality()


            self.state = 121
            self.match(PlantUMLParser.ID)
            self.state = 124
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==7:
                self.state = 122
                self.match(PlantUMLParser.T__6)
                self.state = 123
                self.match(PlantUMLParser.ID)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BidirectionalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PlantUMLParser.RULE_bidirectional

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBidirectional" ):
                listener.enterBidirectional(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBidirectional" ):
                listener.exitBidirectional(self)




    def bidirectional(self):

        localctx = PlantUMLParser.BidirectionalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_bidirectional)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(PlantUMLParser.T__7)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnidirectionalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.nav_l = None # Token
            self.nav_r = None # Token


        def getRuleIndex(self):
            return PlantUMLParser.RULE_unidirectional

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnidirectional" ):
                listener.enterUnidirectional(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnidirectional" ):
                listener.exitUnidirectional(self)




    def unidirectional(self):

        localctx = PlantUMLParser.UnidirectionalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_unidirectional)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 129
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==9:
                self.state = 128
                localctx.nav_l = self.match(PlantUMLParser.T__8)


            self.state = 131
            self.match(PlantUMLParser.T__7)
            self.state = 133
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 132
                localctx.nav_r = self.match(PlantUMLParser.T__9)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AggregationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.aggr_l = None # Token
            self.aggr_r = None # Token


        def getRuleIndex(self):
            return PlantUMLParser.RULE_aggregation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggregation" ):
                listener.enterAggregation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggregation" ):
                listener.exitAggregation(self)




    def aggregation(self):

        localctx = PlantUMLParser.AggregationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_aggregation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 141
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
            if la_ == 1:
                self.state = 136
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==11:
                    self.state = 135
                    localctx.aggr_l = self.match(PlantUMLParser.T__10)


                pass

            elif la_ == 2:
                self.state = 139
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 138
                    self.match(PlantUMLParser.T__8)


                pass


            self.state = 143
            self.match(PlantUMLParser.T__7)
            self.state = 150
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
            if la_ == 1:
                self.state = 145
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 144
                    self.match(PlantUMLParser.T__9)


                pass

            elif la_ == 2:
                self.state = 148
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==11:
                    self.state = 147
                    localctx.aggr_r = self.match(PlantUMLParser.T__10)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompositionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.comp_l = None # Token
            self.comp_r = None # Token

        def ASTK(self, i:int=None):
            if i is None:
                return self.getTokens(PlantUMLParser.ASTK)
            else:
                return self.getToken(PlantUMLParser.ASTK, i)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_composition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComposition" ):
                listener.enterComposition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComposition" ):
                listener.exitComposition(self)




    def composition(self):

        localctx = PlantUMLParser.CompositionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_composition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.state = 153
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==41:
                    self.state = 152
                    localctx.comp_l = self.match(PlantUMLParser.ASTK)


                pass

            elif la_ == 2:
                self.state = 156
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 155
                    self.match(PlantUMLParser.T__8)


                pass


            self.state = 160
            self.match(PlantUMLParser.T__7)
            self.state = 167
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
            if la_ == 1:
                self.state = 162
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 161
                    self.match(PlantUMLParser.T__9)


                pass

            elif la_ == 2:
                self.state = 165
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==41:
                    self.state = 164
                    localctx.comp_r = self.match(PlantUMLParser.ASTK)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InheritanceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.inh_left = None # Token

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(PlantUMLParser.ID)
            else:
                return self.getToken(PlantUMLParser.ID, i)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_inheritance

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInheritance" ):
                listener.enterInheritance(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInheritance" ):
                listener.exitInheritance(self)




    def inheritance(self):

        localctx = PlantUMLParser.InheritanceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_inheritance)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.match(PlantUMLParser.ID)
            self.state = 172
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [12]:
                self.state = 170
                localctx.inh_left = self.match(PlantUMLParser.T__11)
                pass
            elif token in [13]:
                self.state = 171
                self.match(PlantUMLParser.T__12)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 174
            self.match(PlantUMLParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_extends

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtends" ):
                listener.enterExtends(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtends" ):
                listener.exitExtends(self)




    def extends(self):

        localctx = PlantUMLParser.ExtendsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_extends)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 176
            self.match(PlantUMLParser.T__13)
            self.state = 177
            self.match(PlantUMLParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CardinalityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.min_ = None # CardinalityValContext
            self.max_ = None # CardinalityValContext

        def D_QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(PlantUMLParser.D_QUOTE)
            else:
                return self.getToken(PlantUMLParser.D_QUOTE, i)

        def cardinalityVal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PlantUMLParser.CardinalityValContext)
            else:
                return self.getTypedRuleContext(PlantUMLParser.CardinalityValContext,i)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_cardinality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCardinality" ):
                listener.enterCardinality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCardinality" ):
                listener.exitCardinality(self)




    def cardinality(self):

        localctx = PlantUMLParser.CardinalityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_cardinality)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179
            self.match(PlantUMLParser.D_QUOTE)
            self.state = 180
            localctx.min_ = self.cardinalityVal()
            self.state = 183
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==15:
                self.state = 181
                self.match(PlantUMLParser.T__14)
                self.state = 182
                localctx.max_ = self.cardinalityVal()


            self.state = 185
            self.match(PlantUMLParser.D_QUOTE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CardinalityValContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(PlantUMLParser.INT, 0)

        def ASTK(self):
            return self.getToken(PlantUMLParser.ASTK, 0)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_cardinalityVal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCardinalityVal" ):
                listener.enterCardinalityVal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCardinalityVal" ):
                listener.exitCardinalityVal(self)




    def cardinalityVal(self):

        localctx = PlantUMLParser.CardinalityValContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_cardinalityVal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            _la = self._input.LA(1)
            if not(_la==39 or _la==41):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def dType(self):
            return self.getTypedRuleContext(PlantUMLParser.DTypeContext,0)


        def NL(self):
            return self.getToken(PlantUMLParser.NL, 0)

        def visibility(self):
            return self.getTypedRuleContext(PlantUMLParser.VisibilityContext,0)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_attribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttribute" ):
                listener.enterAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttribute" ):
                listener.exitAttribute(self)




    def attribute(self):

        localctx = PlantUMLParser.AttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_attribute)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 190
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 31457280) != 0):
                self.state = 189
                self.visibility()


            self.state = 192
            self.match(PlantUMLParser.ID)
            self.state = 193
            self.match(PlantUMLParser.T__6)
            self.state = 194
            self.dType()
            self.state = 195
            self.match(PlantUMLParser.NL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MethodContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # Token

        def NL(self):
            return self.getToken(PlantUMLParser.NL, 0)

        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def visibility(self):
            return self.getTypedRuleContext(PlantUMLParser.VisibilityContext,0)


        def modifier(self):
            return self.getTypedRuleContext(PlantUMLParser.ModifierContext,0)


        def parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PlantUMLParser.ParameterContext)
            else:
                return self.getTypedRuleContext(PlantUMLParser.ParameterContext,i)


        def dType(self):
            return self.getTypedRuleContext(PlantUMLParser.DTypeContext,0)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_method

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMethod" ):
                listener.enterMethod(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMethod" ):
                listener.exitMethod(self)




    def method(self):

        localctx = PlantUMLParser.MethodContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_method)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 198
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 31457280) != 0):
                self.state = 197
                self.visibility()


            self.state = 201
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34 or _la==35:
                self.state = 200
                self.modifier()


            self.state = 203
            localctx.name = self.match(PlantUMLParser.ID)
            self.state = 204
            self.match(PlantUMLParser.T__15)
            self.state = 210
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 205
                self.parameter()
                self.state = 208
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==17:
                    self.state = 206
                    self.match(PlantUMLParser.T__16)
                    self.state = 207
                    self.parameter()




            self.state = 212
            self.match(PlantUMLParser.T__17)
            self.state = 215
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==7:
                self.state = 213
                self.match(PlantUMLParser.T__6)
                self.state = 214
                self.dType()


            self.state = 217
            self.match(PlantUMLParser.NL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # Token

        def dType(self):
            return self.getTypedRuleContext(PlantUMLParser.DTypeContext,0)


        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def value(self):
            return self.getTypedRuleContext(PlantUMLParser.ValueContext,0)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameter" ):
                listener.enterParameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameter" ):
                listener.exitParameter(self)




    def parameter(self):

        localctx = PlantUMLParser.ParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_parameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 219
            localctx.name = self.match(PlantUMLParser.ID)
            self.state = 220
            self.match(PlantUMLParser.T__6)
            self.state = 221
            self.dType()
            self.state = 224
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==19:
                self.state = 222
                self.match(PlantUMLParser.T__18)
                self.state = 223
                self.value()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def INT(self):
            return self.getToken(PlantUMLParser.INT, 0)

        def FLOAT(self):
            return self.getToken(PlantUMLParser.FLOAT, 0)

        def D_QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(PlantUMLParser.D_QUOTE)
            else:
                return self.getToken(PlantUMLParser.D_QUOTE, i)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValue" ):
                listener.enterValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValue" ):
                listener.exitValue(self)




    def value(self):

        localctx = PlantUMLParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 227
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==44:
                self.state = 226
                self.match(PlantUMLParser.D_QUOTE)


            self.state = 229
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1924145348608) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 231
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==44:
                self.state = 230
                self.match(PlantUMLParser.D_QUOTE)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primitiveData(self):
            return self.getTypedRuleContext(PlantUMLParser.PrimitiveDataContext,0)


        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_dType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDType" ):
                listener.enterDType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDType" ):
                listener.exitDType(self)




    def dType(self):

        localctx = PlantUMLParser.DTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_dType)
        try:
            self.state = 235
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [25, 26, 27, 28, 29, 30, 31, 32, 33]:
                self.enterOuterAlt(localctx, 1)
                self.state = 233
                self.primitiveData()
                pass
            elif token in [38]:
                self.enterOuterAlt(localctx, 2)
                self.state = 234
                self.match(PlantUMLParser.ID)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumerationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def NL(self):
            return self.getToken(PlantUMLParser.NL, 0)

        def enumLiteral(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PlantUMLParser.EnumLiteralContext)
            else:
                return self.getTypedRuleContext(PlantUMLParser.EnumLiteralContext,i)


        def getRuleIndex(self):
            return PlantUMLParser.RULE_enumeration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumeration" ):
                listener.enterEnumeration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumeration" ):
                listener.exitEnumeration(self)




    def enumeration(self):

        localctx = PlantUMLParser.EnumerationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_enumeration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 237
            self.match(PlantUMLParser.T__19)
            self.state = 238
            self.match(PlantUMLParser.ID)
            self.state = 239
            self.match(PlantUMLParser.T__3)
            self.state = 240
            self.match(PlantUMLParser.NL)
            self.state = 244
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==38:
                self.state = 241
                self.enumLiteral()
                self.state = 246
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 247
            self.match(PlantUMLParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PlantUMLParser.ID, 0)

        def NL(self):
            return self.getToken(PlantUMLParser.NL, 0)

        def getRuleIndex(self):
            return PlantUMLParser.RULE_enumLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumLiteral" ):
                listener.enterEnumLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumLiteral" ):
                listener.exitEnumLiteral(self)




    def enumLiteral(self):

        localctx = PlantUMLParser.EnumLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_enumLiteral)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 249
            self.match(PlantUMLParser.ID)
            self.state = 250
            self.match(PlantUMLParser.NL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VisibilityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PlantUMLParser.RULE_visibility

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVisibility" ):
                listener.enterVisibility(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVisibility" ):
                listener.exitVisibility(self)




    def visibility(self):

        localctx = PlantUMLParser.VisibilityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_visibility)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 252
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 31457280) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimitiveDataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PlantUMLParser.RULE_primitiveData

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimitiveData" ):
                listener.enterPrimitiveData(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimitiveData" ):
                listener.exitPrimitiveData(self)




    def primitiveData(self):

        localctx = PlantUMLParser.PrimitiveDataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_primitiveData)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 254
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 17146314752) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ModifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PlantUMLParser.RULE_modifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterModifier" ):
                listener.enterModifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitModifier" ):
                listener.exitModifier(self)




    def modifier(self):

        localctx = PlantUMLParser.ModifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_modifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 256
            _la = self._input.LA(1)
            if not(_la==34 or _la==35):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





