import setuptools

setuptools.setup(
    name="odoo_addon_energy_selfconsumption",
    setup_requires=['setuptools-odoo'],
    odoo_addon=True,
)
