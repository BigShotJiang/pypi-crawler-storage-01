# brnow_tts/__init__.py

from .TTS import TTS
