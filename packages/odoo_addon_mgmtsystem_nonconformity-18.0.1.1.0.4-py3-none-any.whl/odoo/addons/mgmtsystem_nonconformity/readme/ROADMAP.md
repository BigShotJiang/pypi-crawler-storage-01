- The custom emails should be replaced by Mail Tracking features and
  Subtypes (like in Project Tasks and Project Issues)
- Automatically add responsible_user_id.\_uid, manager_user_id.\_uid,
  author_user_id.\_uid to chatter
