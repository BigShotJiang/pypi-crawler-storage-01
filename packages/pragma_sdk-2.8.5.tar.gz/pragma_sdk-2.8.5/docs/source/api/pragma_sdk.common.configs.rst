configs
=============================



AssetConfig
------------------------------------------

.. automodule:: pragma_sdk.common.configs.asset_config
   :members:
   :undoc-members:
   :show-inheritance:
