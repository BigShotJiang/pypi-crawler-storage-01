"""
Package initialization for lask.

This module provides access to the main lask functionality.
"""

from src.main import main

__all__ = ["main"]
