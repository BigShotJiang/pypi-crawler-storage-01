These files generated using script
`$IGNITE_SRC/modules/platforms/cpp/thin-client-test/config/ssl/generate_certificates.sh`
To update them just run script and move files to this folder.