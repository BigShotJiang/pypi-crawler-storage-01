from . import test_l10n_br_purchase_stock
from . import test_stock_rule
