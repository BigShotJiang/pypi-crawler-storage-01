O módulo depende do:

- l10n_br_purchase
- l10n_br_stock_account
