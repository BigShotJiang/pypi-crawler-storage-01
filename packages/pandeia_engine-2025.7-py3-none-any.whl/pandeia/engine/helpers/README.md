helpers
=======

This directory contains helper code and accessors, some of which use the tables and executables under pandeia/backgrounds.
