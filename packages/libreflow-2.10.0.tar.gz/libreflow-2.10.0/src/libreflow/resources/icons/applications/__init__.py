import kabaret.app.resources as resources
import logging


resources.add_folder("icons.applications", __file__)
logging.debug("ICONS.APPLICATIONS LOADED")
