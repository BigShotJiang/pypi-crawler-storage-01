import kabaret.app.resources as resources
import logging


resources.add_folder("mark_sequence.fields", __file__)
