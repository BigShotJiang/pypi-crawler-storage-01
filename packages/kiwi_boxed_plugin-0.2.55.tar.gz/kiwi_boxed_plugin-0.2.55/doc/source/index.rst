.. toctree::
   :maxdepth: 1

   commands
