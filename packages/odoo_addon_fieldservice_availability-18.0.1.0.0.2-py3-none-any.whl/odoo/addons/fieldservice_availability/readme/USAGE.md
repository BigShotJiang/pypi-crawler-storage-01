Navigate to Field Service \> Configuration \> Scheduling. Once there,
you can select Delivery Time Ranges, Blackout Days, Blackout Groups or Festive Days to
create new records.
