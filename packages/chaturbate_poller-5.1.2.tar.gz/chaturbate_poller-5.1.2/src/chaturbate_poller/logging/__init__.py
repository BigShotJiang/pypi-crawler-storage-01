"""Logging configuration module."""  # noqa: A005, RUF100
