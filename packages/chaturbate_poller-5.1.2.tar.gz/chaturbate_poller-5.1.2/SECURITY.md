# Security Policy

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities to
**[security@reid.ca](mailto:security@reid.ca)**. If the issue is confirmed, I will release a patch as soon
as possible depending on complexity.
