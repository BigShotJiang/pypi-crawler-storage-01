"""
MCP图片工具服务入口点

这个模块允许直接运行mcp_imgutils包，例如:
`python -m mcp_imgutils`
"""

from . import main

if __name__ == "__main__":
    main()
