# mdc-rackauskas

🟢 Konsolinis įrankis Minecraft serverių parsisiuntimui ir paleidimui.

## Diegimas

```bash
pip install mdc-rackauskas
