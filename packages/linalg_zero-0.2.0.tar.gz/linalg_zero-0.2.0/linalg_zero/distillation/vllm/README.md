Check out the [official documentation](https://github.com/vllm-project/vllm/blob/main/docs/features/tool_calling.md) for installation instructions.
