::: rapidstats._polars._numeric
::: rapidstats._polars._format
