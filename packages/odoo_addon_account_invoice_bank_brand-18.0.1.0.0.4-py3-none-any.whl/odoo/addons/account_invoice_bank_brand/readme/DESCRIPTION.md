This module addresses the need to specify different receiving bank accounts based on brand.
When generating invoices, the module automatically populates the invoice's bank account field with the configured default, streamlining the payment process and ensuring invoices specify the correct remittance details based on the brand.
