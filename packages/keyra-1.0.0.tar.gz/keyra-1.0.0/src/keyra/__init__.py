from keyra.key import (
    key, 
    generate_password, 
    generate_pin, 
    generate_token,
    append_date,
    append_timestamp,
    append_datetime,
    get_formatted_date,
    get_formatted_timestamp,
    auto_increment_suffix,
    make_filename_safe,
    add_extension
)

__version__ = "1.0.0"
__author__ = "jisan"
__email__ = "realterm.io@gmail.com"
