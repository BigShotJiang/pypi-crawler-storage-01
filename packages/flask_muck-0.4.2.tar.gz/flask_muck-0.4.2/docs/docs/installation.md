# Installation

## pip

Flask-Muck is currently only available on PyPi and can be installed with pip.

`pip install flask-muck`