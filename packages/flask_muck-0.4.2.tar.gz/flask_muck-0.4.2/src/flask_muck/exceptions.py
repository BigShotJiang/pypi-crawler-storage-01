class MuckImplementationError(Exception):
    pass
