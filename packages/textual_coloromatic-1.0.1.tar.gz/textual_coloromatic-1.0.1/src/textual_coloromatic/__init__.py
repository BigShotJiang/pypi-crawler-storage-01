"""Textual-Coloromatic
A Textual widget by Edward Jazzhands.

To import:
```
from textual_coloromatic import Coloromatic
```
"""

from textual_coloromatic.coloromatic import Coloromatic

__all__ = ["Coloromatic"]
