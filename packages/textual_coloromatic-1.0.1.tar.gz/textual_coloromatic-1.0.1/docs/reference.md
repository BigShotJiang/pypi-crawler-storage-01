# Color-O-Matic reference

::: textual_coloromatic.coloromatic.Coloromatic
