NAME = __name__.replace('_', '-').split('.')[0]
SMB_CONF = "/etc/samba/smb.conf"
AVAHI_SMB_SERVICE = "/etc/avahi/services/smb.service"
CONFIRM_PHRASE = "I KNOW WHAT I AM DOING"
