# Multipath

This section documents the Device Mapper Multipath functionality.

::: sts.multipath
