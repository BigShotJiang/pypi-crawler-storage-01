# LVM

This section documents the Logical Volume Management (LVM) functionality.

::: sts.lvm
