def hello():
    return "Salut les gens !"


if __name__ == "__main__":
    print(hello())
