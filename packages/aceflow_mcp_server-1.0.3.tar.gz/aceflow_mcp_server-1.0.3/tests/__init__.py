"""Test configuration and initialization."""

import pytest