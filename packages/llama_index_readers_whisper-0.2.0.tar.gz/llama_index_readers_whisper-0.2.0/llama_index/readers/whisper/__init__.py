from llama_index.readers.whisper.base import WhisperReader

__all__ = ["WhisperReader"]
