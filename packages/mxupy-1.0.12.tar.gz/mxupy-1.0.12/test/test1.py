import mxupy as mu

mu.setVideoFPS(r"D:\MuseTalk\results\output\outputxxx_lele512_10_xtu_lele.mp4",
               r"D:\MuseTalk\results\output\outputxxx_lele512_60_xtu_lele.mp4", 60)
