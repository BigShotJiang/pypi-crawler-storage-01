#define str(s) #s
#define xstr(s) str(s)

#include "config.h"
#include xstr(params/params-SLH_DSA_MODE.h)

