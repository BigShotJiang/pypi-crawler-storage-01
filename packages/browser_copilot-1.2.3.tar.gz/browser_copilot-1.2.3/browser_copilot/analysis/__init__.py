"""Analysis module for Browser Copilot"""

from .report_parser import ReportParser

__all__ = ["ReportParser"]
