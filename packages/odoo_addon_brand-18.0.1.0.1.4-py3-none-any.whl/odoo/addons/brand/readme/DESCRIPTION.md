This is a base addon for brand modules. It adds the brand object and its
menu and define an abstract model to be inherited from branded objects.
