from rdkit.Chem import Mol

Rxn = tuple[Mol, Mol]
