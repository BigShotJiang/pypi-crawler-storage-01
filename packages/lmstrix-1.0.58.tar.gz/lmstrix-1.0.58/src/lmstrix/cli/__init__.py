"""Command-line interface for LMStrix."""

__all__: list[str] = []
