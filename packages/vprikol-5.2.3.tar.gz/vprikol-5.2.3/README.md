# vprikol

## Установка

```sh
pip install vprikol -U
```

## Документация

https://apitest.szx.su/docs

## Поддержка

https://discord.com/invite/ZtpJVCYzAv
