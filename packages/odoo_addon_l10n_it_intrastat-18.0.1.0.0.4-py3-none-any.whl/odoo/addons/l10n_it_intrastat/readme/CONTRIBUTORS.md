- Alessandro Camilli

- Lorenzo Battistini

- Lara Baggio \<<lbaggio@linkgroup.it>\>

- Glauco Prina \<<gprina@linkgroup.it>\>

- Sergio Zanchetta \<<https://github.com/primes2h>\>

- [Ooops](https://www.ooops404.com):

  > - Giovanni Serra \<<giovanni@gslab.it>\>

- Antonio Maria Vigliotti \<<antoniomaria.vigliotti@gmail.com>\>

- Fabio Giovannelli \<<fabio.giovannelli@didotech.com>\>

- Alex Comba \<<alex.comba@agilebg.com>\>

- [Aion Tech](https://aiontech.company/):
  - Simone Rubino \<<simone.rubino@aion-tech.it>\>
