# -*- coding: utf-8 -*-
"""命令行接口模块"""

from .command_line import CommandLineInterface, main

__all__ = ['CommandLineInterface', 'main']
