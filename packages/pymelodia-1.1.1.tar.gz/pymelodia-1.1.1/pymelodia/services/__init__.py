# -*- coding: utf-8 -*-
"""业务服务模块"""

from .download_service import MusicDownloadService

__all__ = ['MusicDownloadService']
