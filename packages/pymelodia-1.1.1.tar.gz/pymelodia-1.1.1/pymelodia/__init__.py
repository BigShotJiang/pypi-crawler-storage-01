# -*- coding: utf-8 -*-
"""
PyMelodia - 网易云音乐下载工具
"""

__version__ = "1.1.1"
__author__ = "yht0511"
__email__ = "admin@teclab.org.cn"
__description__ = "网易云音乐下载工具"

from .cli.command_line import main

__all__ = ['main']

__all__ = ['main']
