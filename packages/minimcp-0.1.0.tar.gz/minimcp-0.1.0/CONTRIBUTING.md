# MiniMCP

A dev readme for MiniMCP.

## Setup
```
uv init --python=python3.10
uv pip install --dev -e .
```

## Running demo app

```
uvicorn demo.main:app --reload
```
