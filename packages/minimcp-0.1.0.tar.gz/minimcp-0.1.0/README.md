# minimcp
A drop in MCP server for you existing Python applications.
