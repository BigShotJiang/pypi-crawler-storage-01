def main():
    print("Hello from minimcp!")


if __name__ == "__main__":
    main()
