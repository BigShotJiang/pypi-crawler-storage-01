from code_exec.controller import api

def run():
    api.run()

if __name__ == '__main__':
    run()