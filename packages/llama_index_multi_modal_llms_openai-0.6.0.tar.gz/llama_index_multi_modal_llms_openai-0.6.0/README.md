# LlamaIndex Multi-Modal-Llms Integration: Openai
