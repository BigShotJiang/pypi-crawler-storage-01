import random

def get_joke():
    jokes = [
        "Why did the chicken cross the road in Lagos? To get to the other side of traffic!",
        "In Africa, even the WiFi takes a break for lunch.",
        "Why do elephants never use computers? They're afraid of the mouse!"
    ]
    return random.choice(jokes)