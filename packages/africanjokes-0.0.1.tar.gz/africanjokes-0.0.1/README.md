# afrojokes

A simple Python library for African jokes.

## Usage

```python
import afrojokes

print(afrojokes.get_joke())
```