from setuptools import setup, find_packages

setup(
    name='africanjokes',
    version='0.0.1',
    description='A library for African jokes',
    author='Morris D. Toclo',
    packages=find_packages(),
    install_requires=[],
    python_requires='>=3.8',
)