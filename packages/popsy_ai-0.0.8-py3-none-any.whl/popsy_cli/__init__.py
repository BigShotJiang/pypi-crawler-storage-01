"""
Popsy AI CLI - Reddit DM automation using Popsy AI
"""

__version__ = "0.0.8"
__author__ = "Popsy AI"
__email__ = "support@popsy.ai"
