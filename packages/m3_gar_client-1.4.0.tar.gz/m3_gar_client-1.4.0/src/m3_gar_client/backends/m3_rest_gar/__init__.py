"""
Бэкенды для сервера ГАР ``m3-rest-gar``.

https://stash.bars-open.ru/projects/M3/repos/m3-rest-gar
"""
