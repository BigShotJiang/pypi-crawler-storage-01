'''the official ENVRI-HUB python package, allowing you to automate resource search and data access'''
__all__ =['Hub']

from envrihub.hub import Hub

