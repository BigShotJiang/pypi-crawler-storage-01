# oda-utils

Un paquete que añade protección Anti-Raid, generación de embeds y respuestas automáticas para bots de Discord.
