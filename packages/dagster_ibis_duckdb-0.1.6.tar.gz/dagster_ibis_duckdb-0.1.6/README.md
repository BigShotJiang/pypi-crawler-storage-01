# dagster-ibis-duckdb
Dagster IO manager for ibis dataframes
