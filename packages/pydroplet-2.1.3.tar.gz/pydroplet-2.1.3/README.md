# pydroplet

This is a package to parse messages from the [Droplet](https://shop.hydrificwater.com/pages/buy-droplet) device.
