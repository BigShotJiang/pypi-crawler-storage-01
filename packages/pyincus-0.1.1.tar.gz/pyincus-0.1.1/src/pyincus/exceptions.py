"""Custom exceptions of the library."""


class PyIncusException(Exception):
    """Exception raised on communications with Incus."""
