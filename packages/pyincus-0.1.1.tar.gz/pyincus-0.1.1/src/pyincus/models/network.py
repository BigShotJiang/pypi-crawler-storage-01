"""Models for Networks."""
