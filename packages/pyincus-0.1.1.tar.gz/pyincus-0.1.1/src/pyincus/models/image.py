"""Models for Images."""
