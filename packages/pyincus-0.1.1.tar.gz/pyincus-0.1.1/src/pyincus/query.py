"""Query builder for the client calls."""
