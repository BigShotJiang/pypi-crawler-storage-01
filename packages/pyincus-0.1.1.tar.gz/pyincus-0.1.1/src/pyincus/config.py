"""Constants."""

from pathlib import Path

UNIX_SOCKET_PATH = Path('/var/lib/incus/unix.socket')
Unset = object()
