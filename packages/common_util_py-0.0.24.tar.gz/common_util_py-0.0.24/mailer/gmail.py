
def send_text():
    print("sending text email to gmail")

def send_html():
    print("sending html email to gmail")

