## main

## 1.0.5 / 2025-08-01
 - Updated dependencies to allow numpy >= 1.26 (numpy 2, basically)
 - Updated gitlab CI file to match other projects.