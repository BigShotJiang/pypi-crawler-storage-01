import lcp_delta.common.constants as constants

MAIN_BASE_URL = constants.MAIN_BASE_URL_DEV
SERIES_BASE_URL = constants.SERIES_BASE_URL_DEV