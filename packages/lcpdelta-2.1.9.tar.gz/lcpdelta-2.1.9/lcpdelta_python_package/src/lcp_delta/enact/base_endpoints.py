from .loader import get_base_endpoints

base_endpoints = get_base_endpoints()