MAIN_BASE_URL = "https://enactapifd.lcp.uk.com"
MAIN_BASE_URL_DEV = "https://enact-backupapi-one.lcp.uk.com"

EPEX_BASE_URL = "https://enact-epex.azurefd.net"
SERIES_BASE_URL = "https://enact-functionapp-siteapi.azurewebsites.net"
SERIES_BASE_URL_DEV = "https://enact-functionapp-siteapi-staging.azurewebsites.net"
