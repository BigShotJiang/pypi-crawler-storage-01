#  Copyright (c) NXAI GmbH.
#  This software may be used and distributed according to the terms of the NXAI Community License Agreement.

from .fwbw import mlstm_siging_chunkwise__xl_chunk
