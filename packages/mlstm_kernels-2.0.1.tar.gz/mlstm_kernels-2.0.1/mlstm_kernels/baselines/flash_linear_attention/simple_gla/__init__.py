# This module is copied from https://github.com/sustcsonglin/flash-linear-attention/blob/fee90b2e72366a46c60e3ef16431133aa5aced8d/fla/ops/simple_gla
# Adapted to make it work in this codebase


from .chunk import chunk_simple_gla

__all__ = ["chunk_simple_gla"]
