# ✍️ psf2flf

Converts bitmap fonts to figlet fonts.

