manga_sources = {"mangadex": "api.MangaDexApi"}
