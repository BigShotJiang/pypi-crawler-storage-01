.. include:: ../fiasco/CITATION.rst
