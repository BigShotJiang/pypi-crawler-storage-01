"""
Tests for ion-specific file parsers
"""
