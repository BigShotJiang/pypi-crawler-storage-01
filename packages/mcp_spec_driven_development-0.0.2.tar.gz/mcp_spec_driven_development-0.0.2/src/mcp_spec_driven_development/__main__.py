"""作为模块运行MCP服务器的入口点。"""

from .server import main

if __name__ == "__main__":
    main()
