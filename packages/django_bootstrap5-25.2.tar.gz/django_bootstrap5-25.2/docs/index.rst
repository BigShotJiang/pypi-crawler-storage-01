Welcome to django-bootstrap5's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   migrate
   forms
   templatetags
   settings
   templates
   widgets
   contributing
   changelog
