# SPDX-FileCopyrightText: 2024-2025 Stefan Bellon
#
# SPDX-License-Identifier: MIT

import rich.traceback

rich.traceback.install(show_locals=True)
