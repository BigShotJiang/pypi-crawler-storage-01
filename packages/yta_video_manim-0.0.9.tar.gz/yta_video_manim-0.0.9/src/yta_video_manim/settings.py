MIN_ANIMATION_DURATION = 1
"""
The minimum number of seconds we accept as a
parameter to build a manim animation.
"""
MAX_ANIMATION_DURATION = 120
"""
The maximum number of seconds we accept as a
parameter to build a manim animation.
"""