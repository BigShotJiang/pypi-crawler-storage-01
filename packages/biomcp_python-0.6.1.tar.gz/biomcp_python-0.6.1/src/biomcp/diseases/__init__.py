"""Disease information tools for BioMCP."""

from .getter import get_disease

__all__ = ["get_disease"]
