"""Integrations package includes both parsers and API's wrapper for jobs aggregators"""

from .remoteok import RemoteOKAPIIntegration
