"""
DevTools - Outils de développement Django
""" 