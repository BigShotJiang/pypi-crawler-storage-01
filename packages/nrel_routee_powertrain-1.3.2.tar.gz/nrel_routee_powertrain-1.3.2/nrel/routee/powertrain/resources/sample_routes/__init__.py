from pathlib import Path


def sample_route_dir() -> Path:
    return Path(__file__).parent
