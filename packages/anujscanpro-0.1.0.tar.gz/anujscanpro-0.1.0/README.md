\# AnujScan Pro



AnujScan is a powerful modular recon and vulnerability analysis toolkit for ethical hackers. Includes WHOIS, subdomain scanner, port scanner, HTTP headers, SSL checker, and more.



\## Installation



pip install anujscan





\## Features



\- WHOIS Lookup

\- Subdomain Scanner

\- HTTP Header Grabber

\- Port Scanner

\- SSL Certificate Checker

\- Directory Bruteforcer (DirBuster)



Built with ❤️ by Anuj Prajapati



