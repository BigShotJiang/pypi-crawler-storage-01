"""
Configuration settings for makeitaquote
"""

API_URL = "https://api.voids.top/fakequote"
BETA_API_URL = "https://api.voids.top/fakequotebeta"