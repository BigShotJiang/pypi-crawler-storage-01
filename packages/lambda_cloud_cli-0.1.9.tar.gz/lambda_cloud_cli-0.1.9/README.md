# lambda-cli

A command-line interface for managing Lambda Cloud resources.

## Install

```bash
pip install lambda-cli

