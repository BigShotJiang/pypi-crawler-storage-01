"""Tests for the calculator package."""
