from atomicshop.wrappers.mongodbw import install_mongodb_win


def main():
    install_mongodb_win.download_install_latest_main()


if __name__ == "__main__":
    main()
