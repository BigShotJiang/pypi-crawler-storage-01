from atomicshop.wrappers.pycharmw import win


def main():
    win.download_install_main()


if __name__ == "__main__":
    main()
