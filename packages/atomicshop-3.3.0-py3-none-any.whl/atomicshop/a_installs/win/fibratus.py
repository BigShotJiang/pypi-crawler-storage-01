from atomicshop.wrappers.fibratusw import install


def main():
    install.install_fibratus(remove_file_after_installation=True)


if __name__ == '__main__':
    main()
