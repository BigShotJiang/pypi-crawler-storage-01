"""Pytest configuration for tests."""


# No async plugin needed since we're using sync tests with anyio.run()
