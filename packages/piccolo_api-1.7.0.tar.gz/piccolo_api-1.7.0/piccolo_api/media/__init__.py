"""
Resources:
https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html
"""
