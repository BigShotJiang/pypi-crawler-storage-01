# stringsmith

Simple and flexible string generation toolkit.

## Features

- Generate random numbers
- Generate random alphabets
- Generate random alphanumeric strings with optional symbols
- CLI and Python API

## Installation

```bash
pip install stringsmith
