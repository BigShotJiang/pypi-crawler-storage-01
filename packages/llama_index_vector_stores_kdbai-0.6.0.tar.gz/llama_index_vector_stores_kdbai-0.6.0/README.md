# LlamaIndex Vector_Stores Integration: KDB.AI
