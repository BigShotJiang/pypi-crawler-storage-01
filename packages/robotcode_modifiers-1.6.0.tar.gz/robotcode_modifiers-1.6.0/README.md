# robotcode-modifiers

[![PyPI - Version](https://img.shields.io/pypi/v/robotcode-modifiers.svg)](https://pypi.org/project/robotcode-modifiers)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/robotcode-modifiers.svg)](https://pypi.org/project/robotcode-modifiers)
[![License](https://img.shields.io/github/license/robotcodedev/robotcode?style=flat&logo=apache)](https://github.com/robotcodedev/robotcode/blob/master/LICENSE.txt)

-----

## Introduction

Some Robot Framework Modifiers for [RobotCode](https://robotcode.io).

## Installation

```console
pip install robotcode-modifiers
```

## License

`robotcode-modifiers` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
