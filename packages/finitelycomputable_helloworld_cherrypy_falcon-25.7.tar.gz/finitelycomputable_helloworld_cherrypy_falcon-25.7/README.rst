==========================
HelloWorld-CherryPy-Falcon
==========================

This application adapts the hello_world endpoint provided in
finitelycomputable.helloworld_falcon to be provided in
finitelycomputable.helloworld_cherrypy using the CherryPy framework.
