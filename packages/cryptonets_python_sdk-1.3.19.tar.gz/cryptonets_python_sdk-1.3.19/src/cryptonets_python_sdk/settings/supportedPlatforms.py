from enum import Enum


class SupportedPlatforms(Enum):
    # supportedOS
    supportedOS = ["Linux", "Darwin","Windows"]

