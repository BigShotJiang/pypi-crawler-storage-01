# Copyright DB InfraGO AG and contributors
# SPDX-License-Identifier: Apache-2.0
"""Contains endpoint functions for accessing the API."""
