# Copyright DB InfraGO AG and contributors
# SPDX-License-Identifier: Apache-2.0
"""Contains methods for accessing the API."""
