"""Configuration module for the chaturbate_poller package."""

from chaturbate_poller.config.manager import ConfigManager

__all__ = ["ConfigManager"]
