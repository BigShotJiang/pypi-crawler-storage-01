"""Database module for chaturbate_poller."""
