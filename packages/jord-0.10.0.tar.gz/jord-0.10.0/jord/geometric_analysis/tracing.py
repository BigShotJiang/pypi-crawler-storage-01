from shapely.geometry import LinearRing

__all__ = ["trace_for_inner_ring"]


def trace_for_inner_ring(geometry) -> LinearRing:
    pass
