class LexerError(Exception):
    pass  # handle unexpected / invalid stuff

class ParseError(Exception):
    pass 

class RuntimeError(Exception):
    pass # my bad