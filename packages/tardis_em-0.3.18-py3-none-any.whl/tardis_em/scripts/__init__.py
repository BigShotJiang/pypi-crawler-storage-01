from tardis_em._version import version

__version__ = version
