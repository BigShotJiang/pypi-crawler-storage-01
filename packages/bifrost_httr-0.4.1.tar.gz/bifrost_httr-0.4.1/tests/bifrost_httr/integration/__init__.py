"""Integration tests for BIFROST-HTTr."""
