"""Tests for the visualization package.

This package contains tests for the visualization components of BIFROST HTTr,
including data visualization, report generation, and plotting utilities.
"""
