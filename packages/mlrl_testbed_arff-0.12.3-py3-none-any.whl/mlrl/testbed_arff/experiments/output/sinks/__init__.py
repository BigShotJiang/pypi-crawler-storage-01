"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to write output data to ARFF files.
"""
from mlrl.testbed_arff.experiments.output.sinks.sink_arff import ArffFileSink
