# fps-login

An FPS plugin for the login API.
