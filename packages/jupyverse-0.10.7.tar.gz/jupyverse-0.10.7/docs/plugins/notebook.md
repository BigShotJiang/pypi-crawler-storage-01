`fps-notebook` implements the Notebook API.
