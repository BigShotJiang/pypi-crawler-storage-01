
# 🙏 MaaHelper v0.0.2

**Modern Enhanced CLI with Multi-Provider AI Support**

Created by **Meet Solanki (AIML Student)**

[![PyPI version](https://badge.fury.io/py/maahelper.svg)](https://badge.fury.io/py/maahelper)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)


## ✨ Features

- 🎨 **Rich CLI**: Real-time streaming, beautiful panels, markdown/code rendering
- 🤖 **Multi-Provider AI**: OpenAI, Groq, Anthropic, Google, Ollama
- 📁 **AI File Analysis**: `file-search <filepath>` for code/data/doc files
- 🔐 **Secure API Key Management**: Local encrypted storage in `C:/Users/<username>/.ai_helper_agent/`
- 💬 **Interactive Chat**: Persistent conversation history, context-aware
- 🚀 **Async Performance**: Fast streaming, low memory, instant startup
- 📊 **Live Stats**: Session, file, and model metrics


## 🚀 Quick Start

### Installation

```bash
pip install maahelper
```

### Usage

```bash
# Start the CLI
ai-helper

# Or run via Python
python -m ai_helper_agent.cli.modern_enhanced_cli
```

### API Key Setup

On first run, you'll be prompted to enter API keys for Groq, OpenAI, etc. These are securely stored in:

```
C:/Users/<username>/.ai_helper_agent/config.json
```

You can manage, edit, or delete keys via the Rich UI manager:

```bash
ai-helper-keys
```


## 🎯 Core Commands

### Basic
- `help` — Show help
- `exit`, `quit`, `bye` — Exit
- `clear` — Clear history
- `status` — Show config

### File
- `file-search <filepath>` — AI file analysis
- `files` — Show files
- `dir` — Show directory

### Config
- `providers` — List providers
- `models` — List models


## 🤖 Supported AI Providers

| Provider | Models | Notes |
|----------|--------|-------|
| **Groq** | Llama 3.1, Llama 3.2, Mixtral, Gemma | ⚡ **Fastest & Free** |
| **OpenAI** | GPT-4, GPT-3.5-turbo | 🧠 Most capable |
| **Anthropic** | Claude 3, Claude 2 | 📝 Great for analysis |
| **Google** | Gemini Pro, Gemini Flash | 🔍 Multimodal support |
| **Ollama** | Local models | 🏠 Privacy-focused |


## 📁 File Analysis Example

```python
You: file-search src/main.py

🤖 AI Assistant
Analyzing your Python file...

File Analysis: src/main.py

File Type: Python Source Code
Size: 1.2KB
Language: Python 3.8+

### Key Components:
- Main Function: Entry point with argument parsing
- Error Handling: Comprehensive try-catch blocks
- Dependencies: requests, json, argparse

### Code Quality:
✅ Good Clean structure and readable code
⚠️ Suggestion: Add type hints for better maintainability
⚠️ Suggestion: Consider adding docstrings

### Recommendations:
1. Add input validation for user arguments
2. Implement logging for better debugging
3. Consider async/await for API calls
```


## 🎨 Rich CLI Features

- **Live Streaming**: See AI responses in real-time
- **Syntax Highlighting**: Code blocks with proper formatting
- **Progress Indicators**: Visual feedback for operations
- **Interactive Menus**: Beautiful provider and model selection
- **Error Handling**: Elegant error messages with helpful suggestions


## 🔧 Configuration

### API Key Management

MaaHelper uses a secure local configuration system:

```
C:\Users\{username}\.ai_helper_agent\
├── config.json          # Encrypted API keys
├── conversation_history/ # Chat sessions
└── logs/                # Application logs
```

### Environment Variables

```bash
# Recommended method
export GROQ_API_KEY="gsk_..."
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
export GOOGLE_API_KEY="AIza..."
```


## 📊 Performance

- **Streaming Speed**: Up to 500+ tokens/second with Groq
- **Memory Usage**: < 50MB typical usage
- **Startup Time**: < 2 seconds cold start
- **File Analysis**: Processes files up to 10MB


## 🛠️ Development

### Requirements
- Python 3.8+
- Rich >= 13.0.0
- OpenAI >= 1.0.0
- Cryptography >= 3.4.0

### Installation for Development

```bash
git clone https://github.com/AIMLDev726/maahelper.git
cd maahelper
pip install -e .
```


## 📝 Examples

### Basic Chat
```bash
You: Explain async/await in Python

🤖 AI Assistant
# Async/Await in Python

**Async/await** is Python's way of handling asynchronous programming...
```

### File Analysis
```bash
You: file-search requirements.txt

🤖 AI Assistant
## Dependency Analysis

Your project has **12 dependencies**:
- **Core**: openai, rich, cryptography
- **Optional**: anthropic, google-generativeai
- **Development**: pytest, black, flake8
```

### Code Review
```bash
You: Review this function for bugs

🤖 AI Assistant
## Code Review Results

✅ **Good Practices**:
- Clear function naming
- Proper error handling

⚠️ **Issues Found**:
- Missing input validation on line 15
- Potential memory leak in loop (line 23)
```


## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request


## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.


## 👨‍💻 Author

Created by **Meet Solanki (AIML Student)**

- GitHub: [@AIMLDev726](https://github.com/AIMLDev726)
- Email: aistudentlearn4@gmail.com


## 🙏 Acknowledgments

- Built with [Rich](https://github.com/Textualize/rich) for beautiful CLI
- Powered by [OpenAI](https://openai.com/) and multiple AI providers
- Thanks to the open-source Python community

---

**⭐ Star this repository if you find it helpful!**
