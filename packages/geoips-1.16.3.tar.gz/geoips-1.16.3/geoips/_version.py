# # # This source code is subject to the license referenced at
# # # https://github.com/NRLMMD-GEOIPS.

# DO NOT EDIT
# managed by poetry-dynamic-versioning
__version__ = "1.16.3"
__version_tuple__ = (1, 16, 3)
