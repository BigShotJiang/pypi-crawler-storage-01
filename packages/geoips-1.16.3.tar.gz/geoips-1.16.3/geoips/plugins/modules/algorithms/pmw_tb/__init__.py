# # # This source code is subject to the license referenced at
# # # https://github.com/NRLMMD-GEOIPS.

"""geoips pmw_tb algorithm init file."""
