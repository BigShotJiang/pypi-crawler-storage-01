# # # This source code is subject to the license referenced at
# # # https://github.com/NRLMMD-GEOIPS.

"""geoips filename_formatters init file."""
