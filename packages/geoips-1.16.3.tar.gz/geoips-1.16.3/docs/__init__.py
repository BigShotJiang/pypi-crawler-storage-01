# # # This source code is subject to the license referenced at
# # # https://github.com/NRLMMD-GEOIPS.

"""Needed so build_docs.py can import update_release_note_index.py."""
