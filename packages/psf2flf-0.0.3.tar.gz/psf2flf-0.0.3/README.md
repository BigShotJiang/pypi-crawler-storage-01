# ✍️ psf2flf

Converts bitmap fonts to figlet fonts.

## todo

- [x] support different readers and writers
- [ ] combine fonts by typeface
- [ ] unicode toilet font writer

