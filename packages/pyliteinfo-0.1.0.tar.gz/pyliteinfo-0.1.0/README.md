# PyLiteInfo

A simple Python library to fetch system, disk, CPU, and memory info, including largest files per drive.

## Install

```bash
pip install pyliteinfo
