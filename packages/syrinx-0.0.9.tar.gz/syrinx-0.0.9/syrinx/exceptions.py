
class ContentError(Exception):
    pass


class ThemeError(Exception):
    pass