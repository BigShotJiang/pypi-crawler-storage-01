from classiq.interface.enum_utils import StrEnum


class QSolver(StrEnum):
    QAOAPenalty = "QAOAPenalty"
    QAOAMixer = "QAOAMixer"
