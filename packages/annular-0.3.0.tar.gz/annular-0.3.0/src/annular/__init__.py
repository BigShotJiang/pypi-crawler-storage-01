"""Documentation about annular."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__author__ = "Sander van Rijn, Christian Doh Dinga"
__email__ = "s.vanrijn@esciencecenter.nl, c.dohdinga@tudelft.nl"
__version__ = "0.3.0"
