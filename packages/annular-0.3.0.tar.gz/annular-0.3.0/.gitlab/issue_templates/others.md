## Other issue

### Issue Description
Please provide a description of the issue here.

### Checklist

- [ ] I have checked the of [existing issues](https://gitlab.tudelft.nl/demoses/annular/-/issues) and couldn't find an issue about this.
