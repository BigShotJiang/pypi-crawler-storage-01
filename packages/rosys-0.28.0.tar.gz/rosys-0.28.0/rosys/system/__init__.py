from .wifi_button_ import WifiButton as wifi_button

__all__ = [
    'wifi_button',
]
