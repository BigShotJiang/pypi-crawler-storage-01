=================================
Layered Config Tree Documentation
=================================

Layered Config Tree is a configuration structure which supports cascading layers.

TBD.
