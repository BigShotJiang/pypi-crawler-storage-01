🚀 LoggerEx - Python Logging Made Beautifully Simple

🔍 Why LoggerEx?
Tired of complex logging setups? LoggerEx makes it simple:
from loggerex import logger  # That's it. You're done. 🎉
logger.success("Hello, beautiful logs!")

✨ Key Features:
- Zero-config magic
- Production-ready
- Developer-friendly
- Drop-in replacement for standard logging

⚡ Quick Start:
Installation:
pip install loggerex

Basic Usage:
```
from loggerex import logger
logger.debug("Debug message 🤓")
logger.info("Informational ℹ️")
logger.warning("Warning! ⚠️")
logger.error("Error occurred ❌")
logger.critical("CRITICAL! 🚨")
```

🌟 Premium Features:
1. Emoji Support: logger.rainbow("🌈 Colorful logs!")
2. Performance Tracking: @logger.timer()
3. Secret Masking: logger.mask(api_key)
4. Smart Formatting: logger.opt(colors=True)
5. Async Ready: await logger.async_debug()

🛠️ Advanced Configuration:
```
logger.configure(
    handlers=[
        {"sink": "file.log", "serialize": True},
        {"sink": sys.stderr, "colorize": True}
    ],
    levels=[{"name": "VERBOSE", "icon": "🔍"}],
    patch=True
)
```

📜 License: MIT - free forever

✨ Happy Logging! ✨