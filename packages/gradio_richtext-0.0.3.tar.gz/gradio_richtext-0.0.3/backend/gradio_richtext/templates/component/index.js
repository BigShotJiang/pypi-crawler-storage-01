import { I as f } from "./Index-mdUcgqjd.js";
export {
  f as default
};
