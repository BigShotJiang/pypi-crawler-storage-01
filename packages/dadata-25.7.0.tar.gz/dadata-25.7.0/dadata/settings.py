"""Dadata client settings"""

TIMEOUT_SEC = 3
SUGGESTION_COUNT = 10
