# llms.txt

For better AI integration, the documentation is provided in easy readable format by LLM's following the
[https://llmstxt.org/](https://llmstxt.org/) convention.

You can fetch it here :

* [llms.txt](/llms.txt)
* [llms-full.txt](/llms-full.txt)
