from datetime import datetime
def run_tool(_):
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")