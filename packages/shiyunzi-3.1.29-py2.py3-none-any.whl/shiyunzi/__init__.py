"""
SYZ Base Image Viewer
A simple image viewer built with PyQt6
"""

__version__ = "1.0.1" 