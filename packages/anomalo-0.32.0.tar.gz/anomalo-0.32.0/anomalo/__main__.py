from .anomalo import main


main()
