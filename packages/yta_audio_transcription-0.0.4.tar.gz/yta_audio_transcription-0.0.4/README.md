# Youtube Autonomous Audio Transcription Module

The Audio transcription module.

Please, check the 'pyproject.toml' file to see the dependencies.

