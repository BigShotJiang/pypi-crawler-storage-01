from django.shortcuts import render  # noqa: F401

# Create your views here.
