from django.contrib import admin  # noqa: F401

# Register your models here.
