1.  "Brand" group and filter is now available in MRP search view
