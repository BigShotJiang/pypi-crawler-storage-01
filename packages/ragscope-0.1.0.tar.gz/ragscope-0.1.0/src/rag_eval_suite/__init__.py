# Makes 'rag_eval_suite' a Python package and exposes its main functions and classes to users.

from .evaluator import RAGEvaluator