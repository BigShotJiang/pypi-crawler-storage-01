This module allows to add a substate to purchase order. For each
purchase order state you can define a substate. With this module you can
define substate which allow you to extend purchase workflow. For
example, you can add substate "waiting for legal documents" if the order
can not be validated without this document (purchase a car for example).
