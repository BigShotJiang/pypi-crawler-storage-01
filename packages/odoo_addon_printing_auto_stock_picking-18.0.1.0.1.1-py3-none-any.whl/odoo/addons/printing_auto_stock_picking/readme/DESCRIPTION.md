When a picking is done, automatically trigger the printing of some
documents. This can be used to print a delivery slip (report) or labels
received from the carrier (attachment).
