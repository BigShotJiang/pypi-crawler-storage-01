============
Bulk queries
============

.. automodule:: yadm.bulk
    :members:
