========
Database
========

.. automodule:: yadm.database

.. autoclass:: Database(client, name)
    :members:
