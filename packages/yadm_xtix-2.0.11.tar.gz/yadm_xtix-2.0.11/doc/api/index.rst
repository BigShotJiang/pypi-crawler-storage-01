===
API
===

API documentation

.. toctree::
   :maxdepth: 5

   database
   documents
   serialize
   queryset
   bulk
   aggregation
   join
   fields/index
