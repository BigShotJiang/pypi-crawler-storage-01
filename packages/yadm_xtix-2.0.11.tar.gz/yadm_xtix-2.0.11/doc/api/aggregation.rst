===========================
Mongo Aggregation Framework
===========================

.. automodule:: yadm.aggregation
    :members:
