========
Queryset
========

.. automodule:: yadm.queryset
    :members:
