====
Join
====

.. automodule:: yadm.join
    :members:
