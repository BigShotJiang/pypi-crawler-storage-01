Marker = type('Marker', (), {})

AttributeNotSet = type('AttributeNotSet', (Marker,), {})
NotLoaded = type('NotLoaded', (Marker,), {})
