from loguru import logger

from .core import DataMax
