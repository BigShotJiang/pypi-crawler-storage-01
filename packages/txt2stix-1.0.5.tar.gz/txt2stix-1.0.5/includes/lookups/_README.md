The following script can be run after importing the data -- these scripts will do this for you: https://github.com/muchdogesec/stix2arango/blob/main/utilities/README.md

Make sure the versions imported, match those in the searches below.

```shell
pip3 install python-arango
```

```shell
python3 includes/lookups/_generate_lookups.py
```