"""
Generate prior for the Cosmos model from the data
"""

from .prior_factory import PriorFactory

__all__ = ["PriorFactory"]
