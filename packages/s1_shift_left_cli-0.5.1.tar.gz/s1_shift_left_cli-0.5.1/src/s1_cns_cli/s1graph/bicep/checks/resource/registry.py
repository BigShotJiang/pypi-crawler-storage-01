from s1_cns_cli.s1graph.bicep.checks.resource.base_registry import Registry

registry = Registry()
