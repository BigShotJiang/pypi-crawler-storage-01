from s1_cns_cli.s1graph.arm.base_registry import Registry

arm_resource_registry = Registry()
arm_parameter_registry = Registry()
