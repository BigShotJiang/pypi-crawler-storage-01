# CloudFormation does not currently support.
#
# September 2021
#
#
# https://github.com/aws-cloudformation/cloudformation-coverage-roadmap/issues/922
