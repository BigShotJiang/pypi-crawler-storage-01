from s1_cns_cli.s1graph.argo_workflows.checks.template import *  # noqa
