"""rtrec - Realtime Recommendation Library"""

try:
    from importlib.metadata import version
    __version__ = version("rtrec")
except Exception:
    pass
