serverUUID = "00000000-cc7a-482a-984a-7f2ed5b3e58f"
character1 = "00000001-8e22-4541-9d4c-21edae82ed19"
character2 = "00000002-8e22-4541-9d4c-21edae82ed19"
