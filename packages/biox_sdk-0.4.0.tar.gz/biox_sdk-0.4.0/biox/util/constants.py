# 普通数据包
PKG_GEN_TYPE = 0
# EEG专用数据包
PKG_EEG_TYPE = 1
# IR专用数据包
PKG_IR_TYPE = 2

PKG_Motion_TYPE = 3

PKG_Metric_TYPE = 4

PKG_Heart_Rate_TYPE = 5

PKG_Marker_TYPE = 6

PKG_General_Metric_TYPE = 7

