# faculty-cli

`faculty` is the command line interface to the [Faculty platform](https://faculty.ai/products-services/platform/).
