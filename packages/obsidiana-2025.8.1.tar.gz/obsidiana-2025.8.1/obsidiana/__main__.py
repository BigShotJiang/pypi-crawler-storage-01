"""
Tools for working with Obsidian vaults.
"""

from obsidiana import _cli

_cli.main()
