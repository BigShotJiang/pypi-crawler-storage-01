The development of this module has been financially supported by:

- Associacion Española de Odoo ([AEODOO](https://www.aeodoo.org/))
