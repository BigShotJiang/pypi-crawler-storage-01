## init
from llama_index.tools.azure_code_interpreter.base import AzureCodeInterpreterToolSpec

__all__ = ["AzureCodeInterpreterToolSpec"]
