#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Staran 工具模块
=============

提供辅助功能和工具函数。
"""

__all__ = []
