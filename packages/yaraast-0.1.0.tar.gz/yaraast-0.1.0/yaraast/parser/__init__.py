"""YARA parser module."""

from yaraast.parser.better_parser import Parser
from yaraast.parser.parser import ParserError

__all__ = ["Parser", "ParserError"]
