"""CLI module for YARA AST."""
