#!/usr/bin/env python3


if __name__ == "__main__":
    print('["Error","Simulated adapter error","adapter-error","fake-adapter",["l"]]')
