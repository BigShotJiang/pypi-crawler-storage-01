from django.apps import AppConfig


class DjangoRqAdminConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "django_rq"
