|pypi| |downloads| |clinicedc|

adverse_event_app
-----------------

.. code-block:: bash

    pip install edc-adverse-event-app==1.0.2

Adverse Event App used for tests in clinicedc/edc projects

.. |pypi| image:: https://img.shields.io/pypi/v/adverse-event-app.svg
    :target: https://pypi.python.org/pypi/adverse-event-app

.. |downloads| image:: https://pepy.tech/badge/adverse-event-app
   :target: https://pepy.tech/project/adverse-event-app

.. |clinicedc| image:: https://img.shields.io/badge/framework-Clinic_EDC-green
   :alt:Made with clinicedc
   :target: https://github.com/clinicedc
