#!/usr/bin/env python3

# Templates class, pylint: disable=too-few-public-methods
class Templates:

    # Constants
    COMMITS_FILE: str = 'commits.yml'
    GITLAB_CI_LOCAL_FOLDER: str = '.gitlab-ci.d'
    TEMPLATES_EOL: str = '\n'
