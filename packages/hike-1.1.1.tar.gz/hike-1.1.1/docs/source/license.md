# Hike is licensed GPLv3+

```bash exec="on"
hike --license
```

[//]: # (license.md ends here)
