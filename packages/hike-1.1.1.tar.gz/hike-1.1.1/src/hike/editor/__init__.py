"""Provides the builtin Markdown editor."""

##############################################################################
# Local imports.
from .screen import Editor

##############################################################################
# Exports.
__all__ = ["Editor"]


### __init__.py ends here
