from typing import Optional, Dict, Tuple, AsyncIterator, Any

class SshClient:
    pass
