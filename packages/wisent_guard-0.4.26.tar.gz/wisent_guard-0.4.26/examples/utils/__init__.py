"""
Utility functions for example scripts.
"""
