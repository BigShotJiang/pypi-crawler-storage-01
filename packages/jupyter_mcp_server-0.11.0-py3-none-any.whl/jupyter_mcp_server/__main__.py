# Copyright (c) 2023-2024 Datalayer, Inc.
#
# BSD 3-Clause License

from jupyter_mcp_server.server import start_command

if __name__ == "__main__":
    """Start the Jupyter MCP Server."""
    start_command()
