"""MCP Types package."""
