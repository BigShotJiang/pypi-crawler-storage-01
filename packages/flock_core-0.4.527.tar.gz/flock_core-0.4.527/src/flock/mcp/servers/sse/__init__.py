"""Default SSE Server Implementation for Flock."""
