"""Default router implementation for the Flock framework."""
