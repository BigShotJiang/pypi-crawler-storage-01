"""
icloudpd-web package.
"""

__version__ = "2025.7.31"
