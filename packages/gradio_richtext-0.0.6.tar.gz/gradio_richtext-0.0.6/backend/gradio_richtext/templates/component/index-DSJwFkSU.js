import { p as P, a as O, s as w, b as R } from "./index-CpVxDhhD.js";
import { d as k } from "./index-Cu1EQZGJ.js";
import { v as F } from "./index-MxBukWlM.js";
function x(t) {
  const e = [];
  let n = -1, r = 0, l = 0;
  for (; ++n < t.length; ) {
    const i = t.charCodeAt(n);
    let a = "";
    if (i === 37 && k(t.charCodeAt(n + 1)) && k(t.charCodeAt(n + 2)))
      l = 2;
    else if (i < 128)
      /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(i)) || (a = String.fromCharCode(i));
    else if (i > 55295 && i < 57344) {
      const c = t.charCodeAt(n + 1);
      i < 56320 && c > 56319 && c < 57344 ? (a = String.fromCharCode(i, c), l = 1) : a = "�";
    } else
      a = String.fromCharCode(i);
    a && (e.push(t.slice(r, n), encodeURIComponent(a)), r = n + l + 1, a = ""), l && (n += l, l = 0);
  }
  return e.join("") + t.slice(r);
}
function U(t, e) {
  const n = {
    type: "element",
    tagName: "blockquote",
    properties: {},
    children: t.wrap(t.all(e), !0)
  };
  return t.patch(e, n), t.applyData(e, n);
}
function T(t, e) {
  const n = { type: "element", tagName: "br", properties: {}, children: [] };
  return t.patch(e, n), [t.applyData(e, n), { type: "text", value: `
` }];
}
function _(t, e) {
  const n = e.value ? e.value + `
` : "", r = {};
  e.lang && (r.className = ["language-" + e.lang]);
  let l = {
    type: "element",
    tagName: "code",
    properties: r,
    children: [{ type: "text", value: n }]
  };
  return e.meta && (l.data = { meta: e.meta }), t.patch(e, l), l = t.applyData(e, l), l = { type: "element", tagName: "pre", properties: {}, children: [l] }, t.patch(e, l), l;
}
function H(t, e) {
  const n = {
    type: "element",
    tagName: "del",
    properties: {},
    children: t.all(e)
  };
  return t.patch(e, n), t.applyData(e, n);
}
function M(t, e) {
  const n = {
    type: "element",
    tagName: "em",
    properties: {},
    children: t.all(e)
  };
  return t.patch(e, n), t.applyData(e, n);
}
function j(t, e) {
  const n = typeof t.options.clobberPrefix == "string" ? t.options.clobberPrefix : "user-content-", r = String(e.identifier).toUpperCase(), l = x(r.toLowerCase()), i = t.footnoteOrder.indexOf(r);
  let a, c = t.footnoteCounts.get(r);
  c === void 0 ? (c = 0, t.footnoteOrder.push(r), a = t.footnoteOrder.length) : a = i + 1, c += 1, t.footnoteCounts.set(r, c);
  const u = {
    type: "element",
    tagName: "a",
    properties: {
      href: "#" + n + "fn-" + l,
      id: n + "fnref-" + l + (c > 1 ? "-" + c : ""),
      dataFootnoteRef: !0,
      ariaDescribedBy: ["footnote-label"]
    },
    children: [{ type: "text", value: String(a) }]
  };
  t.patch(e, u);
  const y = {
    type: "element",
    tagName: "sup",
    properties: {},
    children: [u]
  };
  return t.patch(e, y), t.applyData(e, y);
}
function q(t, e) {
  const n = {
    type: "element",
    tagName: "h" + e.depth,
    properties: {},
    children: t.all(e)
  };
  return t.patch(e, n), t.applyData(e, n);
}
function z(t, e) {
  if (t.options.allowDangerousHtml) {
    const n = { type: "raw", value: e.value };
    return t.patch(e, n), t.applyData(e, n);
  }
}
function B(t, e) {
  const n = e.referenceType;
  let r = "]";
  if (n === "collapsed" ? r += "[]" : n === "full" && (r += "[" + (e.label || e.identifier) + "]"), e.type === "imageReference")
    return [{ type: "text", value: "![" + e.alt + r }];
  const l = t.all(e), i = l[0];
  i && i.type === "text" ? i.value = "[" + i.value : l.unshift({ type: "text", value: "[" });
  const a = l[l.length - 1];
  return a && a.type === "text" ? a.value += r : l.push({ type: "text", value: r }), l;
}
function $(t, e) {
  const n = String(e.identifier).toUpperCase(), r = t.definitionById.get(n);
  if (!r)
    return B(t, e);
  const l = { src: x(r.url || ""), alt: e.alt };
  r.title !== null && r.title !== void 0 && (l.title = r.title);
  const i = { type: "element", tagName: "img", properties: l, children: [] };
  return t.patch(e, i), t.applyData(e, i);
}
function E(t, e) {
  const n = { src: x(e.url) };
  e.alt !== null && e.alt !== void 0 && (n.alt = e.alt), e.title !== null && e.title !== void 0 && (n.title = e.title);
  const r = { type: "element", tagName: "img", properties: n, children: [] };
  return t.patch(e, r), t.applyData(e, r);
}
function V(t, e) {
  const n = { type: "text", value: e.value.replace(/\r?\n|\r/g, " ") };
  t.patch(e, n);
  const r = {
    type: "element",
    tagName: "code",
    properties: {},
    children: [n]
  };
  return t.patch(e, r), t.applyData(e, r);
}
function Z(t, e) {
  const n = String(e.identifier).toUpperCase(), r = t.definitionById.get(n);
  if (!r)
    return B(t, e);
  const l = { href: x(r.url || "") };
  r.title !== null && r.title !== void 0 && (l.title = r.title);
  const i = {
    type: "element",
    tagName: "a",
    properties: l,
    children: t.all(e)
  };
  return t.patch(e, i), t.applyData(e, i);
}
function G(t, e) {
  const n = { href: x(e.url) };
  e.title !== null && e.title !== void 0 && (n.title = e.title);
  const r = {
    type: "element",
    tagName: "a",
    properties: n,
    children: t.all(e)
  };
  return t.patch(e, r), t.applyData(e, r);
}
function J(t, e, n) {
  const r = t.all(e), l = n ? K(n) : L(e), i = {}, a = [];
  if (typeof e.checked == "boolean") {
    const o = r[0];
    let p;
    o && o.type === "element" && o.tagName === "p" ? p = o : (p = { type: "element", tagName: "p", properties: {}, children: [] }, r.unshift(p)), p.children.length > 0 && p.children.unshift({ type: "text", value: " " }), p.children.unshift({
      type: "element",
      tagName: "input",
      properties: { type: "checkbox", checked: e.checked, disabled: !0 },
      children: []
    }), i.className = ["task-list-item"];
  }
  let c = -1;
  for (; ++c < r.length; ) {
    const o = r[c];
    (l || c !== 0 || o.type !== "element" || o.tagName !== "p") && a.push({ type: "text", value: `
` }), o.type === "element" && o.tagName === "p" && !l ? a.push(...o.children) : a.push(o);
  }
  const u = r[r.length - 1];
  u && (l || u.type !== "element" || u.tagName !== "p") && a.push({ type: "text", value: `
` });
  const y = { type: "element", tagName: "li", properties: i, children: a };
  return t.patch(e, y), t.applyData(e, y);
}
function K(t) {
  let e = !1;
  if (t.type === "list") {
    e = t.spread || !1;
    const n = t.children;
    let r = -1;
    for (; !e && ++r < n.length; )
      e = L(n[r]);
  }
  return e;
}
function L(t) {
  const e = t.spread;
  return e ?? t.children.length > 1;
}
function Q(t, e) {
  const n = {}, r = t.all(e);
  let l = -1;
  for (typeof e.start == "number" && e.start !== 1 && (n.start = e.start); ++l < r.length; ) {
    const a = r[l];
    if (a.type === "element" && a.tagName === "li" && a.properties && Array.isArray(a.properties.className) && a.properties.className.includes("task-list-item")) {
      n.className = ["contains-task-list"];
      break;
    }
  }
  const i = {
    type: "element",
    tagName: e.ordered ? "ol" : "ul",
    properties: n,
    children: t.wrap(r, !0)
  };
  return t.patch(e, i), t.applyData(e, i);
}
function W(t, e) {
  const n = {
    type: "element",
    tagName: "p",
    properties: {},
    children: t.all(e)
  };
  return t.patch(e, n), t.applyData(e, n);
}
function X(t, e) {
  const n = { type: "root", children: t.wrap(t.all(e)) };
  return t.patch(e, n), t.applyData(e, n);
}
function Y(t, e) {
  const n = {
    type: "element",
    tagName: "strong",
    properties: {},
    children: t.all(e)
  };
  return t.patch(e, n), t.applyData(e, n);
}
function ee(t, e) {
  const n = t.all(e), r = n.shift(), l = [];
  if (r) {
    const a = {
      type: "element",
      tagName: "thead",
      properties: {},
      children: t.wrap([r], !0)
    };
    t.patch(e.children[0], a), l.push(a);
  }
  if (n.length > 0) {
    const a = {
      type: "element",
      tagName: "tbody",
      properties: {},
      children: t.wrap(n, !0)
    }, c = P(e.children[1]), u = O(e.children[e.children.length - 1]);
    c && u && (a.position = { start: c, end: u }), l.push(a);
  }
  const i = {
    type: "element",
    tagName: "table",
    properties: {},
    children: t.wrap(l, !0)
  };
  return t.patch(e, i), t.applyData(e, i);
}
function te(t, e, n) {
  const r = n ? n.children : void 0, i = (r ? r.indexOf(e) : 1) === 0 ? "th" : "td", a = n && n.type === "table" ? n.align : void 0, c = a ? a.length : e.children.length;
  let u = -1;
  const y = [];
  for (; ++u < c; ) {
    const p = e.children[u], h = {}, f = a ? a[u] : void 0;
    f && (h.align = f);
    let s = { type: "element", tagName: i, properties: h, children: [] };
    p && (s.children = t.all(p), t.patch(p, s), s = t.applyData(p, s)), y.push(s);
  }
  const o = {
    type: "element",
    tagName: "tr",
    properties: {},
    children: t.wrap(y, !0)
  };
  return t.patch(e, o), t.applyData(e, o);
}
function ne(t, e) {
  const n = {
    type: "element",
    tagName: "td",
    // Assume body cell.
    properties: {},
    children: t.all(e)
  };
  return t.patch(e, n), t.applyData(e, n);
}
const v = 9, D = 32;
function re(t) {
  const e = String(t), n = /\r?\n|\r/g;
  let r = n.exec(e), l = 0;
  const i = [];
  for (; r; )
    i.push(
      A(e.slice(l, r.index), l > 0, !0),
      r[0]
    ), l = r.index + r[0].length, r = n.exec(e);
  return i.push(A(e.slice(l), l > 0, !1)), i.join("");
}
function A(t, e, n) {
  let r = 0, l = t.length;
  if (e) {
    let i = t.codePointAt(r);
    for (; i === v || i === D; )
      r++, i = t.codePointAt(r);
  }
  if (n) {
    let i = t.codePointAt(l - 1);
    for (; i === v || i === D; )
      l--, i = t.codePointAt(l - 1);
  }
  return l > r ? t.slice(r, l) : "";
}
function le(t, e) {
  const n = { type: "text", value: re(String(e.value)) };
  return t.patch(e, n), t.applyData(e, n);
}
function ie(t, e) {
  const n = {
    type: "element",
    tagName: "hr",
    properties: {},
    children: []
  };
  return t.patch(e, n), t.applyData(e, n);
}
const ae = {
  blockquote: U,
  break: T,
  code: _,
  delete: H,
  emphasis: M,
  footnoteReference: j,
  heading: q,
  html: z,
  imageReference: $,
  image: E,
  inlineCode: V,
  linkReference: Z,
  link: G,
  listItem: J,
  list: Q,
  paragraph: W,
  // @ts-expect-error: root is different, but hard to type.
  root: X,
  strong: Y,
  table: ee,
  tableCell: ne,
  tableRow: te,
  text: le,
  thematicBreak: ie,
  toml: b,
  yaml: b,
  definition: b,
  footnoteDefinition: b
};
function b() {
}
function oe(t, e) {
  const n = [{ type: "text", value: "↩" }];
  return e > 1 && n.push({
    type: "element",
    tagName: "sup",
    properties: {},
    children: [{ type: "text", value: String(e) }]
  }), n;
}
function ce(t, e) {
  return "Back to reference " + (t + 1) + (e > 1 ? "-" + e : "");
}
function pe(t) {
  const e = typeof t.options.clobberPrefix == "string" ? t.options.clobberPrefix : "user-content-", n = t.options.footnoteBackContent || oe, r = t.options.footnoteBackLabel || ce, l = t.options.footnoteLabel || "Footnotes", i = t.options.footnoteLabelTagName || "h2", a = t.options.footnoteLabelProperties || {
    className: ["sr-only"]
  }, c = [];
  let u = -1;
  for (; ++u < t.footnoteOrder.length; ) {
    const y = t.footnoteById.get(
      t.footnoteOrder[u]
    );
    if (!y)
      continue;
    const o = t.all(y), p = String(y.identifier).toUpperCase(), h = x(p.toLowerCase());
    let f = 0;
    const s = [], g = t.footnoteCounts.get(p);
    for (; g !== void 0 && ++f <= g; ) {
      s.length > 0 && s.push({ type: "text", value: " " });
      let d = typeof n == "string" ? n : n(u, f);
      typeof d == "string" && (d = { type: "text", value: d }), s.push({
        type: "element",
        tagName: "a",
        properties: {
          href: "#" + e + "fnref-" + h + (f > 1 ? "-" + f : ""),
          dataFootnoteBackref: "",
          ariaLabel: typeof r == "string" ? r : r(u, f),
          className: ["data-footnote-backref"]
        },
        children: Array.isArray(d) ? d : [d]
      });
    }
    const m = o[o.length - 1];
    if (m && m.type === "element" && m.tagName === "p") {
      const d = m.children[m.children.length - 1];
      d && d.type === "text" ? d.value += " " : m.children.push({ type: "text", value: " " }), m.children.push(...s);
    } else
      o.push(...s);
    const N = {
      type: "element",
      tagName: "li",
      properties: { id: e + "fn-" + h },
      children: t.wrap(o, !0)
    };
    t.patch(y, N), c.push(N);
  }
  if (c.length !== 0)
    return {
      type: "element",
      tagName: "section",
      properties: { dataFootnotes: !0, className: ["footnotes"] },
      children: [
        {
          type: "element",
          tagName: i,
          properties: {
            ...w(a),
            id: "footnote-label"
          },
          children: [{ type: "text", value: l }]
        },
        { type: "text", value: `
` },
        {
          type: "element",
          tagName: "ol",
          properties: {},
          children: t.wrap(c, !0)
        },
        { type: "text", value: `
` }
      ]
    };
}
const C = {}.hasOwnProperty, se = {};
function ue(t, e) {
  const n = e || se, r = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = { ...ae, ...n.handlers }, c = {
    all: y,
    applyData: fe,
    definitionById: r,
    footnoteById: l,
    footnoteCounts: i,
    footnoteOrder: [],
    handlers: a,
    one: u,
    options: n,
    patch: he,
    wrap: de
  };
  return F(t, function(o) {
    if (o.type === "definition" || o.type === "footnoteDefinition") {
      const p = o.type === "definition" ? r : l, h = String(o.identifier).toUpperCase();
      p.has(h) || p.set(h, o);
    }
  }), c;
  function u(o, p) {
    const h = o.type, f = c.handlers[h];
    if (C.call(c.handlers, h) && f)
      return f(c, o, p);
    if (c.options.passThrough && c.options.passThrough.includes(h)) {
      if ("children" in o) {
        const { children: g, ...m } = o, N = w(m);
        return N.children = c.all(o), N;
      }
      return w(o);
    }
    return (c.options.unknownHandler || ye)(c, o, p);
  }
  function y(o) {
    const p = [];
    if ("children" in o) {
      const h = o.children;
      let f = -1;
      for (; ++f < h.length; ) {
        const s = c.one(h[f], o);
        if (s) {
          if (f && h[f - 1].type === "break" && (!Array.isArray(s) && s.type === "text" && (s.value = I(s.value)), !Array.isArray(s) && s.type === "element")) {
            const g = s.children[0];
            g && g.type === "text" && (g.value = I(g.value));
          }
          Array.isArray(s) ? p.push(...s) : p.push(s);
        }
      }
    }
    return p;
  }
}
function he(t, e) {
  t.position && (e.position = R(t));
}
function fe(t, e) {
  let n = e;
  if (t && t.data) {
    const r = t.data.hName, l = t.data.hChildren, i = t.data.hProperties;
    if (typeof r == "string")
      if (n.type === "element")
        n.tagName = r;
      else {
        const a = "children" in n ? n.children : [n];
        n = { type: "element", tagName: r, properties: {}, children: a };
      }
    n.type === "element" && i && Object.assign(n.properties, w(i)), "children" in n && n.children && l !== null && l !== void 0 && (n.children = l);
  }
  return n;
}
function ye(t, e) {
  const n = e.data || {}, r = "value" in e && !(C.call(n, "hProperties") || C.call(n, "hChildren")) ? { type: "text", value: e.value } : {
    type: "element",
    tagName: "div",
    properties: {},
    children: t.all(e)
  };
  return t.patch(e, r), t.applyData(e, r);
}
function de(t, e) {
  const n = [];
  let r = -1;
  for (e && n.push({ type: "text", value: `
` }); ++r < t.length; )
    r && n.push({ type: "text", value: `
` }), n.push(t[r]);
  return e && t.length > 0 && n.push({ type: "text", value: `
` }), n;
}
function I(t) {
  let e = 0, n = t.charCodeAt(e);
  for (; n === 9 || n === 32; )
    e++, n = t.charCodeAt(e);
  return t.slice(e);
}
function S(t, e) {
  const n = ue(t, e), r = n.one(t, void 0), l = pe(n), i = Array.isArray(r) ? { type: "root", children: r } : r || { type: "root", children: [] };
  return l && i.children.push({ type: "text", value: `
` }, l), i;
}
function Ne(t, e) {
  return t && "run" in t ? async function(n, r) {
    const l = (
      /** @type {HastRoot} */
      S(n, { file: r, ...e })
    );
    await t.run(l, r);
  } : function(n, r) {
    return (
      /** @type {HastRoot} */
      S(n, { file: r, ...t || e })
    );
  };
}
export {
  Ne as default,
  oe as defaultFootnoteBackContent,
  ce as defaultFootnoteBackLabel,
  ae as defaultHandlers
};
