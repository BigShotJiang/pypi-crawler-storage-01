import { b as f, c as s } from "./index-Cu1EQZGJ.js";
function k(e) {
  return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
function h(e, n, r, t) {
  const l = e.length;
  let i = 0, u;
  if (n < 0 ? n = -n > l ? 0 : l + n : n = n > l ? l : n, r = r > 0 ? r : 0, t.length < 1e4)
    u = Array.from(t), u.unshift(n, r), e.splice(...u);
  else
    for (r && e.splice(n, r); i < t.length; )
      u = t.slice(i, i + 1e4), u.unshift(n, 0), e.splice(...u), i += 1e4, n += 1e4;
}
function d(e, n) {
  return e.length > 0 ? (h(e, e.length, 0, n), e) : n;
}
const a = {}.hasOwnProperty;
function x(e) {
  const n = {};
  let r = -1;
  for (; ++r < e.length; )
    p(n, e[r]);
  return n;
}
function p(e, n) {
  let r;
  for (r in n) {
    const l = (a.call(e, r) ? e[r] : void 0) || (e[r] = {}), i = n[r];
    let u;
    if (i)
      for (u in i) {
        a.call(l, u) || (l[u] = []);
        const o = i[u];
        g(
          // @ts-expect-error Looks like a list.
          l[u],
          Array.isArray(o) ? o : o ? [o] : []
        );
      }
  }
}
function g(e, n) {
  let r = -1;
  const t = [];
  for (; ++r < n.length; )
    (n[r].add === "after" ? e : t).push(n[r]);
  h(e, 0, 0, t);
}
function I(e, n, r) {
  const t = [];
  let l = -1;
  for (; ++l < e.length; ) {
    const i = e[l].resolveAll;
    i && !t.includes(i) && (n = i(n, r), t.push(i));
  }
  return n;
}
function w(e, n, r, t) {
  const l = t ? t - 1 : Number.POSITIVE_INFINITY;
  let i = 0;
  return u;
  function u(c) {
    return f(c) ? (e.enter(r), o(c)) : n(c);
  }
  function o(c) {
    return f(c) && i++ < l ? (e.consume(c), o) : (e.exit(r), n(c));
  }
}
const A = {
  partial: !0,
  tokenize: b
};
function b(e, n, r) {
  return t;
  function t(i) {
    return f(i) ? w(e, l, "linePrefix")(i) : l(i);
  }
  function l(i) {
    return i === null || s(i) ? n(i) : r(i);
  }
}
export {
  A as b,
  x as c,
  w as f,
  k as n,
  d as p,
  I as r,
  h as s
};
