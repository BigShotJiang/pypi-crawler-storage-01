import { _, l as Q, c as nt, H as Et, V as Lt, F as tt, i as q, W as Tt, X as Nt, Y as mt, d as Dt, am as Ot, N as At } from "./mermaid.core-BshCbZ_5.js";
import { c as ut } from "./cytoscape.esm-CphbmbIK.js";
import { c as at, g as It } from "./Index-DAWbLH7y.js";
var ft = { exports: {} }, rt = { exports: {} }, it = { exports: {} }, ct;
function Ct() {
  return ct || (ct = 1, function(C, M) {
    (function(D, y) {
      C.exports = y();
    })(at, function() {
      return (
        /******/
        function(u) {
          var D = {};
          function y(r) {
            if (D[r])
              return D[r].exports;
            var t = D[r] = {
              /******/
              i: r,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return u[r].call(t.exports, t, t.exports, y), t.l = !0, t.exports;
          }
          return y.m = u, y.c = D, y.i = function(r) {
            return r;
          }, y.d = function(r, t, e) {
            y.o(r, t) || Object.defineProperty(r, t, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: e
              /******/
            });
          }, y.n = function(r) {
            var t = r && r.__esModule ? (
              /******/
              function() {
                return r.default;
              }
            ) : (
              /******/
              function() {
                return r;
              }
            );
            return y.d(t, "a", t), t;
          }, y.o = function(r, t) {
            return Object.prototype.hasOwnProperty.call(r, t);
          }, y.p = "", y(y.s = 26);
        }([
          /* 0 */
          /***/
          function(u, D, y) {
            function r() {
            }
            r.QUALITY = 1, r.DEFAULT_CREATE_BENDS_AS_NEEDED = !1, r.DEFAULT_INCREMENTAL = !1, r.DEFAULT_ANIMATION_ON_LAYOUT = !0, r.DEFAULT_ANIMATION_DURING_LAYOUT = !1, r.DEFAULT_ANIMATION_PERIOD = 50, r.DEFAULT_UNIFORM_LEAF_NODE_SIZES = !1, r.DEFAULT_GRAPH_MARGIN = 15, r.NODE_DIMENSIONS_INCLUDE_LABELS = !1, r.SIMPLE_NODE_SIZE = 40, r.SIMPLE_NODE_HALF_SIZE = r.SIMPLE_NODE_SIZE / 2, r.EMPTY_COMPOUND_NODE_SIZE = 40, r.MIN_EDGE_LENGTH = 1, r.WORLD_BOUNDARY = 1e6, r.INITIAL_WORLD_BOUNDARY = r.WORLD_BOUNDARY / 1e3, r.WORLD_CENTER_X = 1200, r.WORLD_CENTER_Y = 900, u.exports = r;
          },
          /* 1 */
          /***/
          function(u, D, y) {
            var r = y(2), t = y(8), e = y(9);
            function i(g, a, v) {
              r.call(this, v), this.isOverlapingSourceAndTarget = !1, this.vGraphObject = v, this.bendpoints = [], this.source = g, this.target = a;
            }
            i.prototype = Object.create(r.prototype);
            for (var o in r)
              i[o] = r[o];
            i.prototype.getSource = function() {
              return this.source;
            }, i.prototype.getTarget = function() {
              return this.target;
            }, i.prototype.isInterGraph = function() {
              return this.isInterGraph;
            }, i.prototype.getLength = function() {
              return this.length;
            }, i.prototype.isOverlapingSourceAndTarget = function() {
              return this.isOverlapingSourceAndTarget;
            }, i.prototype.getBendpoints = function() {
              return this.bendpoints;
            }, i.prototype.getLca = function() {
              return this.lca;
            }, i.prototype.getSourceInLca = function() {
              return this.sourceInLca;
            }, i.prototype.getTargetInLca = function() {
              return this.targetInLca;
            }, i.prototype.getOtherEnd = function(g) {
              if (this.source === g)
                return this.target;
              if (this.target === g)
                return this.source;
              throw "Node is not incident with this edge";
            }, i.prototype.getOtherEndInGraph = function(g, a) {
              for (var v = this.getOtherEnd(g), n = a.getGraphManager().getRoot(); ; ) {
                if (v.getOwner() == a)
                  return v;
                if (v.getOwner() == n)
                  break;
                v = v.getOwner().getParent();
              }
              return null;
            }, i.prototype.updateLength = function() {
              var g = new Array(4);
              this.isOverlapingSourceAndTarget = t.getIntersection(this.target.getRect(), this.source.getRect(), g), this.isOverlapingSourceAndTarget || (this.lengthX = g[0] - g[2], this.lengthY = g[1] - g[3], Math.abs(this.lengthX) < 1 && (this.lengthX = e.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = e.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY));
            }, i.prototype.updateLengthSimple = function() {
              this.lengthX = this.target.getCenterX() - this.source.getCenterX(), this.lengthY = this.target.getCenterY() - this.source.getCenterY(), Math.abs(this.lengthX) < 1 && (this.lengthX = e.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = e.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY);
            }, u.exports = i;
          },
          /* 2 */
          /***/
          function(u, D, y) {
            function r(t) {
              this.vGraphObject = t;
            }
            u.exports = r;
          },
          /* 3 */
          /***/
          function(u, D, y) {
            var r = y(2), t = y(10), e = y(13), i = y(0), o = y(16), g = y(4);
            function a(n, c, l, E) {
              l == null && E == null && (E = c), r.call(this, E), n.graphManager != null && (n = n.graphManager), this.estimatedSize = t.MIN_VALUE, this.inclusionTreeDepth = t.MAX_VALUE, this.vGraphObject = E, this.edges = [], this.graphManager = n, l != null && c != null ? this.rect = new e(c.x, c.y, l.width, l.height) : this.rect = new e();
            }
            a.prototype = Object.create(r.prototype);
            for (var v in r)
              a[v] = r[v];
            a.prototype.getEdges = function() {
              return this.edges;
            }, a.prototype.getChild = function() {
              return this.child;
            }, a.prototype.getOwner = function() {
              return this.owner;
            }, a.prototype.getWidth = function() {
              return this.rect.width;
            }, a.prototype.setWidth = function(n) {
              this.rect.width = n;
            }, a.prototype.getHeight = function() {
              return this.rect.height;
            }, a.prototype.setHeight = function(n) {
              this.rect.height = n;
            }, a.prototype.getCenterX = function() {
              return this.rect.x + this.rect.width / 2;
            }, a.prototype.getCenterY = function() {
              return this.rect.y + this.rect.height / 2;
            }, a.prototype.getCenter = function() {
              return new g(this.rect.x + this.rect.width / 2, this.rect.y + this.rect.height / 2);
            }, a.prototype.getLocation = function() {
              return new g(this.rect.x, this.rect.y);
            }, a.prototype.getRect = function() {
              return this.rect;
            }, a.prototype.getDiagonal = function() {
              return Math.sqrt(this.rect.width * this.rect.width + this.rect.height * this.rect.height);
            }, a.prototype.getHalfTheDiagonal = function() {
              return Math.sqrt(this.rect.height * this.rect.height + this.rect.width * this.rect.width) / 2;
            }, a.prototype.setRect = function(n, c) {
              this.rect.x = n.x, this.rect.y = n.y, this.rect.width = c.width, this.rect.height = c.height;
            }, a.prototype.setCenter = function(n, c) {
              this.rect.x = n - this.rect.width / 2, this.rect.y = c - this.rect.height / 2;
            }, a.prototype.setLocation = function(n, c) {
              this.rect.x = n, this.rect.y = c;
            }, a.prototype.moveBy = function(n, c) {
              this.rect.x += n, this.rect.y += c;
            }, a.prototype.getEdgeListToNode = function(n) {
              var c = [], l = this;
              return l.edges.forEach(function(E) {
                if (E.target == n) {
                  if (E.source != l) throw "Incorrect edge source!";
                  c.push(E);
                }
              }), c;
            }, a.prototype.getEdgesBetween = function(n) {
              var c = [], l = this;
              return l.edges.forEach(function(E) {
                if (!(E.source == l || E.target == l)) throw "Incorrect edge source and/or target";
                (E.target == n || E.source == n) && c.push(E);
              }), c;
            }, a.prototype.getNeighborsList = function() {
              var n = /* @__PURE__ */ new Set(), c = this;
              return c.edges.forEach(function(l) {
                if (l.source == c)
                  n.add(l.target);
                else {
                  if (l.target != c)
                    throw "Incorrect incidency!";
                  n.add(l.source);
                }
              }), n;
            }, a.prototype.withChildren = function() {
              var n = /* @__PURE__ */ new Set(), c, l;
              if (n.add(this), this.child != null)
                for (var E = this.child.getNodes(), T = 0; T < E.length; T++)
                  c = E[T], l = c.withChildren(), l.forEach(function(m) {
                    n.add(m);
                  });
              return n;
            }, a.prototype.getNoOfChildren = function() {
              var n = 0, c;
              if (this.child == null)
                n = 1;
              else
                for (var l = this.child.getNodes(), E = 0; E < l.length; E++)
                  c = l[E], n += c.getNoOfChildren();
              return n == 0 && (n = 1), n;
            }, a.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == t.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, a.prototype.calcEstimatedSize = function() {
              return this.child == null ? this.estimatedSize = (this.rect.width + this.rect.height) / 2 : (this.estimatedSize = this.child.calcEstimatedSize(), this.rect.width = this.estimatedSize, this.rect.height = this.estimatedSize, this.estimatedSize);
            }, a.prototype.scatter = function() {
              var n, c, l = -i.INITIAL_WORLD_BOUNDARY, E = i.INITIAL_WORLD_BOUNDARY;
              n = i.WORLD_CENTER_X + o.nextDouble() * (E - l) + l;
              var T = -i.INITIAL_WORLD_BOUNDARY, m = i.INITIAL_WORLD_BOUNDARY;
              c = i.WORLD_CENTER_Y + o.nextDouble() * (m - T) + T, this.rect.x = n, this.rect.y = c;
            }, a.prototype.updateBounds = function() {
              if (this.getChild() == null)
                throw "assert failed";
              if (this.getChild().getNodes().length != 0) {
                var n = this.getChild();
                if (n.updateBounds(!0), this.rect.x = n.getLeft(), this.rect.y = n.getTop(), this.setWidth(n.getRight() - n.getLeft()), this.setHeight(n.getBottom() - n.getTop()), i.NODE_DIMENSIONS_INCLUDE_LABELS) {
                  var c = n.getRight() - n.getLeft(), l = n.getBottom() - n.getTop();
                  this.labelWidth > c && (this.rect.x -= (this.labelWidth - c) / 2, this.setWidth(this.labelWidth)), this.labelHeight > l && (this.labelPos == "center" ? this.rect.y -= (this.labelHeight - l) / 2 : this.labelPos == "top" && (this.rect.y -= this.labelHeight - l), this.setHeight(this.labelHeight));
                }
              }
            }, a.prototype.getInclusionTreeDepth = function() {
              if (this.inclusionTreeDepth == t.MAX_VALUE)
                throw "assert failed";
              return this.inclusionTreeDepth;
            }, a.prototype.transform = function(n) {
              var c = this.rect.x;
              c > i.WORLD_BOUNDARY ? c = i.WORLD_BOUNDARY : c < -i.WORLD_BOUNDARY && (c = -i.WORLD_BOUNDARY);
              var l = this.rect.y;
              l > i.WORLD_BOUNDARY ? l = i.WORLD_BOUNDARY : l < -i.WORLD_BOUNDARY && (l = -i.WORLD_BOUNDARY);
              var E = new g(c, l), T = n.inverseTransformPoint(E);
              this.setLocation(T.x, T.y);
            }, a.prototype.getLeft = function() {
              return this.rect.x;
            }, a.prototype.getRight = function() {
              return this.rect.x + this.rect.width;
            }, a.prototype.getTop = function() {
              return this.rect.y;
            }, a.prototype.getBottom = function() {
              return this.rect.y + this.rect.height;
            }, a.prototype.getParent = function() {
              return this.owner == null ? null : this.owner.getParent();
            }, u.exports = a;
          },
          /* 4 */
          /***/
          function(u, D, y) {
            function r(t, e) {
              t == null && e == null ? (this.x = 0, this.y = 0) : (this.x = t, this.y = e);
            }
            r.prototype.getX = function() {
              return this.x;
            }, r.prototype.getY = function() {
              return this.y;
            }, r.prototype.setX = function(t) {
              this.x = t;
            }, r.prototype.setY = function(t) {
              this.y = t;
            }, r.prototype.getDifference = function(t) {
              return new DimensionD(this.x - t.x, this.y - t.y);
            }, r.prototype.getCopy = function() {
              return new r(this.x, this.y);
            }, r.prototype.translate = function(t) {
              return this.x += t.width, this.y += t.height, this;
            }, u.exports = r;
          },
          /* 5 */
          /***/
          function(u, D, y) {
            var r = y(2), t = y(10), e = y(0), i = y(6), o = y(3), g = y(1), a = y(13), v = y(12), n = y(11);
            function c(E, T, m) {
              r.call(this, m), this.estimatedSize = t.MIN_VALUE, this.margin = e.DEFAULT_GRAPH_MARGIN, this.edges = [], this.nodes = [], this.isConnected = !1, this.parent = E, T != null && T instanceof i ? this.graphManager = T : T != null && T instanceof Layout && (this.graphManager = T.graphManager);
            }
            c.prototype = Object.create(r.prototype);
            for (var l in r)
              c[l] = r[l];
            c.prototype.getNodes = function() {
              return this.nodes;
            }, c.prototype.getEdges = function() {
              return this.edges;
            }, c.prototype.getGraphManager = function() {
              return this.graphManager;
            }, c.prototype.getParent = function() {
              return this.parent;
            }, c.prototype.getLeft = function() {
              return this.left;
            }, c.prototype.getRight = function() {
              return this.right;
            }, c.prototype.getTop = function() {
              return this.top;
            }, c.prototype.getBottom = function() {
              return this.bottom;
            }, c.prototype.isConnected = function() {
              return this.isConnected;
            }, c.prototype.add = function(E, T, m) {
              if (T == null && m == null) {
                var L = E;
                if (this.graphManager == null)
                  throw "Graph has no graph mgr!";
                if (this.getNodes().indexOf(L) > -1)
                  throw "Node already in graph!";
                return L.owner = this, this.getNodes().push(L), L;
              } else {
                var O = E;
                if (!(this.getNodes().indexOf(T) > -1 && this.getNodes().indexOf(m) > -1))
                  throw "Source or target not in graph!";
                if (!(T.owner == m.owner && T.owner == this))
                  throw "Both owners must be this graph!";
                return T.owner != m.owner ? null : (O.source = T, O.target = m, O.isInterGraph = !1, this.getEdges().push(O), T.edges.push(O), m != T && m.edges.push(O), O);
              }
            }, c.prototype.remove = function(E) {
              var T = E;
              if (E instanceof o) {
                if (T == null)
                  throw "Node is null!";
                if (!(T.owner != null && T.owner == this))
                  throw "Owner graph is invalid!";
                if (this.graphManager == null)
                  throw "Owner graph manager is invalid!";
                for (var m = T.edges.slice(), L, O = m.length, d = 0; d < O; d++)
                  L = m[d], L.isInterGraph ? this.graphManager.remove(L) : L.source.owner.remove(L);
                var N = this.nodes.indexOf(T);
                if (N == -1)
                  throw "Node not in owner node list!";
                this.nodes.splice(N, 1);
              } else if (E instanceof g) {
                var L = E;
                if (L == null)
                  throw "Edge is null!";
                if (!(L.source != null && L.target != null))
                  throw "Source and/or target is null!";
                if (!(L.source.owner != null && L.target.owner != null && L.source.owner == this && L.target.owner == this))
                  throw "Source and/or target owner is invalid!";
                var s = L.source.edges.indexOf(L), h = L.target.edges.indexOf(L);
                if (!(s > -1 && h > -1))
                  throw "Source and/or target doesn't know this edge!";
                L.source.edges.splice(s, 1), L.target != L.source && L.target.edges.splice(h, 1);
                var N = L.source.owner.getEdges().indexOf(L);
                if (N == -1)
                  throw "Not in owner's edge list!";
                L.source.owner.getEdges().splice(N, 1);
              }
            }, c.prototype.updateLeftTop = function() {
              for (var E = t.MAX_VALUE, T = t.MAX_VALUE, m, L, O, d = this.getNodes(), N = d.length, s = 0; s < N; s++) {
                var h = d[s];
                m = h.getTop(), L = h.getLeft(), E > m && (E = m), T > L && (T = L);
              }
              return E == t.MAX_VALUE ? null : (d[0].getParent().paddingLeft != null ? O = d[0].getParent().paddingLeft : O = this.margin, this.left = T - O, this.top = E - O, new v(this.left, this.top));
            }, c.prototype.updateBounds = function(E) {
              for (var T = t.MAX_VALUE, m = -t.MAX_VALUE, L = t.MAX_VALUE, O = -t.MAX_VALUE, d, N, s, h, f, p = this.nodes, A = p.length, I = 0; I < A; I++) {
                var R = p[I];
                E && R.child != null && R.updateBounds(), d = R.getLeft(), N = R.getRight(), s = R.getTop(), h = R.getBottom(), T > d && (T = d), m < N && (m = N), L > s && (L = s), O < h && (O = h);
              }
              var x = new a(T, L, m - T, O - L);
              T == t.MAX_VALUE && (this.left = this.parent.getLeft(), this.right = this.parent.getRight(), this.top = this.parent.getTop(), this.bottom = this.parent.getBottom()), p[0].getParent().paddingLeft != null ? f = p[0].getParent().paddingLeft : f = this.margin, this.left = x.x - f, this.right = x.x + x.width + f, this.top = x.y - f, this.bottom = x.y + x.height + f;
            }, c.calculateBounds = function(E) {
              for (var T = t.MAX_VALUE, m = -t.MAX_VALUE, L = t.MAX_VALUE, O = -t.MAX_VALUE, d, N, s, h, f = E.length, p = 0; p < f; p++) {
                var A = E[p];
                d = A.getLeft(), N = A.getRight(), s = A.getTop(), h = A.getBottom(), T > d && (T = d), m < N && (m = N), L > s && (L = s), O < h && (O = h);
              }
              var I = new a(T, L, m - T, O - L);
              return I;
            }, c.prototype.getInclusionTreeDepth = function() {
              return this == this.graphManager.getRoot() ? 1 : this.parent.getInclusionTreeDepth();
            }, c.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == t.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, c.prototype.calcEstimatedSize = function() {
              for (var E = 0, T = this.nodes, m = T.length, L = 0; L < m; L++) {
                var O = T[L];
                E += O.calcEstimatedSize();
              }
              return E == 0 ? this.estimatedSize = e.EMPTY_COMPOUND_NODE_SIZE : this.estimatedSize = E / Math.sqrt(this.nodes.length), this.estimatedSize;
            }, c.prototype.updateConnected = function() {
              var E = this;
              if (this.nodes.length == 0) {
                this.isConnected = !0;
                return;
              }
              var T = new n(), m = /* @__PURE__ */ new Set(), L = this.nodes[0], O, d, N = L.withChildren();
              for (N.forEach(function(I) {
                T.push(I), m.add(I);
              }); T.length !== 0; ) {
                L = T.shift(), O = L.getEdges();
                for (var s = O.length, h = 0; h < s; h++) {
                  var f = O[h];
                  if (d = f.getOtherEndInGraph(L, this), d != null && !m.has(d)) {
                    var p = d.withChildren();
                    p.forEach(function(I) {
                      T.push(I), m.add(I);
                    });
                  }
                }
              }
              if (this.isConnected = !1, m.size >= this.nodes.length) {
                var A = 0;
                m.forEach(function(I) {
                  I.owner == E && A++;
                }), A == this.nodes.length && (this.isConnected = !0);
              }
            }, u.exports = c;
          },
          /* 6 */
          /***/
          function(u, D, y) {
            var r, t = y(1);
            function e(i) {
              r = y(5), this.layout = i, this.graphs = [], this.edges = [];
            }
            e.prototype.addRoot = function() {
              var i = this.layout.newGraph(), o = this.layout.newNode(null), g = this.add(i, o);
              return this.setRootGraph(g), this.rootGraph;
            }, e.prototype.add = function(i, o, g, a, v) {
              if (g == null && a == null && v == null) {
                if (i == null)
                  throw "Graph is null!";
                if (o == null)
                  throw "Parent node is null!";
                if (this.graphs.indexOf(i) > -1)
                  throw "Graph already in this graph mgr!";
                if (this.graphs.push(i), i.parent != null)
                  throw "Already has a parent!";
                if (o.child != null)
                  throw "Already has a child!";
                return i.parent = o, o.child = i, i;
              } else {
                v = g, a = o, g = i;
                var n = a.getOwner(), c = v.getOwner();
                if (!(n != null && n.getGraphManager() == this))
                  throw "Source not in this graph mgr!";
                if (!(c != null && c.getGraphManager() == this))
                  throw "Target not in this graph mgr!";
                if (n == c)
                  return g.isInterGraph = !1, n.add(g, a, v);
                if (g.isInterGraph = !0, g.source = a, g.target = v, this.edges.indexOf(g) > -1)
                  throw "Edge already in inter-graph edge list!";
                if (this.edges.push(g), !(g.source != null && g.target != null))
                  throw "Edge source and/or target is null!";
                if (!(g.source.edges.indexOf(g) == -1 && g.target.edges.indexOf(g) == -1))
                  throw "Edge already in source and/or target incidency list!";
                return g.source.edges.push(g), g.target.edges.push(g), g;
              }
            }, e.prototype.remove = function(i) {
              if (i instanceof r) {
                var o = i;
                if (o.getGraphManager() != this)
                  throw "Graph not in this graph mgr";
                if (!(o == this.rootGraph || o.parent != null && o.parent.graphManager == this))
                  throw "Invalid parent node!";
                var g = [];
                g = g.concat(o.getEdges());
                for (var a, v = g.length, n = 0; n < v; n++)
                  a = g[n], o.remove(a);
                var c = [];
                c = c.concat(o.getNodes());
                var l;
                v = c.length;
                for (var n = 0; n < v; n++)
                  l = c[n], o.remove(l);
                o == this.rootGraph && this.setRootGraph(null);
                var E = this.graphs.indexOf(o);
                this.graphs.splice(E, 1), o.parent = null;
              } else if (i instanceof t) {
                if (a = i, a == null)
                  throw "Edge is null!";
                if (!a.isInterGraph)
                  throw "Not an inter-graph edge!";
                if (!(a.source != null && a.target != null))
                  throw "Source and/or target is null!";
                if (!(a.source.edges.indexOf(a) != -1 && a.target.edges.indexOf(a) != -1))
                  throw "Source and/or target doesn't know this edge!";
                var E = a.source.edges.indexOf(a);
                if (a.source.edges.splice(E, 1), E = a.target.edges.indexOf(a), a.target.edges.splice(E, 1), !(a.source.owner != null && a.source.owner.getGraphManager() != null))
                  throw "Edge owner graph or owner graph manager is null!";
                if (a.source.owner.getGraphManager().edges.indexOf(a) == -1)
                  throw "Not in owner graph manager's edge list!";
                var E = a.source.owner.getGraphManager().edges.indexOf(a);
                a.source.owner.getGraphManager().edges.splice(E, 1);
              }
            }, e.prototype.updateBounds = function() {
              this.rootGraph.updateBounds(!0);
            }, e.prototype.getGraphs = function() {
              return this.graphs;
            }, e.prototype.getAllNodes = function() {
              if (this.allNodes == null) {
                for (var i = [], o = this.getGraphs(), g = o.length, a = 0; a < g; a++)
                  i = i.concat(o[a].getNodes());
                this.allNodes = i;
              }
              return this.allNodes;
            }, e.prototype.resetAllNodes = function() {
              this.allNodes = null;
            }, e.prototype.resetAllEdges = function() {
              this.allEdges = null;
            }, e.prototype.resetAllNodesToApplyGravitation = function() {
              this.allNodesToApplyGravitation = null;
            }, e.prototype.getAllEdges = function() {
              if (this.allEdges == null) {
                var i = [], o = this.getGraphs();
                o.length;
                for (var g = 0; g < o.length; g++)
                  i = i.concat(o[g].getEdges());
                i = i.concat(this.edges), this.allEdges = i;
              }
              return this.allEdges;
            }, e.prototype.getAllNodesToApplyGravitation = function() {
              return this.allNodesToApplyGravitation;
            }, e.prototype.setAllNodesToApplyGravitation = function(i) {
              if (this.allNodesToApplyGravitation != null)
                throw "assert failed";
              this.allNodesToApplyGravitation = i;
            }, e.prototype.getRoot = function() {
              return this.rootGraph;
            }, e.prototype.setRootGraph = function(i) {
              if (i.getGraphManager() != this)
                throw "Root not in this graph mgr!";
              this.rootGraph = i, i.parent == null && (i.parent = this.layout.newNode("Root node"));
            }, e.prototype.getLayout = function() {
              return this.layout;
            }, e.prototype.isOneAncestorOfOther = function(i, o) {
              if (!(i != null && o != null))
                throw "assert failed";
              if (i == o)
                return !0;
              var g = i.getOwner(), a;
              do {
                if (a = g.getParent(), a == null)
                  break;
                if (a == o)
                  return !0;
                if (g = a.getOwner(), g == null)
                  break;
              } while (!0);
              g = o.getOwner();
              do {
                if (a = g.getParent(), a == null)
                  break;
                if (a == i)
                  return !0;
                if (g = a.getOwner(), g == null)
                  break;
              } while (!0);
              return !1;
            }, e.prototype.calcLowestCommonAncestors = function() {
              for (var i, o, g, a, v, n = this.getAllEdges(), c = n.length, l = 0; l < c; l++) {
                if (i = n[l], o = i.source, g = i.target, i.lca = null, i.sourceInLca = o, i.targetInLca = g, o == g) {
                  i.lca = o.getOwner();
                  continue;
                }
                for (a = o.getOwner(); i.lca == null; ) {
                  for (i.targetInLca = g, v = g.getOwner(); i.lca == null; ) {
                    if (v == a) {
                      i.lca = v;
                      break;
                    }
                    if (v == this.rootGraph)
                      break;
                    if (i.lca != null)
                      throw "assert failed";
                    i.targetInLca = v.getParent(), v = i.targetInLca.getOwner();
                  }
                  if (a == this.rootGraph)
                    break;
                  i.lca == null && (i.sourceInLca = a.getParent(), a = i.sourceInLca.getOwner());
                }
                if (i.lca == null)
                  throw "assert failed";
              }
            }, e.prototype.calcLowestCommonAncestor = function(i, o) {
              if (i == o)
                return i.getOwner();
              var g = i.getOwner();
              do {
                if (g == null)
                  break;
                var a = o.getOwner();
                do {
                  if (a == null)
                    break;
                  if (a == g)
                    return a;
                  a = a.getParent().getOwner();
                } while (!0);
                g = g.getParent().getOwner();
              } while (!0);
              return g;
            }, e.prototype.calcInclusionTreeDepths = function(i, o) {
              i == null && o == null && (i = this.rootGraph, o = 1);
              for (var g, a = i.getNodes(), v = a.length, n = 0; n < v; n++)
                g = a[n], g.inclusionTreeDepth = o, g.child != null && this.calcInclusionTreeDepths(g.child, o + 1);
            }, e.prototype.includesInvalidEdge = function() {
              for (var i, o = this.edges.length, g = 0; g < o; g++)
                if (i = this.edges[g], this.isOneAncestorOfOther(i.source, i.target))
                  return !0;
              return !1;
            }, u.exports = e;
          },
          /* 7 */
          /***/
          function(u, D, y) {
            var r = y(0);
            function t() {
            }
            for (var e in r)
              t[e] = r[e];
            t.MAX_ITERATIONS = 2500, t.DEFAULT_EDGE_LENGTH = 50, t.DEFAULT_SPRING_STRENGTH = 0.45, t.DEFAULT_REPULSION_STRENGTH = 4500, t.DEFAULT_GRAVITY_STRENGTH = 0.4, t.DEFAULT_COMPOUND_GRAVITY_STRENGTH = 1, t.DEFAULT_GRAVITY_RANGE_FACTOR = 3.8, t.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = 1.5, t.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION = !0, t.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION = !0, t.DEFAULT_COOLING_FACTOR_INCREMENTAL = 0.3, t.COOLING_ADAPTATION_FACTOR = 0.33, t.ADAPTATION_LOWER_NODE_LIMIT = 1e3, t.ADAPTATION_UPPER_NODE_LIMIT = 5e3, t.MAX_NODE_DISPLACEMENT_INCREMENTAL = 100, t.MAX_NODE_DISPLACEMENT = t.MAX_NODE_DISPLACEMENT_INCREMENTAL * 3, t.MIN_REPULSION_DIST = t.DEFAULT_EDGE_LENGTH / 10, t.CONVERGENCE_CHECK_PERIOD = 100, t.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = 0.1, t.MIN_EDGE_LENGTH = 1, t.GRID_CALCULATION_CHECK_PERIOD = 10, u.exports = t;
          },
          /* 8 */
          /***/
          function(u, D, y) {
            var r = y(12);
            function t() {
            }
            t.calcSeparationAmount = function(e, i, o, g) {
              if (!e.intersects(i))
                throw "assert failed";
              var a = new Array(2);
              this.decideDirectionsForOverlappingNodes(e, i, a), o[0] = Math.min(e.getRight(), i.getRight()) - Math.max(e.x, i.x), o[1] = Math.min(e.getBottom(), i.getBottom()) - Math.max(e.y, i.y), e.getX() <= i.getX() && e.getRight() >= i.getRight() ? o[0] += Math.min(i.getX() - e.getX(), e.getRight() - i.getRight()) : i.getX() <= e.getX() && i.getRight() >= e.getRight() && (o[0] += Math.min(e.getX() - i.getX(), i.getRight() - e.getRight())), e.getY() <= i.getY() && e.getBottom() >= i.getBottom() ? o[1] += Math.min(i.getY() - e.getY(), e.getBottom() - i.getBottom()) : i.getY() <= e.getY() && i.getBottom() >= e.getBottom() && (o[1] += Math.min(e.getY() - i.getY(), i.getBottom() - e.getBottom()));
              var v = Math.abs((i.getCenterY() - e.getCenterY()) / (i.getCenterX() - e.getCenterX()));
              i.getCenterY() === e.getCenterY() && i.getCenterX() === e.getCenterX() && (v = 1);
              var n = v * o[0], c = o[1] / v;
              o[0] < c ? c = o[0] : n = o[1], o[0] = -1 * a[0] * (c / 2 + g), o[1] = -1 * a[1] * (n / 2 + g);
            }, t.decideDirectionsForOverlappingNodes = function(e, i, o) {
              e.getCenterX() < i.getCenterX() ? o[0] = -1 : o[0] = 1, e.getCenterY() < i.getCenterY() ? o[1] = -1 : o[1] = 1;
            }, t.getIntersection2 = function(e, i, o) {
              var g = e.getCenterX(), a = e.getCenterY(), v = i.getCenterX(), n = i.getCenterY();
              if (e.intersects(i))
                return o[0] = g, o[1] = a, o[2] = v, o[3] = n, !0;
              var c = e.getX(), l = e.getY(), E = e.getRight(), T = e.getX(), m = e.getBottom(), L = e.getRight(), O = e.getWidthHalf(), d = e.getHeightHalf(), N = i.getX(), s = i.getY(), h = i.getRight(), f = i.getX(), p = i.getBottom(), A = i.getRight(), I = i.getWidthHalf(), R = i.getHeightHalf(), x = !1, G = !1;
              if (g === v) {
                if (a > n)
                  return o[0] = g, o[1] = l, o[2] = v, o[3] = p, !1;
                if (a < n)
                  return o[0] = g, o[1] = m, o[2] = v, o[3] = s, !1;
              } else if (a === n) {
                if (g > v)
                  return o[0] = c, o[1] = a, o[2] = h, o[3] = n, !1;
                if (g < v)
                  return o[0] = E, o[1] = a, o[2] = N, o[3] = n, !1;
              } else {
                var U = e.height / e.width, X = i.height / i.width, w = (n - a) / (v - g), S = void 0, F = void 0, b = void 0, Y = void 0, k = void 0, H = void 0;
                if (-U === w ? g > v ? (o[0] = T, o[1] = m, x = !0) : (o[0] = E, o[1] = l, x = !0) : U === w && (g > v ? (o[0] = c, o[1] = l, x = !0) : (o[0] = L, o[1] = m, x = !0)), -X === w ? v > g ? (o[2] = f, o[3] = p, G = !0) : (o[2] = h, o[3] = s, G = !0) : X === w && (v > g ? (o[2] = N, o[3] = s, G = !0) : (o[2] = A, o[3] = p, G = !0)), x && G)
                  return !1;
                if (g > v ? a > n ? (S = this.getCardinalDirection(U, w, 4), F = this.getCardinalDirection(X, w, 2)) : (S = this.getCardinalDirection(-U, w, 3), F = this.getCardinalDirection(-X, w, 1)) : a > n ? (S = this.getCardinalDirection(-U, w, 1), F = this.getCardinalDirection(-X, w, 3)) : (S = this.getCardinalDirection(U, w, 2), F = this.getCardinalDirection(X, w, 4)), !x)
                  switch (S) {
                    case 1:
                      Y = l, b = g + -d / w, o[0] = b, o[1] = Y;
                      break;
                    case 2:
                      b = L, Y = a + O * w, o[0] = b, o[1] = Y;
                      break;
                    case 3:
                      Y = m, b = g + d / w, o[0] = b, o[1] = Y;
                      break;
                    case 4:
                      b = T, Y = a + -O * w, o[0] = b, o[1] = Y;
                      break;
                  }
                if (!G)
                  switch (F) {
                    case 1:
                      H = s, k = v + -R / w, o[2] = k, o[3] = H;
                      break;
                    case 2:
                      k = A, H = n + I * w, o[2] = k, o[3] = H;
                      break;
                    case 3:
                      H = p, k = v + R / w, o[2] = k, o[3] = H;
                      break;
                    case 4:
                      k = f, H = n + -I * w, o[2] = k, o[3] = H;
                      break;
                  }
              }
              return !1;
            }, t.getCardinalDirection = function(e, i, o) {
              return e > i ? o : 1 + o % 4;
            }, t.getIntersection = function(e, i, o, g) {
              if (g == null)
                return this.getIntersection2(e, i, o);
              var a = e.x, v = e.y, n = i.x, c = i.y, l = o.x, E = o.y, T = g.x, m = g.y, L = void 0, O = void 0, d = void 0, N = void 0, s = void 0, h = void 0, f = void 0, p = void 0, A = void 0;
              return d = c - v, s = a - n, f = n * v - a * c, N = m - E, h = l - T, p = T * E - l * m, A = d * h - N * s, A === 0 ? null : (L = (s * p - h * f) / A, O = (N * f - d * p) / A, new r(L, O));
            }, t.angleOfVector = function(e, i, o, g) {
              var a = void 0;
              return e !== o ? (a = Math.atan((g - i) / (o - e)), o < e ? a += Math.PI : g < i && (a += this.TWO_PI)) : g < i ? a = this.ONE_AND_HALF_PI : a = this.HALF_PI, a;
            }, t.doIntersect = function(e, i, o, g) {
              var a = e.x, v = e.y, n = i.x, c = i.y, l = o.x, E = o.y, T = g.x, m = g.y, L = (n - a) * (m - E) - (T - l) * (c - v);
              if (L === 0)
                return !1;
              var O = ((m - E) * (T - a) + (l - T) * (m - v)) / L, d = ((v - c) * (T - a) + (n - a) * (m - v)) / L;
              return 0 < O && O < 1 && 0 < d && d < 1;
            }, t.HALF_PI = 0.5 * Math.PI, t.ONE_AND_HALF_PI = 1.5 * Math.PI, t.TWO_PI = 2 * Math.PI, t.THREE_PI = 3 * Math.PI, u.exports = t;
          },
          /* 9 */
          /***/
          function(u, D, y) {
            function r() {
            }
            r.sign = function(t) {
              return t > 0 ? 1 : t < 0 ? -1 : 0;
            }, r.floor = function(t) {
              return t < 0 ? Math.ceil(t) : Math.floor(t);
            }, r.ceil = function(t) {
              return t < 0 ? Math.floor(t) : Math.ceil(t);
            }, u.exports = r;
          },
          /* 10 */
          /***/
          function(u, D, y) {
            function r() {
            }
            r.MAX_VALUE = 2147483647, r.MIN_VALUE = -2147483648, u.exports = r;
          },
          /* 11 */
          /***/
          function(u, D, y) {
            var r = /* @__PURE__ */ function() {
              function a(v, n) {
                for (var c = 0; c < n.length; c++) {
                  var l = n[c];
                  l.enumerable = l.enumerable || !1, l.configurable = !0, "value" in l && (l.writable = !0), Object.defineProperty(v, l.key, l);
                }
              }
              return function(v, n, c) {
                return n && a(v.prototype, n), c && a(v, c), v;
              };
            }();
            function t(a, v) {
              if (!(a instanceof v))
                throw new TypeError("Cannot call a class as a function");
            }
            var e = function(v) {
              return { value: v, next: null, prev: null };
            }, i = function(v, n, c, l) {
              return v !== null ? v.next = n : l.head = n, c !== null ? c.prev = n : l.tail = n, n.prev = v, n.next = c, l.length++, n;
            }, o = function(v, n) {
              var c = v.prev, l = v.next;
              return c !== null ? c.next = l : n.head = l, l !== null ? l.prev = c : n.tail = c, v.prev = v.next = null, n.length--, v;
            }, g = function() {
              function a(v) {
                var n = this;
                t(this, a), this.length = 0, this.head = null, this.tail = null, v != null && v.forEach(function(c) {
                  return n.push(c);
                });
              }
              return r(a, [{
                key: "size",
                value: function() {
                  return this.length;
                }
              }, {
                key: "insertBefore",
                value: function(n, c) {
                  return i(c.prev, e(n), c, this);
                }
              }, {
                key: "insertAfter",
                value: function(n, c) {
                  return i(c, e(n), c.next, this);
                }
              }, {
                key: "insertNodeBefore",
                value: function(n, c) {
                  return i(c.prev, n, c, this);
                }
              }, {
                key: "insertNodeAfter",
                value: function(n, c) {
                  return i(c, n, c.next, this);
                }
              }, {
                key: "push",
                value: function(n) {
                  return i(this.tail, e(n), null, this);
                }
              }, {
                key: "unshift",
                value: function(n) {
                  return i(null, e(n), this.head, this);
                }
              }, {
                key: "remove",
                value: function(n) {
                  return o(n, this);
                }
              }, {
                key: "pop",
                value: function() {
                  return o(this.tail, this).value;
                }
              }, {
                key: "popNode",
                value: function() {
                  return o(this.tail, this);
                }
              }, {
                key: "shift",
                value: function() {
                  return o(this.head, this).value;
                }
              }, {
                key: "shiftNode",
                value: function() {
                  return o(this.head, this);
                }
              }, {
                key: "get_object_at",
                value: function(n) {
                  if (n <= this.length()) {
                    for (var c = 1, l = this.head; c < n; )
                      l = l.next, c++;
                    return l.value;
                  }
                }
              }, {
                key: "set_object_at",
                value: function(n, c) {
                  if (n <= this.length()) {
                    for (var l = 1, E = this.head; l < n; )
                      E = E.next, l++;
                    E.value = c;
                  }
                }
              }]), a;
            }();
            u.exports = g;
          },
          /* 12 */
          /***/
          function(u, D, y) {
            function r(t, e, i) {
              this.x = null, this.y = null, t == null && e == null && i == null ? (this.x = 0, this.y = 0) : typeof t == "number" && typeof e == "number" && i == null ? (this.x = t, this.y = e) : t.constructor.name == "Point" && e == null && i == null && (i = t, this.x = i.x, this.y = i.y);
            }
            r.prototype.getX = function() {
              return this.x;
            }, r.prototype.getY = function() {
              return this.y;
            }, r.prototype.getLocation = function() {
              return new r(this.x, this.y);
            }, r.prototype.setLocation = function(t, e, i) {
              t.constructor.name == "Point" && e == null && i == null ? (i = t, this.setLocation(i.x, i.y)) : typeof t == "number" && typeof e == "number" && i == null && (parseInt(t) == t && parseInt(e) == e ? this.move(t, e) : (this.x = Math.floor(t + 0.5), this.y = Math.floor(e + 0.5)));
            }, r.prototype.move = function(t, e) {
              this.x = t, this.y = e;
            }, r.prototype.translate = function(t, e) {
              this.x += t, this.y += e;
            }, r.prototype.equals = function(t) {
              if (t.constructor.name == "Point") {
                var e = t;
                return this.x == e.x && this.y == e.y;
              }
              return this == t;
            }, r.prototype.toString = function() {
              return new r().constructor.name + "[x=" + this.x + ",y=" + this.y + "]";
            }, u.exports = r;
          },
          /* 13 */
          /***/
          function(u, D, y) {
            function r(t, e, i, o) {
              this.x = 0, this.y = 0, this.width = 0, this.height = 0, t != null && e != null && i != null && o != null && (this.x = t, this.y = e, this.width = i, this.height = o);
            }
            r.prototype.getX = function() {
              return this.x;
            }, r.prototype.setX = function(t) {
              this.x = t;
            }, r.prototype.getY = function() {
              return this.y;
            }, r.prototype.setY = function(t) {
              this.y = t;
            }, r.prototype.getWidth = function() {
              return this.width;
            }, r.prototype.setWidth = function(t) {
              this.width = t;
            }, r.prototype.getHeight = function() {
              return this.height;
            }, r.prototype.setHeight = function(t) {
              this.height = t;
            }, r.prototype.getRight = function() {
              return this.x + this.width;
            }, r.prototype.getBottom = function() {
              return this.y + this.height;
            }, r.prototype.intersects = function(t) {
              return !(this.getRight() < t.x || this.getBottom() < t.y || t.getRight() < this.x || t.getBottom() < this.y);
            }, r.prototype.getCenterX = function() {
              return this.x + this.width / 2;
            }, r.prototype.getMinX = function() {
              return this.getX();
            }, r.prototype.getMaxX = function() {
              return this.getX() + this.width;
            }, r.prototype.getCenterY = function() {
              return this.y + this.height / 2;
            }, r.prototype.getMinY = function() {
              return this.getY();
            }, r.prototype.getMaxY = function() {
              return this.getY() + this.height;
            }, r.prototype.getWidthHalf = function() {
              return this.width / 2;
            }, r.prototype.getHeightHalf = function() {
              return this.height / 2;
            }, u.exports = r;
          },
          /* 14 */
          /***/
          function(u, D, y) {
            var r = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
              return typeof e;
            } : function(e) {
              return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
            };
            function t() {
            }
            t.lastID = 0, t.createID = function(e) {
              return t.isPrimitive(e) ? e : (e.uniqueID != null || (e.uniqueID = t.getString(), t.lastID++), e.uniqueID);
            }, t.getString = function(e) {
              return e == null && (e = t.lastID), "Object#" + e;
            }, t.isPrimitive = function(e) {
              var i = typeof e > "u" ? "undefined" : r(e);
              return e == null || i != "object" && i != "function";
            }, u.exports = t;
          },
          /* 15 */
          /***/
          function(u, D, y) {
            function r(l) {
              if (Array.isArray(l)) {
                for (var E = 0, T = Array(l.length); E < l.length; E++)
                  T[E] = l[E];
                return T;
              } else
                return Array.from(l);
            }
            var t = y(0), e = y(6), i = y(3), o = y(1), g = y(5), a = y(4), v = y(17), n = y(27);
            function c(l) {
              n.call(this), this.layoutQuality = t.QUALITY, this.createBendsAsNeeded = t.DEFAULT_CREATE_BENDS_AS_NEEDED, this.incremental = t.DEFAULT_INCREMENTAL, this.animationOnLayout = t.DEFAULT_ANIMATION_ON_LAYOUT, this.animationDuringLayout = t.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = t.DEFAULT_ANIMATION_PERIOD, this.uniformLeafNodeSizes = t.DEFAULT_UNIFORM_LEAF_NODE_SIZES, this.edgeToDummyNodes = /* @__PURE__ */ new Map(), this.graphManager = new e(this), this.isLayoutFinished = !1, this.isSubLayout = !1, this.isRemoteUse = !1, l != null && (this.isRemoteUse = l);
            }
            c.RANDOM_SEED = 1, c.prototype = Object.create(n.prototype), c.prototype.getGraphManager = function() {
              return this.graphManager;
            }, c.prototype.getAllNodes = function() {
              return this.graphManager.getAllNodes();
            }, c.prototype.getAllEdges = function() {
              return this.graphManager.getAllEdges();
            }, c.prototype.getAllNodesToApplyGravitation = function() {
              return this.graphManager.getAllNodesToApplyGravitation();
            }, c.prototype.newGraphManager = function() {
              var l = new e(this);
              return this.graphManager = l, l;
            }, c.prototype.newGraph = function(l) {
              return new g(null, this.graphManager, l);
            }, c.prototype.newNode = function(l) {
              return new i(this.graphManager, l);
            }, c.prototype.newEdge = function(l) {
              return new o(null, null, l);
            }, c.prototype.checkLayoutSuccess = function() {
              return this.graphManager.getRoot() == null || this.graphManager.getRoot().getNodes().length == 0 || this.graphManager.includesInvalidEdge();
            }, c.prototype.runLayout = function() {
              this.isLayoutFinished = !1, this.tilingPreLayout && this.tilingPreLayout(), this.initParameters();
              var l;
              return this.checkLayoutSuccess() ? l = !1 : l = this.layout(), t.ANIMATE === "during" ? !1 : (l && (this.isSubLayout || this.doPostLayout()), this.tilingPostLayout && this.tilingPostLayout(), this.isLayoutFinished = !0, l);
            }, c.prototype.doPostLayout = function() {
              this.incremental || this.transform(), this.update();
            }, c.prototype.update2 = function() {
              if (this.createBendsAsNeeded && (this.createBendpointsFromDummyNodes(), this.graphManager.resetAllEdges()), !this.isRemoteUse) {
                for (var l = this.graphManager.getAllEdges(), E = 0; E < l.length; E++)
                  l[E];
                for (var T = this.graphManager.getRoot().getNodes(), E = 0; E < T.length; E++)
                  T[E];
                this.update(this.graphManager.getRoot());
              }
            }, c.prototype.update = function(l) {
              if (l == null)
                this.update2();
              else if (l instanceof i) {
                var E = l;
                if (E.getChild() != null)
                  for (var T = E.getChild().getNodes(), m = 0; m < T.length; m++)
                    update(T[m]);
                if (E.vGraphObject != null) {
                  var L = E.vGraphObject;
                  L.update(E);
                }
              } else if (l instanceof o) {
                var O = l;
                if (O.vGraphObject != null) {
                  var d = O.vGraphObject;
                  d.update(O);
                }
              } else if (l instanceof g) {
                var N = l;
                if (N.vGraphObject != null) {
                  var s = N.vGraphObject;
                  s.update(N);
                }
              }
            }, c.prototype.initParameters = function() {
              this.isSubLayout || (this.layoutQuality = t.QUALITY, this.animationDuringLayout = t.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = t.DEFAULT_ANIMATION_PERIOD, this.animationOnLayout = t.DEFAULT_ANIMATION_ON_LAYOUT, this.incremental = t.DEFAULT_INCREMENTAL, this.createBendsAsNeeded = t.DEFAULT_CREATE_BENDS_AS_NEEDED, this.uniformLeafNodeSizes = t.DEFAULT_UNIFORM_LEAF_NODE_SIZES), this.animationDuringLayout && (this.animationOnLayout = !1);
            }, c.prototype.transform = function(l) {
              if (l == null)
                this.transform(new a(0, 0));
              else {
                var E = new v(), T = this.graphManager.getRoot().updateLeftTop();
                if (T != null) {
                  E.setWorldOrgX(l.x), E.setWorldOrgY(l.y), E.setDeviceOrgX(T.x), E.setDeviceOrgY(T.y);
                  for (var m = this.getAllNodes(), L, O = 0; O < m.length; O++)
                    L = m[O], L.transform(E);
                }
              }
            }, c.prototype.positionNodesRandomly = function(l) {
              if (l == null)
                this.positionNodesRandomly(this.getGraphManager().getRoot()), this.getGraphManager().getRoot().updateBounds(!0);
              else
                for (var E, T, m = l.getNodes(), L = 0; L < m.length; L++)
                  E = m[L], T = E.getChild(), T == null || T.getNodes().length == 0 ? E.scatter() : (this.positionNodesRandomly(T), E.updateBounds());
            }, c.prototype.getFlatForest = function() {
              for (var l = [], E = !0, T = this.graphManager.getRoot().getNodes(), m = !0, L = 0; L < T.length; L++)
                T[L].getChild() != null && (m = !1);
              if (!m)
                return l;
              var O = /* @__PURE__ */ new Set(), d = [], N = /* @__PURE__ */ new Map(), s = [];
              for (s = s.concat(T); s.length > 0 && E; ) {
                for (d.push(s[0]); d.length > 0 && E; ) {
                  var h = d[0];
                  d.splice(0, 1), O.add(h);
                  for (var f = h.getEdges(), L = 0; L < f.length; L++) {
                    var p = f[L].getOtherEnd(h);
                    if (N.get(h) != p)
                      if (!O.has(p))
                        d.push(p), N.set(p, h);
                      else {
                        E = !1;
                        break;
                      }
                  }
                }
                if (!E)
                  l = [];
                else {
                  var A = [].concat(r(O));
                  l.push(A);
                  for (var L = 0; L < A.length; L++) {
                    var I = A[L], R = s.indexOf(I);
                    R > -1 && s.splice(R, 1);
                  }
                  O = /* @__PURE__ */ new Set(), N = /* @__PURE__ */ new Map();
                }
              }
              return l;
            }, c.prototype.createDummyNodesForBendpoints = function(l) {
              for (var E = [], T = l.source, m = this.graphManager.calcLowestCommonAncestor(l.source, l.target), L = 0; L < l.bendpoints.length; L++) {
                var O = this.newNode(null);
                O.setRect(new Point(0, 0), new Dimension(1, 1)), m.add(O);
                var d = this.newEdge(null);
                this.graphManager.add(d, T, O), E.add(O), T = O;
              }
              var d = this.newEdge(null);
              return this.graphManager.add(d, T, l.target), this.edgeToDummyNodes.set(l, E), l.isInterGraph() ? this.graphManager.remove(l) : m.remove(l), E;
            }, c.prototype.createBendpointsFromDummyNodes = function() {
              var l = [];
              l = l.concat(this.graphManager.getAllEdges()), l = [].concat(r(this.edgeToDummyNodes.keys())).concat(l);
              for (var E = 0; E < l.length; E++) {
                var T = l[E];
                if (T.bendpoints.length > 0) {
                  for (var m = this.edgeToDummyNodes.get(T), L = 0; L < m.length; L++) {
                    var O = m[L], d = new a(O.getCenterX(), O.getCenterY()), N = T.bendpoints.get(L);
                    N.x = d.x, N.y = d.y, O.getOwner().remove(O);
                  }
                  this.graphManager.add(T, T.source, T.target);
                }
              }
            }, c.transform = function(l, E, T, m) {
              if (T != null && m != null) {
                var L = E;
                if (l <= 50) {
                  var O = E / T;
                  L -= (E - O) / 50 * (50 - l);
                } else {
                  var d = E * m;
                  L += (d - E) / 50 * (l - 50);
                }
                return L;
              } else {
                var N, s;
                return l <= 50 ? (N = 9 * E / 500, s = E / 10) : (N = 9 * E / 50, s = -8 * E), N * l + s;
              }
            }, c.findCenterOfTree = function(l) {
              var E = [];
              E = E.concat(l);
              var T = [], m = /* @__PURE__ */ new Map(), L = !1, O = null;
              (E.length == 1 || E.length == 2) && (L = !0, O = E[0]);
              for (var d = 0; d < E.length; d++) {
                var N = E[d], s = N.getNeighborsList().size;
                m.set(N, N.getNeighborsList().size), s == 1 && T.push(N);
              }
              var h = [];
              for (h = h.concat(T); !L; ) {
                var f = [];
                f = f.concat(h), h = [];
                for (var d = 0; d < E.length; d++) {
                  var N = E[d], p = E.indexOf(N);
                  p >= 0 && E.splice(p, 1);
                  var A = N.getNeighborsList();
                  A.forEach(function(x) {
                    if (T.indexOf(x) < 0) {
                      var G = m.get(x), U = G - 1;
                      U == 1 && h.push(x), m.set(x, U);
                    }
                  });
                }
                T = T.concat(h), (E.length == 1 || E.length == 2) && (L = !0, O = E[0]);
              }
              return O;
            }, c.prototype.setGraphManager = function(l) {
              this.graphManager = l;
            }, u.exports = c;
          },
          /* 16 */
          /***/
          function(u, D, y) {
            function r() {
            }
            r.seed = 1, r.x = 0, r.nextDouble = function() {
              return r.x = Math.sin(r.seed++) * 1e4, r.x - Math.floor(r.x);
            }, u.exports = r;
          },
          /* 17 */
          /***/
          function(u, D, y) {
            var r = y(4);
            function t(e, i) {
              this.lworldOrgX = 0, this.lworldOrgY = 0, this.ldeviceOrgX = 0, this.ldeviceOrgY = 0, this.lworldExtX = 1, this.lworldExtY = 1, this.ldeviceExtX = 1, this.ldeviceExtY = 1;
            }
            t.prototype.getWorldOrgX = function() {
              return this.lworldOrgX;
            }, t.prototype.setWorldOrgX = function(e) {
              this.lworldOrgX = e;
            }, t.prototype.getWorldOrgY = function() {
              return this.lworldOrgY;
            }, t.prototype.setWorldOrgY = function(e) {
              this.lworldOrgY = e;
            }, t.prototype.getWorldExtX = function() {
              return this.lworldExtX;
            }, t.prototype.setWorldExtX = function(e) {
              this.lworldExtX = e;
            }, t.prototype.getWorldExtY = function() {
              return this.lworldExtY;
            }, t.prototype.setWorldExtY = function(e) {
              this.lworldExtY = e;
            }, t.prototype.getDeviceOrgX = function() {
              return this.ldeviceOrgX;
            }, t.prototype.setDeviceOrgX = function(e) {
              this.ldeviceOrgX = e;
            }, t.prototype.getDeviceOrgY = function() {
              return this.ldeviceOrgY;
            }, t.prototype.setDeviceOrgY = function(e) {
              this.ldeviceOrgY = e;
            }, t.prototype.getDeviceExtX = function() {
              return this.ldeviceExtX;
            }, t.prototype.setDeviceExtX = function(e) {
              this.ldeviceExtX = e;
            }, t.prototype.getDeviceExtY = function() {
              return this.ldeviceExtY;
            }, t.prototype.setDeviceExtY = function(e) {
              this.ldeviceExtY = e;
            }, t.prototype.transformX = function(e) {
              var i = 0, o = this.lworldExtX;
              return o != 0 && (i = this.ldeviceOrgX + (e - this.lworldOrgX) * this.ldeviceExtX / o), i;
            }, t.prototype.transformY = function(e) {
              var i = 0, o = this.lworldExtY;
              return o != 0 && (i = this.ldeviceOrgY + (e - this.lworldOrgY) * this.ldeviceExtY / o), i;
            }, t.prototype.inverseTransformX = function(e) {
              var i = 0, o = this.ldeviceExtX;
              return o != 0 && (i = this.lworldOrgX + (e - this.ldeviceOrgX) * this.lworldExtX / o), i;
            }, t.prototype.inverseTransformY = function(e) {
              var i = 0, o = this.ldeviceExtY;
              return o != 0 && (i = this.lworldOrgY + (e - this.ldeviceOrgY) * this.lworldExtY / o), i;
            }, t.prototype.inverseTransformPoint = function(e) {
              var i = new r(this.inverseTransformX(e.x), this.inverseTransformY(e.y));
              return i;
            }, u.exports = t;
          },
          /* 18 */
          /***/
          function(u, D, y) {
            function r(n) {
              if (Array.isArray(n)) {
                for (var c = 0, l = Array(n.length); c < n.length; c++)
                  l[c] = n[c];
                return l;
              } else
                return Array.from(n);
            }
            var t = y(15), e = y(7), i = y(0), o = y(8), g = y(9);
            function a() {
              t.call(this), this.useSmartIdealEdgeLengthCalculation = e.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.idealEdgeLength = e.DEFAULT_EDGE_LENGTH, this.springConstant = e.DEFAULT_SPRING_STRENGTH, this.repulsionConstant = e.DEFAULT_REPULSION_STRENGTH, this.gravityConstant = e.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = e.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = e.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = e.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.displacementThresholdPerNode = 3 * e.DEFAULT_EDGE_LENGTH / 100, this.coolingFactor = e.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.initialCoolingFactor = e.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.totalDisplacement = 0, this.oldTotalDisplacement = 0, this.maxIterations = e.MAX_ITERATIONS;
            }
            a.prototype = Object.create(t.prototype);
            for (var v in t)
              a[v] = t[v];
            a.prototype.initParameters = function() {
              t.prototype.initParameters.call(this, arguments), this.totalIterations = 0, this.notAnimatedIterations = 0, this.useFRGridVariant = e.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION, this.grid = [];
            }, a.prototype.calcIdealEdgeLengths = function() {
              for (var n, c, l, E, T, m, L = this.getGraphManager().getAllEdges(), O = 0; O < L.length; O++)
                n = L[O], n.idealLength = this.idealEdgeLength, n.isInterGraph && (l = n.getSource(), E = n.getTarget(), T = n.getSourceInLca().getEstimatedSize(), m = n.getTargetInLca().getEstimatedSize(), this.useSmartIdealEdgeLengthCalculation && (n.idealLength += T + m - 2 * i.SIMPLE_NODE_SIZE), c = n.getLca().getInclusionTreeDepth(), n.idealLength += e.DEFAULT_EDGE_LENGTH * e.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR * (l.getInclusionTreeDepth() + E.getInclusionTreeDepth() - 2 * c));
            }, a.prototype.initSpringEmbedder = function() {
              var n = this.getAllNodes().length;
              this.incremental ? (n > e.ADAPTATION_LOWER_NODE_LIMIT && (this.coolingFactor = Math.max(this.coolingFactor * e.COOLING_ADAPTATION_FACTOR, this.coolingFactor - (n - e.ADAPTATION_LOWER_NODE_LIMIT) / (e.ADAPTATION_UPPER_NODE_LIMIT - e.ADAPTATION_LOWER_NODE_LIMIT) * this.coolingFactor * (1 - e.COOLING_ADAPTATION_FACTOR))), this.maxNodeDisplacement = e.MAX_NODE_DISPLACEMENT_INCREMENTAL) : (n > e.ADAPTATION_LOWER_NODE_LIMIT ? this.coolingFactor = Math.max(e.COOLING_ADAPTATION_FACTOR, 1 - (n - e.ADAPTATION_LOWER_NODE_LIMIT) / (e.ADAPTATION_UPPER_NODE_LIMIT - e.ADAPTATION_LOWER_NODE_LIMIT) * (1 - e.COOLING_ADAPTATION_FACTOR)) : this.coolingFactor = 1, this.initialCoolingFactor = this.coolingFactor, this.maxNodeDisplacement = e.MAX_NODE_DISPLACEMENT), this.maxIterations = Math.max(this.getAllNodes().length * 5, this.maxIterations), this.totalDisplacementThreshold = this.displacementThresholdPerNode * this.getAllNodes().length, this.repulsionRange = this.calcRepulsionRange();
            }, a.prototype.calcSpringForces = function() {
              for (var n = this.getAllEdges(), c, l = 0; l < n.length; l++)
                c = n[l], this.calcSpringForce(c, c.idealLength);
            }, a.prototype.calcRepulsionForces = function() {
              var n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, c = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, l, E, T, m, L = this.getAllNodes(), O;
              if (this.useFRGridVariant)
                for (this.totalIterations % e.GRID_CALCULATION_CHECK_PERIOD == 1 && n && this.updateGrid(), O = /* @__PURE__ */ new Set(), l = 0; l < L.length; l++)
                  T = L[l], this.calculateRepulsionForceOfANode(T, O, n, c), O.add(T);
              else
                for (l = 0; l < L.length; l++)
                  for (T = L[l], E = l + 1; E < L.length; E++)
                    m = L[E], T.getOwner() == m.getOwner() && this.calcRepulsionForce(T, m);
            }, a.prototype.calcGravitationalForces = function() {
              for (var n, c = this.getAllNodesToApplyGravitation(), l = 0; l < c.length; l++)
                n = c[l], this.calcGravitationalForce(n);
            }, a.prototype.moveNodes = function() {
              for (var n = this.getAllNodes(), c, l = 0; l < n.length; l++)
                c = n[l], c.move();
            }, a.prototype.calcSpringForce = function(n, c) {
              var l = n.getSource(), E = n.getTarget(), T, m, L, O;
              if (this.uniformLeafNodeSizes && l.getChild() == null && E.getChild() == null)
                n.updateLengthSimple();
              else if (n.updateLength(), n.isOverlapingSourceAndTarget)
                return;
              T = n.getLength(), T != 0 && (m = this.springConstant * (T - c), L = m * (n.lengthX / T), O = m * (n.lengthY / T), l.springForceX += L, l.springForceY += O, E.springForceX -= L, E.springForceY -= O);
            }, a.prototype.calcRepulsionForce = function(n, c) {
              var l = n.getRect(), E = c.getRect(), T = new Array(2), m = new Array(4), L, O, d, N, s, h, f;
              if (l.intersects(E)) {
                o.calcSeparationAmount(l, E, T, e.DEFAULT_EDGE_LENGTH / 2), h = 2 * T[0], f = 2 * T[1];
                var p = n.noOfChildren * c.noOfChildren / (n.noOfChildren + c.noOfChildren);
                n.repulsionForceX -= p * h, n.repulsionForceY -= p * f, c.repulsionForceX += p * h, c.repulsionForceY += p * f;
              } else
                this.uniformLeafNodeSizes && n.getChild() == null && c.getChild() == null ? (L = E.getCenterX() - l.getCenterX(), O = E.getCenterY() - l.getCenterY()) : (o.getIntersection(l, E, m), L = m[2] - m[0], O = m[3] - m[1]), Math.abs(L) < e.MIN_REPULSION_DIST && (L = g.sign(L) * e.MIN_REPULSION_DIST), Math.abs(O) < e.MIN_REPULSION_DIST && (O = g.sign(O) * e.MIN_REPULSION_DIST), d = L * L + O * O, N = Math.sqrt(d), s = this.repulsionConstant * n.noOfChildren * c.noOfChildren / d, h = s * L / N, f = s * O / N, n.repulsionForceX -= h, n.repulsionForceY -= f, c.repulsionForceX += h, c.repulsionForceY += f;
            }, a.prototype.calcGravitationalForce = function(n) {
              var c, l, E, T, m, L, O, d;
              c = n.getOwner(), l = (c.getRight() + c.getLeft()) / 2, E = (c.getTop() + c.getBottom()) / 2, T = n.getCenterX() - l, m = n.getCenterY() - E, L = Math.abs(T) + n.getWidth() / 2, O = Math.abs(m) + n.getHeight() / 2, n.getOwner() == this.graphManager.getRoot() ? (d = c.getEstimatedSize() * this.gravityRangeFactor, (L > d || O > d) && (n.gravitationForceX = -this.gravityConstant * T, n.gravitationForceY = -this.gravityConstant * m)) : (d = c.getEstimatedSize() * this.compoundGravityRangeFactor, (L > d || O > d) && (n.gravitationForceX = -this.gravityConstant * T * this.compoundGravityConstant, n.gravitationForceY = -this.gravityConstant * m * this.compoundGravityConstant));
            }, a.prototype.isConverged = function() {
              var n, c = !1;
              return this.totalIterations > this.maxIterations / 3 && (c = Math.abs(this.totalDisplacement - this.oldTotalDisplacement) < 2), n = this.totalDisplacement < this.totalDisplacementThreshold, this.oldTotalDisplacement = this.totalDisplacement, n || c;
            }, a.prototype.animate = function() {
              this.animationDuringLayout && !this.isSubLayout && (this.notAnimatedIterations == this.animationPeriod ? (this.update(), this.notAnimatedIterations = 0) : this.notAnimatedIterations++);
            }, a.prototype.calcNoOfChildrenForAllNodes = function() {
              for (var n, c = this.graphManager.getAllNodes(), l = 0; l < c.length; l++)
                n = c[l], n.noOfChildren = n.getNoOfChildren();
            }, a.prototype.calcGrid = function(n) {
              var c = 0, l = 0;
              c = parseInt(Math.ceil((n.getRight() - n.getLeft()) / this.repulsionRange)), l = parseInt(Math.ceil((n.getBottom() - n.getTop()) / this.repulsionRange));
              for (var E = new Array(c), T = 0; T < c; T++)
                E[T] = new Array(l);
              for (var T = 0; T < c; T++)
                for (var m = 0; m < l; m++)
                  E[T][m] = new Array();
              return E;
            }, a.prototype.addNodeToGrid = function(n, c, l) {
              var E = 0, T = 0, m = 0, L = 0;
              E = parseInt(Math.floor((n.getRect().x - c) / this.repulsionRange)), T = parseInt(Math.floor((n.getRect().width + n.getRect().x - c) / this.repulsionRange)), m = parseInt(Math.floor((n.getRect().y - l) / this.repulsionRange)), L = parseInt(Math.floor((n.getRect().height + n.getRect().y - l) / this.repulsionRange));
              for (var O = E; O <= T; O++)
                for (var d = m; d <= L; d++)
                  this.grid[O][d].push(n), n.setGridCoordinates(E, T, m, L);
            }, a.prototype.updateGrid = function() {
              var n, c, l = this.getAllNodes();
              for (this.grid = this.calcGrid(this.graphManager.getRoot()), n = 0; n < l.length; n++)
                c = l[n], this.addNodeToGrid(c, this.graphManager.getRoot().getLeft(), this.graphManager.getRoot().getTop());
            }, a.prototype.calculateRepulsionForceOfANode = function(n, c, l, E) {
              if (this.totalIterations % e.GRID_CALCULATION_CHECK_PERIOD == 1 && l || E) {
                var T = /* @__PURE__ */ new Set();
                n.surrounding = new Array();
                for (var m, L = this.grid, O = n.startX - 1; O < n.finishX + 2; O++)
                  for (var d = n.startY - 1; d < n.finishY + 2; d++)
                    if (!(O < 0 || d < 0 || O >= L.length || d >= L[0].length)) {
                      for (var N = 0; N < L[O][d].length; N++)
                        if (m = L[O][d][N], !(n.getOwner() != m.getOwner() || n == m) && !c.has(m) && !T.has(m)) {
                          var s = Math.abs(n.getCenterX() - m.getCenterX()) - (n.getWidth() / 2 + m.getWidth() / 2), h = Math.abs(n.getCenterY() - m.getCenterY()) - (n.getHeight() / 2 + m.getHeight() / 2);
                          s <= this.repulsionRange && h <= this.repulsionRange && T.add(m);
                        }
                    }
                n.surrounding = [].concat(r(T));
              }
              for (O = 0; O < n.surrounding.length; O++)
                this.calcRepulsionForce(n, n.surrounding[O]);
            }, a.prototype.calcRepulsionRange = function() {
              return 0;
            }, u.exports = a;
          },
          /* 19 */
          /***/
          function(u, D, y) {
            var r = y(1), t = y(7);
            function e(o, g, a) {
              r.call(this, o, g, a), this.idealLength = t.DEFAULT_EDGE_LENGTH;
            }
            e.prototype = Object.create(r.prototype);
            for (var i in r)
              e[i] = r[i];
            u.exports = e;
          },
          /* 20 */
          /***/
          function(u, D, y) {
            var r = y(3);
            function t(i, o, g, a) {
              r.call(this, i, o, g, a), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0, this.startX = 0, this.finishX = 0, this.startY = 0, this.finishY = 0, this.surrounding = [];
            }
            t.prototype = Object.create(r.prototype);
            for (var e in r)
              t[e] = r[e];
            t.prototype.setGridCoordinates = function(i, o, g, a) {
              this.startX = i, this.finishX = o, this.startY = g, this.finishY = a;
            }, u.exports = t;
          },
          /* 21 */
          /***/
          function(u, D, y) {
            function r(t, e) {
              this.width = 0, this.height = 0, t !== null && e !== null && (this.height = e, this.width = t);
            }
            r.prototype.getWidth = function() {
              return this.width;
            }, r.prototype.setWidth = function(t) {
              this.width = t;
            }, r.prototype.getHeight = function() {
              return this.height;
            }, r.prototype.setHeight = function(t) {
              this.height = t;
            }, u.exports = r;
          },
          /* 22 */
          /***/
          function(u, D, y) {
            var r = y(14);
            function t() {
              this.map = {}, this.keys = [];
            }
            t.prototype.put = function(e, i) {
              var o = r.createID(e);
              this.contains(o) || (this.map[o] = i, this.keys.push(e));
            }, t.prototype.contains = function(e) {
              return r.createID(e), this.map[e] != null;
            }, t.prototype.get = function(e) {
              var i = r.createID(e);
              return this.map[i];
            }, t.prototype.keySet = function() {
              return this.keys;
            }, u.exports = t;
          },
          /* 23 */
          /***/
          function(u, D, y) {
            var r = y(14);
            function t() {
              this.set = {};
            }
            t.prototype.add = function(e) {
              var i = r.createID(e);
              this.contains(i) || (this.set[i] = e);
            }, t.prototype.remove = function(e) {
              delete this.set[r.createID(e)];
            }, t.prototype.clear = function() {
              this.set = {};
            }, t.prototype.contains = function(e) {
              return this.set[r.createID(e)] == e;
            }, t.prototype.isEmpty = function() {
              return this.size() === 0;
            }, t.prototype.size = function() {
              return Object.keys(this.set).length;
            }, t.prototype.addAllTo = function(e) {
              for (var i = Object.keys(this.set), o = i.length, g = 0; g < o; g++)
                e.push(this.set[i[g]]);
            }, t.prototype.size = function() {
              return Object.keys(this.set).length;
            }, t.prototype.addAll = function(e) {
              for (var i = e.length, o = 0; o < i; o++) {
                var g = e[o];
                this.add(g);
              }
            }, u.exports = t;
          },
          /* 24 */
          /***/
          function(u, D, y) {
            var r = /* @__PURE__ */ function() {
              function o(g, a) {
                for (var v = 0; v < a.length; v++) {
                  var n = a[v];
                  n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(g, n.key, n);
                }
              }
              return function(g, a, v) {
                return a && o(g.prototype, a), v && o(g, v), g;
              };
            }();
            function t(o, g) {
              if (!(o instanceof g))
                throw new TypeError("Cannot call a class as a function");
            }
            var e = y(11), i = function() {
              function o(g, a) {
                t(this, o), (a !== null || a !== void 0) && (this.compareFunction = this._defaultCompareFunction);
                var v = void 0;
                g instanceof e ? v = g.size() : v = g.length, this._quicksort(g, 0, v - 1);
              }
              return r(o, [{
                key: "_quicksort",
                value: function(a, v, n) {
                  if (v < n) {
                    var c = this._partition(a, v, n);
                    this._quicksort(a, v, c), this._quicksort(a, c + 1, n);
                  }
                }
              }, {
                key: "_partition",
                value: function(a, v, n) {
                  for (var c = this._get(a, v), l = v, E = n; ; ) {
                    for (; this.compareFunction(c, this._get(a, E)); )
                      E--;
                    for (; this.compareFunction(this._get(a, l), c); )
                      l++;
                    if (l < E)
                      this._swap(a, l, E), l++, E--;
                    else return E;
                  }
                }
              }, {
                key: "_get",
                value: function(a, v) {
                  return a instanceof e ? a.get_object_at(v) : a[v];
                }
              }, {
                key: "_set",
                value: function(a, v, n) {
                  a instanceof e ? a.set_object_at(v, n) : a[v] = n;
                }
              }, {
                key: "_swap",
                value: function(a, v, n) {
                  var c = this._get(a, v);
                  this._set(a, v, this._get(a, n)), this._set(a, n, c);
                }
              }, {
                key: "_defaultCompareFunction",
                value: function(a, v) {
                  return v > a;
                }
              }]), o;
            }();
            u.exports = i;
          },
          /* 25 */
          /***/
          function(u, D, y) {
            var r = /* @__PURE__ */ function() {
              function i(o, g) {
                for (var a = 0; a < g.length; a++) {
                  var v = g[a];
                  v.enumerable = v.enumerable || !1, v.configurable = !0, "value" in v && (v.writable = !0), Object.defineProperty(o, v.key, v);
                }
              }
              return function(o, g, a) {
                return g && i(o.prototype, g), a && i(o, a), o;
              };
            }();
            function t(i, o) {
              if (!(i instanceof o))
                throw new TypeError("Cannot call a class as a function");
            }
            var e = function() {
              function i(o, g) {
                var a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, v = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : -1, n = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : -1;
                t(this, i), this.sequence1 = o, this.sequence2 = g, this.match_score = a, this.mismatch_penalty = v, this.gap_penalty = n, this.iMax = o.length + 1, this.jMax = g.length + 1, this.grid = new Array(this.iMax);
                for (var c = 0; c < this.iMax; c++) {
                  this.grid[c] = new Array(this.jMax);
                  for (var l = 0; l < this.jMax; l++)
                    this.grid[c][l] = 0;
                }
                this.tracebackGrid = new Array(this.iMax);
                for (var E = 0; E < this.iMax; E++) {
                  this.tracebackGrid[E] = new Array(this.jMax);
                  for (var T = 0; T < this.jMax; T++)
                    this.tracebackGrid[E][T] = [null, null, null];
                }
                this.alignments = [], this.score = -1, this.computeGrids();
              }
              return r(i, [{
                key: "getScore",
                value: function() {
                  return this.score;
                }
              }, {
                key: "getAlignments",
                value: function() {
                  return this.alignments;
                }
                // Main dynamic programming procedure
              }, {
                key: "computeGrids",
                value: function() {
                  for (var g = 1; g < this.jMax; g++)
                    this.grid[0][g] = this.grid[0][g - 1] + this.gap_penalty, this.tracebackGrid[0][g] = [!1, !1, !0];
                  for (var a = 1; a < this.iMax; a++)
                    this.grid[a][0] = this.grid[a - 1][0] + this.gap_penalty, this.tracebackGrid[a][0] = [!1, !0, !1];
                  for (var v = 1; v < this.iMax; v++)
                    for (var n = 1; n < this.jMax; n++) {
                      var c = void 0;
                      this.sequence1[v - 1] === this.sequence2[n - 1] ? c = this.grid[v - 1][n - 1] + this.match_score : c = this.grid[v - 1][n - 1] + this.mismatch_penalty;
                      var l = this.grid[v - 1][n] + this.gap_penalty, E = this.grid[v][n - 1] + this.gap_penalty, T = [c, l, E], m = this.arrayAllMaxIndexes(T);
                      this.grid[v][n] = T[m[0]], this.tracebackGrid[v][n] = [m.includes(0), m.includes(1), m.includes(2)];
                    }
                  this.score = this.grid[this.iMax - 1][this.jMax - 1];
                }
                // Gets all possible valid sequence combinations
              }, {
                key: "alignmentTraceback",
                value: function() {
                  var g = [];
                  for (g.push({
                    pos: [this.sequence1.length, this.sequence2.length],
                    seq1: "",
                    seq2: ""
                  }); g[0]; ) {
                    var a = g[0], v = this.tracebackGrid[a.pos[0]][a.pos[1]];
                    v[0] && g.push({
                      pos: [a.pos[0] - 1, a.pos[1] - 1],
                      seq1: this.sequence1[a.pos[0] - 1] + a.seq1,
                      seq2: this.sequence2[a.pos[1] - 1] + a.seq2
                    }), v[1] && g.push({
                      pos: [a.pos[0] - 1, a.pos[1]],
                      seq1: this.sequence1[a.pos[0] - 1] + a.seq1,
                      seq2: "-" + a.seq2
                    }), v[2] && g.push({
                      pos: [a.pos[0], a.pos[1] - 1],
                      seq1: "-" + a.seq1,
                      seq2: this.sequence2[a.pos[1] - 1] + a.seq2
                    }), a.pos[0] === 0 && a.pos[1] === 0 && this.alignments.push({
                      sequence1: a.seq1,
                      sequence2: a.seq2
                    }), g.shift();
                  }
                  return this.alignments;
                }
                // Helper Functions
              }, {
                key: "getAllIndexes",
                value: function(g, a) {
                  for (var v = [], n = -1; (n = g.indexOf(a, n + 1)) !== -1; )
                    v.push(n);
                  return v;
                }
              }, {
                key: "arrayAllMaxIndexes",
                value: function(g) {
                  return this.getAllIndexes(g, Math.max.apply(null, g));
                }
              }]), i;
            }();
            u.exports = e;
          },
          /* 26 */
          /***/
          function(u, D, y) {
            var r = function() {
            };
            r.FDLayout = y(18), r.FDLayoutConstants = y(7), r.FDLayoutEdge = y(19), r.FDLayoutNode = y(20), r.DimensionD = y(21), r.HashMap = y(22), r.HashSet = y(23), r.IGeometry = y(8), r.IMath = y(9), r.Integer = y(10), r.Point = y(12), r.PointD = y(4), r.RandomSeed = y(16), r.RectangleD = y(13), r.Transform = y(17), r.UniqueIDGeneretor = y(14), r.Quicksort = y(24), r.LinkedList = y(11), r.LGraphObject = y(2), r.LGraph = y(5), r.LEdge = y(1), r.LGraphManager = y(6), r.LNode = y(3), r.Layout = y(15), r.LayoutConstants = y(0), r.NeedlemanWunsch = y(25), u.exports = r;
          },
          /* 27 */
          /***/
          function(u, D, y) {
            function r() {
              this.listeners = [];
            }
            var t = r.prototype;
            t.addListener = function(e, i) {
              this.listeners.push({
                event: e,
                callback: i
              });
            }, t.removeListener = function(e, i) {
              for (var o = this.listeners.length; o >= 0; o--) {
                var g = this.listeners[o];
                g.event === e && g.callback === i && this.listeners.splice(o, 1);
              }
            }, t.emit = function(e, i) {
              for (var o = 0; o < this.listeners.length; o++) {
                var g = this.listeners[o];
                e === g.event && g.callback(i);
              }
            }, u.exports = r;
          }
          /******/
        ])
      );
    });
  }(it)), it.exports;
}
var gt;
function Rt() {
  return gt || (gt = 1, function(C, M) {
    (function(D, y) {
      C.exports = y(Ct());
    })(at, function(u) {
      return (
        /******/
        function(D) {
          var y = {};
          function r(t) {
            if (y[t])
              return y[t].exports;
            var e = y[t] = {
              /******/
              i: t,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return D[t].call(e.exports, e, e.exports, r), e.l = !0, e.exports;
          }
          return r.m = D, r.c = y, r.i = function(t) {
            return t;
          }, r.d = function(t, e, i) {
            r.o(t, e) || Object.defineProperty(t, e, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: i
              /******/
            });
          }, r.n = function(t) {
            var e = t && t.__esModule ? (
              /******/
              function() {
                return t.default;
              }
            ) : (
              /******/
              function() {
                return t;
              }
            );
            return r.d(e, "a", e), e;
          }, r.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e);
          }, r.p = "", r(r.s = 7);
        }([
          /* 0 */
          /***/
          function(D, y) {
            D.exports = u;
          },
          /* 1 */
          /***/
          function(D, y, r) {
            var t = r(0).FDLayoutConstants;
            function e() {
            }
            for (var i in t)
              e[i] = t[i];
            e.DEFAULT_USE_MULTI_LEVEL_SCALING = !1, e.DEFAULT_RADIAL_SEPARATION = t.DEFAULT_EDGE_LENGTH, e.DEFAULT_COMPONENT_SEPERATION = 60, e.TILE = !0, e.TILING_PADDING_VERTICAL = 10, e.TILING_PADDING_HORIZONTAL = 10, e.TREE_REDUCTION_ON_INCREMENTAL = !1, D.exports = e;
          },
          /* 2 */
          /***/
          function(D, y, r) {
            var t = r(0).FDLayoutEdge;
            function e(o, g, a) {
              t.call(this, o, g, a);
            }
            e.prototype = Object.create(t.prototype);
            for (var i in t)
              e[i] = t[i];
            D.exports = e;
          },
          /* 3 */
          /***/
          function(D, y, r) {
            var t = r(0).LGraph;
            function e(o, g, a) {
              t.call(this, o, g, a);
            }
            e.prototype = Object.create(t.prototype);
            for (var i in t)
              e[i] = t[i];
            D.exports = e;
          },
          /* 4 */
          /***/
          function(D, y, r) {
            var t = r(0).LGraphManager;
            function e(o) {
              t.call(this, o);
            }
            e.prototype = Object.create(t.prototype);
            for (var i in t)
              e[i] = t[i];
            D.exports = e;
          },
          /* 5 */
          /***/
          function(D, y, r) {
            var t = r(0).FDLayoutNode, e = r(0).IMath;
            function i(g, a, v, n) {
              t.call(this, g, a, v, n);
            }
            i.prototype = Object.create(t.prototype);
            for (var o in t)
              i[o] = t[o];
            i.prototype.move = function() {
              var g = this.graphManager.getLayout();
              this.displacementX = g.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.noOfChildren, this.displacementY = g.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.noOfChildren, Math.abs(this.displacementX) > g.coolingFactor * g.maxNodeDisplacement && (this.displacementX = g.coolingFactor * g.maxNodeDisplacement * e.sign(this.displacementX)), Math.abs(this.displacementY) > g.coolingFactor * g.maxNodeDisplacement && (this.displacementY = g.coolingFactor * g.maxNodeDisplacement * e.sign(this.displacementY)), this.child == null ? this.moveBy(this.displacementX, this.displacementY) : this.child.getNodes().length == 0 ? this.moveBy(this.displacementX, this.displacementY) : this.propogateDisplacementToChildren(this.displacementX, this.displacementY), g.totalDisplacement += Math.abs(this.displacementX) + Math.abs(this.displacementY), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0;
            }, i.prototype.propogateDisplacementToChildren = function(g, a) {
              for (var v = this.getChild().getNodes(), n, c = 0; c < v.length; c++)
                n = v[c], n.getChild() == null ? (n.moveBy(g, a), n.displacementX += g, n.displacementY += a) : n.propogateDisplacementToChildren(g, a);
            }, i.prototype.setPred1 = function(g) {
              this.pred1 = g;
            }, i.prototype.getPred1 = function() {
              return pred1;
            }, i.prototype.getPred2 = function() {
              return pred2;
            }, i.prototype.setNext = function(g) {
              this.next = g;
            }, i.prototype.getNext = function() {
              return next;
            }, i.prototype.setProcessed = function(g) {
              this.processed = g;
            }, i.prototype.isProcessed = function() {
              return processed;
            }, D.exports = i;
          },
          /* 6 */
          /***/
          function(D, y, r) {
            var t = r(0).FDLayout, e = r(4), i = r(3), o = r(5), g = r(2), a = r(1), v = r(0).FDLayoutConstants, n = r(0).LayoutConstants, c = r(0).Point, l = r(0).PointD, E = r(0).Layout, T = r(0).Integer, m = r(0).IGeometry, L = r(0).LGraph, O = r(0).Transform;
            function d() {
              t.call(this), this.toBeTiled = {};
            }
            d.prototype = Object.create(t.prototype);
            for (var N in t)
              d[N] = t[N];
            d.prototype.newGraphManager = function() {
              var s = new e(this);
              return this.graphManager = s, s;
            }, d.prototype.newGraph = function(s) {
              return new i(null, this.graphManager, s);
            }, d.prototype.newNode = function(s) {
              return new o(this.graphManager, s);
            }, d.prototype.newEdge = function(s) {
              return new g(null, null, s);
            }, d.prototype.initParameters = function() {
              t.prototype.initParameters.call(this, arguments), this.isSubLayout || (a.DEFAULT_EDGE_LENGTH < 10 ? this.idealEdgeLength = 10 : this.idealEdgeLength = a.DEFAULT_EDGE_LENGTH, this.useSmartIdealEdgeLengthCalculation = a.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.springConstant = v.DEFAULT_SPRING_STRENGTH, this.repulsionConstant = v.DEFAULT_REPULSION_STRENGTH, this.gravityConstant = v.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = v.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = v.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = v.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.prunedNodesAll = [], this.growTreeIterations = 0, this.afterGrowthIterations = 0, this.isTreeGrowing = !1, this.isGrowthFinished = !1, this.coolingCycle = 0, this.maxCoolingCycle = this.maxIterations / v.CONVERGENCE_CHECK_PERIOD, this.finalTemperature = v.CONVERGENCE_CHECK_PERIOD / this.maxIterations, this.coolingAdjuster = 1);
            }, d.prototype.layout = function() {
              var s = n.DEFAULT_CREATE_BENDS_AS_NEEDED;
              return s && (this.createBendpoints(), this.graphManager.resetAllEdges()), this.level = 0, this.classicLayout();
            }, d.prototype.classicLayout = function() {
              if (this.nodesWithGravity = this.calculateNodesToApplyGravitationTo(), this.graphManager.setAllNodesToApplyGravitation(this.nodesWithGravity), this.calcNoOfChildrenForAllNodes(), this.graphManager.calcLowestCommonAncestors(), this.graphManager.calcInclusionTreeDepths(), this.graphManager.getRoot().calcEstimatedSize(), this.calcIdealEdgeLengths(), this.incremental) {
                if (a.TREE_REDUCTION_ON_INCREMENTAL) {
                  this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                  var h = new Set(this.getAllNodes()), f = this.nodesWithGravity.filter(function(I) {
                    return h.has(I);
                  });
                  this.graphManager.setAllNodesToApplyGravitation(f);
                }
              } else {
                var s = this.getFlatForest();
                if (s.length > 0)
                  this.positionNodesRadially(s);
                else {
                  this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                  var h = new Set(this.getAllNodes()), f = this.nodesWithGravity.filter(function(p) {
                    return h.has(p);
                  });
                  this.graphManager.setAllNodesToApplyGravitation(f), this.positionNodesRandomly();
                }
              }
              return this.initSpringEmbedder(), this.runSpringEmbedder(), !0;
            }, d.prototype.tick = function() {
              if (this.totalIterations++, this.totalIterations === this.maxIterations && !this.isTreeGrowing && !this.isGrowthFinished)
                if (this.prunedNodesAll.length > 0)
                  this.isTreeGrowing = !0;
                else
                  return !0;
              if (this.totalIterations % v.CONVERGENCE_CHECK_PERIOD == 0 && !this.isTreeGrowing && !this.isGrowthFinished) {
                if (this.isConverged())
                  if (this.prunedNodesAll.length > 0)
                    this.isTreeGrowing = !0;
                  else
                    return !0;
                this.coolingCycle++, this.layoutQuality == 0 ? this.coolingAdjuster = this.coolingCycle : this.layoutQuality == 1 && (this.coolingAdjuster = this.coolingCycle / 3), this.coolingFactor = Math.max(this.initialCoolingFactor - Math.pow(this.coolingCycle, Math.log(100 * (this.initialCoolingFactor - this.finalTemperature)) / Math.log(this.maxCoolingCycle)) / 100 * this.coolingAdjuster, this.finalTemperature), this.animationPeriod = Math.ceil(this.initialAnimationPeriod * Math.sqrt(this.coolingFactor));
              }
              if (this.isTreeGrowing) {
                if (this.growTreeIterations % 10 == 0)
                  if (this.prunedNodesAll.length > 0) {
                    this.graphManager.updateBounds(), this.updateGrid(), this.growTree(this.prunedNodesAll), this.graphManager.resetAllNodesToApplyGravitation();
                    var s = new Set(this.getAllNodes()), h = this.nodesWithGravity.filter(function(A) {
                      return s.has(A);
                    });
                    this.graphManager.setAllNodesToApplyGravitation(h), this.graphManager.updateBounds(), this.updateGrid(), this.coolingFactor = v.DEFAULT_COOLING_FACTOR_INCREMENTAL;
                  } else
                    this.isTreeGrowing = !1, this.isGrowthFinished = !0;
                this.growTreeIterations++;
              }
              if (this.isGrowthFinished) {
                if (this.isConverged())
                  return !0;
                this.afterGrowthIterations % 10 == 0 && (this.graphManager.updateBounds(), this.updateGrid()), this.coolingFactor = v.DEFAULT_COOLING_FACTOR_INCREMENTAL * ((100 - this.afterGrowthIterations) / 100), this.afterGrowthIterations++;
              }
              var f = !this.isTreeGrowing && !this.isGrowthFinished, p = this.growTreeIterations % 10 == 1 && this.isTreeGrowing || this.afterGrowthIterations % 10 == 1 && this.isGrowthFinished;
              return this.totalDisplacement = 0, this.graphManager.updateBounds(), this.calcSpringForces(), this.calcRepulsionForces(f, p), this.calcGravitationalForces(), this.moveNodes(), this.animate(), !1;
            }, d.prototype.getPositionsData = function() {
              for (var s = this.graphManager.getAllNodes(), h = {}, f = 0; f < s.length; f++) {
                var p = s[f].rect, A = s[f].id;
                h[A] = {
                  id: A,
                  x: p.getCenterX(),
                  y: p.getCenterY(),
                  w: p.width,
                  h: p.height
                };
              }
              return h;
            }, d.prototype.runSpringEmbedder = function() {
              this.initialAnimationPeriod = 25, this.animationPeriod = this.initialAnimationPeriod;
              var s = !1;
              if (v.ANIMATE === "during")
                this.emit("layoutstarted");
              else {
                for (; !s; )
                  s = this.tick();
                this.graphManager.updateBounds();
              }
            }, d.prototype.calculateNodesToApplyGravitationTo = function() {
              var s = [], h, f = this.graphManager.getGraphs(), p = f.length, A;
              for (A = 0; A < p; A++)
                h = f[A], h.updateConnected(), h.isConnected || (s = s.concat(h.getNodes()));
              return s;
            }, d.prototype.createBendpoints = function() {
              var s = [];
              s = s.concat(this.graphManager.getAllEdges());
              var h = /* @__PURE__ */ new Set(), f;
              for (f = 0; f < s.length; f++) {
                var p = s[f];
                if (!h.has(p)) {
                  var A = p.getSource(), I = p.getTarget();
                  if (A == I)
                    p.getBendpoints().push(new l()), p.getBendpoints().push(new l()), this.createDummyNodesForBendpoints(p), h.add(p);
                  else {
                    var R = [];
                    if (R = R.concat(A.getEdgeListToNode(I)), R = R.concat(I.getEdgeListToNode(A)), !h.has(R[0])) {
                      if (R.length > 1) {
                        var x;
                        for (x = 0; x < R.length; x++) {
                          var G = R[x];
                          G.getBendpoints().push(new l()), this.createDummyNodesForBendpoints(G);
                        }
                      }
                      R.forEach(function(U) {
                        h.add(U);
                      });
                    }
                  }
                }
                if (h.size == s.length)
                  break;
              }
            }, d.prototype.positionNodesRadially = function(s) {
              for (var h = new c(0, 0), f = Math.ceil(Math.sqrt(s.length)), p = 0, A = 0, I = 0, R = new l(0, 0), x = 0; x < s.length; x++) {
                x % f == 0 && (I = 0, A = p, x != 0 && (A += a.DEFAULT_COMPONENT_SEPERATION), p = 0);
                var G = s[x], U = E.findCenterOfTree(G);
                h.x = I, h.y = A, R = d.radialLayout(G, U, h), R.y > p && (p = Math.floor(R.y)), I = Math.floor(R.x + a.DEFAULT_COMPONENT_SEPERATION);
              }
              this.transform(new l(n.WORLD_CENTER_X - R.x / 2, n.WORLD_CENTER_Y - R.y / 2));
            }, d.radialLayout = function(s, h, f) {
              var p = Math.max(this.maxDiagonalInTree(s), a.DEFAULT_RADIAL_SEPARATION);
              d.branchRadialLayout(h, null, 0, 359, 0, p);
              var A = L.calculateBounds(s), I = new O();
              I.setDeviceOrgX(A.getMinX()), I.setDeviceOrgY(A.getMinY()), I.setWorldOrgX(f.x), I.setWorldOrgY(f.y);
              for (var R = 0; R < s.length; R++) {
                var x = s[R];
                x.transform(I);
              }
              var G = new l(A.getMaxX(), A.getMaxY());
              return I.inverseTransformPoint(G);
            }, d.branchRadialLayout = function(s, h, f, p, A, I) {
              var R = (p - f + 1) / 2;
              R < 0 && (R += 180);
              var x = (R + f) % 360, G = x * m.TWO_PI / 360, U = A * Math.cos(G), X = A * Math.sin(G);
              s.setCenter(U, X);
              var w = [];
              w = w.concat(s.getEdges());
              var S = w.length;
              h != null && S--;
              for (var F = 0, b = w.length, Y, k = s.getEdgesBetween(h); k.length > 1; ) {
                var H = k[0];
                k.splice(0, 1);
                var P = w.indexOf(H);
                P >= 0 && w.splice(P, 1), b--, S--;
              }
              h != null ? Y = (w.indexOf(k[0]) + 1) % b : Y = 0;
              for (var W = Math.abs(p - f) / S, $ = Y; F != S; $ = ++$ % b) {
                var j = w[$].getOtherEnd(s);
                if (j != h) {
                  var V = (f + F * W) % 360, z = (V + W) % 360;
                  d.branchRadialLayout(j, s, V, z, A + I, I), F++;
                }
              }
            }, d.maxDiagonalInTree = function(s) {
              for (var h = T.MIN_VALUE, f = 0; f < s.length; f++) {
                var p = s[f], A = p.getDiagonal();
                A > h && (h = A);
              }
              return h;
            }, d.prototype.calcRepulsionRange = function() {
              return 2 * (this.level + 1) * this.idealEdgeLength;
            }, d.prototype.groupZeroDegreeMembers = function() {
              var s = this, h = {};
              this.memberGroups = {}, this.idToDummyNode = {};
              for (var f = [], p = this.graphManager.getAllNodes(), A = 0; A < p.length; A++) {
                var I = p[A], R = I.getParent();
                this.getNodeDegreeWithChildren(I) === 0 && (R.id == null || !this.getToBeTiled(R)) && f.push(I);
              }
              for (var A = 0; A < f.length; A++) {
                var I = f[A], x = I.getParent().id;
                typeof h[x] > "u" && (h[x] = []), h[x] = h[x].concat(I);
              }
              Object.keys(h).forEach(function(G) {
                if (h[G].length > 1) {
                  var U = "DummyCompound_" + G;
                  s.memberGroups[U] = h[G];
                  var X = h[G][0].getParent(), w = new o(s.graphManager);
                  w.id = U, w.paddingLeft = X.paddingLeft || 0, w.paddingRight = X.paddingRight || 0, w.paddingBottom = X.paddingBottom || 0, w.paddingTop = X.paddingTop || 0, s.idToDummyNode[U] = w;
                  var S = s.getGraphManager().add(s.newGraph(), w), F = X.getChild();
                  F.add(w);
                  for (var b = 0; b < h[G].length; b++) {
                    var Y = h[G][b];
                    F.remove(Y), S.add(Y);
                  }
                }
              });
            }, d.prototype.clearCompounds = function() {
              var s = {}, h = {};
              this.performDFSOnCompounds();
              for (var f = 0; f < this.compoundOrder.length; f++)
                h[this.compoundOrder[f].id] = this.compoundOrder[f], s[this.compoundOrder[f].id] = [].concat(this.compoundOrder[f].getChild().getNodes()), this.graphManager.remove(this.compoundOrder[f].getChild()), this.compoundOrder[f].child = null;
              this.graphManager.resetAllNodes(), this.tileCompoundMembers(s, h);
            }, d.prototype.clearZeroDegreeMembers = function() {
              var s = this, h = this.tiledZeroDegreePack = [];
              Object.keys(this.memberGroups).forEach(function(f) {
                var p = s.idToDummyNode[f];
                h[f] = s.tileNodes(s.memberGroups[f], p.paddingLeft + p.paddingRight), p.rect.width = h[f].width, p.rect.height = h[f].height;
              });
            }, d.prototype.repopulateCompounds = function() {
              for (var s = this.compoundOrder.length - 1; s >= 0; s--) {
                var h = this.compoundOrder[s], f = h.id, p = h.paddingLeft, A = h.paddingTop;
                this.adjustLocations(this.tiledMemberPack[f], h.rect.x, h.rect.y, p, A);
              }
            }, d.prototype.repopulateZeroDegreeMembers = function() {
              var s = this, h = this.tiledZeroDegreePack;
              Object.keys(h).forEach(function(f) {
                var p = s.idToDummyNode[f], A = p.paddingLeft, I = p.paddingTop;
                s.adjustLocations(h[f], p.rect.x, p.rect.y, A, I);
              });
            }, d.prototype.getToBeTiled = function(s) {
              var h = s.id;
              if (this.toBeTiled[h] != null)
                return this.toBeTiled[h];
              var f = s.getChild();
              if (f == null)
                return this.toBeTiled[h] = !1, !1;
              for (var p = f.getNodes(), A = 0; A < p.length; A++) {
                var I = p[A];
                if (this.getNodeDegree(I) > 0)
                  return this.toBeTiled[h] = !1, !1;
                if (I.getChild() == null) {
                  this.toBeTiled[I.id] = !1;
                  continue;
                }
                if (!this.getToBeTiled(I))
                  return this.toBeTiled[h] = !1, !1;
              }
              return this.toBeTiled[h] = !0, !0;
            }, d.prototype.getNodeDegree = function(s) {
              s.id;
              for (var h = s.getEdges(), f = 0, p = 0; p < h.length; p++) {
                var A = h[p];
                A.getSource().id !== A.getTarget().id && (f = f + 1);
              }
              return f;
            }, d.prototype.getNodeDegreeWithChildren = function(s) {
              var h = this.getNodeDegree(s);
              if (s.getChild() == null)
                return h;
              for (var f = s.getChild().getNodes(), p = 0; p < f.length; p++) {
                var A = f[p];
                h += this.getNodeDegreeWithChildren(A);
              }
              return h;
            }, d.prototype.performDFSOnCompounds = function() {
              this.compoundOrder = [], this.fillCompexOrderByDFS(this.graphManager.getRoot().getNodes());
            }, d.prototype.fillCompexOrderByDFS = function(s) {
              for (var h = 0; h < s.length; h++) {
                var f = s[h];
                f.getChild() != null && this.fillCompexOrderByDFS(f.getChild().getNodes()), this.getToBeTiled(f) && this.compoundOrder.push(f);
              }
            }, d.prototype.adjustLocations = function(s, h, f, p, A) {
              h += p, f += A;
              for (var I = h, R = 0; R < s.rows.length; R++) {
                var x = s.rows[R];
                h = I;
                for (var G = 0, U = 0; U < x.length; U++) {
                  var X = x[U];
                  X.rect.x = h, X.rect.y = f, h += X.rect.width + s.horizontalPadding, X.rect.height > G && (G = X.rect.height);
                }
                f += G + s.verticalPadding;
              }
            }, d.prototype.tileCompoundMembers = function(s, h) {
              var f = this;
              this.tiledMemberPack = [], Object.keys(s).forEach(function(p) {
                var A = h[p];
                f.tiledMemberPack[p] = f.tileNodes(s[p], A.paddingLeft + A.paddingRight), A.rect.width = f.tiledMemberPack[p].width, A.rect.height = f.tiledMemberPack[p].height;
              });
            }, d.prototype.tileNodes = function(s, h) {
              var f = a.TILING_PADDING_VERTICAL, p = a.TILING_PADDING_HORIZONTAL, A = {
                rows: [],
                rowWidth: [],
                rowHeight: [],
                width: 0,
                height: h,
                // assume minHeight equals to minWidth
                verticalPadding: f,
                horizontalPadding: p
              };
              s.sort(function(x, G) {
                return x.rect.width * x.rect.height > G.rect.width * G.rect.height ? -1 : x.rect.width * x.rect.height < G.rect.width * G.rect.height ? 1 : 0;
              });
              for (var I = 0; I < s.length; I++) {
                var R = s[I];
                A.rows.length == 0 ? this.insertNodeToRow(A, R, 0, h) : this.canAddHorizontal(A, R.rect.width, R.rect.height) ? this.insertNodeToRow(A, R, this.getShortestRowIndex(A), h) : this.insertNodeToRow(A, R, A.rows.length, h), this.shiftToLastRow(A);
              }
              return A;
            }, d.prototype.insertNodeToRow = function(s, h, f, p) {
              var A = p;
              if (f == s.rows.length) {
                var I = [];
                s.rows.push(I), s.rowWidth.push(A), s.rowHeight.push(0);
              }
              var R = s.rowWidth[f] + h.rect.width;
              s.rows[f].length > 0 && (R += s.horizontalPadding), s.rowWidth[f] = R, s.width < R && (s.width = R);
              var x = h.rect.height;
              f > 0 && (x += s.verticalPadding);
              var G = 0;
              x > s.rowHeight[f] && (G = s.rowHeight[f], s.rowHeight[f] = x, G = s.rowHeight[f] - G), s.height += G, s.rows[f].push(h);
            }, d.prototype.getShortestRowIndex = function(s) {
              for (var h = -1, f = Number.MAX_VALUE, p = 0; p < s.rows.length; p++)
                s.rowWidth[p] < f && (h = p, f = s.rowWidth[p]);
              return h;
            }, d.prototype.getLongestRowIndex = function(s) {
              for (var h = -1, f = Number.MIN_VALUE, p = 0; p < s.rows.length; p++)
                s.rowWidth[p] > f && (h = p, f = s.rowWidth[p]);
              return h;
            }, d.prototype.canAddHorizontal = function(s, h, f) {
              var p = this.getShortestRowIndex(s);
              if (p < 0)
                return !0;
              var A = s.rowWidth[p];
              if (A + s.horizontalPadding + h <= s.width) return !0;
              var I = 0;
              s.rowHeight[p] < f && p > 0 && (I = f + s.verticalPadding - s.rowHeight[p]);
              var R;
              s.width - A >= h + s.horizontalPadding ? R = (s.height + I) / (A + h + s.horizontalPadding) : R = (s.height + I) / s.width, I = f + s.verticalPadding;
              var x;
              return s.width < h ? x = (s.height + I) / h : x = (s.height + I) / s.width, x < 1 && (x = 1 / x), R < 1 && (R = 1 / R), R < x;
            }, d.prototype.shiftToLastRow = function(s) {
              var h = this.getLongestRowIndex(s), f = s.rowWidth.length - 1, p = s.rows[h], A = p[p.length - 1], I = A.width + s.horizontalPadding;
              if (s.width - s.rowWidth[f] > I && h != f) {
                p.splice(-1, 1), s.rows[f].push(A), s.rowWidth[h] = s.rowWidth[h] - I, s.rowWidth[f] = s.rowWidth[f] + I, s.width = s.rowWidth[instance.getLongestRowIndex(s)];
                for (var R = Number.MIN_VALUE, x = 0; x < p.length; x++)
                  p[x].height > R && (R = p[x].height);
                h > 0 && (R += s.verticalPadding);
                var G = s.rowHeight[h] + s.rowHeight[f];
                s.rowHeight[h] = R, s.rowHeight[f] < A.height + s.verticalPadding && (s.rowHeight[f] = A.height + s.verticalPadding);
                var U = s.rowHeight[h] + s.rowHeight[f];
                s.height += U - G, this.shiftToLastRow(s);
              }
            }, d.prototype.tilingPreLayout = function() {
              a.TILE && (this.groupZeroDegreeMembers(), this.clearCompounds(), this.clearZeroDegreeMembers());
            }, d.prototype.tilingPostLayout = function() {
              a.TILE && (this.repopulateZeroDegreeMembers(), this.repopulateCompounds());
            }, d.prototype.reduceTrees = function() {
              for (var s = [], h = !0, f; h; ) {
                var p = this.graphManager.getAllNodes(), A = [];
                h = !1;
                for (var I = 0; I < p.length; I++)
                  f = p[I], f.getEdges().length == 1 && !f.getEdges()[0].isInterGraph && f.getChild() == null && (A.push([f, f.getEdges()[0], f.getOwner()]), h = !0);
                if (h == !0) {
                  for (var R = [], x = 0; x < A.length; x++)
                    A[x][0].getEdges().length == 1 && (R.push(A[x]), A[x][0].getOwner().remove(A[x][0]));
                  s.push(R), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                }
              }
              this.prunedNodesAll = s;
            }, d.prototype.growTree = function(s) {
              for (var h = s.length, f = s[h - 1], p, A = 0; A < f.length; A++)
                p = f[A], this.findPlaceforPrunedNode(p), p[2].add(p[0]), p[2].add(p[1], p[1].source, p[1].target);
              s.splice(s.length - 1, 1), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
            }, d.prototype.findPlaceforPrunedNode = function(s) {
              var h, f, p = s[0];
              p == s[1].source ? f = s[1].target : f = s[1].source;
              var A = f.startX, I = f.finishX, R = f.startY, x = f.finishY, G = 0, U = 0, X = 0, w = 0, S = [G, X, U, w];
              if (R > 0)
                for (var F = A; F <= I; F++)
                  S[0] += this.grid[F][R - 1].length + this.grid[F][R].length - 1;
              if (I < this.grid.length - 1)
                for (var F = R; F <= x; F++)
                  S[1] += this.grid[I + 1][F].length + this.grid[I][F].length - 1;
              if (x < this.grid[0].length - 1)
                for (var F = A; F <= I; F++)
                  S[2] += this.grid[F][x + 1].length + this.grid[F][x].length - 1;
              if (A > 0)
                for (var F = R; F <= x; F++)
                  S[3] += this.grid[A - 1][F].length + this.grid[A][F].length - 1;
              for (var b = T.MAX_VALUE, Y, k, H = 0; H < S.length; H++)
                S[H] < b ? (b = S[H], Y = 1, k = H) : S[H] == b && Y++;
              if (Y == 3 && b == 0)
                S[0] == 0 && S[1] == 0 && S[2] == 0 ? h = 1 : S[0] == 0 && S[1] == 0 && S[3] == 0 ? h = 0 : S[0] == 0 && S[2] == 0 && S[3] == 0 ? h = 3 : S[1] == 0 && S[2] == 0 && S[3] == 0 && (h = 2);
              else if (Y == 2 && b == 0) {
                var P = Math.floor(Math.random() * 2);
                S[0] == 0 && S[1] == 0 ? P == 0 ? h = 0 : h = 1 : S[0] == 0 && S[2] == 0 ? P == 0 ? h = 0 : h = 2 : S[0] == 0 && S[3] == 0 ? P == 0 ? h = 0 : h = 3 : S[1] == 0 && S[2] == 0 ? P == 0 ? h = 1 : h = 2 : S[1] == 0 && S[3] == 0 ? P == 0 ? h = 1 : h = 3 : P == 0 ? h = 2 : h = 3;
              } else if (Y == 4 && b == 0) {
                var P = Math.floor(Math.random() * 4);
                h = P;
              } else
                h = k;
              h == 0 ? p.setCenter(f.getCenterX(), f.getCenterY() - f.getHeight() / 2 - v.DEFAULT_EDGE_LENGTH - p.getHeight() / 2) : h == 1 ? p.setCenter(f.getCenterX() + f.getWidth() / 2 + v.DEFAULT_EDGE_LENGTH + p.getWidth() / 2, f.getCenterY()) : h == 2 ? p.setCenter(f.getCenterX(), f.getCenterY() + f.getHeight() / 2 + v.DEFAULT_EDGE_LENGTH + p.getHeight() / 2) : p.setCenter(f.getCenterX() - f.getWidth() / 2 - v.DEFAULT_EDGE_LENGTH - p.getWidth() / 2, f.getCenterY());
            }, D.exports = d;
          },
          /* 7 */
          /***/
          function(D, y, r) {
            var t = {};
            t.layoutBase = r(0), t.CoSEConstants = r(1), t.CoSEEdge = r(2), t.CoSEGraph = r(3), t.CoSEGraphManager = r(4), t.CoSELayout = r(6), t.CoSENode = r(5), D.exports = t;
          }
          /******/
        ])
      );
    });
  }(rt)), rt.exports;
}
(function(C, M) {
  (function(D, y) {
    C.exports = y(Rt());
  })(at, function(u) {
    return (
      /******/
      function(D) {
        var y = {};
        function r(t) {
          if (y[t])
            return y[t].exports;
          var e = y[t] = {
            /******/
            i: t,
            /******/
            l: !1,
            /******/
            exports: {}
            /******/
          };
          return D[t].call(e.exports, e, e.exports, r), e.l = !0, e.exports;
        }
        return r.m = D, r.c = y, r.i = function(t) {
          return t;
        }, r.d = function(t, e, i) {
          r.o(t, e) || Object.defineProperty(t, e, {
            /******/
            configurable: !1,
            /******/
            enumerable: !0,
            /******/
            get: i
            /******/
          });
        }, r.n = function(t) {
          var e = t && t.__esModule ? (
            /******/
            function() {
              return t.default;
            }
          ) : (
            /******/
            function() {
              return t;
            }
          );
          return r.d(e, "a", e), e;
        }, r.o = function(t, e) {
          return Object.prototype.hasOwnProperty.call(t, e);
        }, r.p = "", r(r.s = 1);
      }([
        /* 0 */
        /***/
        function(D, y) {
          D.exports = u;
        },
        /* 1 */
        /***/
        function(D, y, r) {
          var t = r(0).layoutBase.LayoutConstants, e = r(0).layoutBase.FDLayoutConstants, i = r(0).CoSEConstants, o = r(0).CoSELayout, g = r(0).CoSENode, a = r(0).layoutBase.PointD, v = r(0).layoutBase.DimensionD, n = {
            // Called on `layoutready`
            ready: function() {
            },
            // Called on `layoutstop`
            stop: function() {
            },
            // 'draft', 'default' or 'proof" 
            // - 'draft' fast cooling rate 
            // - 'default' moderate cooling rate 
            // - "proof" slow cooling rate
            quality: "default",
            // include labels in node dimensions
            nodeDimensionsIncludeLabels: !1,
            // number of ticks per frame; higher is faster but more jerky
            refresh: 30,
            // Whether to fit the network view after when done
            fit: !0,
            // Padding on fit
            padding: 10,
            // Whether to enable incremental mode
            randomize: !0,
            // Node repulsion (non overlapping) multiplier
            nodeRepulsion: 4500,
            // Ideal edge (non nested) length
            idealEdgeLength: 50,
            // Divisor to compute edge forces
            edgeElasticity: 0.45,
            // Nesting factor (multiplier) to compute ideal edge length for nested edges
            nestingFactor: 0.1,
            // Gravity force (constant)
            gravity: 0.25,
            // Maximum number of iterations to perform
            numIter: 2500,
            // For enabling tiling
            tile: !0,
            // Type of layout animation. The option set is {'during', 'end', false}
            animate: "end",
            // Duration for animate:end
            animationDuration: 500,
            // Represents the amount of the vertical space to put between the zero degree members during the tiling operation(can also be a function)
            tilingPaddingVertical: 10,
            // Represents the amount of the horizontal space to put between the zero degree members during the tiling operation(can also be a function)
            tilingPaddingHorizontal: 10,
            // Gravity range (constant) for compounds
            gravityRangeCompound: 1.5,
            // Gravity force (constant) for compounds
            gravityCompound: 1,
            // Gravity range (constant)
            gravityRange: 3.8,
            // Initial cooling factor for incremental layout
            initialEnergyOnIncremental: 0.5
          };
          function c(m, L) {
            var O = {};
            for (var d in m)
              O[d] = m[d];
            for (var d in L)
              O[d] = L[d];
            return O;
          }
          function l(m) {
            this.options = c(n, m), E(this.options);
          }
          var E = function(L) {
            L.nodeRepulsion != null && (i.DEFAULT_REPULSION_STRENGTH = e.DEFAULT_REPULSION_STRENGTH = L.nodeRepulsion), L.idealEdgeLength != null && (i.DEFAULT_EDGE_LENGTH = e.DEFAULT_EDGE_LENGTH = L.idealEdgeLength), L.edgeElasticity != null && (i.DEFAULT_SPRING_STRENGTH = e.DEFAULT_SPRING_STRENGTH = L.edgeElasticity), L.nestingFactor != null && (i.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = e.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = L.nestingFactor), L.gravity != null && (i.DEFAULT_GRAVITY_STRENGTH = e.DEFAULT_GRAVITY_STRENGTH = L.gravity), L.numIter != null && (i.MAX_ITERATIONS = e.MAX_ITERATIONS = L.numIter), L.gravityRange != null && (i.DEFAULT_GRAVITY_RANGE_FACTOR = e.DEFAULT_GRAVITY_RANGE_FACTOR = L.gravityRange), L.gravityCompound != null && (i.DEFAULT_COMPOUND_GRAVITY_STRENGTH = e.DEFAULT_COMPOUND_GRAVITY_STRENGTH = L.gravityCompound), L.gravityRangeCompound != null && (i.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = e.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = L.gravityRangeCompound), L.initialEnergyOnIncremental != null && (i.DEFAULT_COOLING_FACTOR_INCREMENTAL = e.DEFAULT_COOLING_FACTOR_INCREMENTAL = L.initialEnergyOnIncremental), L.quality == "draft" ? t.QUALITY = 0 : L.quality == "proof" ? t.QUALITY = 2 : t.QUALITY = 1, i.NODE_DIMENSIONS_INCLUDE_LABELS = e.NODE_DIMENSIONS_INCLUDE_LABELS = t.NODE_DIMENSIONS_INCLUDE_LABELS = L.nodeDimensionsIncludeLabels, i.DEFAULT_INCREMENTAL = e.DEFAULT_INCREMENTAL = t.DEFAULT_INCREMENTAL = !L.randomize, i.ANIMATE = e.ANIMATE = t.ANIMATE = L.animate, i.TILE = L.tile, i.TILING_PADDING_VERTICAL = typeof L.tilingPaddingVertical == "function" ? L.tilingPaddingVertical.call() : L.tilingPaddingVertical, i.TILING_PADDING_HORIZONTAL = typeof L.tilingPaddingHorizontal == "function" ? L.tilingPaddingHorizontal.call() : L.tilingPaddingHorizontal;
          };
          l.prototype.run = function() {
            var m, L, O = this.options;
            this.idToLNode = {};
            var d = this.layout = new o(), N = this;
            N.stopped = !1, this.cy = this.options.cy, this.cy.trigger({ type: "layoutstart", layout: this });
            var s = d.newGraphManager();
            this.gm = s;
            var h = this.options.eles.nodes(), f = this.options.eles.edges();
            this.root = s.addRoot(), this.processChildrenList(this.root, this.getTopMostNodes(h), d);
            for (var p = 0; p < f.length; p++) {
              var A = f[p], I = this.idToLNode[A.data("source")], R = this.idToLNode[A.data("target")];
              if (I !== R && I.getEdgesBetween(R).length == 0) {
                var x = s.add(d.newEdge(), I, R);
                x.id = A.id();
              }
            }
            var G = function(w, S) {
              typeof w == "number" && (w = S);
              var F = w.data("id"), b = N.idToLNode[F];
              return {
                x: b.getRect().getCenterX(),
                y: b.getRect().getCenterY()
              };
            }, U = function X() {
              for (var w = function() {
                O.fit && O.cy.fit(O.eles, O.padding), m || (m = !0, N.cy.one("layoutready", O.ready), N.cy.trigger({ type: "layoutready", layout: N }));
              }, S = N.options.refresh, F, b = 0; b < S && !F; b++)
                F = N.stopped || N.layout.tick();
              if (F) {
                d.checkLayoutSuccess() && !d.isSubLayout && d.doPostLayout(), d.tilingPostLayout && d.tilingPostLayout(), d.isLayoutFinished = !0, N.options.eles.nodes().positions(G), w(), N.cy.one("layoutstop", N.options.stop), N.cy.trigger({ type: "layoutstop", layout: N }), L && cancelAnimationFrame(L), m = !1;
                return;
              }
              var Y = N.layout.getPositionsData();
              O.eles.nodes().positions(function(k, H) {
                if (typeof k == "number" && (k = H), !k.isParent()) {
                  for (var P = k.id(), W = Y[P], $ = k; W == null && (W = Y[$.data("parent")] || Y["DummyCompound_" + $.data("parent")], Y[P] = W, $ = $.parent()[0], $ != null); )
                    ;
                  return W != null ? {
                    x: W.x,
                    y: W.y
                  } : {
                    x: k.position("x"),
                    y: k.position("y")
                  };
                }
              }), w(), L = requestAnimationFrame(X);
            };
            return d.addListener("layoutstarted", function() {
              N.options.animate === "during" && (L = requestAnimationFrame(U));
            }), d.runLayout(), this.options.animate !== "during" && (N.options.eles.nodes().not(":parent").layoutPositions(N, N.options, G), m = !1), this;
          }, l.prototype.getTopMostNodes = function(m) {
            for (var L = {}, O = 0; O < m.length; O++)
              L[m[O].id()] = !0;
            var d = m.filter(function(N, s) {
              typeof N == "number" && (N = s);
              for (var h = N.parent()[0]; h != null; ) {
                if (L[h.id()])
                  return !1;
                h = h.parent()[0];
              }
              return !0;
            });
            return d;
          }, l.prototype.processChildrenList = function(m, L, O) {
            for (var d = L.length, N = 0; N < d; N++) {
              var s = L[N], h = s.children(), f, p = s.layoutDimensions({
                nodeDimensionsIncludeLabels: this.options.nodeDimensionsIncludeLabels
              });
              if (s.outerWidth() != null && s.outerHeight() != null ? f = m.add(new g(O.graphManager, new a(s.position("x") - p.w / 2, s.position("y") - p.h / 2), new v(parseFloat(p.w), parseFloat(p.h)))) : f = m.add(new g(this.graphManager)), f.id = s.data("id"), f.paddingLeft = parseInt(s.css("padding")), f.paddingTop = parseInt(s.css("padding")), f.paddingRight = parseInt(s.css("padding")), f.paddingBottom = parseInt(s.css("padding")), this.options.nodeDimensionsIncludeLabels && s.isParent()) {
                var A = s.boundingBox({ includeLabels: !0, includeNodes: !1 }).w, I = s.boundingBox({ includeLabels: !0, includeNodes: !1 }).h, R = s.css("text-halign");
                f.labelWidth = A, f.labelHeight = I, f.labelPos = R;
              }
              if (this.idToLNode[s.data("id")] = f, isNaN(f.rect.x) && (f.rect.x = 0), isNaN(f.rect.y) && (f.rect.y = 0), h != null && h.length > 0) {
                var x;
                x = O.getGraphManager().add(O.newGraph(), f), this.processChildrenList(x, h, O);
              }
            }
          }, l.prototype.stop = function() {
            return this.stopped = !0, this;
          };
          var T = function(L) {
            L("layout", "cose-bilkent", l);
          };
          typeof cytoscape < "u" && T(cytoscape), D.exports = T;
        }
        /******/
      ])
    );
  });
})(ft);
var xt = ft.exports;
const Mt = /* @__PURE__ */ It(xt);
var st = function() {
  var C = /* @__PURE__ */ _(function(O, d, N, s) {
    for (N = N || {}, s = O.length; s--; N[O[s]] = d) ;
    return N;
  }, "o"), M = [1, 4], u = [1, 13], D = [1, 12], y = [1, 15], r = [1, 16], t = [1, 20], e = [1, 19], i = [6, 7, 8], o = [1, 26], g = [1, 24], a = [1, 25], v = [6, 7, 11], n = [1, 6, 13, 15, 16, 19, 22], c = [1, 33], l = [1, 34], E = [1, 6, 7, 11, 13, 15, 16, 19, 22], T = {
    trace: /* @__PURE__ */ _(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, mindMap: 4, spaceLines: 5, SPACELINE: 6, NL: 7, MINDMAP: 8, document: 9, stop: 10, EOF: 11, statement: 12, SPACELIST: 13, node: 14, ICON: 15, CLASS: 16, nodeWithId: 17, nodeWithoutId: 18, NODE_DSTART: 19, NODE_DESCR: 20, NODE_DEND: 21, NODE_ID: 22, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 6: "SPACELINE", 7: "NL", 8: "MINDMAP", 11: "EOF", 13: "SPACELIST", 15: "ICON", 16: "CLASS", 19: "NODE_DSTART", 20: "NODE_DESCR", 21: "NODE_DEND", 22: "NODE_ID" },
    productions_: [0, [3, 1], [3, 2], [5, 1], [5, 2], [5, 2], [4, 2], [4, 3], [10, 1], [10, 1], [10, 1], [10, 2], [10, 2], [9, 3], [9, 2], [12, 2], [12, 2], [12, 2], [12, 1], [12, 1], [12, 1], [12, 1], [12, 1], [14, 1], [14, 1], [18, 3], [17, 1], [17, 4]],
    performAction: /* @__PURE__ */ _(function(d, N, s, h, f, p, A) {
      var I = p.length - 1;
      switch (f) {
        case 6:
        case 7:
          return h;
        case 8:
          h.getLogger().trace("Stop NL ");
          break;
        case 9:
          h.getLogger().trace("Stop EOF ");
          break;
        case 11:
          h.getLogger().trace("Stop NL2 ");
          break;
        case 12:
          h.getLogger().trace("Stop EOF2 ");
          break;
        case 15:
          h.getLogger().info("Node: ", p[I].id), h.addNode(p[I - 1].length, p[I].id, p[I].descr, p[I].type);
          break;
        case 16:
          h.getLogger().trace("Icon: ", p[I]), h.decorateNode({ icon: p[I] });
          break;
        case 17:
        case 21:
          h.decorateNode({ class: p[I] });
          break;
        case 18:
          h.getLogger().trace("SPACELIST");
          break;
        case 19:
          h.getLogger().trace("Node: ", p[I].id), h.addNode(0, p[I].id, p[I].descr, p[I].type);
          break;
        case 20:
          h.decorateNode({ icon: p[I] });
          break;
        case 25:
          h.getLogger().trace("node found ..", p[I - 2]), this.$ = { id: p[I - 1], descr: p[I - 1], type: h.getType(p[I - 2], p[I]) };
          break;
        case 26:
          this.$ = { id: p[I], descr: p[I], type: h.nodeType.DEFAULT };
          break;
        case 27:
          h.getLogger().trace("node found ..", p[I - 3]), this.$ = { id: p[I - 3], descr: p[I - 1], type: h.getType(p[I - 2], p[I]) };
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: 2, 5: 3, 6: [1, 5], 8: M }, { 1: [3] }, { 1: [2, 1] }, { 4: 6, 6: [1, 7], 7: [1, 8], 8: M }, { 6: u, 7: [1, 10], 9: 9, 12: 11, 13: D, 14: 14, 15: y, 16: r, 17: 17, 18: 18, 19: t, 22: e }, C(i, [2, 3]), { 1: [2, 2] }, C(i, [2, 4]), C(i, [2, 5]), { 1: [2, 6], 6: u, 12: 21, 13: D, 14: 14, 15: y, 16: r, 17: 17, 18: 18, 19: t, 22: e }, { 6: u, 9: 22, 12: 11, 13: D, 14: 14, 15: y, 16: r, 17: 17, 18: 18, 19: t, 22: e }, { 6: o, 7: g, 10: 23, 11: a }, C(v, [2, 22], { 17: 17, 18: 18, 14: 27, 15: [1, 28], 16: [1, 29], 19: t, 22: e }), C(v, [2, 18]), C(v, [2, 19]), C(v, [2, 20]), C(v, [2, 21]), C(v, [2, 23]), C(v, [2, 24]), C(v, [2, 26], { 19: [1, 30] }), { 20: [1, 31] }, { 6: o, 7: g, 10: 32, 11: a }, { 1: [2, 7], 6: u, 12: 21, 13: D, 14: 14, 15: y, 16: r, 17: 17, 18: 18, 19: t, 22: e }, C(n, [2, 14], { 7: c, 11: l }), C(E, [2, 8]), C(E, [2, 9]), C(E, [2, 10]), C(v, [2, 15]), C(v, [2, 16]), C(v, [2, 17]), { 20: [1, 35] }, { 21: [1, 36] }, C(n, [2, 13], { 7: c, 11: l }), C(E, [2, 11]), C(E, [2, 12]), { 21: [1, 37] }, C(v, [2, 25]), C(v, [2, 27])],
    defaultActions: { 2: [2, 1], 6: [2, 2] },
    parseError: /* @__PURE__ */ _(function(d, N) {
      if (N.recoverable)
        this.trace(d);
      else {
        var s = new Error(d);
        throw s.hash = N, s;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ _(function(d) {
      var N = this, s = [0], h = [], f = [null], p = [], A = this.table, I = "", R = 0, x = 0, G = 2, U = 1, X = p.slice.call(arguments, 1), w = Object.create(this.lexer), S = { yy: {} };
      for (var F in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, F) && (S.yy[F] = this.yy[F]);
      w.setInput(d, S.yy), S.yy.lexer = w, S.yy.parser = this, typeof w.yylloc > "u" && (w.yylloc = {});
      var b = w.yylloc;
      p.push(b);
      var Y = w.options && w.options.ranges;
      typeof S.yy.parseError == "function" ? this.parseError = S.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function k(B) {
        s.length = s.length - 2 * B, f.length = f.length - B, p.length = p.length - B;
      }
      _(k, "popStack");
      function H() {
        var B;
        return B = h.pop() || w.lex() || U, typeof B != "number" && (B instanceof Array && (h = B, B = h.pop()), B = N.symbols_[B] || B), B;
      }
      _(H, "lex");
      for (var P, W, $, j, V = {}, z, Z, lt, J; ; ) {
        if (W = s[s.length - 1], this.defaultActions[W] ? $ = this.defaultActions[W] : ((P === null || typeof P > "u") && (P = H()), $ = A[W] && A[W][P]), typeof $ > "u" || !$.length || !$[0]) {
          var et = "";
          J = [];
          for (z in A[W])
            this.terminals_[z] && z > G && J.push("'" + this.terminals_[z] + "'");
          w.showPosition ? et = "Parse error on line " + (R + 1) + `:
` + w.showPosition() + `
Expecting ` + J.join(", ") + ", got '" + (this.terminals_[P] || P) + "'" : et = "Parse error on line " + (R + 1) + ": Unexpected " + (P == U ? "end of input" : "'" + (this.terminals_[P] || P) + "'"), this.parseError(et, {
            text: w.match,
            token: this.terminals_[P] || P,
            line: w.yylineno,
            loc: b,
            expected: J
          });
        }
        if ($[0] instanceof Array && $.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + W + ", token: " + P);
        switch ($[0]) {
          case 1:
            s.push(P), f.push(w.yytext), p.push(w.yylloc), s.push($[1]), P = null, x = w.yyleng, I = w.yytext, R = w.yylineno, b = w.yylloc;
            break;
          case 2:
            if (Z = this.productions_[$[1]][1], V.$ = f[f.length - Z], V._$ = {
              first_line: p[p.length - (Z || 1)].first_line,
              last_line: p[p.length - 1].last_line,
              first_column: p[p.length - (Z || 1)].first_column,
              last_column: p[p.length - 1].last_column
            }, Y && (V._$.range = [
              p[p.length - (Z || 1)].range[0],
              p[p.length - 1].range[1]
            ]), j = this.performAction.apply(V, [
              I,
              x,
              R,
              S.yy,
              $[1],
              f,
              p
            ].concat(X)), typeof j < "u")
              return j;
            Z && (s = s.slice(0, -1 * Z * 2), f = f.slice(0, -1 * Z), p = p.slice(0, -1 * Z)), s.push(this.productions_[$[1]][0]), f.push(V.$), p.push(V._$), lt = A[s[s.length - 2]][s[s.length - 1]], s.push(lt);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, m = /* @__PURE__ */ function() {
    var O = {
      EOF: 1,
      parseError: /* @__PURE__ */ _(function(N, s) {
        if (this.yy.parser)
          this.yy.parser.parseError(N, s);
        else
          throw new Error(N);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ _(function(d, N) {
        return this.yy = N || this.yy || {}, this._input = d, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ _(function() {
        var d = this._input[0];
        this.yytext += d, this.yyleng++, this.offset++, this.match += d, this.matched += d;
        var N = d.match(/(?:\r\n?|\n).*/g);
        return N ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), d;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ _(function(d) {
        var N = d.length, s = d.split(/(?:\r\n?|\n)/g);
        this._input = d + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - N), this.offset -= N;
        var h = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), s.length - 1 && (this.yylineno -= s.length - 1);
        var f = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: s ? (s.length === h.length ? this.yylloc.first_column : 0) + h[h.length - s.length].length - s[0].length : this.yylloc.first_column - N
        }, this.options.ranges && (this.yylloc.range = [f[0], f[0] + this.yyleng - N]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ _(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ _(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ _(function(d) {
        this.unput(this.match.slice(d));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ _(function() {
        var d = this.matched.substr(0, this.matched.length - this.match.length);
        return (d.length > 20 ? "..." : "") + d.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ _(function() {
        var d = this.match;
        return d.length < 20 && (d += this._input.substr(0, 20 - d.length)), (d.substr(0, 20) + (d.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ _(function() {
        var d = this.pastInput(), N = new Array(d.length + 1).join("-");
        return d + this.upcomingInput() + `
` + N + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ _(function(d, N) {
        var s, h, f;
        if (this.options.backtrack_lexer && (f = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (f.yylloc.range = this.yylloc.range.slice(0))), h = d[0].match(/(?:\r\n?|\n).*/g), h && (this.yylineno += h.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: h ? h[h.length - 1].length - h[h.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + d[0].length
        }, this.yytext += d[0], this.match += d[0], this.matches = d, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(d[0].length), this.matched += d[0], s = this.performAction.call(this, this.yy, this, N, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), s)
          return s;
        if (this._backtrack) {
          for (var p in f)
            this[p] = f[p];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ _(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var d, N, s, h;
        this._more || (this.yytext = "", this.match = "");
        for (var f = this._currentRules(), p = 0; p < f.length; p++)
          if (s = this._input.match(this.rules[f[p]]), s && (!N || s[0].length > N[0].length)) {
            if (N = s, h = p, this.options.backtrack_lexer) {
              if (d = this.test_match(s, f[p]), d !== !1)
                return d;
              if (this._backtrack) {
                N = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return N ? (d = this.test_match(N, f[h]), d !== !1 ? d : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ _(function() {
        var N = this.next();
        return N || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ _(function(N) {
        this.conditionStack.push(N);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ _(function() {
        var N = this.conditionStack.length - 1;
        return N > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ _(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ _(function(N) {
        return N = this.conditionStack.length - 1 - Math.abs(N || 0), N >= 0 ? this.conditionStack[N] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ _(function(N) {
        this.begin(N);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ _(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ _(function(N, s, h, f) {
        switch (h) {
          case 0:
            return N.getLogger().trace("Found comment", s.yytext), 6;
          case 1:
            return 8;
          case 2:
            this.begin("CLASS");
            break;
          case 3:
            return this.popState(), 16;
          case 4:
            this.popState();
            break;
          case 5:
            N.getLogger().trace("Begin icon"), this.begin("ICON");
            break;
          case 6:
            return N.getLogger().trace("SPACELINE"), 6;
          case 7:
            return 7;
          case 8:
            return 15;
          case 9:
            N.getLogger().trace("end icon"), this.popState();
            break;
          case 10:
            return N.getLogger().trace("Exploding node"), this.begin("NODE"), 19;
          case 11:
            return N.getLogger().trace("Cloud"), this.begin("NODE"), 19;
          case 12:
            return N.getLogger().trace("Explosion Bang"), this.begin("NODE"), 19;
          case 13:
            return N.getLogger().trace("Cloud Bang"), this.begin("NODE"), 19;
          case 14:
            return this.begin("NODE"), 19;
          case 15:
            return this.begin("NODE"), 19;
          case 16:
            return this.begin("NODE"), 19;
          case 17:
            return this.begin("NODE"), 19;
          case 18:
            return 13;
          case 19:
            return 22;
          case 20:
            return 11;
          case 21:
            this.begin("NSTR2");
            break;
          case 22:
            return "NODE_DESCR";
          case 23:
            this.popState();
            break;
          case 24:
            N.getLogger().trace("Starting NSTR"), this.begin("NSTR");
            break;
          case 25:
            return N.getLogger().trace("description:", s.yytext), "NODE_DESCR";
          case 26:
            this.popState();
            break;
          case 27:
            return this.popState(), N.getLogger().trace("node end ))"), "NODE_DEND";
          case 28:
            return this.popState(), N.getLogger().trace("node end )"), "NODE_DEND";
          case 29:
            return this.popState(), N.getLogger().trace("node end ...", s.yytext), "NODE_DEND";
          case 30:
            return this.popState(), N.getLogger().trace("node end (("), "NODE_DEND";
          case 31:
            return this.popState(), N.getLogger().trace("node end (-"), "NODE_DEND";
          case 32:
            return this.popState(), N.getLogger().trace("node end (-"), "NODE_DEND";
          case 33:
            return this.popState(), N.getLogger().trace("node end (("), "NODE_DEND";
          case 34:
            return this.popState(), N.getLogger().trace("node end (("), "NODE_DEND";
          case 35:
            return N.getLogger().trace("Long description:", s.yytext), 20;
          case 36:
            return N.getLogger().trace("Long description:", s.yytext), 20;
        }
      }, "anonymous"),
      rules: [/^(?:\s*%%.*)/i, /^(?:mindmap\b)/i, /^(?::::)/i, /^(?:.+)/i, /^(?:\n)/i, /^(?:::icon\()/i, /^(?:[\s]+[\n])/i, /^(?:[\n]+)/i, /^(?:[^\)]+)/i, /^(?:\))/i, /^(?:-\))/i, /^(?:\(-)/i, /^(?:\)\))/i, /^(?:\))/i, /^(?:\(\()/i, /^(?:\{\{)/i, /^(?:\()/i, /^(?:\[)/i, /^(?:[\s]+)/i, /^(?:[^\(\[\n\)\{\}]+)/i, /^(?:$)/i, /^(?:["][`])/i, /^(?:[^`"]+)/i, /^(?:[`]["])/i, /^(?:["])/i, /^(?:[^"]+)/i, /^(?:["])/i, /^(?:[\)]\))/i, /^(?:[\)])/i, /^(?:[\]])/i, /^(?:\}\})/i, /^(?:\(-)/i, /^(?:-\))/i, /^(?:\(\()/i, /^(?:\()/i, /^(?:[^\)\]\(\}]+)/i, /^(?:.+(?!\(\())/i],
      conditions: { CLASS: { rules: [3, 4], inclusive: !1 }, ICON: { rules: [8, 9], inclusive: !1 }, NSTR2: { rules: [22, 23], inclusive: !1 }, NSTR: { rules: [25, 26], inclusive: !1 }, NODE: { rules: [21, 24, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], inclusive: !0 } }
    };
    return O;
  }();
  T.lexer = m;
  function L() {
    this.yy = {};
  }
  return _(L, "Parser"), L.prototype = T, T.Parser = L, new L();
}();
st.parser = st;
var wt = st, St = {
  DEFAULT: 0,
  NO_BORDER: 0,
  ROUNDED_RECT: 1,
  RECT: 2,
  CIRCLE: 3,
  CLOUD: 4,
  BANG: 5,
  HEXAGON: 6
}, K, Gt = (K = class {
  constructor() {
    this.nodes = [], this.count = 0, this.elements = {}, this.getLogger = this.getLogger.bind(this), this.nodeType = St, this.clear(), this.getType = this.getType.bind(this), this.getMindmap = this.getMindmap.bind(this), this.getElementById = this.getElementById.bind(this), this.getParent = this.getParent.bind(this), this.getMindmap = this.getMindmap.bind(this), this.addNode = this.addNode.bind(this), this.decorateNode = this.decorateNode.bind(this);
  }
  clear() {
    this.nodes = [], this.count = 0, this.elements = {};
  }
  getParent(M) {
    for (let u = this.nodes.length - 1; u >= 0; u--)
      if (this.nodes[u].level < M)
        return this.nodes[u];
    return null;
  }
  getMindmap() {
    return this.nodes.length > 0 ? this.nodes[0] : null;
  }
  addNode(M, u, D, y) {
    var o, g;
    Q.info("addNode", M, u, D, y);
    const r = nt();
    let t = ((o = r.mindmap) == null ? void 0 : o.padding) ?? tt.mindmap.padding;
    switch (y) {
      case this.nodeType.ROUNDED_RECT:
      case this.nodeType.RECT:
      case this.nodeType.HEXAGON:
        t *= 2;
        break;
    }
    const e = {
      id: this.count++,
      nodeId: q(u, r),
      level: M,
      descr: q(D, r),
      type: y,
      children: [],
      width: ((g = r.mindmap) == null ? void 0 : g.maxNodeWidth) ?? tt.mindmap.maxNodeWidth,
      padding: t
    }, i = this.getParent(M);
    if (i)
      i.children.push(e), this.nodes.push(e);
    else if (this.nodes.length === 0)
      this.nodes.push(e);
    else
      throw new Error(
        `There can be only one root. No parent could be found for ("${e.descr}")`
      );
  }
  getType(M, u) {
    switch (Q.debug("In get type", M, u), M) {
      case "[":
        return this.nodeType.RECT;
      case "(":
        return u === ")" ? this.nodeType.ROUNDED_RECT : this.nodeType.CLOUD;
      case "((":
        return this.nodeType.CIRCLE;
      case ")":
        return this.nodeType.CLOUD;
      case "))":
        return this.nodeType.BANG;
      case "{{":
        return this.nodeType.HEXAGON;
      default:
        return this.nodeType.DEFAULT;
    }
  }
  setElementForId(M, u) {
    this.elements[M] = u;
  }
  getElementById(M) {
    return this.elements[M];
  }
  decorateNode(M) {
    if (!M)
      return;
    const u = nt(), D = this.nodes[this.nodes.length - 1];
    M.icon && (D.icon = q(M.icon, u)), M.class && (D.class = q(M.class, u));
  }
  type2Str(M) {
    switch (M) {
      case this.nodeType.DEFAULT:
        return "no-border";
      case this.nodeType.RECT:
        return "rect";
      case this.nodeType.ROUNDED_RECT:
        return "rounded-rect";
      case this.nodeType.CIRCLE:
        return "circle";
      case this.nodeType.CLOUD:
        return "cloud";
      case this.nodeType.BANG:
        return "bang";
      case this.nodeType.HEXAGON:
        return "hexgon";
      default:
        return "no-border";
    }
  }
  getLogger() {
    return Q;
  }
}, _(K, "MindmapDB"), K), _t = 12, Ft = /* @__PURE__ */ _(function(C, M, u, D) {
  M.append("path").attr("id", "node-" + u.id).attr("class", "node-bkg node-" + C.type2Str(u.type)).attr(
    "d",
    `M0 ${u.height - 5} v${-u.height + 2 * 5} q0,-5 5,-5 h${u.width - 2 * 5} q5,0 5,5 v${u.height - 5} H0 Z`
  ), M.append("line").attr("class", "node-line-" + D).attr("x1", 0).attr("y1", u.height).attr("x2", u.width).attr("y2", u.height);
}, "defaultBkg"), bt = /* @__PURE__ */ _(function(C, M, u) {
  M.append("rect").attr("id", "node-" + u.id).attr("class", "node-bkg node-" + C.type2Str(u.type)).attr("height", u.height).attr("width", u.width);
}, "rectBkg"), Ut = /* @__PURE__ */ _(function(C, M, u) {
  const D = u.width, y = u.height, r = 0.15 * D, t = 0.25 * D, e = 0.35 * D, i = 0.2 * D;
  M.append("path").attr("id", "node-" + u.id).attr("class", "node-bkg node-" + C.type2Str(u.type)).attr(
    "d",
    `M0 0 a${r},${r} 0 0,1 ${D * 0.25},${-1 * D * 0.1}
      a${e},${e} 1 0,1 ${D * 0.4},${-1 * D * 0.1}
      a${t},${t} 1 0,1 ${D * 0.35},${1 * D * 0.2}

      a${r},${r} 1 0,1 ${D * 0.15},${1 * y * 0.35}
      a${i},${i} 1 0,1 ${-1 * D * 0.15},${1 * y * 0.65}

      a${t},${r} 1 0,1 ${-1 * D * 0.25},${D * 0.15}
      a${e},${e} 1 0,1 ${-1 * D * 0.5},0
      a${r},${r} 1 0,1 ${-1 * D * 0.25},${-1 * D * 0.15}

      a${r},${r} 1 0,1 ${-1 * D * 0.1},${-1 * y * 0.35}
      a${i},${i} 1 0,1 ${D * 0.1},${-1 * y * 0.65}

    H0 V0 Z`
  );
}, "cloudBkg"), Pt = /* @__PURE__ */ _(function(C, M, u) {
  const D = u.width, y = u.height, r = 0.15 * D;
  M.append("path").attr("id", "node-" + u.id).attr("class", "node-bkg node-" + C.type2Str(u.type)).attr(
    "d",
    `M0 0 a${r},${r} 1 0,0 ${D * 0.25},${-1 * y * 0.1}
      a${r},${r} 1 0,0 ${D * 0.25},0
      a${r},${r} 1 0,0 ${D * 0.25},0
      a${r},${r} 1 0,0 ${D * 0.25},${1 * y * 0.1}

      a${r},${r} 1 0,0 ${D * 0.15},${1 * y * 0.33}
      a${r * 0.8},${r * 0.8} 1 0,0 0,${1 * y * 0.34}
      a${r},${r} 1 0,0 ${-1 * D * 0.15},${1 * y * 0.33}

      a${r},${r} 1 0,0 ${-1 * D * 0.25},${y * 0.15}
      a${r},${r} 1 0,0 ${-1 * D * 0.25},0
      a${r},${r} 1 0,0 ${-1 * D * 0.25},0
      a${r},${r} 1 0,0 ${-1 * D * 0.25},${-1 * y * 0.15}

      a${r},${r} 1 0,0 ${-1 * D * 0.1},${-1 * y * 0.33}
      a${r * 0.8},${r * 0.8} 1 0,0 0,${-1 * y * 0.34}
      a${r},${r} 1 0,0 ${D * 0.1},${-1 * y * 0.33}

    H0 V0 Z`
  );
}, "bangBkg"), Yt = /* @__PURE__ */ _(function(C, M, u) {
  M.append("circle").attr("id", "node-" + u.id).attr("class", "node-bkg node-" + C.type2Str(u.type)).attr("r", u.width / 2);
}, "circleBkg");
function pt(C, M, u, D, y) {
  return C.insert("polygon", ":first-child").attr(
    "points",
    D.map(function(r) {
      return r.x + "," + r.y;
    }).join(" ")
  ).attr("transform", "translate(" + (y.width - M) / 2 + ", " + u + ")");
}
_(pt, "insertPolygonShape");
var Xt = /* @__PURE__ */ _(function(C, M, u) {
  const D = u.height, r = D / 4, t = u.width - u.padding + 2 * r, e = [
    { x: r, y: 0 },
    { x: t - r, y: 0 },
    { x: t, y: -D / 2 },
    { x: t - r, y: -D },
    { x: r, y: -D },
    { x: 0, y: -D / 2 }
  ];
  pt(M, t, D, e, u);
}, "hexagonBkg"), kt = /* @__PURE__ */ _(function(C, M, u) {
  M.append("rect").attr("id", "node-" + u.id).attr("class", "node-bkg node-" + C.type2Str(u.type)).attr("height", u.height).attr("rx", u.padding).attr("ry", u.padding).attr("width", u.width);
}, "roundedRectBkg"), Ht = /* @__PURE__ */ _(async function(C, M, u, D, y) {
  const r = y.htmlLabels, t = D % (_t - 1), e = M.append("g");
  u.section = t;
  let i = "section-" + t;
  t < 0 && (i += " section-root"), e.attr("class", (u.class ? u.class + " " : "") + "mindmap-node " + i);
  const o = e.append("g"), g = e.append("g"), a = u.descr.replace(/(<br\/*>)/g, `
`);
  await Ot(
    g,
    a,
    {
      useHtmlLabels: r,
      width: u.width,
      classes: "mindmap-node-label"
    },
    y
  ), r || g.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle");
  const v = g.node().getBBox(), [n] = At(y.fontSize);
  if (u.height = v.height + n * 1.1 * 0.5 + u.padding, u.width = v.width + 2 * u.padding, u.icon)
    if (u.type === C.nodeType.CIRCLE)
      u.height += 50, u.width += 50, e.append("foreignObject").attr("height", "50px").attr("width", u.width).attr("style", "text-align: center;").append("div").attr("class", "icon-container").append("i").attr("class", "node-icon-" + t + " " + u.icon), g.attr(
        "transform",
        "translate(" + u.width / 2 + ", " + (u.height / 2 - 1.5 * u.padding) + ")"
      );
    else {
      u.width += 50;
      const c = u.height;
      u.height = Math.max(c, 60);
      const l = Math.abs(u.height - c);
      e.append("foreignObject").attr("width", "60px").attr("height", u.height).attr("style", "text-align: center;margin-top:" + l / 2 + "px;").append("div").attr("class", "icon-container").append("i").attr("class", "node-icon-" + t + " " + u.icon), g.attr(
        "transform",
        "translate(" + (25 + u.width / 2) + ", " + (l / 2 + u.padding / 2) + ")"
      );
    }
  else if (r) {
    const c = (u.width - v.width) / 2, l = (u.height - v.height) / 2;
    g.attr("transform", "translate(" + c + ", " + l + ")");
  } else {
    const c = u.width / 2, l = u.padding / 2;
    g.attr("transform", "translate(" + c + ", " + l + ")");
  }
  switch (u.type) {
    case C.nodeType.DEFAULT:
      Ft(C, o, u, t);
      break;
    case C.nodeType.ROUNDED_RECT:
      kt(C, o, u, t);
      break;
    case C.nodeType.RECT:
      bt(C, o, u, t);
      break;
    case C.nodeType.CIRCLE:
      o.attr("transform", "translate(" + u.width / 2 + ", " + +u.height / 2 + ")"), Yt(C, o, u, t);
      break;
    case C.nodeType.CLOUD:
      Ut(C, o, u, t);
      break;
    case C.nodeType.BANG:
      Pt(C, o, u, t);
      break;
    case C.nodeType.HEXAGON:
      Xt(C, o, u, t);
      break;
  }
  return C.setElementForId(u.id, e), u.height;
}, "drawNode"), $t = /* @__PURE__ */ _(function(C, M) {
  const u = C.getElementById(M.id), D = M.x || 0, y = M.y || 0;
  u.attr("transform", "translate(" + D + "," + y + ")");
}, "positionNode");
ut.use(Mt);
async function ot(C, M, u, D, y) {
  await Ht(C, M, u, D, y), u.children && await Promise.all(
    u.children.map(
      (r, t) => ot(C, M, r, D < 0 ? t : D, y)
    )
  );
}
_(ot, "drawNodes");
function dt(C, M) {
  M.edges().map((u, D) => {
    const y = u.data();
    if (u[0]._private.bodyBounds) {
      const r = u[0]._private.rscratch;
      Q.trace("Edge: ", D, y), C.insert("path").attr(
        "d",
        `M ${r.startX},${r.startY} L ${r.midX},${r.midY} L${r.endX},${r.endY} `
      ).attr("class", "edge section-edge-" + y.section + " edge-depth-" + y.depth);
    }
  });
}
_(dt, "drawEdges");
function ht(C, M, u, D) {
  M.add({
    group: "nodes",
    data: {
      id: C.id.toString(),
      labelText: C.descr,
      height: C.height,
      width: C.width,
      level: D,
      nodeId: C.id,
      padding: C.padding,
      type: C.type
    },
    position: {
      x: C.x,
      y: C.y
    }
  }), C.children && C.children.forEach((y) => {
    ht(y, M, u, D + 1), M.add({
      group: "edges",
      data: {
        id: `${C.id}_${y.id}`,
        source: C.id,
        target: y.id,
        depth: D,
        section: y.section
      }
    });
  });
}
_(ht, "addNodes");
function vt(C, M) {
  return new Promise((u) => {
    const D = Dt("body").append("div").attr("id", "cy").attr("style", "display:none"), y = ut({
      container: document.getElementById("cy"),
      // container to render in
      style: [
        {
          selector: "edge",
          style: {
            "curve-style": "bezier"
          }
        }
      ]
    });
    D.remove(), ht(C, y, M, 0), y.nodes().forEach(function(r) {
      r.layoutDimensions = () => {
        const t = r.data();
        return { w: t.width, h: t.height };
      };
    }), y.layout({
      name: "cose-bilkent",
      // @ts-ignore Types for cose-bilkent are not correct?
      quality: "proof",
      styleEnabled: !1,
      animate: !1
    }).run(), y.ready((r) => {
      Q.info("Ready", r), u(y);
    });
  });
}
_(vt, "layoutMindmap");
function yt(C, M) {
  M.nodes().map((u, D) => {
    const y = u.data();
    y.x = u.position().x, y.y = u.position().y, $t(C, y);
    const r = C.getElementById(y.nodeId);
    Q.info("id:", D, "Position: (", u.position().x, ", ", u.position().y, ")", y), r.attr(
      "transform",
      `translate(${u.position().x - y.width / 2}, ${u.position().y - y.height / 2})`
    ), r.attr("attr", `apa-${D})`);
  });
}
_(yt, "positionNodes");
var Wt = /* @__PURE__ */ _(async (C, M, u, D) => {
  var a, v;
  Q.debug(`Rendering mindmap diagram
` + C);
  const y = D.db, r = y.getMindmap();
  if (!r)
    return;
  const t = nt();
  t.htmlLabels = !1;
  const e = Et(M), i = e.append("g");
  i.attr("class", "mindmap-edges");
  const o = e.append("g");
  o.attr("class", "mindmap-nodes"), await ot(y, o, r, -1, t);
  const g = await vt(r, t);
  dt(i, g), yt(y, g), Lt(
    void 0,
    e,
    ((a = t.mindmap) == null ? void 0 : a.padding) ?? tt.mindmap.padding,
    ((v = t.mindmap) == null ? void 0 : v.useMaxWidth) ?? tt.mindmap.useMaxWidth
  );
}, "draw"), Bt = {
  draw: Wt
}, Vt = /* @__PURE__ */ _((C) => {
  let M = "";
  for (let u = 0; u < C.THEME_COLOR_LIMIT; u++)
    C["lineColor" + u] = C["lineColor" + u] || C["cScaleInv" + u], Tt(C["lineColor" + u]) ? C["lineColor" + u] = Nt(C["lineColor" + u], 20) : C["lineColor" + u] = mt(C["lineColor" + u], 20);
  for (let u = 0; u < C.THEME_COLOR_LIMIT; u++) {
    const D = "" + (17 - 3 * u);
    M += `
    .section-${u - 1} rect, .section-${u - 1} path, .section-${u - 1} circle, .section-${u - 1} polygon, .section-${u - 1} path  {
      fill: ${C["cScale" + u]};
    }
    .section-${u - 1} text {
     fill: ${C["cScaleLabel" + u]};
    }
    .node-icon-${u - 1} {
      font-size: 40px;
      color: ${C["cScaleLabel" + u]};
    }
    .section-edge-${u - 1}{
      stroke: ${C["cScale" + u]};
    }
    .edge-depth-${u - 1}{
      stroke-width: ${D};
    }
    .section-${u - 1} line {
      stroke: ${C["cScaleInv" + u]} ;
      stroke-width: 3;
    }

    .disabled, .disabled circle, .disabled text {
      fill: lightgray;
    }
    .disabled text {
      fill: #efefef;
    }
    `;
  }
  return M;
}, "genSections"), Zt = /* @__PURE__ */ _((C) => `
  .edge {
    stroke-width: 3;
  }
  ${Vt(C)}
  .section-root rect, .section-root path, .section-root circle, .section-root polygon  {
    fill: ${C.git0};
  }
  .section-root text {
    fill: ${C.gitBranchLabel0};
  }
  .icon-container {
    height:100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .edge {
    fill: none;
  }
  .mindmap-node-label {
    dy: 1em;
    alignment-baseline: middle;
    text-anchor: middle;
    dominant-baseline: middle;
    text-align: center;
  }
`, "getStyles"), Qt = Zt, Jt = {
  get db() {
    return new Gt();
  },
  renderer: Bt,
  parser: wt,
  styles: Qt
};
export {
  Jt as diagram
};
