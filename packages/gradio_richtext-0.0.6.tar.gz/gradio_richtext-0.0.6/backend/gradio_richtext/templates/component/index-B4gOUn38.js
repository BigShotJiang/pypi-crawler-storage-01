import { c as x } from "./index-zPv55tna.js";
import { v as L } from "./index-MxBukWlM.js";
import { t as w } from "./index-Dzq2w4iB.js";
import { E as O } from "./index-DPVDNjDQ.js";
import { p as z } from "./index-dR6aK-GC.js";
function F(r, n, e, c) {
  const l = e.enter("blockquote"), s = e.createTracker(c);
  s.move("> "), s.shift(2);
  const o = e.indentLines(
    e.containerFlow(r, s.current()),
    B
  );
  return l(), o;
}
function B(r, n, e) {
  return ">" + (e ? "" : " ") + r;
}
function $(r, n) {
  return b(r, n.inConstruct, !0) && !b(r, n.notInConstruct, !1);
}
function b(r, n, e) {
  if (typeof n == "string" && (n = [n]), !n || n.length === 0)
    return e;
  let c = -1;
  for (; ++c < n.length; )
    if (r.includes(n[c]))
      return !0;
  return !1;
}
function g(r, n, e, c) {
  let l = -1;
  for (; ++l < e.unsafe.length; )
    if (e.unsafe[l].character === `
` && $(e.stack, e.unsafe[l]))
      return /[ \t]/.test(c.before) ? "" : " ";
  return `\\
`;
}
function q(r, n) {
  const e = String(r);
  let c = e.indexOf(n), l = c, s = 0, o = 0;
  if (typeof n != "string")
    throw new TypeError("Expected substring");
  for (; c !== -1; )
    c === l ? ++s > o && (o = s) : s = 1, l = c + n.length, c = e.indexOf(n, l);
  return o;
}
function M(r, n) {
  return !!(n.options.fences === !1 && r.value && // If there’s no info…
  !r.lang && // And there’s a non-whitespace character…
  /[^ \r\n]/.test(r.value) && // And the value doesn’t start or end in a blank…
  !/^[\t ]*(?:[\r\n]|$)|(?:^|[\r\n])[\t ]*$/.test(r.value));
}
function Q(r) {
  const n = r.options.fence || "`";
  if (n !== "`" && n !== "~")
    throw new Error(
      "Cannot serialize code with `" + n + "` for `options.fence`, expected `` ` `` or `~`"
    );
  return n;
}
function U(r, n, e, c) {
  const l = Q(e), s = r.value || "", o = l === "`" ? "GraveAccent" : "Tilde";
  if (M(r, e)) {
    const a = e.enter("codeIndented"), h = e.indentLines(s, H);
    return a(), h;
  }
  const u = e.createTracker(c), t = l.repeat(Math.max(q(s, l) + 1, 3)), i = e.enter("codeFenced");
  let f = u.move(t);
  if (r.lang) {
    const a = e.enter(`codeFencedLang${o}`);
    f += u.move(
      e.safe(r.lang, {
        before: f,
        after: " ",
        encode: ["`"],
        ...u.current()
      })
    ), a();
  }
  if (r.lang && r.meta) {
    const a = e.enter(`codeFencedMeta${o}`);
    f += u.move(" "), f += u.move(
      e.safe(r.meta, {
        before: f,
        after: `
`,
        encode: ["`"],
        ...u.current()
      })
    ), a();
  }
  return f += u.move(`
`), s && (f += u.move(s + `
`)), f += u.move(t), i(), f;
}
function H(r, n, e) {
  return (e ? "" : "    ") + r;
}
function k(r) {
  const n = r.options.quote || '"';
  if (n !== '"' && n !== "'")
    throw new Error(
      "Cannot serialize title with `" + n + "` for `options.quote`, expected `\"`, or `'`"
    );
  return n;
}
function K(r, n, e, c) {
  const l = k(e), s = l === '"' ? "Quote" : "Apostrophe", o = e.enter("definition");
  let u = e.enter("label");
  const t = e.createTracker(c);
  let i = t.move("[");
  return i += t.move(
    e.safe(e.associationId(r), {
      before: i,
      after: "]",
      ...t.current()
    })
  ), i += t.move("]: "), u(), // If there’s no url, or…
  !r.url || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(r.url) ? (u = e.enter("destinationLiteral"), i += t.move("<"), i += t.move(
    e.safe(r.url, { before: i, after: ">", ...t.current() })
  ), i += t.move(">")) : (u = e.enter("destinationRaw"), i += t.move(
    e.safe(r.url, {
      before: i,
      after: r.title ? " " : `
`,
      ...t.current()
    })
  )), u(), r.title && (u = e.enter(`title${s}`), i += t.move(" " + l), i += t.move(
    e.safe(r.title, {
      before: i,
      after: l,
      ...t.current()
    })
  ), i += t.move(l), u()), o(), i;
}
function D(r) {
  const n = r.options.emphasis || "*";
  if (n !== "*" && n !== "_")
    throw new Error(
      "Cannot serialize emphasis with `" + n + "` for `options.emphasis`, expected `*`, or `_`"
    );
  return n;
}
function p(r) {
  return "&#x" + r.toString(16).toUpperCase() + ";";
}
function d(r, n, e) {
  const c = x(r), l = x(n);
  return c === void 0 ? l === void 0 ? (
    // Letter inside:
    // we have to encode *both* letters for `_` as it is looser.
    // it already forms for `*` (and GFMs `~`).
    e === "_" ? { inside: !0, outside: !0 } : { inside: !1, outside: !1 }
  ) : l === 1 ? (
    // Whitespace inside: encode both (letter, whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: encode outer (letter)
    { inside: !1, outside: !0 }
  ) : c === 1 ? l === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : l === 1 ? (
    // Whitespace inside: encode both (whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  ) : l === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : l === 1 ? (
    // Whitespace inside: encode inner (whitespace).
    { inside: !0, outside: !1 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  );
}
C.peek = G;
function C(r, n, e, c) {
  const l = D(e), s = e.enter("emphasis"), o = e.createTracker(c), u = o.move(l);
  let t = o.move(
    e.containerPhrasing(r, {
      after: l,
      before: u,
      ...o.current()
    })
  );
  const i = t.charCodeAt(0), f = d(
    c.before.charCodeAt(c.before.length - 1),
    i,
    l
  );
  f.inside && (t = p(i) + t.slice(1));
  const a = t.charCodeAt(t.length - 1), h = d(c.after.charCodeAt(0), a, l);
  h.inside && (t = t.slice(0, -1) + p(a));
  const m = o.move(l);
  return s(), e.attentionEncodeSurroundingInfo = {
    after: h.outside,
    before: f.outside
  }, u + t + m;
}
function G(r, n, e) {
  return e.options.emphasis || "*";
}
function W(r, n) {
  let e = !1;
  return L(r, function(c) {
    if ("value" in c && /\r?\n|\r/.test(c.value) || c.type === "break")
      return e = !0, O;
  }), !!((!r.depth || r.depth < 3) && w(r) && (n.options.setext || e));
}
function X(r, n, e, c) {
  const l = Math.max(Math.min(6, r.depth || 1), 1), s = e.createTracker(c);
  if (W(r, e)) {
    const f = e.enter("headingSetext"), a = e.enter("phrasing"), h = e.containerPhrasing(r, {
      ...s.current(),
      before: `
`,
      after: `
`
    });
    return a(), f(), h + `
` + (l === 1 ? "=" : "-").repeat(
      // The whole size…
      h.length - // Minus the position of the character after the last EOL (or
      // 0 if there is none)…
      (Math.max(h.lastIndexOf("\r"), h.lastIndexOf(`
`)) + 1)
    );
  }
  const o = "#".repeat(l), u = e.enter("headingAtx"), t = e.enter("phrasing");
  s.move(o + " ");
  let i = e.containerPhrasing(r, {
    before: "# ",
    after: `
`,
    ...s.current()
  });
  return /^[\t ]/.test(i) && (i = p(i.charCodeAt(0)) + i.slice(1)), i = i ? o + " " + i : o, e.options.closeAtx && (i += " " + o), t(), u(), i;
}
_.peek = j;
function _(r) {
  return r.value || "";
}
function j() {
  return "<";
}
I.peek = J;
function I(r, n, e, c) {
  const l = k(e), s = l === '"' ? "Quote" : "Apostrophe", o = e.enter("image");
  let u = e.enter("label");
  const t = e.createTracker(c);
  let i = t.move("![");
  return i += t.move(
    e.safe(r.alt, { before: i, after: "]", ...t.current() })
  ), i += t.move("]("), u(), // If there’s no url but there is a title…
  !r.url && r.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(r.url) ? (u = e.enter("destinationLiteral"), i += t.move("<"), i += t.move(
    e.safe(r.url, { before: i, after: ">", ...t.current() })
  ), i += t.move(">")) : (u = e.enter("destinationRaw"), i += t.move(
    e.safe(r.url, {
      before: i,
      after: r.title ? " " : ")",
      ...t.current()
    })
  )), u(), r.title && (u = e.enter(`title${s}`), i += t.move(" " + l), i += t.move(
    e.safe(r.title, {
      before: i,
      after: l,
      ...t.current()
    })
  ), i += t.move(l), u()), i += t.move(")"), o(), i;
}
function J() {
  return "!";
}
A.peek = N;
function A(r, n, e, c) {
  const l = r.referenceType, s = e.enter("imageReference");
  let o = e.enter("label");
  const u = e.createTracker(c);
  let t = u.move("![");
  const i = e.safe(r.alt, {
    before: t,
    after: "]",
    ...u.current()
  });
  t += u.move(i + "]["), o();
  const f = e.stack;
  e.stack = [], o = e.enter("reference");
  const a = e.safe(e.associationId(r), {
    before: t,
    after: "]",
    ...u.current()
  });
  return o(), e.stack = f, s(), l === "full" || !i || i !== a ? t += u.move(a + "]") : l === "shortcut" ? t = t.slice(0, -1) : t += u.move("]"), t;
}
function N() {
  return "!";
}
E.peek = V;
function E(r, n, e) {
  let c = r.value || "", l = "`", s = -1;
  for (; new RegExp("(^|[^`])" + l + "([^`]|$)").test(c); )
    l += "`";
  for (/[^ \r\n]/.test(c) && (/^[ \r\n]/.test(c) && /[ \r\n]$/.test(c) || /^`|`$/.test(c)) && (c = " " + c + " "); ++s < e.unsafe.length; ) {
    const o = e.unsafe[s], u = e.compilePattern(o);
    let t;
    if (o.atBreak)
      for (; t = u.exec(c); ) {
        let i = t.index;
        c.charCodeAt(i) === 10 && c.charCodeAt(i - 1) === 13 && i--, c = c.slice(0, i) + " " + c.slice(t.index + 1);
      }
  }
  return l + c + l;
}
function V() {
  return "`";
}
function P(r, n) {
  const e = w(r);
  return !!(!n.options.resourceLink && // If there’s a url…
  r.url && // And there’s a no title…
  !r.title && // And the content of `node` is a single text node…
  r.children && r.children.length === 1 && r.children[0].type === "text" && // And if the url is the same as the content…
  (e === r.url || "mailto:" + e === r.url) && // And that starts w/ a protocol…
  /^[a-z][a-z+.-]+:/i.test(r.url) && // And that doesn’t contain ASCII control codes (character escapes and
  // references don’t work), space, or angle brackets…
  !/[\0- <>\u007F]/.test(r.url));
}
S.peek = Y;
function S(r, n, e, c) {
  const l = k(e), s = l === '"' ? "Quote" : "Apostrophe", o = e.createTracker(c);
  let u, t;
  if (P(r, e)) {
    const f = e.stack;
    e.stack = [], u = e.enter("autolink");
    let a = o.move("<");
    return a += o.move(
      e.containerPhrasing(r, {
        before: a,
        after: ">",
        ...o.current()
      })
    ), a += o.move(">"), u(), e.stack = f, a;
  }
  u = e.enter("link"), t = e.enter("label");
  let i = o.move("[");
  return i += o.move(
    e.containerPhrasing(r, {
      before: i,
      after: "](",
      ...o.current()
    })
  ), i += o.move("]("), t(), // If there’s no url but there is a title…
  !r.url && r.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(r.url) ? (t = e.enter("destinationLiteral"), i += o.move("<"), i += o.move(
    e.safe(r.url, { before: i, after: ">", ...o.current() })
  ), i += o.move(">")) : (t = e.enter("destinationRaw"), i += o.move(
    e.safe(r.url, {
      before: i,
      after: r.title ? " " : ")",
      ...o.current()
    })
  )), t(), r.title && (t = e.enter(`title${s}`), i += o.move(" " + l), i += o.move(
    e.safe(r.title, {
      before: i,
      after: l,
      ...o.current()
    })
  ), i += o.move(l), t()), i += o.move(")"), u(), i;
}
function Y(r, n, e) {
  return P(r, e) ? "<" : "[";
}
T.peek = Z;
function T(r, n, e, c) {
  const l = r.referenceType, s = e.enter("linkReference");
  let o = e.enter("label");
  const u = e.createTracker(c);
  let t = u.move("[");
  const i = e.containerPhrasing(r, {
    before: t,
    after: "]",
    ...u.current()
  });
  t += u.move(i + "]["), o();
  const f = e.stack;
  e.stack = [], o = e.enter("reference");
  const a = e.safe(e.associationId(r), {
    before: t,
    after: "]",
    ...u.current()
  });
  return o(), e.stack = f, s(), l === "full" || !i || i !== a ? t += u.move(a + "]") : l === "shortcut" ? t = t.slice(0, -1) : t += u.move("]"), t;
}
function Z() {
  return "[";
}
function v(r) {
  const n = r.options.bullet || "*";
  if (n !== "*" && n !== "+" && n !== "-")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.bullet`, expected `*`, `+`, or `-`"
    );
  return n;
}
function ee(r) {
  const n = v(r), e = r.options.bulletOther;
  if (!e)
    return n === "*" ? "-" : "*";
  if (e !== "*" && e !== "+" && e !== "-")
    throw new Error(
      "Cannot serialize items with `" + e + "` for `options.bulletOther`, expected `*`, `+`, or `-`"
    );
  if (e === n)
    throw new Error(
      "Expected `bullet` (`" + n + "`) and `bulletOther` (`" + e + "`) to be different"
    );
  return e;
}
function re(r) {
  const n = r.options.bulletOrdered || ".";
  if (n !== "." && n !== ")")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.bulletOrdered`, expected `.` or `)`"
    );
  return n;
}
function y(r) {
  const n = r.options.rule || "*";
  if (n !== "*" && n !== "-" && n !== "_")
    throw new Error(
      "Cannot serialize rules with `" + n + "` for `options.rule`, expected `*`, `-`, or `_`"
    );
  return n;
}
function ne(r, n, e, c) {
  const l = e.enter("list"), s = e.bulletCurrent;
  let o = r.ordered ? re(e) : v(e);
  const u = r.ordered ? o === "." ? ")" : "." : ee(e);
  let t = n && e.bulletLastUsed ? o === e.bulletLastUsed : !1;
  if (!r.ordered) {
    const f = r.children ? r.children[0] : void 0;
    if (
      // Bullet could be used as a thematic break marker:
      (o === "*" || o === "-") && // Empty first list item:
      f && (!f.children || !f.children[0]) && // Directly in two other list items:
      e.stack[e.stack.length - 1] === "list" && e.stack[e.stack.length - 2] === "listItem" && e.stack[e.stack.length - 3] === "list" && e.stack[e.stack.length - 4] === "listItem" && // That are each the first child.
      e.indexStack[e.indexStack.length - 1] === 0 && e.indexStack[e.indexStack.length - 2] === 0 && e.indexStack[e.indexStack.length - 3] === 0 && (t = !0), y(e) === o && f
    ) {
      let a = -1;
      for (; ++a < r.children.length; ) {
        const h = r.children[a];
        if (h && h.type === "listItem" && h.children && h.children[0] && h.children[0].type === "thematicBreak") {
          t = !0;
          break;
        }
      }
    }
  }
  t && (o = u), e.bulletCurrent = o;
  const i = e.containerFlow(r, c);
  return e.bulletLastUsed = o, e.bulletCurrent = s, l(), i;
}
function te(r) {
  const n = r.options.listItemIndent || "one";
  if (n !== "tab" && n !== "one" && n !== "mixed")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`"
    );
  return n;
}
function ie(r, n, e, c) {
  const l = te(e);
  let s = e.bulletCurrent || v(e);
  n && n.type === "list" && n.ordered && (s = (typeof n.start == "number" && n.start > -1 ? n.start : 1) + (e.options.incrementListMarker === !1 ? 0 : n.children.indexOf(r)) + s);
  let o = s.length + 1;
  (l === "tab" || l === "mixed" && (n && n.type === "list" && n.spread || r.spread)) && (o = Math.ceil(o / 4) * 4);
  const u = e.createTracker(c);
  u.move(s + " ".repeat(o - s.length)), u.shift(o);
  const t = e.enter("listItem"), i = e.indentLines(
    e.containerFlow(r, u.current()),
    f
  );
  return t(), i;
  function f(a, h, m) {
    return h ? (m ? "" : " ".repeat(o)) + a : (m ? s : s + " ".repeat(o - s.length)) + a;
  }
}
function oe(r, n, e, c) {
  const l = e.enter("paragraph"), s = e.enter("phrasing"), o = e.containerPhrasing(r, c);
  return s(), l(), o;
}
function ce(r, n, e, c) {
  return (r.children.some(function(o) {
    return z(o);
  }) ? e.containerPhrasing : e.containerFlow).call(e, r, c);
}
function le(r) {
  const n = r.options.strong || "*";
  if (n !== "*" && n !== "_")
    throw new Error(
      "Cannot serialize strong with `" + n + "` for `options.strong`, expected `*`, or `_`"
    );
  return n;
}
R.peek = ue;
function R(r, n, e, c) {
  const l = le(e), s = e.enter("strong"), o = e.createTracker(c), u = o.move(l + l);
  let t = o.move(
    e.containerPhrasing(r, {
      after: l,
      before: u,
      ...o.current()
    })
  );
  const i = t.charCodeAt(0), f = d(
    c.before.charCodeAt(c.before.length - 1),
    i,
    l
  );
  f.inside && (t = p(i) + t.slice(1));
  const a = t.charCodeAt(t.length - 1), h = d(c.after.charCodeAt(0), a, l);
  h.inside && (t = t.slice(0, -1) + p(a));
  const m = o.move(l + l);
  return s(), e.attentionEncodeSurroundingInfo = {
    after: h.outside,
    before: f.outside
  }, u + t + m;
}
function ue(r, n, e) {
  return e.options.strong || "*";
}
function se(r, n, e, c) {
  return e.safe(r.value, c);
}
function fe(r) {
  const n = r.options.ruleRepetition || 3;
  if (n < 3)
    throw new Error(
      "Cannot serialize rules with repetition `" + n + "` for `options.ruleRepetition`, expected `3` or more"
    );
  return n;
}
function ae(r, n, e) {
  const c = (y(e) + (e.options.ruleSpaces ? " " : "")).repeat(fe(e));
  return e.options.ruleSpaces ? c.slice(0, -1) : c;
}
const ve = {
  blockquote: F,
  break: g,
  code: U,
  definition: K,
  emphasis: C,
  hardBreak: g,
  heading: X,
  html: _,
  image: I,
  imageReference: A,
  inlineCode: E,
  link: S,
  linkReference: T,
  list: ne,
  listItem: ie,
  paragraph: oe,
  root: ce,
  strong: R,
  text: se,
  thematicBreak: ae
};
export {
  W as a,
  p as e,
  M as f,
  ve as h,
  $ as p
};
