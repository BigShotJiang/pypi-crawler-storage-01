import { n as j, b as wt, f as L, s as W, r as xt, c as yt } from "./blank-line-C74Di3OL.js";
import { u as R, a as $, d as N, e as O, m as A, f as Ct, c as P, b as T } from "./index-Cu1EQZGJ.js";
import { c as Y } from "./index-zPv55tna.js";
import { c as K } from "./index-uEBo76nn.js";
import { o as E } from "./default-BwQc_qtq.js";
import { c as Dt, v as dt } from "./index-DPVDNjDQ.js";
import { h as rt } from "./index-B4gOUn38.js";
function At(t) {
  if (typeof t != "string")
    throw new TypeError("Expected a string");
  return t.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
function Ft(t, n, e) {
  const o = Dt((e || {}).ignore || []), a = St(n);
  let i = -1;
  for (; ++i < a.length; )
    dt(t, "text", u);
  function u(c, m) {
    let l = -1, g;
    for (; ++l < m.length; ) {
      const k = m[l], h = g ? g.children : void 0;
      if (o(
        k,
        h ? h.indexOf(k) : void 0,
        g
      ))
        return;
      g = k;
    }
    if (g)
      return s(c, m);
  }
  function s(c, m) {
    const l = m[m.length - 1], g = a[i][0], k = a[i][1];
    let h = 0;
    const w = l.children.indexOf(c);
    let p = !1, x = [];
    g.lastIndex = 0;
    let y = g.exec(c.value);
    for (; y; ) {
      const d = y.index, D = {
        index: y.index,
        input: y.input,
        stack: [...m, c]
      };
      let C = k(...y, D);
      if (typeof C == "string" && (C = C.length > 0 ? { type: "text", value: C } : void 0), C === !1 ? g.lastIndex = d + 1 : (h !== d && x.push({
        type: "text",
        value: c.value.slice(h, d)
      }), Array.isArray(C) ? x.push(...C) : C && x.push(C), h = d + y[0].length, p = !0), !g.global)
        break;
      y = g.exec(c.value);
    }
    return p ? (h < c.value.length && x.push({ type: "text", value: c.value.slice(h) }), l.children.splice(w, 1, ...x)) : x = [c], w + x.length;
  }
}
function St(t) {
  const n = [];
  if (!Array.isArray(t))
    throw new TypeError("Expected find and replace tuple or list of tuples");
  const e = !t[0] || Array.isArray(t[0]) ? t : [t];
  let r = -1;
  for (; ++r < e.length; ) {
    const o = e[r];
    n.push([Lt(o[0]), zt(o[1])]);
  }
  return n;
}
function Lt(t) {
  return typeof t == "string" ? new RegExp(At(t), "g") : t;
}
function zt(t) {
  return typeof t == "function" ? t : function() {
    return t;
  };
}
const H = "phrasing", V = ["autolink", "link", "image", "label"];
function Tt() {
  return {
    transforms: [jt],
    enter: {
      literalAutolink: Rt,
      literalAutolinkEmail: q,
      literalAutolinkHttp: q,
      literalAutolinkWww: q
    },
    exit: {
      literalAutolink: Ot,
      literalAutolinkEmail: Pt,
      literalAutolinkHttp: Et,
      literalAutolinkWww: It
    }
  };
}
function Mt() {
  return {
    unsafe: [
      {
        character: "@",
        before: "[+\\-.\\w]",
        after: "[\\-.\\w]",
        inConstruct: H,
        notInConstruct: V
      },
      {
        character: ".",
        before: "[Ww]",
        after: "[\\-.\\w]",
        inConstruct: H,
        notInConstruct: V
      },
      {
        character: ":",
        before: "[ps]",
        after: "\\/",
        inConstruct: H,
        notInConstruct: V
      }
    ]
  };
}
function Rt(t) {
  this.enter({ type: "link", title: null, url: "", children: [] }, t);
}
function q(t) {
  this.config.enter.autolinkProtocol.call(this, t);
}
function Et(t) {
  this.config.exit.autolinkProtocol.call(this, t);
}
function It(t) {
  this.config.exit.data.call(this, t);
  const n = this.stack[this.stack.length - 1];
  E(n.type === "link"), n.url = "http://" + this.sliceSerialize(t);
}
function Pt(t) {
  this.config.exit.autolinkEmail.call(this, t);
}
function Ot(t) {
  this.exit(t);
}
function jt(t) {
  Ft(
    t,
    [
      [/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, _t],
      [new RegExp("(?<=^|\\s|\\p{P}|\\p{S})([-.\\w+]+)@([-\\w]+(?:\\.[-\\w]+)+)", "gu"), vt]
    ],
    { ignore: ["link", "linkReference"] }
  );
}
function _t(t, n, e, r, o) {
  let a = "";
  if (!lt(o) || (/^w/i.test(n) && (e = n + e, n = "", a = "http://"), !Bt(e)))
    return !1;
  const i = Wt(e + r);
  if (!i[0]) return !1;
  const u = {
    type: "link",
    title: null,
    url: a + n + i[0],
    children: [{ type: "text", value: n + i[0] }]
  };
  return i[1] ? [u, { type: "text", value: i[1] }] : u;
}
function vt(t, n, e, r) {
  return (
    // Not an expected previous character.
    !lt(r, !0) || // Label ends in not allowed character.
    /[-\d_]$/.test(e) ? !1 : {
      type: "link",
      title: null,
      url: "mailto:" + n + "@" + e,
      children: [{ type: "text", value: n + "@" + e }]
    }
  );
}
function Bt(t) {
  const n = t.split(".");
  return !(n.length < 2 || n[n.length - 1] && (/_/.test(n[n.length - 1]) || !/[a-zA-Z\d]/.test(n[n.length - 1])) || n[n.length - 2] && (/_/.test(n[n.length - 2]) || !/[a-zA-Z\d]/.test(n[n.length - 2])));
}
function Wt(t) {
  const n = /[!"&'),.:;<>?\]}]+$/.exec(t);
  if (!n)
    return [t, void 0];
  t = t.slice(0, n.index);
  let e = n[0], r = e.indexOf(")");
  const o = K(t, "(");
  let a = K(t, ")");
  for (; r !== -1 && o > a; )
    t += e.slice(0, r + 1), e = e.slice(r + 1), r = e.indexOf(")"), a++;
  return [t, e];
}
function lt(t, n) {
  const e = t.input.charCodeAt(t.index - 1);
  return (t.index === 0 || R(e) || $(e)) && // If it’s an email, the previous character should not be a slash.
  (!n || e !== 47);
}
at.peek = Qt;
function Ht() {
  this.buffer();
}
function Vt(t) {
  this.enter({ type: "footnoteReference", identifier: "", label: "" }, t);
}
function qt() {
  this.buffer();
}
function Ut(t) {
  this.enter(
    { type: "footnoteDefinition", identifier: "", label: "", children: [] },
    t
  );
}
function Gt(t) {
  const n = this.resume(), e = this.stack[this.stack.length - 1];
  E(e.type === "footnoteReference"), e.identifier = j(
    this.sliceSerialize(t)
  ).toLowerCase(), e.label = n;
}
function $t(t) {
  this.exit(t);
}
function Nt(t) {
  const n = this.resume(), e = this.stack[this.stack.length - 1];
  E(e.type === "footnoteDefinition"), e.identifier = j(
    this.sliceSerialize(t)
  ).toLowerCase(), e.label = n;
}
function Zt(t) {
  this.exit(t);
}
function Qt() {
  return "[";
}
function at(t, n, e, r) {
  const o = e.createTracker(r);
  let a = o.move("[^");
  const i = e.enter("footnoteReference"), u = e.enter("reference");
  return a += o.move(
    e.safe(e.associationId(t), { after: "]", before: a })
  ), u(), i(), a += o.move("]"), a;
}
function Jt() {
  return {
    enter: {
      gfmFootnoteCallString: Ht,
      gfmFootnoteCall: Vt,
      gfmFootnoteDefinitionLabelString: qt,
      gfmFootnoteDefinition: Ut
    },
    exit: {
      gfmFootnoteCallString: Gt,
      gfmFootnoteCall: $t,
      gfmFootnoteDefinitionLabelString: Nt,
      gfmFootnoteDefinition: Zt
    }
  };
}
function Xt(t) {
  let n = !1;
  return t && t.firstLineBlank && (n = !0), {
    handlers: { footnoteDefinition: e, footnoteReference: at },
    // This is on by default already.
    unsafe: [{ character: "[", inConstruct: ["label", "phrasing", "reference"] }]
  };
  function e(r, o, a, i) {
    const u = a.createTracker(i);
    let s = u.move("[^");
    const c = a.enter("footnoteDefinition"), m = a.enter("label");
    return s += u.move(
      a.safe(a.associationId(r), { before: s, after: "]" })
    ), m(), s += u.move("]:"), r.children && r.children.length > 0 && (u.shift(4), s += u.move(
      (n ? `
` : " ") + a.indentLines(
        a.containerFlow(r, u.current()),
        n ? ot : Yt
      )
    )), c(), s;
  }
}
function Yt(t, n, e) {
  return n === 0 ? t : ot(t, n, e);
}
function ot(t, n, e) {
  return (e ? "" : "    ") + t;
}
const Kt = [
  "autolink",
  "destinationLiteral",
  "destinationRaw",
  "reference",
  "titleQuote",
  "titleApostrophe"
];
ut.peek = re;
function te() {
  return {
    canContainEols: ["delete"],
    enter: { strikethrough: ne },
    exit: { strikethrough: ie }
  };
}
function ee() {
  return {
    unsafe: [
      {
        character: "~",
        inConstruct: "phrasing",
        notInConstruct: Kt
      }
    ],
    handlers: { delete: ut }
  };
}
function ne(t) {
  this.enter({ type: "delete", children: [] }, t);
}
function ie(t) {
  this.exit(t);
}
function ut(t, n, e, r) {
  const o = e.createTracker(r), a = e.enter("strikethrough");
  let i = o.move("~~");
  return i += e.containerPhrasing(t, {
    ...o.current(),
    before: i,
    after: "~"
  }), i += o.move("~~"), a(), i;
}
function re() {
  return "~";
}
function le(t) {
  return t.length;
}
function ae(t, n) {
  const e = n || {}, r = (e.align || []).concat(), o = e.stringLength || le, a = [], i = [], u = [], s = [];
  let c = 0, m = -1;
  for (; ++m < t.length; ) {
    const b = [], w = [];
    let p = -1;
    for (t[m].length > c && (c = t[m].length); ++p < t[m].length; ) {
      const x = oe(t[m][p]);
      if (e.alignDelimiters !== !1) {
        const y = o(x);
        w[p] = y, (s[p] === void 0 || y > s[p]) && (s[p] = y);
      }
      b.push(x);
    }
    i[m] = b, u[m] = w;
  }
  let l = -1;
  if (typeof r == "object" && "length" in r)
    for (; ++l < c; )
      a[l] = tt(r[l]);
  else {
    const b = tt(r);
    for (; ++l < c; )
      a[l] = b;
  }
  l = -1;
  const g = [], k = [];
  for (; ++l < c; ) {
    const b = a[l];
    let w = "", p = "";
    b === 99 ? (w = ":", p = ":") : b === 108 ? w = ":" : b === 114 && (p = ":");
    let x = e.alignDelimiters === !1 ? 1 : Math.max(
      1,
      s[l] - w.length - p.length
    );
    const y = w + "-".repeat(x) + p;
    e.alignDelimiters !== !1 && (x = w.length + x + p.length, x > s[l] && (s[l] = x), k[l] = x), g[l] = y;
  }
  i.splice(1, 0, g), u.splice(1, 0, k), m = -1;
  const h = [];
  for (; ++m < i.length; ) {
    const b = i[m], w = u[m];
    l = -1;
    const p = [];
    for (; ++l < c; ) {
      const x = b[l] || "";
      let y = "", d = "";
      if (e.alignDelimiters !== !1) {
        const D = s[l] - (w[l] || 0), C = a[l];
        C === 114 ? y = " ".repeat(D) : C === 99 ? D % 2 ? (y = " ".repeat(D / 2 + 0.5), d = " ".repeat(D / 2 - 0.5)) : (y = " ".repeat(D / 2), d = y) : d = " ".repeat(D);
      }
      e.delimiterStart !== !1 && !l && p.push("|"), e.padding !== !1 && // Don’t add the opening space if we’re not aligning and the cell is
      // empty: there will be a closing space.
      !(e.alignDelimiters === !1 && x === "") && (e.delimiterStart !== !1 || l) && p.push(" "), e.alignDelimiters !== !1 && p.push(y), p.push(x), e.alignDelimiters !== !1 && p.push(d), e.padding !== !1 && p.push(" "), (e.delimiterEnd !== !1 || l !== c - 1) && p.push("|");
    }
    h.push(
      e.delimiterEnd === !1 ? p.join("").replace(/ +$/, "") : p.join("")
    );
  }
  return h.join(`
`);
}
function oe(t) {
  return t == null ? "" : String(t);
}
function tt(t) {
  const n = typeof t == "string" ? t.codePointAt(0) : 0;
  return n === 67 || n === 99 ? 99 : n === 76 || n === 108 ? 108 : n === 82 || n === 114 ? 114 : 0;
}
function ue() {
  return {
    enter: {
      table: se,
      tableData: et,
      tableHeader: et,
      tableRow: he
    },
    exit: {
      codeText: ce,
      table: fe,
      tableData: U,
      tableHeader: U,
      tableRow: U
    }
  };
}
function se(t) {
  const n = t._align;
  this.enter(
    {
      type: "table",
      align: n.map(function(e) {
        return e === "none" ? null : e;
      }),
      children: []
    },
    t
  ), this.data.inTable = !0;
}
function fe(t) {
  this.exit(t), this.data.inTable = void 0;
}
function he(t) {
  this.enter({ type: "tableRow", children: [] }, t);
}
function U(t) {
  this.exit(t);
}
function et(t) {
  this.enter({ type: "tableCell", children: [] }, t);
}
function ce(t) {
  let n = this.resume();
  this.data.inTable && (n = n.replace(/\\([\\|])/g, me));
  const e = this.stack[this.stack.length - 1];
  E(e.type === "inlineCode"), e.value = n, this.exit(t);
}
function me(t, n) {
  return n === "|" ? n : t;
}
function ge(t) {
  const n = t || {}, e = n.tableCellPadding, r = n.tablePipeAlign, o = n.stringLength, a = e ? " " : "|";
  return {
    unsafe: [
      { character: "\r", inConstruct: "tableCell" },
      { character: `
`, inConstruct: "tableCell" },
      // A pipe, when followed by a tab or space (padding), or a dash or colon
      // (unpadded delimiter row), could result in a table.
      { atBreak: !0, character: "|", after: "[	 :-]" },
      // A pipe in a cell must be encoded.
      { character: "|", inConstruct: "tableCell" },
      // A colon must be followed by a dash, in which case it could start a
      // delimiter row.
      { atBreak: !0, character: ":", after: "-" },
      // A delimiter row can also start with a dash, when followed by more
      // dashes, a colon, or a pipe.
      // This is a stricter version than the built in check for lists, thematic
      // breaks, and setex heading underlines though:
      // <https://github.com/syntax-tree/mdast-util-to-markdown/blob/51a2038/lib/unsafe.js#L57>
      { atBreak: !0, character: "-", after: "[:|-]" }
    ],
    handlers: {
      inlineCode: g,
      table: i,
      tableCell: s,
      tableRow: u
    }
  };
  function i(k, h, b, w) {
    return c(m(k, b, w), k.align);
  }
  function u(k, h, b, w) {
    const p = l(k, b, w), x = c([p]);
    return x.slice(0, x.indexOf(`
`));
  }
  function s(k, h, b, w) {
    const p = b.enter("tableCell"), x = b.enter("phrasing"), y = b.containerPhrasing(k, {
      ...w,
      before: a,
      after: a
    });
    return x(), p(), y;
  }
  function c(k, h) {
    return ae(k, {
      align: h,
      // @ts-expect-error: `markdown-table` types should support `null`.
      alignDelimiters: r,
      // @ts-expect-error: `markdown-table` types should support `null`.
      padding: e,
      // @ts-expect-error: `markdown-table` types should support `null`.
      stringLength: o
    });
  }
  function m(k, h, b) {
    const w = k.children;
    let p = -1;
    const x = [], y = h.enter("table");
    for (; ++p < w.length; )
      x[p] = l(w[p], h, b);
    return y(), x;
  }
  function l(k, h, b) {
    const w = k.children;
    let p = -1;
    const x = [], y = h.enter("tableRow");
    for (; ++p < w.length; )
      x[p] = s(w[p], k, h, b);
    return y(), x;
  }
  function g(k, h, b) {
    let w = rt.inlineCode(k, h, b);
    return b.stack.includes("tableCell") && (w = w.replace(/\|/g, "\\$&")), w;
  }
}
function pe() {
  return {
    exit: {
      taskListCheckValueChecked: nt,
      taskListCheckValueUnchecked: nt,
      paragraph: be
    }
  };
}
function ke() {
  return {
    unsafe: [{ atBreak: !0, character: "-", after: "[:|-]" }],
    handlers: { listItem: we }
  };
}
function nt(t) {
  const n = this.stack[this.stack.length - 2];
  E(n.type === "listItem"), n.checked = t.type === "taskListCheckValueChecked";
}
function be(t) {
  const n = this.stack[this.stack.length - 2];
  if (n && n.type === "listItem" && typeof n.checked == "boolean") {
    const e = this.stack[this.stack.length - 1];
    E(e.type === "paragraph");
    const r = e.children[0];
    if (r && r.type === "text") {
      const o = n.children;
      let a = -1, i;
      for (; ++a < o.length; ) {
        const u = o[a];
        if (u.type === "paragraph") {
          i = u;
          break;
        }
      }
      i === e && (r.value = r.value.slice(1), r.value.length === 0 ? e.children.shift() : e.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, e.position.start = Object.assign({}, r.position.start)));
    }
  }
  this.exit(t);
}
function we(t, n, e, r) {
  const o = t.children[0], a = typeof t.checked == "boolean" && o && o.type === "paragraph", i = "[" + (t.checked ? "x" : " ") + "] ", u = e.createTracker(r);
  a && u.move(i);
  let s = rt.listItem(t, n, e, {
    ...r,
    ...u.current()
  });
  return a && (s = s.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, c)), s;
  function c(m) {
    return m + i;
  }
}
function xe() {
  return [
    Tt(),
    Jt(),
    te(),
    ue(),
    pe()
  ];
}
function ye(t) {
  return {
    extensions: [
      Mt(),
      Xt(t),
      ee(),
      ge(t),
      ke()
    ]
  };
}
const Ce = {
  tokenize: Le,
  partial: !0
}, st = {
  tokenize: ze,
  partial: !0
}, ft = {
  tokenize: Te,
  partial: !0
}, ht = {
  tokenize: Me,
  partial: !0
}, De = {
  tokenize: Re,
  partial: !0
}, ct = {
  name: "wwwAutolink",
  tokenize: Fe,
  previous: gt
}, mt = {
  name: "protocolAutolink",
  tokenize: Se,
  previous: pt
}, S = {
  name: "emailAutolink",
  tokenize: Ae,
  previous: kt
}, F = {};
function de() {
  return {
    text: F
  };
}
let z = 48;
for (; z < 123; )
  F[z] = S, z++, z === 58 ? z = 65 : z === 91 && (z = 97);
F[43] = S;
F[45] = S;
F[46] = S;
F[95] = S;
F[72] = [S, mt];
F[104] = [S, mt];
F[87] = [S, ct];
F[119] = [S, ct];
function Ae(t, n, e) {
  const r = this;
  let o, a;
  return i;
  function i(l) {
    return !G(l) || !kt.call(r, r.previous) || Z(r.events) ? e(l) : (t.enter("literalAutolink"), t.enter("literalAutolinkEmail"), u(l));
  }
  function u(l) {
    return G(l) ? (t.consume(l), u) : l === 64 ? (t.consume(l), s) : e(l);
  }
  function s(l) {
    return l === 46 ? t.check(De, m, c)(l) : l === 45 || l === 95 || N(l) ? (a = !0, t.consume(l), s) : m(l);
  }
  function c(l) {
    return t.consume(l), o = !0, s;
  }
  function m(l) {
    return a && o && O(r.previous) ? (t.exit("literalAutolinkEmail"), t.exit("literalAutolink"), n(l)) : e(l);
  }
}
function Fe(t, n, e) {
  const r = this;
  return o;
  function o(i) {
    return i !== 87 && i !== 119 || !gt.call(r, r.previous) || Z(r.events) ? e(i) : (t.enter("literalAutolink"), t.enter("literalAutolinkWww"), t.check(Ce, t.attempt(st, t.attempt(ft, a), e), e)(i));
  }
  function a(i) {
    return t.exit("literalAutolinkWww"), t.exit("literalAutolink"), n(i);
  }
}
function Se(t, n, e) {
  const r = this;
  let o = "", a = !1;
  return i;
  function i(l) {
    return (l === 72 || l === 104) && pt.call(r, r.previous) && !Z(r.events) ? (t.enter("literalAutolink"), t.enter("literalAutolinkHttp"), o += String.fromCodePoint(l), t.consume(l), u) : e(l);
  }
  function u(l) {
    if (O(l) && o.length < 5)
      return o += String.fromCodePoint(l), t.consume(l), u;
    if (l === 58) {
      const g = o.toLowerCase();
      if (g === "http" || g === "https")
        return t.consume(l), s;
    }
    return e(l);
  }
  function s(l) {
    return l === 47 ? (t.consume(l), a ? c : (a = !0, s)) : e(l);
  }
  function c(l) {
    return l === null || Ct(l) || A(l) || R(l) || $(l) ? e(l) : t.attempt(st, t.attempt(ft, m), e)(l);
  }
  function m(l) {
    return t.exit("literalAutolinkHttp"), t.exit("literalAutolink"), n(l);
  }
}
function Le(t, n, e) {
  let r = 0;
  return o;
  function o(i) {
    return (i === 87 || i === 119) && r < 3 ? (r++, t.consume(i), o) : i === 46 && r === 3 ? (t.consume(i), a) : e(i);
  }
  function a(i) {
    return i === null ? e(i) : n(i);
  }
}
function ze(t, n, e) {
  let r, o, a;
  return i;
  function i(c) {
    return c === 46 || c === 95 ? t.check(ht, s, u)(c) : c === null || A(c) || R(c) || c !== 45 && $(c) ? s(c) : (a = !0, t.consume(c), i);
  }
  function u(c) {
    return c === 95 ? r = !0 : (o = r, r = void 0), t.consume(c), i;
  }
  function s(c) {
    return o || r || !a ? e(c) : n(c);
  }
}
function Te(t, n) {
  let e = 0, r = 0;
  return o;
  function o(i) {
    return i === 40 ? (e++, t.consume(i), o) : i === 41 && r < e ? a(i) : i === 33 || i === 34 || i === 38 || i === 39 || i === 41 || i === 42 || i === 44 || i === 46 || i === 58 || i === 59 || i === 60 || i === 63 || i === 93 || i === 95 || i === 126 ? t.check(ht, n, a)(i) : i === null || A(i) || R(i) ? n(i) : (t.consume(i), o);
  }
  function a(i) {
    return i === 41 && r++, t.consume(i), o;
  }
}
function Me(t, n, e) {
  return r;
  function r(u) {
    return u === 33 || u === 34 || u === 39 || u === 41 || u === 42 || u === 44 || u === 46 || u === 58 || u === 59 || u === 63 || u === 95 || u === 126 ? (t.consume(u), r) : u === 38 ? (t.consume(u), a) : u === 93 ? (t.consume(u), o) : (
      // `<` is an end.
      u === 60 || // So is whitespace.
      u === null || A(u) || R(u) ? n(u) : e(u)
    );
  }
  function o(u) {
    return u === null || u === 40 || u === 91 || A(u) || R(u) ? n(u) : r(u);
  }
  function a(u) {
    return O(u) ? i(u) : e(u);
  }
  function i(u) {
    return u === 59 ? (t.consume(u), r) : O(u) ? (t.consume(u), i) : e(u);
  }
}
function Re(t, n, e) {
  return r;
  function r(a) {
    return t.consume(a), o;
  }
  function o(a) {
    return N(a) ? e(a) : n(a);
  }
}
function gt(t) {
  return t === null || t === 40 || t === 42 || t === 95 || t === 91 || t === 93 || t === 126 || A(t);
}
function pt(t) {
  return !O(t);
}
function kt(t) {
  return !(t === 47 || G(t));
}
function G(t) {
  return t === 43 || t === 45 || t === 46 || t === 95 || N(t);
}
function Z(t) {
  let n = t.length, e = !1;
  for (; n--; ) {
    const r = t[n][1];
    if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
      e = !0;
      break;
    }
    if (r._gfmAutolinkLiteralWalkedInto) {
      e = !1;
      break;
    }
  }
  return t.length > 0 && !e && (t[t.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), e;
}
const Ee = {
  tokenize: We,
  partial: !0
};
function Ie() {
  return {
    document: {
      91: {
        name: "gfmFootnoteDefinition",
        tokenize: _e,
        continuation: {
          tokenize: ve
        },
        exit: Be
      }
    },
    text: {
      91: {
        name: "gfmFootnoteCall",
        tokenize: je
      },
      93: {
        name: "gfmPotentialFootnoteCall",
        add: "after",
        tokenize: Pe,
        resolveTo: Oe
      }
    }
  };
}
function Pe(t, n, e) {
  const r = this;
  let o = r.events.length;
  const a = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let i;
  for (; o--; ) {
    const s = r.events[o][1];
    if (s.type === "labelImage") {
      i = s;
      break;
    }
    if (s.type === "gfmFootnoteCall" || s.type === "labelLink" || s.type === "label" || s.type === "image" || s.type === "link")
      break;
  }
  return u;
  function u(s) {
    if (!i || !i._balanced)
      return e(s);
    const c = j(r.sliceSerialize({
      start: i.end,
      end: r.now()
    }));
    return c.codePointAt(0) !== 94 || !a.includes(c.slice(1)) ? e(s) : (t.enter("gfmFootnoteCallLabelMarker"), t.consume(s), t.exit("gfmFootnoteCallLabelMarker"), n(s));
  }
}
function Oe(t, n) {
  let e = t.length;
  for (; e--; )
    if (t[e][1].type === "labelImage" && t[e][0] === "enter") {
      t[e][1];
      break;
    }
  t[e + 1][1].type = "data", t[e + 3][1].type = "gfmFootnoteCallLabelMarker";
  const r = {
    type: "gfmFootnoteCall",
    start: Object.assign({}, t[e + 3][1].start),
    end: Object.assign({}, t[t.length - 1][1].end)
  }, o = {
    type: "gfmFootnoteCallMarker",
    start: Object.assign({}, t[e + 3][1].end),
    end: Object.assign({}, t[e + 3][1].end)
  };
  o.end.column++, o.end.offset++, o.end._bufferIndex++;
  const a = {
    type: "gfmFootnoteCallString",
    start: Object.assign({}, o.end),
    end: Object.assign({}, t[t.length - 1][1].start)
  }, i = {
    type: "chunkString",
    contentType: "string",
    start: Object.assign({}, a.start),
    end: Object.assign({}, a.end)
  }, u = [
    // Take the `labelImageMarker` (now `data`, the `!`)
    t[e + 1],
    t[e + 2],
    ["enter", r, n],
    // The `[`
    t[e + 3],
    t[e + 4],
    // The `^`.
    ["enter", o, n],
    ["exit", o, n],
    // Everything in between.
    ["enter", a, n],
    ["enter", i, n],
    ["exit", i, n],
    ["exit", a, n],
    // The ending (`]`, properly parsed and labelled).
    t[t.length - 2],
    t[t.length - 1],
    ["exit", r, n]
  ];
  return t.splice(e, t.length - e + 1, ...u), t;
}
function je(t, n, e) {
  const r = this, o = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let a = 0, i;
  return u;
  function u(l) {
    return t.enter("gfmFootnoteCall"), t.enter("gfmFootnoteCallLabelMarker"), t.consume(l), t.exit("gfmFootnoteCallLabelMarker"), s;
  }
  function s(l) {
    return l !== 94 ? e(l) : (t.enter("gfmFootnoteCallMarker"), t.consume(l), t.exit("gfmFootnoteCallMarker"), t.enter("gfmFootnoteCallString"), t.enter("chunkString").contentType = "string", c);
  }
  function c(l) {
    if (
      // Too long.
      a > 999 || // Closing brace with nothing.
      l === 93 && !i || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      l === null || l === 91 || A(l)
    )
      return e(l);
    if (l === 93) {
      t.exit("chunkString");
      const g = t.exit("gfmFootnoteCallString");
      return o.includes(j(r.sliceSerialize(g))) ? (t.enter("gfmFootnoteCallLabelMarker"), t.consume(l), t.exit("gfmFootnoteCallLabelMarker"), t.exit("gfmFootnoteCall"), n) : e(l);
    }
    return A(l) || (i = !0), a++, t.consume(l), l === 92 ? m : c;
  }
  function m(l) {
    return l === 91 || l === 92 || l === 93 ? (t.consume(l), a++, c) : c(l);
  }
}
function _e(t, n, e) {
  const r = this, o = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let a, i = 0, u;
  return s;
  function s(h) {
    return t.enter("gfmFootnoteDefinition")._container = !0, t.enter("gfmFootnoteDefinitionLabel"), t.enter("gfmFootnoteDefinitionLabelMarker"), t.consume(h), t.exit("gfmFootnoteDefinitionLabelMarker"), c;
  }
  function c(h) {
    return h === 94 ? (t.enter("gfmFootnoteDefinitionMarker"), t.consume(h), t.exit("gfmFootnoteDefinitionMarker"), t.enter("gfmFootnoteDefinitionLabelString"), t.enter("chunkString").contentType = "string", m) : e(h);
  }
  function m(h) {
    if (
      // Too long.
      i > 999 || // Closing brace with nothing.
      h === 93 && !u || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      h === null || h === 91 || A(h)
    )
      return e(h);
    if (h === 93) {
      t.exit("chunkString");
      const b = t.exit("gfmFootnoteDefinitionLabelString");
      return a = j(r.sliceSerialize(b)), t.enter("gfmFootnoteDefinitionLabelMarker"), t.consume(h), t.exit("gfmFootnoteDefinitionLabelMarker"), t.exit("gfmFootnoteDefinitionLabel"), g;
    }
    return A(h) || (u = !0), i++, t.consume(h), h === 92 ? l : m;
  }
  function l(h) {
    return h === 91 || h === 92 || h === 93 ? (t.consume(h), i++, m) : m(h);
  }
  function g(h) {
    return h === 58 ? (t.enter("definitionMarker"), t.consume(h), t.exit("definitionMarker"), o.includes(a) || o.push(a), L(t, k, "gfmFootnoteDefinitionWhitespace")) : e(h);
  }
  function k(h) {
    return n(h);
  }
}
function ve(t, n, e) {
  return t.check(wt, n, t.attempt(Ee, n, e));
}
function Be(t) {
  t.exit("gfmFootnoteDefinition");
}
function We(t, n, e) {
  const r = this;
  return L(t, o, "gfmFootnoteDefinitionIndent", 5);
  function o(a) {
    const i = r.events[r.events.length - 1];
    return i && i[1].type === "gfmFootnoteDefinitionIndent" && i[2].sliceSerialize(i[1], !0).length === 4 ? n(a) : e(a);
  }
}
function He(t) {
  let e = (t || {}).singleTilde;
  const r = {
    name: "strikethrough",
    tokenize: a,
    resolveAll: o
  };
  return e == null && (e = !0), {
    text: {
      126: r
    },
    insideSpan: {
      null: [r]
    },
    attentionMarkers: {
      null: [126]
    }
  };
  function o(i, u) {
    let s = -1;
    for (; ++s < i.length; )
      if (i[s][0] === "enter" && i[s][1].type === "strikethroughSequenceTemporary" && i[s][1]._close) {
        let c = s;
        for (; c--; )
          if (i[c][0] === "exit" && i[c][1].type === "strikethroughSequenceTemporary" && i[c][1]._open && // If the sizes are the same:
          i[s][1].end.offset - i[s][1].start.offset === i[c][1].end.offset - i[c][1].start.offset) {
            i[s][1].type = "strikethroughSequence", i[c][1].type = "strikethroughSequence";
            const m = {
              type: "strikethrough",
              start: Object.assign({}, i[c][1].start),
              end: Object.assign({}, i[s][1].end)
            }, l = {
              type: "strikethroughText",
              start: Object.assign({}, i[c][1].end),
              end: Object.assign({}, i[s][1].start)
            }, g = [["enter", m, u], ["enter", i[c][1], u], ["exit", i[c][1], u], ["enter", l, u]], k = u.parser.constructs.insideSpan.null;
            k && W(g, g.length, 0, xt(k, i.slice(c + 1, s), u)), W(g, g.length, 0, [["exit", l, u], ["enter", i[s][1], u], ["exit", i[s][1], u], ["exit", m, u]]), W(i, c - 1, s - c + 3, g), s = c + g.length - 2;
            break;
          }
      }
    for (s = -1; ++s < i.length; )
      i[s][1].type === "strikethroughSequenceTemporary" && (i[s][1].type = "data");
    return i;
  }
  function a(i, u, s) {
    const c = this.previous, m = this.events;
    let l = 0;
    return g;
    function g(h) {
      return c === 126 && m[m.length - 1][1].type !== "characterEscape" ? s(h) : (i.enter("strikethroughSequenceTemporary"), k(h));
    }
    function k(h) {
      const b = Y(c);
      if (h === 126)
        return l > 1 ? s(h) : (i.consume(h), l++, k);
      if (l < 2 && !e) return s(h);
      const w = i.exit("strikethroughSequenceTemporary"), p = Y(h);
      return w._open = !p || p === 2 && !!b, w._close = !b || b === 2 && !!p, u(h);
    }
  }
}
class Ve {
  /**
   * Create a new edit map.
   */
  constructor() {
    this.map = [];
  }
  /**
   * Create an edit: a remove and/or add at a certain place.
   *
   * @param {number} index
   * @param {number} remove
   * @param {Array<Event>} add
   * @returns {undefined}
   */
  add(n, e, r) {
    qe(this, n, e, r);
  }
  // To do: add this when moving to `micromark`.
  // /**
  //  * Create an edit: but insert `add` before existing additions.
  //  *
  //  * @param {number} index
  //  * @param {number} remove
  //  * @param {Array<Event>} add
  //  * @returns {undefined}
  //  */
  // addBefore(index, remove, add) {
  //   addImplementation(this, index, remove, add, true)
  // }
  /**
   * Done, change the events.
   *
   * @param {Array<Event>} events
   * @returns {undefined}
   */
  consume(n) {
    if (this.map.sort(function(a, i) {
      return a[0] - i[0];
    }), this.map.length === 0)
      return;
    let e = this.map.length;
    const r = [];
    for (; e > 0; )
      e -= 1, r.push(n.slice(this.map[e][0] + this.map[e][1]), this.map[e][2]), n.length = this.map[e][0];
    r.push(n.slice()), n.length = 0;
    let o = r.pop();
    for (; o; ) {
      for (const a of o)
        n.push(a);
      o = r.pop();
    }
    this.map.length = 0;
  }
}
function qe(t, n, e, r) {
  let o = 0;
  if (!(e === 0 && r.length === 0)) {
    for (; o < t.map.length; ) {
      if (t.map[o][0] === n) {
        t.map[o][1] += e, t.map[o][2].push(...r);
        return;
      }
      o += 1;
    }
    t.map.push([n, e, r]);
  }
}
function Ue(t, n) {
  let e = !1;
  const r = [];
  for (; n < t.length; ) {
    const o = t[n];
    if (e) {
      if (o[0] === "enter")
        o[1].type === "tableContent" && r.push(t[n + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
      else if (o[1].type === "tableContent") {
        if (t[n - 1][1].type === "tableDelimiterMarker") {
          const a = r.length - 1;
          r[a] = r[a] === "left" ? "center" : "right";
        }
      } else if (o[1].type === "tableDelimiterRow")
        break;
    } else o[0] === "enter" && o[1].type === "tableDelimiterRow" && (e = !0);
    n += 1;
  }
  return r;
}
function Ge() {
  return {
    flow: {
      null: {
        name: "table",
        tokenize: $e,
        resolveAll: Ne
      }
    }
  };
}
function $e(t, n, e) {
  const r = this;
  let o = 0, a = 0, i;
  return u;
  function u(f) {
    let I = r.events.length - 1;
    for (; I > -1; ) {
      const X = r.events[I][1].type;
      if (X === "lineEnding" || // Note: markdown-rs uses `whitespace` instead of `linePrefix`
      X === "linePrefix") I--;
      else break;
    }
    const Q = I > -1 ? r.events[I][1].type : null, J = Q === "tableHead" || Q === "tableRow" ? C : s;
    return J === C && r.parser.lazy[r.now().line] ? e(f) : J(f);
  }
  function s(f) {
    return t.enter("tableHead"), t.enter("tableRow"), c(f);
  }
  function c(f) {
    return f === 124 || (i = !0, a += 1), m(f);
  }
  function m(f) {
    return f === null ? e(f) : P(f) ? a > 1 ? (a = 0, r.interrupt = !0, t.exit("tableRow"), t.enter("lineEnding"), t.consume(f), t.exit("lineEnding"), k) : e(f) : T(f) ? L(t, m, "whitespace")(f) : (a += 1, i && (i = !1, o += 1), f === 124 ? (t.enter("tableCellDivider"), t.consume(f), t.exit("tableCellDivider"), i = !0, m) : (t.enter("data"), l(f)));
  }
  function l(f) {
    return f === null || f === 124 || A(f) ? (t.exit("data"), m(f)) : (t.consume(f), f === 92 ? g : l);
  }
  function g(f) {
    return f === 92 || f === 124 ? (t.consume(f), l) : l(f);
  }
  function k(f) {
    return r.interrupt = !1, r.parser.lazy[r.now().line] ? e(f) : (t.enter("tableDelimiterRow"), i = !1, T(f) ? L(t, h, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(f) : h(f));
  }
  function h(f) {
    return f === 45 || f === 58 ? w(f) : f === 124 ? (i = !0, t.enter("tableCellDivider"), t.consume(f), t.exit("tableCellDivider"), b) : D(f);
  }
  function b(f) {
    return T(f) ? L(t, w, "whitespace")(f) : w(f);
  }
  function w(f) {
    return f === 58 ? (a += 1, i = !0, t.enter("tableDelimiterMarker"), t.consume(f), t.exit("tableDelimiterMarker"), p) : f === 45 ? (a += 1, p(f)) : f === null || P(f) ? d(f) : D(f);
  }
  function p(f) {
    return f === 45 ? (t.enter("tableDelimiterFiller"), x(f)) : D(f);
  }
  function x(f) {
    return f === 45 ? (t.consume(f), x) : f === 58 ? (i = !0, t.exit("tableDelimiterFiller"), t.enter("tableDelimiterMarker"), t.consume(f), t.exit("tableDelimiterMarker"), y) : (t.exit("tableDelimiterFiller"), y(f));
  }
  function y(f) {
    return T(f) ? L(t, d, "whitespace")(f) : d(f);
  }
  function d(f) {
    return f === 124 ? h(f) : f === null || P(f) ? !i || o !== a ? D(f) : (t.exit("tableDelimiterRow"), t.exit("tableHead"), n(f)) : D(f);
  }
  function D(f) {
    return e(f);
  }
  function C(f) {
    return t.enter("tableRow"), _(f);
  }
  function _(f) {
    return f === 124 ? (t.enter("tableCellDivider"), t.consume(f), t.exit("tableCellDivider"), _) : f === null || P(f) ? (t.exit("tableRow"), n(f)) : T(f) ? L(t, _, "whitespace")(f) : (t.enter("data"), v(f));
  }
  function v(f) {
    return f === null || f === 124 || A(f) ? (t.exit("data"), _(f)) : (t.consume(f), f === 92 ? bt : v);
  }
  function bt(f) {
    return f === 92 || f === 124 ? (t.consume(f), v) : v(f);
  }
}
function Ne(t, n) {
  let e = -1, r = !0, o = 0, a = [0, 0, 0, 0], i = [0, 0, 0, 0], u = !1, s = 0, c, m, l;
  const g = new Ve();
  for (; ++e < t.length; ) {
    const k = t[e], h = k[1];
    k[0] === "enter" ? h.type === "tableHead" ? (u = !1, s !== 0 && (it(g, n, s, c, m), m = void 0, s = 0), c = {
      type: "table",
      start: Object.assign({}, h.start),
      // Note: correct end is set later.
      end: Object.assign({}, h.end)
    }, g.add(e, 0, [["enter", c, n]])) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (r = !0, l = void 0, a = [0, 0, 0, 0], i = [0, e + 1, 0, 0], u && (u = !1, m = {
      type: "tableBody",
      start: Object.assign({}, h.start),
      // Note: correct end is set later.
      end: Object.assign({}, h.end)
    }, g.add(e, 0, [["enter", m, n]])), o = h.type === "tableDelimiterRow" ? 2 : m ? 3 : 1) : o && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") ? (r = !1, i[2] === 0 && (a[1] !== 0 && (i[0] = i[1], l = B(g, n, a, o, void 0, l), a = [0, 0, 0, 0]), i[2] = e)) : h.type === "tableCellDivider" && (r ? r = !1 : (a[1] !== 0 && (i[0] = i[1], l = B(g, n, a, o, void 0, l)), a = i, i = [a[1], e, 0, 0])) : h.type === "tableHead" ? (u = !0, s = e) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (s = e, a[1] !== 0 ? (i[0] = i[1], l = B(g, n, a, o, e, l)) : i[1] !== 0 && (l = B(g, n, i, o, e, l)), o = 0) : o && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") && (i[3] = e);
  }
  for (s !== 0 && it(g, n, s, c, m), g.consume(n.events), e = -1; ++e < n.events.length; ) {
    const k = n.events[e];
    k[0] === "enter" && k[1].type === "table" && (k[1]._align = Ue(n.events, e));
  }
  return t;
}
function B(t, n, e, r, o, a) {
  const i = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData", u = "tableContent";
  e[0] !== 0 && (a.end = Object.assign({}, M(n.events, e[0])), t.add(e[0], 0, [["exit", a, n]]));
  const s = M(n.events, e[1]);
  if (a = {
    type: i,
    start: Object.assign({}, s),
    // Note: correct end is set later.
    end: Object.assign({}, s)
  }, t.add(e[1], 0, [["enter", a, n]]), e[2] !== 0) {
    const c = M(n.events, e[2]), m = M(n.events, e[3]), l = {
      type: u,
      start: Object.assign({}, c),
      end: Object.assign({}, m)
    };
    if (t.add(e[2], 0, [["enter", l, n]]), r !== 2) {
      const g = n.events[e[2]], k = n.events[e[3]];
      if (g[1].end = Object.assign({}, k[1].end), g[1].type = "chunkText", g[1].contentType = "text", e[3] > e[2] + 1) {
        const h = e[2] + 1, b = e[3] - e[2] - 1;
        t.add(h, b, []);
      }
    }
    t.add(e[3] + 1, 0, [["exit", l, n]]);
  }
  return o !== void 0 && (a.end = Object.assign({}, M(n.events, o)), t.add(o, 0, [["exit", a, n]]), a = void 0), a;
}
function it(t, n, e, r, o) {
  const a = [], i = M(n.events, e);
  o && (o.end = Object.assign({}, i), a.push(["exit", o, n])), r.end = Object.assign({}, i), a.push(["exit", r, n]), t.add(e + 1, 0, a);
}
function M(t, n) {
  const e = t[n], r = e[0] === "enter" ? "start" : "end";
  return e[1][r];
}
const Ze = {
  name: "tasklistCheck",
  tokenize: Je
};
function Qe() {
  return {
    text: {
      91: Ze
    }
  };
}
function Je(t, n, e) {
  const r = this;
  return o;
  function o(s) {
    return (
      // Exit if there’s stuff before.
      r.previous !== null || // Exit if not in the first content that is the first child of a list
      // item.
      !r._gfmTasklistFirstContentOfListItem ? e(s) : (t.enter("taskListCheck"), t.enter("taskListCheckMarker"), t.consume(s), t.exit("taskListCheckMarker"), a)
    );
  }
  function a(s) {
    return A(s) ? (t.enter("taskListCheckValueUnchecked"), t.consume(s), t.exit("taskListCheckValueUnchecked"), i) : s === 88 || s === 120 ? (t.enter("taskListCheckValueChecked"), t.consume(s), t.exit("taskListCheckValueChecked"), i) : e(s);
  }
  function i(s) {
    return s === 93 ? (t.enter("taskListCheckMarker"), t.consume(s), t.exit("taskListCheckMarker"), t.exit("taskListCheck"), u) : e(s);
  }
  function u(s) {
    return P(s) ? n(s) : T(s) ? t.check({
      tokenize: Xe
    }, n, e)(s) : e(s);
  }
}
function Xe(t, n, e) {
  return L(t, r, "whitespace");
  function r(o) {
    return o === null ? e(o) : n(o);
  }
}
function Ye(t) {
  return yt([
    de(),
    Ie(),
    He(t),
    Ge(),
    Qe()
  ]);
}
const Ke = {};
function un(t) {
  const n = (
    /** @type {Processor<Root>} */
    this
  ), e = t || Ke, r = n.data(), o = r.micromarkExtensions || (r.micromarkExtensions = []), a = r.fromMarkdownExtensions || (r.fromMarkdownExtensions = []), i = r.toMarkdownExtensions || (r.toMarkdownExtensions = []);
  o.push(Ye(e)), a.push(xe()), i.push(ye(e));
}
export {
  un as default
};
