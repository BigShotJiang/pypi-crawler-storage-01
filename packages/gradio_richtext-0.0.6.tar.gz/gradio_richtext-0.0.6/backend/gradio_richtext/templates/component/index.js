import { I as f } from "./Index-DAWbLH7y.js";
export {
  f as default
};
