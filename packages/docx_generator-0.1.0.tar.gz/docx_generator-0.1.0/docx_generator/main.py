import sys
import requests
from io import BytesIO
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt

def generate_docx(input_text: str) -> BytesIO:
    """生成带居中楷体段落的Word文档"""
    doc = Document()
    for paragraph_text in input_text.split('\n'):
        if paragraph_text.strip():  # 跳过空行
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(paragraph_text.strip())
            run.font.name = '楷体'
            run.font.size = Pt(12)
    
    output = BytesIO()
    doc.save(output)
    output.seek(0)
    return output

def upload_to_tmp(file_stream: BytesIO, filename: str = "document.docx") -> str:
    """上传文档到临时文件服务"""
    api_url = "https://tmpfiles.org/api/v1/upload"
    files = {'file': (filename, file_stream, 
                     'application/vnd.openxmlformats-officedocument.wordprocessingml.document')}
    try:
        response = requests.post(api_url, files=files)
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success' and 'data' in data and 'url' in data['data']:
                return data['data']['url']
        return "上传失败"
    except Exception:
        return "上传失败"

def main():
    # 从标准输入读取数据
    input_data = sys.stdin.read()
    if not input_data.strip():
        return {"output": "错误：输入为空"}
    
    # 生成并上传文档
    doc_stream = generate_docx(input_data)
    result_url = upload_to_tmp(doc_stream)
    doc_stream.close()
    
    print(result_url)  # 输出到stdout供平台捕获

if __name__ == "__main__":
    main()