DROP INDEX random_chunks_metadata_order;
DROP INDEX random_chunks_metadata_order2;
DROP TABLE chunks_metadata;
DROP INDEX lookup_submission_by_metadata;
DROP TABLE submissions_metadata;
