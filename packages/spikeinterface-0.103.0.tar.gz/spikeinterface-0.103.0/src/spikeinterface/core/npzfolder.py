"""
This file is for backwards compatibility with the old npz folder structure.
"""

from __future__ import annotations


from .sortingfolder import NpzFolderSorting
