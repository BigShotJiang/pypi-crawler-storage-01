from .deepinterpolation import DeepInterpolatedRecording, deepinterpolate
from .train import train_deepinterpolation
