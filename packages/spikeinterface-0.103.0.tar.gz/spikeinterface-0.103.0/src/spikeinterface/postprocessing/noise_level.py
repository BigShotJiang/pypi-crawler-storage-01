# "noise_levels" extensions is now in core
# this is kept name space compatibility but should be removed soon
from spikeinterface.core.analyzer_extension_core import ComputeNoiseLevels, compute_noise_levels
