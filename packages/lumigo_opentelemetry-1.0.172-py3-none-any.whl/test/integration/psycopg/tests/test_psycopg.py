# importing the test class from the shared_tests.py file will run the tests
from test.integration.shared.psycopg.shared_tests import TestPsycopgSpans  # noqa
