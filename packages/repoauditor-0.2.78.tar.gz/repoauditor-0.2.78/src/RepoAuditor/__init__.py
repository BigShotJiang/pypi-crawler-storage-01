APP_NAME = "RepoAuditor"

# Note that the default value below will be used until the value
# here is explicitly updated by the Continuous Integration system.
__version__ = "0.2.78"
