foo="$1"
bar="$foo"
result=$("$bar")