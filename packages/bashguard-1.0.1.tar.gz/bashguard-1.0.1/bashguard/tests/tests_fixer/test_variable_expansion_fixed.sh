#!/bin/bash

PATH=/usr/bin

FOO="$1"
BAR="$2"

echo "$FOO" && echo "$BAR" && echo "$FOO" && echo "$BAR"
