foo="$1"

result=$("$foo")

result=`"$gio"`

eval "$foo"

source "$foo"
