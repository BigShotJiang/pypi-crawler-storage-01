"""
BashGuard - A static analysis tool for Bash scripts.
"""

from importlib.metadata import version
__version__ = version("bashguard")
