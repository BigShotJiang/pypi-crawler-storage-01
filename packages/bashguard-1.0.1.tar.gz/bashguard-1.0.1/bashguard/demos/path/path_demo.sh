#!/bin/bash

fortune