from llama_index.readers.couchbase.base import CouchbaseReader

__all__ = ["CouchbaseReader"]
