from llama_index.vector_stores.deeplake.base import DeepLakeVectorStore

__all__ = ["DeepLakeVectorStore"]
