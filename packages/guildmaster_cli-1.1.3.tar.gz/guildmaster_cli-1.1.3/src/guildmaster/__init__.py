"""
This is the __init__.py file for the GuildMaster package.
It initializes the package and sets the version.
"""

__version__ = "1.1.3"
