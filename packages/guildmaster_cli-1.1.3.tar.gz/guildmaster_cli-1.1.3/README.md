# GuildMaster CLI

🚧 This repository is still in progress, and won't be complete until for a little while. 🚧

command to bump version:

bumpver update --patch
bumpver update --major
bumpver update --minor
