# ⚠️ Known Limitations

- YAML comments are stripped during rendering
