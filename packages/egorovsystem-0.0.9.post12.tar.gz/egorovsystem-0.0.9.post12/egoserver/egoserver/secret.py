SECRET_KEY = 'django-insecure-(sqtddlvbbbg9*s@($a*uubagzkve)8mx+3ol9wyj#lymw5g@f'
