try:
    from fast_array_diff import remove_items as subtract_lists
except:
    pass # bruh, idk why this happens on some machines tbh and i aint tryna fix this rn it's 1:40 am