def test_image():
    assert True
