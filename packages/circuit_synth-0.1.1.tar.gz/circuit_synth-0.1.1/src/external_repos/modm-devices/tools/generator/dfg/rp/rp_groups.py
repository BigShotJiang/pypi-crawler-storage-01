# -*- coding: utf-8 -*-
# Copyright (c) 2022, Andrey Kunitsyn
# All rights reserved.

rp_groups = [
    # RP devices
    {"family": ["20"]}
]
