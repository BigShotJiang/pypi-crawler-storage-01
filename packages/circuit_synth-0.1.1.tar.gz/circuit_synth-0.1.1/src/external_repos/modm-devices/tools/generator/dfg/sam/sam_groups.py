# -*- coding: utf-8 -*-
# Copyright (c) 2016, Niklas Hauser
# All rights reserved.

sam_groups = [
    {"series": ["d10", "d11"]},
    {"series": ["d09"]},
    {"series": ["da1"]},
    {"series": ["d20"]},
    {"series": ["d21"]},
    {"series": ["d51", "e51", "e53", "e54"]},
    {"series": ["l21"]},
    {"series": ["l22"]},
    {"series": ["g51", "g53", "g54"]},
    {"series": ["g55"]},
    {"series": ["e70", "s70", "v70", "v71"]},
]
