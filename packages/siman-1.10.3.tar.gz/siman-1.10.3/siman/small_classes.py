# -*- coding: utf-8 -*-
#Copyright Aksyonov D.A
from __future__ import division, unicode_literals, absolute_import 
class empty_struct():
    def __init__(self):
        pass