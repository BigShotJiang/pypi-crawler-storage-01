# LlamaIndex Retrievers Integration: Bm25 Retriever
