# PyCloud OS'e Hoş Geldiniz! 🎉

Bu dosya sizin kişisel masaüstünüzde yer almaktadır.

## Hızlı Başlangıç

- 📁 **Dosyalar**: Dock'taki Dosyalar simgesine tıklayarak dosya yöneticinizi açabilirsiniz
- 💻 **Terminal**: Sistem komutları için terminal uygulamasını kullanın
- 🐍 **Python IDE**: Python geliştirme için IDE'yi açın
- ⚙️ **Ayarlar**: Sistem ayarlarını topbar'daki bulut menüsünden erişebilirsiniz

## Klasörleriniz

- **Belgeler**: Dokümanlarınız için
- **İndirilenler**: İndirilen dosyalar
- **Projeler**: Geliştirme projeleri
- **Resimler**: Görseller ve fotoğraflar

Keyifli kullanımlar! 😊
