"""
Cloud AppStore Core Module
Modern uygulama mağazası çekirdek modülleri
"""

__version__ = "2.0.0"
__author__ = "PyCloud OS Team" 