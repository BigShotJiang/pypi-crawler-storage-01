"""
AppProxy plugin for YAPP - enables app-to-app chaining.
"""

from .plugin import AppProxy

__all__ = ["AppProxy"]