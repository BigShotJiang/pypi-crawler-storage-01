from llama_index.readers.file.slides.base import PptxReader

__all__ = ["PptxReader"]
