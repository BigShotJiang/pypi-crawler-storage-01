"""
PyCon India is India's largest volunteer driven python conference.
"""

def main():
    print("Welcome to PyCon India")

if __name__ == '__main__':
    main()
