from .resource import Dashboard
from .dto import CounterWidgetDto, DashboardDto, TableWidgetDto, MapWidgetDto, MitreWidgetDto, MetricWidgetDto, \
    WidgetDto
