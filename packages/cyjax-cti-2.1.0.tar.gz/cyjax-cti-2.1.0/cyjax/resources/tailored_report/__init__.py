from .resource import TailoredReport
from .dto import TailoredReportDto
