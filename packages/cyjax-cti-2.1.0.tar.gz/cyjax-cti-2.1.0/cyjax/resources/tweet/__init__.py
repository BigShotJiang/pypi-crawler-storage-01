from .resource import Tweet
from .dto import TweetDto
