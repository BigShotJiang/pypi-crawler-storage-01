from .resource import Paste
from .dto import PasteDto
