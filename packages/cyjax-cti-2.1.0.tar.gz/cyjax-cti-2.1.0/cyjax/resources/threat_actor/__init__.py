from .resource import ThreatActor
from .dto import ThreatActorDto
