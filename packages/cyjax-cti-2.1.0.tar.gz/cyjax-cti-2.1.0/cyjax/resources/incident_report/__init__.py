from .resource import IncidentReport
from .dto import IncidentReportDto
