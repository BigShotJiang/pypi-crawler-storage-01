from .resource import MaliciousDomain
from .dto import MaliciousDomainDto
