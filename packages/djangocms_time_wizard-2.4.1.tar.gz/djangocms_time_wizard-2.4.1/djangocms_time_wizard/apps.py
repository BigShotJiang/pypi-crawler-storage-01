from django.apps import AppConfig


class DjangoCMSTimeWizardConfig(AppConfig):
    name = 'djangocms_time_wizard'
    default_auto_field = "django.db.models.AutoField"
