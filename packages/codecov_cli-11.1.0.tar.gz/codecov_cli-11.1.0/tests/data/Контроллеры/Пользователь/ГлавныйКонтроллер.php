// See <https://github.com/codecov/codecov-action/issues/1550>
// Plus, add a bunch of unicode chars in order to trigger
// <https://github.com/codecov/codecov-action/issues/1539>

// µ, ¹², ‘’“”, őá…–🤮🚀¿ 한글 테스트