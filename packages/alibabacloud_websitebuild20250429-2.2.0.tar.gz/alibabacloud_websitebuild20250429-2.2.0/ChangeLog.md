2025-07-23 Version: 2.1.0
- Support API SyncAppInstanceForPartner.


2025-07-10 Version: 2.0.0
- Update API CreateLogoTask: add request parameters LogoVersion.
- Update API CreateLogoTask: delete request parameters Version.


2025-06-25 Version: 1.2.1
- Generated python 2025-04-29 for WebsiteBuild.

2025-06-24 Version: 1.2.0
- Support API CreateLogoTask.
- Support API GetCreateLogoTask.


2025-06-12 Version: 1.1.0
- Support API OperateAppInstanceForPartner.


2025-05-24 Version: 1.0.0
- Generated python 2025-04-29 for WebsiteBuild.

