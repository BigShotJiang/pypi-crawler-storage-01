"""Mock objects test package."""
