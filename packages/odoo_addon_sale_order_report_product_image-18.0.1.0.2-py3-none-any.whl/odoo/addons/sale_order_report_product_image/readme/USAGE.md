- Go to **Sales \> Orders** and print a quotation or sales order. You
  must see the product images in report now.
