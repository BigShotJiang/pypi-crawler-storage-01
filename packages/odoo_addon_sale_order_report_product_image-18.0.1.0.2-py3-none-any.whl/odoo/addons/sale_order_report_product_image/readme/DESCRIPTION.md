This module allows to show product images in sales order report. If
product does not have its image, a generic icon will be displayed.
