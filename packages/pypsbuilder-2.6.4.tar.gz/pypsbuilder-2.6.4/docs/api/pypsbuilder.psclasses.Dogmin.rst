﻿pypsbuilder.psclasses.Dogmin
============================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: Dogmin

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Dogmin.__init__
      ~Dogmin.annotation
      ~Dogmin.label
      ~Dogmin.ptguess
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Dogmin.out
   
   