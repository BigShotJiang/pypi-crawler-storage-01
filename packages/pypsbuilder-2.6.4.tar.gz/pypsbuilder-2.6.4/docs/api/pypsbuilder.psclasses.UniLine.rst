﻿pypsbuilder.psclasses.UniLine
=============================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: UniLine

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UniLine.__init__
      ~UniLine.annotation
      ~UniLine.contains_inv
      ~UniLine.datakeys
      ~UniLine.get_label_point
      ~UniLine.label
      ~UniLine.ptguess
      ~UniLine.shape
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UniLine.connected
      ~UniLine.midix
   
   