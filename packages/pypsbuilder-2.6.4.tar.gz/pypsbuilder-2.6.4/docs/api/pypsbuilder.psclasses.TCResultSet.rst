﻿pypsbuilder.psclasses.TCResultSet
=================================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: TCResultSet

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TCResultSet.__init__
      ~TCResultSet.insert
      ~TCResultSet.ptguess
      ~TCResultSet.rename_phase
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TCResultSet.c
      ~TCResultSet.phases
      ~TCResultSet.variance
      ~TCResultSet.x
      ~TCResultSet.y
   
   