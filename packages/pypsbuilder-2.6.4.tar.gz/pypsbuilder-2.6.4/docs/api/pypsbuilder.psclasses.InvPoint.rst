﻿pypsbuilder.psclasses.InvPoint
==============================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: InvPoint

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~InvPoint.__init__
      ~InvPoint.all_unilines
      ~InvPoint.annotation
      ~InvPoint.datakeys
      ~InvPoint.label
      ~InvPoint.ptguess
      ~InvPoint.shape
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~InvPoint.midix
   
   