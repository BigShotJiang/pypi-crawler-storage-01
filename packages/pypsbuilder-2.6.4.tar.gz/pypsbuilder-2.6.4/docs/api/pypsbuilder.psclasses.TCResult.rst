﻿pypsbuilder.psclasses.TCResult
==============================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: TCResult

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TCResult.__init__
      ~TCResult.from_block
      ~TCResult.rename_phase
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TCResult.phases
   
   