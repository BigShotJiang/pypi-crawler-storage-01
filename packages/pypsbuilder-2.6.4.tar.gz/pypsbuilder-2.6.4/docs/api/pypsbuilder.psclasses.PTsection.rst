﻿pypsbuilder.psclasses.PTsection
===============================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: PTsection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PTsection.__init__
      ~PTsection.add_dogmin
      ~PTsection.add_inv
      ~PTsection.add_uni
      ~PTsection.cleanup_data
      ~PTsection.create_shapes
      ~PTsection.from_file
      ~PTsection.getidinv
      ~PTsection.getiduni
      ~PTsection.read_file
      ~PTsection.show
      ~PTsection.trim_uni
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PTsection.range_shapes
      ~PTsection.ratio
      ~PTsection.type
   
   