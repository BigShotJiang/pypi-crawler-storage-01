﻿pypsbuilder.psclasses.TXsection
===============================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: TXsection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TXsection.__init__
      ~TXsection.add_dogmin
      ~TXsection.add_inv
      ~TXsection.add_uni
      ~TXsection.cleanup_data
      ~TXsection.create_shapes
      ~TXsection.from_file
      ~TXsection.getidinv
      ~TXsection.getiduni
      ~TXsection.read_file
      ~TXsection.show
      ~TXsection.trim_uni
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TXsection.range_shapes
      ~TXsection.ratio
      ~TXsection.type
   
   