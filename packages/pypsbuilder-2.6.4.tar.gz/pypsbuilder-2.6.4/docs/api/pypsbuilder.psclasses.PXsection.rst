﻿pypsbuilder.psclasses.PXsection
===============================

.. currentmodule:: pypsbuilder.psclasses

.. autoclass:: PXsection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PXsection.__init__
      ~PXsection.add_dogmin
      ~PXsection.add_inv
      ~PXsection.add_uni
      ~PXsection.cleanup_data
      ~PXsection.create_shapes
      ~PXsection.from_file
      ~PXsection.getidinv
      ~PXsection.getiduni
      ~PXsection.read_file
      ~PXsection.show
      ~PXsection.trim_uni
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PXsection.range_shapes
      ~PXsection.ratio
      ~PXsection.type
   
   