#!/bin/bash

pyuic6 ptbuilder.ui > ../ui_ptbuilder.py
pyuic6 txbuilder.ui > ../ui_txbuilder.py
pyuic6 pxbuilder.ui > ../ui_pxbuilder.py
pyuic6 adduni.ui > ../ui_adduni.py
pyuic6 addinv.ui > ../ui_addinv.py
pyuic6 uniguess.ui > ../ui_uniguess.py

# do not forget to replace PyQt6 with qtpy in all generated .py files
