# Knights who say... nee?

## Installation

```bash
pip install nee
```

## License

MIT
