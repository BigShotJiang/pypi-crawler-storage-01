EU_BASE_URL = "https://api.cloud.eu.llamaindex.ai"
