"""Main entry point for the ASCOM MCP server."""

from .server_fastmcp import run

if __name__ == "__main__":
    run()
