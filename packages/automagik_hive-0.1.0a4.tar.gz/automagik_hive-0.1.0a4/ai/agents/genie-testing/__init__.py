"""
🧞 Genie Testing - Testing Domain Specialist Agent

Enhanced Agno agent for strategic testing coordination through intelligent
routing to specialized .claude/agents.
"""

from .agent import get_genie_testing

__all__ = ["get_genie_testing"]
