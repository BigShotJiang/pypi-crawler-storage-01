"""Siglis device handlers."""
