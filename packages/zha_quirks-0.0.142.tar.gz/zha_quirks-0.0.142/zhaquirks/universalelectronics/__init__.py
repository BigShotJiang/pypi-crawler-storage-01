"""Module for Universal Electronics devices."""
