"""LDS module."""

MANUFACTURER = "LDS"
