"""Module for Xiaomi Aqara quirks implementations."""
