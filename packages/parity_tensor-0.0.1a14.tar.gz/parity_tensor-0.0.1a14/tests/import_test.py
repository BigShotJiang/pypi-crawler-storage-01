def test_import() -> None:
    from parity_tensor import ParityTensor
    assert isinstance(ParityTensor, type)
