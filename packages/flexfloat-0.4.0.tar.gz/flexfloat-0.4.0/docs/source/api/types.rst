Types Module
============

This module contains type definitions and protocols used throughout FlexFloat.

.. automodule:: flexfloat.types
   :members:
   :undoc-members:
   :show-inheritance:

Type Aliases
============

.. autodata:: flexfloat.types.Number
