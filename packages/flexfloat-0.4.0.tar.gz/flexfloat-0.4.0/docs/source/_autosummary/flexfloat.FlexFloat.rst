﻿flexfloat.FlexFloat
===================

.. currentmodule:: flexfloat

.. autoclass:: FlexFloat