"""MCP Web Automation Server"""
