from setuptools import setup, find_packages

setup(
    name='tsengmodtool',
    version='3.0.4',
    packages=find_packages(),
    include_package_data=True,
    description='完整中文版《貓咪大戰爭》存檔修改工具，林安潔製作',
)
