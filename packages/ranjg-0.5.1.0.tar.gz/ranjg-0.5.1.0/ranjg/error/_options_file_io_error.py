class OptionsFileIOError(Exception):
    """Options file error class.

    This error raises if loading options file is failed.
    """
