class SchemaFileIOError(Exception):
    """Schema file error class.

    This error raises if loading schema file is failed.
    """
