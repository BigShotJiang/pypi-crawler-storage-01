from os.path import expanduser

home = expanduser('~')
home_bismuth = f'{home}\\Bismuth'

print(home, home_bismuth)
