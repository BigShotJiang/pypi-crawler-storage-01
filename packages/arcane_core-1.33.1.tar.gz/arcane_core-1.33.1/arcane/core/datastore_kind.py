USER_OAUTH_CREDENTIAL_KIND = 'user-oauth-credential'
