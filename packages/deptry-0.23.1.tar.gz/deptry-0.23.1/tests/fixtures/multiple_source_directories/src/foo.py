import httpx

from foobar import a_local_method
