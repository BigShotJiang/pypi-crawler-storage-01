import celery

from foobaz import a_local_method
