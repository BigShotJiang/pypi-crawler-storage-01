from src_directory.foo import a_local_method
