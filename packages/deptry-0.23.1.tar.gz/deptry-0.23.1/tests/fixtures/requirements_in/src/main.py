from os import chdir, walk
from pathlib import Path

import black
import click
import h11
import white as w
from urllib3 import contrib
import bs4
import itchiodl
