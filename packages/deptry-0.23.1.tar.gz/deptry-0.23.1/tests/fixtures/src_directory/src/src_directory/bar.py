from src_directory.foo import a_local_method
from foobar import another_local_method
