import httpx


def another_local_method(): ...
