from os import chdir, walk
from pathlib import Path

import flake8
import white as w

from foo import api
