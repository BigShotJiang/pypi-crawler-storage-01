from __future__ import annotations

import logging

logging.getLogger("nbconvert").setLevel(logging.WARNING)
