"""Google Workspace MCP - Google Workspace integration for Model Context Protocol."""

__version__ = "1.0.0"
