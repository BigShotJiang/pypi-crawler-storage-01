# pyreadcon

[![PyPI - Version](https://img.shields.io/pypi/v/pyreadcon.svg)](https://pypi.org/project/pyreadcon)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyreadcon.svg)](https://pypi.org/project/pyreadcon)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pyreadcon
```

## License

`pyreadcon` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
