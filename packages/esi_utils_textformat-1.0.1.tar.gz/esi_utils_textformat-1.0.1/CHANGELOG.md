## main

## 1.0.1 / 2025-08-01

- Added changelog
- Add pyproject.toml
- Put code in src/