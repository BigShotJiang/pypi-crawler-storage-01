#!/usr/bin/env python2

from . import __version__ as version
__version__ 	= version.version
__email__		= "cumulus13@gmail.com"
__author__		= "cumulus13@gmail.com"

from .idm import *