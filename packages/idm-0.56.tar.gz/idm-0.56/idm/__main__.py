from . import idm

def usage():
	c = idm.IDMan()
	c.usage()
