class GeoDB:
    db_type = "geo_db"


class GraphDB:
    db_type = "graph_db"


class KVDB:
    db_type = "kv_db"


class NoSQLDB:
    db_type = "nosql_db"


class RelationalDB:
    db_type = "relational_db"


class TimeSeriesDB:
    db_type = "time_series_db"


class VectorDB:
    db_type = "vector_db"
