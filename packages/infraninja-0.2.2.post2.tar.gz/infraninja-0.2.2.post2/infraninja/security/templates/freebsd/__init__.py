# FreeBSD security templates
