from enum import Enum

class Events(Enum):
    CLICKED = "clicked"
    CHANGED = "changed"
    DESTROY = "destroy"
