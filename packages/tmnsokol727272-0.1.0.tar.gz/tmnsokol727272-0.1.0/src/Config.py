class Config:
    OUTPUT_FOLDER_PATH = "./Output"
    OUTPUT_HEAD_PKL_MODEL_NAME = "head_model_output.pkl"
    OUTPUT_PI_PKL_MODEL_NAME = "pi_model_output.pkl"