# Database Treasure Hunt - pip_install_or_pypi

Great that you have reached here! This is the Official Repository where the source code for the `pip_install_or_pypi` challenge in the Databased Hack&Seek 2025 event is stored.

Here is a clue, To get to the flag, you need to see the source code! How do you do that? Well, figure it out!
All the best!

> Oh by the way, watch out for some frenzy gifts I left for you there!

