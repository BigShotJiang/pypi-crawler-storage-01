module.exports = {
    // launch: {
    //     headless: true,
    // },
    // server: {
    //     command: "/home/blurry/lino/env/bin/python puppeteers/noi/manage.py runserver 127.0.0.1:3000",
    //     launchTimeout: 10000,
    // }
}
