__all__ = [
    "__version__",
]

from .__about__ import __version__
