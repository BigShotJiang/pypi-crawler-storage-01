#!/usr/bin/env python
# -*- coding: utf-8 -*-
from distutils.core import setup

setup(name='simple_pkg',
      packages=['simple_pkg'],
      version='0.1',
      author='Mister Unicodé',
      author_email='mister.unicode@example.tld',
      description='Python package with Unicodé fields',
      long_description='This is a Python package with Unicodé data.',
      )
