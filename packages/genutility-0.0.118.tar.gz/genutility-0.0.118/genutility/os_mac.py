def _filemanager_cmd_mac(path: str) -> str:
    return f'open -R "{path}"'
