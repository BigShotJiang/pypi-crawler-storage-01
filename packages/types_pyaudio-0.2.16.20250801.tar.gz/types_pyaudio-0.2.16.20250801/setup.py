
from setuptools import setup

setup(package_data={'pyaudio-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
