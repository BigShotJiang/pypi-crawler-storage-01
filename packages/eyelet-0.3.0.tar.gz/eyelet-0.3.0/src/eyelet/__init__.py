"""
Eyelet - Hook Orchestration for AI Agents

Thread through the eyelet!
"""

__version__ = "0.3.0"
__author__ = "Brian Morin"

# Defer imports to avoid circular dependencies
__all__ = ["Hook", "HookType", "ToolMatcher"]
