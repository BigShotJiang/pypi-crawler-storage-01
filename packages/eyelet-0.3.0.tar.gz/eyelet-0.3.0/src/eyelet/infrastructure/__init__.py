"""Infrastructure layer - External integrations and persistence"""
