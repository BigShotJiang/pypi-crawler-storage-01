"""Application layer - Use cases and services"""
