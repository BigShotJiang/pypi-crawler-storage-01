"""Domain layer - Core business entities and logic"""
