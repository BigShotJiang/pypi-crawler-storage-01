"""Presentation layer - TUI and visual interfaces"""
