"""Entry point for eyelet when run as a module"""

from eyelet.cli.main import cli

if __name__ == "__main__":
    cli()
