// Copyright (c) 2025 Vantage Compute Corporation.

declare module "*.svg" {
  const content: string;
  export default content;
}
