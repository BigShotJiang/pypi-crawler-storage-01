#
# For backwards compatibility only.
# Prefer installation via setup.cfg and pyproject.toml
from setuptools import setup
setup()

