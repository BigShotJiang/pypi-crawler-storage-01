# -*- coding: utf-8 -*-

from backpack import Collection as BaseCollection


class Collection(BaseCollection):

    pass
