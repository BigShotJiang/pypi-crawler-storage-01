# -*- coding: utf-8 -*-

from .make_command import ModelMakeCommand
