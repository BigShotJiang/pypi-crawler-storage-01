# LlamaIndex Vector_Stores Integration: ClickHouse
