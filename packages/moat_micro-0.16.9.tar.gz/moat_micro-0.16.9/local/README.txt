This directory is intended to contain your configuration files.

Files in this directory are not auto-added to git. You need to use the "-f" option.

