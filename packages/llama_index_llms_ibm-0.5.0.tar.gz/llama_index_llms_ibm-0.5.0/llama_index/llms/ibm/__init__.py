from llama_index.llms.ibm.base import WatsonxLLM


__all__ = ["WatsonxLLM"]
