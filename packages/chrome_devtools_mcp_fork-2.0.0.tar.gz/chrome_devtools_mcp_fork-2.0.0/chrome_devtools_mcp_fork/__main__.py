#!/usr/bin/env python3
"""Module execution entry point for chrome_devtools_mcp_fork."""

from chrome_devtools_mcp_fork.main import main

if __name__ == "__main__":
    main()