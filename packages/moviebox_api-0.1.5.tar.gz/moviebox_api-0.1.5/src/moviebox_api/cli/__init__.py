"""Commandline interface"""

from moviebox_api.cli.interface import main
