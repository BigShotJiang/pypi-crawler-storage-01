# Internal components that are dynamically loaded by the AI Connector
# Listing them here allows for them to use relative imports
__version__ = "1.1.8"
