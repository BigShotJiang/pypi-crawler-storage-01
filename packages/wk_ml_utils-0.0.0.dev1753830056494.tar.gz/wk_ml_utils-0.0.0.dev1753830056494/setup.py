from distutils.core import setup

setup(
    name='wk_ml_utils',
    version='0.0.0.dev1753830056494',
    py_modules=["module"],
)