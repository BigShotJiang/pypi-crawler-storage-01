def hello() -> str:
    return "Hello from fputils!"
