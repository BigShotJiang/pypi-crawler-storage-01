"""
Integration channel app.

See README.md.
"""
