"""
The Degreed Integrated Channel package.
"""

__version__ = "0.1.0"
