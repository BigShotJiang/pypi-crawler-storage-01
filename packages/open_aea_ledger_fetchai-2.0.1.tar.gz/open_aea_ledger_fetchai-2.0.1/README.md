# Fetch.AI crypto plug-in

Fetch.AI crypto plug-in for the AEA framework.

## Install

``` bash
python setup.py install
```

## Run tests

``` bash
python setup.py test
```
