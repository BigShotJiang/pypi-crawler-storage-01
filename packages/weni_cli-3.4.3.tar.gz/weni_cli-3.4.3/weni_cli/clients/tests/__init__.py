"""
Tests for the clients package.
"""
