__version__ = "2.0.0"

from .get_exchange_details import get_exchange_details
