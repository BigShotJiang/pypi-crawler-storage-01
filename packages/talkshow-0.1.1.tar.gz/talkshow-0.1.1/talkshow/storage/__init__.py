"""Data storage components."""

from .json_storage import JSONStorage

__all__ = [
    "JSONStorage",
]