- Create a task based on a risk response: it would be nice if a task can
  automatically be created based on the risk response information.
