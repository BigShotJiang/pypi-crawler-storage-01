With this module you can manage your projects risk using the MOR method.

<https://www.axelos.com/best-practice-solutions/mor/what-is-mor>
