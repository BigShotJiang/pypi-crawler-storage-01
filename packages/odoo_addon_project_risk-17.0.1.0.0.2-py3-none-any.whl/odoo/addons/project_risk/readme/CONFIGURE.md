This module provides a number of default risk categories, but you can
add more at *Project \> Configuration \> Risk Categories*. For risk
response categories you need to go to *Project \> Configuration \> Risk
Response Categories*.
