# Changelog

## [v0.0.6](https://github.com/pmariglia/poke-engine-doubles/releases/tag/v0.0.6) - 2025-07-31

### Refactor

- Evaluation considers other speed modifies when looking at who is faster - ([602d1a9](https://github.com/pmariglia/poke-engine-doubles/commit/602d1a9e0ceb65d2aa2f42e4b2983c4ada3e3de7))

- Python bindings a little less sucky - ([794c77b](https://github.com/pmariglia/poke-engine-doubles/commit/794c77bf7c75b33823b189d7d2471b39ddfa3cd2))

## [v0.0.5](https://github.com/pmariglia/poke-engine-doubles/releases/tag/v0.0.5) - 2025-07-27

### Performance

- Until 50x visits per option are done, choose iteratively - ([8d0f85c](https://github.com/pmariglia/poke-engine-doubles/commit/8d0f85cbe85bd538a773fe92d62a51b127103fbb))

## [v0.0.3](https://github.com/pmariglia/poke-engine-doubles/releases/tag/v0.0.3) - 2025-07-27

### Features
- Python bindings refactor

## [v0.0.0](https://github.com/pmariglia/poke-engine-doubles/releases/tag/v0.0.0) - 2025-04-21

### Features

- Doubles lol