Python bindings for the poke-engine library. Still a work in progress.

For full documentation, see the [poke-engine documentation](https://poke-engine.readthedocs.io/en/latest/).