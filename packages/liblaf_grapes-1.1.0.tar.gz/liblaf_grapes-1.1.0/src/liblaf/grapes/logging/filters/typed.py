import loguru

type FilterLike = "str | loguru.FilterDict | loguru.FilterFunction | None"
