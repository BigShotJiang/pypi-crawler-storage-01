"""
Command-line interface for QuantaThread framework.
"""

from .main import main

__all__ = ['main'] 