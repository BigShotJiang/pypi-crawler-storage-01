"""Contract addresses for the Standard Protocol matching engine."""

matching_engine_addresses = {
    "Mode Mainnet": "0x240aA2c15fBf6F65882A847462b04d5DA51A37Df",
    "Somnia Testnet": "0x4Ca2C768773F6E0e9255da5B4e21ED9BA282B85e",
}
