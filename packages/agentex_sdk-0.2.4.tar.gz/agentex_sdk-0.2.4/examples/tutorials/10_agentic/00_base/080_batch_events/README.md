# [Agentic] Batch Events

This tutorial demonstrates batch event processing and the limitations of the base agentic ACP protocol.

## Official Documentation

[080 Batch Events Base Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/base/batch_events/)
