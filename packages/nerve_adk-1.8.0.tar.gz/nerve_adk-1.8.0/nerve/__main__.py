from nerve import cli


def run() -> None:
    cli.cli()


if __name__ == "__main__":
    cli.cli()
