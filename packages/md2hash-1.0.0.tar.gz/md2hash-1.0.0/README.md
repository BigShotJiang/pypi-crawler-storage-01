# MD2 Hash

A pure Python implementation of the MD2 cryptographic hash function as defined in RFC 1319.

## Installation

```bash
pip install md2-hash