::: extract_favicon.main
