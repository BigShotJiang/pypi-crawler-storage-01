:status: under-construction

Non-realtime Scores
===================

.. self-criticism::

   These docs are still under construction.

Outline:

- what is a session
- what's different from realtime
- core concepts: moments, states, transitions
- rendering & renderables
