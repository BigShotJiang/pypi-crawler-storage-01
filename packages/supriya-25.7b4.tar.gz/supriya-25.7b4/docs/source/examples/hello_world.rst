:status: under-construction

Hello, world!
=============

.. self-criticism::

   These docs are still under construction.

See the :si-icon:`octicons/mark-github-16` :github-tree:`full source code
<examples/hello_world>`.

.. code-block:: bash
   :caption: Invoke the script with ...

   python hello_world.py

.. literalinclude:: ../../../examples/hello_world/hello_world.py
   :caption:
   :pyobject: main
