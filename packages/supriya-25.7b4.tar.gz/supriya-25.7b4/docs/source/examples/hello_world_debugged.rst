:status: under-construction

Hello, world!, debugged
=======================

.. self-criticism::

   These docs are still under construction.

See the :si-icon:`octicons/mark-github-16` :github-tree:`full source code
<examples/hello_world_debugged>`.

.. code-block:: bash
   :caption: Invoke the script with ...

   python hello_world_debugged.py

.. literalinclude:: ../../../examples/hello_world_debugged/hello_world_debugged.py
   :caption:
   :pyobject: play_synths

.. literalinclude:: ../../../examples/hello_world_debugged/hello_world_debugged.py
   :caption:
   :pyobject: stop_synths

.. literalinclude:: ../../../examples/hello_world_debugged/hello_world_debugged.py
   :caption:
   :pyobject: debug

.. literalinclude:: ../../../examples/hello_world_debugged/hello_world_debugged.py
   :caption:
   :pyobject: main
