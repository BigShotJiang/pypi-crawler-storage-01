# TODO List

- [ ] finish documentation
- [ ] write log_image for all loggers
- [ ] support defining series of experiments using ranges or dynamic searches
- [ ] support eval of parameters in the config file
