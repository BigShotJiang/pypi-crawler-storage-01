# sage_setup: distribution = sagemath-tachyon
# delvewheel: patch

from sage.all__sagemath_objects import *

from sage.interfaces.all__sagemath_tachyon import *
from sage.libs.all__sagemath_tachyon import *
