.. _examples:

Examples
========

This is a collection of demos and examples of what can be done with pymsis.
