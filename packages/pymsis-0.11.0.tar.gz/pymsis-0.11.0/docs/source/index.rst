.. include:: ../../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 1
   :hidden:
   
   examples/index
   reference/index
   development/index
   changelog/index
