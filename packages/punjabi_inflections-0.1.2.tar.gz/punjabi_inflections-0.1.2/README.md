# Punjabi Verb Forms

![PyPI](https://img.shields.io/pypi/v/Punjabi-inflections
![Downloads](https://img.shields.io/pypi/dm/Punjabi-inflections)
![Python Versions](https://img.shields.io/pypi/pyversions/Punjabi-inflections)
![License](https://img.shields.io/pypi/l/Punjabi-inflections)

> A Python package for generating inflections of Punjabi verbs written in Shahmukhi script.

---

## 🚀 Installation

```bash
pip install Punjabi-inflections