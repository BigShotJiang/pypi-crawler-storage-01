from .flexistack import Flexistack, flexi_action, flexi_middleware, flexi_plugin, safe_import

__version__ = '0.2.33'
__name__        = "flexistack"
__all__         = ['Flexistack', 'flexi_action', 'flexi_middleware', 'flexi_plugin', 'safe_import']
