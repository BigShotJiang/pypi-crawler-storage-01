# LlamaIndex Llms Integration: Predibase
