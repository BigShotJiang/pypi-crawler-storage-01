from llama_index.llms.predibase.base import PredibaseLLM

__all__ = ["PredibaseLLM"]
