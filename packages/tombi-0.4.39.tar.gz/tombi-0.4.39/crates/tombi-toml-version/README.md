# toml-version

Many crates handle different logic depending on the version of TOML.
To make it easier to resolve dependencies, a crate that only handles the version of TOML is prepared.
