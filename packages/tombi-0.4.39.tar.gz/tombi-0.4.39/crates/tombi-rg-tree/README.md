# Red Green Tree

This crate is inspired by [rowan](https://github.com/rust-analyzer/rowan) of [rust-analyzer](https://github.com/rust-lang/rust-analyzer).

`rg-tree` is a Red Green Trees (also known as Lossless Syntax Trees) for Rust,
which is designed to be fast, safe, and convenient.
