# jack_midi_looper

A jack client which generates MIDI events by beat, not time, using "loops" imported from midi files.
