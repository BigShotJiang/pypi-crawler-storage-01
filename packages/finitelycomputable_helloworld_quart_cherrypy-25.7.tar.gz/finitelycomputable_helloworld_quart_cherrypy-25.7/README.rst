=========================
HelloWorld-Quart-CherryPy
=========================

This application adapts the hello_world endpoint provided in
finitelycomputable.helloworld_cherrypy to be provided in
finitelycomputable.helloworld_quart using the Quart framework.
