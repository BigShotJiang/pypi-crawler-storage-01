=====
Usage
=====

To use Martens in a project::

    import martens
