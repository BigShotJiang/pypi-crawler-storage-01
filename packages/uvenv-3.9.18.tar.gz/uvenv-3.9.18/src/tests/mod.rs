#![expect(dead_code, reason = "This is a tests module.")]
mod shared;
mod special_home_dir;
mod version;
