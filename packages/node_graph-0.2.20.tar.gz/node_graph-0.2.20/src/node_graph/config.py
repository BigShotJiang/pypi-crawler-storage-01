builtin_inputs = [
    {"name": "_wait", "link_limit": 1000000, "metadata": {"arg_type": "none"}}
]
builtin_outputs = [{"name": "_wait"}, {"name": "_outputs"}]
