# sage_setup: distribution = sagemath-symbolics
from sage.rings.function_field.all__sagemath_modules import *
