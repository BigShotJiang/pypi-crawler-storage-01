# __init__.py
# version of the czitools package
__version__ = "0.10.1"
