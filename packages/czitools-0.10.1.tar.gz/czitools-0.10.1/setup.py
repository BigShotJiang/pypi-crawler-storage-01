import setuptools

setuptools.setup(include_package_data=True)
