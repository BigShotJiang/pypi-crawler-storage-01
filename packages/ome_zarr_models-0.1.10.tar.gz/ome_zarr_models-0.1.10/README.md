# ome-zarr-models-py

[![Documentation Status](https://readthedocs.org/projects/ome-zarr-models-py/badge/?version=latest)](https://ome-zarr-models-py.readthedocs.io/en/latest/?badge=latest)
[![Run tests](https://github.com/ome-zarr-models/ome-zarr-models-py/actions/workflows/python-package.yml/badge.svg?branch=main)](https://github.com/ome-zarr-models/ome-zarr-models-py/actions/workflows/python-package.yml)
[![codecov](https://codecov.io/gh/ome-zarr-models/ome-zarr-models-py/graph/badge.svg?token=QDV2J4ZUZ7)](https://codecov.io/gh/ome-zarr-models/ome-zarr-models-py)

A minimal Python package for reading OME-Zarr (meta)data.

See the docs for more info: https://ome-zarr-models-py.readthedocs.io
