# Image

::: ome_zarr_models.v04.image

## Multiscales metadata

::: ome_zarr_models.v04.multiscales

## Coordinate transformation metadata

::: ome_zarr_models.v04.coordinate_transformations

## Axes metadata

::: ome_zarr_models.v04.axes

## OMERO metadata

::: ome_zarr_models.v04.omero
