class ApplicationExecutionError(Exception):
    pass


class DesmanaExecutionError(Exception):
    pass


class GISWellExecutionError(Exception):
    pass


class UDSConnectionError(Exception):
    pass
