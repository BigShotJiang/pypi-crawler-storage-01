from dataclasses import dataclass


@dataclass
class CubeInfo:
    cube_id: int
    cube_name: str
