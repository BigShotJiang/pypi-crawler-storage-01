from dataclasses import dataclass


@dataclass
class Color:
    alpha: int
    red: int
    green: int
    blue: int
