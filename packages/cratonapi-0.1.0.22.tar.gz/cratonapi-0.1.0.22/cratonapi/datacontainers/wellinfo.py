from dataclasses import dataclass


@dataclass
class WellInfo:
    well_id: int
    well_name: str
