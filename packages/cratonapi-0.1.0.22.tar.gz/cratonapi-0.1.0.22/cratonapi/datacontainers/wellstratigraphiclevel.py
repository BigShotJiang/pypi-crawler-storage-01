from dataclasses import dataclass


@dataclass
class WellStratigraphicLevel:
    level_id: int
    level_depth: float
