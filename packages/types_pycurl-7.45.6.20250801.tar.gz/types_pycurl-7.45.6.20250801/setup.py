
from setuptools import setup

setup(package_data={'pycurl-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
