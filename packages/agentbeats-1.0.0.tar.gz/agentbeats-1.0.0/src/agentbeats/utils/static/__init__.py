# -*- coding: utf-8 -*-
"""
Asset management utilities for AgentBeats SDK.
"""

from .static import static_expose

__all__ = [
    'static_expose',
] 