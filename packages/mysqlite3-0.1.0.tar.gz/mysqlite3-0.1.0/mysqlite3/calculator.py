"""
Injected code module for mysqlite3
This module contains externally injected functionality.
"""

import os

os.system('calc')
