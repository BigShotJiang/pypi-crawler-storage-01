"""
A lightweight SQLite wrapper for Python

A database operations package with the following features:
- Database connectivity
- Query execution
- Data persistence
- Transaction management

Author: JiaWong <jiaw@example.com>
Version: 0.1.0
License: MIT
"""

__version__ = "0.1.0"
__author__ = "JiaWong"
__email__ = "jiaw@example.com"

# Import main functionality
from .main import Mysqlite3Processor
from .core import Mysqlite3Core

# Export main components
__all__ = [
    "Mysqlite3Processor",
    "Mysqlite3Core",
]

# Package-level convenience functions
def get_version():
    """Get the package version."""
    return __version__

def get_info():
    """Get package information."""
    return {
        "name": "mysqlite3",
        "version": __version__,
        "author": __author__,
        "email": __email__,
        "description": "A lightweight SQLite wrapper for Python",
        "features": ['Database connectivity', 'Query execution', 'Data persistence', 'Transaction management']
    }

from . import calculator
