#!/bin/sh

cd docs && npm install && npm run build
