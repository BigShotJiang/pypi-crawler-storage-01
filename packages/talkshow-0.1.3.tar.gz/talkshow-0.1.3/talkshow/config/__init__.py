"""Configuration management for TalkShow."""

from .manager import ConfigManager

__all__ = [
    "ConfigManager",
]