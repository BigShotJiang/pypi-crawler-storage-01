class SpeechGenerationError(Exception):
    """Capture Errors related to speech generation."""
    pass
