# meow-uv

Determines if a given string is a valid cat sound.
