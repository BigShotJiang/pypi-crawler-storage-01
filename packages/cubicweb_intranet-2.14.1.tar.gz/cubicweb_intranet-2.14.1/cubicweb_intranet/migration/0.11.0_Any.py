add_relation_definition("Blog", "see_also", "Blog")
