add_cube("book")
