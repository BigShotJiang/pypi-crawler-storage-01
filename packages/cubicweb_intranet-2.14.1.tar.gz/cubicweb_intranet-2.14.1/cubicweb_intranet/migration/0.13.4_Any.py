add_relation_definition("Comment", "comments", "BlogEntry")
drop_relation_definition("Comment", "comments", "Blog")
