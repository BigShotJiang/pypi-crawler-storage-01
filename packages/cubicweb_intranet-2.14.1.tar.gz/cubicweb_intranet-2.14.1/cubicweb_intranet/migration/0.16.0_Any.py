add_relation_definition("Comment", "comments", "Book")
add_relation_definition("Tag", "tags", "Book")
