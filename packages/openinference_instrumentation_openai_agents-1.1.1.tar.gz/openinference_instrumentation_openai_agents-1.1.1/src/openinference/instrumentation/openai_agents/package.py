_instruments = ("openai-agents >= 0.1.0",)
_supports_metrics = False
