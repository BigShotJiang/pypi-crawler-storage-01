__version__ = "1.2.1"  # pragma: no cover
