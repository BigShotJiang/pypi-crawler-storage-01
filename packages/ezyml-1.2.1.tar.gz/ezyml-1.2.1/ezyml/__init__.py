# ezyml/__init__.py

# This file makes the 'ezyml' directory a Python package.

# Import the main class to make it directly accessible to users
from .core import EZTrainer

__version__ = "1.2.1"
__author__ = "Raktim Kalita"
