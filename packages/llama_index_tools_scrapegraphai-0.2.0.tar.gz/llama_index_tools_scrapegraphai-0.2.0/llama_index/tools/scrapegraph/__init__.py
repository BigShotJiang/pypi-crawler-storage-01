from llama_index.tools.scrapegraph.base import ScrapegraphToolSpec

__all__ = ["ScrapegraphToolSpec"]
