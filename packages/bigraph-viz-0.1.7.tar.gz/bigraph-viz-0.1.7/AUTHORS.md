# Authors of Bigraph Viz

The maintainers of the Bigraph-Viz project are:

* Eran Agmon  (@eagmon)
* * Ryan Spangler (@prismofeverything)
