API reference
=============

This page provides an auto-generated summary of Waveform Editor's API. For more details
and examples, refer to the relevant chapters in the main part of the
documentation.

.. autosummary::
   :toctree: generated/
   :recursive:
   :template: custom-module-template.rst

   waveform_editor
  
