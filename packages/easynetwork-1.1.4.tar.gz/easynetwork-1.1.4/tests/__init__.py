from __future__ import annotations

import pytest

pytest.register_assert_rewrite(f"{__package__}.tools")
