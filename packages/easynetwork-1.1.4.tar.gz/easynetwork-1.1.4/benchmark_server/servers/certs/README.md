# Disclaimer

This SSL certificate is not mine. I stole it from [uvloop](https://github.com/MagicStack/uvloop/tree/v0.19.0/tests/certs).

It's boring to create one from scratch.
