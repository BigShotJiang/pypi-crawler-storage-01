# Network Server Performance Benchmarking Toolbench

Here is a kind of modernized fork of [MagicStack's toolbench](https://github.com/MagicStack/vmbench).

This is a solution for **macro** benchmarking of servers supplied by EasyNetwork, with comparisons against the standard library.
