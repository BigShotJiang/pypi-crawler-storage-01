.. Links

.. _UDP: https://en.wikipedia.org/wiki/User_Datagram_Protocol

.. _TCP: https://en.wikipedia.org/wiki/Transmission_Control_Protocol

.. _FTP: https://en.wikipedia.org/wiki/File_Transfer_Protocol

.. _File Transfer Protocol: `FTP`_

.. _Telnet Protocol: https://en.wikipedia.org/wiki/Telnet
