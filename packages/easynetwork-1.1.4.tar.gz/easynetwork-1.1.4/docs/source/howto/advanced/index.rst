**************
Advanced Guide
**************

.. toctree::
   :maxdepth: 1

   serializers
   buffered_serializers
   serializer_combinations
   serializer_composition
   standalone_servers
   multithreaded_servers
