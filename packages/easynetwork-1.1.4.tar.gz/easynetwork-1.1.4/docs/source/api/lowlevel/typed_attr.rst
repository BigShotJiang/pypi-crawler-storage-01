************************
AnyIO's Typed Attributes
************************

.. automodule:: easynetwork.lowlevel.typed_attr
   :members:
