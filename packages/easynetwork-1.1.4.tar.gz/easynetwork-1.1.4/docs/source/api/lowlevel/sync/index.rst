*************************
Low-level synchronous API
*************************

.. automodule:: easynetwork.lowlevel.api_sync

-----

.. toctree::
   :maxdepth: 2

   endpoints
   transports
