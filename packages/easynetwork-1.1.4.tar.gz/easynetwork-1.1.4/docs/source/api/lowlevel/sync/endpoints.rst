*****************
Generic Endpoints
*****************

.. automodule:: easynetwork.lowlevel.api_sync.endpoints

.. contents:: Table of Contents
   :local:

------

Stream Endpoints
================

.. automodule:: easynetwork.lowlevel.api_sync.endpoints.stream
   :members:

Datagram Endpoints
==================

.. automodule:: easynetwork.lowlevel.api_sync.endpoints.datagram
   :members:
