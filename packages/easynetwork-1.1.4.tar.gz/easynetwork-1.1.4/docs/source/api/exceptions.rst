**********
Exceptions
**********

.. automodule:: easynetwork.exceptions
   :members:
