***************
CBOR Serializer
***************

.. automodule:: easynetwork.serializers.cbor

.. autoclass:: CBORSerializer
   :members:

Configuration
=============

.. autoclass:: CBOREncoderConfig
   :members:
   :undoc-members:

.. autoclass:: CBORDecoderConfig
   :members:
   :undoc-members:
