**********************
MessagePack Serializer
**********************

.. automodule:: easynetwork.serializers.msgpack

.. autoclass:: MessagePackSerializer
   :members:

Configuration
=============

.. autoclass:: MessagePackerConfig
   :members:
   :undoc-members:

.. autoclass:: MessageUnpackerConfig
   :members:
   :undoc-members:
