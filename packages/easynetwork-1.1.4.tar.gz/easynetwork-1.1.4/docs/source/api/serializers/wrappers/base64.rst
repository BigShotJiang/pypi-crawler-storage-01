*************************
Base64 Encoder Serializer
*************************

.. automodule:: easynetwork.serializers.wrapper.base64

.. autoclass:: Base64EncoderSerializer
   :members:
   :exclude-members: generate_key

.. automethod:: Base64EncoderSerializer.generate_key
