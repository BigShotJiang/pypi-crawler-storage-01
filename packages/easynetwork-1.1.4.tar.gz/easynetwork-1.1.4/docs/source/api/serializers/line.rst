*****************
String Serializer
*****************

.. automodule:: easynetwork.serializers.line

.. autoclass:: StringLineSerializer
   :members:
