***************
JSON Serializer
***************

.. automodule:: easynetwork.serializers.json

.. autoclass:: JSONSerializer
   :members:

Configuration
=============

.. autoclass:: JSONEncoderConfig
   :members:
   :undoc-members:

.. autoclass:: JSONDecoderConfig
   :members:
   :undoc-members:
