"""
Agents module - AI agents for automated scraping tasks using pydantic-ai
"""

__all__ = []
