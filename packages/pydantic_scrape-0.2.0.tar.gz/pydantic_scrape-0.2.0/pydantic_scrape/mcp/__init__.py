"""MCP servers for pydantic-scrape"""

from .camoufox_server import CamoufoxMCPServer

__all__ = ["CamoufoxMCPServer"]