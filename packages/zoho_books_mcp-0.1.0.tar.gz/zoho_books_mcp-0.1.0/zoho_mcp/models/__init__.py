"""
Zoho Books MCP Integration Server Models

This module contains all the Pydantic models for input and output validation.
"""
