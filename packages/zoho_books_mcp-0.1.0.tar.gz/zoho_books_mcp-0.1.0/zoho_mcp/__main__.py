"""
Entry point for running zoho_mcp as a module.
"""

from zoho_mcp import main

if __name__ == "__main__":
    main()
