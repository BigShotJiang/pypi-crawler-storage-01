"""
Tests for Zoho Books MCP tools.
"""