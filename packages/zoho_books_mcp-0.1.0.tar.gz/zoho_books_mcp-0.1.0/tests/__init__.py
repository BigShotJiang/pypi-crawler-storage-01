"""
Tests for Zoho Books MCP Integration Server.
"""