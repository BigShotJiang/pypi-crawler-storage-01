from setuptools import setup
from setuptools.command.install import install

setup(
  name='tasker',
  url='https://github.com/monotone-the-musical/tasker',
  author='mtm',
  author_email='monotone.the.musical@gmail.com',
  scripts=['files/tasker.py', 'files/tasker'],
)
