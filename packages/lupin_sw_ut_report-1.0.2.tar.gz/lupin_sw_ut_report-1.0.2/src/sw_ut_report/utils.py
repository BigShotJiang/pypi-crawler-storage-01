def remove_excess_space(line: str) -> str:
    return " ".join(line.split())
