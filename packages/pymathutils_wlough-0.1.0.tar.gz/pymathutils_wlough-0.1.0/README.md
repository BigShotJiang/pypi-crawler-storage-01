# MathUtils

mathematical utilities with C++ backend for high-performance numerical computations.

