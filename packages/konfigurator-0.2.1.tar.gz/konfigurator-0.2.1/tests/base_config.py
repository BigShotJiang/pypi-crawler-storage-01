from konfigurator import FieldReference

class_config_2 = dict(
    type="tests.test_utils.MyBaseTestClass",
    name=FieldReference("test_instance_2"),
)
