"""MCP Calculator Demo - A Model Context Protocol server providing calculator functionality."""

__version__ = "0.1.0" 