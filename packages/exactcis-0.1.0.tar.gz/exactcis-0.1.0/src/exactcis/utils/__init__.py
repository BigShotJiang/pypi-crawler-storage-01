"""
Utility modules for the ExactCIs package.
"""

from exactcis.utils.stats import normal_quantile

__all__ = ["normal_quantile"]
