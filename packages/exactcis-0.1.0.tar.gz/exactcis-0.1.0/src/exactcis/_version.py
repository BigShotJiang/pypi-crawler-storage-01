# Version information for exactcis
# This file should match the version in pyproject.toml and __init__.py
__version__ = '0.1.0'
