Analysis Reports
===============

This section contains analysis reports and comparisons of different confidence interval methods.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   logical_comparison_report
   comparison_tables
   comparison_analysis_summary