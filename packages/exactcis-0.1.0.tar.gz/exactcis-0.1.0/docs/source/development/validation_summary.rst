Validation Summary
=================

This page includes the validation summary documentation from the analysis/literature directory.

.. mdinclude:: ../../../analysis/literature/validation_summary.md