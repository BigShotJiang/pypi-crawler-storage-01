Architecture
===========

This page includes the architecture documentation from the docs/development directory.

.. mdinclude:: ../../_markdown/development/architecture.md