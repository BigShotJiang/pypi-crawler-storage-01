Literature Review
================

This section contains literature reviews and background information relevant to the ExactCIs package.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   literature
   method_comparison_analysis