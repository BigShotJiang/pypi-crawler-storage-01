Methodology
===========

This page includes the methodology documentation from the analysis/literature directory.

.. mdinclude:: ../../_markdown/literature/methodology.md