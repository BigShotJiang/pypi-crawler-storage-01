This data set contains roughly 44,000 examples of robot pushing motions,
including one training set (train) and two test sets of previously seen
(testseen) and unseen (testnovel) objects. This is the small 64x64 version.
