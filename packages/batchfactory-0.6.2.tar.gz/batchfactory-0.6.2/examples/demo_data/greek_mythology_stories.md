# Greek Mythology Stories
Prometheus Steals Fire  
The Odyssey  
The Trojan War  
Pandora's Box  
Helen and the Golden Apple  
Achilles' Heel  
Achilles and the Tortoise  
Antaeus and the Earth  
Oedipus Rex  
Perseus and Medusa  
The Twelve Labors of Heracles  
The Fall of Icarus  
Orpheus and Eurydice  
Jason and the Golden Fleece  
Medea’s Revenge  
Theseus and the Minotaur  
Theseus and the Underworld  
Pygmalion and Galatea  
Ship of Theseus  
Endymion and Selene  
Sisyphus and the Boulder  
The Sword of Damocles  
The Abduction of Europa  
Io and Zeus  
Laurels of Daphne  
Phaethon and the Sun Chariot  
Echo  
Narcissus  
The Legend of Marathon  
Olympia and the Olympic Games  
The Midas Touch  
Arachne Turned into a Spider  
Hera’s Wrath  
Adonis' Ephemeral Beauty  
Cupid's Arrow  
Hercules at the Crossroads  
Tantalus' Torment  
Niobe's Tears  
Daedalus' Labyrinth  
Cassandra's Prophecy  
Apples of the Hesperides  
Bellerophon and Pegasus  
The Riddle of the Sphinx  
The Sirens' Song  
The Gordian Knot  
Actaeon's Fate  
Atlas Bearing the Sky  
The River Lethe  
The Moirai (Fates)  
Medusa's Gaze  
The Castration of Uranus  
The Birth from Chaos  
Cronus Devours His Children  
Titanomachy  
The Birth of the Olympian Gods
