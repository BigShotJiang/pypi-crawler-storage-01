from globalgenie.storage.mongodb import MongoDbStorage as MongoDbWorkflowStorage  # noqa: F401
