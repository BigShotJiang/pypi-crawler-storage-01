from globalgenie.app.slack.app import SlackAPI

__all__ = ["SlackAPI"]
