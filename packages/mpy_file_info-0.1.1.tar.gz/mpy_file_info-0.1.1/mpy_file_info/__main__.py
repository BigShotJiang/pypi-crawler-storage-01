from mpy_file_info.mpy_tool import main

if __name__ == "__main__":
    main()
