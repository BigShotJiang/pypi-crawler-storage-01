% AUTO-GENERATED FILE -- DO NOT EDIT!

# auth.thread

## Module: {mod}`zmq.auth.thread`

```{eval-rst}
.. automodule:: zmq.auth.thread
```

```{currentmodule} zmq.auth.thread
```

## Classes

### {class}`ThreadAuthenticator`

```{eval-rst}
.. autoclass:: ThreadAuthenticator
  :members:
  :undoc-members:
  :inherited-members:
```

```{eval-rst}
.. autoclass:: AuthenticationThread
```
