from django.contrib import admin

from .models import Uri

admin.site.register(Uri)
