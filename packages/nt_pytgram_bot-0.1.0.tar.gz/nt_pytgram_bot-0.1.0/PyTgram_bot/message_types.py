class Update:
    def __init__(self, update_id, message):
        self.update_id = update_id
        self.message = message
