from .core import BeamGit
import gitlab



class BeamGitLab(BeamGit):
    pass