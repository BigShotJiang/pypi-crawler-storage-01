from .core import BeamGit


class BeamGitHub(BeamGit):
    pass
