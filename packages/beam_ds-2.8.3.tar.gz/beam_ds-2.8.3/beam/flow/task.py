from ..base import BeamBase




class BeamTask(BeamBase):
    