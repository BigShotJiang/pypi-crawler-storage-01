
from .assistant import BeamAssistant
