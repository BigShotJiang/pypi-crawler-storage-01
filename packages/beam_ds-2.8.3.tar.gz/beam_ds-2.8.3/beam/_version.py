# Description: Beam version file
__version__ = '2.8.3'

if __name__ == '__main__':
    print(__version__)
