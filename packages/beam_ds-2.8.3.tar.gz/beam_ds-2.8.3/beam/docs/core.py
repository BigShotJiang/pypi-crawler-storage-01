from datetime import datetime


class BeamDoc:
    pass
