Authors
=======

Pavol Juhas,
Chris Farrow,
Simon J.L. Billinge

Contributors
------------

For a list of contributors, visit
https://github.com/diffpy/diffpy.srreal/graphs/contributors
