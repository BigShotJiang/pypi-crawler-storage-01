from vartulz_compliance_sdk.paths.v1_utility_get_all_member.get import ApiForget


class V1UtilityGetAllMember(
    ApiForget,
):
    pass
