from vartulz_compliance_sdk.paths.v1_utility_fy_getall.get import ApiForget


class V1UtilityFyGetall(
    ApiForget,
):
    pass
