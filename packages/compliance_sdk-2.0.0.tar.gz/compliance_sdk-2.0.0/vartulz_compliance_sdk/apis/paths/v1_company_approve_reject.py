from vartulz_compliance_sdk.paths.v1_company_approve_reject.get import ApiForget


class V1CompanyApproveReject(
    ApiForget,
):
    pass
