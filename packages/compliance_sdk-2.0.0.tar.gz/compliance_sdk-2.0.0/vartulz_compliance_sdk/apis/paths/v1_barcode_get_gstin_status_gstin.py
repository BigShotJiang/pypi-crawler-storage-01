from vartulz_compliance_sdk.paths.v1_barcode_get_gstin_status_gstin.get import ApiForget


class V1BarcodeGetGstinStatusGstin(
    ApiForget,
):
    pass
