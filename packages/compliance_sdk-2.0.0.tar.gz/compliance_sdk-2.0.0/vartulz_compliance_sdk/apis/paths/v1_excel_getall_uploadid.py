from vartulz_compliance_sdk.paths.v1_excel_getall_uploadid.get import ApiForget


class V1ExcelGetallUploadid(
    ApiForget,
):
    pass
