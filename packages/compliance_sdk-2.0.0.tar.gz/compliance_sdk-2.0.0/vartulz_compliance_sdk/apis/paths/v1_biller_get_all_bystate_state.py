from vartulz_compliance_sdk.paths.v1_biller_get_all_bystate_state.get import ApiForget


class V1BillerGetAllBystateState(
    ApiForget,
):
    pass
