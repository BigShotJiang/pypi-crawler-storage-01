from vartulz_compliance_sdk.paths.v1_pan_get_details.post import ApiForpost


class V1PanGetDetails(
    ApiForpost,
):
    pass
