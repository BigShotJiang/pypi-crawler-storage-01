from vartulz_compliance_sdk.paths.v1_bank_add_verify.post import ApiForpost


class V1BankAddVerify(
    ApiForpost,
):
    pass
