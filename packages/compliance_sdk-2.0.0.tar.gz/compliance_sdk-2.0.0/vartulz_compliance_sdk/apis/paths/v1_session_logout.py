from vartulz_compliance_sdk.paths.v1_session_logout.get import ApiForget


class V1SessionLogout(
    ApiForget,
):
    pass
