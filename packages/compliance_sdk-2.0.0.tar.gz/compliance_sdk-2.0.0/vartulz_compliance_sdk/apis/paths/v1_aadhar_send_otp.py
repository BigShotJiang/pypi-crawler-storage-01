from vartulz_compliance_sdk.paths.v1_aadhar_send_otp.post import ApiForpost


class V1AadharSendOtp(
    ApiForpost,
):
    pass
