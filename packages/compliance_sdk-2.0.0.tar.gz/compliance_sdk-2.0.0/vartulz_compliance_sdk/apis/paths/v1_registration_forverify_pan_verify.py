from vartulz_compliance_sdk.paths.v1_registration_forverify_pan_verify.post import ApiForpost


class V1RegistrationForverifyPanVerify(
    ApiForpost,
):
    pass
