from vartulz_compliance_sdk.paths.v1_utility_get_preference_details_gstin.get import ApiForget


class V1UtilityGetPreferenceDetailsGstin(
    ApiForget,
):
    pass
