from vartulz_compliance_sdk.paths.v1_crypto_decrypt.post import ApiForpost


class V1CryptoDecrypt(
    ApiForpost,
):
    pass
