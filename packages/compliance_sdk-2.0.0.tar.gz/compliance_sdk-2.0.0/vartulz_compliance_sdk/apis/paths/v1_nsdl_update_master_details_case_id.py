from vartulz_compliance_sdk.paths.v1_nsdl_update_master_details_case_id.post import ApiForpost


class V1NsdlUpdateMasterDetailsCaseId(
    ApiForpost,
):
    pass
