from vartulz_compliance_sdk.paths.v1_utility_electricity_details.post import ApiForpost


class V1UtilityElectricityDetails(
    ApiForpost,
):
    pass
