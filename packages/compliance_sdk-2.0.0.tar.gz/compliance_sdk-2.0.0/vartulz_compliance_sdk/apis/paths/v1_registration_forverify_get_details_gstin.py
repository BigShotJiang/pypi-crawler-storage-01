from vartulz_compliance_sdk.paths.v1_registration_forverify_get_details_gstin.get import ApiForget


class V1RegistrationForverifyGetDetailsGstin(
    ApiForget,
):
    pass
