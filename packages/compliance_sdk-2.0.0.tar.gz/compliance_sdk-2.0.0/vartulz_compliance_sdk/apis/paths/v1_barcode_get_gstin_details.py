from vartulz_compliance_sdk.paths.v1_barcode_get_gstin_details.get import ApiForget


class V1BarcodeGetGstinDetails(
    ApiForget,
):
    pass
