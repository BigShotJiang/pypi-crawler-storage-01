from vartulz_compliance_sdk.paths.v1_bank_delete_bank.post import ApiForpost


class V1BankDeleteBank(
    ApiForpost,
):
    pass
