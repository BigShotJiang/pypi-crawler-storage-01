from vartulz_compliance_sdk.paths.v1_aadhar_submit_otp.post import ApiForpost


class V1AadharSubmitOtp(
    ApiForpost,
):
    pass
