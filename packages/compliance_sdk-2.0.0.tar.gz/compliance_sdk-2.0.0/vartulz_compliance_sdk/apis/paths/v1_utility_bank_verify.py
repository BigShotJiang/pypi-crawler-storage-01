from vartulz_compliance_sdk.paths.v1_utility_bank_verify.post import ApiForpost


class V1UtilityBankVerify(
    ApiForpost,
):
    pass
