from vartulz_compliance_sdk.paths.v1_gstin_update_track_details.post import ApiForpost


class V1GstinUpdateTrackDetails(
    ApiForpost,
):
    pass
