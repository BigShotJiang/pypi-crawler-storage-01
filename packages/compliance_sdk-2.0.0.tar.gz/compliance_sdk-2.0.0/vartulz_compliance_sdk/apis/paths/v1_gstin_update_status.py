from vartulz_compliance_sdk.paths.v1_gstin_update_status.post import ApiForpost


class V1GstinUpdateStatus(
    ApiForpost,
):
    pass
