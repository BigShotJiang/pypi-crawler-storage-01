from vartulz_compliance_sdk.paths.v1_pan_get_details_bycase.get import ApiForget


class V1PanGetDetailsBycase(
    ApiForget,
):
    pass
