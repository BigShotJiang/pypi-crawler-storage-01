from vartulz_compliance_sdk.paths.v1_profile_send_password_otp_company_id.get import ApiForget


class V1ProfileSendPasswordOtpCompanyId(
    ApiForget,
):
    pass
