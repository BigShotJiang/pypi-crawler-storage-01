from vartulz_compliance_sdk.paths.v1_utility_get_track_details_gstin.get import ApiForget


class V1UtilityGetTrackDetailsGstin(
    ApiForget,
):
    pass
