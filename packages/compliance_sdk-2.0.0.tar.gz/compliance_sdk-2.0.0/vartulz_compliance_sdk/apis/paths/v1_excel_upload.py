from vartulz_compliance_sdk.paths.v1_excel_upload.post import ApiForpost


class V1ExcelUpload(
    ApiForpost,
):
    pass
