from vartulz_compliance_sdk.paths.v1_barcode_get_iec_details.get import ApiForget


class V1BarcodeGetIecDetails(
    ApiForget,
):
    pass
