from vartulz_compliance_sdk.paths.v1_nsdl_update_electricitybill_details_case_id.post import ApiForpost


class V1NsdlUpdateElectricitybillDetailsCaseId(
    ApiForpost,
):
    pass
