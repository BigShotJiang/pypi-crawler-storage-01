from vartulz_compliance_sdk.paths.v1_profile_get_profile_balance.get import ApiForget


class V1ProfileGetProfileBalance(
    ApiForget,
):
    pass
