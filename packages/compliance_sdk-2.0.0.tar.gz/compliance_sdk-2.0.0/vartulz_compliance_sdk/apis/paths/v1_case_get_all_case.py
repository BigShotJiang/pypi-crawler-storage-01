from vartulz_compliance_sdk.paths.v1_case_get_all_case.get import ApiForget


class V1CaseGetAllCase(
    ApiForget,
):
    pass
