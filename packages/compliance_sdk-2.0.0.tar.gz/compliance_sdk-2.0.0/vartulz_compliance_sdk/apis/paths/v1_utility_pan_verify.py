from vartulz_compliance_sdk.paths.v1_utility_pan_verify.post import ApiForpost


class V1UtilityPanVerify(
    ApiForpost,
):
    pass
