This module add multi-company management to crm lost reason
