"""Tests for gsffile."""
