#!/bin/bash

apt update && dnf upgrade
apt install -y curl wget vim openssh python3 python3-pip java-17-openjdk