Notes on proof_of_space.md and build process for proof_of_space.html:

proof_of_space.html is generated from proof_of_space.md using "Markdown All in One" plugin for Visual Studio Code. The latest version of the plugin is 3.2.0 as of 2020-07-29.

The following settings should be changed to generate the HTML in a consistent way:
- Set "Absolute Img Path" to False.
- Set "Downcase Link" to False.
