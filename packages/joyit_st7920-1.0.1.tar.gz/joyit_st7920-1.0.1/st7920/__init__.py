from .st7920 import *

name = "st7920"