"""
Constants used across the Membit package.
"""

MEMBIT_API_URL = "https://api-app.membit.ai"
