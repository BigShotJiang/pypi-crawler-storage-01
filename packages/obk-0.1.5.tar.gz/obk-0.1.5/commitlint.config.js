/** commitlint.config.cjs */
module.exports = {
  extends: ['@commitlint/config-conventional'],
};

