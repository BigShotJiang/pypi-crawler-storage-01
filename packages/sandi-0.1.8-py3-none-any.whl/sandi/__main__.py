from sandi.app import App

import tkinter as tk

root = tk.Tk()
app = App(root)
root.mainloop()