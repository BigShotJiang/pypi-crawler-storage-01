To use this module, you need to:

1.  Go to Settings \> Users & Companies \> Brands

2.  Select a brand

3.  Define its bank account

4.  Create a new invoice
    1.  Select the brand
    2.  The bank account is automatically filled with the brand's specified bank account.
