from kirin import ir

dialect = ir.Dialect("qasm2.noise")
