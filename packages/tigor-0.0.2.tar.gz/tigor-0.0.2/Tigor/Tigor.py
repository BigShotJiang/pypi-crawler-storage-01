def a(x):
    return x