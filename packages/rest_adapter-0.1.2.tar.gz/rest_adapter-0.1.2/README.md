# Rest Adapter

[![PyPI version](https://badge.fury.io/py/rest-adapter.svg)](https://badge.fury.io/py/rest-adapter)
![Python version](https://img.shields.io/badge/Python_Version-3.10-blue.svg)
[![License](https://img.shields.io/pypi/l/rest-adapter)](https://opensource.org/licenses/GPL-3.0)


**Rest Adapter** is a Python wrapper for the Requests module. This is intended primarily for HBNet Networks internal use, but is free for any interested party to use.

## Please note
This project is a Work In Progress and is intended primarily for HBNet Networks internal use.

## Contributing

Contributions and suggestions are welcome! Please open issues or pull requests.

## License

This project is licensed under the GNU/GPL License. See the [LICENSE](LICENSE) file for details.

---

© 2025 HBNet Networks
