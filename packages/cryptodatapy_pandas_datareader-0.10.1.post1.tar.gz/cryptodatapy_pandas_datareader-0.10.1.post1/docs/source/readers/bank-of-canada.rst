Bank of Canada
--------------

.. py:module:: pandas_datareader.bankofcanada

.. autoclass:: BankOfCanadaReader
   :members:
   :inherited-members:
