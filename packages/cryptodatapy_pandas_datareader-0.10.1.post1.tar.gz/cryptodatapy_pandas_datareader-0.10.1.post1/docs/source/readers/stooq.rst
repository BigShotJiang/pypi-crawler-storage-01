Stooq.com
---------

.. py:module:: pandas_datareader.stooq

.. autoclass:: StooqDailyReader
   :members:
   :inherited-members:
