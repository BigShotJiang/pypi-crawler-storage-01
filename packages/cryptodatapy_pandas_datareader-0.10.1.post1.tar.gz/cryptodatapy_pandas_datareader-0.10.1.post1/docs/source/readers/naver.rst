Naver Finance
-------------

.. py:module:: pandas_datareader.naver

.. autoclass:: NaverDailyReader
   :members:
   :inherited-members: read
