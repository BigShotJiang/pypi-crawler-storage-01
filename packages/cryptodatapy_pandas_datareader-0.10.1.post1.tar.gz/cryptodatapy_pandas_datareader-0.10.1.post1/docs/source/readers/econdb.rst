Econdb
--------

.. py:module:: pandas_datareader.econdb

.. autoclass:: EcondbReader
   :members:
   :inherited-members:
