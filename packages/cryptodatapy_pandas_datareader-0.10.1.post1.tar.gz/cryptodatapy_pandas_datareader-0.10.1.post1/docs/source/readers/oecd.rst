Organisation for Economic Co-operation and Development (OECD)
-------------------------------------------------------------

.. py:module:: pandas_datareader.oecd

.. autoclass:: OECDReader
   :members:
   :inherited-members:
