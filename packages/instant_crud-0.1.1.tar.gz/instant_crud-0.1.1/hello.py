def main():
    print("Hello from instant-crud!")


if __name__ == "__main__":
    main()
