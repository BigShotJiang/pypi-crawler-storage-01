from .calzone import *
from .calzone import __doc__
del calzone

VERSION = "1.1.3"
