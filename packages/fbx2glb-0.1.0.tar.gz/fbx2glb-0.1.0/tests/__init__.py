"""
Test package for fbx2glb.
"""