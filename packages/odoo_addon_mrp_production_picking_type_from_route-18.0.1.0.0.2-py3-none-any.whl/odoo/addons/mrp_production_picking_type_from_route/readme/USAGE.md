To use this module, you need to:

1.  Go to *Manufacturing \> Manufacturing Orders*.
2.  Create a new MO.
3.  Select a product, the operation type has been updated based on the
    routes configured for that product.
