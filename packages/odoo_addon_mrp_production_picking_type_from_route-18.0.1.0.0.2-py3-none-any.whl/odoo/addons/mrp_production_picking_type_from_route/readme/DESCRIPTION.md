This module add an onchange that updates the operation type based on the
product while creating a new MO manually.
