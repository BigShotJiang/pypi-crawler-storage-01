REPO_URL = "https://github.com/FAIRmat-NFDI/nexus_definitions/tree/fairmat"
MANUAL_URL = "https://manual.nexusformat.org"
