import runpy

if __name__ == "__main__":
    runpy.run_module('llmvm.server.server', run_name="__main__")
