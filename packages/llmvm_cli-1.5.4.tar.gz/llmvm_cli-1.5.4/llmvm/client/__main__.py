import runpy

if __name__ == "__main__":
    runpy.run_module('llmvm.client.cli', run_name="__main__")