# sage_setup: distribution = sagemath-qepcad
