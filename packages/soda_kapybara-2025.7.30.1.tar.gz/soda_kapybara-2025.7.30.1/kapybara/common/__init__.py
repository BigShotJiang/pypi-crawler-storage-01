"""
通用组件

"""

from .envWrite import env_write

__all__ = [
    "env_write",
]