from pipelet.decarators.logging_decorator import logging_decorator

__all__ = ("logging_decorator",)
