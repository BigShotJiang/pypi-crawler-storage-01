from pipelet.processors.chain_processors.base import (
    ChainAllProcessor,
    ChainAnyProcessor,
)

__all__ = (
    "ChainAnyProcessor",
    "ChainAllProcessor",
)
