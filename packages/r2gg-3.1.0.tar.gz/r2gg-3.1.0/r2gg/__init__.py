#! python3  # noqa: E265

# submodules
from .__about__ import __version__  # noqa: F401
