from llama_index.embeddings.clarifai.base import ClarifaiEmbedding

__all__ = ["ClarifaiEmbedding"]
