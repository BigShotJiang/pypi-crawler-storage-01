# LlamaIndex Embeddings Integration: Clarifai
