def main():
    print("Hello from krnel-client-library!")


if __name__ == "__main__":
    main()
