This module add multi-company management to res partner industry
