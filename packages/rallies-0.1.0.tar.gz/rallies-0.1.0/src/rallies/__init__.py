"""Rallies - Stock Analysis Agent"""

from rich.console import Console

__version__ = "0.1.0"

console = Console()