# JobLogLevel


## Enum

* `DEBUG` (value: `'debug'`)

* `INFO` (value: `'info'`)

* `WARNING` (value: `'warning'`)

* `ERROR` (value: `'error'`)

* `CRITICAL` (value: `'critical'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


