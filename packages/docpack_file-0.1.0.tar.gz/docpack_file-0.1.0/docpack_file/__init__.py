"""Docpack - A package format for document outlines and resources."""

from .handler import DocpackHandler

__version__ = "0.1.0"
__all__ = ["DocpackHandler"]