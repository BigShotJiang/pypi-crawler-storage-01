from ecsapi import Api

api = Api()

print(api.fetch_server("ec206907"))
