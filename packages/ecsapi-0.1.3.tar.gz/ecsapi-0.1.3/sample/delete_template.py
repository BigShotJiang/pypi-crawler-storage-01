from ecsapi import Api

api = Api()

print(api.delete_template(593))
