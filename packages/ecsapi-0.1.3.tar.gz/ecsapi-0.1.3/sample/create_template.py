from ecsapi import Api

api = Api()

print(api.create_template(server="ec206918"))
