from ecsapi import Api

api = Api()

print(api.update_template(598, "update by ecsapi", "update by ecsapi"))
