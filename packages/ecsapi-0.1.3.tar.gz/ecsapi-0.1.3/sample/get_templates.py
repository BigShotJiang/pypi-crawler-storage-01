from ecsapi import Api

api = Api()

print(api.fetch_templates())
