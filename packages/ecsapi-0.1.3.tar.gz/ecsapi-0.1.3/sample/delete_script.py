from ecsapi import Api

api = Api()

print(api.delete_script(54))
