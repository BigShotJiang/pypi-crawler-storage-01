# weavster

[![Release](https://img.shields.io/github/v/release/weavster-dev/weavster)](https://img.shields.io/github/v/release/weavster-dev/weavster)
[![Build status](https://img.shields.io/github/actions/workflow/status/weavster-dev/weavster/main.yml?branch=main)](https://github.com/weavster-dev/weavster/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/weavster-dev/weavster)](https://img.shields.io/github/commit-activity/m/weavster-dev/weavster)
[![License](https://img.shields.io/github/license/weavster-dev/weavster)](https://img.shields.io/github/license/weavster-dev/weavster)

Weavster is a cloud-native integration platform that brings declarative simplicity to data pipelines of all sizes.
