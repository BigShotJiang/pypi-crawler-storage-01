__version__ = "0.1.3"
__copyright__ = "Copyright AgileBits, Inc. 2022; Jeffrey Goldberg 2024–2025"
