#ifndef EIGEN_CXX11_TENSOR_MODULE_H
#error "Please include unsupported/Eigen/CXX11/Tensor instead of including headers inside the src directory directly."
#endif
